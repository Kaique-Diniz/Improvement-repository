# H3-O-D3-T — duração, falhas e encerramento

27/11/2026 — America/Sao_Paulo. Especificação documental proposta; não implementada, não validada e sem autorização de execução.

## Base textual e lacunas comprovadas somente por leitura

R01: B003–016 inicializa antes do try B112; B346–383 consolida/serializa depois
de catch/finally. Falhas nessas regiões podem impedir o objeto normal, sem prova
de ocorrência nesta etapa. N04-01/03/04/05 cobrem escopo, propagação, consolidação
e serialização ainda não exercitados. Não prometer JSON universal.

R02: B074/B077 estabelecem opções WMI de 10 segundos; B086 limita 256 registros.
Não são orçamento global de conexão implícita/Get/MoveNext/Current/Dispose,
serialização, captura e término. N03-04/N02-06 dependem de evidência nativa própria.
Provider, COM/RPC e host podem permanecer em atividade não observável pelo bloco.

B093–107 tenta descarte, registra flag e pode lançar outra exceção; B337–338 tenta
WindowsIdentity.Dispose. Finally pode falhar, não rodar em término fatal ou
sobrepor erro anterior. Flag false é indicação de falha; true não prova externamente
o fechamento de tudo. Não alterar os quatro tratamentos R1 D01–D04.

## Eventos necessários e tratamento proposto

| Evento ou lacuna | Distinção exigida | Registro e resposta futuros |
|---|---|---|
| Ausência de saída | Zero conteúdo esperado difere de fragmento e de silêncio sobre início | Evidência ausente; não inventar objeto ou causa |
| Falha de inicialização comprovada | Evento anterior ao início do procedimento, se essa fronteira foi realmente observada | Registrar fase e limite; não atribuir a processing por suposição |
| Falha de processamento comprovada | Evento depois do início observado, durante operação identificada | Registrar fase/API somente quando comprovadas e sanitizáveis |
| Fase incerta | Sem observabilidade suficiente para localizar falha | Fase desconhecida e resultado inconclusivo; sem reconstruir chamada |
| Truncamento/serialização incompleta | Há dados, completude não demonstrada | Evidência incompleta; preservar captura legítima sem repará-la |
| Objeto incompatível ou saída adicional | Não é só uma ausência de erro | Evidência incompatível; não selecionar trecho favorável |
| Impedimento de escopo/privacidade | Não admite continuar para descobrir mais contexto | Suspender novas ações; aplicar apenas parada previamente revisada |
| Duração excedida ou observador perdido | Não equivale a processo terminado | Registrar evento real e encerramento não comprovado |
| Interrupção observada | Pedido de cancelamento não prova efeito da interrupção | Distinguir pedido, efeito observado e término |
| Término do processo | Evento sobre a instância acompanhada | Separar provider/recursos incertos; sem aprovação implícita |
| Descarte falho/recursos incertos | Ausência de exceção final não corrige flag ou falha anterior | Encerramento não comprovado; não reiniciar |
| Falha do próprio receptor/registro | Perda de observabilidade do contrato externo | Bloquear interpretação favorável; não fabricar início/fim retroativos |

As falhas que exigem suspensão incluem integridade/autoridade/escopo incompatíveis,
tentativa ou risco não resolvido de leitura fora da área, privacidade comprometida,
erro de API relevante, dados indispensáveis ausentes, perda de recepção, limite
aprovado excedido e encerramento incerto. Não há rotina de parada implementada
por esta lista. Se não existir forma segura previamente revisada, não iniciar.

## Duração total: decisão e propriedade técnica distintas

A decisão legítima futura precisa delimitar marco inicial, marco final, propriedade
a limitar, papel responsável, cobertura de chamadas bloqueantes, método de medição,
limite total, tratamento de perda de acompanhamento e evidência de término.
Nenhum prazo global é fixado aqui. Os 180 dias de retenção não são limite de
execução. Hora de parede com fuso tem limitações e não substitui um método de
medição de duração apropriado ainda por escolher.

Distinguir duração do procedimento, tempo de acompanhamento e latência de encerramento.
Não afirmar que contar tempo impõe limite às chamadas ou fecha recursos.
Sem solução revisada de duração e parada, M-C11/M-C12 continuam impeditivos.
Uma espera com retorno incerto não pode ser tratada como observação concluída
apenas por finalidade limitada.

## Alternativas de desenho a estudar, nenhuma escolhida

- Enquadramento externo de recepção e eventos, mantendo o procedimento intacto,
  somente se demonstrar cobertura suficiente sem executar para autoautorizar.
- Redefinição mínima futura de limites de tratamento/saída do procedimento,
  preservando motivos/códigos e sem prometer captura de falha fatal de host.
- Mecanismo externo de acompanhamento em projeto próprio, se necessário. Um
  processo separado não demonstra sozinho limite de provider ou encerramento.
- Redução futura de consultas não essenciais, somente por projeto revisado e
  sem dispensar os controles de segurança das leituras mantidas.

Watchdog, supervisor, cancelamento ou término forçado não são selecionados nem
criados. Exigiriam análise de direitos, efeitos, recursos remanescentes, privacidade,
compatibilidade PS5.1 e autorização específica. Nenhum kill, serviço, retry ou
alteração persistente é instruído.

## Evidência necessária para falar em encerramento

A futura evidência deve vincular instância/fonte/autorização; registrar início
quando observado, falhas, tentativas/resultado de descarte e término observado;
identificar recursos efetivamente abrangidos e pontos sem observabilidade.
Diferenciar objeto ManagementObject, enumerador, coleção, searcher, identidade
e recursos do host/provider. Não ampliar consultas para inventariar estado privado.

Aceitação futura não exige alegar inexistência universal de efeitos: exige
conclusão delimitada e defensável sobre os recursos indispensáveis no escopo,
com as incertezas remanescentes explicitadas. Se a incerteza comprometer segurança
ou encerramento necessário, a conclusão permanece bloqueante. Observador perdido,
flag false, exceção de descarte ou ausência de evento de término não satisfazem
o requisito.

## Proibição de repetição automática

Não repetir após divergência de identidade, escopo/autorização insuficiente,
saída ausente/incompatível, interrupção, espera indeterminada, falha de descarte,
privacidade ou encerramento incerto. Mesmo nova autorização não apaga a rodada
anterior. Eventual repetição exige revisão das causas, demonstração de precondições
e decisão própria; nunca repetição infinita ou reuso silencioso do registro.
Registro parcial só por meio previamente legitimado/protegido, sem inventar sucesso.
