# H3-O-D3-T — escolhas técnicas ainda abertas

27/11/2026 — America/Sao_Paulo. Especificação documental proposta; não implementada, não validada e sem autorização de execução.

## Autoridade e fronteira

L-D01=A e L-D02=11 classificações deliberadas estão preservadas; não se pede nova
aprovação de G01–G11. Os tópicos D3T-Q são decisões futuras de projeto, não decisões
privadas L-D tomadas pelo executor. Campos/valores de operador, host, caminhos,
SIDs, validade e duração permanecem não preenchidos.

Custodiante e demais autoridades legítimas decidem legitimidade, escopo, papéis,
referências privadas, exposição/privacidade e validade em seu âmbito. Revisores
técnicos propõem mecanismos e demonstram propriedades; não conferem autoridade
institucional nem aceitam risco em nome do custodiante. Nenhum papel nominal ou
competência é comprovado por esta distribuição conceitual.

| ID | Questão a decidir em escopo próprio | Alternativas de desenho e dependência | Critério de decisão futura, sem escolha atual |
|---|---|---|---|
| D3T-Q01 | Origem e vínculo à instância | Cadeia externa legítima; eventual ajuste do emissor se insuficiente | Demonstrar quais bytes/rodada/autorização, sem confiar apenas no rótulo próprio; A01 |
| D3T-Q02 | Canais/codificação/representação | Captura e formato de versão definidos em projeto próprio; sem fallback silencioso | Preservar completude/privacidade, recusar extras/duplicatas/coerções; A05/A10 |
| D3T-Q03 | Fronteiras de falhas | Recepção externa, possível envelope interno ou combinação | Cobrir ausência/parcialidade sem prometer JSON em fatal; A02 |
| D3T-Q04 | Duração total e resposta | Método de medição/acompanhamento e limite legítimo ainda não fixados | Cobertura verificável de espera e resposta segura; não confundir timeout WMI e retenção; A03 |
| D3T-Q05 | Recursos/encerramento | Prova pertinente por recurso e observador, limite de provider/host explícito | Término não certifica recurso; falha/incerteza bloqueia continuidade; A04 |
| D3T-Q06 | Identidade e confinamento | Prova independente de alcance/mutabilidade; mecanismo físico por projeto se indispensável | Nenhuma leitura fora do escopo; releitura/atributo igual não basta; A06 |
| D3T-Q07 | Confronto privado L-D06 | Cobertura/método/validade legítimos antes da leitura; possível interface futura | Sete classes preservadas, referência ausente inconclusiva, sem Git/scan ou caminhos aqui; A07 |
| D3T-Q08 | Proteção necessária à leitura | Evidência independente ou método efetivo em escopo próprio se necessário | Não usar DACL ancestral/contadores para certificar direitos ou destino futuro; A08 |
| D3T-Q09 | Resolução e origem do host | Proveniência aceita; eventual revisão de qualificação/dependências | Sem autoload presumido inofensivo ou configuração persistente alterada; A09 |
| D3T-Q10 | Registro privado e resumo | Destinatários/proteção/minimização decididos privadamente | Não ocultar evidência adversa, expor privado, criar custódia ou prometer apagamento; A10 |
| D3T-Q11 | Necessidade e alcance de WMI/indicadores | Manter desenho limitado ou revisão futura de consultas necessárias | Sem ampliar inventário, dispensar administrativo, trocar inconclusão por aprovação; A11/A12 |
| D3T-Q12 | Versão, critérios e validação | Identidade nova para qualquer revisão; separar estática/nativa/contrato/inspeção/custódia | Nenhuma herança automática de N01/resultado antigo; quinze N e G10 exigem evidência própria |

Todos os 12 tópicos: NAO_ESCOLHIDO, NAO_APROVADO, NAO_IMPLEMENTADO, NAO_VALIDADO.
A recomendação técnica da matriz não é adoção da opção nem autorização de
implementar. A01–A15 são identificadores de propostas D3T, sem ligação operacional.

## Categorias de propostas

- OBRIGATORIA_ANTES_DE_OBSERVACAO: tratamento suficiente de origem/vínculo,
  ausência/falhas, duração/parada, fechamento, recepção/coerência e privacidade.
  A necessidade é da propriedade/tratamento, não de modificar necessariamente R1.
- CONDICIONAL_A_DECISAO_OU_EVIDENCIA: mecanismo de identidade, confronto de
  referências, efetividade pertinente, resolução e provedores. A segurança da
  leitura não é condicional/dispensável; se o mecanismo ainda não escolhido for
  necessário àquela segurança, a leitura não pode começar.
- APRIMORAMENTO_NAO_INDISPENSAVEL: telemetria além do mínimo suficiente e redução
  de falso positivo. Não elimina o mínimo obrigatório nem as recusas conservadoras.
- EXCLUSIVA_DE_PORTAO_POSTERIOR: reserva/criação exclusiva e proteção da cópia
  futura/H3-C, sem deslocar para depois proteção necessária à própria observação.

## Implementação eventualmente submetível a autorização

Um futuro pedido poderia delimitar apenas D/E/F: origem/vínculo, tratamento de
recepção incompatível/ausente, eventos reais, duração/encerramento e registro
mínimo, com critérios M-C e versão próprios. Isso seria proposta de implementação,
não algo autorizado ou iniciado. Se auditoria demonstrar necessidade de revisão
de C, propor separadamente fronteiras de erro, identidade/confinamento ou outro
mecanismo mínimo, com riscos/compatibilidade/fechamento e validação própria.

Não incluir por implicação: supervisor/watchdog/término forçado, novas flags/APIs,
política DACL, teste entre contas, L-D06 privada, criação de destino, XML, runner C,
operações financeiras ou conversão. Nenhum teste/comando, mock ou fixture executável
é preparado aqui. A futura aprovação do desenho não deve autorizar execução nativa
automaticamente.
