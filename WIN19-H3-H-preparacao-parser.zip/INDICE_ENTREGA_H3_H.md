# WIN19-H3-H — índice e proveniência

24/11/2026 — America/Sao_Paulo. Pasta documental nova externa ao Git:
/workspace/work/WIN19-H3-H-PREPARACAO-PARSER-20261124.
Não é destino de custódia, arquivo executável ou diretório criado no Windows.

## Oito arquivos exclusivos

1. [RELATORIO_H3_H_PREPARACAO.md](RELATORIO_H3_H_PREPARACAO.md) — objetivo,
   identidades, método e estado real não executado.
2. [PROCEDIMENTO_PARSER_PS51.md](PROCEDIMENTO_PARSER_PS51.md) — único bloco auxiliar
   proposto para futura revisão, não executado nem parseado nesta tarefa.
3. [REVISAO_ESTATICA_PARSER.md](REVISAO_ESTATICA_PARSER.md) — separação dado/execução,
   operações, guardas, efeitos indiretos e limitações.
4. [PROTOCOLO_EXECUCAO_WINDOWS.md](PROTOCOLO_EXECUCAO_WINDOWS.md) — roteiro
   prospectivo condicionado a revisão/autorização próprias, sem solicitação atual.
5. [MODELO_RESULTADO_SINTATICO.md](MODELO_RESULTADO_SINTATICO.md) — chaves/tipos e
   estados da saída, sem instância fictícia de sucesso.
6. [LIMITACOES_E_PORTOES_H3_H.md](LIMITACOES_E_PORTOES_H3_H.md) — limites do parser,
   nove riscos/quatro itens não verificados integrais e bloqueios.
7. INDICE_ENTREGA_H3_H.md — este inventário.
8. [MANIFESTO_SHA256_H3_H](MANIFESTO_SHA256_H3_H) — tamanho/hash dos sete anteriores;
   sem autorreferência, com hash próprio informado na conversa.

## Instrução e parecer obrigatórios

Texto colado.txt, instrução H3-H de 24/11/2026: 12.585 bytes, SHA-256
bd28f384d46c3e7b8a4742925a82732f3218435b0a01d6a55eb734ec3e3ac4c0.
PARECER_INDEPENDENTE_WIN19_H3_F_R1_2026-11-24.md: 7.253 bytes, SHA-256
eb6d4941b8e6c280c574a08ef45d8b6538bc91f0f3352ff189059f752110d365.
Ambos lidos integralmente como documentos; não executados nem copiados aqui.
Parecer aceita apenas materialização/integridade R1 com ressalvas; instrução
H3-H autoriza preparar, mas não executar auxiliar/parser ou procedimento de destino.

## Referências H3-F-R1 autenticadas e preservadas

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md | 22438 | d927512fb7a00ed5614d8920717670b0675865518a865f8fdbed569f685a9145 |
| EVIDENCIA_COMPARACAO_BINARIA.md | 4231 | a7fa90aabe215a4dceae7fdfee99e33d656c5db60a7c8f9eb4c33e407ee869fd |
| RISCOS_PENDENTES_E_PORTOES.md | 12028 | 74bc0dd84073b06ebbce245600e47a342f2ce0c7925518fd19436f82a2482d8a |
| INDICE_ENTREGA_H3_F_R1.md | 4749 | 80d818408e7d78e732b782f78219dd74cd4e3451096627a6bfad30dc2c5bb685 |
| MANIFESTO_SHA256_H3_F_R1 | 633 | 5b517e9b7572c5505b6bd35ecefb19ad127e0d4e7842bc0447f61b15b311f99d |

Todos os seis documentos cobertos e o manifesto foram conferidos e permaneceram
iguais antes/depois. Pacote H3-F-R1 anterior: 20.627 bytes, SHA-256
442e17cfaae0afe91ff63d3fa60ba3e824e988f0ff586a436f9513a4612dffaa,
preservado. Nenhum contrato ou candidata foi copiado para esta pasta.

Bloco fonte autenticado: 20.362 bytes/383 linhas UTF-8 sem BOM, LF e LF final,
SHA-256 af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5.
Extração documental dos marcadores H3_F_R1, excluindo cercas e preservando LF final;
nenhum parser PowerShell foi usado para conferir esses bytes.

## Identidade e extração do auxiliar H3-H

Em PROCEDIMENTO_PARSER_PS51.md, extrair bytes após a cerca powershell imediatamente
seguinte a INICIO_BLOCO_AUXILIAR_H3_H até a cerca final imediatamente anterior a
FIM_BLOCO_AUXILIAR_H3_H. Excluir marcadores/cercas, incluir o LF final do código.
UTF-8 sem BOM, apenas LF; não normalizar. Há strings de cercas da fonte dentro
do auxiliar: elas não são o delimitador final próprio da H3-H.

Auxiliar: 12997 bytes, 234 linhas. SHA-256
1353dd74a7abbf6569b62ae21ad8169e6ca66a0626a8ff23973742c229599bcb.
Hash identifica texto proposto, não funcionamento/sintaxe ou aprovação.

## Fontes públicas de apoio

Documentação Microsoft consultada em 24/11/2026, sem executar exemplos:
[Parser.ParseInput](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.parser.parseinput),
[ParseError](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.parseerror?view=powershellsdk-7.6.0),
[IScriptExtent](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.iscriptextent),
[UTF8Encoding](https://learn.microsoft.com/en-us/dotnet/api/system.text.utf8encoding.-ctor?view=netframework-4.8.1).
O portal agrega versões de SDK, incluindo referência 5.1; isso não é evidência de
biblioteca presente no Windows-alvo. Uma abertura genérica inicial de ParseError
não retornou conteúdo; consulta pública com versão exposta permitiu obter o
contrato. Nenhuma biblioteca foi instalada ou usada como substituto de PS5.1.

## Ferramentas e parada

Python -I -B/biblioteca padrão somente para leitura dos documentos/metadados,
bytes, extração documental e hashes/manifesto; terminal Linux. Revisão estática
manual do auxiliar, sem parser, lint, execução, teste ou simulação do PowerShell.
Os códigos e JSON de erro no auxiliar são prospectivos, não evidências nativas.
Não houve WMI, ACL, XML/JUnit, criação de custódia, privilégio, política, conta,
Git/R1-FIX, .ps1, ZIP, instalação, commit/push/merge/publicação. Só oito arquivos
pedidos. PARSING_NATIVO_PS51=NAO_EXECUTADO; parar para auditoria independente.
