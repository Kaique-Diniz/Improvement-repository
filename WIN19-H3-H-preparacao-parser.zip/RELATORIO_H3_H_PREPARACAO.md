# WIN19-H3-H — preparação da análise sintática nativa

24/11/2026 — America/Sao_Paulo.
**H3-H=PROCEDIMENTO_PARSER_PROPOSTO_AGUARDANDO_REVISAO.**
**PARSING_NATIVO_PS51=NAO_EXECUTADO.**

## Entrega e situação atual

Preparados sete documentos e manifesto em pasta nova externa ao Git. O auxiliar
PowerShell está apenas em PROCEDIMENTO_PARSER_PS51.md, com marcadores e hash;
não foi executado, submetido a parser, lint, teste sintático ou simulação.
O ambiente disponível é Linux, sem evidência de Windows PowerShell 5.1 nativo.
Não se utilizou PowerShell 7 ou ferramenta alternativa para substituir essa prova.

A fonte H3-F-R1 foi autenticada documentalmente por bytes/hashes, sem interpretar
sua linguagem. Isso é diferente das verificações que o auxiliar fará, somente se
futuramente autorizado no Windows. A quantidade de erros sintáticos não foi medida;
não é zero informado por suposição. Nenhuma saída de sucesso foi produzida.

## Identidade da fonte que deverá ser analisada

Markdown COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md: 22.438 bytes, SHA-256
`d927512fb7a00ed5614d8920717670b0675865518a865f8fdbed569f685a9145`.
Bloco revisado completo: 20.362 bytes, 383 linhas, UTF-8 sem BOM, somente LF e
LF final; SHA-256
`af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5`.
A extração usa os marcadores H3_F_R1 originais, exclui cercas/marcadores e mantém
todos os bytes internos. A chamada final permanece na string de entrada.

## Separação entre dado e execução

O auxiliar futuro autentica ambiente, método disponível, caminho privado da fonte,
tamanho/hash do documento, UTF-8 estrito, marcadores e identidade do bloco.
O arquivo é aberto apenas para leitura, sem criar/copiar, e fechado antes de
chamar o parser. A única análise do texto é a sobrecarga de três argumentos de
System.Management.Automation.Language.Parser.ParseInput: string, tokens por
referência, erros por referência. O resultado AST não é convertido em scriptblock
ou invocado; tokens e código-fonte não são publicados. Somente ErrorId e posições
numéricas são destinados ao JSON sanitizado, sem Message/Extent.Text.

A chamada final do auxiliar invoca apenas o próprio auxiliar, em etapa futura.
Ela não é a chamada principal H3-F-R1 armazenada como texto. Não carregar a fonte
por colagem, dot-source, importação, Invoke-Expression ou execução direta.

## Referência independente e limites

Parecer H3-F-R1 lido integralmente: aceita materialização/integridade com ressalvas,
não aprova execução. Preservados os nove riscos R01–R09 e quatro itens N01–N04,
registrados integralmente nas limitações. Nenhum foi promovido a resolvido.
A preparação não comprova resolução .NET, WMI, finally, recursos, JSON, semântica
V01–V10, segurança, proteção/identidade do destino ou autenticidade do JUnit.

## Identidade do auxiliar e conferências realizadas

Bloco auxiliar proposto: 12997 bytes, 234 linhas UTF-8 sem BOM/LF.
SHA-256: `1353dd74a7abbf6569b62ae21ad8169e6ca66a0626a8ff23973742c229599bcb`.
Extração precisa no próprio documento e no índice; hash não valida funcionamento.
Os sete documentos novos tiveram tamanhos/hashes conferidos no manifesto, que
não se autorreferencia. H3-F-R1 e pacote anterior permanecem idênticos.

Somente documentação, revisão estática e metadados de integridade. Não houve
parser, procedimento auxiliar, PowerShell, WMI, ACL, acesso/cópia/sanitização do
JUnit, criação de custódia, mudança de segurança, Git/R1-FIX, instalação, .ps1,
ZIP, commit, push, merge ou publicação. Parar para auditoria independente.
