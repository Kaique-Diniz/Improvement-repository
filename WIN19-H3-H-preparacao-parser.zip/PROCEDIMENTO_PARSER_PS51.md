# H3-H — auxiliar de parsing PS5.1 proposto, não executado

24/11/2026 — America/Sao_Paulo.
**PROCEDIMENTO_PARSER_PROPOSTO_AGUARDANDO_REVISAO. NÃO EXECUTAR AGORA.**

Este é o auxiliar futuro, distinto do texto H3-F-R1 que será analisado como dado.
Não foi submetido a parsing, teste ou execução nesta entrega. Não há .ps1.
Requer revisão independente e autorização específica antes de qualquer uso.
Sessão futura: Windows PowerShell 5.1 Desktop local, confiável, sem elevação,
sem perfil/scripts externos ou captura/transcrição não autorizada. Nenhuma
instalação, política de execução ou comando de lançamento é fornecido.

A entrada única é o caminho privado do Markdown já autenticado, com seu nome
original. Não fornecer caminho do JUnit, de destino ou dados pessoais no chat.
O código recusa fonte não local fixa, reparse detectado e identidade divergente.
Essas restrições são somente para ler o documento; não avaliam a custódia.
Nenhum procedimento H3-F-R1 é invocado. A chamada final dele é preservada no
texto recebido por ParseInput, sem dot-source, compilação ou execução da AST.

<!-- INICIO_BLOCO_AUXILIAR_H3_H -->
```powershell
function Invoke-H3HParserProposto {
    # AUXILIAR PROPOSTO: nao executar antes de revisao/autorizacao separadas.
    $ErrorActionPreference = 'Stop'
    $r = [ordered]@{
        etapa = 'WIN19-H3-H'; versao_auxiliar = '20261124-proposta-1'
        ambiente_parser = 'NAO_CONFIRMADO'; versao_powershell = $null
        api_parser_disponivel = $false; parser_assembly_nome = $null
        parser_assembly_versao = $null
        fonte_sha256_conferida = $false; fonte_tamanho_bytes = $null
        bloco_sha256_conferido = $false; bloco_tamanho_bytes = $null
        bloco_linhas = $null; parser_invocado = $false; parsing_concluido = $false
        quantidade_erros = $null; erros_sintaticos = @()
        resultado_sintatico = 'PARSING_NAO_EXECUTADO'; codigo_impedimento = $null
        script_analisado_executado = $false; recursos_leitura_fechados = $true
    }
    $control = [pscustomobject]@{ Parada = $false; Fase = 'AMBIENTE' }
    $pathPrivate = $null; $documentBytes = $null; $documentText = $null
    $sourceBytes = $null; $sourceText = $null; $ast = $null
    $tokens = $null; $parseErrors = $null
    function Stop-H3H([string]$Result, [string]$Code) {
        $r.resultado_sintatico = $Result; $r.codigo_impedimento = $Code
        $control.Parada = $true
        throw [OperationCanceledException]::new('H3H_PARADA_CONTROLADA')
    }
    function Get-H3HHash([byte[]]$Bytes) {
        $sha = $null
        try {
            $sha = [Security.Cryptography.SHA256]::Create()
            return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant()
        } finally {
            if ($null -ne $sha) {
                try { $sha.Dispose() } catch {
                    $r.recursos_leitura_fechados = $false
                    throw [InvalidOperationException]::new('H3H_ENCERRAMENTO_HASH_FALHOU')
                }
            }
        }
    }
    try {
        $r.versao_powershell = $PSVersionTable.PSVersion.ToString()
        if (($PSVersionTable.PSVersion.Major -ne 5) -or
            ($PSVersionTable.PSVersion.Minor -ne 1) -or
            ($PSVersionTable.PSEdition -ne 'Desktop') -or
            ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT)) {
            Stop-H3H 'PARSING_NAO_EXECUTADO' 'H3H_REQUER_WINDOWS_POWERSHELL_51'
        }
        $sender = Microsoft.PowerShell.Utility\Get-Variable -Name PSSenderInfo -ErrorAction SilentlyContinue
        $session = [Environment]::GetEnvironmentVariable('SESSIONNAME', 'Process')
        if (($null -ne $sender -and $null -ne $sender.Value) -or
            ($Host.Name -eq 'ServerRemoteHost') -or ($session -match '^(RDP|ICA)')) {
            Stop-H3H 'PARSING_NAO_EXECUTADO' 'H3H_SESSAO_REMOTA_FORA_DO_ESCOPO'
        }
        $control.Fase = 'API'
        $parserType = [System.Management.Automation.Language.Parser]
        $signature = [type[]]@([string],
            [System.Management.Automation.Language.Token[]].MakeByRefType(),
            [System.Management.Automation.Language.ParseError[]].MakeByRefType())
        $method = $parserType.GetMethod('ParseInput', $signature)
        $assembly = $parserType.Assembly.GetName()
        if ($null -eq $method -or -not $method.IsStatic -or
            $assembly.Name -ne 'System.Management.Automation') {
            Stop-H3H 'PARSING_NAO_EXECUTADO' 'H3H_API_PARSER_NAO_CONFIRMADA'
        }
        $r.ambiente_parser = 'WINDOWS_POWERSHELL_51_DESKTOP'
        $r.api_parser_disponivel = $true
        $r.parser_assembly_nome = 'System.Management.Automation'
        $r.parser_assembly_versao = $assembly.Version.ToString()
        # Metadados da assembly nao substituem confianca previa no host nativo.
        $control.Fase = 'CAMINHO'
        $pathPrivate = Microsoft.PowerShell.Utility\Read-Host -Prompt 'Caminho local privado do Markdown H3-F-R1 (somente leitura)'
        if ([string]::IsNullOrWhiteSpace($pathPrivate) -or
            ($pathPrivate -ne $pathPrivate.Trim()) -or ($pathPrivate.Length -gt 240) -or
            ($pathPrivate -notmatch '^[A-Za-z]:\\') -or $pathPrivate.Contains('/') -or
            -not [IO.Path]::GetFileName($pathPrivate).Equals(
                'COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md', [StringComparison]::OrdinalIgnoreCase)) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_CAMINHO_FONTE_INVALIDO'
        }
        if (-not [IO.Path]::GetFullPath($pathPrivate).Equals($pathPrivate, [StringComparison]::OrdinalIgnoreCase)) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_CAMINHO_FONTE_AMBIGUO'
        }
        $parts = @($pathPrivate.Substring(3).Split([char]92))
        foreach ($part in $parts) {
            if ([string]::IsNullOrWhiteSpace($part) -or ($part -ne $part.Trim()) -or
                $part.EndsWith('.') -or $part.Contains('~') -or ($part -in @('.', '..')) -or
                ($part.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) -or
                ($part -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]|CONIN\$|CONOUT\$)(\..*)?$')) {
                Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_COMPONENTE_FONTE_AMBIGUO'
            }
        }
        $root = $pathPrivate.Substring(0, 3)
        $drive = [IO.DriveInfo]::new($root)
        if ($drive.DriveType -ne [IO.DriveType]::Fixed -or -not $drive.IsReady) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_FONTE_NAO_LOCAL_FIXA'
        }
        $cursor = $root
        $rootAttributes = [IO.File]::GetAttributes($root)
        if (($rootAttributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or
            ($rootAttributes -band [IO.FileAttributes]::Directory) -eq 0) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_RAIZ_FONTE_INADEQUADA'
        }
        for ($i = 0; $i -lt $parts.Count; $i++) {
            $cursor = [IO.Path]::Combine($cursor, $parts[$i])
            $attr = [IO.File]::GetAttributes($cursor)
            if (($attr -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_REPARSE_FONTE_DETECTADO'
            }
            if (($i -lt $parts.Count - 1 -and ($attr -band [IO.FileAttributes]::Directory) -eq 0) -or
                ($i -eq $parts.Count - 1 -and ($attr -band [IO.FileAttributes]::Directory) -ne 0)) {
                Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_TIPO_FONTE_INADEQUADO'
            }
        }
        $control.Fase = 'LEITURA'
        $reader = $null
        try {
            $reader = [IO.FileStream]::new($pathPrivate, [IO.FileMode]::Open,
                [IO.FileAccess]::Read, [IO.FileShare]::Read)
            $r.fonte_tamanho_bytes = $reader.Length
            if ($reader.Length -ne 22438) {
                Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_TAMANHO_DOCUMENTO_DIVERGENTE'
            }
            $documentBytes = [byte[]]::new(22438)
            $offset = 0
            while ($offset -lt $documentBytes.Length) {
                $n = $reader.Read($documentBytes, $offset, $documentBytes.Length - $offset)
                if ($n -le 0) { Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_LEITURA_DOCUMENTO_INCOMPLETA' }
                $offset += $n
            }
            if ($reader.ReadByte() -ne -1 -or $reader.Length -ne 22438) {
                Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_DOCUMENTO_INSTAVEL'
            }
        } finally {
            if ($null -ne $reader) {
                try { $reader.Dispose() } catch {
                    $r.recursos_leitura_fechados = $false
                    throw [InvalidOperationException]::new('H3H_ENCERRAMENTO_FONTE_FALHOU')
                } finally { $reader = $null }
            }
        }
        $control.Fase = 'FONTE'
        if ((Get-H3HHash $documentBytes) -ne 'd927512fb7a00ed5614d8920717670b0675865518a865f8fdbed569f685a9145') {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_HASH_DOCUMENTO_DIVERGENTE'
        }
        $r.fonte_sha256_conferida = $true
        $utf8 = [Text.UTF8Encoding]::new($false, $true)
        if (($documentBytes[0] -eq 239 -and $documentBytes[1] -eq 187 -and $documentBytes[2] -eq 191) -or
            [Array]::IndexOf($documentBytes, [byte]13) -ge 0) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_CODIFICACAO_DOCUMENTO_DIVERGENTE'
        }
        $documentText = $utf8.GetString($documentBytes)
        $control.Fase = 'EXTRACAO'
        $open = '<!-- INICIO_BLOCO_POWERSHELL_H3_F_R1 -->' + "`n" + '```powershell' + "`n"
        $close = '```' + "`n" + '<!-- FIM_BLOCO_POWERSHELL_H3_F_R1 -->'
        $begin = $documentText.IndexOf($open, [StringComparison]::Ordinal)
        if ($begin -lt 0 -or $documentText.LastIndexOf($open, [StringComparison]::Ordinal) -ne $begin) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_MARCADOR_INICIAL_AMBIGUO'
        }
        $contentStart = $begin + $open.Length
        $end = $documentText.IndexOf($close, $contentStart, [StringComparison]::Ordinal)
        if ($end -lt $contentStart -or $documentText.LastIndexOf($close, [StringComparison]::Ordinal) -ne $end) {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_MARCADOR_FINAL_AMBIGUO'
        }
        $sourceText = $documentText.Substring($contentStart, $end - $contentStart)
        $sourceBytes = $utf8.GetBytes($sourceText)
        $control.Fase = 'BLOCO'
        $r.bloco_tamanho_bytes = $sourceBytes.Length
        $r.bloco_linhas = $sourceText.Split([char]10).Length - 1
        if ($sourceBytes.Length -ne 20362 -or $r.bloco_linhas -ne 383 -or
            -not $sourceText.EndsWith("`n") -or [Array]::IndexOf($sourceBytes, [byte]13) -ge 0 -or
            (Get-H3HHash $sourceBytes) -ne 'af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5') {
            Stop-H3H 'FONTE_NAO_AUTENTICADA' 'H3H_IDENTIDADE_BLOCO_DIVERGENTE'
        }
        $r.bloco_sha256_conferido = $true
        if (-not $r.recursos_leitura_fechados) {
            Stop-H3H 'PARSING_INCONCLUSIVO' 'H3H_RECURSO_NAO_ENCERRADO'
        }
        $control.Fase = 'PARSER'
        $tokens = $null; $parseErrors = $null
        $r.parser_invocado = $true
        # Unica analise do texto. Nao compilar, invocar ou executar a AST.
        $ast = [System.Management.Automation.Language.Parser]::ParseInput(
            $sourceText, [ref]$tokens, [ref]$parseErrors)
        if ($null -eq $ast -or $null -eq $tokens -or $null -eq $parseErrors) {
            Stop-H3H 'PARSING_INCONCLUSIVO' 'H3H_RETORNO_PARSER_INCOMPLETO'
        }
        $r.quantidade_erros = @($parseErrors).Count
        $details = [System.Collections.Generic.List[object]]::new()
        foreach ($errorItem in $parseErrors) {
            if ($null -eq $errorItem -or $null -eq $errorItem.Extent) {
                Stop-H3H 'PARSING_INCONCLUSIVO' 'H3H_POSICAO_ERRO_INDISPONIVEL'
            }
            $errorId = [string]$errorItem.ErrorId
            if ($errorId -notmatch '^[A-Za-z][A-Za-z0-9_]{0,127}$') {
                $errorId = 'IDENTIFICADOR_NAO_COMPARTILHAVEL'
            }
            $extent = $errorItem.Extent
            [void]$details.Add([ordered]@{
                identificador = $errorId; classificacao = 'ERRO_SINTATICO'
                linha_inicial = $extent.StartLineNumber; coluna_inicial = $extent.StartColumnNumber
                linha_final = $extent.EndLineNumber; coluna_final = $extent.EndColumnNumber
                entrada_incompleta = $errorItem.IncompleteInput
            })
        }
        $r.erros_sintaticos = @($details.ToArray())
        $r.parsing_concluido = $true
        if ($r.quantidade_erros -eq 0) {
            $r.resultado_sintatico = 'SINTAXE_VALIDA_PS51'
        } else {
            $r.resultado_sintatico = 'SINTAXE_INVALIDA_PS51'
            $r.codigo_impedimento = 'H3H_ERROS_SINTATICOS_ENCONTRADOS'
        }
    } catch {
        if (-not $control.Parada) {
            $r.resultado_sintatico = 'PARSING_INCONCLUSIVO'
            $r.codigo_impedimento = 'H3H_FALHA_AUXILIAR_SEM_DETALHES_PUBLICOS'
        }
    } finally {
        if (-not $r.recursos_leitura_fechados) {
            $r.resultado_sintatico = 'PARSING_INCONCLUSIVO'
            $r.codigo_impedimento = 'H3H_RECURSO_NAO_ENCERRADO'
        }
        # So referencias; isto nao e apagamento forense nem alteracao de arquivo.
        $pathPrivate = $null; $cursor = $null; $documentBytes = $null; $documentText = $null
        $sourceBytes = $null; $sourceText = $null; $ast = $null; $tokens = $null; $parseErrors = $null
    }
    return $r
}
try {
    # Invoca somente o auxiliar futuro, nunca a funcao contida no texto analisado.
    $summary = Invoke-H3HParserProposto
    $summary | Microsoft.PowerShell.Utility\ConvertTo-Json -Depth 8 -ErrorAction Stop
} catch {
    # Fallback de erro com observacoes desconhecidas, nunca sucesso ficticio.
    '{"etapa":"WIN19-H3-H","ambiente_parser":null,"versao_powershell":null,"fonte_sha256_conferida":null,"bloco_sha256_conferido":null,"bloco_tamanho_bytes":null,"parser_invocado":null,"quantidade_erros":null,"resultado_sintatico":"PARSING_INCONCLUSIVO","codigo_impedimento":"H3H_FALHA_ENVELOPE_OU_SERIALIZACAO","script_analisado_executado":false}'
}
```
<!-- FIM_BLOCO_AUXILIAR_H3_H -->

## Extração e identidade do auxiliar proposto

Extrair somente os bytes entre a cerca powershell e a cerca final identificadas
pelos marcadores INICIO_BLOCO_AUXILIAR_H3_H/FIM_BLOCO_AUXILIAR_H3_H. Excluir
marcadores/cercas/texto externo e incluir o LF final imediatamente antes da cerca
final. UTF-8 sem BOM; finais LF, sem CR. Não normalizar nem converter para CRLF.
O bloco contém strings com cercas da fonte: usar os marcadores próprios do
auxiliar e a cerca final imediatamente anterior ao marcador final, não cortar
no primeiro conjunto de três crases encontrado dentro de uma string.

Tamanho do bloco auxiliar: 12997 bytes.

SHA-256: `1353dd74a7abbf6569b62ae21ad8169e6ca66a0626a8ff23973742c229599bcb`.

Este hash não valida sintaxe ou funcionamento. A inspeção foi somente textual.
Erros/códigos descritos no auxiliar são prospectivos, não resultados de uma
execução. O fallback JSON é um ramo de erro proposto, não evidência produzida.
