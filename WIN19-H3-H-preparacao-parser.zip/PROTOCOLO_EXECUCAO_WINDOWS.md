# H3-H — roteiro de execução futura do parser, ainda não autorizado

24/11/2026. **NÃO EXECUTAR AGORA.** O ponto de parada desta entrega é auditoria
independente. Os passos seguintes são proposta para decisão/autorização posterior,
exclusivamente pelo usuário local. Supervisão significa controle do custodiante,
não assistência remota ou concessão de acesso a terceiros.

## Antes de qualquer execução futura

1. Obter aceitação independente desta preparação e autorização específica para
   somente o parsing nativo. Não interpretar a aceitação de materialização R1,
   publicação de ZIP anterior ou recebimento deste roteiro como essa autorização.
2. Usar Windows PowerShell 5.1 Desktop legítimo/confiável em sessão local privada,
   sem elevação administrativa, sem perfil/scripts externos nem captura/transcrição
   não autorizada. Não utilizar PowerShell 7, instalar engine/módulo ou alterar
   política de execução/ACL para conseguir prosseguir.
3. Ter o Markdown fonte já obtido pelo canal documental auditado, com seu nome
   original. Se for necessária aquisição/extração local, tratá-la como preparação
   documental autorizada separada; o auxiliar não baixa, extrai ou cria arquivos.
   A fonte está no pacote anterior WIN19-H3-F-R1-correcoes.zip, SHA-256
   442e17cfaae0afe91ff63d3fa60ba3e824e988f0ff586a436f9513a4612dffaa.
   [Pacote já publicado](https://raw.githubusercontent.com/Kaique-Diniz/Improvement-repository/4b0e6890035e0562358b5e5175e274386889adea/WIN19-H3-F-R1-correcoes.zip).
4. Confirmar a identidade do documento sem editá-lo: nome
   COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md, 22.438 bytes, SHA-256
   d927512fb7a00ed5614d8920717670b0675865518a865f8fdbed569f685a9145.
   Não abrir/salvar em editor que transforme LF em CRLF ou adicione BOM.
5. Conferir os sete documentos H3-H contra seu manifesto e o hash independente
   informado na entrega. Conferir também os bytes do único bloco auxiliar pelos
   marcadores próprios. Não usar transcrição incompleta do chat como substituto.
   Nenhum caminho real precisa ser enviado na conversa.

## Execução futura, somente se expressamente autorizada

6. Distinguir os dois Markdown: PROCEDIMENTO_PARSER_PS51.md contém o auxiliar;
   COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md é apenas a fonte analisada. Nunca
   colar, dot-source, importar ou executar o bloco H3-F-R1 para “carregar funções”.
   Sua última linha invoca o procedimento de destino se o texto for executado.
7. Na sessão local autorizada, usar exclusivamente o bloco auxiliar completo
   previamente auditado, extraído de PROCEDIMENTO_PARSER_PS51.md sem cercas ou
   marcadores. Não usar a fonte com -File/-Command nem salvar .ps1 para executá-la.
   Este roteiro não fornece comando de lançamento ou autoriza o ato neste momento.
8. O próprio auxiliar conferirá e registrará a versão efetiva PS5.1/Windows e a
   disponibilidade da API. Incompatibilidade implica parada. Não substituir por
   outro interpretador para produzir resultado com o mesmo rótulo.
9. Quando o auxiliar pedir o caminho, fornecer LOCALMENTE apenas o caminho privado
   completo do Markdown fonte existente. Ele deve estar em unidade fixa local,
   sem alias/reparse observado e com seu nome original. Caminho de custódia e
   JUnit não são entradas desta análise. Se a guarda recusar, não escolher outro
   alvo automaticamente nem enfraquecer a guarda.
10. O auxiliar lê/authentica o Markdown e bloco, fecha a leitura e passa a string
    integral a ParseInput, incluindo sua chamada final. Não há execução da AST,
    função analisada, consultas WMI ou leitura de ACL. Observar somente seu resumo.

## Como interpretar e o que compartilhar

- SINTAXE_VALIDA_PS51: somente se ambiente/API/dupla autenticação estiverem
  confirmados, parser concluído e quantidade de erros igual a zero. É validade
  gramatical daquele texto naquele engine, não aprovação funcional/segurança.
- SINTAXE_INVALIDA_PS51: erros retornados pelo parser; preservar quantidade,
  identificadores e posições. Não executar para reproduzir ou corrigir a fonte.
- FONTE_NAO_AUTENTICADA: identidade/entrada não confirmada; não chamar parser,
  converter LF, editar, reconstruir ou buscar substituto para forçar o hash.
- PARSING_NAO_EXECUTADO: ambiente/API ou precondição impede tentativa.
- PARSING_INCONCLUSIVO: falha do auxiliar/parser/encerramento/metadados/saída;
  ausência de JSON ou interrupção do host também não equivale a sucesso.

Compartilhar somente JSON sanitizado revisado: ambiente/versão, flags de
conferência, tamanho do bloco, tentativa/conclusão, quantidade/posições dos erros
e resultado/código. Não enviar prompts com caminho digitado, screenshots do host,
nomes, SIDs, arquivo, AST, tokens, fonte completa, mensagens brutas ou XML.
Se um campo vier null, é desconhecido/não obtido, nunca zero ou confirmação.

## Paradas e custódia dos resultados

Qualquer divergência ou falha encerra a análise sem retry, contorno, instalação,
elevação, mudança de segurança ou execução de código analisado. O auxiliar não
salva logs; registros privados posteriores exigem destino/autorização próprios.
Não usar este roteiro para criar custódia do JUnit ou reabrir Portão B.

Depois do parsing autorizado futuro, parar e entregar apenas as evidências reais
para revisão. Nem mesmo zero erros libera o procedimento do destino, H3-C,
H3-S, H4, WIN/DACL, runner, conversões ou qualquer portão posterior.
