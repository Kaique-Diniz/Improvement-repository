# H3-H — revisão estática do auxiliar proposto

24/11/2026. Leitura do texto, não parsing nem teste de compatibilidade.
O auxiliar foi confrontado com o escopo H3-H e os contratos públicos da API;
seu funcionamento e sintaxe em Windows PowerShell 5.1 não foram validados.

## Fluxo de dados e separação de responsabilidades

Caminho privado do Markdown → leitura somente de bytes → autenticação do documento
→ UTF-8 estrito/extração → autenticação integral do bloco → string → ParseInput
→ AST/tokens/erros em memória → somente identificadores/posições/estados no resumo.
Não existe ligação do texto analisado a uma API de execução no fluxo proposto.
A fonte autenticada contém a invocação final, mas ela é analisada como texto.

O auxiliar não chama a função de destino nem avalia seu corpo. Não usa
Invoke-Expression, ScriptBlock::Create, GetScriptBlock, Invoke, dot-source,
Import-Module, compilação ou lançamento powershell.exe sobre a fonte. O método
obtido por reflexão serve à identificação da sobrecarga; não invoca o método
refletido nem carrega o código analisado como definições.

## Operações propostas, efeitos e guardas

| Operação do auxiliar | Finalidade e limite de segurança |
|---|---|
| Versão/plataforma e indicadores da sessão | Exige Windows PowerShell 5.1 Desktop/Windows, recusa remoto observável; não instala engine ou certifica host por versão apenas |
| Reflexão de Parser/assembly já disponível | Confirma método estático com string e dois arrays por referência; nome/versão da assembly são metadados, não atestado de assinatura/origem confiável |
| Read-Host | Recebe só caminho local da fonte, sem valor padrão, nunca caminho do destino ou do JUnit; console deve ser privado |
| Strings/DriveInfo/GetAttributes dos componentes da fonte | Restrição conservadora a caminho absoluto/volume fixo local/arquivo com nome esperado, sem reparse observado; não inspeciona permissões ou destino de custódia |
| FileStream Open + Read + FileShare.Read | Não cria ou modifica arquivo; leitura limitada a 22.438 bytes e EOF/Length; fecha antes da autenticação/parser. Não é prova geral de identidade física ou eliminação de corridas |
| SHA256 sobre buffers e Dispose | Autentica documento e bloco; falha de encerramento impede conclusão favorável; sem gerar arquivo ou log |
| UTF8Encoding(false,true) | Rejeita UTF-8 inválido; também verifica ausência de BOM/CR. A conversão não normaliza conteúdo; tamanho/hash do bloco reencodificado precisam coincidir |
| IndexOf/LastIndexOf/Substring | Extração por marcadores/cercas literais únicos, sem Trim do código e com LF final. Não é execução ou parsing PowerShell |
| Parser.ParseInput de três argumentos | Única análise da linguagem sobre string autenticada, sem nome/caminho de arquivo nos extents; AST e tokens não executados nem publicados |
| ParseError.ErrorId/Extent/IncompleteInput | Só identificador filtrado e posições, sem Message, ToString, texto do extent ou arquivo; falha/metadado incompleto produz inconclusão |
| Return/ConvertTo-Json | Objeto agregado de primitivas/listas; fallback de erro usa null para observações desconhecidas, nunca sucesso inventado |
| finally/liberação de referências | Encerra recursos de leitura/hash; não apaga arquivo/memória/log nem promete limpeza forense |

## Segurança crítica: análise não é execução

O texto da fonte não é passado a um operador de chamada, comando de shell,
compilador de scriptblock ou carregador de módulos. A única API que o recebe é
ParseInput. O retorno fica em memória, sem invocação. Essa distinção é apoiada
pelo contrato publicado do parser, que retorna AST/tokens/erros; a documentação
não substitui confiança na assembly carregada nem valida o auxiliar inteiro.
[Parser.ParseInput](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.parser.parseinput).

[ParseError](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.parseerror?view=powershellsdk-7.6.0)
fornece ErrorId/Extent/IncompleteInput; não é necessário divulgar sua Message.
O construtor de [UTF8Encoding](https://learn.microsoft.com/en-us/dotnet/api/system.text.utf8encoding.-ctor?view=netframework-4.8.1)
com erro em bytes inválidos evita aceitação por substituição silenciosa.
Esses contratos foram consultados, sem executar exemplos ou instalar assemblies.

## Proibições e riscos residuais do auxiliar

Não há WMI, leitura de ACL, JUnit, dados de clientes, modificação de permissões,
contas/privilégios/políticas, acesso remoto, script externo, instalador, criação
de pasta, arquivo temporário, log ou transcript. Os únicos metadados/filesystem
consultados numa execução futura seriam os da fonte Markdown e seus componentes,
necessários à leitura autorizada. Isso não é inspeção do destino H3.

A sessão/assembly/módulos padrão devem ser previamente confiáveis; qualificar
cmdlets não autentica todo o host e pode implicar autoload. Console/captura,
ErrorRecord e buffers podem reter informação; não há promessa de zero efeitos
internos, auditoria ou atualização de metadados de acesso pelo Windows. Não mudar
políticas nem desligar auditoria para contornar esse limite. Uma máquina/host
inadequados impedem a futura execução, em vez de justificar instalação ou elevação.

Guardas nominais de reparse não fixam identidade por handle; a leitura usa um
handle único e autentica seus bytes, mas não certifica a cadeia física. Nenhuma
condição inconclusiva autoriza ler outro arquivo, buscar alternativa, normalizar
código, corrigir sintaxe, tentar novamente ou executar a fonte. O auxiliar também
não foi parseado nesta etapa; qualquer defeito identificado em auditoria exige
revisão própria antes de liberar uso.
