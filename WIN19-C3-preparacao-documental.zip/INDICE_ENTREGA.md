# WIN19-C3 — entrega documental para revisão

18/11/2026, America/Sao_Paulo. Nova pasta externa ao Git. Nenhuma implementação,
coleta ou execução autorizada por esta entrega. As versões anteriores estão intactas.

## Documentos principais

1. [RELATORIO_C3_CONSOLIDACAO.md](RELATORIO_C3_CONSOLIDACAO.md) — conclusão, decisões,
   limites e suficiência da proposta para eventual revisão de implementação.
2. [PROTOCOLO_RECUPERACAO_JUNIT_WINDOWS.md](PROTOCOLO_RECUPERACAO_JUNIT_WINDOWS.md) —
   recuperação somente leitura e sanitização futura condicionadas, sem coleta agora.
3. [MATRIZ_T01_T07_DECISOES.csv](MATRIZ_T01_T07_DECISOES.csv) — requisitos, alternativas,
   evidências, positivos, bloqueios, riscos, dependências, impacto e decisão por T.
4. [REVISAO_ARQUITETURA_RUNNER_C.md](REVISAO_ARQUITETURA_RUNNER_C.md) — arquitetura
   textual consolidada, sem código executável.
5. [ESCOPO_PROPOSTO_IMPLEMENTACAO_C.md](ESCOPO_PROPOSTO_IMPLEMENTACAO_C.md) — proposta
   limitada para autorização futura separada de execução; não abre portão.
6. [RISCOS_E_BLOQUEIOS_REMANESCENTES.md](RISCOS_E_BLOQUEIOS_REMANESCENTES.md) — o que
   precisa de fonte, decisão e prova antes dos próximos portões.
7. [MANIFESTO_SHA256](MANIFESTO_SHA256) — nome relativo, tamanho e SHA dos arquivos
   efetivamente entregues nesta C3; exclui somente a si próprio.

## Matrizes, diferenças e rastreabilidade

- [MATRIZ_C3_CONFRONTO_HISTORICO.csv](MATRIZ_C3_CONFRONTO_HISTORICO.csv): 19 linhas
  herdadas/provisórias, com campos futuros de confronto; zero confirmação.
- [MATRIZ_C3_SKIPS_A_CONFERIR.csv](MATRIZ_C3_SKIPS_A_CONFERIR.csv): sete fichas vazias,
  não sete casos/nodeids recuperados. Nada foi atribuído pelo agrupamento secundário.
- [MATRIZ_DIFERENCAS_C2_C3.csv](MATRIZ_DIFERENCAS_C2_C3.csv): alterações de desenho,
  fonte C2, estado C3 e evidência futura, sem promoção de aprovação.
- [DIFF_ARQUITETURA_C2_C3.patch](DIFF_ARQUITETURA_C2_C3.patch): comparação documental
  da arquitetura C2 com C3. Não é patch de código nem aplicação de W14P.
- [INVENTARIO_FONTES_C3.csv](INVENTARIO_FONTES_C3.csv): fontes consultadas ou referências
  reutilizadas, versão por SHA/tamanho e limites. Mtime UTC não é data de execução.
- fontes_recebidas/: cópias literais da instrução C3 e do parecer de referência.
  O texto colado foi renomeado descritivamente, sem alteração de bytes.
- [CONFERENCIA_DOCUMENTAL.md](CONFERENCIA_DOCUMENTAL.md): consistência de campos,
  contagens, hashes/preservação e restrições, sem resultados de testes.

## Bases e resultado

A base C2 é o pacote 35 arquivos SHA
94f1039bd3bc6263bd82041349f132a0c9aa4ccc047db7d0ade12997324aec24,
manifesto a8785f24699cfa7ac606f751b54248c2d6832313bc7a06e5b2517e0a01e9def6.
Parecer independente SHA
0311d7bea6ae108f89fc10812ad72cbdcf0ef4be91664378ea6936395f07da3c,
recebido novamente e igual ao antes lido. Aceita documentação com ressalvas.

T01/T06 ESPECIFICADO; T03/T04/T05/T07 PARCIAL; T02 BLOQUEADO no ramo de erro nativo.
Esses rótulos são de desenho: todos os controles continuam NÃO_VALIDADO e o runner
NÃO_IMPLEMENTADO. O desenho permite revisão de uma proposta limitada, não autoriza
implementação integral ou execução. O parecer independente futuro decide o avanço.

Faltam JUnit original Windows, log/comando/contexto, código físico da época e
associação do manifesto 448 ao run, além de custódia/retenção próprias. Não pedir
raw privado nem recriar fonte por transcrição. Portão B permanece encerrado, sua
autorização consumida. DACL D01–D10 PARA_APROVAÇÃO; C/D/E e conversões bloqueados;
prontidao_para_executar=false; autorizacao_testes=PENDENTE.

Nenhum Python, pytest, PowerShell, import de produto, teste/preflight, fixture,
runner, worktree, configuração Git, privilégio/ACL, conversão ou publicação foi
executado/criado/alterado nesta C3. Apenas leitura estática e documentos novos,
sem exclusão de históricos. Parar para revisão, sem solicitação automática de execução.
