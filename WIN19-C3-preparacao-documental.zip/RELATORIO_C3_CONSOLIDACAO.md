# WIN19-C3 — consolidação documental e viabilidade futura

18/11/2026, referência civil America/Sao_Paulo. **Somente análise documental,
inspeção estática e especificações novas externas ao Git.** A aprovação C1/C2 com
ressalvas foi usada como referência, sem transformar aceite documental em execução.

## 1. Conclusão principal

C3 entrega o protocolo de recuperação histórica sem coletar, uma proposta de
arquitetura mais precisa e o limite de eventual implementação separada. **Runner
NÃO_IMPLEMENTADO; prontidao_para_executar=false; autorização de testes PENDENTE.**
Os 19 vínculos continuam PROVISORIO_SEM_FONTE, decisões PENDENTE e zero confirmados.
Todos WIN-01..19 e DACL permanecem NÃO_VALIDADO; C/D/E e conversões bloqueados.

| Pendência | Decisão de desenho nesta C3 | Limite remanescente |
|---|---|---|
| T01 Observador | ESPECIFICADO | Journal/ACK/ordem/falhas descritos; desempenho/durabilidade não ensaiados |
| T02 Erro nativo WIN-03 | BLOQUEADO | Nenhuma indução segura/verificável demonstrada para o ramo de erro |
| T03 Links e identidade | PARCIAL | Tipos/positivos definidos, capacidade symlink e handles/ABI não demonstrados |
| T04 Git/Python | PARCIAL | Contrato controlado definido; bootstrap concreto e instalações Windows ainda ausentes |
| T05 Autoridade/snapshot | PARCIAL | Fronteiras definidas, W14P não aplicada e snapshot seguro ainda dependente de T01/T03 |
| T06 CLI/oráculo | ESPECIFICADO | Planos/oráculo/canais definidos; depende de T01/T04/T07 e revisão das fixtures |
| T07 Limpeza | PARCIAL | Limites/resíduo/propriedade definidos; primitives/cancelamento nativos precisam de revisão |

ESPECIFICADO só qualifica desenho documental, sem equivalência com IMPLEMENTADO,
PASS ou VALIDADO. PARCIAL não significa que a parte descrita foi implementada.
BLOQUEADO em T02 refere-se à subafirmação de erro nativo, sem abrir automaticamente
as demais. A matriz T01–T07 detalha os nove campos de análise e critérios de revisão.

## 2. C3-A — recuperação preparada, não realizada

PROTOCOLO_RECUPERACAO_JUNIT_WINDOWS.md define decisões prévias, observação futura
de existência/nome/tamanho/SHA/tipo/localização/datas, custódia sem regravação e
metodologia de sanitização mediante autorização própria. Trata datas da execução,
do arquivo e da coleta separadamente; não promete impedir efeitos de último acesso.

MATRIZ_C3_CONFRONTO_HISTORICO.csv preserva 19 linhas anteriores e acrescenta campos
de confronto futuro sem presumir relação 1:1 entre WIN e testcase. Os testemunhos
primários continuam SEM_FONTE. MATRIZ_C3_SKIPS_A_CONFERIR.csv contém sete fichas
virgens, expressamente não nodeids recuperados; motivos/fases/parâmetros não inventados.

Permanecem faltando: completa-utf8.xml original na máquina Windows; log persistido,
argv/comando literal, ambiente/plugins e contexto do mesmo run; código/alterações
físicos da época; prova de qual manifesto 448 foi usado; custódia/retenção e aceite
humano por vínculo. A transcrição secundária e a coincidência de nomes não substituem
isso. Não se pediu raw privado ou acesso ao computador. Os 90 dias de B não foram
atribuídos a C1. Nenhum extrator foi escrito ou executado.

Manifesto 448 conhecido, SHA-256
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb,
é identidade de artefato observado, não prova de seu uso na rodada de 2.842/19/7.
A aceitação independente dos 16 auxiliares e dos 34 arquivos do manifesto C2 sana
a lacuna de entrega documental, não essa lacuna histórica.

## 3. C3-B — decisões que tornam o desenho mais verificável

T01 agora separa emissor nativo, supervisor e escritor único: início antes de
setup/fixture, eventos sequenciados com cadeia de integridade, confirmação depois
da gravação/sincronização solicitada e bloqueio sem ACK. Há tratamento de primeira
falha e falhas secundárias, cauda truncada e journal parcial. JUnit não é o único
sobrevivente. Limites propostos de evento/espera dependem de revisão; não há prova
contra queda de energia nem autenticidade contra reescrita pelo mesmo token.

T02 separa 1/2/3 nativos, -1/0/+1 normalizados, falha de DLL/preparação, NUL pré-API
e retorno nativo de erro. O último continua sem estratégia segura. T03 distingue
symlink/junction/hardlink/alias/ID/volume e impõe true no positivo, sem tornar todo
hardlink vulnerabilidade ou trocar symlink indisponível por junction.

T04 explicita o problema de .pth, sitecustomize, plugins e import que produz efeito
antes da checagem posterior. Propõe bootstrap externo controlado, mas reconhece que
não há concretização Windows para validá-lo nesta C3. Git não herda configuração
ou variáveis por conveniência. Mesmo token não equivale a sandbox de código hostil.

T05 mantém W14P não aplicada, revê o helper arquivos→bytes e define cobertura de
vazios, identidades, políticas/concessões/corpos/recibos/locks/chaves. Igualdade final
não prova ausência de leitura ou alteração transitória revertida. T06 separa CLI,
JSON, auditoria, DTO e exportação e prevê ambos canais drenados continuamente,
com oráculo anterior ao leitor e evidência antes de asserções mesmo em timeout.

T07 propõe propriedade por criação/identidade, processos/handles próprios, tentativa
limitada e observação de exclusão pendente sem repetir remoção. Não altera motor,
share0x3 ou residual histórico. Esses limites são desenho para revisão, não evidência
de viabilidade; WinAPI bloqueante e substituição concorrente continuam pendências.

## 4. Suficiência para uma futura autorização de implementação

O desenho está suficientemente organizado para revisão de uma proposta LIMITADA,
com responsabilidades, entradas, positivos, instrumentação, entrega e exclusões.
**Não está suficientemente fechado para recomendar autorização integral do runner C.**
T03/T04/T05/T07 precisam de decisões/restrições antes de aceitar um diff integral;
T02 exige aceitação explícita da lacuna ou estratégia segura revisada separadamente.

ESCOPO_PROPOSTO_IMPLEMENTACAO_C.md não é autorização: eventual escrita de código
externo, execução desse código e ensaio DACL continuam decisões distintas. Não se
solicitou desbloqueio automático nem se criou esqueleto executável para contornar
esse ponto de parada. Se uma necessidade real implicar alteração do produto/política,
o impacto terá de ser proposto em tarefa própria. Nenhuma foi implementada aqui.

## 5. Fontes e preservação

Foram lidas instrução C3, parecer independente, arquitetura/pendências/matrizes C2,
W14P, trechos de snapshot e contrato CompareStringOrdinal, apenas como texto. Fontes
e versões estão em INVENTARIO_FONTES_C3.csv, com SHA e tamanho. O parecer recebido
é idêntico à cópia antes lida: SHA
0311d7bea6ae108f89fc10812ad72cbdcf0ef4be91664378ea6936395f07da3c.
As duas fontes recebidas são preservadas em cópias documentais, sem executá-las.

Não houve Python, pytest, PowerShell, import, script do projeto, teste, preflight,
coleta Windows/DACL, Git/configuração/worktree, instalação, mudança de conta/ACL/
privilégio/política, conversão, remoção histórica, commit, push, merge ou publicação.
Apenas leitura e novos documentos. Não houve sondagem de capacidades ou verificação
operacional dos 470 arquivos. O desvio Python anterior continua declarado com efeitos
não demonstrados, comando SEM_FONTE; não houve replay para reconstituí-lo.

MATRIZ_DIFERENCAS_C2_C3.csv relaciona mudanças de desenho. O diff documental compara
a arquitetura C2 preservada com C3, sem patch de produção. MANIFESTO_SHA256 cobre
os arquivos efetivamente entregues, excluindo só a si próprio. Parar para revisão.
