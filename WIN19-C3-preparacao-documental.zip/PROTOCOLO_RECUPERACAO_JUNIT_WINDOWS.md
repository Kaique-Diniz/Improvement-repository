# C3-A — protocolo proposto de recuperação histórica, somente leitura

18/11/2026. **NÃO EXECUTADO.** Documento para análise do usuário, não script nem
solicitação de envio de bruto privado. Não presumir acesso do Codex ao Windows.
Não repetir pytest, extrator, parsing PowerShell ou preflight B para obter prova.

## 1. Objeto e critérios de identidade

Alvo relatado: %LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml.
Rodada relatada: Windows EXP-04 UTF-8, 2.842 casos, 2.816 PASS, 19 FAIL, sete SKIP,
zero ERROR. Esses contadores são testemunho secundário, não medição desta etapa.
Nome da pasta e totais coincidentes não autenticam um arquivo ou a versão executada.

Manifesto de 448 entradas observado: SHA-256
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb,
50.698 bytes, baseline 770d062d29c4361d6932592883df9339bb4089bc.
O artefato está autenticado documentalmente; sua adoção no run segue não demonstrada.

## 2. Condições antes de qualquer recuperação futura

| Campo de decisão | Situação atual |
|---|---|
| Custodiante autorizado do original | PENDENTE, identidade concreta fica privada |
| Autorização para leitura/cópia local do alvo específico | PENDENTE; esta tarefa só prepara o protocolo |
| Destino local novo para cópia e metadados | PENDENTE, fora de Git/candidatas/documentos de clientes |
| Responsável e revisão de sanitização/transferência | PENDENTE, autorização separada |
| Retenção, data de revisão, descarte e exceções de preservação | PENDENTE, decisão própria de C1 |
| Aceite de vínculo por controle | PENDENTE, após fonte e revisão humana |

Não aplicar os 90 dias de B automaticamente. Não alterar ACL, owner, privilégio,
conta, Developer Mode, timestamps ou atributos para viabilizar o acesso. Sem acesso
legítimo ao original, registrar impedimento e parar; não elevar nem procurar cópia
em depósitos pessoais não autorizados. Não solicitar dados brutos privados no chat.

## 3. Metadados a observar futuramente, sem alterar bytes

No caminho exato informado, o custodiante verificará existência, nome original,
tipo regular, tamanho e localização física/ancestrais. Link/reparse, redirecionamento,
volume inesperado ou identidade ambígua impede tratar esse caminho como original
regular autenticado. Registrar privadamente a localização completa; derivado público
usa apenas alias normalizado com %LOCALAPPDATA% e um identificador da peça.

Registrar: SHA-256 calculado dos bytes; tamanho; identidade do arquivo/volume quando
obtida por leitura legítima; datas de criação/modificação e fuso de apresentação;
instante UTC e fuso da observação; pessoa/ferramenta e versão usadas; resultado ou
falha segura. Datas do arquivo, do diretório e do XML são campos distintos, nenhum
substitui o instante de execução sem contexto. SHA agora calculado fixa bytes AGORA;
não retroage como atestação contemporânea do run.

Se a ferramenta de leitura puder observar mudança concorrente, conferir identidade,
tamanho e hash antes/depois da cópia. Mudança ou impossibilidade de assegurar uma
leitura consistente gera PENDENTE_FONTE_MUTAVEL, não escolha arbitrária de versão.
Não abrir arquivo para escrita nem usar salvamento de editor. Leitura pode afetar
metadado de último acesso conforme o filesystem; não prometer congelamento forense
integral nem reescrever atributos para ocultar isso.

## 4. Preservação e cadeia de custódia

Original permanece na máquina/custódia designada, sem mover, renomear, regravar,
normalizar encoding ou finais de linha. Uma cópia local nova só após autorização,
com criação exclusiva, sem sobrescrever destino. Registrar origem→cópia, nomes
originais, bytes/SHA dos dois, data/fuso, ferramenta e responsável. Confirmar igualdade
integral quando legítima; divergência preserva ambas as peças e bloqueia vínculo.

Registros de custódia e raw continuam privados, com inventário e recibo do responsável.
A ausência atual de política DACL aprovada não permite afirmar que um novo depósito
é protegido pelo aplicativo. Usar custódia já autorizada pelo titular, sem alteração
de permissões nesta etapa. O local público nunca recebe raw, conta, SID/SDDL ou senha.

## 5. Cópia sanitizada — metodologia condicionada a nova autorização

Antes de derivar, aprovar finalidade, campos compartilháveis, remoções e revisor.
Trabalhar sobre cópia autorizada, preservando original e cópia fiel. Não fazer busca
por nomes para inferir controle. Se futuramente for usado leitor de XML, ele deve
ser aprovado separadamente, tratar XML como dados, recusar DTD/entidades externas,
XInclude e acessos a rede; não executar anexos, scripts ou conteúdo de traceback.
Nenhum leitor/extrator foi implementado ou executado na C3.

Remover/aliasar caminhos pessoais, contas, hostnames privados, documentos, valores
financeiros de pessoas, conteúdo de fixtures privadas, credenciais, tokens, cookies,
URLs autenticadas, locals e mensagens sensíveis. Substituições precisam ser estáveis
para conservar relações entre casos sem revelar valores. Nome/class/parâmetro que
contenha dado privado recebe alias; correspondência literal original fica sob custódia.
Não apagar failure/skipped, inverter resultado ou preencher campo ausente com inferência.

O revisor confere a cópia em contexto, não só por regex, e registra alterações por
categoria e posição. Hash do original e do derivado, bytes, regra/versão, responsável,
autorização e data/fuso compõem a cadeia. Sanitização muda bytes; o SHA original não
pode ser atribuído ao derivado. Se não houver forma segura de compartilhar um campo,
manter SEM_FONTE no relatório público e indicar que requer revisão privada legítima.

## 6. Reconciliação futura do XML com os 19 controles

Preservar a hierarquia de suites. Distinguir os contadores declarados de cada nível
da enumeração de testcase folhas; não somar testsuites pai com filhos. Registrar
caminho hierárquico e ordinal de cada ocorrência, classname/name/parâmetros originais,
elementos failure/error/skipped, fase quando efetivamente disponível e referência
privada de traceback. Não deduplicar apenas por classname/name: repetições, retries
ou suites diferentes precisam de decisão explícita e contagem preservada.

Confrontar os 19 failure observados com o resumo e a versão EXATA dos testes da
época. Se totais divergem, preservar divergência; não ajustar XML ou fundir rodadas.
As 19 linhas em MATRIZ_C3_CONFRONTO_HISTORICO.csv são propostas por WIN, não prova
de correspondência 1:1. Identificar ausências, múltiplas correspondências, parâmetros
diferentes e casos extras. Um WIN histórico e um subcaso prospectivo podem divergir.

Proposta de estado só após fonte: OBSERVADO_COM_FONTE, DIVERGENTE ou AMBIGUO, com
motivo. Sem fonte, PROVISORIO_SEM_FONTE. Confirmação exige aceite do revisor, data
e versão da fonte; o Codex não converte coincidência de nome em confirmação humana.
Linux, cleanup, B e rodadas anteriores de 38 falhas não substituem essa execução.

## 7. Sete skips: fichas sem atribuição prévia

MATRIZ_C3_SKIPS_A_CONFERIR.csv contém sete fichas VIRGENS, não sete nodeids
recuperados. Os IDs C3-SKIP-01..07 só numeram slots de documentação. Cada ficha
receberá, se a fonte aparecer: suite/ordinal, classname/name/parâmetro, motivo literal,
fase real ou NÃO_INFORMADA, hash do XML e referência sanitizada, decisão do revisor.
Não preencher reason ou fase por nome do teste/linha do log. Preservar motivos
não equivalentes e eventual cardinalidade diferente da declarada.

O índice secundário conhecido traz quatro reconstrução/symlink, dois authority/POSIX
e um ACL/symlink, agrupados; não vincular esses grupos às fichas sem XML. Os dois
POSIX não são automaticamente WIN-18/19. Skip não é PASS nem controle nativo validado.

## 8. Versão, comando e ambiente da mesma rodada

Recuperação documental futura deverá relacionar, sem reproduzir a suíte:

| Peça | Confronto necessário |
|---|---|
| XML e log/stdout/stderr originais, se existentes | Mesmo run, nomes, tempos/fuso e resultados; nomes adicionais hoje SEM_FONTE |
| Comando/argv literal e origem | Flags UTF-8, import paths, plugins, parâmetros e destinos reais; não reconstruir da memória |
| Ambiente | Windows, Python/pytest/dependências/plugins, variáveis relevantes sanitizadas; não coletar segredos |
| Código da época | Commit e alterações/untracked, manifesto completo e evidência física preservada, sem reexecutar |
| Manifesto efetivamente usado | Bytes/SHA e associação contemporânea ao run; comparar a 19f936... sem presumir igualdade |
| Relatório de verificação 448 da época | Relacionar caminhos/versão/arquivo de manifesto; texto “448 OK” isolado é insuficiente |

O estado atual de um checkout não prova os bytes de novembro daquela execução.
Ausência de snapshot contemporâneo limita a conclusão, mesmo que HEAD coincida.
Dados não existentes continuam ausentes; não recriar histórico ou logs por descrição.

## 9. Aceitação documental futura e ponto de parada atual

O protocolo só poderá resultar em confronto quando houver fonte identificada,
leitura autorizada, cadeia de custódia, comparação de versão e revisão humana.
Identidade de arquivo não basta para inferir uso na execução. Se faltar qualquer
peça, manter limitação por campo/controle em vez de declarar reconciliação global.

Nesta C3 não houve coleta, leitura remota do Windows, extrator ou pedido de raw.
Os 19 vínculos continuam provisórios e as sete fichas sem fonte. Retenção e
custodiante seguem decisões próprias pendentes. Entregar este protocolo e parar.
