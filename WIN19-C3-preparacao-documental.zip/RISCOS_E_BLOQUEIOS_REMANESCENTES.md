# C3 — riscos e bloqueios remanescentes

18/11/2026. Natureza documental. Nenhum controle foi ensaiado nesta etapa.

## 1. Estados obrigatórios preservados

| Componente | Estado |
|---|---|
| Portão B | ENCERRADO DOCUMENTALMENTE, autorização única consumida |
| WIN-01 a WIN-19 | NÃO_VALIDADO |
| 19 vínculos históricos | PROVISORIO_SEM_FONTE, zero confirmações, revisor PENDENTE |
| Autorizações de testes | PENDENTE |
| Runner C | NÃO_IMPLEMENTADO |
| Prontidão para executar | false |
| DACL D01–D10 | PARA_APROVAÇÃO |
| Portões C/D/E | BLOQUEADOS |
| Conversões reais | BLOQUEADAS |

ESPECIFICADO na matriz T01–T07 qualifica somente completude de desenho documental.
Não é IMPLEMENTADO, PASS, VALIDADO ou aprovação de implementação/execução.

## 2. Riscos de história e custódia

| Risco | Tratamento documental atual | Falta |
|---|---|---|
| Confundir XML Linux/posterior com rodada Windows 19/7 | Protocolo por peça/run/versão, sem somar suites/cópias | Original, log, comando e contexto sob custódia |
| SHA do manifesto 448 tomado como prova de uso | Distinguir identidade documental e associação à execução | Registro contemporâneo de uso e versão física |
| Origem inferida de nome/contagem | Matriz 19 linhas provisórias, sete fichas vazias | Revisão humana dos testcase e parâmetros originais |
| Bruto privado exposto na recuperação | Custódia local e sanitização por autorização específica | Responsável, retenção e regras aprovadas |
| Comando Python anterior reconstruído por memória | Nota anterior preservada, sem replay | Registro bruto se existir e recuperação for autorizada |

Não pedir raw privado nem recriar XML/log. A retenção de 90 dias de B não é herdada
por C1. Recuperação futura autorizada continua separada desta preparação.

## 3. Riscos de arquitetura e dependências antes da implementação integral

| ID | Risco residual | Condição necessária para avançar |
|---|---|---|
| T01 | Observador perde ACK, ordem ou dados em crash/erro de disco | Revisão do contrato de journal/transporte e futura evidência, sem alegar resistência a energia perdida |
| T02 | Ramo de erro Win32 não exercitado ou preparação confundida com API | Aceitar lacuna explícita ou revisar estratégia segura; nada de NUL/mock/memória insegura |
| T03 | Link/identidade/ancestral muda entre verificação e uso | Estratégia nativa de handles e ABI revisada, capacidade por subafirmação sem privilégio novo |
| T04 | .pth/plugin/import/DLL/configuração muda origem ou escreve na candidata | Bootstrap concreto e manifestos Windows aprovados, ambiente controlado; mesmo token não é sandbox |
| T05 | Snapshot não vê vazio/identidade ou é lido por redirecionamento | Modelo completo, camada T03 e diagnóstico anterior a assert; W14P continua não aplicada |
| T06 | Oráculo compartilha erro da factory ou DTO é confundido com fluxo CLI | Revisão independente da declaração e limites por plano; saídas parciais e positivas reais |
| T07 | Cleanup apaga objeto trocado, bloqueia ou perde evidência | Primitivas/compartilhamento/cancelamento revistos; limites e resíduo próprios, nunca fallback amplo |

T01/T06 ESPECIFICADO não eliminam esses riscos de implementação e validação.
T03/T04/T05/T07 continuam PARCIAL. T02 BLOQUEADO refere-se ao ramo de erro nativo,
não autorização para rodar automaticamente as demais subafirmações.

Limites de tempo propostos de T07 estão PARA_REVISÃO. Sem observação de conclusão,
a ausência não é comprovada. Não haver erro aparente ou só existir marker de posse
não autoriza excluir. Proteção contra race e uso correto da ABI não são dedutíveis
de hash do código ou de resultado anterior de outro executor.

## 4. Segurança que permanece sem prova

Não foram validados acesso entre tokens, negação DACL por objeto/operação, herança,
owner, READ_CONTROL/WRITE_DAC/WRITE_OWNER, CREATE/REPLACE e DELETE_CHILD integrados
ao aplicativo. Permissões POSIX, sharing violation, flags diagnósticas e ACL instalada
manualmente não substituem isso. D01–D10 continuam PARA_APROVAÇÃO; nenhuma conta,
policy, ACL, privilégio ou Developer Mode foi alterado.

Igualdade final de bytes não comprova ausência de leitura, alteração transitória
revertida ou exfiltração. Mesmo usuário/aplicativo não constitui isolamento de SO
contra código hostil sob o mesmo token. Se esses requisitos forem essenciais,
será preciso outro desenho e autorização, sem enfraquecer controle para obter verde.

## 5. Sequência de decisões, sem execução automática

1. Parecer independente da C3 e aprovação/restrição das decisões de desenho.
2. Eventual autorização específica de implementação externa, com exclusões e
   tratamento das quatro pendências parciais e do bloqueio T02.
3. Revisão de fontes/diff/manifests e ambiente proposto; política de custódia.
4. Autorização distinta de execução C, por casos/capacidades e ponto de parada.
5. Política D e autorização própria de ensaios DACL; depois avaliação de E.

Aceite documental não abre nenhum desses portões. A proposta não autoriza nova
worktree, instalação, import, teste ou publicação. Artefatos anteriores, candidata
470, motor/flags e custódia privada permanecem intactos. Parar após esta entrega.
