# EXP-04 / WIN19 — Parecer independente da complementação documental C1/C2

**Data da documentação analisada:** 18/11/2026  
**Objeto:** `WIN19-C1-C2-complementacao-documental.zip`  
**Escopo desta avaliação:** leitura estática e verificação independente dos arquivos recebidos; nenhum script, teste Windows/DACL, preflight ou runner do pacote foi executado.  
**Decisão:** **ACEITA como complementação documental com ressalvas; C1 permanece PARCIAL, C2 permanece especificação NÃO_IMPLEMENTADA; Portões C/D/E não autorizados.**

## 1. Integridade efetivamente conferida

- SHA-256 do ZIP recebido: `94f1039bd3bc6263bd82041349f132a0c9aa4ccc047db7d0ade12997324aec24`.
- ZIP contém **35 arquivos regulares** e nenhum caminho absoluto, componente `..` ou entrada symlink. Checagem CRC não encontrou erro.
- `MANIFESTO_SHA256`: SHA-256 `a8785f24699cfa7ac606f751b54248c2d6832313bc7a06e5b2517e0a01e9def6`, igual ao SHA declarado na entrega.
- O manifesto declara **34 arquivos distintos**; o 35.º é ele próprio, excluído para evitar autorreferência. **34/34** arquivos presentes, com SHA-256 e tamanho corretos.
- `INTEGRIDADE_16_AUXILIARES.csv`: **16/16** cópias `auxiliares_anteriores/...` comparadas contra os valores de seu inventário **e também contra o manifesto anterior** `auxiliares_anteriores/MANIFESTO_SHA256.sha256` (22 entradas). Todas coincidem; a lacuna de disponibilidade dos 16 auxiliares na amostra anterior está sanada.
- `fontes_observadas/VERSAO_EXP04_SHA256.json`: **50.698 bytes**, SHA-256 `19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb`, com **448 entradas** no campo `arquivos`. A verificação atesta apenas os bytes recebidos, **não o vínculo desse manifesto à execução Windows**.
- O ZIP recebido não contém arquivos com extensões `.py`, `.ps1`, `.bat`, `.cmd`, `.sh` ou `.exe`. Isso **não demonstra** ausência de execução por processos no workspace original.

## 2. Reconciliação histórica C1

- `MATRIZ_C1_ATUALIZADA.csv`: **19 linhas, 19 IDs únicos, 25 colunas**.
- Todos os 19 vínculos: `PROVISORIO_SEM_FONTE`; todas as decisões: `PENDENTE`.
- Os campos de testemunho original (teste, classe, parâmetro, versão, SHA do XML e traceback original) permanecem `SEM_FONTE`; **0 confirmações por fonte primária**.
- O manifesto de 448 entradas está observado e hashado, mas seu uso na rodada Windows **não está demonstrado**. Log textual e índice de origem permanecem secundários.
- Continua faltando a custódia do JUnit original da rodada Windows de 2.842 casos, 19 falhas, sete skips, bem como comando/ambiente e associação à versão física efetiva. JUnit posterior, Linux, suites de cleanup ou o Portão B não substituem essas fontes.

**Julgamento C1:** complementação documental consistente, porém reconciliação histórica **não concluída**. Não elevar nenhum WIN-01 a WIN-19 a confirmado.

## 3. Revisão prospectiva C2

- `MATRIZ_C2_ATUALIZADA.csv`: **21 subcasos únicos, 19 IDs, 31 colunas**; grupos API=5, LINK=11, MODO=3 e CHMOD=2.
- WIN-11-A/B e WIN-13-A/B permanecem subcasos separados. Todas as 21 linhas preservam `funcional`, `nativo`, `DACL` = `NÃO_VALIDADO`, `vinculo_historico=PROVISORIO_SEM_FONTE` e `decisao_revisor=PENDENTE`.
- Os 21 critérios complementares constam de `CRITERIOS_C2_COMPLEMENTARES.csv` e do relatório individual, ainda sem implementação.
- **WIN-03:** separa retorno nativo `CompareStringOrdinal` (1/2/3) de retorno normalizado do wrapper (-1/0/+1), sem usar NUL/mock/ponteiro inseguro como prova da falha. **Ramo de erro nativo permanece NÃO_VALIDADO.**
- **WIN-04:** exige dois controles que retornem verdadeiro e comparação distinta com hardlink, para impedir falso PASS por comparador sempre falso; condiciona equivalência real à capacidade existente.
- **WIN-11:** separa Git sintético (allowlist/configuração própria) de ancestral symlink, exigindo positivos independentes para repositório e aplicação; ausência de capacidade symlink não vira PASS.
- **WIN-14:** trata W14P como proposta **não aplicada** e identifica a insuficiência de snapshot de arquivos→bytes, exigindo identidade, diretórios vazios, políticas e concessões da autoridade sem expor segredos. DACL e ausência de leitura não são inferidas.
- **WIN-16:** separa CLI, JSON, DTO e exportação, com oráculo prévio independente e proposta de observação durável antes de asserções e após timeout/crash. Nenhuma exportação real foi validada.
- **WIN-18/19:** preservados como protocolos DACL bloqueados, dependentes de política D01–D10 e tokens distintos; `chmod` ou compartilhamento Win32 não satisfazem esses contratos.

`ESPECIFICACAO_RUNNER_C_REVISADA.md` descreve estados, custódia externa, persistência por evento, isolamento, limites de cleanup, sentinelas, captura de erro e classificação por eixo. Isso é **especificação textual**, não executor auditado.

**Julgamento C2:** a especificação dos 21 subcasos está documentalmente coerente e atende às ressalvas prioritárias sem mascarar lacunas. Não há base para autorizar execução; mesmo a implementação exigirá revisão/autorização própria e resolução dos riscos de arquitetura relevantes.

## 4. Desvio processual

A `NOTA_DESVIO_PROCESSUAL.md` reconhece o uso inicial de Python para abrir ZIP em tarefa anterior. O comando exato e a trilha de efeitos continuam `SEM_FONTE`. A classificação **“desvio processual declarado, com efeitos não demonstrados”** é proporcional aos registros acessíveis; não equivale a afirmar ausência de efeitos. Não é necessário repetir a operação para fabricar rastreabilidade.

O relato de que nesta complementação não houve Python, testes, modificações ou publicação é informação **declarada**, não verificada por telemetria independente do workspace do Codex. A verificação do ZIP limita-se aos documentos entregues.

## 5. Condições e próximas decisões

**Concluídos documentalmente:** restauração e integridade dos 16 auxiliares, cadeia da entrega atual, rastreabilidade de fontes e complementação da especificação de 21 subcasos.

**Pendências históricas:** localizar e custodiar `completa-utf8.xml` original no Windows do usuário, log/argv/ambiente do mesmo run, versão/código físico e prova de uso do manifesto 448; confrontar os 19 nodeids e sete skips sob revisão humana. Definir custódia/retenção próprias para fontes C1, sem herdar automaticamente os 90 dias de B.

**Pendências prospectivas:** rever observador durável (T01), erro nativo WIN-03 (T02), capacidades de links/identidade (T03), isolamento Git/Python (T04), W14P e fronteiras (T05), oráculo CLI/DTO (T06), limpeza e resíduos (T07); DACL D01–D10 continua `PARA_APROVAÇÃO` (D00).

**Preservar até nova decisão explícita:** `prontidao_para_executar=false`, `autorizacao_testes=PENDENTE`, `WIN01–WIN19=NÃO_VALIDADO`, `DACL=NÃO_VALIDADO`, `C/D/E=BLOQUEADOS`, `CONVERSOES_REAIS=BLOQUEADAS`. Nenhuma autorização prévia para a coleta B pode ser reutilizada.

### Decisão final

**ACEITAR a complementação documental C1/C2 e encerrar sua revisão como pacote, com ressalvas; NÃO declarar C1 reconciliado, NÃO declarar runner implementado, NÃO abrir Portão C nem autorizar testes.** A melhor próxima ação é recuperar o JUnit original de maneira somente leitura e, em paralelo, manter revisão conceitual restrita de T01–T07; autorização de implementação e autorização de execução devem ser decisões distintas.
