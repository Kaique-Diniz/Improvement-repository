# Proposta para eventual implementação C — não autorizada nesta C3

18/11/2026. Esta é uma proposta de escopo a revisar, não solicitação automática
de desbloqueio. Não há runner ou fixture criados. Implementar e executar são
autorizações separadas. O parecer independente futuro decidirá se cabe avançar.

## 1. Objetivo limitado e restrições de desenho

Propor componentes externos para observar os 21 subcasos prospectivos da matriz
C2, sem modificar candidata R1-FIX 470, motor de limpeza, share0x3, contratos de
negócio, políticas DACL, permissões ou privilégios. Os 19 vínculos históricos seguem
provisórios, independentemente do resultado de qualquer futuro componente.

Não propor acesso entre contas, ativar symlink, instalar dependências, criar nova
candidata, operar conversões reais ou publicar. WIN-18/19 ficam protocolos bloqueados.
O ramo de erro nativo de WIN-03 não pode ser marcado PASS por omissão/injeção.

## 2. Componentes externos previstos

| Componente conceitual | Responsabilidade | Condição/lacuna anterior a implementar |
|---|---|---|
| Supervisor | Máquina de estados, reserva, filhos próprios, stop e relatório parcial | Política de processo/timeout e cancelamento T07 revisada |
| Escritor de eventos | Sequência, integridade, confirmação e primeira falha, fora do temporário | Contrato T01 e limites de dados aprovados |
| Transporte seguro | Eventos tipados e limitados, confirmação por etapa | Recusar payload privado/ilegível e perda silenciosa |
| Referências e bootstrap | Manifestos, binários, dependências, origem dos imports | T04: selecionar bootstrap concreto e congelar ambiente |
| Capacidades e identidade | Distinguir tipo/tag/volume/file ID, ancestral e reparse | T03: primitives/ABI e capacidade legitimamente disponível |
| Laboratório sintético | Criação exclusiva e positivos/adversariais por cenário | Contratos das fixtures revisados, sem fixture legada importada |
| Snapshots | Bytes, tipos/nomes/IDs/diretórios, fronteiras de autoridade | T05 e T03; W14P não é implementação aprovada |
| Adaptador CLI/oráculo | Canais contínuos, JSON/auditoria e comparação independente | T06 com dependências T01/T04/T07 |
| Julgamento | Resultado por afirmação/eixo, sem transferir PASS | Critérios congelados, skips/bloqueios explícitos |
| Encerramento/custódia | Recursos próprios, limite de cleanup, resíduo e recibo | T07 parcial; não adotar motor anterior como prova automática |

Esses nomes são papéis de arquitetura, não arquivos executáveis entregues. Não
implementar componentes parciais sob autorização genérica: o escopo aprovado deve
selecionar explicitamente quais contratos e riscos abrange.

## 3. Fontes, versões e hashes exigidos

Referências documentais atuais são listadas em INVENTARIO_FONTES_C3.csv. A versão
C2 é o pacote de 35 arquivos SHA-256
94f1039bd3bc6263bd82041349f132a0c9aa4ccc047db7d0ade12997324aec24,
manifesto a8785f24699cfa7ac606f751b54248c2d6832313bc7a06e5b2517e0a01e9def6.
O parecer de aceite com ressalvas tem SHA
0311d7bea6ae108f89fc10812ad72cbdcf0ef4be91664378ea6936395f07da3c.

Referência R1-FIX 470: manifesto documental
REFERENCIA_R1_FIX_470_SHA256.json, SHA-256
a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c,
base 770d062d29c4361d6932592883df9339bb4089bc. Esta C3 não executa verificação
operacional desses 470 arquivos, nem autentica a candidata no Windows do usuário.

Antes de uma futura execução, serão necessários os bytes reais correspondentes,
manifestos do runner/helpers/fixtures, hashes dos executáveis Git/Python, dependências
transitivas/plugins, schemas/oráculos e parâmetros aprovados. Hashes Windows desses
binários e instalações seguem SEM_FONTE nesta entrega; não substituir pelos do Linux.
Cabe ao futuro escopo distinguir inspeção do código e eventual validação executável.

## 4. Contratos das fixtures, positivos e instrumentação

- Fixtures novas seriam sintéticas e locais, com construção declarativa de entradas,
  schema e resultados esperados revisados antes do leitor. Não usar documentos de
  clientes, fixtures legadas importadas ou gabarito copiado da saída do produto.
- Cada componente terá positivo próprio no laboratório: caso válido, bytes/árvore
  congelados e operação correta antes do adversarial. WIN-11 exige positivos
  independentes de repo e app. WIN-04 exige true próprio/equivalente e false distinto.
- Symlink/junction/hardlink/alias têm requisitos distintos; capacidade ausente não
  será contornada por elevação ou cenário de outro tipo. Nenhum conjunto verde
  limitado autoriza afirmar que o controle não exercitado foi aprovado.
- Observador externo inicia antes do filho/setup; asserções só depois de registros
  confirmados. Erros são capturados onde ocorrem, com API/camada corretas.
- W14P não é aplicada automaticamente; a proposta futura de snapshot terá diff
  próprio para nomes/tipos/IDs/diretórios e eventos, sem serializar segredos.
- CLI, JSON, auditoria e DTO têm resultados separados. Exportação operacional e
  validação de valores privados estão fora desta proposta.

## 5. Critérios de inspeção do eventual código

O revisor deverá conferir que nenhum import, inicialização de módulo ou descoberta
de plugin executa a suíte ou cria recursos antes da autorização de execução.
Examinar chamadas nativas, assinatura/tipos, captura imediata do erro, handles,
identidade de raízes/objetos e caminhos de exceção. Recusar passagem por links,
remoção por caminho não identificado, timeout sem evidência, retorno de sucesso
com cleanup incompleto e vazamento por traceback/locals.

Conferir dependências e bootstrap, ambiente por lista positiva, tratamento de .pth,
DLLs/imports transitivos, ausência de cache/bytecode, eventos anteriores a asserções,
primeira falha e canais contínuos. Cobertura documental deve relacionar cada um
dos 21 subcasos a suas subafirmações, positivos, sentinelas e limitações.

Mudanças no produto, API pública, regras financeiras/cadastrais ou política de
segurança devem ser recusadas nesse diff e propostas separadamente. Não fabricar
uma alteração de negócio para facilitar a fixture. Não reutilizar aprovação de
cleanup, parsing ou B para essas primitives.

## 6. Dossiê antes de qualquer pedido de execução

Uma implementação futura, se autorizada, deve parar e entregar: fontes/diff completos,
manifestos e procedimento de instalação/reconstrução isolada sem sobrescrita; lista
de dependências/binários e origem; mapa 21 cenários→evidência; desenho final de
cleanup/processos; inventário de riscos; roteiro de ambiente sem elevação; custódia,
retenção e autorização por caso. Nenhum teste, import de projeto, coleta pytest,
preflight ou ensaio resulta implicitamente da autorização de escrever código.

Quais verificações de código poderão ser executadas durante implementação precisam
constar expressamente da autorização futura. Esta C3 não autoriza sequer executá-las
agora. Aprovação do diff não dispensa autorização separada de execução Windows C.
DACL D requer ainda política, laboratório/tokens e integração real aprovados.

## 7. Suficiência atual para futura decisão

A documentação é suficiente para avaliar uma proposta limitada de componentes
externos, com T01/T06 especificados e dependências explícitas. **Não é suficiente
para autorizar implementação integral nem afirmar runner pronto.** Antes de aceitar
esse escopo integral, resolver/restringir T03/T04/T05/T07; aceitar expressamente a
lacuna T02 ou aprovar estratégia segura em revisão própria, sem convertê-la em PASS.

Uma eventual divisão de implementação deve indicar o que permanece bloqueado e
impedir execução por import/entrada automática. Não propor redução silenciosa de
21 cenários para parecer completo. A melhor decisão atual é revisão independente
destes limites; nenhum pedido de autorização operacional é feito nesta entrega.
