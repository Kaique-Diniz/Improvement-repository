# C3-B — arquitetura textual do futuro runner C

18/11/2026. **Especificação, sem implementação ou execução.** Base: arquitetura C2,
parecer independente e instruções C3. T01–T07 têm decisões de DESENHO, não resultado
de teste. Nenhuma configuração descrita foi aplicada. Não há comandos executáveis.

## 1. Fronteiras e estados

Componentes externos propostos: supervisor, escritor de eventos, transporte de
observações, verificador de referências, avaliador de capacidades, laboratório
sintético, snapshots, adaptador CLI, classificador de resultados e encerramento.
Todos seriam externos à candidata R1-FIX 470. O JUnit do futuro ensaio não substitui
o JUnit histórico. WIN-18/19 continuam protocolos DACL, fora de execução C comum.

O supervisor futuro só iniciará recursos após autorização específica e referências
congeladas. Fluxo proposto: autorização → identidade de versão → reserva exclusiva
→ início confirmado → setup/capacidade → positivo → snapshot → adversarial → operação
observada → evento confirmado → comparação → julgamento → encerramento → custódia.

Antes de cada transição que depende de evidência, exigir confirmação. Não produzir
PASS quando falta um estágio necessário. BLOQUEADO e SKIP preservam NÃO_VALIDADO
na afirmação não exercitada. Funcional, nativo, DACL, limpeza e custódia são campos
independentes. Interromper a sequência pertinente em API inesperada, identidade
divergente, alteração de sentinela ou perda de evidência, sem mudar expectativas.

## 2. T01 — observador durável: ESPECIFICADO

### Contrato de dados e ordenação

Um único escritor externo atribui sequência crescente por run. Evento tem versão
de schema, run/caso/subcaso, número e identificador de tentativa, etapa, instante
UTC e relógio monotônico de duração, componente emissor, tipo de objeto, operação,
resultado observado, origem da API/código, primeira falha, integridade e eixos.
Relógio civil não ordena eventos sozinho. Não publicar path pessoal, conta, SID,
SDDL, documentos, chaves, credenciais ou repr/locals de objetos secretos.

Registro determinístico e delimitado, com tamanho e hash; cada evento encadeia o
hash anterior. O índice final aponta hashes/quantidades confirmados. Uma cauda
truncada, lacuna, repetição conflitante ou cadeia inválida não recebe conclusão
completa. Hash encadeado não autentica contra reescrita pelo mesmo token: custódia,
recibo e hash final externo são necessários e não equivalem a DACL.

### Confirmação e falha de escrita

O escritor valida o evento seguro, grava fora de basetemp, esvazia buffers e pede
sincronização ao SO. Só depois confirma ao emissor o número/hash da sequência.
Releitura pode corroborar bytes, não provar resistência a queda de energia. A
revisão de implementação deve validar a primitiva de sincronização Windows usada.
O escopo mínimo é sobrevivência observável a falha de processo, sem prometer
resistência do hardware/volume a corte de energia ou adulteração pelo proprietário.

Nenhuma operação adversarial nem asserção interpretativa avança antes da confirmação
do evento correspondente. Deve existir início confirmado antes de disparar setup
do filho; falha de import, setup ou fixture não pode ocorrer antes do registro do
run no supervisor. Falha de espaço, permissão, transporte, serialização ou confirmação
bloqueia avanço. Se nem registrar a falha for possível, preservar último checkpoint
e marcar saída incompleta por canal mínimo seguro; nunca sintetizar journal íntegro.

Transporte terá tipos/campos permitidos e uma pendência por etapa, sem fila ilimitada.
Proposta PARA_REVISÃO: até 64 KiB UTF-8 por evento e espera de confirmação de até
30 segundos acompanhada por supervisor independente. Excesso, perda ou timeout
bloqueia, sem truncar ou reenviar automaticamente um evento que possa ter sido
gravado. Dado maior fica na custódia raw autorizada com referência. Os limites
precisam de aceite do revisor e não são resultados de desempenho observado.

### Primeira falha e crash

O emissor captura API/retorno/Win32 imediatamente onde ocorreu, antes de outra
chamada nativa. Só então transmite dado seguro. Escritor não reconstrói GetLastError
em outro processo. Se o produto não expõe essa origem, registrar NÃO_OBSERVÁVEL
e o código de aplicação disponível, sem modificar a candidata para instrumentar.
Os eventos anteriores às asserções referem-se aos cenários/helpers externos; uma
falha interna do produto é cercada por evento de chamada e captura de exceção,
sem inventar observação anterior de seu estado interno. Primeira falha é preservada; CloseHandle, timeout e cleanup
posteriores ficam como falhas secundárias. Erro de preparação não muda de categoria
só porque tem o código esperado pelo nome do teste.

Supervisor conserva início/último checkpoint se filho morrer. Se o próprio supervisor
morrer, a existência de eventos parciais permite reconhecer incompletude, não um
PASS. Reabertura e recuperação de journal exigem procedimento autorizado posterior,
sem repetir o caso automaticamente nem limpar laboratório inconclusivo. JUnit é
artefato complementar que pode faltar ou divergir; divergência precisa de revisão.

Evidência futura de aceite: sequência íntegra, confirmações anteriores aos marcos,
primeira falha preservada, saídas parciais em erro de setup/timeout/crash/falta de
escrita e observador externo intacto. Nada disso foi ensaiado na C3.

## 3. T02 — CompareStringOrdinal: BLOQUEADO no ramo de erro

Categorias distintas: comparação nativa válida (retornos 1/2/3); wrapper normalizado
(-1/0/+1); falha realmente retornada pela API; erro de carregar DLL/preparar buffer;
recusa pré-API; superfície NÃO_OBSERVÁVEL. Pares Unicode conhecidos de WIN-03
continuam o positivo funcional; não-BMP exige contagem WCHAR correta da versão.

Somente retorno nativo zero acompanhado do erro imediatamente capturado, buffers
válidos, assinatura/versão e chamada comprovadas sustentaria uma observação do ramo
de falha. Uma exceção do wrapper deve ter origem conferida: indisponibilidade de
DLL e NUL pré-API são preparação/recusa, não erro retornado por CompareStringOrdinal.
Não fazer aproximação textual, mock, ponteiro inválido, comprimento inconsistente
ou injeção insegura para fabricar esse ramo.

Não foi identificada estratégia segura e verificável de indução dentro do contrato
atual. Manter NÃO_VALIDADO. Se futuramente ocorrer falha natural sob autorização,
preservar evidência e parar para diagnóstico, sem repetir tentativas arbitrárias.
Instrumentação adicional apenas de observação teria de ser proposta e aprovada
separadamente; não alterar o produto para obter erro. Essa lacuna não autoriza
excluir silenciosamente a subafirmação nem chamar WIN-03 integralmente aprovado.

## 4. T03 — capacidades e identidade: PARCIAL

| Objeto/afirmação | Prova positiva futura | Limite |
|---|---|---|
| Arquivo regular | Mesmo caminho, volume/file ID conhecidos e bytes completos | Hash não é identidade |
| Symlink arquivo/diretório | Tipo/tag/entrada e alvo próprios, capacidade efetivamente criada | Erro 1314 só deixa cenário não validado; não mudar privilégio |
| Junction | Tag de mount point e destino próprios observados, em cenário próprio aprovado | Não substitui symlink indisponível |
| Hardlink | Dois nomes, mesmo volume/file ID, nlink e bytes iguais | Não é reparse nem vulnerabilidade universal |
| Alias 8.3 | Alias real existente, longo/curto com mesmo objeto e bytes | Não fabricar nome nem inferir capacidade |
| Comparador de caminhos | Próprio e equivalente real true; diferente false | Identidade física e nome normalizado são contratos distintos |

Hardlink de nome diferente deve ser julgado pela regra do comparador diagnóstico;
o leitor ID+SHA pode ter outro contrato. Mesmo conteúdo em OUTRO arquivo é negativo
necessário para impedir equivalência por hash. File ID é interpretado junto do
volume e da vida do objeto; pode ser reutilizado após exclusão e não autoriza apagar
um nome encontrado depois. Comparador sempre false falha no controle positivo.

Futura camada nativa deverá manter identidade de raiz/ancestrais/entrada sem seguir
reparse e impedir redirecionamento entre inspeção e uso. Caminho resolvido, lstat
antes de abrir ou snapshot por nome não bastam sob substituição concorrente. A
estratégia de handles/compartilhamento/ABI Windows ainda exige revisão; não é
comprovada pelos helpers propostos ou pelo cleanup anterior. Limitar inicialmente
a volume local de laboratório aprovado; rede/namespace especial não é suportado
por inferência. Nenhuma capacidade foi sondada nesta etapa.

O privilégio de symlink permanece indisponível segundo o ambiente relatado. Não
ativar Developer Mode ou elevar. Se não houver laboratório legítimo com a capacidade,
manter subafirmações dependentes NÃO_VALIDADO. Não transformar junction em atalho
para produzir PASS de symlink. Por essas lacunas, T03 não está integralmente fechado.

## 5. T04 — Git, Python e imports: PARCIAL

Git: executável absoluto e SHA aprovados; processo filho por lista positiva mínima;
remover TODA variável GIT_* herdada, inclusive config injetada, alternate object,
worktree/index/templates/exec path. Reintroduzir apenas controles de processo
revisados: sem config de sistema, global vazia própria, local nova, hooks/template
vazios próprios, nenhum include ou rede. Não mudar HOME ou config persistente.
Diretório de trabalho e criação exclusiva precisam corresponder ao laboratório.
Positivo Git de laboratório não atesta todas as formas de Git do produto.

Python: binário absoluto 3.12 aprovado e UTF-8; bootstrap futuro externo sob revisão,
sem execução automática de sitecustomize/usercustomize/.pth não aprovados, sem
PYTHONPATH/PYTHONHOME herdados. Preferir uma inicialização sem processamento automático
de site e inserir explicitamente apenas a candidata e diretórios de dependências
congelados. Não combinar modo isolado que ignora PYTHONPATH com alegação de que a
variável definiu imports. Bootstrap, extensões, carregamento de DLL e dependências
transitivas precisam de mapa de origem antes de autorizar execução.

Nenhum .pth pode ser executado implicitamente; se uma dependência exigir uma ação
assim, revisar a necessidade e uma alternativa explícita. Não herdar plugins via
ambiente/entry points: lista aprovada e desabilitação de descoberta automática.
Sem xdist, cache do pytest ou bytecode. Congelar origem dos módulos carregados e
comparar com o mapa aprovado, sem chamar uma origem inesperada só para verificá-la.
A verificação posterior do módulo é complementar, pois um import já pode ter efeitos.

Controle positivo futuro: módulo benigno conhecido vindo da raiz aprovada e Git
sintético no destino certo, com evidência de configuração e integridade antes/depois.
Raiz do projeto não pode virar cwd implícito que introduz módulos. Outputs e temporários
ficam externos e explícitos; importação e callbacks com escrita inesperada bloqueiam.

Não há hashes do executável/dependências Windows efetivamente instalados nesta C3,
nem bootstrap concreto revisado. Sem import/instalação agora. Mesmo token não é
sandbox contra Python hostil; hash final detecta estado final, não impede escrita
transitória. Barreira de SO, se exigida, precisa de política/arquitetura separada,
sem modificar ACL nesta etapa. Esses pontos mantêm T04 PARCIAL.

## 6. T05 — WIN-14 e snapshots: PARCIAL

W14P continua não aplicada. Acrescenta snapshot de authority.raiz após o positivo
e sua igualdade após a recusa; amplia intenção, mas o helper atual só guarda mapa
de arquivos regulares→bytes. Não representa diretórios vazios/identidade, nem garante
raiz/ancestrais contra substituição, nem evidência durável antes dos asserts internos.

A futura referência será congelada APÓS pacote mínimo legítimo, autoridade/concessão,
gravação, recibo, verificação de assinatura/ator/hash e releitura. A política histórica
criada por esse positivo pertence ao estado permitido. Novo ID do ataque será validado
antes de trocar somente a fonte por link. Esperar recusa da fonte antes de _guardar;
corpo/recibo/policy novos não podem ser aceitos como efeito irrelevante.

Snapshots por fronteira, sem curto-circuito: fontes, sentinela externa própria,
repo de corpos, âncoras/recibos/locks, toda autoridade (chave, concessões, policies
e demais entradas reais). Capturar nomes relativos, tipos, identidade/volume,
diretórios inclusive vazios, bytes completos e metadados relevantes que possam ser
lidos legitimamente. Anomalia ou leitura incompleta gera evento incompleto, não
assert que perde diagnóstico. Nenhum segredo ou hash de credencial vai ao derivado;
booleans por fronteira são suficientes ao relatório público.

Comparação final prova somente os estados observados. Não demonstra ausência de
leitura, escrita transitória revertida, todo estado em memória ou isolamento de
segredo por DACL. Se o contrato exigir essas alegações, a evidência deverá ser
desenhada separadamente; não promover igualdade posterior a prova de não acesso.

T05 depende de T01/T03 e revisão do helper para snapshots seguros. Nenhum produto
foi modificado. Mudança no escritor/leitor ou política física exigiria tarefa
específica; não é requisito a implementar por suposição de vulnerabilidade.

## 7. T06 — WIN-16 e oráculo: ESPECIFICADO

| Plano | Positivo/expectativa congelada | Evidência futura e limite |
|---|---|---|
| CLI | PDF posicionado fabricado com um documento válido: zero/comparacao_confere | Retorno e stdout/stderr não substituem JSON; erros de setup não são retenção |
| JSON/documentos | Oráculo declarativo prévio, IDs/regras de origem/contagens conhecidos | Zero divergências; um/um/zero; duas evidências corretas no conflito e fontes intactas |
| Auditoria | Conflito fabricado: dois/revisao_humana e ocorrência esperada, sem homologação | Retorno dois sozinho é ambíguo; registrar JSON ausente/ilegível também |
| DTO | Pessoa do gabarito conflitante recusada por revisão humana | Prova isolada; não é o objeto materializado pelo CLI |
| Exportação | Não faz parte desse CLI de validação | Sem canônico/XLSX indevido é guarda local, não homologação operacional |

Oráculo é definido antes da leitura a partir da tabela de dados/coordenadas sintéticas
e algoritmo de IDs declarados, sem copiar saída do leitor ou importar seu helper
para gerar esperado. Deve ser revisado independentemente da factory/renderizador;
a mesma tabela compartilhada pode gerar erro comum entre fixture e esperado. Congelar
versão/hashes e inspecionar que o PDF realmente representa a intenção em futura revisão
legítima. Não usar resultado financeiro privado nem transformar fixture em autorização.

Supervisor inicia evento confirmado antes do filho; stdout e stderr são drenados
continuamente para arquivos exclusivos de custódia externa ao basetemp, com sequência
e checkpoints, sem aguardar término normal. Dois canais devem ser drenados para
não bloquear por pipe cheio. Buffers finitos, contadores e qualquer perda registrada;
perda de conteúdo necessário impede aceite, sem truncamento silencioso.

Assim que ler JSON/auditoria, persistir status, contagens, ocorrência, comparação de
bytes e erro antes das asserções. Raw de documentos sintéticos permanece privado;
o derivado só contém agregados seguros. Em timeout/crash, conservar bytes já recebidos,
registrar fase e falta de término, encerrar só filho próprio e impedir PASS. Detalhes
de cancelamento dependem de T07; isso não é resultado observado nesta C3.

O desenho dos quatro planos, oráculo, fluxo de observação e limites está especificado.
Implementação concreta depende de T01/T04/T07 e revisão de fixtures. Prova ponta a
ponta de exportação ou regra financeira não integra esse escopo. Conversões bloqueadas.

## 8. T07 — propriedade e limpeza: PARCIAL

Reservar basetemp inexistente por raiz exclusiva, nunca reutilizar caminho. O registro
de propriedade terá identificador de criação do ensaio, raiz/volume/IDs, tipos,
ancestrais e objetos adicionados. Marcador em arquivo não basta: pode ser copiado.
Evidências não podem residir no que será removido. Processo é próprio se foi criado
pelo supervisor e há handle/identidade de criação, não apenas PID ou nome reutilizável.

Proposta de política limitada, ainda não implementação: uma tentativa de exclusão
por entrada de identidade confirmada na fase de cleanup. Falha não dispara rmtree,
recursão alternativa ou nova rodada. Exclusão pendente pode ter somente observação
de conclusão, sem repetir a exclusão: até 20 observações, intervalo alvo de 100 ms,
orçamento de dois segundos por caso acompanhado por relógio monotônico. Esses limites
são escolha conservadora PARA_REVISÃO, não parâmetro testado; demora legítima pode
produzir resíduo/falha. Limites de observação não tornam WinAPI bloqueante cancelável.

Recusar alteração de identidade, entrada desconhecida, link/reparse inesperado ou
alvo externo. Percorrer sem seguir link; remover somente entrada própria conforme
seu tipo, sem atravessar destino. Necessidade de handles/compartilhamento e primitives
de remoção por identidade ainda deve ser auditada. Não alterar temporarios.py,
share0x3, motor validado ou políticas para resolver a lacuna do runner. Antes/depois
por caminho sozinho não comprova proteção contra substituição concorrente.

Filhos/handles próprios serão registrados desde criação e fechados em ordem definida.
A opção de conter descendentes num grupo de processos próprio precisa de revisão
nativa; não presumir que um PID autoriza encerrar todos os processos de mesmo nome.
Se API ou filho bloquear, supervisor conserva evidências e marca timeout/resíduo;
não encerra processo desconhecido nem promete limpeza completa. Cancelamento por
handle/grupo comprovadamente próprio é dependência de implementação ainda pendente.

Resultado separado: estado do teste, eixos, encerramento de processos/handles,
limpeza e custódia. Resíduo gera FALHOU na limpeza ou NAO_COMPROVADA se a verificação
não terminou; nenhum sucesso operacional global. Persistir primeira falha, API,
Win32/errno imediato, tipo/profundidade/contadores e falhas secundárias, sem paths
privados. Preservar JUnit/journal/relatório parcial e laboratório inconclusivo.
Procedimento posterior de resíduo precisa de autorização específica. Não tocar o
residual antigo ou qualquer evidência preexistente nesta fase ou em fallback.

## 9. Avaliação de viabilidade e alcance futuro

T01 e T06 têm contratos documentados; não são implementados ou aprovados por teste.
T02 bloqueia a subafirmação de erro nativo. T03/T04/T05/T07 são parciais por capacidade,
identidade/ABI, bootstrap e primitivas de limpeza/observação ainda não revisados.
Não declarar o runner integral pronto para implementação ou execução automática.

A proposta de escopo separado pode ser submetida à revisão, com dependências e
exclusões explícitas. Eventual implementação parcial de componentes não executáveis
por si só também requer autorização. Nenhuma lacuna autoriza mudar o produto, DACL,
privilégio ou evidência anterior. O próximo parecer decidirá o avanço documental.
