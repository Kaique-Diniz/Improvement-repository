# H3-H-E2 — registro das tentativas e evidência recebida

26/11/2026. Referência documental local REG-H3H-E2-20261126-01.
Não é ID nativo de mensagem, assinatura ou identificação de máquina.

## Fonte e sequência informada

A instrução H3-H-E2 fornecida pelo usuário, Texto colado.txt, é a fonte documental
da narrativa e do JSON. Ela informa que H3-H-E1 foi concluída no Windows local.
Não se recuperou uma captura original do console, log automático ou arquivo
primário da saída. As tentativas são registradas na ordem informada, sem horário
exato, caminho privado ou identificação pessoal.

| Tentativa | Evidência recebida | Autenticação e parser | Resultado registrado |
|---|---|---|---|
| Primeira | Relato textual, H3H_CAMINHO_FONTE_INVALIDO | Fonte não autenticada; parser não invocado | Interrupção de entrada; quantidade de erros sintáticos não medida/não aplicável, sem reconstruir JSON |
| Segunda | JSON sanitizado de 20 campos na instrução | Fonte/bloco conferidos; parser invocado e concluído | SINTAXE_VALIDA_PS51, 0 erros, lista vazia, sem impedimento; código analisado executado=false |

O caminho completo foi informado localmente pelo usuário na segunda tentativa,
segundo a narrativa. Não foi fornecido nem solicitado nesta consolidação.
Não se reexecutou a tentativa inválida ou válida para confirmar o relato.

## Registro individual das condições da segunda tentativa

| Condição | Valor informado | Conferência documental |
|---|---|---|
| Etapa/versão auxiliar | WIN19-H3-H / 20261124-proposta-1 | Rótulos correspondem ao auxiliar proposto |
| Ambiente | WINDOWS_POWERSHELL_51_DESKTOP | Coerente com exigência PS5.1; contexto não autenticado independentemente |
| Versão efetiva relatada | 5.1.26100.10068 | Major/minor 5.1 coerentes |
| API | disponível=true | Relato, não consulta pelo Codex |
| Assembly | System.Management.Automation / 3.0.0.0 | Metadado; não assinatura |
| Documento | fonte_sha256_conferida=true; 22.438 bytes | Coincide com tamanho aprovado; digest esperado consta nas fontes |
| Bloco | bloco_sha256_conferido=true; 20.362 bytes; 383 linhas | Coincide com identidade R1 aprovada |
| Parser | invocado=true; concluído=true | Coerência das flags com resultado |
| Erros | quantidade=0; erros_sintaticos=[] | Contagem/lista coerentes |
| Classificação | SINTAXE_VALIDA_PS51; codigo_impedimento=null | Coerente apenas no eixo sintático |
| Execução do analisado | false | Não é prova externa da ausência de toda operação da máquina |
| Recursos | recursos_leitura_fechados=true | Refere-se ao auxiliar; não aos recursos WMI do código analisado |

## Documento JSON derivado

RESULTADO_PARSING_SANITIZADO.json contém exatamente o objeto informado na segunda
tentativa, normalizado para JSON UTF-8 sem BOM, indentação de dois espaços e LF
final. Não foi acrescentada metadata de proveniência dentro dele para não alterar
os valores observados; a identificação DERIVADO consta neste registro e no índice.
Valores null/booleanos/números/strings/lista vazia foram preservados sem coerção.

Tamanho desta versão derivada: 714 bytes. SHA-256 novo:
83bb042a0ce388c38f1ca2e01187030a867719a3b907e845e0faaf69a408e1c0.
Mesmo que sua representação coincida com o trecho textual recebido, esse hash
não autentica os bytes históricos do console Windows nem sua cadeia de custódia.

## Três camadas de hash

1. Máquina do usuário: conferências de fonte/bloco são INFORMADAS pelos booleanos
   true; os digests calculados não são transportados no JSON.
2. Artefatos prévios: hashes esperados dos Markdown/blocos são conhecidos e
   recalculados documentalmente em Linux, sem abrir o Windows ou executar código.
3. Entrega E2: manifesto/hash do JSON e documentos novos identificam a consolidação
   atual; não são assinatura ou hash da saída original da máquina.

A correspondência de versão do auxiliar não é seu auto-hash em execução.
Não se conclui parsing independente do auxiliar de 12.997 bytes a partir desse
rótulo. A conclusão atual aplica-se somente ao bloco H3-F-R1 indicado.
