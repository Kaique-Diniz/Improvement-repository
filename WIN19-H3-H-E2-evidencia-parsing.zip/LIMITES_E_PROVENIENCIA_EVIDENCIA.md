# H3-H-E2 — limites técnicos e proveniência da evidência

26/11/2026. Fonte: transcrição textual e narrativa incorporadas à instrução
H3-H-E2 recebida do usuário. Não é arquivo primário autenticado de saída Windows.

## Alcance probatório

O registro é uma evidência de resultado informado pelo usuário, coerente com os
artefatos autenticados e o modelo de saída. Não foi conferido por monitoramento
de runtime, tokens/AST originais ou captura independente. Não há assinatura,
hash histórico da saída, identidade de máquina, conta/SID, caminho local, hora
exata das tentativas ou cadeia de custódia demonstrada. Nenhum desses dados é
inferido do número de versão ou solicitado nesta consolidação.

Há distinção entre conferir o JSON como dados e executar o parser de PowerShell:
a primeira foi realizada documentalmente; a segunda não foi realizada pelo Codex.
O novo JSON normalizado é DERIVADO, com valores iguais aos recebidos, e seu hash
é atual. Não substituir a origem por essa cópia nem renomear seu hash como se
fosse digest original do console Windows.

Os booleanos de hash informam correspondência segundo o procedimento relatado;
não apresentam digests calculados ou bytes do Windows. Hashes locais prévios
atestam o conjunto documental esperado. O rótulo do auxiliar coincide, mas não
prova que os 12.997 bytes autenticados foram os efetivamente executados.
Assembly 3.0.0.0 é metadado, não assinatura ou atestado de legitimidade do host.

## O parsing não comprova

1. Funcionamento das APIs .NET em execução.
2. Correção/disponibilidade das consultas WMI.
3. Tratamento adequado de exceções e condições de falha.
4. Encerramento efetivo de recursos do H3-F-R1, inclusive finally/Dispose WMI.
5. Segurança das operações de leitura do destino.
6. Identidade física do disco ou natureza inequivocamente interna.
7. Ausência de reparse points, aliases, SUBST ou redirecionamentos.
8. Correção funcional dos critérios V01–V10.
9. Proteção do futuro diretório, XML, parciais ou registros.
10. Conformidade da custódia e acesso efetivo de coadministradores.
11. Autenticidade do JUnit histórico ou reconciliação dos seus vínculos.
12. Prontidão operacional do MVP, homologação WIN/DACL ou conversões reais.

O parser não substitui teste funcional ou auditoria de segurança. Nenhum controle
é considerado aprovado por efeito desse resultado. A flag recursos_leitura_fechados
se refere ao auxiliar; script_analisado_executado=false não é prova externa de
que nenhuma outra operação ocorreu no computador.

## Publicação e governança independentes

O parecer H3-J de 26/11/2026 aceita documentalmente a confirmação do meio público
H3-F-R1 e encerra essa pendência restrita. Não autentica retroativamente o pedido
primário anterior, ator/horário do push ou conformidade institucional. H3-H é
publicação distinta, fora dessa confirmação. Esta consolidação não muda tais
ressalvas nem usa link público como fonte operacional automática.

Custódia local, papéis privados e retenção 180 dias após cópia fiel aceita não
são modificados. Não há criação de destino, cópia de JUnit, divulgação privada,
ACL/privilégio/política ou execução autorizada por este documento. Nenhuma nova
execução Windows, teste ou operação de custódia integra a H3-H-E2.
