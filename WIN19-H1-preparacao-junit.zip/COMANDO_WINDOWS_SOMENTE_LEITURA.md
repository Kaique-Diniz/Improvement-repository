# WIN19-H1 — identificação local proposta, somente leitura

24/11/2026 — America/Sao_Paulo. **PROPOSTO; NÃO EXECUTADO; REVISÃO PENDENTE.**
O Codex não executou este bloco nem seu parser PowerShell. Compatibilidade nativa
PowerShell 5.1 ainda não verificada por execução. Não é preflight do Portão B,
runner, recuperação de XML, sanitizador, teste de segurança ou autorização de cópia.

## Escopo do bloco para revisão

Alvo único relatado:
`%LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml`.
A resolução parte somente de LOCALAPPDATA, não de nomes de usuário, HOME, Git ou
candidatas. São lidos metadados desse caminho e de seus ancestrais necessários,
sem enumerar arquivos, pesquisar pastas alternativas ou seguir uma nova origem.
O bloco não deverá ser executado pelo usuário antes da revisão deste procedimento.

A criação e a modificação UTC são observadas em variáveis transitórias e conferidas
antes/depois. A criação não é exportada: a lista de saída compartilhável H1 admite
somente a data de modificação. Não há persistência de registro privado ou relatório
nesta etapa; o protocolo de custódia futuro definirá a anotação durável autorizada.

## Bloco único PowerShell 5.1 — somente proposta

```powershell
& {
    $ErrorActionPreference = 'Stop'
    $h1Nome = 'completa-utf8.xml'
    $h1Stream = $null
    $h1Hasher = $null
    $h1Verificacoes = [ordered]@{
        powershell_versao = $PSVersionTable.PSVersion.ToString()
        powershell_51 = $false
        volume_local_fixo = $false
        componentes_sem_reparse = $false
        alvo_regular = $false
        criacao_utc_observada_internamente = $false
        leitura_integral_para_hash = $false
        metadados_estaveis = $false
        identidade_fisica_autenticada = $false
        autenticidade_historica_comprovada = $false
        recursos_fechados = $false
        fuso_datas = 'UTC'
        resultado = 'NAO_CONCLUIDO'
    }
    $h1Saida = [ordered]@{
        estado = 'NAO_LOCALIZADO'
        nome_arquivo = $h1Nome
        tamanho_bytes = $null
        sha256 = $null
        modificacao_utc = $null
        verificacoes = $h1Verificacoes
        codigo_impedimento = $null
    }
    $h1Codigos = @(
        'H1_POWERSHELL_51_REQUERIDO', 'H1_AMBIENTE_WINDOWS_REQUERIDO',
        'H1_LOCALAPPDATA_INVALIDO', 'H1_VOLUME_NAO_FIXO',
        'H1_REPARSE_DETECTADO', 'H1_ANCESTRAL_NAO_DIRETORIO',
        'H1_ALVO_NAO_REGULAR', 'H1_ARQUIVO_VAZIO',
        'H1_LEITURA_INCOMPLETA', 'H1_COMPONENTES_ALTERADOS',
        'H1_METADADOS_ALTERADOS', 'H1_SHA256_INDISPONIVEL'
    )

    function Obter-H1Snapshot {
        param([string]$Alvo)
        $raiz = [IO.Path]::GetPathRoot($Alvo)
        $relativo = $Alvo.Substring($raiz.Length)
        $partes = $relativo.Split([char[]]@([char]92),
            [StringSplitOptions]::None)
        $caminhos = @($raiz)
        $atual = $raiz
        foreach ($parte in $partes) {
            if ([string]::IsNullOrEmpty($parte) -or
                $parte -eq '.' -or $parte -eq '..' -or
                $parte.EndsWith('.') -or $parte.EndsWith(' ') -or
                $parte.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) {
                throw 'H1_LOCALAPPDATA_INVALIDO'
            }
            $atual = [IO.Path]::Combine($atual, $parte)
            $caminhos += $atual
        }
        $componentes = @()
        $arquivo = $null
        for ($i = 0; $i -lt $caminhos.Count; $i++) {
            $atributos = [IO.File]::GetAttributes($caminhos[$i])
            if (($atributos -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw 'H1_REPARSE_DETECTADO'
            }
            $ultimo = ($i -eq $caminhos.Count - 1)
            $diretorio = (($atributos -band [IO.FileAttributes]::Directory) -ne 0)
            $dispositivo = (($atributos -band [IO.FileAttributes]::Device) -ne 0)
            if ($dispositivo -or ($ultimo -and $diretorio)) {
                throw 'H1_ALVO_NAO_REGULAR'
            }
            if (-not $ultimo -and -not $diretorio) {
                throw 'H1_ANCESTRAL_NAO_DIRETORIO'
            }
            if ($ultimo) {
                $item = [IO.FileInfo]::new($caminhos[$i])
            }
            else {
                $item = [IO.DirectoryInfo]::new($caminhos[$i])
            }
            $item.Refresh()
            if (-not $item.Exists) { throw 'H1_COMPONENTES_ALTERADOS' }
            if ($item.Attributes -ne $atributos) { throw 'H1_COMPONENTES_ALTERADOS' }
            $componentes += [pscustomobject]@{
                indice = $i
                atributos = [int]$atributos
                criacao_ticks_utc = $item.CreationTimeUtc.Ticks
            }
            if ($ultimo) {
                $arquivo = [pscustomobject]@{
                    nome = $item.Name
                    tamanho = $item.Length
                    criacao_utc = $item.CreationTimeUtc
                    modificacao_utc = $item.LastWriteTimeUtc
                }
            }
        }
        [pscustomobject]@{ Componentes = $componentes; Arquivo = $arquivo }
    }

    function Confirmar-H1Estabilidade {
        param($Antes, $Depois)
        if ($Antes.Componentes.Count -ne $Depois.Componentes.Count) {
            throw 'H1_COMPONENTES_ALTERADOS'
        }
        for ($i = 0; $i -lt $Antes.Componentes.Count; $i++) {
            if ($Antes.Componentes[$i].atributos -ne $Depois.Componentes[$i].atributos -or
                $Antes.Componentes[$i].criacao_ticks_utc -ne $Depois.Componentes[$i].criacao_ticks_utc) {
                throw 'H1_COMPONENTES_ALTERADOS'
            }
        }
        if ($Antes.Arquivo.tamanho -ne $Depois.Arquivo.tamanho -or
            $Antes.Arquivo.criacao_utc.Ticks -ne $Depois.Arquivo.criacao_utc.Ticks -or
            $Antes.Arquivo.modificacao_utc.Ticks -ne $Depois.Arquivo.modificacao_utc.Ticks) {
            throw 'H1_METADADOS_ALTERADOS'
        }
    }

    try {
        if ($PSVersionTable.PSVersion.Major -ne 5 -or
            $PSVersionTable.PSVersion.Minor -ne 1) {
            throw 'H1_POWERSHELL_51_REQUERIDO'
        }
        $h1Verificacoes.powershell_51 = $true
        if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
            throw 'H1_AMBIENTE_WINDOWS_REQUERIDO'
        }
        $h1BaseBruta = $env:LOCALAPPDATA
        if ([string]::IsNullOrWhiteSpace($h1BaseBruta) -or
            $h1BaseBruta -notmatch '^[A-Za-z]:\\') {
            throw 'H1_LOCALAPPDATA_INVALIDO'
        }
        $h1BaseBruta = $h1BaseBruta.TrimEnd([char]92)
        $h1Base = [IO.Path]::GetFullPath($h1BaseBruta)
        if (-not [string]::Equals($h1BaseBruta, $h1Base,
            [StringComparison]::OrdinalIgnoreCase)) {
            throw 'H1_LOCALAPPDATA_INVALIDO'
        }
        $h1Alvo = [IO.Path]::Combine($h1Base, 'EXP04-Auditoria')
        $h1Alvo = [IO.Path]::Combine($h1Alvo, 'Completa-UTF8-20261117-094619')
        $h1Alvo = [IO.Path]::Combine($h1Alvo, $h1Nome)
        $h1Disco = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($h1Alvo))
        if (-not $h1Disco.IsReady -or $h1Disco.DriveType -ne [IO.DriveType]::Fixed) {
            throw 'H1_VOLUME_NAO_FIXO'
        }
        $h1Verificacoes.volume_local_fixo = $true
        $h1Antes = Obter-H1Snapshot -Alvo $h1Alvo
        $h1Saida.estado = 'LOCALIZADO'
        $h1Saida.nome_arquivo = $h1Antes.Arquivo.nome
        $h1Verificacoes.alvo_regular = $true
        $h1Verificacoes.criacao_utc_observada_internamente = $true
        $h1InstantePrivadoUtc = [DateTime]::UtcNow
        if ($h1Antes.Arquivo.tamanho -le 0) { throw 'H1_ARQUIVO_VAZIO' }
        $h1Stream = [IO.File]::Open($h1Alvo, [IO.FileMode]::Open,
            [IO.FileAccess]::Read, [IO.FileShare]::Read)
        if (-not $h1Stream.CanRead -or -not $h1Stream.CanSeek -or
            $h1Stream.Length -ne $h1Antes.Arquivo.tamanho) {
            throw 'H1_LEITURA_INCOMPLETA'
        }
        $h1Hasher = [Security.Cryptography.SHA256]::Create()
        if ($null -eq $h1Hasher) { throw 'H1_SHA256_INDISPONIVEL' }
        $h1Digest = $h1Hasher.ComputeHash($h1Stream)
        if ($h1Stream.Position -ne $h1Antes.Arquivo.tamanho -or
            $h1Stream.Length -ne $h1Antes.Arquivo.tamanho) {
            throw 'H1_LEITURA_INCOMPLETA'
        }
        $h1Depois = Obter-H1Snapshot -Alvo $h1Alvo
        Confirmar-H1Estabilidade -Antes $h1Antes -Depois $h1Depois
        $h1Verificacoes.componentes_sem_reparse = $true
        $h1Verificacoes.leitura_integral_para_hash = $true
        $h1Verificacoes.metadados_estaveis = $true
        $h1Saida.tamanho_bytes = $h1Depois.Arquivo.tamanho
        $h1Saida.sha256 = [BitConverter]::ToString($h1Digest).Replace('-', '').ToLowerInvariant()
        $h1Saida.modificacao_utc = $h1Depois.Arquivo.modificacao_utc.ToString(
            "yyyy-MM-ddTHH:mm:ss.fffffff'Z'", [Globalization.CultureInfo]::InvariantCulture)
        $h1Verificacoes.resultado = 'METADADOS_CONFERIDOS_COM_LIMITACOES'
    }
    catch {
        $h1Erro = $_.Exception.GetBaseException()
        if ($h1Codigos -contains $h1Erro.Message) {
            $h1Saida.codigo_impedimento = $h1Erro.Message
        }
        elseif ($h1Erro -is [IO.FileNotFoundException] -or
                $h1Erro -is [IO.DirectoryNotFoundException]) {
            $h1Saida.codigo_impedimento = 'H1_CAMINHO_OU_ALVO_AUSENTE'
        }
        elseif ($h1Erro -is [UnauthorizedAccessException] -or
                $h1Erro -is [Security.SecurityException]) {
            $h1Saida.codigo_impedimento = 'H1_ACESSO_NEGADO'
        }
        elseif ($h1Erro -is [IO.IOException]) {
            $h1Saida.codigo_impedimento = 'H1_IO_OU_COMPARTILHAMENTO_IMPEDITIVO'
        }
        else {
            $h1Saida.codigo_impedimento = 'H1_ERRO_OPERACIONAL_NAO_CLASSIFICADO'
        }
        $h1Saida.tamanho_bytes = $null
        $h1Saida.sha256 = $null
        $h1Saida.modificacao_utc = $null
        $h1Verificacoes.resultado = 'IMPEDIDO'
    }
    finally {
        $h1FechamentoOk = $true
        foreach ($h1Recurso in @($h1Hasher, $h1Stream)) {
            if ($null -ne $h1Recurso) {
                try { $h1Recurso.Dispose() }
                catch { $h1FechamentoOk = $false }
            }
        }
        $h1Verificacoes.recursos_fechados = $h1FechamentoOk
        if (-not $h1FechamentoOk) {
            if ($null -eq $h1Saida.codigo_impedimento) {
                $h1Saida.codigo_impedimento = 'H1_FECHAMENTO_LEITURA_FALHOU'
            }
            $h1Saida.sha256 = $null
            $h1Verificacoes.resultado = 'IMPEDIDO'
        }
    }
    [pscustomobject]$h1Saida | ConvertTo-Json -Depth 4
}
```

## Leitura da saída proposta

Apenas sete campos de topo: estado LOCALIZADO/NAO_LOCALIZADO; nome_arquivo;
tamanho_bytes; sha256; modificacao_utc; verificacoes; codigo_impedimento.
Criação/horário de observação e caminhos não são exportados. A versão PowerShell e
as limitações aparecem somente como resultados das verificações. Compartilhar,
após revisão e execução autorizadas ao usuário, apenas esse resumo JSON, nunca
$Error, histórico da sessão, transcrição integral, XML ou mensagem bruta de exceção.

LOCALIZADO significa que o caminho foi observado como arquivo regular após as
verificações iniciais. Não é prova de originalidade histórica. NAO_LOCALIZADO com
impedimento significa identificação não concluída: não prova ausência absoluta
quando houve acesso negado, reparse, ambiente inválido ou erro operacional.
O nome é obtido da consulta FileInfo do alvo referido; não é autenticação física
nem garantia de grafia/capitalização original em filesystem case-insensitive.

| Resultado/código | Interpretação e parada |
|---|---|
| METADADOS_CONFERIDOS_COM_LIMITACOES, sem impedimento observado | Fingerprint atual e metadados observáveis; não autoriza cópia, parsing ou vínculo |
| H1_CAMINHO_OU_ALVO_AUSENTE | Algum componente/alvo não pôde ser localizado; não buscar outros caminhos |
| H1_ACESSO_NEGADO | Não elevar privilégios nem alterar permissões |
| H1_REPARSE_DETECTADO | Recusa de symlink/junction/reparse no alvo ou ancestrais; sem seguir outra fonte |
| H1_COMPONENTES_ALTERADOS / H1_METADADOS_ALTERADOS | Mudança observável; não escolher automaticamente uma versão ou repetir em laço |
| H1_LEITURA_INCOMPLETA / H1_IO_OU_COMPARTILHAMENTO_IMPEDITIVO | Leitura não comprovada, compartilhamento impeditivo ou I/O; hash não aceito |
| H1_ALVO_NAO_REGULAR / H1_ANCESTRAL_NAO_DIRETORIO | Tipo inadequado no caminho exato |
| H1_ARQUIVO_VAZIO | Arquivo vazio não serve como JUnit identificado nesta etapa |
| H1_POWERSHELL_51_REQUERIDO / H1_AMBIENTE_WINDOWS_REQUERIDO | Procedimento não executa em ambiente diferente do proposto |
| H1_LOCALAPPDATA_INVALIDO / H1_VOLUME_NAO_FIXO | Caminho não canônico/local inequívoco no perfil proposto; sem fallback |
| H1_SHA256_INDISPONIVEL / H1_FECHAMENTO_LEITURA_FALHOU / H1_ERRO_OPERACIONAL_NAO_CLASSIFICADO | Impedimento não convertido em sucesso; mensagem bruta não exportada |

## Limites de concorrência e autenticação

FileMode.Open/FileAccess.Read/FileShare.Read só abre para leitura e, enquanto o
handle estiver aberto, não concede compartilhamento para escrita/exclusão.
Não é mudança de ACL, política ou atributo; pode falhar se houver compartilhamento
incompatível. Há comparação de tamanho, criação/modificação UTC, atributos e criação
dos componentes antes/depois, além de comprimento/posição do stream. Isso detecta
somente mudanças observáveis e não elimina todas as janelas de corrida.

Não há pin nativo dos diretórios, file ID/volume serial, contagem de hardlinks,
resolução física independente de alias 8.3/SUBST nem prova forense de que um ancestral
não foi trocado e restaurado entre consultas. Hash e metadados estáveis não bastam
para autenticar o vínculo histórico do objeto. Os campos identidade_fisica_autenticada
e autenticidade_historica_comprovada permanecem false inclusive no caso nominal.
Ambiguidade conhecida ou exigência de autenticação física mais forte bloqueia a
próxima decisão; deverá ser relatada, sem acrescentar P/Invoke ou ferramentas aqui.

A rotina não altera LastWriteTime/CreationTime, atributos, owner ou permissões.
Leitura pode produzir atualização de último acesso gerida pelo sistema de arquivos;
não é prometida preservação forense absoluta de todos os metadados, e nada é
reescrito para ocultá-la. Não há cópia, rename, move, escrita, XML parser, Git,
pytest, rede, execução de traceback, mudança de policy ou privilégio.

Este documento contém preparação, não um resultado observado no Windows. A execução
manual pelo usuário só poderá ocorrer após a revisão; cópia/sanitização/reconciliação
continuam decisões separadas. O bloco não salva saída, não cria custódia e não
transforma um hash calculado hoje em prova contemporânea da execução de 17/11.
