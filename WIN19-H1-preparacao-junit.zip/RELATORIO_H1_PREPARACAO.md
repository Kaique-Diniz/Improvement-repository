# WIN19-H1 — identificação do JUnit e preparação da custódia

24/11/2026 — America/Sao_Paulo. **PREPARACAO_DOCUMENTAL; revisão independente pendente.**

## Situação atual

A Categoria A está CONSOLIDADA_DOCUMENTALMENTE conforme o parecer C8 de 24/11.
Essa decisão encerra a composição documental 5+1; não implementa consumidor B,
runner C, segurança nativa ou homologação Windows/DACL.

A fonte primária histórica continua ausente desta custódia documental. O alvo
relatado é exclusivamente:
`%LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml`.
O Windows do usuário não é acessível ao Codex nesta tarefa. Existência, regularidade,
tamanho, hash e metadados atuais desse XML não foram observados. Estado obrigatório:
**JUnit original = AGUARDANDO_IDENTIFICACAO_LOCAL**.

A transcrição secundária relata 2.842 casos, 2.816 PASS, 19 FAIL, sete SKIP e zero
ERROR. São números relatados, não contagens XML verificadas nesta H1. Nome, pasta,
metadados e totais compatíveis não comprovam originalidade ou versão executada.

## Preparação efetivamente realizada

- Lida a instrução H1 e o parecer independente C8, sem executar seus conteúdos.
- Reutilizado o protocolo C3 de recuperação como referência; o complemento H1
  trata apenas decisões ainda necessárias, sem recriar a custódia anterior.
- Revistas as matrizes C1 atualizada e C3: 19 vínculos provisórios, sem confirmação
  por primário e sem aceite humano. As sete fichas C3 continuam sem XML/ocorrências.
- Preparado um único bloco PowerShell 5.1 dentro do documento de comando. Está
  proposto, não executado e sem validação de runtime/compatibilidade nativa nesta H1.
- Documentados campos de sanitização futura, critérios de confronto 19/7, fontes
  contemporâneas faltantes e decisões separadas de autorização/custódia.
- Conferidos hashes de documentos consultados, do manifesto documental EXP-04
  448 e da entrega C8; nenhum XML foi aberto, coletado, parseado ou sanitizado.

## Procedimento proposto e alcance

O bloco resolve somente LOCALAPPDATA mais o sufixo fixo relatado, verifica versão
PowerShell/ambiente, caminho canônico de unidade local fixa, atributos do alvo e
ancestrais, reparse points e regularidade. Propõe SHA-256 sobre um stream somente
leitura e confronto de metadados antes/depois; não altera atributos ou políticas.
Erros e mudanças observáveis produzem impedimentos seguros, sem mensagens privadas.
Não busca outro arquivo, não abre para escrita e não persiste saída ou XML.

A saída compartilhável fica restrita a estado LOCALIZADO/NAO_LOCALIZADO, nome,
tamanho, SHA-256, modificação UTC, resultados das verificações e impedimento.
Criação UTC e instante da observação são apenas registros transitórios internos:
a lista de saída autorizada não os exporta. Registro privado durável será uma
etapa de custódia específica, ainda não autorizada nem criada.

O procedimento mede fingerprint atual e metadados observáveis, sem garantia
forense. Não autentica file ID/volume, hardlink, resolução física de todos os
aliases ou troca/restauração de ancestrais entre consultas. O hash atual não
retroage para autenticar a rodada histórica; identidade física e autenticidade
histórica ficam explicitamente não comprovadas, inclusive na saída nominal.

## Manifesto 448 e versão

O documento EXP-04 de 448 arquivos está presente e corresponde ao SHA-256
`19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb`,
50.698 bytes. Nesta H1 apenas sua identidade documental foi conferida, sem parsing
do manifesto ou verificação física dos 448 arquivos. Seu uso na rodada Windows
continua NAO_DEMONSTRADO. Não é o manifesto R1-FIX de 470 arquivos.

## Resultado documental e parada

Nove documentos preparados; não há resultados Windows novos, matrizes preenchidas,
cópia de XML, depósito de custódia, executável ou ZIP novo. Cópia, sanitização e
reconciliação dependem de decisões próprias, após identificação local e revisão.
Os 90 dias de retenção do Portão B não se estendem automaticamente a H1.

Preservados: Categoria A CONSOLIDADA_DOCUMENTALMENTE; runner NÃO_IMPLEMENTADO;
WIN01–WIN19/DACL NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE; cópia/sanitização
PENDENTE; C/D/E BLOQUEADOS; conversões reais BLOQUEADAS; prontidão para ensaios false.

Não houve PowerShell, pytest, preflight B, runner, parsing XML, sanitizador,
operação na máquina do usuário, Git, configuração, ACL/privilégio/conta/política,
conversão, limpeza, commit, push, merge ou publicação. Entregar e parar para revisão
independente; nenhuma próxima ação é autorizada automaticamente pelos documentos.
