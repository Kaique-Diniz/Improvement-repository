# WIN19-H1 — índice e proveniência da preparação

24/11/2026 — America/Sao_Paulo. Pasta nova e exclusiva de documentos:
`/workspace/work/WIN19-H1-PREPARACAO-JUNIT-20261124`.
É preparação externa ao Git/candidata, não área de custódia ou destino de XML.

## Nove documentos entregues

1. [RELATORIO_H1_PREPARACAO.md](RELATORIO_H1_PREPARACAO.md) — situação, alcance e parada.
2. [COMANDO_WINDOWS_SOMENTE_LEITURA.md](COMANDO_WINDOWS_SOMENTE_LEITURA.md) — único
   bloco PowerShell 5.1 proposto, não executado, com saída limitada e ressalvas.
3. [COMPLEMENTO_CUSTODIA_JUNIT.md](COMPLEMENTO_CUSTODIA_JUNIT.md) — complemento
   específico de decisões pendentes, reutilizando o protocolo C3.
4. [PLANO_SANITIZACAO_JUNIT.md](PLANO_SANITIZACAO_JUNIT.md) — classes de campos,
   preservação de ocorrências e proteção de dados; nenhum sanitizador implementado.
5. [CRITERIOS_RECONCILIACAO_19_E_7.md](CRITERIOS_RECONCILIACAO_19_E_7.md) — critérios
   futuros para fonte primária/versão e revisão humana, sem matrizes novas presumidas.
6. [FONTES_HISTORICAS_PENDENTES.md](FONTES_HISTORICAS_PENDENTES.md) — XML, log,
   comando, ambiente e vínculo do manifesto ainda faltantes.
7. [DECISOES_E_PORTOES_H1.md](DECISOES_E_PORTOES_H1.md) — decisões e estados preservados.
8. INDICE_ENTREGA.md — este registro de proveniência.
9. [MANIFESTO_SHA256_H1](MANIFESTO_SHA256_H1) — tamanho/hash dos oito documentos
   anteriores; exclui somente a si, evitando autorreferência.

## Instrução e parecer recebidos

Instrução H1, Texto colado.txt: 9.451 bytes, SHA-256
`abc506b182b99e939bbf3f7b1191ab59dce6ab5839099e9c4bd2d443ed73d53f`.
É a referência principal de execução. Parecer obrigatório
PARECER_INDEPENDENTE_WIN19_C8_2026-11-24.md: 7.404 bytes, SHA-256
`8dfbe8d08e8fbed0b6d417a1e566cb00df767f4089aee730533d29ee9a507e1d`.
O parecer aceita e encerra a C8 documentalmente, sem conceder operação ou custódia.
Não foram criadas cópias desses anexos na pasta H1.

## Fontes anteriores efetivamente consultadas

| Fonte documental consultada | Bytes | SHA-256 conferido |
| --- | --- | --- |
| WIN19-C3-PREPARACAO-20261118/PROTOCOLO_RECUPERACAO_JUNIT_WINDOWS.md | 9819 | 6cff82b749d207db8527c64e8240385a5bf105704391361b016a3b3c34fa5305 |
| WIN19-C3-PREPARACAO-20261118/MATRIZ_C3_CONFRONTO_HISTORICO.csv | 16873 | 2d81945210976678f726904e15c201896c04ee45c3b2a6d6e2984b5a98e9df57 |
| WIN19-C3-PREPARACAO-20261118/MATRIZ_C3_SKIPS_A_CONFERIR.csv | 1198 | 85bf279549c195eb0833032e207578a69f1f1fe203e1478c776bd0c115d11df9 |
| WIN19-C1-C2-COMPLEMENTACAO-20261118/MATRIZ_C1_ATUALIZADA.csv | 15079 | f593bfd674a4cc0c0f9ab7571749cb9a8ee1eabbcba6b2383dad8eba07d78f4f |
| WIN19-C1-C2-DOCUMENTAL-20261118/RELATORIO_C1_FONTES_E_LACUNAS.md | 9441 | 503ae4c8f78ec3dcc36354321188c550e09b0e73fa9fb50b04a60199ff48fb09 |
| WIN19-C1-C2-DOCUMENTAL-20261118/fontes_relato/INDICE_RECUPERACAO_USUARIO_20261118.md | 4331 | 64cb7c5f3092df0b8c584ce5dc56fbbc98bfda3bda59c12a860ae9cbcdd55d7d |
| WIN19-C1-C2-DOCUMENTAL-20261118/SKIPS_RELATADOS_TRANSCRICAO.csv | 868 | 9d6474b581ac6326fa95accf224dda39f8ea36868c166b7ba546538aae1d46f3 |
| EXP-04-entrega/VERSAO_EXP04_SHA256.json | 50698 | 19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb |

A leitura das matrizes C1/C3 confirmou seu caráter de propostas sem primário e
revisão pendente; a leitura das sete fichas confirmou que não são nodeids observados.
O protocolo C3 foi reutilizado sem substituição. Os registros de relato continuam
fontes secundárias, sem promover as contagens a observações da H1.

Manifesto documental C8, novamente conferido com seus sete arquivos, SHA-256
`5b78a76589bd89e37dd0028fb0eebcaa225c0bfc047903fb6fad1eff46021668`.
Sua identidade e as demais fontes da tabela permaneceram iguais antes/depois da
redação. Nenhum desses hashes é hash do JUnit original, cujo valor segue SEM_FONTE.
O SHA do manifesto 448 não comprova sua adoção na execução nem se confunde com 470.

## Integridade e limites do procedimento proposto

Documento do comando preparado nesta H1: SHA-256
`e39461ec4bac7aa7325eee427a38ef1c6945e09631844aae3edf1b981a58eb1a`.
Bloco PowerShell literal dentro desse Markdown, incluindo LF final: SHA-256
`99954472c83cd893f89e907ae47249132d7faf65eb064fa7faf3ca0955002109`.
O hash do bloco foi calculado por extração textual, sem parsing/compilação ou
execução PowerShell. São identidades da proposta para revisão, não resultados de
compatibilidade nativa nem prova de segurança. O manifesto H1 inclui o hash do
Markdown inteiro e dos outros documentos efetivamente materializados.

A preparação usou leitura de documentos, cálculo de SHA-256, edição de Markdown e
redação local com utilitários de texto/arquivo e Python -I -B/stdlib pathlib/hashlib.
Nenhum programa anterior, bloco PowerShell, módulo do produto, parser XML ou código
do traceback foi executado. Não houve programa auxiliar .ps1/.py entregue.

## Preservação e parada

A pasta contém somente estes nove documentos, sem XML, ZIP, executáveis, novas
matrizes de resultados, fixtures ou depósito privado. As fontes C1/C3/C8 e o
manifesto 448 foram lidos sem modificação; C5/C6/C6-R1/C7/C7-R1, R1-FIX e custódias
anteriores não receberam escrita ou execução. Nenhuma operação na máquina Windows
do usuário foi realizada ou presumida.

Categoria A CONSOLIDADA_DOCUMENTALMENTE; runner NÃO_IMPLEMENTADO;
WIN/DACL NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE; JUnit
AGUARDANDO_IDENTIFICACAO_LOCAL; cópia/sanitização PENDENTE; C/D/E e conversões
BLOQUEADOS; prontidão false. Sem Git, publicação, coleta, limpeza ou modificação de
ACL/privilégio/conta/política. Parar para revisão independente dos nove documentos.
