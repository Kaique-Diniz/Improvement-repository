# H1 — fontes históricas da rodada EXP-04 ainda necessárias

24/11/2026. Lista documental de identificação futura, sem busca na máquina do
usuário, coleta, parsing, reconstrução de comando ou execução de suíte.

## Fontes e lacunas por dimensão

| Fonte/informação | Estado do primário nesta H1 | Relato/limite conhecido | Próxima decisão possível |
|---|---|---|---|
| completa-utf8.xml | AGUARDANDO_IDENTIFICACAO_LOCAL; bytes/hash/metadados atuais SEM_FONTE | Caminho relativo a LOCALAPPDATA informado; não observado pelo Codex | Revisar procedimento e permitir ao usuário a identificação local somente leitura |
| Log/stdout/stderr original | SEM_FONTE; nomes originais não identificados | Há registro de transcrição secundária, não log persistido autenticado | Identificar existência/proveniência sob autorização futura, sem busca ampla nesta etapa |
| Comando/argv Pytest literal | SEM_FONTE | Estrutura lembrada não autentica linha de shell, aspas ou parâmetros completos | Examinar fonte contemporânea/histórico autorizado privadamente, sem executar comando |
| Parâmetros UTF-8 | SEM_FONTE primária | PYTHONUTF8=1/Python 3.12 constam de relato secundário | Relacionar registros contemporâneos, sem reconfigurar ambiente |
| Python/Pytest/plugins/dependências | SEM_FONTE primária da rodada | Não usar versões atuais do executor ou Windows como versão histórica | Fonte da mesma execução e identificação de plugins/flags relevantes |
| Ambiente Windows da execução | SEM_FONTE primária detalhada | Local/horário na pasta e relato Windows não são medição de versão/fuso/filesystem | Contexto contemporâneo autorizado e sanitizado |
| Commit e árvore da época | SEM_FONTE de correspondência física completa | Baseline relatada não comprova alterações, untracked ou bytes executados | Snapshot/registro do momento, sem checkout/testes para recriar o passado |
| Manifesto efetivamente usado | SEM_FONTE de adoção na execução | Manifesto 448 está identificado como documento, uso NAO_DEMONSTRADO | Fonte que associe seus bytes/hash àquela rodada |
| Verificação contemporânea dos 448 arquivos | SEM_FONTE primária | Texto afirma 448 hashes, sem identificar o manifesto efetivamente usado | Relatório da época com identidade, contexto e vínculo à execução |
| Resultado/retorno/duração | SEM_FONTE primária autenticada | Totais 2842/2816/19/7/0 são da transcrição relatada | Confrontar primários sem ajustar contagem ou fundir rodadas |

SEM_FONTE indica indisponibilidade primária para esta análise, não declaração de
que o arquivo não existe no Windows. Se a fonte não tiver sido preservada, registrar
essa ausência após constatação autorizada; não fabricar substituto ou preencher
com o estado atual do ambiente.

## Manifesto documental disponível

`EXP-04-entrega/VERSAO_EXP04_SHA256.json`: 50.698 bytes, SHA-256
`19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb`.
Refere-se à EXP-04 de 448 arquivos, baseline documental
`770d062d29c4361d6932592883df9339bb4089bc` conforme as fontes anteriores.
A H1 conferiu apenas identidade do documento; não parseou seu conteúdo, verificou
448 arquivos físicos ou vinculou seu uso ao run. Não confundir com R1-FIX de 470.

## Fonte secundária já existente

O registro local INDICE_RECUPERACAO_USUARIO_20261118.md descreve a transcrição de
console e os 19 identificadores/quatro grupos de skips relatados. É documento local
novo daquela tarefa, não os bytes de Texto colado(6).txt ou do derivado sanitizado
referidos pelo usuário. Os hashes relatados desses brutos/derivados não autenticam
o registro local nem devem substituí-lo. A H1 não recuperou esses bytes da biblioteca.

O caminho-alvo e os números compatíveis não demonstram comando, código, manifesto,
continuidade de custódia ou data de execução. A data do nome da pasta, criação,
modificação do arquivo, timestamp XML e instante de observação são coisas distintas.
Qualquer divergência ou lacuna deve permanecer explícita na futura reconciliação.

Nenhuma fonte adicional foi solicitada como bruto privado nem coletada nesta etapa.
Após a revisão, somente o resumo de identificação sanitizado poderá subsidiar uma
nova decisão; cópia, sanitização e confronto permanecem autorizações separadas.
