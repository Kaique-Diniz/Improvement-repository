# H1 — critérios de confronto futuro dos 19 vínculos e sete skips

24/11/2026. **Não executado.** Reutilizar as matrizes C1/C3 existentes, sem criar
nova matriz de resultados presumidos. Nenhum estado histórico é alterado na H1.

## Revisão documental das bases

- MATRIZ_C1_ATUALIZADA.csv: 19 propostas, PROVISORIO_SEM_FONTE; fonte primária
  NAO_RECEBIDA; confirmação por primário NAO; decisão do revisor PENDENTE.
- MATRIZ_C3_CONFRONTO_HISTORICO.csv: preserva as 19 propostas e acrescenta suite/
  ordinal, relação original→WIN e aceite humano ainda sem fonte; não presume 1:1.
- MATRIZ_C3_SKIPS_A_CONFERIR.csv: sete fichas C3-SKIP-01..07 explicitamente virgens,
  não sete nodeids recuperados. XML/classname/name/parâmetro/motivo/fase seguem sem fonte.

Coincidências literais entre o índice secundário e nomes propostos estão em
colunas separadas e não confirmam os vínculos. Os controles prospectivos e seus
21 subcasos não são uma transcrição da ocorrência histórica de 19 falhas.

## Precondições de confronto

Somente após XML identificado/autenticado, custódia e compartilhamento autorizados,
versão/contexto examinados e eventual sanitização revisada. Não aplicar parser
nesta H1. A leitura futura deverá preservar a hierarquia, duplicatas, retries e
fases quando presentes; contadores declarados e enumeração de ocorrências serão
campos separados, sem dupla contagem de pai/filho ou cópias da mesma rodada.

## Registro necessário por vínculo, a preencher somente com fonte

| Informação exigida | Critério de preenchimento futuro |
|---|---|
| Referência à fonte | Hash/tamanho da peça autenticada e vínculo à cópia/derivado autorizado |
| Ocorrência original | Hierarquia de suites e ordinal/localização inequívoca; nomes sozinhos podem repetir |
| Identificador e parâmetro | Literal original quando disponível; preservar parametrização sem reconstrução por semelhança |
| Nodeid | Usar explícito se existir; se XML só fornece classname/name, marcar nodeid não fornecido e separar qualquer derivação proposta |
| Classificação | failure/error/skipped e fase efetivamente documentada; não inferir API ou WinError pelo nome |
| Versão dos testes | Referência à fonte exata da época e estado da árvore/manifesto; HEAD atual não basta |
| Controle WIN proposto | Hipótese de associação separada do identificador original; zero, uma ou várias correspondências podem existir |
| Evidência favorável/impeditiva | Conteúdo/código/contrato e contexto que justificam ou impedem associação; privacidade preservada |
| Revisão humana | Revisor/data/versão/motivo em custódia apropriada; aceite não inferido pelo Codex |

Não converter automaticamente classname com pontos em caminho tests/... nem
reconstruir parametrização ausente e chamar isso de nodeid original. Qualquer
conversão documental futura precisa de origem rastreável e confronto com a versão.
Uma falha pode afetar vários controles, um controle pode depender de várias
ocorrências, ou não haver associação. Não forçar bijeção 19→19.

## Estados documentais e aprovação humana separada

| Estado futuro possível | Uso restrito |
|---|---|
| PROVISORIO_SEM_FONTE | Sem primário autenticado/vínculo demonstrado; estado de todos os 19 nesta H1 |
| OBSERVADO_COM_FONTE | Uma ocorrência efetivamente observada em fonte identificada; não significa vínculo confirmado ou controle aprovado |
| AMBIGUO | Múltiplas correspondências, fase/nodeid/contexto insuficientes ou associação não individualizável |
| DIVERGENTE | Diferença efetivamente confrontada de identificador, parâmetro, resultado, versão ou contagem |

O estado proposto deve registrar sua justificação e fonte, preservando a proposta
anterior. Aprovação/aceite final permanece decisão humana explícita. Nenhum desses
estados equivale a PASS funcional, validação nativa ou homologação DACL.

## Sete fichas de skip

Cada ocorrência deverá receber sua própria suite/ordinal, classname/name/parâmetro,
motivo literal, fase se fornecida (caso contrário NAO_INFORMADA), hash da fonte,
referência sanitizada, revisão e conclusão limitada. Não distribuir os quatro casos
agrupados da reconstrução entre quatro nodeids inventados. Se a fonte mostrar
quantidade diferente, preservar a divergência, sem apagar ou acrescentar ocorrências.

O índice secundário traz quatro registros agrupados que somam sete: quatro de
reconstrução/symlink, um rules/test_authority:128, um rules/test_authority:168 e um
ACL/symlink. Os dois POSIX de rules/test_authority não são automaticamente as falhas
private_simulation/permissao_fonte e permissao_raiz propostas para WIN-18/19.
O motivo ACL/symlink não fornece por si só um código Win32. Nenhum grupo preenche
ficha C3 ou demonstra controle nativo executado. SKIP continua sem aprovação.

## Totais, origem e conflitos

A referência 2842/2816/19/7/0 é relato secundário. Futuros totais incompatíveis,
suites múltiplas, retries, erro de setup/teardown ou presença simultânea de elementos
adversos precisam de decisão documentada, não correção do XML. Distinguir ausência
de failure num testcase de prova de que o cenário de segurança foi exercitado.
Não transferir resultados de Linux, cleanup, B, BPQ-04/38 falhas ou outra rodada
EXP-04. Conferir código/contexto/manifesto antes de propor associação histórica.

A H1 termina na especificação desses critérios; nenhum dos 19 vínculos ou das
sete fichas foi preenchido, confirmado ou promovido.
