# H1 — plano de sanitização futura, sem implementação

24/11/2026. Complementa as seções 5–7 do protocolo C3. **Não implementado e não
executado.** Nenhum XML foi recebido, aberto ou parseado nesta tarefa. Os campos
abaixo são classes de tratamento para revisão, não diagnóstico do conteúdo real.

## Precondições

Exigir original identificado, cópia fiel e custódia autorizadas, fonte/hash próprio,
finalidade de compartilhamento, campos aprovados e revisor. Trabalhar futuramente
somente na cópia autorizada. Bruto e cópia fiel permanecem privados e imutáveis;
o derivado sanitizado terá bytes/hash próprios, relacionados à origem em registro
privado. Não assumir que sanitização ou publicação estejam autorizadas pela H1.

## Classificação documental dos campos

| Campo ou conteúdo potencial | Compartilhamento eventual | Preservação para confronto |
|---|---|---|
| Hierarquia testsuites/testsuite e ordinal de ocorrência | Estrutura compartilhável após revisão de rótulos | Conservar ordem, relações e identidade local de cada ocorrência; não somar pais/filhos |
| Classname, name, nodeid explícito e parametrização sem dados privados | Literais apenas se autorizados e revisados | Manter grafia e parâmetro; não corrigir para encaixar em WIN |
| Identificadores/parâmetros com pessoas, paths ou segredos | Pseudonimização estável, se segura e autorizada | Original literal e mapa 1:1 ficam privados, ligados ao hash/ordinal; derivação declarada |
| Elementos failure, error e skipped e multiplicidade | Preservar presença/classificação; textos revisados | Nunca remover resultado adverso, trocar categoria ou deduplicar para alterar contagem |
| Motivo individual de skip | Literal somente se seguro; se sensível, derivado marcado/restrito | Motivo integral permanece privado e acessível ao revisor autorizado; não inventar motivo para cobrir ocultação |
| Fase, timestamp e duração quando presentes | Revisão de sensibilidade e fuso; não inventar ausentes | Distinguir atributo XML, data do filesystem e instante de observação |
| Contadores declarados por suíte | Compartilháveis como declarações com referência ao nível | Preservar divergência frente à enumeração futura; não ajustar contagem à transcrição |
| Versão executada e referência ao relatório original | Aliases/metadados autorizados e proveniência | Manter o vínculo ao documento real; sem transformar fonte secundária em primária |
| Caminhos de usuário, conta, hostname, SID/SDDL e localização privada | Privados ou pseudônimos aprovados, sem reversão pública | Mapeamento e localização exata sob custódia privada |
| Tracebacks, system-out/system-err, properties e mensagens livres | Revisão campo a campo; potencialmente privados | Preservar bruto; compartilhar só o necessário e sanitizado sem executar conteúdo |
| CPF/CNPJ, contatos, valores financeiros privados, documentos de moradores | Exclusivamente privados; não publicar | Retenção somente conforme decisão legítima; não importar no Git |
| Credenciais, tokens, cookies, URLs autenticadas, locals e payloads | Nunca compartilhar nem publicar | Tratar sob custódia/revisão privada; hashes de segredos não são substituto público seguro |

Nenhum campo é automaticamente público por ter regex válida ou parecer nome de
teste. Parâmetros e mensagens podem conter dados sensíveis. Se não for possível
compartilhar um literal com segurança, marcar a restrição/insuficiência no derivado
e manter a revisão privada; não apresentar pseudônimo como identificador original.

## Regras para futura ferramenta, ainda não autorizada

A implementação e sua validação deverão ser aprovadas separadamente. XML será
tratado como dado: proibir DTD, entidades externas, resolução por rede, XInclude,
referências a arquivos e execução de scripts/anexos ou texto de traceback. Não
executar código extraído do XML para descobrir significado. Definir os limites de
leitura/recursos sob revisão própria, sem adotar orçamento inventado nesta H1.

Conservar possibilidade de reconciliar cada ocorrência pelo hash da fonte,
hierarquia/ordinal, identidade/parametrização original e registro privado de
transformação. Mudança de encoding/formatação do derivado não é correção da fonte;
nenhum hash do original pode ser atribuído ao derivado. Não apagar erros/skips,
simplificar razões adversas para produzir aprovação ou fundir resultados de rodadas.

A revisão humana deverá examinar também dados de texto livre e arquivos embutidos,
não apenas regex. Registrar categorias/posições das alterações, ferramenta/regra,
responsável, autorização e data/fuso. A H1 prepara esses critérios, sem escrever
sanitizador, ler XML ou gerar cópia compartilhável. Parar para decisão posterior.
