# H1 — complemento de custódia histórica, ainda não criada

24/11/2026. Referência reutilizada, sem duplicação do protocolo:
`WIN19-C3-PREPARACAO-20261118/PROTOCOLO_RECUPERACAO_JUNIT_WINDOWS.md`.
SHA-256 `6cff82b749d207db8527c64e8240385a5bf105704391361b016a3b3c34fa5305`.
Mantêm-se suas seções de identidade, original, cópia fiel, sanitização e confronto.
Este complemento delimita somente decisões que continuam pendentes.

## Decisões antes de qualquer cópia futura

| Decisão | Situação atual | Registro/condição necessária |
|---|---|---|
| Custodiante | PENDENTE | Identidade concreta e responsabilidade mantidas em registro privado; não coletadas aqui |
| Autorização do arquivo específico | PENDENTE | Escopo nominal do XML, finalidade, ações permitidas, responsável e validade; sem autorização por mera presença de caminho |
| Destino local novo e exclusivo | PENDENTE | Nome/volume/local fora de Git, candidatas e documentos de clientes; criação exclusiva após decisão, sem sobrescrita |
| Preservação do original | OBRIGATÓRIA NA FUTURA DECISÃO | Não renomear, mover, normalizar, regravar ou alterar atributos/permissões do original |
| Proveniência e horários | PENDENTE | Caminho completo privado, nome original, bytes/hash, criação/modificação e fuso, instante UTC de observação/cópia, ferramenta e custodiante |
| Origem versus cópia | PENDENTE | Hash/tamanho dos dois, consistência de leitura, igualdade de bytes quando autorizada; divergência bloqueia uso |
| Acesso e dados privados | PENDENTE | Pessoas autorizadas, local já legitimamente acessível, restrições de transferência e revisão; não presumir proteção DACL do aplicativo |
| Retenção H1 | SEM_PRAZO_APROVADO | Prazo e responsável pela revisão precisam de decisão própria; não herdar os 90 dias do Portão B |
| Descarte e exceções de preservação | PENDENTE | Revisão humana prévia, autorização específica e tratamento de obrigação de retenção; nada apagado automaticamente |
| Compartilhamento/sanitização | PENDENTE | Campos, finalidade, revisor e autorização separados; bruto e mapa reversível permanecem privados |

A saída de identificação pode subsidiar essas decisões, mas não as concede. A
pasta documental H1 não é depósito de XML; nenhum destino privado foi criado.
Não está autorizado enviar o bruto no chat ou publicá-lo em branch de transferência.

## Condições de aceitação de uma futura cópia

Somente depois de autorização e destino exclusivos: identificar qual objeto será
copiado, registrar origem/derivado e histórico das observações; preservar original;
confirmar identidade antes/depois; não tratar hash do derivado como hash do original.
Hash/tamanho atuais iguais não comprovam uso no run ou imutabilidade pretérita.
Se a autenticação física exigir mais do que os metadados H1, a extensão deverá ser
especificamente revisada, não improvisada com privilégios ou módulos experimentais.

## Impedimentos e encaminhamento

- Ausente ou caminho não localizado: registrar fonte não obtida e impedimento;
  não criar substituto, executar pytest, varrer diretórios ou renomear outro XML.
- Inacessível: registrar impedimento; não alterar owner, ACL, privilégio ou política.
- Reparse/redirecionamento/identidade ambígua: não seguir outra origem e não copiar.
- Mutável ou divergente: preservar observações já obtidas privadamente; marcar
  PENDENTE_FONTE_MUTAVEL/impedimento, sem escolher a versão conveniente ou repetir
  infinitamente até coincidir com o esperado.
- Fonte ou log inexistente: manter SEM_FONTE por campo, sem reconstrução retrospectiva.

Nenhuma custódia anterior do Portão B é reaberta. Cópia, retenção, sanitização,
confronto e eventual descarte ficam para autorizações separadas. Parada nesta
preparação; não há operação de recuperação ou criação de custódia nesta H1.
