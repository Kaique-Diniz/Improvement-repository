# REC-01 — Execução privada Windows 10/11, PowerShell 5.1

Não modificar D2. Não instalar o utilitário dentro da candidata. Executar como
usuário normal, sem alterar política PowerShell, DACL ou privilégios. Se a
política local impedir `.ps1`, usar a chamada Python direta abaixo, sem alterar
a política. A ferramenta exige Python **3.12** e usa as dependências já
existentes do ambiente D2; não instala pacotes automaticamente.

## 1. Separar áreas e conferir a ferramenta

Obter a entrega REC por meio aprovado; conferir `SHA256SUMS.txt` e o hash do
pacote recebido antes de executar. Preservar a cópia auditada da ferramenta.
As fontes reais e os XLSX não devem ser enviados ao Cloud nem ficar em Git.

Definir as áreas antes de extrair o pacote ou criar a worktree REC:

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'REC01-Privado'
$Fontes = Join-Path $Root 'Fontes'
$Resultados = Join-Path $Root 'Resultados'
$Pacote = Join-Path $Root 'Pacote'
$Ferramenta = Join-Path $Pacote 'payload\tools\reconciliacao_privada'
$Entrega = Join-Path $Root 'REC01-Worktree'
$Manifesto = Join-Path $Root 'manifesto-privado.json'
# Ajustar estes dois caminhos para os locais JA EXISTENTES:
$Candidata = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria2\WIN-01-D2'
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe'
# Checkout Git existente, usado apenas para criar a nova worktree REC:
$Repo = Join-Path $HOME 'Conversor-MVP-BPQ04'

# Criar somente se ausentes, sem sobrescrever documentos ou evidencias.
foreach ($Dir in @($Root, $Fontes, $Resultados)) {
    if (-not (Test-Path -LiteralPath $Dir)) {
        New-Item -ItemType Directory -Path $Dir | Out-Null
    }
}
& $Python --version
if ($LASTEXITCODE -ne 0) { throw 'PYTHON_INDISPONIVEL' }
& $Python -m pip check
if ($LASTEXITCODE -ne 0) { throw 'DEPENDENCIAS_INCONSISTENTES' }
```

O resultado de `--version` deve ser 3.12.x. A ferramenta verifica a versão, os
454 hashes, fontes, pais dos caminhos e área fora do Git; não depende de Git
stderr no PowerShell. `pip check` não instala nem atualiza dependências.

O ZIP contém `payload/`, evidências sintéticas e `MANIFESTO_ENTREGA.json`.
Extrair em `$Pacote`, um diretório novo, e conferir o SHA-256/CRC recebido.
Reconstruir o payload sobre **nova** worktree do baseline:

```powershell
if (Test-Path -LiteralPath $Entrega) { throw 'ENTREGA_PREEXISTENTE_PRESERVAR' }
& git -C $Repo worktree add --detach $Entrega 770d062d29c4361d6932592883df9339bb4089bc
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_REC01_NAO_CRIADA' }
$ReconstrutorRec = Join-Path $Pacote 'payload\tools\reconciliacao_privada\reconstruir_entrega.py'
& $Python -B $ReconstrutorRec --pacote $Pacote --destino $Entrega
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_REC01_BLOQUEADA' }
```

O reconstrutor confere o baseline, a raiz Git, estado limpo, todos os hashes do
pacote e conflitos antes de copiar somente arquivos REC novos. Não sobrepõe
arquivos existentes. Se houver interrupção parcial, preservar a pasta e
reconstruir em outro destino novo. O baseline fornece as fixtures sintéticas
já versionadas; o payload fornece testes/ferramentas/documentação REC.
Não fazer checkout ou instalar dentro da D2.

Escolher uma área privada já protegida para o usuário. Confirmar restrições
de acesso com a administração local, se necessário. Ler uma ACL ou usar
LOCALAPPDATA não comprova a política efetiva nem segurança geral NTFS.
Não iniciar auditoria real em pasta compartilhada, sincronizada ou com
escritores concorrentes. Nenhum dado real deve ser usado nos testes sintéticos.

## 2. Preparar manifesto e fontes

Copiar localmente as fontes originais e os 12 relatórios para subpastas de
`$Fontes`, preservando seus bytes. Não renomear A/B com base apenas em tamanho;
conferir o modo da conversão e seus registros privados. A ferramenta não pode
distinguir rótulos de modos se os conteúdos forem equivalentes sem extras.

```powershell
if (Test-Path -LiteralPath $Manifesto) { throw 'MANIFESTO_EXISTENTE_PRESERVAR' }
Copy-Item -LiteralPath (Join-Path $Ferramenta 'manifesto.exemplo.json') -Destination $Manifesto
```

Editar a cópia privada com editor local. Não colar nomes/documentos na conversa.
Consultar `REC_01.md` para os campos. Usar a raiz absoluta de `$Fontes` e caminhos
relativos com `/`. Fornecer os seis campos de endereço **da conversão**, por
condomínio, como strings; não usar residência pessoal ou herdar outro perfil.
Cadastro opcional ausente: `null`. Não substituir ausência por arquivo vazio.

Para preencher o SHA-256, ler localmente o hash e registrá-lo somente no
manifesto privado. Não usar hash da saída como substituto da origem documental:

```powershell
# Exemplo de obtencao local, sem imprimir o caminho ou conteudo:
$ArquivoLocal = Join-Path $Fontes 'SUBPASTA/ARQUIVO.xlsx'
$HashLocal = (Get-FileHash -LiteralPath $ArquivoLocal -Algorithm SHA256).Hash.ToLowerInvariant()
# Transcrever $HashLocal para o campo sha256 correspondente do manifesto privado.
```

`exemplo` deve mudar para `false`, `area_privada_confirmada` para `true` e cada
endereço deve ter `confirmado: true`. Remover todos os placeholders e hashes
zerados. Os checkpoints do exemplo são externos e removíveis. Não alteram
as expectativas calculadas da fonte.

`regressao` deve continuar `null` se não houver referência histórica externa
confiável. Isso deixa **somente esse eixo** sem evidência e impede aprovação
global completa; o resultado documental é informado separadamente. Se houver
referência, identificar seus hashes A/B e sua origem privada independentemente
das saídas em análise. Não copiar simplesmente seus hashes para forçar aprovação.

## 3. Testes sintéticos e sondas nativas

Executar a partir da raiz da entrega REC, onde ficam `tools/` e `tests/`.
As fixtures de `tests/` pertencem ao baseline e à entrega auditada; nenhuma
contém documento real. O pacote de distribuição informa como reconstruí-las
a partir do baseline, sem instalação dentro da D2.

Definir `$Entrega` como a raiz da worktree REC reconstruída, separada da D2 e dos
dados reais. O comando abaixo aceita espaços/acentos e preserva PYTHONPATH:

```powershell
$PythonPathAnterior = $env:PYTHONPATH
try {
    $env:PYTHONPATH = $Entrega + ';' + (Join-Path $Candidata 'src')
    Push-Location $Entrega
    try {
        & $Python -B -m pytest -q tools/reconciliacao_privada/test_rec01.py `
            tools/reconciliacao_privada/test_windows_nativo.py -o pythonpath= --tb=short
        if ($LASTEXITCODE -ne 0) { throw 'REGRESSOES_REC01_REPROVADAS' }
    }
    finally { Pop-Location }
}
finally { $env:PYTHONPATH = $PythonPathAnterior }
```

As sondas nativas verificam parser PowerShell 5.1 e rejeição de junction externa.
Falha na criação de junction fica como skip com controle não validado. Não
habilitar privilégios para tornar testes verdes. A suíte deve registrar os
skips e não tratá-los como aprovação de segurança.

## 4. Executar a reconciliação privada

```powershell
& (Join-Path $Ferramenta 'executar.ps1') -Python $Python -Candidata $Candidata `
    -Manifesto $Manifesto -SaidaPai $Resultados
```

Alternativa Python direta, sem depender da execução de `.ps1`:

```powershell
$Execucao = 'REC01-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N')
& $Python -B (Join-Path $Ferramenta 'auditar.py') --manifesto $Manifesto `
    --candidata $Candidata --saida-pai $Resultados --execucao $Execucao
$Codigo = $LASTEXITCODE
if ($Codigo -ne 0) { throw 'REC01_NAO_APROVADA_CONFERIR_RELATORIOS_LOCAIS' }
```

Não executar com `-X utf8` como requisito: leituras REC são explicitamente
UTF-8/binárias. A saída contém exclusivamente estado agregado, quantidade de
perfis e códigos seguros. Não imprime caminho de fontes, documentos, pessoas,
endereços ou traceback. Status 0 somente nos dois estados aprovados do escopo;
2 para divergência, falta de evidência ou erro. A decisão de aceite é humana.

## 5. Conferir antes de compartilhar

Na pasta nova da rodada, abrir os cinco arquivos de `compartilhavel/`. Confirmar
estado de cada eixo, integridade **antes e depois**, perfis completos e
`privacidade_inspecionada: true`. Ausência de relatório final, erro, interrupção,
skips ou pendência não significam aprovação. Não somar execuções diferentes.

Revisar as divergências com os documentos em `privado/REC01_detalhes.json`.
Os casos BPQ-04 individuais permanecem exclusivamente nessa área privada.
Não enviar esse arquivo, o manifesto, fontes, XLSX ou a pasta inteira da rodada.
Compartilhar exclusivamente os cinco agregados após revisão visual adicional.

O roteiro não instala nada, não chama conversão, não altera DACL, não exige
administrador e não escreve na D2. Integridade 454/454 é reavaliada ao finalizar.
Segurança geral Windows, DACL efetiva e homologação operacional continuam fora
do aceite da REC.
