# REC-01 — Reconciliação documental privada

Utilitário externo em `tools/reconciliacao_privada/`. Entrega de preparação e
testes sintéticos, sem homologação dos seis condomínios. Não executa conversão,
não escreve nas fontes ou XLSX e não altera a candidata D2.

## Base efetivamente encontrada

Worktree REC isolada: `/workspace/work/rec-01`, detached em
`770d062d29c4361d6932592883df9339bb4089bc`. A candidata local D2 está disponível
em `/workspace/work/win-01-d-auditoria2`; o manifesto de 454 arquivos foi
conferido antes da implementação. O operador Windows ainda precisa conferir
seus próprios 454 arquivos: HEAD sozinho não é prova da versão.

O manifesto `CANDIDATA_D2_SHA256.json` fixa os 454 hashes auditados. Em relação
ao baseline, os únicos arquivos `src/` diferentes nessa candidata são
`adapters/windows_acl_evidence.py` (API diagnóstica Kernel32) e `web/app.py`
(duas leituras UTF-8). Leitores, contratos, políticas, perfis, motor e exportador
usados pela REC são iguais ao baseline. A ferramenta carrega **o `src/` da D2
verificada**, não uma instalação editável incidental. Não incorpora essas
alterações ao checkout REC. A integridade de D2 é conferida antes/depois.

Nenhuma fonte privada nem os 12 XLSX reais foram recebidos nesta tarefa. As
contagens Windows e os checkpoints são evidências fornecidas pelo usuário,
não execuções desta entrega. A segurança Windows continua não homologada.

## Contratos examinados e decisões

Foram examinados `INT_02.md` (inclusive reconciliação histórica),
`BPQ_04_IDENTIDADE_CADASTRAL.md`, `PASSAREDO.md`, `FOREST_HILL.md`,
`PARQUE_SANTA_MONICA.md`, `VERO_ENCANTO.md`, `ITAJUBA.md`,
`tests/homologacao/runner.py`, `laboratorio/comparison.py`, `web/service.py`,
`web/perfis.json`, `export/contract.py`, `export/identifiers.py`,
`export/xlsx.py`, leitores e associações das seis famílias.

| Eixo | Fonte de expectativa | Limite de independência |
| --- | --- | --- |
| Financeiro documental | Boletos extraídos das fontes; cálculo REC de dias, Decimal e multiconjuntos | Compartilha leitores auditados; um erro comum de extração exige conferência visual da fonte |
| Identidade e origem | Estrutura, reconhecimento por conteúdo e hashes homologados do papel/perfil | Hash do manifesto privado isolado não comprova identidade; fonte nova sem hash no catálogo gera evidência insuficiente |
| Cadastro A1/B1 | Políticas existentes, aplicadas aos originais; comparação integral das células | Não é reimplementação independente da política; prova concordância com o contrato auditado |
| Apresentação | Codificação documental existente e rótulos por perfil; projeção REC das 30 células | Codificadores e algumas funções puras de rótulo são compartilhados |
| A/B | Multiconjuntos das 30 células financeiras e extras B justificados | Exportações equivalentes sem extras não permitem distinguir os rótulos A/B por conteúdo |
| Regressão histórica | Hashes de referências externas declaradas pelo operador | Origem independente dessas referências precisa de revisão humana; copiar o hash da própria saída não produz evidência histórica |

Não usa `analisar`, o motor de regras, `materializar` ou o escritor como fonte
de expectativa. Um teste adicional compara projeção REC com saídas sintéticas
do MVP; é explicitamente uma regressão, não a prova documental principal.
O comparador histórico existente compara saídas, e seu dicionário por
identificador pode perder ocorrências: não é utilizado como conciliador
financeiro desta rodada. A REC usa `Counter`, sem deduplicação.

## Regras da rodada

Referência fixa `2026-11-09`. Passaredo e Santa Mônica: atraso **> 60** dias;
demais quatro: **> 30**. Nenhum filtro judicial, de acordo ou exclusão nova.
Itajubá anterior a `2023-12-01`, valor não positivo, fonte crítica ou identidade
insuficiente geram revisão/evidência insuficiente, nunca aprovação por omissão.
A ferramenta recusa configuração financeira da candidata que não corresponda
a esses prazos e às exclusões vazias documentadas.

Cada ocorrência mantém identificador, bloco/unidade e origens no relatório
privado. Contagens financeiras são multiconjuntos de unidade/vencimento/valor;
a conformidade integral também compara as 30 células, inclusive parcela,
descrição, nome financeiro, documento e contatos. Diferenças são categorias
potencialmente sobrepostas, não somáveis como número de dívidas distintas.

Grupos com mesma unidade/data/valor são conciliados em multiplicidade, com
ressalva `PAREAMENTO_INDIVIDUAL_NAO_DEMONSTRADO`. Parcela de apresentação não é
um identificador documental inequívoco. Comparações por célula só recebem
localização de pareamento quando a chave de apresentação é única; divergências
restantes permanecem explícitas, sem tentar associar pessoas por proximidade.

Cadastro é opcional. Sem cadastro, a saída precisa manter a retenção esperada;
isso pode produzir `APROVADO_COM_RESSALVAS`, nunca preenchimento por template.
As políticas A1/B1 permanecem intactas, inclusive BPQ-04. Os casos particulares
de titular individual e documento exclusivo do pagador só podem ser concluídos
com a ficha privada; o relatório privado contém referências e projeções para
essa revisão. Os testes reutilizam somente exemplos sintéticos dessas políticas.

Endereço exige os **seis campos explícitos e confirmados por perfil**. Campos
vazios/placeholder bloqueiam esta primeira entrega, por conservadorismo. O
complemento vem da unidade; endereço pessoal não substitui o padrão informado.
Não há armazenamento de configuração entre sessões nem implementação ADDR-01.

Os números da solicitação estão apenas em `manifesto.exemplo.json`, como
`checkpoint` externo, removível. Divergência com checkpoint não altera a
expectativa extraída. A verdade financeira não é uma constante de contagem.

## Manifesto privado

Copiar o exemplo **fora do Git**. O exemplo é deliberadamente inválido:
`exemplo: true`, hashes zerados, caminhos e endereço por preencher são recusados.
Após preencher, usar `exemplo: false` e confirmar a área privada e endereços.

- `raizes`: mapa de diretórios absolutos autorizados, existentes e fora do Git.
- `perfis`: exatamente um item de cada um dos seis perfis.
- `financeiro`, `A`, `B`: objetos com `raiz`, `arquivo` relativo em barras `/`,
  `sha256`. `cadastro` tem o mesmo formato ou é `null`.
- `endereco`: `perfil`, `confirmado: true`, `campos` com `logradouro`, `numero`,
  `cep`, `bairro`, `cidade`, `uf`, todos strings. Não incluir complemento aqui.
- `regressao`: `null` quando não houver referência independente; nesse caso o
  eixo documental pode passar, mas o estado global é `EVIDENCIA_INSUFICIENTE`.
  Havendo prova histórica externa, usar
  `{"tipo":"HASH_REFERENCIA_EXTERNA","A":"<64 hex>","B":"<64 hex>"}`.
  Verificar a procedência dessa referência antes de usá-la; esta é uma premissa
  do operador, não uma cadeia de custódia certificada pela ferramenta.
- `checkpoint`: opcional, `dividas`, `cadastrais_b`, `valor_original` decimal
  textual. Não é insumo de cálculo ou substituto da fonte.

SHA-256 antes/depois não comprova sozinho origem documental. Além da declaração
de hashes do operador, fontes originais precisam corresponder ao catálogo
auditado do perfil para aprovação completa. Arquivo atualizado não homologado
requer revisão de proveniência separada; não editar D2 para contornar o bloqueio.

## Relatórios e estados

Cada execução cria pasta nova, sem sobrescrever resultados. `privado/` contém
`REC01_detalhes.json`, com caminhos, hashes de fontes, IDs/origens, linhas
esperadas e divergências localizáveis. **Não compartilhar essa pasta.**

`compartilhavel/` contém somente:

- `REC01_resumo.json`: seis perfis, estados separados documental/regressão,
  completude, originais, elegíveis/não elegíveis, exportados, extras, totais,
  divergências, retenções, pendências e ressalvas.
- `REC01_matriz.csv`: projeção agregada do resumo, sem campos livres.
- `REC01_divergencias_agregadas.json`: contagens por código seguro.
- `REC01_integridade.json`: antes/depois, quantidades e hash do manifesto público
  da candidata; não publica hashes individuais de documentos privados.
- `REC01_execucao.json`: estado, código seguro, inspeção de privacidade e SO.

O esquema formal está em `relatorios.schema.json`. A inspeção antes da escrita
usa lista positiva de campos, perfis, estados e códigos. Não admite texto livre,
IDs, CPF/CNPJ, nomes, e-mails, telefones, caminhos ou hashes de arquivos privados.
CSV deriva dos valores já inspecionados. Revisão humana do conjunto efetivamente
selecionado para envio continua necessária; nunca enviar manifesto/detalhes.

Precedência: `ERRO_OPERACIONAL` > `DIVERGENTE` > `EVIDENCIA_INSUFICIENTE` >
`APROVADO_COM_RESSALVAS` > `APROVADO`. Não somar totais de execuções diferentes.
Erro de qualquer fonte, interrupção ou alteração de integridade invalida a
execução inteira, preservando o estado explícito nos seis perfis. Exceções e
stdout/stderr dos leitores não são reproduzidos em logs ou terminal.

`APROVADO` significa concordância no escopo e nas premissas declaradas; não
homologação operacional, autoria jurídica ou certificação de segurança.

## Modelo de ameaça e limites

Operador confiável, diretórios privados sob seu controle, arquivos estáticos
durante a execução, sem processo hostil com a mesma identidade. Validação
lexical, `lstat` de todos os pais, rejeição de symlinks/junctions/reparse points,
abertura somente leitura, `fstat`, SHA-256 e identidade antes/depois. Metadados
Git danificados, worktrees e bare são tratados conservadoramente na área privada.
Arquivos extras na candidata são recusados; caches e `work/` preexistentes são
áreas auxiliares não importadas e não pertencem aos 454 hashes. Não se leem
`.pyc` preexistentes da candidata. O utilitário não faz chamadas de rede.

Hardlinks regulares com bytes e hash esperados são permitidos, conforme contrato
D2 informado pelo usuário. Não comprovam origem física exclusiva, isolamento,
ausência de aliases ou DACL segura. Mudança pelo alias detectável por
hash/identidade invalida a execução. Não presume que todo hardlink é defeito.

As guardas de caminho são estáticas; não há caminhada Windows de handles de
diretórios nem garantia contra substituição hostil entre verificações. Mudanças
transitórias restauradas entre fotografias e encerramento forçado do processo
podem escapar: ausência de relatório final nunca é aprovação. Guardar fontes
em área sem escritores concorrentes. Não enfraquecer controles para executar.

Em POSIX, novas pastas/arquivos recebem 0700/0600. No Windows, a ferramenta não
aplica DACL e não trata chmod como proteção NTFS. O operador deve escolher uma
área cujo acesso já esteja restrito; `area_privada_confirmada` é sua confirmação,
não teste de acesso efetivo. DACL, acesso por outro usuário, isolamento entre
processos, reparse concorrente e segurança geral Windows permanecem pendentes.

Leitores compartilhados podem ter erro comum de interpretação; a reconciliação
não substitui inspeção das páginas e cabeçalhos privados. XLSX carregado sem
executar fórmulas, rejeitando fórmulas, macros, links externos, documentos
numéricos, tipos financeiros inválidos e mais de 30 colunas em Dados.
Limites: 100 MiB por fonte/expansão XLSX, 100 mil linhas exportadas. Não há sandbox
de parser nem limite global de CPU/RSS. PDFs e planilhas devem ser confiáveis.

## Execução e aceite

Seguir `REC_01_WINDOWS.md`. Resultados Linux e preservação constam de
`REC_01_ENTREGA.md`; rastreabilidade em `REC_01_RASTREABILIDADE.md`.
Não alterar D2, produção, políticas ou pacotes anteriores. Sem publicação,
commit, push, PR ou merge. A primeira entrega está destinada à auditoria técnica
e execução privada controlada. Os seis condomínios só terão parecer funcional
após análise dos documentos reais pelo operador.
