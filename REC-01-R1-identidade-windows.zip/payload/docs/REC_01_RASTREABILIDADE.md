# REC-01 — Rastreabilidade e confirmação pendente

Todos os testes citados estão em `tools/reconciliacao_privada/test_rec01.py`,
exceto as sondas indicadas. Fixtures pré-existentes em `tests/int02` e nas seis
famílias são exclusivamente sintéticas. Nenhum resultado a seguir é execução
com documentos reais. Conferir contagens finais em `REC_01_ENTREGA.md`.

| Requisito | Verificação / teste associado | Evidência da entrega |
| --- | --- | --- |
| 1. Seis perfis | `test_seis_perfis_leitores_originais_com_fontes_sinteticas` parametrizado | JUnit Linux |
| 2. Referência e limites | `test_limites_exatos`, 6 × 3; `test_itajuba_escopo_anterior_nao_vira_exclusao_comprovada` | JUnit Linux |
| 3. Duplicidades legítimas | `test_duplicatas_legitimas_contadas_ambiguidade_explicita` × 6 | Contagem integral, ressalva individual |
| 4–5. Omissão / acréscimo indevido | `test_omissao_acrescimo_e_inelegivel`, `test_b_financeiro_adicional` | Categorias separadas; sem deduplicar |
| 6–8. Centavo, dia, bloco/unidade | `test_alteracao_celula_detectada` | Nove alterações isoladas, inclusive cadastro/endereço/identificador |
| 9. Extra B indevido | `test_b_extra_indevida_e_modos_trocados`, `test_cadastral_alterada_uma_celula` | Multiconjunto de 30 células |
| 10–12. Retenção / associação / cadastro opcional | `test_retencao_correta_e_associacao_indevida` × 6 × 4 | Linha financeira preservada; documento indevido detectado |
| 13. Cadastro alheio | `test_cadastro_cruzado_recusado`, fonte conhecida de outro perfil AUTO GESTÃO | Rejeição por contrato; origens novas não homologadas não passam |
| 14. A/B trocados | `test_b_extra_indevida_e_modos_trocados` | Extra em A + falta em B; limite quando modos são equivalentes documentado |
| 15. Alteração de fontes | `test_alteracao_durante_execucao_e_interrupcao[input]`, `test_substituicao_durante_leitura_recusada` | Hash + identidade por handle; erro explícito |
| 16. Caminhos / links | `test_manifesto_negativo`, `test_links_inseguros_recusados`, `test_reparse_recusado_por_atributo`, `test_git_danificado_e_bare_recusados` | Guardas Linux/simulação de atributo; Windows real pendente |
| 17. Interrupção | `test_alteracao_durante_execucao_e_interrupcao[interrupcao]` | Seis perfis com erro; encerramento forçado sem final nunca aprova |
| 18. Privacidade | `test_erro_sem_dados_privados`, `test_inspecao_privacidade_recusa_injecao`, `test_inspecao_recusa_nome_disfarcado_de_codigo`, `test_fontes_reais_nao_necessarias_cli_sanitiza_erro`, `test_cli_argumento_invalido_nao_repete_dados_privados` | Sem stdout/stderr privado; lista positiva antes da escrita |
| 19. Determinismo | `test_integracao_completa_determinismo_privacidade` | Cinco agregados idênticos byte a byte em duas execuções |
| 20. Candidata antes/depois | `test_candidata_diferente_antes_processar`, alteração `[candidata]`, `test_verificador_candidata_recusa_extra_e_pai_simbolico` | Não depende só do HEAD; manifesto público 454 hashes |
| BPQ-04 | `test_bpq04_titular_individual_versus_documento_so_pagador` | Casos equivalentes fictícios; identificações reais só no Windows |
| Origem independente | `test_fonte_nova_sem_hash_catalogado_nao_aprova`, `test_falta_regressao_nao_aprova_globalmente` | Falta de evidência não vira aprovação |
| Checkpoints externos | `test_checkpoint_nao_alimenta_esperado` | Contagem forçada no manifesto produz divergência, não muda o motor |
| XLSX seguro e tipos | `test_xlsx_invalido_recusado` | Fórmula, documento numérico, linha cadastral com valor e coluna extra recusados |
| Regressão, separada da auditoria documental | `test_projecao_independente_confere_saida_mvp_sintetico` × 6 | Produção gera somente fixture comparativa, não expectativa documental |
| Hardlink regular | `test_hardlink_validado_por_hash_nao_certifica_origem_fisica` | Hash válido permitido; alias alterado invalida; sem atesto físico/ACL |
| Preservação de evidências | `test_saida_existente_preservada` | Recusa sobrescrita |

## Confirmações Windows ainda necessárias

1. `test_windows_nativo.py::test_powershell_51_parse_launcher`: parser real
   Windows PowerShell 5.1. Linux não executou esse teste.
2. `test_windows_nativo.py::test_junction_externa_recusada`: reparse real em
   volume local. Linux testou apenas a guarda por atributo simulado.
3. CLI/launcher completos, CP1252 padrão, sem `-X utf8`, caminhos com espaços e
   acentos, áreas fora do Git e 454 hashes antes/depois. Smoke Linux separado
   não substitui essa confirmação.
4. Symlinks sem privilégios: cinco testes podem ficar ignorados com código
   `REC01_SYMLINK_SEM_PRIVILEGIO_CONTROLE_NAO_VALIDADO` caso Windows retorne 1314.
   Não elevar privilégios. Registrar como controle não validado; não aprovado.
5. Acesso efetivo da pasta privada/DACL não é sondado nem aprovado pela REC.
   Segurança Windows, isolamento de outro processo e substituição concorrente
   hostil continuam fora da evidência, mesmo que a suíte funcional passe.
6. Reconciliação integral dos documentos reais, 12 XLSX, endereços da sessão,
   fontes homologadas e referências históricas independentes. Os checkpoints
   informados pelo usuário não substituem essa execução.

Não há conclusão de homologação dos seis condomínios ou reabertura da WIN-01-D2.
