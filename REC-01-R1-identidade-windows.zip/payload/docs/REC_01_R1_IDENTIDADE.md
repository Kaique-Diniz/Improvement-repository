# REC-01-R1 — Identidade física e tempos no Windows

**Candidata para nova avaliação sintética Windows. Não utilizar R1 com
documentos reais antes dessa validação.** Não altera produção, D2 ou negócio.

## Evidência recebida e alcance

O usuário informou execução Windows/PowerShell 5.1/Python 3.12.10, `pip check`
aprovado, 16 arquivos REC originais conferidos e 454 hashes D2 íntegros.
Resultado relatado: **116 testes, 106 passed, 5 failed, 5 skipped, 0 errors**.
Não recebemos o XML primário; não simulamos sua execução no Linux.

A sonda nativa relatada comparou `lstat` com `fstat` em dois arquivos sintéticos.
No pequeno, todos os campos coincidiram e `Arquivo.ler` aceitou. No maior,
somente `st_ctime_ns` diferiu entre APIs; os dois `fstat` permaneceram iguais
e ocorreu `FONTE_SUBSTITUIDA`, sem substituição realizada. O tamanho observado
é uma correlação, não uma regra ou limiar utilizado na correção.

Cinco falhas históricas a reexecutar individualmente:

| Nodeid em `tools/reconciliacao_privada/test_rec01.py` | Evidência Windows original | Verificação R1 Linux | Situação nativa R1 |
| --- | --- | --- | --- |
| `test_integracao_completa_determinismo_privacidade` | Falhou, informado pelo usuário | Original + modelo Windows com ctime cruzado diferente | PENDENTE |
| `test_alteracao_durante_execucao_e_interrupcao[input]` | Falhou, informado pelo usuário | Original + modelo; erro final de integridade preservado | PENDENTE |
| `test_alteracao_durante_execucao_e_interrupcao[interrupcao]` | Falhou, informado pelo usuário | Original + modelo; interrupção preservada | PENDENTE |
| `test_falta_regressao_nao_aprova_globalmente` | Falhou, informado pelo usuário | Original + modelo; ausência permanece insuficiente | PENDENTE |
| `test_checkpoint_nao_alimenta_esperado` | Falhou, informado pelo usuário | Original + modelo; checkpoint permanece divergente | PENDENTE |

O falso positivo da comparação foi demonstrado. **Não se atribui a causa de
cada uma das cinco falhas exclusivamente a ele sem os respectivos registros
nativos.** O modelo novo chama as funções originais, sem editar suas asserções.

## Investigação técnica e referências primárias

Python 3.12 descontinua `ctime` como nome para criação no Windows; a documentação
orienta `st_birthtime` para esse dado. Dispositivo e índice do arquivo têm outra
finalidade; `st_ino` pode ocupar 128 bits no Windows. Não usar criação/modificação
como substitutos da identidade. Ver [documentação Python 3.12](https://docs.python.org/3.12/library/os.html#os.stat_result).

Foi inspecionado o **tag v3.12.10**, correspondente à versão informada:

- [`Modules/posixmodule.c`, `win32_xstat`](https://github.com/python/cpython/blob/v3.12.10/Modules/posixmodule.c#L2139):
  após a coleta, copia `st_birthtime` para `st_ctime` no caminho usado por stat/lstat.
- [`Python/fileutils.c`, `_Py_attribute_data_to_stat`](https://github.com/python/cpython/blob/v3.12.10/Python/fileutils.c#L1108):
  conserva CreationTime em birthtime e ChangeTime em ctime.
- [`Python/fileutils.c`, `_Py_fstat_noraise`](https://github.com/python/cpython/blob/v3.12.10/Python/fileutils.c#L1233):
  consulta o handle e chama esse conversor, sem a sobreposição de ctime feita por
  `win32_xstat`. Também solicita `FileIdInfo`; preservamos os bits retornados.

Isso explica tecnicamente por que duas APIs podem devolver ctimes diferentes
para o mesmo objeto intacto nessa versão. É inspeção de fonte oficial, somada
à sonda fornecida pelo usuário; não é uma nova execução Windows no Codex.

A Microsoft documenta a comparação conjunta de volume e file ID e ressalva
dependências do sistema de arquivos e eventual reutilização de IDs. Referências:
[BY_HANDLE_FILE_INFORMATION](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/ns-fileapi-by_handle_file_information)
e [FILE_ID_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_info).
R1 não introduz FFI ou dependência de módulos ACL diagnósticos para isso.

## Estratégia aplicada

Somente `seguranca.py` foi alterado dentre os 16 arquivos da REC original.
Os demais 15, incluindo `auditoria.py`, regras de relatório, CLI, PowerShell,
reconstrutor e testes originais, permanecem idênticos ao ZIP publicado.

`AssinaturaArquivo` mantém explicitamente:

- `fisica`: dispositivo/volume e identificador completos, sem truncar bits;
- `tamanho` e `mtime_ns`: sinais de alteração, não prova de identidade;
- `ctime_ns`: conservado, com comparação condicionada ao tipo de API/plataforma.

| Comparação | Windows | POSIX |
| --- | --- | --- |
| lstat antes × fstat aberto | ID + tamanho + mtime | ID + tamanho + mtime + ctime |
| fstat antes × fstat depois da leitura | ID + tamanho + mtime + ctime | Os mesmos cinco campos da REC original |
| lstat antes × lstat depois | ID + tamanho + mtime + ctime | Os mesmos cinco campos da REC original |
| fstat × lstat depois | ID + tamanho + mtime | Os mesmos cinco campos da REC original |
| `Arquivo.conferir`: descritor anterior × novo descritor | ID + tamanho + mtime + ctime | Os mesmos cinco campos da REC original |
| `Arquivo.conferir`: caminho anterior × novo caminho | ID + tamanho + mtime + ctime | Os mesmos cinco campos da REC original |

Assim, **ctime não foi removido de todas as verificações**, nem trocado por uma
tolerância de tempo arbitrária. Só deixou de ser comparado entre APIs distintas
no Windows. A igualdade estrita anterior permanece em todos os cruzamentos POSIX.

Cada abertura ainda exige arquivo regular no descritor, validação de todos os
ancestrais antes e depois, ausência de links/reparse points e raiz autorizada.
Compara o objeto que foi aberto ao validado, lê integralmente, confere tamanho
efetivamente lido, calcula SHA-256 e exige o hash fornecido. Na conferência final,
relê e revalida o caminho, os bytes e ambas as famílias de metadados.

IDs ausentes, não inteiros, inode não positivo ou dispositivo inválido bloqueiam
com `FALHA_LEITURA`, código operacional seguro já existente. No Windows, volume
zero também é recusado conservadoramente, inclusive se um volume excepcional
pudesse tê-lo legitimamente: não se presume prova disponível. POSIX continua
aceitando dispositivo zero com inode válido. Não há fallback apenas pelo hash.
Se um provedor/filesystem não fornecer IDs confiáveis/compatíveis, a leitura
não está autorizada; não fabricar ou truncar identificadores para fazê-la passar.

## Propriedades demonstradas e códigos

| Cenário sintético | Verificação / código |
| --- | --- |
| Pequeno e maior intactos | Bytes integrais e identidade conferidos; aceitos |
| Apenas ctime cruzado diferente no modelo Windows | Aceito; mesmos IDs/tamanho/mtime e estabilidade entre chamadas da mesma API |
| Mesmo modelo sob política POSIX | `FONTE_SUBSTITUIDA`; igualdade estrita não removida |
| ctime do mesmo tipo de API mudou | `FONTE_SUBSTITUIDA`, inclusive em `conferir` |
| Outro objeto, bytes e tempos iguais | `FONTE_SUBSTITUIDA`, diferença física continua necessária |
| Substituição entre caminho validado e abertura | `FONTE_SUBSTITUIDA` |
| Mutação durante a leitura, mesmo tamanho | `FONTE_SUBSTITUIDA`, sinal temporal mudou |
| Mutação depois da leitura, mtime restaurado, mesmo objeto/tamanho | `HASH_DIVERGENTE` |
| Ancestral trocado por symlink/junction | `LINK_OU_REPARSE_RECUSADO`, mesmo que o arquivo físico seja o mesmo |
| Identidade/tempos necessários indisponíveis | `FALHA_LEITURA`, sem aprovação por SHA isolado |
| Fonte muda na auditoria | `INTEGRIDADE_FINAL_FALHOU`, preservado pelo código original |
| Interrupção sem mudança de integridade | `EXECUCAO_INTERROMPIDA`, preservado pelo código original |

No teste de substituição final, os sinais temporais são normalizados
deliberadamente no modelo: remover a comparação física faria o teste falhar.
Os dois cenários com ancestral usam symlink em POSIX e junction de usuário em
Windows, sem habilitar privilégios. Falha em criar junction gera skip explícito
de controle não validado; não é convertida em aprovação.

## Limites, skips e aceite

Linux testa os arquivos reais sintéticos do seu filesystem e modela as duas
políticas de comparação. Isso não comprova o resultado da candidata em NTFS.
Quatro novos casos nativos Windows ficam separados: pequeno, maior, substituição
com bytes iguais e mutação com mtime restaurado. Somam-se às duas sondas nativas
originais; são seis skips nativos esperados no Linux.

Os **cinco skips de symlink históricos Windows** continuam explicitamente nas
funções originais: três parametrizações de `test_links_inseguros_recusados`,
`test_verificador_candidata_recusa_extra_e_pai_simbolico` e
`test_reconstrucao_payload_sem_sobrescrita[pai_link]`. Motivo do helper original:
`REC01_SYMLINK_SEM_PRIVILEGIO_CONTROLE_NAO_VALIDADO`, quando winerror é 1314.
Não foram removidos, promovidos a aprovação ou substituídos por skips de função
para esconder as cinco falhas históricas.

As limitações estáticas de contenção e concorrência da REC permanecem. Volume/ID
não é identificador eterno entre ciclos de exclusão; não se declara imunidade a
um escritor hostil restaurando todos os sinais entre fotografias. Hardlink com
ID/bytes válidos continua compatível com o contrato existente. Não se certifica
DACL, origem física exclusiva, acesso por outro usuário ou segurança geral Windows.

Critério ainda pendente: passar os testes nativos R1 e reexecutar os cinco
históricos e a suíte completa no Windows 3.12.10/PowerShell 5.1, com D2 íntegra.
Seguir `REC_01_R1_WINDOWS.md`. **Não usar R1 com documentos reais antes dessa
nova validação.**
