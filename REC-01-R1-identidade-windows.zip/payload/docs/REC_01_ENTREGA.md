# REC-01 — Entrega para auditoria e execução privada

## Resultado

Ferramenta externa implementada em worktree isolada e pronta para **revisão
técnica e execução privada controlada**, sujeita às premissas documentadas.
Não houve reconciliação com fontes reais, homologação funcional dos seis
condomínios ou certificação de segurança Windows.

Baseline: `770d062d29c4361d6932592883df9339bb4089bc`.
Worktree: `/workspace/work/rec-01`, HEAD detached no baseline.
Todas as alterações são arquivos novos em `tools/reconciliacao_privada/` e
`docs/REC_01*`. Nenhum arquivo previamente versionado foi alterado.

## Arquivos

- `documental.py`: leitura pelos contratos existentes, expectativa documental,
  cálculo independente de prazo/original, retenções A1/B1 e multiconjuntos.
- `seguranca.py`: leitura por handle, contenção estática, recusa de links,
  Git danificado/bare, hashes, candidata e arquivos novos sem sobrescrita.
- `auditoria.py`: execução, estados, verificação final, detalhes privados e
  cinco agregados inspecionados por lista positiva.
- `auditar.py` e `executar.ps1`: CLI e launcher sem instalação/elevação.
- `reconstruir_entrega.py`: payload REC somente em checkout limpo do baseline,
  verificação de hashes e conflitos antes de copiar.
- `CANDIDATA_D2_SHA256.json`: versão pública fixada nos 454 arquivos auditados.
- `manifesto.exemplo.json`: seis perfis, sem dados privados, placeholders
  deliberadamente inválidos e checkpoints externos removíveis.
- `relatorios.schema.json`: esquema formal dos agregados.
- `test_rec01.py`: testes sintéticos dos requisitos e casos negativos.
- `test_windows_nativo.py`: duas sondas separadas, pendentes em Windows real.
- `REC_01.md`, `REC_01_WINDOWS.md`, `REC_01_RASTREABILIDADE.md` e este relatório.

O diff integral da entrega inclui arquivos **não rastreados** como adições
contra `/dev/null`; não se usou `git diff` vazio como representação do trabalho.
O pacote local reúne payload, diff, manifesto SHA-256, logs/JUnit finais,
preservação e inventário da diferença D2/baseline. Não contém fontes privadas,
exportações reais, credenciais ou tokens. Há documentos fiscais e contatos
**fictícios**, restritos às fixtures de teste já identificadas como sintéticas.

## Testes efetivamente executados

Linux, Python 3.12.14, dependências existentes, sem instalação nesta tarefa.
Rodada final única: **114 passed, 0 failed, 2 skipped, 0 errors**, em 26,06 s.
Os dois skips são exclusivamente as sondas Windows/PowerShell nativas.
Não são aprovações dos controles correspondentes.

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/workspace/work/rec-01:/workspace/work/win-01-d-auditoria2/src \
PYTHONUTF8=0 /workspace/work/win01a-venv/bin/python -B -m pytest -q \
  tools/reconciliacao_privada/test_rec01.py \
  tools/reconciliacao_privada/test_windows_nativo.py \
  -o pythonpath= --tb=short \
  --junitxml=/workspace/work/rec01-evidencias/rec01-final-auditavel.xml
```

Inclui leitura das seis famílias, 18 limites de prazo, retenções/associações,
duplicatas legítimas, erro de centavo/dia/unidade/bloco, extras B, troca A/B,
substituição de fonte, alteração da candidata, interrupção, privacidade,
determinismo, BPQ-04 e reconstrução sem sobrescrita. Seis casos adicionais
dentro dessa mesma rodada comparam a projeção independente com saída sintética
do MVP; suas aprovações não são somadas novamente. O caso final de privacidade
também confirma que argumentos CLI inválidos não são repetidos por argparse
quando contêm texto privado.

Reconstrução real em outra worktree limpa do baseline: 16 arquivos REC
restaurados, nenhum arquivo de produção alterado. A cópia reconstruída e o
pacote inicial de conferência local foram preservados; a entrega final é
`REC-01-entrega-final.zip`.

Smoke da CLI completa: seis perfis sintéticos, sem cadastro, em caminho com
espaços/acentos fora do Git; D2 efetivamente carregada e **454 hashes antes e
depois**. Sem stderr/PII. Retornou status 2 e `EVIDENCIA_INSUFICIENTE`, como
esperado por origem sintética não catalogada e ausência de referência histórica
externa. Isso comprova que a execução completa não fabrica uma aprovação.

AST/sintaxe dos módulos e parse de todos os JSON: aprovados.
`pip check`: `No broken requirements found.` Inspeção de credenciais: nenhum
segredo identificado; a ocorrência `tokens` é variável local do parser PS.

Não se repetiu a suíte de homologação WIN-01-D2: a REC não reabre essa etapa.
Os resultados Windows **2.665 passed/14 skipped/zero falhas**, as 749 regressões,
os 12 XLSX e as sondas 8.3/junction/hardlink foram **informados pelo usuário**,
não executados nesta tarefa. CP1252/PowerShell 5.1/NTFS nativos continuam
dependentes da execução REC no computador do operador.

## Diferença da candidata e preservação

D2: 454 arquivos contra 430 no baseline, 24 novos e 17 alterados, nenhum
ausente. Inventário integral em `evidencias/D2_vs_baseline.json` no pacote.
Somente dois arquivos `src/` diferem, conforme descrito em `REC_01.md`.
Nenhuma dessas alterações foi introduzida ou reaplicada pela REC.

Fotografias por SHA-256 e estado Git antes/depois confirmaram preservação das
worktrees A revisada (475 arquivos observados), C (553), D (517), D2 (527),
incluindo seus diretórios de trabalho e logs, exceto caches transitórios.
Todos os ZIP anteriores permanecem idênticos. Checkout original permanece
limpo em `04f29ff5fc9124b988bd611d3d1b8d7224ae874f`.
Ver `evidencias/PRESERVACAO.json`. Os 454 arquivos de versão D2 também foram
conferidos independentemente pelo verificador da CLI.

Não houve commit, push, PR, merge ou publicação. Não há alteração em produção,
leitores, regras financeiras, cadastro, exportação, A/B, endereço persistente,
ACLs ou configurações do sistema. A worktree REC permanece para revisão.

## Parecer e pendências

A entrega permite a auditoria privada integral com fontes estáticas,
proveniência homologada e endereços da conversão. Os leitores e A1/B1 são
compartilhados, limitação explícita da independência; campos vazios podem ser
retenções corretas. Pareamento individual em grupos repetidos não é afirmado.
Regressão sem referência externa permanece separadamente sem evidência.

Antes do aceite funcional: revisar código/diff, confirmar sondas Windows REC,
verificar a área privada já protegida, executar os seis perfis e analisar os
cinco agregados e diferenças privadas. O manifesto precisa da procedência
independente das referências históricas; seu simples preenchimento não a prova.

DACL efetiva, outro usuário/processo, substituição hostil concorrente e
segurança Windows geral permanecem não homologadas. Nenhum skip, hash ou teste
sintético substitui esse conjunto de evidências ou as fontes reais.
