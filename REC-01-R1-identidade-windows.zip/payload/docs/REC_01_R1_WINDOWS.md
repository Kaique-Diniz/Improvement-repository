# REC-01-R1 — Roteiro de revalidação sintética Windows

**Não executar R1 com documentos reais nesta etapa.** Reconstruir em outra
worktree; preservar REC original, D2 (454 hashes), pacotes e resultados anteriores.
Python 3.12, Windows 10/11 e PowerShell 5.1, sem administrador/instalação/DACL.
Os caminhos abaixo são exemplos em LOCALAPPDATA; ajustar os locais existentes.

## 1. Receber e conferir o novo pacote

O ZIP R1 precisa ser recebido por mecanismo autorizado. Nenhuma publicação é
realizada nesta entrega. Conferir o SHA-256 novo recebido separadamente; não
usar `420f4fc4...`, que identifica a REC original. O ZIP novo contém payload
completo e manifesto recalculado. As versões históricas da documentação REC
original são preservadas no payload: **seguir estes documentos R1 primeiro**.

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'REC01-R1-Auditoria'
$Pacote = Join-Path $Root 'Pacote'
$Entrega = Join-Path $Root 'REC01-R1-Worktree'
$Resultados = Join-Path $Root 'Resultados'
$Zip = Join-Path $Root 'REC-01-R1-identidade-windows.zip'
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe'
$D2 = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria2\WIN-01-D2'
$Repo = Join-Path $HOME 'Conversor-MVP-BPQ04'
$HashEsperado = 'PREENCHER_COM_SHA256_R1_DA_ENTREGA'

if ($HashEsperado -notmatch '^[0-9a-f]{64}$') { throw 'SHA256_R1_AUSENTE' }
if (-not (Test-Path -LiteralPath $Zip -PathType Leaf)) { throw 'PACOTE_R1_AUSENTE' }
$HashObtido = (Get-FileHash -LiteralPath $Zip -Algorithm SHA256).Hash.ToLowerInvariant()
if ($HashObtido -ne $HashEsperado) { throw 'SHA256_R1_DIVERGENTE' }
if (Test-Path -LiteralPath $Pacote) { throw 'EXTRACAO_PREEXISTENTE_PRESERVAR' }
if (Test-Path -LiteralPath $Entrega) { throw 'WORKTREE_PREEXISTENTE_PRESERVAR' }
Expand-Archive -LiteralPath $Zip -DestinationPath $Pacote
& $Python --version
if ($LASTEXITCODE -ne 0) { throw 'PYTHON_INDISPONIVEL' }
& $Python -m pip check
if ($LASTEXITCODE -ne 0) { throw 'DEPENDENCIAS_INCONSISTENTES' }
```

Confirmar versão 3.12.x e manter a mesma versão 3.12.10 da sonda se disponível.
Escolher `$Resultados` fora de qualquer worktree Git, em área privada já
restrita. Não alterar permissões/política do Windows para executar o roteiro.

## 2. Reconstruir em worktree nova do baseline

O helper original `reconstruir_entrega.py` foi mantido byte a byte. Ele verifica
todos os hashes do novo manifesto, estado limpo, raiz/base Git e conflitos
antes de adicionar o payload. Nunca usar a worktree original como destino.

```powershell
& git -C $Repo worktree add --quiet --detach $Entrega 770d062d29c4361d6932592883df9339bb4089bc
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_R1_NAO_CRIADA' }
$Reconstrutor = Join-Path $Pacote 'payload\tools\reconciliacao_privada\reconstruir_entrega.py'
& $Python -B $Reconstrutor --pacote $Pacote --destino $Entrega
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_R1_BLOQUEADA' }
```

Comparar a quantidade de arquivos adicionados com `payload_arquivos` do
`MANIFESTO_ENTREGA.json`. Erro/interrupção: preservar o destino e reconstruir
em outro novo. Não repetir sobrepor, não usar force e não atualizar a D2.

## 3. Conferir 454 hashes D2 e a versão R1 antes/depois

No exemplo abaixo, salvar este Python **fora do Git**, em `$Root\conferir_r1.py`,
com codificação UTF-8. É verificação de bytes, somente leitura. Não imprime
caminhos, conteúdo ou IDs de arquivos.

```python
from hashlib import sha256
import json
from pathlib import Path
import sys

pacote, entrega, d2 = map(Path, sys.argv[1:4])
manifesto = json.loads((pacote / 'MANIFESTO_ENTREGA.json').read_text(encoding='utf-8'))
n = 0
for nome, esperado in manifesto['arquivos'].items():
    if nome.startswith('payload/'):
        relativo = nome[len('payload/'):]
        if sha256((entrega / relativo).read_bytes()).hexdigest() != esperado:
            raise SystemExit('R1_HASH_DIVERGENTE')
        n += 1
sys.dont_write_bytecode = True
sys.path.insert(0, str(entrega))
from tools.reconciliacao_privada.seguranca import verificar_candidata
versao = json.loads((entrega / 'tools/reconciliacao_privada/CANDIDATA_D2_SHA256.json').read_text(encoding='utf-8'))
if len(versao['arquivos']) != 454 or verificar_candidata(d2, versao) != 454:
    raise SystemExit('D2_HASH_DIVERGENTE')
print(json.dumps({'estado': 'INTEGRIDADE_OK', 'arquivos_r1': n, 'hashes_d2': 454}))
```

Rodar antes e depois dos testes; se o verificador bloquear com identidade
indisponível ou metadados inesperados, **interromper e registrar o bloqueio**.
Não omitir esse controle nem substituir por uma comparação somente por hash
para declarar sucesso da ferramenta.

```powershell
$Conferencia = Join-Path $Root 'conferir_r1.py'
& $Python -B $Conferencia $Pacote $Entrega $D2
if ($LASTEXITCODE -ne 0) { throw 'INTEGRIDADE_INICIAL_BLOQUEADA' }
```

O Python de conferência acima é destinado a arquivos sintéticos/públicos de
software; exceções dele podem conter caminhos de software locais. Não enviar
traceback ou a pasta privada indiscriminadamente. Os erros da CLI REC continuam
sanitizados pelos testes originais, que não foram modificados.

## 4. Executar os cinco históricos separadamente

Criar diretório de evidências **novo**, fora do Git. Não somar suas contagens
às da rodada integral. Fixar temporariamente PYTHONPATH para o utilitário R1
e o `src` D2 verificado; não instalar no projeto e não usar `-X utf8`.

```powershell
if (-not (Test-Path -LiteralPath $Resultados)) {
    New-Item -ItemType Directory -Path $Resultados | Out-Null
}
$Run = Join-Path $Resultados ('R1-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $Run | Out-Null
$PythonPathAnterior = $env:PYTHONPATH
$Utf8Anterior = $env:PYTHONUTF8
$BytecodeAnterior = $env:PYTHONDONTWRITEBYTECODE
try {
    $env:PYTHONPATH = $Entrega + ';' + (Join-Path $D2 'src')
    $env:PYTHONUTF8 = '0'
    $env:PYTHONDONTWRITEBYTECODE = '1'
    Push-Location $Entrega
    try {
        $Historicos = @(
            'tools/reconciliacao_privada/test_rec01.py::test_integracao_completa_determinismo_privacidade'
            'tools/reconciliacao_privada/test_rec01.py::test_alteracao_durante_execucao_e_interrupcao[input]'
            'tools/reconciliacao_privada/test_rec01.py::test_alteracao_durante_execucao_e_interrupcao[interrupcao]'
            'tools/reconciliacao_privada/test_rec01.py::test_falta_regressao_nao_aprova_globalmente'
            'tools/reconciliacao_privada/test_rec01.py::test_checkpoint_nao_alimenta_esperado'
        )
        $XmlHistoricos = Join-Path $Run 'historicos-r1.xml'
        & $Python -B -m pytest -q @Historicos -o pythonpath= --tb=short -rA --junitxml $XmlHistoricos
        $StatusHistoricos = $LASTEXITCODE
        if ($StatusHistoricos -ne 0) { throw 'HISTORICOS_R1_REPROVADOS_PRESERVAR_EVIDENCIA' }

        $XmlIntegral = Join-Path $Run 'integral-r1.xml'
        & $Python -B -m pytest -q tools/reconciliacao_privada/test_rec01.py `
            tools/reconciliacao_privada/test_windows_nativo.py `
            tools/reconciliacao_privada/test_identidade_r1.py `
            tools/reconciliacao_privada/test_identidade_windows_nativo_r1.py `
            -o pythonpath= --tb=short -rA --junitxml $XmlIntegral
        $StatusIntegral = $LASTEXITCODE
        if ($StatusIntegral -ne 0) { throw 'INTEGRAL_R1_REPROVADA_PRESERVAR_EVIDENCIA' }
    }
    finally { Pop-Location }
}
finally {
    $env:PYTHONPATH = $PythonPathAnterior
    $env:PYTHONUTF8 = $Utf8Anterior
    $env:PYTHONDONTWRITEBYTECODE = $BytecodeAnterior
    & $Python -B $Conferencia $Pacote $Entrega $D2
    if ($LASTEXITCODE -ne 0) { throw 'INTEGRIDADE_FINAL_BLOQUEADA' }
}
```

Se a etapa histórica falhar, o `finally` ainda confere integridade. Registrar
essa falha antes de uma eventual execução integral separada. Nenhum código de
saída do pytest é tratado automaticamente como aprovação. Manter o XML original
privado como evidência primária, sem transcrever dados sensíveis.

## 5. Avaliar sem promover skips

- Conferir explicitamente os cinco históricos, quatro novos casos nativos e
  testes de privacidade, determinismo, manifesto, interrupção, mutação de fontes,
  regressão ausente e checkpoint.
- Registrar todas as linhas `SKIPPED` com nodeid e motivo. Os cinco históricos
  de symlink permanecem sem comprovação se winerror for 1314; não habilitar
  privilégios nem tratá-los como aprovados.
- Novos dois cenários de ancestral podem produzir skip específico se junction
  não puder ser criada. Isso é ausência de evidência, não correção comprovada.
- Confirmar 454 hashes D2 e hashes R1 antes/depois. As contagens históricas,
  focadas e integrais são execuções distintas; não somá-las.
- Se houver nova divergência `ctime` entre chamadas da MESMA API, identidade
  zero/indisponível ou outro falso positivo, preservar os registros sintéticos e
  devolver para auditoria. Não retirar controles para produzir testes verdes.

Mesmo após testes sintéticos favoráveis, decidir humanamente sobre a próxima
fase. Até a revisão dos resultados Windows R1, **não usar documentos reais**.
Sem instalação de dependências, commit, push, PR, merge ou publicação nesta etapa.
