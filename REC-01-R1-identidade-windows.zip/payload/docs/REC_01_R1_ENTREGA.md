# REC-01-R1 — Entrega para nova avaliação Windows

**Não utilizar R1 com documentos reais antes da nova validação Windows.**
Esta entrega prepara a correção e sua auditoria; não declara encerradas as cinco
falhas nativas nem homologa segurança Windows ou os seis condomínios.

## Versão e limites

Worktree isolada `/workspace/work/rec-01-r1`, detached no baseline
`770d062d29c4361d6932592883df9339bb4089bc`.
Os 16 arquivos REC originais foram recuperados do ZIP publicado, SHA-256
`420f4fc4bd183df3934f1581e8d4828870c8862d497584c78ffd4b2d3ac1e096`, e
conferidos antes de editar. A candidata D2 disponível tem 454 arquivos de versão
e é somente lida. Nada foi presumido sobre arquivos do computador do usuário.

Dentre esses 16 arquivos, **somente `seguranca.py` mudou**. Os outros 15 continuam
byte a byte iguais ao pacote original, inclusive os dois arquivos de testes
originais, o reconstrutor, os scripts e a camada de relatórios. Mais cinco
arquivos novos compõem a revisão:

- `tools/reconciliacao_privada/test_identidade_r1.py`;
- `tools/reconciliacao_privada/test_identidade_windows_nativo_r1.py`;
- `docs/REC_01_R1_IDENTIDADE.md`;
- `docs/REC_01_R1_WINDOWS.md`;
- este `docs/REC_01_R1_ENTREGA.md`.

O payload completo R1 contém **21 arquivos**. A documentação REC original é
mantida como histórica; a orientação R1 de não usar documentos reais prevalece
nesta avaliação. Não foram alterados leitores, A1/B1, elegibilidade, exportador,
MVP, D2, dados de condomínios ou configuração do sistema. Não houve instalação,
commit, push, PR, merge ou publicação.

## Mudança e justificativa

`AssinaturaArquivo` separa ID físico, tamanho, mtime e ctime. No Windows somente
a comparação de ctime **entre lstat e fstat** deixa de ser exigida. Ctime
permanece estrito entre chamadas da mesma API, durante a leitura e na conferência
final. POSIX preserva os cinco campos estritos em todos os cruzamentos.
O ID completo do arquivo nunca é substituído por SHA-256; dados indisponíveis
falham conservadoramente. Mantidos validação de caminhos, links, reparse points,
arquivo regular, releitura, SHA-256 integral e integridade final. Também se
confere que a quantidade efetivamente lida corresponda ao tamanho anunciado.

A inspeção do CPython **v3.12.10** identificou a sobreposição de ctime por
birthtime no caminho de stat/lstat e a conservação de ChangeTime no conversor
usado por fstat. Ver justificativa completa e fontes em `REC_01_R1_IDENTIDADE.md`.
Isso sustenta a correção do falso positivo informado; não atribui automaticamente
a mesma causa a cada um dos cinco nodeids históricos.

## Testes efetivamente executados no Codex

Linux, Python 3.12.14; CPython Windows/PowerShell/NTFS não estão disponíveis
neste executor. Usado o `src` D2 verificado, sem `-X utf8`, com `PYTHONUTF8=0`.

| Rodada | Passed | Failed | Skipped | Errors | Duração |
| --- | ---: | ---: | ---: | ---: | ---: |
| Focada R1, duas novas suítes | 41 | 0 | 4 | 0 | 5,68 s |
| Integral REC original + R1, única rodada final | 155 | 0 | 6 | 0 | 23,97 s |

**Não somar rodadas.** A integral contém os 114 casos sintéticos originais e
41 novos; seus seis skips são as duas sondas Windows originais e quatro casos
Windows R1. Não são aprovações desses controles. Os cinco skips de symlink
informados pelo usuário no Windows continuam documentados separadamente e
seus testes permanecem intactos.

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/workspace/work/rec-01-r1:/workspace/work/win-01-d-auditoria2/src \
PYTHONUTF8=0 /workspace/work/win01a-venv/bin/python -B -m pytest -q \
  tools/reconciliacao_privada/test_rec01.py \
  tools/reconciliacao_privada/test_windows_nativo.py \
  tools/reconciliacao_privada/test_identidade_r1.py \
  tools/reconciliacao_privada/test_identidade_windows_nativo_r1.py \
  -o pythonpath= --tb=short \
  --junitxml=/workspace/work/rec01-r1-evidencias/rec01-r1-integral.xml
```

As regressões novas verificam arquivo pequeno/maior, ctime cruzado Windows,
ctime estrito POSIX/mesma API, IDs de 128 bits, identidade inválida, descritor
não regular, substituição com bytes e tempos iguais, troca antes da abertura,
mutação durante/depois da leitura e troca de ancestral por link/junction.
Chamam também as funções originais dos cinco históricos sob um modelo de
metadados Windows, preservando integralmente suas asserções.

Na integral passaram os negativos de privacidade/argumentos, integridade dos
agregados, determinismo, manifesto incompleto, regressão ausente, checkpoint
divergente, interrupção e alteração das fontes. Os códigos exigidos continuam
comprovados nos cenários sintéticos: `FONTE_SUBSTITUIDA`, `HASH_DIVERGENTE`,
`INTEGRIDADE_FINAL_FALHOU`, `EXECUCAO_INTERROMPIDA`. Nenhum relatório compartilhável
passou a conter IDs físicos, ctimes, conteúdo ou caminhos privados.

AST/compilação em memória e parse JSON: aprovados. `pip check`:
`No broken requirements found.` Não se repetiu a suíte de produção WIN-01-D2;
isso não faz parte desta correção do utilitário externo.

## Pacote e reconstrução

Novo arquivo local: `/workspace/work/REC-01-R1-identidade-windows.zip`.
Contém payload completo, diff integral **contra a REC original**, manifesto
novo, logs/JUnit sintéticos, fontes técnicas referenciadas, evidência histórica
identificada como fornecida pelo usuário, preservação e reconstrução isolada.
Não contém documentos privados, PDFs/XLSX reais, credenciais ou tokens.

Todos os hashes são recalculados dos bytes atuais. O SHA-256 novo do ZIP e do
manifesto identificam esta revisão; os 15 arquivos intocados naturalmente têm
os mesmos hashes individuais da REC original. Não se reutiliza um manifesto
antigo como prova da revisão. CRC e hashes internos são conferidos no pacote.

O reconstrutor original é adequado ao novo manifesto e foi mantido sem edição.
A entrega exige nova worktree limpa do baseline; recusa arquivos existentes ou
estado incompatível antes de copiar. A evidência de reconstrução registra a
igualdade dos 21 hashes do payload e a recusa de uma segunda aplicação, sem
sobrescrita. Nenhuma correspondência de versão é deduzida apenas do HEAD.

Worktrees e ZIP anteriores foram fotografados antes da edição e são conferidos
novamente por hash/estado Git. D2 permanece com seus 454 hashes. Logs e estados
históricos não foram substituídos; os resultados R1 têm arquivos novos.

## Pendências e parecer

**Preparada para auditoria e nova avaliação sintética Windows; não liberada
para documentos reais.** O aceite nativo exige:

1. Reexecutar os cinco históricos individualmente, sem presumir causa comum.
2. Passar os quatro novos casos reais de Windows e as sondas originais.
3. Executar integral REC+R1, registrar cada skip/motivo e conferir os hashes
   D2/R1 antes e depois, conforme `REC_01_R1_WINDOWS.md`.
4. Examinar eventual nova diferença temporal da mesma API ou identidade física
   indisponível, sem remover controles para produzir aprovação.

Os cinco cenários symlink com privilégio 1314 permanecem sem prova se forem
ignorados; novos skips de junction também não aprovam isolamento. DACL efetiva,
acesso por outro usuário, identificadores reutilizados entre ciclos de exclusão
e substituição hostil transitória continuam nos limites documentados. Esta
correção não é certificação de segurança nem reconciliação de documentos reais.
