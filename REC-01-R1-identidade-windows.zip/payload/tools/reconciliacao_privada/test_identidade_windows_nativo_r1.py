"""R1: testes adicionais somente Windows real, sem arquivos privados."""
import os
from pathlib import Path

import pytest

from tools.reconciliacao_privada.seguranca import Arquivo, Bloqueio, hash_bytes

pytestmark = pytest.mark.skipif(os.name != 'nt', reason='REC01_R1_WINDOWS_NATIVO_NAO_EXECUTADO')


@pytest.mark.parametrize('tamanho', [19, 2 * 1024 * 1024 + 37])
def test_windows_real_arquivo_intacto_pequeno_e_maior(tmp_path, tamanho):
    conteudo = (b'REC01_R1_SINTETICO_' * (tamanho // 18 + 1))[:tamanho]
    path = tmp_path / 'amostra sintetica.bin'; path.write_bytes(conteudo)
    f = Arquivo.ler(tmp_path, path.name, hash_bytes(conteudo))
    assert f.conteudo == conteudo and f.identidade.fisica == (path.stat().st_dev, path.stat().st_ino)
    f.conferir()


def test_windows_real_objeto_substituido_com_bytes_iguais(tmp_path):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    f = Arquivo.ler(tmp_path, path.name)
    novo = tmp_path / 'novo'; novo.write_bytes(b'SINTETICO')
    assert novo.stat().st_ino != path.stat().st_ino
    os.replace(novo, path)
    with pytest.raises(Bloqueio, match='^FONTE_SUBSTITUIDA$'): f.conferir()


def test_windows_real_hash_distingue_conteudo_com_mtime_restaurado(tmp_path):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    antes = path.stat()
    f = Arquivo.ler(tmp_path, path.name)
    path.write_bytes(b'ALTERACAO')
    os.utime(path, ns=(antes.st_atime_ns, antes.st_mtime_ns))
    assert path.stat().st_ino == antes.st_ino and path.stat().st_size == antes.st_size
    with pytest.raises(Bloqueio, match='^HASH_DIVERGENTE$'): f.conferir()
