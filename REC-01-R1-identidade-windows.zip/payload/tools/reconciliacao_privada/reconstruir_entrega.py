"""Adicionar somente o payload REC em checkout novo e limpo do baseline.

Executar a copia extraida do pacote; sem deps, instalacao, commit ou rede.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess

BASE = '770d062d29c4361d6932592883df9339bb4089bc'


def checar_caminho(path, *, ausente=False):
    p = Path(os.path.abspath(path))
    for node in (*reversed(p.parents), p):
        if ausente and not os.path.lexists(node):
            continue
        st = node.lstat()
        if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
            raise ValueError('CAMINHO_RECUSADO')
    return p


def reconstruir(pacote, destino):
    pacote = checar_caminho(pacote)
    destino = checar_caminho(destino)
    def git(*args):
        p = subprocess.run(['git', '-C', str(destino), *args], capture_output=True, timeout=30)
        if p.returncode:
            raise ValueError('GIT_NAO_CONFIRMADO')
        return p.stdout.decode('utf-8', errors='strict').strip()
    if git('rev-parse', 'HEAD') != BASE or git('status', '--porcelain=v1', '--untracked-files=all'):
        raise ValueError('BASELINE_OU_ESTADO_INCOMPATIVEL')
    if not Path(git('rev-parse', '--show-toplevel')).samefile(destino):
        raise ValueError('DESTINO_NAO_E_RAIZ_DA_WORKTREE')
    indice = json.loads((pacote / 'MANIFESTO_ENTREGA.json').read_text(encoding='utf-8'))
    hashes = indice['arquivos']
    if indice['baseline'] != BASE or not hashes:
        raise ValueError('MANIFESTO_INVALIDO')
    planos = []
    for nome, digest in sorted(hashes.items()):
        partes = PurePosixPath(nome)
        if partes.is_absolute() or any(x in ('', '.', '..') for x in nome.split('/')) or '\\' in nome or ':' in nome:
            raise ValueError('CAMINHO_RECUSADO')
        fonte = checar_caminho(pacote.joinpath(*partes.parts))
        conteudo = fonte.read_bytes()
        if sha256(conteudo).hexdigest() != digest:
            raise ValueError('HASH_PACOTE_DIVERGENTE')
        if partes.parts[0] == 'payload':
            relativo = PurePosixPath(*partes.parts[1:])
            if not (str(relativo).startswith('tools/reconciliacao_privada/') or str(relativo).startswith('docs/REC_01')):
                raise ValueError('PAYLOAD_FORA_ESCOPO')
            alvo = checar_caminho(destino.joinpath(*relativo.parts), ausente=True)
            if os.path.lexists(alvo):
                raise ValueError('ARQUIVO_PREEXISTENTE_PRESERVADO')
            planos.append((alvo, conteudo, digest))
    if not planos:
        raise ValueError('PAYLOAD_AUSENTE')
    # Validar todos os conflitos/hashes antes da primeira escrita.
    for alvo, conteudo, digest in planos:
        alvo.parent.mkdir(parents=True, exist_ok=True)
        checar_caminho(alvo.parent)
        with alvo.open('xb') as f:
            f.write(conteudo)
        if sha256(alvo.read_bytes()).hexdigest() != digest:
            raise ValueError('HASH_FINAL_DIVERGENTE')
    return len(planos)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pacote', required=True, type=Path)
    p.add_argument('--destino', required=True, type=Path)
    args = p.parse_args()
    try:
        n = reconstruir(args.pacote, args.destino)
        print(json.dumps({'estado': 'RECONSTRUIDA', 'arquivos_rec': n, 'producao_alterada': False}))
        return 0
    except Exception:
        print('{"estado":"BLOQUEADO","codigo":"RECONSTRUCAO_REC01_NAO_CONFIRMADA"}')
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
