"""REC-01-R1: modelos de metadados Windows e mutações só de arquivos sintéticos.

WINDOWS=True modela a política da comparação, não executa APIs NTFS em Linux.
As funções originais dos cinco históricos são chamadas sem relaxar asserções.
"""
from hashlib import sha256
import os
from pathlib import Path
import stat
import subprocess
from types import SimpleNamespace

import pytest

from tools.reconciliacao_privada import seguranca as s
from tools.reconciliacao_privada import test_rec01 as original

# Reutilizar construtores/fixtures sintéticos, sem duplicar ou editar a suíte original.
rodada = original.rodada
referencia = original.referencia


class OSLocal:
    """Substituições restritas ao módulo auditado; não alterar os.name global."""
    def __init__(self, **substituicoes):
        self.substituicoes = substituicoes

    def __getattr__(self, nome):
        return self.substituicoes.get(nome, getattr(os, nome))


def campos(st, **alterados):
    valores = {nome: getattr(st, nome) for nome in dir(st) if nome.startswith('st_')}
    valores.update(alterados)
    return SimpleNamespace(**valores)


def simular_ctime_windows(monkeypatch):
    def fstat(fd):
        st = os.fstat(fd)
        return campos(st, st_ctime_ns=st.st_ctime_ns + 17_000_000_000)
    monkeypatch.setattr(s, 'WINDOWS', True)
    monkeypatch.setattr(s, 'os', OSLocal(fstat=fstat))


class LeituraComGancho:
    def __init__(self, handle, gancho):
        self.handle, self.gancho = handle, gancho

    def __enter__(self):
        self.handle.__enter__()
        return self

    def __exit__(self, *args):
        return self.handle.__exit__(*args)

    def fileno(self):
        return self.handle.fileno()

    def read(self, limite):
        data = self.handle.read(limite)
        self.gancho()
        return data


@pytest.mark.parametrize('tamanho', [19, 2 * 1024 * 1024 + 37])
def test_arquivo_intacto_pequeno_e_maior(tmp_path, tamanho):
    data = (b'REC01_R1_SINTETICO_' * (tamanho // 18 + 1))[:tamanho]
    path = tmp_path / 'amostra.bin'; path.write_bytes(data)
    f = s.Arquivo.ler(tmp_path, path.name, sha256(data).hexdigest())
    assert f.conteudo == data and f.identidade.fisica == (path.stat().st_dev, path.stat().st_ino)
    f.conferir()


@pytest.mark.parametrize('windows', [False, True])
def test_ctime_cruzado_isolado_so_tolerado_no_windows(tmp_path, monkeypatch, windows):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    simular_ctime_windows(monkeypatch)
    monkeypatch.setattr(s, 'WINDOWS', windows)
    original_path, descritor = path.lstat(), None
    with path.open('rb') as h:
        descritor = s.os.fstat(h.fileno())
    assert original_path.st_dev == descritor.st_dev and original_path.st_ino == descritor.st_ino
    assert original_path.st_size == descritor.st_size and original_path.st_mtime_ns == descritor.st_mtime_ns
    assert original_path.st_ctime_ns != descritor.st_ctime_ns
    if windows:
        f = s.Arquivo.ler(tmp_path, path.name, s.hash_bytes(b'SINTETICO'))
        assert f.identidade.ctime_ns != f.estado_caminho.ctime_ns
        f.conferir()
    else:
        with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
            s.Arquivo.ler(tmp_path, path.name)


@pytest.mark.parametrize('windows', [False, True])
def test_ctime_de_descritor_durante_leitura_continua_bloqueante(tmp_path, monkeypatch, windows):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    ctime_inicial = path.lstat().st_ctime_ns
    monkeypatch.setattr(s, 'WINDOWS', windows)
    chamadas = 0
    def fstat(fd):
        nonlocal chamadas
        chamadas += 1
        st = os.fstat(fd)
        return campos(st, st_ctime_ns=ctime_inicial + (1 if chamadas > 1 else 0))
    monkeypatch.setattr(s, 'os', OSLocal(fstat=fstat))
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        s.Arquivo.ler(tmp_path, 'amostra')
    assert chamadas == 2


@pytest.mark.parametrize('api', ['lstat', 'fstat'])
def test_ctime_mesma_api_na_conferencia_final_preservado(tmp_path, monkeypatch, api):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    simular_ctime_windows(monkeypatch)
    f = s.Arquivo.ler(tmp_path, path.name)
    if api == 'fstat':
        fstat_anterior = s.os.fstat
        monkeypatch.setattr(s, 'os', OSLocal(fstat=lambda fd: campos(
            fstat_anterior(fd), st_ctime_ns=f.identidade.ctime_ns + 1)))
    else:
        lstat_anterior = Path.lstat
        def lstat(p, *args, **kw):
            st = lstat_anterior(p, *args, **kw)
            return campos(st, st_ctime_ns=f.estado_caminho.ctime_ns + 1) if p == path else st
        monkeypatch.setattr(Path, 'lstat', lstat)
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        f.conferir()


@pytest.mark.parametrize('campo,valor', [
    ('st_ino', 0), ('st_ino', None), ('st_ino', -1), ('st_ino', True),
    ('st_ino', '123'), ('st_dev', 0), ('st_dev', None), ('st_dev', -1),
    ('st_mtime_ns', None), ('st_ctime_ns', None),
])
@pytest.mark.parametrize('api', ['lstat', 'fstat'])
def test_identidade_ou_metadados_indisponiveis_falham_conservadoramente(tmp_path, monkeypatch, campo, valor, api):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    monkeypatch.setattr(s, 'WINDOWS', True)
    if api == 'fstat':
        monkeypatch.setattr(s, 'os', OSLocal(fstat=lambda fd: campos(os.fstat(fd), **{campo: valor})))
    else:
        real_lstat = Path.lstat
        def lstat(p, *args, **kw):
            st = real_lstat(p, *args, **kw)
            return campos(st, **{campo: valor}) if p == path else st
        monkeypatch.setattr(Path, 'lstat', lstat)
    with pytest.raises(s.Bloqueio, match='^FALHA_LEITURA$'):
        s.Arquivo.ler(tmp_path, path.name, s.hash_bytes(b'SINTETICO'))


def test_identificador_128_bits_nao_e_truncado(tmp_path, monkeypatch):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    monkeypatch.setattr(s, 'WINDOWS', True)
    lstat_real = Path.lstat
    def lstat(p, *args, **kw):
        st = lstat_real(p, *args, **kw)
        return campos(st, st_ino=(1 << 96) + 123) if p == path else st
    monkeypatch.setattr(Path, 'lstat', lstat)
    monkeypatch.setattr(s, 'os', OSLocal(fstat=lambda fd: campos(os.fstat(fd), st_ino=(2 << 96) + 123)))
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        s.Arquivo.ler(tmp_path, path.name)


def test_descritor_nao_regular_nao_e_aceito(tmp_path, monkeypatch):
    (tmp_path / 'amostra').write_bytes(b'SINTETICO')
    monkeypatch.setattr(s, 'os', OSLocal(fstat=lambda fd: campos(os.fstat(fd), st_mode=stat.S_IFIFO | 0o600)))
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        s.Arquivo.ler(tmp_path, 'amostra')


def test_substituicao_mesmos_bytes_e_tempos_normalizados_nao_vira_aprovacao(tmp_path, monkeypatch):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    inicial = path.stat()
    # Modelo adversarial: mesmos sinais temporais/tamanho, ID real diferente.
    def normalizar(st):
        return campos(st, st_mtime_ns=inicial.st_mtime_ns, st_ctime_ns=inicial.st_ctime_ns)
    lstat_real = Path.lstat
    def lstat(p, *args, **kw):
        st = lstat_real(p, *args, **kw)
        return normalizar(st) if p == path else st
    monkeypatch.setattr(Path, 'lstat', lstat)
    monkeypatch.setattr(s, 'os', OSLocal(fstat=lambda fd: normalizar(os.fstat(fd))))
    f = s.Arquivo.ler(tmp_path, path.name, s.hash_bytes(b'SINTETICO'))
    novo = tmp_path / 'novo'; novo.write_bytes(b'SINTETICO')
    assert novo.stat().st_ino != inicial.st_ino
    os.replace(novo, path)
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        f.conferir()


def test_substituicao_entre_validacao_e_abertura(tmp_path, monkeypatch):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    def abrir(p, flags):
        novo = tmp_path / 'novo'; novo.write_bytes(b'SINTETICO')
        os.replace(novo, p)
        return os.open(p, flags)
    monkeypatch.setattr(s, 'os', OSLocal(open=abrir))
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        s.Arquivo.ler(tmp_path, path.name)


def test_conteudo_alterado_durante_leitura(tmp_path, monkeypatch):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    antes = path.stat()
    def alterar():
        path.write_bytes(b'ALTERACAO')  # Mesmo tamanho; objeto existente, sem substituir.
        os.utime(path, ns=(antes.st_atime_ns, antes.st_mtime_ns + 2_000_000_000))
    monkeypatch.setattr(s, 'os', OSLocal(fdopen=lambda fd, modo: LeituraComGancho(os.fdopen(fd, modo), alterar)))
    with pytest.raises(s.Bloqueio, match='^FONTE_SUBSTITUIDA$'):
        s.Arquivo.ler(tmp_path, path.name, s.hash_bytes(b'SINTETICO'))


def test_hash_independente_detecta_alteracao_apos_leitura_mesmo_tamanho_mtime(tmp_path):
    path = tmp_path / 'amostra'; path.write_bytes(b'SINTETICO')
    antes = path.stat()
    f = s.Arquivo.ler(tmp_path, path.name, s.hash_bytes(b'SINTETICO'))
    path.write_bytes(b'ALTERACAO')
    os.utime(path, ns=(antes.st_atime_ns, antes.st_mtime_ns))
    assert path.stat().st_ino == antes.st_ino and path.stat().st_size == antes.st_size
    with pytest.raises(s.Bloqueio, match='^HASH_DIVERGENTE$'):
        f.conferir()


def criar_link_diretorio(alias, destino):
    if os.name != 'nt':
        alias.symlink_to(destino, target_is_directory=True)
    else:
        p = subprocess.run(['cmd.exe', '/d', '/c', 'mklink', '/J', str(alias), str(destino)],
                           capture_output=True, timeout=30)
        if p.returncode != 0:
            pytest.skip('REC01_R1_JUNCTION_NAO_CRIADA_CONTROLE_NAO_VALIDADO')


@pytest.mark.parametrize('momento', ['antes_abrir', 'conferir'])
def test_troca_ancestral_por_link_ou_junction_recusada(tmp_path, monkeypatch, momento):
    raiz = tmp_path / 'privado'; raiz.mkdir()
    pai = raiz / 'subpasta'; pai.mkdir(); (pai / 'amostra').write_bytes(b'SINTETICO')
    movido = tmp_path / 'movido'
    def trocar():
        pai.rename(movido)
        criar_link_diretorio(pai, movido)
    try:
        if momento == 'conferir':
            f = s.Arquivo.ler(raiz, 'subpasta/amostra')
            trocar()
            with pytest.raises(s.Bloqueio, match='^LINK_OU_REPARSE_RECUSADO$'): f.conferir()
        else:
            def abrir(p, flags):
                trocar()
                return os.open(p, flags)
            monkeypatch.setattr(s, 'os', OSLocal(open=abrir))
            with pytest.raises(s.Bloqueio, match='^LINK_OU_REPARSE_RECUSADO$'):
                s.Arquivo.ler(raiz, 'subpasta/amostra')
    finally:
        if os.path.lexists(pai) and movido.exists():
            if os.name == 'nt': pai.rmdir()
            else: pai.unlink()


@pytest.mark.parametrize('cenario', ['determinismo', 'input', 'interrupcao', 'regressao', 'checkpoint'])
def test_cinco_historicos_com_diferenca_ctime_windows(rodada, tmp_path, monkeypatch, cenario):
    simular_ctime_windows(monkeypatch)
    if cenario == 'determinismo':
        original.test_integracao_completa_determinismo_privacidade(rodada, tmp_path)
    elif cenario in ('input', 'interrupcao'):
        original.test_alteracao_durante_execucao_e_interrupcao(rodada, tmp_path, cenario)
    elif cenario == 'regressao':
        original.test_falta_regressao_nao_aprova_globalmente(rodada, tmp_path)
    else:
        original.test_checkpoint_nao_alimenta_esperado(rodada, tmp_path)
