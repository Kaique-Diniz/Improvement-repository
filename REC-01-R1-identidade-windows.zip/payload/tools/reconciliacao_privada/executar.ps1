param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Candidata,
    [Parameter(Mandatory=$true)][string]$Manifesto,
    [Parameter(Mandatory=$true)][string]$SaidaPai
)
$ErrorActionPreference = 'Stop'
# PowerShell 5.1; usuario normal, sem instalacao, DACL ou mudanca de politica.
if ($env:OS -ne 'Windows_NT') { throw 'WINDOWS_REAL_OBRIGATORIO' }
foreach ($Arquivo in @($Python, $Manifesto)) {
    if (-not (Test-Path -LiteralPath $Arquivo -PathType Leaf)) { throw 'ENTRADA_AUSENTE' }
}
foreach ($Pasta in @($Candidata, $SaidaPai)) {
    if (-not (Test-Path -LiteralPath $Pasta -PathType Container)) { throw 'DIRETORIO_AUSENTE' }
}
$Execucao = 'REC01-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N')
$Ferramenta = Join-Path $PSScriptRoot 'auditar.py'
# O Python captura e sanitiza erros. Nao ha Git nativo no pipeline PowerShell.
& $Python -B $Ferramenta --manifesto $Manifesto --candidata $Candidata --saida-pai $SaidaPai --execucao $Execucao
$Codigo = $LASTEXITCODE
if ($Codigo -ne 0) { throw 'REC01_NAO_APROVADA_CONFERIR_RELATORIOS_LOCAIS' }
Write-Host 'REC01_CONCLUIDA; DECISAO_DE_ACEITE_HUMANA; SEGURANCA_WINDOWS_NAO_HOMOLOGADA'
