"""Sondas complementares, somente Windows real, sem elevar privilégios."""
import os
from pathlib import Path
import subprocess
import pytest

from tools.reconciliacao_privada.seguranca import Arquivo, Bloqueio

pytestmark = pytest.mark.skipif(os.name != 'nt', reason='REC01_WINDOWS_NATIVO_NAO_EXECUTADO')


def test_powershell_51_parse_launcher():
    script = str(Path(__file__).with_name('executar.ps1')).replace("'", "''")
    code = ("$ErrorActionPreference='Stop'; $tokens=$null; $erros=$null; "
            f"[void][System.Management.Automation.Language.Parser]::ParseFile('{script}',[ref]$tokens,[ref]$erros); "
            "if ($erros.Count -gt 0) {exit 2}; if ($PSVersionTable.PSVersion.Major -ne 5) {exit 3}; exit 0")
    p = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', code],
                       capture_output=True, timeout=30)
    assert p.returncode == 0, 'REC01_POWERSHELL_51_NAO_CONFIRMADO'


def test_junction_externa_recusada(tmp_path):
    root = tmp_path / 'privado'; root.mkdir()
    fora = tmp_path / 'fora'; fora.mkdir(); (fora / 'amostra').write_bytes(b'SINTETICO')
    junction = root / 'junction'
    p = subprocess.run(['cmd.exe', '/d', '/c', 'mklink', '/J', str(junction), str(fora)],
                       capture_output=True, timeout=30)
    if p.returncode != 0:
        pytest.skip('REC01_JUNCTION_NAO_CRIADA_CONTROLE_NAO_VALIDADO')
    try:
        with pytest.raises(Bloqueio, match='LINK_OU_REPARSE_RECUSADO'):
            Arquivo.ler(root, 'junction/amostra')
    finally:
        # Remove apenas a junction sintética, nunca seu destino.
        junction.rmdir()
