"""Projeção documental independente do motor e do escritor XLSX.

Reutiliza os leitores e as políticas A1/B1 auditadas, explicitamente. Nunca
chama analisar(), avaliar_regras(), materializar() ou escrever_xlsx().
"""
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from io import BytesIO

from .seguranca import Bloqueio, hash_bytes

PERFIS = ('passaredo', 'forest_hill', 'parque_santa_monica', 'vero_encanto',
          'itajuba', 'terraco_beach_parque')
PRAZOS = dict(zip(PERFIS, (60, 30, 60, 30, 30, 30)))
DATA_REF = date(2026, 11, 9)
ENDERECO = ('logradouro', 'numero', 'cep', 'bairro', 'cidade', 'uf')


@dataclass
class Linha:
    valores: tuple
    referencia: dict = field(default_factory=dict)

    @property
    def financeira(self):
        return any(v != '' for v in self.valores[24:])


@dataclass
class Expectativa:
    financeiras: list
    cadastrais: list
    excluidas: list
    originais: int
    retencoes: Counter
    pendencias: Counter = field(default_factory=Counter)
    ressalvas: Counter = field(default_factory=Counter)
    privado: dict = field(default_factory=dict)


def elegibilidade(perfil, vencimento, valor):
    if perfil not in PRAZOS:
        raise Bloqueio('PERFIL_NAO_SUPORTADO')
    if perfil == 'itajuba' and vencimento < date(2023, 12, 1):
        return 'REVISAO_ESCOPO_DOCUMENTAL'
    if valor <= 0:
        return 'REVISAO_VALOR_NAO_POSITIVO'
    return 'ELEGIVEL' if (DATA_REF - vencimento).days > PRAZOS[perfil] else 'PRAZO_NAO_ATINGIDO'


def base_pessoa(pessoa, identificador, complemento, nome_cedente, endereco):
    from conversor.domain.documents import resolver_documento
    doc = resolver_documento(pessoa)
    if doc.bloqueante:
        raise Bloqueio('IDENTIDADE_DOCUMENTAL_BLOQUEANTE')
    contato = pessoa.contato
    values = [nome_cedente, identificador, doc.valor, pessoa.nome,
              endereco['logradouro'], endereco['numero'], complemento, endereco['cep'],
              endereco['bairro'], endereco['cidade'], endereco['uf']]
    for i in range(5):
        tel = contato.telefones[i] if i < len(contato.telefones) else None
        values.extend((tel.ddd, tel.numero) if tel else ('', ''))
    values.extend(contato.emails[i] if i < len(contato.emails) else '' for i in range(3))
    return values


def construir(perfil_id, financeiro, cadastro, endereco):
    from conversor.web import service
    from conversor.export.identifiers import selecionar_perfil
    from conversor.application.passaredo_cadastro import associar as auto
    from conversor.application.oma_cadastro import associar as oma
    from conversor.application.vero_cadastro import associar as vero
    from conversor.application.itajuba import associar as itj, rotulo as rotulo_itj
    from conversor.application.beach_parque_cadastro import associar as beach, resolver_linha_cadastral
    from conversor.readers.passaredo_canonical import lancamentos_originais
    from conversor.readers.itajuba_pdf import originais as originais_itj
    from conversor.readers.beach_parque_xlsx import originais as originais_beach
    from conversor.domain.forest_hill import rotulo_descricao as rotulo_forest
    from conversor.domain.beach_parque import rotulo_descricao as rotulo_beach
    import json

    if perfil_id not in PERFIS:
        raise Bloqueio('PERFIL_NAO_SUPORTADO')
    perfil, codigo, leitor = service.reconhecer(financeiro, perfil_informado=perfil_id)
    if perfil['id'] != perfil_id:
        raise Bloqueio('FONTE_DE_OUTRO_CONDOMINIO')
    # Uma alteração de regra na candidata não pode ser absorvida silenciosamente.
    if perfil['dias'] != PRAZOS[perfil_id] or perfil['exclusoes']:
        raise Bloqueio('CONTRATO_FINANCEIRO_INESPERADO')
    lote, _ = service.ler(financeiro, perfil, codigo, leitor, 'inadimplencia')
    pendencias, ressalvas = Counter(), Counter()
    catalogo = perfil['fontes_homologacao_sha256']
    if hash_bytes(financeiro) != catalogo.get('inadimplencia'):
        pendencias['ORIGEM_FINANCEIRA_NAO_COMPROVADA'] += 1
    cad = None
    if cadastro is not None:
        pc, cc, lc = service.reconhecer(cadastro, cadastro=True, perfil_informado=perfil_id)
        if pc['id'] != perfil_id or cc != codigo:
            raise Bloqueio('CADASTRO_DE_OUTRO_CONDOMINIO')
        cad, _ = service.ler(cadastro, pc, cc, lc, 'cadastro')
        if hash_bytes(cadastro) != catalogo.get('cadastro'):
            pendencias['ORIGEM_CADASTRAL_NAO_COMPROVADA'] += 1
    else:
        # Opcional: ausência aprovada somente se a saída conservar as retenções.
        ressalvas['CADASTRO_OPCIONAL_NAO_FORNECIDO'] += 1
    associar = {'passaredo': auto, 'forest_hill': auto, 'parque_santa_monica': oma,
                'vero_encanto': vero, 'itajuba': itj, 'terraco_beach_parque': beach}[perfil_id]
    lote, pessoas_boleto, resumo_cad, _ = associar(lote, cad)
    pessoas = {p.unidade_id: p for p in lote.pessoas}
    if perfil_id in ('passaredo', 'forest_hill'):
        dados = lancamentos_originais(lote)
    elif perfil_id == 'itajuba':
        dados = originais_itj(lote)
    elif perfil_id == 'terraco_beach_parque':
        dados = originais_beach(lote)
    else:
        dados = {}
    saida = selecionar_perfil(json.loads(service.PERFIS_SAIDA_PATH.read_bytes()),
        administradora_id=perfil['administradora_id'], condominio_id=perfil['condominio_id'])
    if saida is None:
        raise Bloqueio('CODIFICACAO_NAO_COMPROVADA')
    # Somente contagens/categorias fixas no agregado; códigos brutos ficam privados.
    motivos = Counter(r.codigo for r in lote.ressalvas)
    retencoes = Counter()
    for codigo, n in motivos.items():
        if 'DIVERGENTE_CADASTRO' in codigo:
            retencoes['RETENCAO_NOMINAL'] += n
        elif 'MULTIPLO' in codigo and 'RETID' in codigo:
            retencoes['RETENCAO_MULTIPLICIDADE'] += n
        elif 'CONFLITANTES_CADASTRO' in codigo:
            retencoes['RETENCAO_CONFLITO_DOCUMENTAL'] += n
        elif 'RETID' in codigo:
            retencoes['RETENCAO_DOCUMENTAL'] += n
        if 'DOCUMENTO_INVALIDO' in codigo or 'DOCUMENTO_MALFORMADO' in codigo:
            retencoes['DOCUMENTO_INVALIDO_NAO_PROMOVIDO'] += n
    financeiros, extras, excluidas = [], [], []
    revisoes, referencias, codigos = [], [], set()
    # Bloqueios canônicos preexistentes não viram aprovação por esta auditoria.
    for r in lote.ressalvas:
        if r.gravidade == 'critico':
            pendencias['FONTE_COM_REVISAO_CRITICA'] += 1
    for u in lote.unidades:
        cedente, complemento = saida.codificar(u, administradora_id=perfil['administradora_id'])
        if cedente in codigos:
            raise Bloqueio('COLISAO_IDENTIDADE_UNIDADE')
        codigos.add(cedente)
        pessoa = pessoas.get(u.id)
        if pessoa is None:
            pendencias['RESPONSAVEL_NAO_COMPROVADO'] += 1
            continue
        boletos = sorted((b for b in lote.boletos if b.unidade_id == u.id),
                         key=lambda b: (b.vencimento, b.identificador, b.id))
        decisoes, parcela, unidade_revisao = [], 0, False
        for b in boletos:
            estado = elegibilidade(perfil_id, b.vencimento, b.composicao.total_original)
            ref = {'boleto_id': b.id, 'identificador_original': b.identificador,
                   'bloco': u.bloco_original, 'unidade': u.unidade_original,
                   'origens': [o.model_dump(mode='json') for o in b.origens], 'motivo': estado}
            referencias.append(ref)
            revisao = estado.startswith('REVISAO')
            unidade_revisao |= revisao
            if revisao:
                pendencias['LANCAMENTO_COM_REVISAO_DOCUMENTAL'] += 1
                revisoes.append(ref)
            d = {'id': b.id, 'unidade_id': u.id, 'situacao_financeira': 'excluido' if estado == 'PRAZO_NAO_ATINGIDO'
                 else 'elegivel_na_simulacao' if estado == 'ELEGIVEL' else 'indeterminado',
                 'situacao': 'nao_elegivel' if estado == 'PRAZO_NAO_ATINGIDO'
                 else 'elegivel' if estado == 'ELEGIVEL' else 'revisao'}
            decisoes.append(d)
            responsavel = pessoas_boleto.get(b.id, pessoa)
            if not responsavel.nome.strip():
                pendencias['RESPONSAVEL_NAO_COMPROVADO'] += 1
                unidade_revisao = True
                continue
            base = base_pessoa(responsavel, cedente, complemento, saida.nome_cedente, endereco)
            if estado == 'ELEGIVEL':
                parcela += 1
            numero = parcela if estado == 'ELEGIVEL' else 1
            if perfil_id in ('passaredo', 'forest_hill'):
                rotulo = dados[b.id]['descricao']
                if perfil_id == 'forest_hill':
                    rotulo, _ = rotulo_forest(rotulo, b.vencimento, numero)
            elif perfil_id == 'itajuba':
                rotulo = rotulo_itj(dados[b.id], b.vencimento, numero)
            elif perfil_id == 'terraco_beach_parque':
                rotulo, _ = rotulo_beach(dados[b.id]['componentes'][0]['historico'], b.vencimento, numero)
            elif saida.rotulo_divida == 'vencimento_apresentacao':
                rotulo = f'COTA {b.vencimento:%m/%Y} - {numero}'
            else:
                raise Bloqueio('ROTULO_NAO_SUPORTADO')
            valores = tuple(base + [cedente, saida.produto, rotulo, numero,
                                   b.vencimento.isoformat(), b.composicao.total_original])
            linha = Linha(valores, ref)
            if estado == 'ELEGIVEL':
                financeiros.append(linha)
            elif not revisao:
                excluidas.append(linha)
        inequivoca = True
        if perfil_id in ('passaredo', 'forest_hill', 'itajuba'):
            inequivoca = len({dados[b.id]['responsavel'] for b in boletos}) == 1
        if any(d['situacao'] == 'nao_elegivel' for d in decisoes) and not unidade_revisao and inequivoca:
            base_cad = base_pessoa(pessoa, cedente, complemento, saida.nome_cedente, endereco)
            detalhe_b1 = None
            if perfil_id == 'terraco_beach_parque':
                pessoal, detalhe_b1 = resolver_linha_cadastral(lote, u, pessoa, decisoes, pessoas_boleto, cad)
                if pessoal is not None:
                    # B1 preserva o nome da unidade e aplica somente contato/documento provados.
                    p = pessoal.model_copy(update={'nome': pessoa.nome})
                    base_cad = base_pessoa(p, cedente, complemento, saida.nome_cedente, endereco)
            extras.append(Linha(tuple(base_cad + [''] * 6),
                {'unidade_id': u.id, 'motivo': 'EXISTE_LANCAMENTO_EXCLUIDO', 'politica_b1': detalhe_b1}))
    repetidas = Counter((r.valores[1], r.valores[28], r.valores[29]) for r in financeiros)
    ambiguas = sum(n for n in repetidas.values() if n > 1)
    if ambiguas:
        ressalvas['PAREAMENTO_INDIVIDUAL_NAO_DEMONSTRADO'] += ambiguas
    # Somente no relatório PRIVADO: permite revisão individual sem publicar IDs.
    projetadas = [{'valores': [format(x, '.2f') if isinstance(x, Decimal) else x for x in r.valores],
                   'referencia': r.referencia} for r in financeiros + extras]
    return Expectativa(financeiros, extras, excluidas, len(lote.boletos), retencoes,
        pendencias, ressalvas, {'lancamentos': referencias, 'revisoes': revisoes,
                               'ressalvas_fonte': dict(motivos), 'politica_cadastral': resumo_cad,
                               'linhas_esperadas': projetadas})


def ler_xlsx(data):
    from openpyxl import load_workbook
    from conversor.domain.template import COLUNAS
    from conversor.domain.canonical import Documento, documento_validado
    from zipfile import ZipFile
    try:
        with ZipFile(BytesIO(data)) as z:
            if (len(z.infolist()) > 1000 or sum(i.file_size for i in z.infolist()) > 100 * 1024 * 1024
                    or any('externallinks/' in n.casefold() or 'vbaproject' in n.casefold() for n in z.namelist())):
                raise Bloqueio('XLSX_INSEGURO')
        w = load_workbook(BytesIO(data), read_only=True, data_only=False, keep_links=False)
        try:
            if 'Dados' not in w.sheetnames:
                raise Bloqueio('XLSX_SEM_DADOS')
            s = w['Dados']
            if s.max_column != 30 or s.max_row > 100000:
                raise Bloqueio('XLSX_FORA_CONTRATO')
            rows = s.iter_rows()
            if tuple(c.value for c in next(rows)) != COLUNAS:
                raise Bloqueio('XLSX_CABECALHO_DIVERGENTE')
            output = []
            for indice, cells in enumerate(rows, 2):
                if len(cells) != 30 or any(c.data_type in ('f', 'e') for c in cells):
                    raise Bloqueio('XLSX_FORMULA_OU_ERRO')
                vals = [c.value if c.value is not None else '' for c in cells]
                if any(not isinstance(v, str) for v in vals[:27]):
                    raise Bloqueio('XLSX_TEXTO_NAO_TEXTUAL')
                if not any(vals):
                    raise Bloqueio('XLSX_LINHA_VAZIA')
                if vals[2]:
                    doc = Documento(tipo='cpf' if len(vals[2]) == 11 else 'cnpj', valor=vals[2])
                    if not documento_validado(doc) or cells[2].number_format != '@':
                        raise Bloqueio('XLSX_DOCUMENTO_INVALIDO')
                financeira = any(v != '' for v in vals[24:])
                if financeira:
                    if (type(vals[27]) is not int or vals[27] < 1 or not isinstance(vals[28], (date, datetime))
                            or type(vals[29]) not in (int, float, Decimal)):
                        raise Bloqueio('XLSX_FINANCEIRO_TIPO_INVALIDO')
                    if isinstance(vals[28], datetime) and vals[28].time() != datetime.min.time():
                        raise Bloqueio('XLSX_FINANCEIRO_TIPO_INVALIDO')
                    valor = Decimal(str(vals[29]))
                    if not valor.is_finite() or valor <= 0 or valor != valor.quantize(Decimal('.01')):
                        raise Bloqueio('XLSX_VALOR_INVALIDO')
                    vals[29] = valor
                    vals[28] = vals[28].date().isoformat() if isinstance(vals[28], datetime) else vals[28].isoformat()
                output.append(Linha(tuple(vals), {'linha_excel': indice}))
            return output
        finally:
            w.close()
    except Bloqueio:
        raise
    except Exception:
        raise Bloqueio('XLSX_INVALIDO') from None


def comparar(esperado, a, b):
    """Counters preservam TODAS as ocorrências. Sem pareamento guloso de pessoas."""
    af = [r for r in a if r.financeira]
    bf = [r for r in b if r.financeira]
    ac = [r for r in a if not r.financeira]
    bc = [r for r in b if not r.financeira]
    divergencias, detalhes = Counter(), []
    def registrar(codigo, n, **privado):
        if n:
            divergencias[codigo] += n
            detalhes.append({'codigo': codigo, 'quantidade': n, **privado})
    registrar('CADASTRAL_INDEVIDA_NO_MODO_A', len(ac))
    ca, cb = Counter(r.valores for r in af), Counter(r.valores for r in bf)
    registrar('MODOS_FINANCEIROS_DIVERGENTES', sum((ca - cb).values()) + sum((cb - ca).values()))
    for modo, rows in (('A', af), ('B', bf)):
        exp = Counter(r.valores for r in esperado.financeiras)
        got = Counter(r.valores for r in rows)
        faltantes, sobras = exp - got, got - exp
        # Quantificar pelo núcleo documental, independentemente das células cadastrais.
        chave = lambda v: (v[1], v[28], v[29])
        ekey = Counter(chave(r.valores) for r in esperado.financeiras)
        gkey = Counter(chave(r.valores) for r in rows)
        registrar('DIVIDA_ELEGIVEL_AUSENTE', sum((ekey - gkey).values()), modo=modo)
        registrar('DIVIDA_NAO_JUSTIFICADA', sum((gkey - ekey).values()), modo=modo)
        for key, n in (gkey - ekey).items():
            if ekey[key]:
                registrar('DUPLICACAO_INDEVIDA', n, modo=modo)
        for key, n in (ekey - gkey).items():
            if ekey[key] > 1 and gkey[key] > 0:
                registrar('OCORRENCIA_PERDIDA', n, modo=modo)
        excluidas = Counter(chave(r.valores) for r in esperado.excluidas)
        registrar('DIVIDA_INELEGIVEL_EXPORTADA', sum(((gkey - ekey) & excluidas).values()), modo=modo)
        # Diagnóstico por célula somente quando a parcela/cedente dá associação única.
        em, gm = defaultdict(list), defaultdict(list)
        for r in esperado.financeiras:
            em[(r.valores[1], r.valores[27])].append(r)
        for r in rows:
            gm[(r.valores[1], r.valores[27])].append(r)
        for key in sorted(em.keys() & gm.keys()):
            if len(em[key]) != 1 or len(gm[key]) != 1:
                continue
            e, g = em[key][0], gm[key][0]
            for col, (ev, gv) in enumerate(zip(e.valores, g.valores)):
                if ev != gv:
                    codigo = ('VALOR_ORIGINAL_DIVERGENTE' if col == 29 else
                              'VENCIMENTO_DIVERGENTE' if col == 28 else
                              'UNIDADE_OU_BLOCO_DIVERGENTE' if col in (1, 6, 24) else
                              'ENDERECO_DIVERGENTE' if col in (4, 5, 7, 8, 9, 10) else
                              'ASSOCIACAO_CADASTRAL_DIVERGENTE' if col == 2 or 11 <= col <= 23 else
                              'IDENTIFICADOR_DIVERGENTE' if col == 26 else 'CELULA_DIVERGENTE')
                    registrar(codigo, 1, modo=modo, coluna=col + 1, esperado=e.referencia, obtido=g.referencia)
        # Uma alteração apenas de bloco/unidade não deve ficar escondida no total.
        sem_unidade = lambda v: tuple(x for i, x in enumerate(v) if i not in (1, 6, 24))
        eunit, gunit = defaultdict(list), defaultdict(list)
        for v in faltantes:
            eunit[sem_unidade(v)].append(v)
        for v in sobras:
            gunit[sem_unidade(v)].append(v)
        for key in eunit.keys() & gunit.keys():
            if len(eunit[key]) == len(gunit[key]) == 1:
                registrar('UNIDADE_OU_BLOCO_DIVERGENTE', min(faltantes[eunit[key][0]], sobras[gunit[key][0]]), modo=modo)
        if faltantes or sobras:
            registrar('LINHA_FINANCEIRA_DIVERGENTE', sum(faltantes.values()) + sum(sobras.values()), modo=modo,
                      faltantes=[r.referencia for r in esperado.financeiras if r.valores in faltantes],
                      excedentes=[r.referencia for r in rows if r.valores in sobras])
    ec, gc = Counter(r.valores for r in esperado.cadastrais), Counter(r.valores for r in bc)
    registrar('CADASTRAL_B_AUSENTE', sum((ec - gc).values()))
    registrar('CADASTRAL_B_NAO_JUSTIFICADA', sum((gc - ec).values()),
              referencias=[r.referencia for r in bc if r.valores in gc - ec])
    return divergencias, detalhes, {
        'exportadas_a': len(af), 'exportadas_b': len(bf), 'cadastrais_b': len(bc),
        'valor_a': format(sum((r.valores[29] for r in af), Decimal(0)), '.2f'),
        'valor_b': format(sum((r.valores[29] for r in bf), Decimal(0)), '.2f')}
