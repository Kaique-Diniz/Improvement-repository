"""Execução transacional de evidências, saída agregada por lista positiva."""
from collections import Counter
from contextlib import redirect_stdout, redirect_stderr
import csv
from io import StringIO
import json
import os
from pathlib import Path
import re

from .documental import DATA_REF, ENDERECO, PERFIS, construir, comparar, ler_xlsx
from .seguranca import (Arquivo, Bloqueio, caminho_estatico, fora_git, gravar_novo,
                        hash_bytes, json_bytes, pasta_saida, verificar_candidata)

ESTADOS = ('APROVADO', 'APROVADO_COM_RESSALVAS', 'DIVERGENTE',
           'EVIDENCIA_INSUFICIENTE', 'ERRO_OPERACIONAL')
HEX = re.compile(r'[0-9a-f]{64}\Z')
# Não refletir mensagens/códigos arbitrários dos leitores, do SO ou do manifesto.
CODIGOS_ERRO = frozenset('''CAMINHO_INACESSIVEL LINK_OU_REPARSE_RECUSADO PAI_NAO_DIRETORIO
ARQUIVO_NAO_REGULAR RAIZ_NAO_DIRETORIO CAMINHO_RELATIVO_INVALIDO AREA_PRIVADA_DENTRO_GIT
FONTE_SUBSTITUIDA FONTE_FORA_RAIZ LIMITE_ARQUIVO_EXCEDIDO FALHA_LEITURA HASH_DIVERGENTE
MANIFESTO_CANDIDATA_INVALIDO ARQUIVO_EXTRA_CANDIDATA NOME_SAIDA_INVALIDO
SAIDA_EXISTENTE_OU_INACESSIVEL MANIFESTO_INVALIDO AREAS_SOBREPOSTAS INTEGRIDADE_FINAL_FALHOU
EXECUCAO_INTERROMPIDA FALHA_PROCESSAMENTO FONTE_OU_CADASTRO_INVALIDO ENDERECO_NAO_COMPROVADO
XLSX_INSEGURO XLSX_SEM_DADOS XLSX_FORA_CONTRATO XLSX_CABECALHO_DIVERGENTE
XLSX_FORMULA_OU_ERRO XLSX_TEXTO_NAO_TEXTUAL XLSX_LINHA_VAZIA XLSX_DOCUMENTO_INVALIDO
XLSX_FINANCEIRO_TIPO_INVALIDO XLSX_VALOR_INVALIDO XLSX_INVALIDO PRIVACIDADE_NAO_COMPROVADA
FONTES_REUTILIZADAS MANIFESTO_EXEMPLO_RECUSADO CANDIDATA_IMPORTADA_DIVERGENTE
'''.split())
CODIGOS_PUBLICOS = CODIGOS_ERRO | frozenset('''EXECUCAO_CONCLUIDA
ORIGEM_FINANCEIRA_NAO_COMPROVADA ORIGEM_CADASTRAL_NAO_COMPROVADA
CADASTRO_OPCIONAL_NAO_FORNECIDO FONTE_COM_REVISAO_CRITICA RESPONSAVEL_NAO_COMPROVADO
LANCAMENTO_COM_REVISAO_DOCUMENTAL PAREAMENTO_INDIVIDUAL_NAO_DEMONSTRADO
RETENCAO_NOMINAL RETENCAO_MULTIPLICIDADE RETENCAO_CONFLITO_DOCUMENTAL RETENCAO_DOCUMENTAL
DOCUMENTO_INVALIDO_NAO_PROMOVIDO REGRESSAO_SEM_REFERENCIA_EXTERNA REGRESSAO_HASH_DIVERGENTE
CHECKPOINT_EXTERNO_DIVERGENTE CADASTRAL_INDEVIDA_NO_MODO_A MODOS_FINANCEIROS_DIVERGENTES
DIVIDA_ELEGIVEL_AUSENTE DIVIDA_NAO_JUSTIFICADA DUPLICACAO_INDEVIDA OCORRENCIA_PERDIDA
DIVIDA_INELEGIVEL_EXPORTADA VALOR_ORIGINAL_DIVERGENTE VENCIMENTO_DIVERGENTE
UNIDADE_OU_BLOCO_DIVERGENTE ENDERECO_DIVERGENTE ASSOCIACAO_CADASTRAL_DIVERGENTE
IDENTIFICADOR_DIVERGENTE CELULA_DIVERGENTE LINHA_FINANCEIRA_DIVERGENTE
CADASTRAL_B_AUSENTE CADASTRAL_B_NAO_JUSTIFICADA
'''.split())


class DescartarSaida:
    def write(self, _):
        return 0
    def flush(self):
        pass


def validar_manifesto(m):
    if (not isinstance(m, dict) or set(m) != {'schema', 'exemplo', 'data_ref', 'area_privada_confirmada', 'raizes', 'perfis'}
            or m.get('schema') != 'REC01@1'
            or m.get('data_ref') != DATA_REF.isoformat() or m.get('exemplo') is not False
            or m.get('area_privada_confirmada') is not True
            or not isinstance(m.get('raizes'), dict) or not m['raizes']
            or not isinstance(m.get('perfis'), list)):
        raise Bloqueio('MANIFESTO_INVALIDO')
    if sorted(x.get('perfil', '') for x in m['perfis']) != sorted(PERFIS):
        raise Bloqueio('MANIFESTO_INVALIDO')
    for k, p in m['raizes'].items():
        if not isinstance(k, str) or not isinstance(p, str) or not Path(p).is_absolute():
            raise Bloqueio('MANIFESTO_INVALIDO')
        fora_git(p)
    for item in m['perfis']:
        if set(item) - {'perfil', 'financeiro', 'cadastro', 'A', 'B', 'endereco', 'regressao', 'checkpoint'}:
            raise Bloqueio('MANIFESTO_INVALIDO')
        for papel in ('financeiro', 'cadastro', 'A', 'B'):
            spec = item.get(papel)
            if papel == 'cadastro' and spec is None:
                continue
            if (not isinstance(spec, dict) or set(spec) != {'raiz', 'arquivo', 'sha256'}
                    or spec['raiz'] not in m['raizes'] or not isinstance(spec['arquivo'], str)
                    or not isinstance(spec['sha256'], str) or not HEX.fullmatch(spec['sha256'])
                    or len(set(spec['sha256'])) == 1):
                raise Bloqueio('MANIFESTO_INVALIDO')
            if any(x in spec['arquivo'].casefold() for x in ('preencher', 'placeholder', '<', '>')):
                raise Bloqueio('MANIFESTO_EXEMPLO_RECUSADO')
        end = item.get('endereco')
        if (not isinstance(end, dict) or set(end) != {'perfil', 'campos', 'confirmado'}
                or end['perfil'] != item['perfil'] or end['confirmado'] is not True
                or not isinstance(end['campos'], dict) or set(end['campos']) != set(ENDERECO)
                or any(not isinstance(v, str) or not v.strip() for v in end['campos'].values())):
            raise Bloqueio('ENDERECO_NAO_COMPROVADO')
        if any('preencher' in v.casefold() or '<' in v for v in end['campos'].values()):
            raise Bloqueio('MANIFESTO_EXEMPLO_RECUSADO')
        reg = item.get('regressao')
        if reg is not None and (not isinstance(reg, dict) or set(reg) != {'tipo', 'A', 'B'}
                or reg['tipo'] != 'HASH_REFERENCIA_EXTERNA'
                or any(not isinstance(reg[k], str) or not HEX.fullmatch(reg[k])
                       or len(set(reg[k])) == 1 for k in ('A', 'B'))):
            raise Bloqueio('MANIFESTO_INVALIDO')
        cp = item.get('checkpoint')
        if cp is not None:
            from decimal import Decimal, InvalidOperation
            try:
                if (set(cp) != {'dividas', 'cadastrais_b', 'valor_original'}
                        or any(type(cp[k]) is not int or cp[k] < 0 for k in ('dividas', 'cadastrais_b'))
                        or not isinstance(cp['valor_original'], str)
                        or not Decimal(cp['valor_original']).is_finite()):
                    raise ValueError
            except (TypeError, ValueError, InvalidOperation):
                raise Bloqueio('MANIFESTO_INVALIDO') from None
    return m


def estado(erro, divergencias, pendencias, ressalvas):
    if erro:
        return 'ERRO_OPERACIONAL'
    if divergencias:
        return 'DIVERGENTE'
    if pendencias:
        return 'EVIDENCIA_INSUFICIENTE'
    return 'APROVADO_COM_RESSALVAS' if ressalvas else 'APROVADO'


def inspecionar_publico(relatorios):
    """Validação por gramática de campos/valores; dados privados não são serializados."""
    # Códigos aceitam só letras/underscore; nenhum caminho, nome livre, contato ou ID.
    def codigo(v):
        return isinstance(v, str) and v in CODIGOS_PUBLICOS
    def contagens(d):
        return isinstance(d, dict) and all(codigo(k) and type(v) is int and 0 <= v <= 10000000 for k, v in d.items())
    def valor(v):
        return isinstance(v, str) and bool(re.fullmatch(r'-?[0-9]{1,12}\.[0-9]{2}', v))
    resumo, divs, integ, execucao = relatorios
    if set(resumo) != {'schema', 'data_ref', 'estado', 'homologacao_operacional', 'perfis'}:
        raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
    if (resumo['schema'] != 'REC01@1' or resumo['data_ref'] != DATA_REF.isoformat()
            or resumo['estado'] not in ESTADOS or resumo['homologacao_operacional'] is not False):
        raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
    campos = {'perfil', 'estado', 'documental', 'regressao', 'fontes_completas', 'originais',
              'elegiveis', 'nao_elegiveis', 'exportadas_a', 'exportadas_b', 'cadastrais_b',
              'valor_esperado', 'valor_a', 'valor_b', 'divergencias', 'retencoes', 'pendencias', 'ressalvas'}
    for r in resumo['perfis']:
        if set(r) != campos or r['perfil'] not in PERFIS or type(r['fontes_completas']) is not bool:
            raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
        if any(r[k] not in ESTADOS for k in ('estado', 'documental', 'regressao')):
            raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
        if any(type(r[k]) is not int or not 0 <= r[k] <= 10000000 for k in
               ('originais', 'elegiveis', 'nao_elegiveis', 'exportadas_a', 'exportadas_b', 'cadastrais_b')):
            raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
        if any(not valor(r[k]) for k in ('valor_esperado', 'valor_a', 'valor_b')):
            raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
        if any(not contagens(r[k]) for k in ('divergencias', 'retencoes', 'pendencias', 'ressalvas')):
            raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
    if not contagens(divs):
        raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
    if (set(integ) != {'antes', 'depois', 'arquivos_lidos', 'arquivos_candidata', 'candidata_manifesto_sha256'}
            or any(type(integ[k]) is not bool for k in ('antes', 'depois'))
            or any(type(integ[k]) is not int for k in ('arquivos_lidos', 'arquivos_candidata'))
            or not HEX.fullmatch(integ['candidata_manifesto_sha256'])):
        raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')
    if (set(execucao) != {'schema', 'estado', 'codigo', 'privacidade_inspecionada', 'seguranca_windows', 'execucao_nativa'}
            or execucao['schema'] != 'REC01@1' or execucao['estado'] not in ESTADOS
            or not codigo(execucao['codigo']) or execucao['privacidade_inspecionada'] is not True
            or execucao['seguranca_windows'] != 'NAO_HOMOLOGADA'
            or execucao['execucao_nativa'] not in ('WINDOWS', 'LINUX', 'OUTRO')):
        raise Bloqueio('PRIVACIDADE_NAO_COMPROVADA')


def executar(m, candidata, versao, destino, *, decoder=construir, transicao=lambda: None,
             arquivos_iniciais=()):
    """API interna testável; CLI fixa a candidata auditada, sem flags de bypass."""
    arquivos = list(arquivos_iniciais)
    privados, results, erro = [], [], None
    integ = {'antes': False, 'depois': False, 'arquivos_lidos': 0,
             'arquivos_candidata': len(versao['arquivos']),
             'candidata_manifesto_sha256': hash_bytes(json_bytes(versao))}
    try:
        validar_manifesto(m)
        candidata = caminho_estatico(candidata)
        verificar_candidata(candidata, versao)
        usados = set()
        for item in sorted(m['perfis'], key=lambda i: i['perfil']):
            perfil, lidos = item['perfil'], {}
            for papel in ('financeiro', 'cadastro', 'A', 'B'):
                spec = item.get(papel)
                if spec is None:
                    lidos[papel] = None
                    continue
                f = Arquivo.ler(m['raizes'][spec['raiz']], spec['arquivo'], spec['sha256'])
                # Fontes originais reutilizadas entre condomínios são ambiguidade, não atalho.
                if papel in ('financeiro', 'cadastro'):
                    if f.digest in usados:
                        raise Bloqueio('FONTES_REUTILIZADAS')
                    usados.add(f.digest)
                arquivos.append(f)
                lidos[papel] = f
            with redirect_stdout(DescartarSaida()), redirect_stderr(DescartarSaida()):
                try:
                    exp = decoder(perfil, lidos['financeiro'].conteudo,
                                  lidos['cadastro'].conteudo if lidos['cadastro'] else None,
                                  item['endereco']['campos'])
                except Bloqueio:
                    raise
                except Exception:
                    raise Bloqueio('FONTE_OU_CADASTRO_INVALIDO') from None
                a, b = ler_xlsx(lidos['A'].conteudo), ler_xlsx(lidos['B'].conteudo)
            div, detalhe, obtido = comparar(exp, a, b)
            cp = item.get('checkpoint')
            if cp is not None:
                from decimal import Decimal
                observado = (len(exp.financeiras), len(exp.cadastrais),
                             sum((r.valores[29] for r in exp.financeiras), Decimal(0)))
                if observado != (cp['dividas'], cp['cadastrais_b'], Decimal(cp['valor_original'])):
                    div['CHECKPOINT_EXTERNO_DIVERGENTE'] += 1
            reg = item.get('regressao')
            regressao = ('APROVADO' if all(lidos[k].digest == reg[k] for k in ('A', 'B')) else 'DIVERGENTE') if reg else 'EVIDENCIA_INSUFICIENTE'
            documental = estado(None, div, exp.pendencias, exp.ressalvas)
            pend = exp.pendencias.copy()
            if regressao == 'EVIDENCIA_INSUFICIENTE':
                pend['REGRESSAO_SEM_REFERENCIA_EXTERNA'] += 1
            elif regressao == 'DIVERGENTE':
                div['REGRESSAO_HASH_DIVERGENTE'] += 1
            from decimal import Decimal
            r = dict(perfil=perfil, estado=estado(None, div, pend, exp.ressalvas), documental=documental,
                     regressao=regressao, fontes_completas=not bool(exp.pendencias), originais=exp.originais,
                     elegiveis=len(exp.financeiras), nao_elegiveis=len(exp.excluidas), **obtido,
                     valor_esperado=format(sum((r.valores[29] for r in exp.financeiras), Decimal(0)), '.2f'),
                     divergencias=dict(div), retencoes=dict(exp.retencoes), pendencias=dict(pend), ressalvas=dict(exp.ressalvas))
            results.append(r)
            privados.append({'perfil': perfil, 'fontes': {k: {'sha256': f.digest, 'caminho': str(f.caminho)}
                for k, f in lidos.items() if f}, 'documental': exp.privado, 'diferencas': detalhe})
        integ['antes'] = True  # Todos os hashes iniciais exigidos foram conferidos.
        transicao()  # Ponto de falha controlado usado pelos testes, inexistente na CLI.
    except KeyboardInterrupt:
        erro = 'EXECUCAO_INTERROMPIDA'
    except Bloqueio as e:
        erro = e.codigo if e.codigo in CODIGOS_ERRO else 'FALHA_PROCESSAMENTO'
    except Exception:
        erro = 'FALHA_PROCESSAMENTO'
    finally:
        try:
            for f in arquivos:
                f.conferir()
            verificar_candidata(candidata, versao)
            integ['depois'] = integ['antes']
        except Exception:
            erro = 'INTEGRIDADE_FINAL_FALHOU'
        integ['arquivos_lidos'] = len(arquivos)
    if erro:
        for perfil in PERFIS:
            if not any(r['perfil'] == perfil for r in results):
                results.append(dict(perfil=perfil, estado='ERRO_OPERACIONAL', documental='ERRO_OPERACIONAL',
                    regressao='ERRO_OPERACIONAL', fontes_completas=False, originais=0, elegiveis=0,
                    nao_elegiveis=0, exportadas_a=0, exportadas_b=0, cadastrais_b=0,
                    valor_esperado='0.00', valor_a='0.00', valor_b='0.00', divergencias={}, retencoes={},
                    pendencias={}, ressalvas={}))
        for r in results:
            r['estado'] = r['documental'] = r['regressao'] = 'ERRO_OPERACIONAL'
            r['pendencias'][erro] = 1
    results.sort(key=lambda r: r['perfil'])
    global_state = ('ERRO_OPERACIONAL' if erro else
                    next((s for s in ('DIVERGENTE', 'EVIDENCIA_INSUFICIENTE', 'APROVADO_COM_RESSALVAS')
                          if any(r['estado'] == s for r in results)), 'APROVADO'))
    resumo = {'schema': 'REC01@1', 'data_ref': DATA_REF.isoformat(), 'estado': global_state,
              'homologacao_operacional': False, 'perfis': results}
    divs = Counter()
    for r in results:
        divs.update(r['divergencias'])
    execucao = {'schema': 'REC01@1', 'estado': global_state, 'codigo': erro or 'EXECUCAO_CONCLUIDA',
                'privacidade_inspecionada': True, 'seguranca_windows': 'NAO_HOMOLOGADA',
                'execucao_nativa': 'WINDOWS' if os.name == 'nt' else 'LINUX' if os.name == 'posix' else 'OUTRO'}
    inspecionar_publico((resumo, dict(divs), integ, execucao))
    privado = destino / 'privado'
    publico = destino / 'compartilhavel'
    privado.mkdir(mode=0o700)
    publico.mkdir(mode=0o700)
    gravar_novo(privado / 'REC01_detalhes.json', json_bytes({'perfis': privados}))
    for nome, data in (('resumo', resumo), ('divergencias_agregadas', dict(divs)),
                       ('integridade', integ), ('execucao', execucao)):
        gravar_novo(publico / f'REC01_{nome}.json', json_bytes(data))
    buffer = StringIO(newline='')
    writer = csv.writer(buffer, lineterminator='\n')
    writer.writerow(('perfil', 'documental', 'regressao', 'estado', 'elegiveis', 'cadastrais_b', 'valor_esperado'))
    for r in results:
        writer.writerow([r[k] for k in ('perfil', 'documental', 'regressao', 'estado', 'elegiveis', 'cadastrais_b', 'valor_esperado')])
    gravar_novo(publico / 'REC01_matriz.csv', buffer.getvalue().encode('utf-8'))
    return resumo
