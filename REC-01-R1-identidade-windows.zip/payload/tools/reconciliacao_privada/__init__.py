"""REC-01: auditoria externa, somente leitura sobre fontes e candidata."""
