"""CLI REC-01: exclusivamente agregados no terminal, nenhuma instalação."""
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
if __package__ in (None, ''):
    sys.path.insert(0, str(Path(__file__).absolute().parents[2]))

from tools.reconciliacao_privada.seguranca import (Arquivo, Bloqueio, caminho_estatico,
    fora_git, pasta_saida, verificar_candidata)
from tools.reconciliacao_privada.auditoria import executar, validar_manifesto


class ArgumentosSeguros(argparse.ArgumentParser):
    def error(self, _message):
        # argparse padrao pode repetir argumentos contendo caminhos/dados privados.
        print('{"estado":"ERRO_OPERACIONAL","codigo":"ARGUMENTOS_REC01_INVALIDOS"}')
        raise SystemExit(2)


def main(argv=None):
    p = ArgumentosSeguros(description='REC-01: reconciliacao privada, sem homologacao automatica.')
    p.add_argument('--manifesto', required=True, type=Path)
    p.add_argument('--candidata', required=True, type=Path)
    p.add_argument('--saida-pai', required=True, type=Path)
    p.add_argument('--execucao', required=True, help='Nome de pasta nova; nunca reutilizada.')
    args = p.parse_args(argv)
    try:
        if sys.version_info[:2] != (3, 12):
            raise Bloqueio('PYTHON_312_OBRIGATORIO')
        candidata = caminho_estatico(args.candidata)
        versao = json.loads(Path(__file__).with_name('CANDIDATA_D2_SHA256.json').read_text(encoding='utf-8'))
        if versao['base'] != '770d062d29c4361d6932592883df9339bb4089bc' or len(versao['arquivos']) != 454:
            raise Bloqueio('MANIFESTO_CANDIDATA_INVALIDO')
        verificar_candidata(candidata, versao)
        manifesto = caminho_estatico(args.manifesto, arquivo=True)
        fora_git(manifesto.parent)
        arquivo_m = Arquivo.ler(manifesto.parent, manifesto.name, limite=1024 * 1024)
        m = validar_manifesto(json.loads(arquivo_m.conteudo.decode('utf-8-sig')))
        saida_pai = fora_git(args.saida_pai)
        areas = [caminho_estatico(v) for v in m['raizes'].values()]
        for area in areas + [manifesto.parent, saida_pai]:
            if area.is_relative_to(candidata) or candidata.is_relative_to(area):
                raise Bloqueio('AREAS_SOBREPOSTAS')
        if any(saida_pai.is_relative_to(area) or area.is_relative_to(saida_pai) for area in areas):
            raise Bloqueio('AREAS_SOBREPOSTAS')
        destino = pasta_saida(saida_pai, args.execucao)
        # Nem ler .pyc preexistente da candidata, nem gravar caches dentro dela.
        sys.pycache_prefix = str(destino / 'cache_nao_criado')
        sys.path.insert(0, str(candidata / 'src'))
        import conversor
        from conversor.web import service
        if (not Path(service.__file__).absolute().is_relative_to(candidata / 'src')
                or not Path(conversor.__file__).absolute().is_relative_to(candidata / 'src')):
            raise Bloqueio('CANDIDATA_IMPORTADA_DIVERGENTE')
        resumo = executar(m, candidata, versao, destino, arquivos_iniciais=(arquivo_m,))
        print(json.dumps({'etapa': 'REC01', 'estado': resumo['estado'], 'perfis_processados': len(resumo['perfis']),
                          'homologacao_operacional': False}, sort_keys=True))
        return 0 if resumo['estado'] in ('APROVADO', 'APROVADO_COM_RESSALVAS') else 2
    except KeyboardInterrupt:
        print('{"estado":"ERRO_OPERACIONAL","codigo":"EXECUCAO_INTERROMPIDA"}')
        return 2
    except Bloqueio as e:
        # Todos os Bloqueio originados nesta CLI têm código constante, sem interpolação.
        print(json.dumps({'estado': 'ERRO_OPERACIONAL', 'codigo': e.codigo}))
        return 2
    except Exception:
        print('{"estado":"ERRO_OPERACIONAL","codigo":"FALHA_EXECUCAO_REC01"}')
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
