"""Somente documentos inteiramente sintéticos; sem depender de fontes privadas."""
from collections import Counter
from copy import deepcopy
from dataclasses import replace
from datetime import datetime, timedelta
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import subprocess
import sys

from openpyxl import Workbook, load_workbook
import pytest

from tools.reconciliacao_privada import auditoria as a
from tools.reconciliacao_privada import documental as d
from tools.reconciliacao_privada import seguranca as s
from tests.int02.fixtures import caso, homologar
from tests.passaredo import fixtures as tab
from tests.oma import fixtures as oma
from tests.vero import fixtures as vero
from tests.itajuba import fixtures as itj
from tests.beach_parque import fixtures as bpq
from conversor.web.service import analisar, PedidoDiagnostico
from conversor.domain.template import COLUNAS

END = dict(logradouro='Rua Inteiramente Sintetica', numero='10', cep='01000000',
           bairro='Bairro Ficticio', cidade='Cidade Ficticia', uf='SP')


def link_sintetico(alvo, origem, *, diretorio=False):
    try:
        alvo.symlink_to(origem, target_is_directory=diretorio)
    except OSError as e:
        if os.name == 'nt' and getattr(e, 'winerror', None) == 1314:
            pytest.skip('REC01_SYMLINK_SEM_PRIVILEGIO_CONTROLE_NAO_VALIDADO')
        raise


@pytest.fixture(autouse=True)
def referencia(monkeypatch):
    for mod in (tab, oma, vero, itj, bpq):
        monkeypatch.setattr(mod, 'REF', d.DATA_REF)


def fonte(perfil, monkeypatch, **kwargs):
    c = caso(perfil, **kwargs)
    homologar(monkeypatch, [c])
    return c


def excel(rows):
    w = Workbook(); sh = w.active; sh.title = 'Dados'; sh.append(COLUNAS)
    for row in rows:
        vals = list(row.valores)
        if row.financeira:
            vals[28] = datetime.fromisoformat(vals[28])
        sh.append(vals)
        for cell in sh[sh.max_row]:
            if isinstance(cell.value, str):
                cell.data_type = 's'
        sh.cell(sh.max_row, 3).number_format = '@'
    data = BytesIO(); w.save(data); w.close()
    return data.getvalue()


def alterar(rows, indice, coluna, valor):
    r = list(rows)
    vals = list(r[indice].valores); vals[coluna] = valor
    r[indice] = d.Linha(tuple(vals), r[indice].referencia)
    return r


@pytest.mark.parametrize('perfil', d.PERFIS)
def test_seis_perfis_leitores_originais_com_fontes_sinteticas(perfil, monkeypatch):
    c = fonte(perfil, monkeypatch)
    exp = d.construir(perfil, c.financeiro, c.cadastro, END)
    assert exp.originais == 3 and len(exp.financeiras) == 1 and len(exp.cadastrais) == 1
    assert len(exp.excluidas) == 2 and not exp.pendencias
    aa, bb = d.ler_xlsx(excel(exp.financeiras)), d.ler_xlsx(excel(exp.financeiras + exp.cadastrais))
    dif, _, out = d.comparar(exp, aa, bb)
    assert not dif and out['exportadas_a'] == 1 and out['cadastrais_b'] == 1
    assert exp.financeiras[0].valores[29] == Decimal(c.valor)
    assert exp.financeiras[0].valores[28] == (d.DATA_REF - timedelta(days=c.prazo+1)).isoformat()


@pytest.mark.parametrize('perfil', d.PERFIS)
@pytest.mark.parametrize('offset,estado', [(-1, 'PRAZO_NAO_ATINGIDO'), (0, 'PRAZO_NAO_ATINGIDO'), (1, 'ELEGIVEL')])
def test_limites_exatos(perfil, offset, estado):
    venc = d.DATA_REF - timedelta(days=d.PRAZOS[perfil] + offset)
    assert d.elegibilidade(perfil, venc, Decimal('1.01')) == estado


def test_itajuba_escopo_anterior_nao_vira_exclusao_comprovada():
    assert d.elegibilidade('itajuba', datetime(2023,11,30).date(), Decimal(1)) == 'REVISAO_ESCOPO_DOCUMENTAL'
    assert d.elegibilidade('passaredo', datetime(2023,11,30).date(), Decimal(1)) == 'ELEGIVEL'


@pytest.fixture
def exp(monkeypatch):
    c = fonte('passaredo', monkeypatch)
    return d.construir(c.perfil, c.financeiro, c.cadastro, END)


@pytest.mark.parametrize('coluna,valor,codigo', [
    (29, Decimal('100.11'), 'VALOR_ORIGINAL_DIVERGENTE'),
    (28, '2026-09-08', 'VENCIMENTO_DIVERGENTE'),
    (6, 'UNIDADE_SINTETICA_ERRADA', 'UNIDADE_OU_BLOCO_DIVERGENTE'),
    (1, 'CEDENTE_SINTETICO_ERRADO', 'UNIDADE_OU_BLOCO_DIVERGENTE'),
    (2, '', 'ASSOCIACAO_CADASTRAL_DIVERGENTE'),
    (11, '99', 'ASSOCIACAO_CADASTRAL_DIVERGENTE'),
    (21, 'outro@example.invalid', 'ASSOCIACAO_CADASTRAL_DIVERGENTE'),
    (4, 'Endereco pessoal indevido', 'ENDERECO_DIVERGENTE'),
    (26, 'IDENTIFICADOR_ERRADO', 'IDENTIFICADOR_DIVERGENTE'),
])
def test_alteracao_celula_detectada(exp, coluna, valor, codigo):
    bad = alterar(exp.financeiras, 0, coluna, valor)
    dif, _, _ = d.comparar(exp, bad, bad + exp.cadastrais)
    assert dif[codigo] and dif['LINHA_FINANCEIRA_DIVERGENTE']


def test_omissao_acrescimo_e_inelegivel(exp):
    dif, _, _ = d.comparar(exp, [], exp.financeiras + exp.cadastrais)
    assert dif['DIVIDA_ELEGIVEL_AUSENTE'] == 1
    dif, _, _ = d.comparar(exp, exp.financeiras + exp.excluidas[:1], exp.financeiras + exp.cadastrais)
    assert dif['DIVIDA_INELEGIVEL_EXPORTADA'] == 1
    dif, _, _ = d.comparar(exp, exp.financeiras * 2, exp.financeiras + exp.cadastrais)
    assert dif['DUPLICACAO_INDEVIDA'] == 1


@pytest.mark.parametrize('perfil', d.PERFIS)
def test_duplicatas_legitimas_contadas_ambiguidade_explicita(perfil, monkeypatch):
    prazo = d.PRAZOS[perfil]
    c = fonte(perfil, monkeypatch, dias=(prazo+1, prazo+1, prazo))
    exp = d.construir(perfil, c.financeiro, c.cadastro, END)
    assert len(exp.financeiras) == 2
    assert exp.ressalvas['PAREAMENTO_INDIVIDUAL_NAO_DEMONSTRADO'] == 2
    assert not d.comparar(exp, exp.financeiras, exp.financeiras + exp.cadastrais)[0]
    assert d.comparar(exp, exp.financeiras[:1], exp.financeiras + exp.cadastrais)[0]['OCORRENCIA_PERDIDA'] == 1


def test_b_extra_indevida_e_modos_trocados(exp):
    dif, _, _ = d.comparar(exp, exp.financeiras, exp.financeiras + exp.cadastrais * 2)
    assert dif['CADASTRAL_B_NAO_JUSTIFICADA'] == 1
    dif, _, _ = d.comparar(exp, exp.financeiras + exp.cadastrais, exp.financeiras)
    assert dif['CADASTRAL_INDEVIDA_NO_MODO_A'] == 1 and dif['CADASTRAL_B_AUSENTE'] == 1
    changed = alterar(exp.financeiras, 0, 3, 'Pessoa Ficticia Trocada')
    assert d.comparar(exp, exp.financeiras, changed + exp.cadastrais)[0]['MODOS_FINANCEIROS_DIVERGENTES']


@pytest.mark.parametrize('perfil', d.PERFIS)
@pytest.mark.parametrize('situacao', ['divergente', 'sem_cadastro', 'invalido', 'multiplo'])
def test_retencao_correta_e_associacao_indevida(perfil, situacao, monkeypatch):
    c = fonte(perfil, monkeypatch,
        nome='Pessoa Ficticia Alfa E Pessoa Ficticia Beta' if situacao == 'multiplo' else 'Pessoa Integralmente Ficticia',
        nome_cad='Outra Pessoa Ficticia' if situacao == 'divergente' else
                 'Pessoa Ficticia Alfa E Pessoa Ficticia Beta' if situacao == 'multiplo' else 'Pessoa Integralmente Ficticia',
        documento='00000000000' if situacao == 'invalido' else '00000000191')
    exp = d.construir(perfil, c.financeiro, None if situacao == 'sem_cadastro' else c.cadastro, END)
    assert len(exp.financeiras) == 1 and exp.financeiras[0].valores[2] == ''
    assert not d.comparar(exp, exp.financeiras, exp.financeiras + exp.cadastrais)[0]
    bad = alterar(exp.financeiras, 0, 2, '00000000191')
    assert d.comparar(exp, bad, bad + exp.cadastrais)[0]['ASSOCIACAO_CADASTRAL_DIVERGENTE']


def test_cadastro_cruzado_recusado(monkeypatch):
    c, outro = caso('passaredo'), caso('forest_hill')
    homologar(monkeypatch, [c, outro])
    with pytest.raises(Exception):
        d.construir(c.perfil, c.financeiro, outro.cadastro, END)


@pytest.mark.parametrize('modo', ['formula', 'documento_numerico', 'valor_cadastral', 'coluna_extra'])
def test_xlsx_invalido_recusado(exp, modo):
    w = load_workbook(BytesIO(excel(exp.financeiras + exp.cadastrais)))
    sh = w['Dados']
    if modo == 'formula': sh.cell(2, 4).value = '=1+1'
    if modo == 'documento_numerico': sh.cell(2, 3).value = 191
    if modo == 'valor_cadastral': sh.cell(3, 30).value = 0
    if modo == 'coluna_extra': sh.cell(1, 31).value = 'INDEVIDA'
    out = BytesIO(); w.save(out); w.close()
    with pytest.raises(s.Bloqueio): d.ler_xlsx(out.getvalue())


@pytest.fixture
def rodada(tmp_path, monkeypatch):
    priv = tmp_path / 'Privado com acentos ç'; priv.mkdir()
    cand = tmp_path / 'candidata'; cand.mkdir(); (cand / 'codigo.py').write_bytes(b'PASSIVO=1\n')
    versao = {'arquivos': {'codigo.py': s.hash_bytes(b'PASSIVO=1\n')}}
    m = {'schema': 'REC01@1', 'exemplo': False, 'data_ref': '2026-11-09',
         'area_privada_confirmada': True, 'raizes': {'fontes': str(priv)}, 'perfis': []}
    for perfil in d.PERFIS:
        c = fonte(perfil, monkeypatch)
        exp = d.construir(perfil, c.financeiro, c.cadastro, END)
        item = {'perfil': perfil, 'endereco': {'perfil': perfil, 'campos': END.copy(), 'confirmado': True},
                'regressao': {'tipo': 'HASH_REFERENCIA_EXTERNA'}}
        for papel, raw in (('financeiro', c.financeiro), ('cadastro', c.cadastro),
                           ('A', excel(exp.financeiras)), ('B', excel(exp.financeiras + exp.cadastrais))):
            nome = f'{perfil}-{papel}.bin'
            (priv / nome).write_bytes(raw)
            item[papel] = {'raiz': 'fontes', 'arquivo': nome, 'sha256': s.hash_bytes(raw)}
            if papel in ('A', 'B'): item['regressao'][papel] = s.hash_bytes(raw)
        m['perfis'].append(item)
    return m, cand, versao


def executar_rodada(rodada, tmp_path, nome='saida', **kw):
    dest = tmp_path / nome; dest.mkdir()
    return a.executar(*rodada, dest, **kw), dest


def test_integracao_completa_determinismo_privacidade(rodada, tmp_path):
    um, p = executar_rodada(rodada, tmp_path, 'um')
    dois, q = executar_rodada(rodada, tmp_path, 'dois')
    assert um['estado'] == dois['estado'] == 'APROVADO'
    assert len(um['perfis']) == 6
    for f in (p / 'compartilhavel').iterdir():
        assert f.read_bytes() == (q / 'compartilhavel' / f.name).read_bytes()
        txt = f.read_text(encoding='utf8')
        assert 'Pessoa' not in txt and 'Rua ' not in txt and str(tmp_path) not in txt
        assert 'example.invalid' not in txt and '00000000191' not in txt and '.bin' not in txt
    assert 'Pessoa' in (p / 'privado/REC01_detalhes.json').read_text(encoding='utf8')


@pytest.mark.parametrize('modo', ['input', 'candidata', 'interrupcao'])
def test_alteracao_durante_execucao_e_interrupcao(rodada, tmp_path, modo):
    def transicao():
        if modo == 'interrupcao': raise KeyboardInterrupt
        alvo = (Path(rodada[0]['raizes']['fontes']) / rodada[0]['perfis'][0]['financeiro']['arquivo']
                if modo == 'input' else rodada[1] / 'codigo.py')
        alvo.write_bytes(b'ALTERADO APENAS NO TESTE SINTETICO')
    result, dest = executar_rodada(rodada, tmp_path, transicao=transicao)
    assert result['estado'] == 'ERRO_OPERACIONAL'
    assert all(r['estado'] == 'ERRO_OPERACIONAL' for r in result['perfis'])
    status = json.loads((dest / 'compartilhavel/REC01_execucao.json').read_text(encoding='utf8'))
    assert status['codigo'] == ('EXECUCAO_INTERROMPIDA' if modo == 'interrupcao' else 'INTEGRIDADE_FINAL_FALHOU')


def test_candidata_diferente_antes_processar(rodada, tmp_path):
    (rodada[1] / 'codigo.py').write_bytes(b'alterado')
    result, dest = executar_rodada(rodada, tmp_path)
    assert result['estado'] == 'ERRO_OPERACIONAL'
    integ = json.loads((dest / 'compartilhavel/REC01_integridade.json').read_text(encoding='utf8'))
    assert not integ['antes'] and not integ['depois']


def test_falta_regressao_nao_aprova_globalmente(rodada, tmp_path):
    del rodada[0]['perfis'][0]['regressao']
    r, _ = executar_rodada(rodada, tmp_path)
    assert r['estado'] == 'EVIDENCIA_INSUFICIENTE'
    perfil = next(p for p in r['perfis'] if p['perfil'] == rodada[0]['perfis'][0]['perfil'])
    assert perfil['documental'] == 'APROVADO' and perfil['regressao'] == 'EVIDENCIA_INSUFICIENTE'


def test_checkpoint_nao_alimenta_esperado(rodada, tmp_path):
    rodada[0]['perfis'][0]['checkpoint'] = {'dividas': 99999, 'cadastrais_b': 42, 'valor_original': '0.01'}
    r, _ = executar_rodada(rodada, tmp_path)
    assert r['estado'] == 'DIVERGENTE'
    p = next(p for p in r['perfis'] if p['perfil'] == rodada[0]['perfis'][0]['perfil'])
    assert p['elegiveis'] == 1 and p['divergencias']['CHECKPOINT_EXTERNO_DIVERGENTE'] == 1


@pytest.mark.parametrize('modo', ['falta', 'fora', 'placeholder', 'endereco', 'exemplo'])
def test_manifesto_negativo(rodada, tmp_path, modo):
    m, _, _ = rodada
    if modo == 'falta': m['perfis'][0]['A']['arquivo'] = 'NAO_EXISTE.xlsx'
    if modo == 'fora': m['perfis'][0]['A']['arquivo'] = '../fora.xlsx'
    if modo == 'placeholder': m['perfis'][0]['financeiro']['sha256'] = '0' * 64
    if modo == 'endereco': m['perfis'][0]['endereco']['perfil'] = 'outro'
    if modo == 'exemplo': m['exemplo'] = True
    r, _ = executar_rodada(rodada, tmp_path)
    assert r['estado'] == 'ERRO_OPERACIONAL' and len(r['perfis']) == 6


@pytest.mark.parametrize('tipo', ['folha', 'pai', 'quebrado'])
def test_links_inseguros_recusados(tmp_path, tipo):
    root = tmp_path / 'root'; root.mkdir()
    fora = tmp_path / 'fora'; fora.mkdir(); (fora / 'arquivo').write_bytes(b'sintetico')
    if tipo == 'pai':
        link_sintetico(root / 'link', fora, diretorio=True); nome = 'link/arquivo'
    else:
        link_sintetico(root / 'link', fora / ('inexistente' if tipo == 'quebrado' else 'arquivo')); nome = 'link'
    with pytest.raises(s.Bloqueio, match='LINK_OU_REPARSE_RECUSADO'):
        s.Arquivo.ler(root, nome)


def test_reparse_recusado_por_atributo(monkeypatch, tmp_path):
    real = Path.lstat
    class Attr:
        def __init__(self, st):
            self.st_mode = st.st_mode
            self.st_file_attributes = 0x400
    monkeypatch.setattr(Path, 'lstat', lambda p: Attr(real(p)) if p == tmp_path else real(p))
    with pytest.raises(s.Bloqueio, match='LINK_OU_REPARSE_RECUSADO'): s.caminho_estatico(tmp_path)


def test_git_danificado_e_bare_recusados(tmp_path):
    root = tmp_path / 'repo'; root.mkdir(); (root / '.git').mkdir()
    with pytest.raises(s.Bloqueio, match='AREA_PRIVADA_DENTRO_GIT'): s.fora_git(root)
    bare = tmp_path / 'bare'; bare.mkdir(); (bare / 'objects').mkdir(); (bare / 'refs').mkdir()
    with pytest.raises(s.Bloqueio): s.fora_git(bare)


def test_saida_existente_preservada(tmp_path):
    out = s.pasta_saida(tmp_path, 'nova'); (out / 'preservado').write_bytes(b'intacto')
    with pytest.raises(s.Bloqueio): s.pasta_saida(tmp_path, 'nova')
    assert (out / 'preservado').read_bytes() == b'intacto'


def test_erro_sem_dados_privados(rodada, tmp_path, capsys):
    def falhar(*_):
        print('PESSOA_PRIVADA 00000000191 segredo@example.invalid')
        print('CAMINHO_PRIVADO', file=sys.stderr)
        raise RuntimeError('PESSOA_PRIVADA 00000000191')
    r, dest = executar_rodada(rodada, tmp_path, decoder=falhar)
    assert r['estado'] == 'ERRO_OPERACIONAL'
    captured = capsys.readouterr()
    assert not captured.out and not captured.err
    for p in (dest / 'compartilhavel').iterdir():
        assert 'PESSOA_PRIVADA' not in p.read_text(encoding='utf8')


def test_inspecao_privacidade_recusa_injecao(rodada, tmp_path):
    _, dest = executar_rodada(rodada, tmp_path)
    pub = dest / 'compartilhavel'
    vals = [json.loads((pub / f'REC01_{n}.json').read_text(encoding='utf8'))
            for n in ('resumo', 'divergencias_agregadas', 'integridade', 'execucao')]
    vals[0]['perfis'][0]['caminho_privado'] = 'C:/Dados privados'
    with pytest.raises(s.Bloqueio, match='PRIVACIDADE_NAO_COMPROVADA'): a.inspecionar_publico(vals)


def test_inspecao_recusa_nome_disfarcado_de_codigo(rodada, tmp_path):
    _, dest = executar_rodada(rodada, tmp_path)
    pub = dest / 'compartilhavel'
    vals = [json.loads((pub / f'REC01_{n}.json').read_text(encoding='utf8'))
            for n in ('resumo', 'divergencias_agregadas', 'integridade', 'execucao')]
    vals[0]['perfis'][0]['pendencias']['PESSOA_INTEGRALMENTE_FICTICIA'] = 1
    with pytest.raises(s.Bloqueio, match='PRIVACIDADE_NAO_COMPROVADA'): a.inspecionar_publico(vals)


def test_fonte_nova_sem_hash_catalogado_nao_aprova(monkeypatch):
    from conversor.web.service import PERFIS as CONFIG
    c = fonte('passaredo', monkeypatch)
    monkeypatch.setitem(CONFIG['passaredo']['fontes_homologacao_sha256'], 'inadimplencia', '1' * 64)
    exp = d.construir(c.perfil, c.financeiro, c.cadastro, END)
    assert exp.pendencias['ORIGEM_FINANCEIRA_NAO_COMPROVADA'] == 1
    assert a.estado(None, {}, exp.pendencias, {}) == 'EVIDENCIA_INSUFICIENTE'


def test_b_financeiro_adicional(exp):
    dif, _, _ = d.comparar(exp, exp.financeiras, exp.financeiras * 2 + exp.cadastrais)
    assert dif['MODOS_FINANCEIROS_DIVERGENTES'] and dif['DUPLICACAO_INDEVIDA']


def test_cadastral_alterada_uma_celula(exp):
    bad = alterar(exp.cadastrais, 0, 21, 'intruso@example.invalid')
    dif, _, _ = d.comparar(exp, exp.financeiras, exp.financeiras + bad)
    assert dif['CADASTRAL_B_NAO_JUSTIFICADA'] == 1 and dif['CADASTRAL_B_AUSENTE'] == 1


def test_verificador_candidata_recusa_extra_e_pai_simbolico(tmp_path):
    root = tmp_path / 'cand'; root.mkdir(); (root / 'ok.py').write_bytes(b'ok')
    v = {'arquivos': {'ok.py': s.hash_bytes(b'ok')}}
    (root / 'extra.py').write_bytes(b'extra')
    with pytest.raises(s.Bloqueio, match='ARQUIVO_EXTRA_CANDIDATA'): s.verificar_candidata(root, v)
    (root / 'extra.py').unlink()
    alias = tmp_path / 'alias'; link_sintetico(alias, root, diretorio=True)
    with pytest.raises(s.Bloqueio, match='LINK_OU_REPARSE_RECUSADO'): s.verificar_candidata(alias, v)


def test_hardlink_validado_por_hash_nao_certifica_origem_fisica(tmp_path):
    externo = tmp_path / 'externo'; externo.write_bytes(b'ficticio')
    root = tmp_path / 'root'; root.mkdir(); os.link(externo, root / 'interno')
    f = s.Arquivo.ler(root, 'interno', s.hash_bytes(b'ficticio'))
    f.conferir()
    externo.write_bytes(b'alterado')
    with pytest.raises(s.Bloqueio): f.conferir()


def test_substituicao_durante_leitura_recusada(monkeypatch, tmp_path):
    (tmp_path / 'fonte').write_bytes(b'ficticio')
    original = os.open
    def abrir(p, flags, *args, **kwargs):
        if Path(p).name == 'fonte':
            novo = tmp_path / 'novo'; novo.write_bytes(b'ficticio')
            os.replace(novo, p)
        return original(p, flags, *args, **kwargs)
    monkeypatch.setattr(os, 'open', abrir)
    with pytest.raises(s.Bloqueio, match='FONTE_SUBSTITUIDA'): s.Arquivo.ler(tmp_path, 'fonte')


@pytest.mark.parametrize('pagador', [False, True])
def test_bpq04_titular_individual_versus_documento_so_pagador(monkeypatch, pagador):
    from tests.beach_parque.test_identidade_individual import fontes, NOME_COMPOSTO
    from tests.int02.fixtures import NOME, CPF
    nome = NOME if pagador else NOME_COMPOSTO
    fin, body = fontes(nome=nome, documento='' if pagador else CPF, contatos=[])
    if pagador:
        body = [(x,y,'CPF: 00000000272') if x == 398 and t == 'CPF: ' else (x,y,t) for x,y,t in body]
    raw_cad = bpq.cadastro([body])
    c = replace(caso('terraco_beach_parque'), financeiro=fin, cadastro=raw_cad)
    homologar(monkeypatch, [c])
    exp = d.construir(c.perfil, fin, raw_cad, END)
    assert len(exp.financeiras) == len(exp.cadastrais) == 1
    assert exp.financeiras[0].valores[2] == ('' if pagador else CPF)
    assert exp.cadastrais[0].valores[2] == ('' if pagador else CPF)
    assert exp.financeiras[0].valores[3] == nome
    assert not d.comparar(exp, exp.financeiras, exp.financeiras + exp.cadastrais)[0]


def test_bloqueio_de_leitor_critico_nao_vira_aprovacao(monkeypatch):
    c = fonte('itajuba', monkeypatch)
    # O limite é testado no avaliador independente, sem alterar motor/fixture histórica.
    assert a.estado(None, {}, {'LANCAMENTO_COM_REVISAO_DOCUMENTAL': 1}, {}) == 'EVIDENCIA_INSUFICIENTE'
    assert d.elegibilidade(c.perfil, datetime(2023,11,1).date(), Decimal('1')) == 'REVISAO_ESCOPO_DOCUMENTAL'


def test_fontes_reais_nao_necessarias_cli_sanitiza_erro(tmp_path):
    cli = Path(__file__).with_name('auditar.py')
    p = subprocess.run([sys.executable, '-B', str(cli), '--manifesto', str(tmp_path / 'SEGREDO.json'),
        '--candidata', str(tmp_path / 'candidata ausente'), '--saida-pai', str(tmp_path), '--execucao', 'nova'],
        capture_output=True, text=True, encoding='utf8')
    assert p.returncode == 2 and not p.stderr
    data = json.loads(p.stdout)
    assert data['estado'] == 'ERRO_OPERACIONAL' and str(tmp_path) not in p.stdout and 'SEGREDO' not in p.stdout


def test_cli_argumento_invalido_nao_repete_dados_privados(tmp_path):
    cli = Path(__file__).with_name('auditar.py')
    p = subprocess.run([sys.executable, '-B', str(cli), '--manifesto', str(tmp_path),
        '--candidata', str(tmp_path), '--saida-pai', str(tmp_path), '--execucao', 'nova',
        '--PESSOA_PRIVADA', 'segredo@example.invalid'], capture_output=True, text=True, encoding='utf8')
    assert p.returncode == 2 and not p.stderr
    assert json.loads(p.stdout)['codigo'] == 'ARGUMENTOS_REC01_INVALIDOS'
    assert 'PESSOA_PRIVADA' not in p.stdout and 'example.invalid' not in p.stdout


@pytest.mark.parametrize('problema', ['nenhum', 'preexistente', 'hash', 'pai_link', 'subpasta'])
def test_reconstrucao_payload_sem_sobrescrita(tmp_path, monkeypatch, problema):
    from tools.reconciliacao_privada import reconstruir_entrega as rec
    pacote = tmp_path / 'pacote'; pacote.mkdir()
    fonte = pacote / 'payload/tools/reconciliacao_privada/exemplo.py'
    fonte.parent.mkdir(parents=True); fonte.write_bytes(b'SINTETICO=1\n')
    nome = 'payload/tools/reconciliacao_privada/exemplo.py'
    indice = {'baseline': rec.BASE, 'arquivos': {nome: s.hash_bytes(fonte.read_bytes())}}
    (pacote / 'MANIFESTO_ENTREGA.json').write_bytes(s.json_bytes(indice))
    dest = tmp_path / 'worktree'; dest.mkdir()
    def git(cmd, **_):
        if cmd[-1] == '--show-toplevel': output = str(tmp_path if problema == 'subpasta' else dest)
        elif cmd[-1] == 'HEAD': output = rec.BASE
        else: output = ''
        return subprocess.CompletedProcess(cmd, 0, output.encode('utf8'), b'')
    monkeypatch.setattr(rec.subprocess, 'run', git)
    if problema == 'preexistente':
        alvo = dest / 'tools/reconciliacao_privada/exemplo.py'
        alvo.parent.mkdir(parents=True); alvo.write_bytes(b'PRESERVADO')
    if problema == 'hash': fonte.write_bytes(b'ALTERADO')
    if problema == 'pai_link':
        outro = tmp_path / 'outro'; outro.mkdir()
        link_sintetico(dest / 'tools', outro, diretorio=True)
    if problema == 'nenhum':
        assert rec.reconstruir(pacote, dest) == 1
        assert (dest / 'tools/reconciliacao_privada/exemplo.py').read_bytes() == b'SINTETICO=1\n'
    else:
        with pytest.raises((ValueError, OSError)): rec.reconstruir(pacote, dest)
        if problema == 'preexistente': assert alvo.read_bytes() == b'PRESERVADO'


@pytest.mark.parametrize('perfil', d.PERFIS)
def test_projecao_independente_confere_saida_mvp_sintetico(perfil, monkeypatch, tmp_path):
    """Regressão adicional; NÃO é a fonte de verdade da auditoria documental."""
    from conversor.export.identifiers import EnderecoPadrao, OrigemEnderecoUsuario
    from conversor.domain.canonical import Endereco
    from datetime import timezone
    c = fonte(perfil, monkeypatch)
    exp = d.construir(perfil, c.financeiro, c.cadastro, END)
    padrao = EnderecoPadrao(endereco=Endereco(**END), evidencia=OrigemEnderecoUsuario(
        registro_id='sintetico', versao=1, registrado_em=datetime(2026,11,9,tzinfo=timezone.utc), sessao_sha256='1'*64))
    linhas = []
    for modo in ('A', 'B'):
        dest = tmp_path / modo
        analisar(c.financeiro, PedidoDiagnostico(data_ref=d.DATA_REF, modo=modo, condominio=perfil),
                 processamento_id='rec01_regressao_ficticia', destino=dest, cadastro=c.cadastro,
                 buscar_endereco=lambda *_: padrao)
        linhas.append(d.ler_xlsx((dest / 'TESTE_LOCAL_NAO_IMPORTAR.xlsx').read_bytes()))
    assert not d.comparar(exp, *linhas)[0]
