# WIN19-R2 — relatório de preparação para auditoria

18/11/2026. Referência principal: INSTRUCAO_CODEX_WIN19_R2_PREPARACAO.md;
fundamentação: PARECER_TECNICO_WIN19_PREPARACAO_2026-11-18.md. Ambos anexos
estão preservados literalmente em fontes_recebidas/, com SHA em PROVENIENCIA_R2.json.

## Resultado e limites

Preparação revisada exclusivamente em pasta externa às candidatas. Não foi
executado teste, coleta pytest, preflight, sonda/API Windows, criação de link,
acesso entre contas nem operação DACL. Não houve commit, push, PR, merge ou
publicação. Nenhum componente de produção, teste histórico, motor/executor de
cleanup, pacote anterior ou candidata validada foi modificado.

A matriz contém 19 vínculos PROVISORIO_SEM_FONTE; funcional/nativo/DACL são
NÃO_VALIDADO em todas as linhas. JUnit EXP-04 original 2842/19/7, log, relatório,
versão e manifesto de origem continuam ausentes. Parecer declara revisão dos
ZIPs Windows anteriores; esses bytes não foram fornecidos neste workspace.
Isso é atestação do revisor, não execução/reconferência feita nesta R2.

## Diferenças para revisão

| Artefato | Alteração e efeito esperado (sem resultado de execução) |
|---|---|
| CHECKLIST_CUSTODIA_JUNIT_R2.json; tools/extrair_junit_historico.py | Dez itens de custódia/proveniência; distingue nodeid candidato de confirmado, detecta duplicatas e mostra contadores das suites folha. Não aprova vínculo nem publica traceback. |
| test_win19_independentes.py / WIN14; factories_r2.py | Substitui conferência isolada/SimpleNamespace por pacote mínimo, quatro catálogos/inventário/atesto sintético, autoridade HMAC real, gravar/carregar e validar recibo; ataque por fonte-link exige recusa sem corpo/recibo novo e sentinelas/bytes preservados. |
| test_win19_independentes.py / WIN16; factories_r2.py | Substitui prova apenas de domínio por CLI real/subprocesso e PDF W045A com conflito fabricado; gabarito construído sem consultar leitor, positivo separado, auditoria de ambos documentos, ausência de canônicos/XLSX e recusa no DTO exportador. |
| WIN03 | Documenta ramo de erro real NÃO_VALIDADO_SEM_INSTRUMENTACAO; comparação real proposta continua, NUL não conta como erro da API. Nenhuma indução insegura. |
| WIN06–10/12 | Inspeciona raiz interna e layout da revisão0; apenas lock regular vazio previsto, evidencias/cabecas devem estar ausentes; objeto inesperado aborta/preserva. WIN12 preserva registro/chave/cabeças e substitui apenas fonte própria identificada. |
| suporte_nativo.py; LinkSintetico/WIN04 | Preparação de remoção por handle sem seguir reparse, identidade/atributos, ancestrais presos durante exclusão, erros imediatos e polling limitado da ausência. Nenhuma remoção recursiva nem alteração do motor. Divergência preserva área. |
| conftest.py | Guarda de origem/imports conversor/examples, resolução antes de carregar, conferência após casos/sessão, 470 antes/depois; eventos persistidos/fsync e observador de falhas nativas do helper. |
| preflight_win19.py/.ps1 | Coleta0 não significa prontidão; lista impedimentos e portões C/D/E bloqueados, distingue conclusão de coleta; volume observado pelo ponto de montagem, somente leitura. Não executado em Linux/Windows. |
| Plano/fichas/matriz R2 | 19 IDs e quatro eixos conservados, fluxos/limites atualizados, executor futuro especificado sem lançador/comando pytest. 21 casos são previsão por leitura, não coleta. |
| DACL R2 | Mantém intenção por papel/objeto/operação, PARA_APROVAÇÃO; dez decisões pendentes detalham READ_CONTROL, WRITE_DAC e WRITE_OWNER separados, fonte imutável, herança, admin, tokens e create/replace. |

## O que a preparação ainda não comprova

Factories e helpers não foram importados nem validados em runtime. Estrutura
Python válida não prova contratos dinâmicos, origem real dos imports Windows,
coordenadas/ordem de fragmentos PDF ou segurança do helper nativo. A próxima
revisão deve conferir esses pontos e o executor de evidências antes de liberar
qualquer ensaio. O helper só registra as suas próprias APIs; não atribui ao
produto uma API/código que ele não expõe. A trilha de diagnóstico individual
antes de cada asserção deve ser fechada no futuro executor, sem inventar evidência.

WIN15 conserva gabarito derivado do leitor somente para opt-in/contrato de saída;
não é oráculo financeiro independente. WIN16 verifica o CLI de validação e a
barreira documental do DTO, sem alegar exercício da exportação operacional.
WIN03 erro nativo continua não demonstrado. Sem alias ou privilégio symlink,
os subcontroles futuros permanecem NÃO_VALIDADO; 1314 não demonstra rejeição.
WIN18/19 e toda DACL efetiva dependem de política, laboratório e tokens aprovados.
Cleanup 36PASS/3SKIP não é aprovação desses controles. Conversões reais bloqueadas.

## Conferências realizadas nesta tarefa

Apenas AST/compilação em memória dos seis scripts, parsing JSON/CSV e cruzamento
dos 19 IDs/cenários, hashes/CRC de artefatos e leitura do Git. Não há pytest,
--collect-only, logs ou JUnit novos de teste. VERIFICACAO_ESTATICA_R2.json registra
a natureza e os limites. Nenhum número de casos previsto é resultado observado.

PRESERVACAO_R2.json registra 470 arquivos exatos sem extras na R1-FIX Linux,
27 worktrees e status/HEAD inalterados, refs Git inalteradas, 15 ZIPs anteriores
preservados e pasta da primeira preparação sem alterações. O manifesto completo
de referência permanece o mesmo SHA a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c.
Isso não é nova conferência na máquina Windows do usuário.

## Artefatos e diff

Esta pasta contém documentos R2, matriz, fichas, checklist, revisão de factories,
fontes recebidas, seis scripts preparados e referências históricas claramente
identificadas. DIFF_PREPARACAO_R2.patch representa remoções, inclusões e alterações
de conteúdo contra a pasta original; não depende de git diff de rastreados.
O diff exclui a si próprio e o manifesto final (evita autorreferência); o manifesto
final cobre todos os demais arquivos, inclusive o diff. Sidecar externo identifica
bytes/entradas/CRC/SHA do ZIP e SHA do manifesto. ZIP anterior não foi substituído.

## Ponto de parada

R2 entregue PARA_REVISÃO. Revisar código/factories, preflight e custódia; somente
uma autorização posterior específica poderá liberar o preflight Windows. Coleta,
ensaios sintéticos e acesso entre tokens são portões distintos e continuam
BLOQUEADOS. Nenhuma homologação Windows/DACL, conversão real ou publicação.
