# WIN19-R2 — preparação para revisão
18/11/2026. Entrega documental/técnica, sem execução de cenários.

Comece por RELATORIO_R2.md, PLANO_NATIVO_WIN19_R2.md e o diff DIFF_PREPARACAO_R2.patch.
Os documentos e índices antigos conservados são fontes da primeira preparação;
os artefatos de nome R2 são a versão de revisão. Não herdar conclusões antigas
como verificações novas. Os anexos recebidos foram preservados literalmente.

19 vínculos PROVISORIO_SEM_FONTE. Funcional/nativo/DACL: NÃO_VALIDADO.
Nada aqui autoriza preflight, pytest, coleta, links ou acesso entre contas.
A flag dos cenários é apenas uma trava, não uma autorização.
Não existe lançador de testes. Sem publicação; pacote anterior preservado.
Conversões reais permanecem BLOQUEADAS. Política DACL PARA_APROVAÇÃO.

O manifesto externo de entrega cobre todos os arquivos, exceto ele próprio.
A integridade do ZIP é registrada em sidecar externo, sem autorreferência.
