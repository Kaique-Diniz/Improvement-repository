# EXP-04 / WIN-19 — Parecer técnico da primeira entrega

**Data:** 18/11/2026  
**Escopo:** auditoria estática do pacote `EXP-04-WIN19-preparacao.zip` e revisão do plano de validação independente.  
**Decisão:** **ACEITA COMO PREPARAÇÃO DOCUMENTAL**, mas **NÃO APROVADA PARA EXECUÇÃO DA SUÍTE NATIVA OU PARA IMPLANTAÇÃO DACL**.

## 1. Integridade diretamente verificada nesta revisão

- ZIP SHA-256: `6e12aedee7e1ed26bf95b4b02d12fc1289428f00f97139b672fd55c391befd72` (idêntico ao informado).
- ZIP: 24 entradas, CRC íntegro.
- Manifesto interno: 23/23 arquivos presentes, hashes corretos; o único excluído é o próprio manifesto.
- Matriz: 19 IDs únicos, grupos API=5, LINK=9, MODO=3, CHMOD=2.
- Cada uma das 19 linhas: `PROVISORIO_SEM_FONTE`, `resultado_nativo=NAO_EXECUTADO`, e eixos funcional/nativo/DACL `NÃO_VALIDADO`.
- Fichas: 19 IDs correspondentes. Os quatro scripts Python do pacote passaram em análise sintática (`ast.parse`); **não foram executados como testes**.
- Manifesto de referência R1-FIX: SHA-256 `a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`.
- Os ZIPs anteriores `R1-FIX-EVIDENCIAS-WINDOWS.zip` e `R1-FIX-SUITE39-WINDOWS.zip`, disponíveis nesta conversa, tiveram seus hashes externos e CRC reconferidos nesta revisão. Isso **não fornece** o JUnit EXP-04 original de 2.842 casos, 19 falhas e sete skips.

**Limite:** não foi realizada nova execução Windows, não foram recalculados os 470 hashes na máquina Windows, não houve alteração Git/ACL/conta/privilégio. Registros de preservação produzidos pelo Codex são evidência declarada pelo pacote, distinta de validação independente do ambiente de origem.

## 2. Parecer sobre os artefatos

**RELATORIO_PROVENIENCIA_WIN19.md:** tecnicamente consistente na separação de fontes efetivas, fontes meramente declaradas e lacunas. Zero vínculos divergentes **não** equivale a 19 vínculos confirmados.

**MATRIZ_WIN19_RECONCILIADA.csv:** aceita como matriz de trabalho com 19 linhas. Os vínculos históricos permanecem `PROVISORIO_SEM_FONTE`; nenhum PASS da suíte de cleanup é transportável para DACL ou para as falhas originais.

**PLANO_NATIVO_WIN19.md / FICHAS_TESTES_NATIVOS_WIN19.json:** escopo bem delimitado. A expansão prevista para 21 casos é plausível (WIN-11 e WIN-13 têm dois subcasos), mas ainda não foi conferida por `pytest --collect-only` e não representa 21 controles homologados.

**testes_propostos/**: código de ensaio independente de fixtures legadas, mas ainda candidato de testes, não uma suíte pronta para homologação. Revisar o tratamento de objetos preexistentes em WIN-06–10 e preservar sem exclusão em caso de identidade inesperada; validar as factories sintéticas de WIN-12/15/16 com coleta controlada antes de execução nativa. Revisar explicitamente que a origem dos imports pertence à candidata cujo manifesto foi conferido. Não converter falhas de fixture em aprovação de segurança.

**tools/preflight_win19.ps1/.py:** em inspeção estática, suas ações são de leitura/inventário; checa hashes/estado Git, volume, token, ambiente e capacidade declarada. Não cria symlinks, não altera políticas ou DACL. É possível avaliar sua execução isolada **após aprovação expressa do procedimento e revisão dos caminhos**. Seu código de saída 0 representa coleta, não prontidão/homologação, mesmo se a capacidade de symlink estiver ausente ou houver impedimento de volume.

**ESPECIFICACAO_DACL_PROPOSTA.md:** adequada como **proposta de política**, não como política implantável. Define papéis O/U/A e reconhece interações entre `DELETE`, `DELETE_CHILD`, herança, owner/administradores, tokens e fluxo real. Existem direitos `R` ainda indecisos; não há contas de laboratório, nem observação de DACL criada/verificada pelo motor. Antes de autorizar ensaios entre tokens, concluir essas decisões e obter aceite específico de ambiente e modelo de ameaça.

## 3. Pendências impeditivas e ações corretivas

1. **Fonte histórica ausente:** localizar e custodiar JUnit/log/relatório EXP-04 original com versão e origem, 19 nodeids e sete motivos individuais dos skips. O extrator preparado só ajuda na triagem; não confirma proveniência automaticamente.
2. **Cobertura integral WIN-14:** complementar o teste do componente `conferir_fontes` com o fluxo real `gravar_pacote`, autoridade e recibo; aprovação parcial não valida fluxo completo.
3. **Cobertura integral WIN-16:** acrescentar cenário documental/CLI real de conflito, com gabarito sintético independente e bloqueio de exportação; teste de modelo isolado não valida pipeline completo.
4. **Ramo de erro de API WIN-03:** documentar estratégia segura para exercitar falha real; entrada inválida/NUL ou mock não provam falha do `CompareStringOrdinal` nativo. Não forçar ponteiros inválidos nem alterar código de segurança para produzir PASS.
5. **WIN-02:** quando não existir alias 8.3 real, manter `NÃO_VALIDADO` para esse subcontrole, sem substituir por nome curto construído.
6. **WIN-06–14:** se o Windows continuar retornando 1314, registrar incapacidade de criar symlink e deixar os controles não exercitados. Junction externa, quando autorizada, requer cenário adicional separado, não substitui symlink.
7. **WIN-18/19 e DACL:** aprovar por escrito papéis/objetos/operações/retenção/exceções e o laboratório NTFS; confirmar tokens realmente distintos e origem da DACL pelo fluxo real. Uma ACL aplicada manualmente não comprova o escritor/leitor.
8. **Evidência:** definir como cada caso persistirá diagnóstico mesmo com falha de asserção; JUnit, APIs/códigos imediatos, hashes/snapshots antes/depois e limpeza segura; custódia de bruto versus cópia sanitizada.

## 4. Portões de autorização

**Portão A — preparação documental:** ACEITO. Nenhum controle WIN-01–19 homologado.

**Portão B — preflight Windows somente leitura:** poderá ser autorizado isoladamente, usando a candidata R1-FIX existente, após validação dos caminhos e confirmação de que a saída não contém dados pessoais. Não autoriza execução pytest nem mudança de privilégio.

**Portão C — ensaios funcionais/nativos sintéticos:** BLOQUEADO até complementação dos cenários, revisão das factories e roteiro com comando reproduzível, basetemp exclusivo e manifestos antes/depois.

**Portão D — DACL entre contas:** BLOQUEADO até aprovação da política, laboratório e tokens de teste, com atribuição explícita da responsabilidade por criação/verificação de DACL pelo sistema sob avaliação.

**Portão E — homologação operacional/conversões reais/merge:** BLOQUEADO, independente dos demais PASS.

## 5. Próxima instrução ao Codex

Produzir **WIN19-R2 — ajuste de preparação, sem execução**: manter todos os 19 vínculos provisórios; corrigir/completar WIN-14, WIN-16 e planejamento seguro de WIN-03; revisar contingências das fixtures WIN-06–10/12/15/16; detalhar coleta de evidências inclusive falhas; revisar protocolo de preflight não invasivo e critérios de saída; apresentar a DACL como proposta revisada com todas as decisões `R` pendentes destacadas. Entregar diff somente dos arquivos de preparação, matrizes, roteiro, manifesto atualizado e parecer explícito do que continua BLOQUEADO. Não modificar nem executar o motor/executor, candidata R1-FIX ou seus 470 arquivos; não instalar ACL ou privilégios; não executar pytest, criar contas, commit, push, merge, publicação, nem desbloquear conversões.

## 6. Referências técnicas de semântica Windows (não são evidência do projeto)

- Microsoft: [File Security and Access Rights](https://learn.microsoft.com/en-us/windows/win32/fileio/file-security-and-access-rights).
- Microsoft: [GetNamedSecurityInfoW](https://learn.microsoft.com/en-us/windows/win32/api/aclapi/nf-aclapi-getnamedsecurityinfow).
- Microsoft: [How AccessCheck Works](https://learn.microsoft.com/en-us/windows/win32/secauthz/how-dacls-control-access-to-an-object).
- Microsoft: [CreateSymbolicLinkW](https://learn.microsoft.com/pt-br/windows/win32/api/winbase/nf-winbase-createsymboliclinkw).

**Conclusão:** documentação aprovada para arquivo e continuidade de preparação; nenhum teste WIN-19, controle DACL ou uso real foi homologado por esta revisão.
