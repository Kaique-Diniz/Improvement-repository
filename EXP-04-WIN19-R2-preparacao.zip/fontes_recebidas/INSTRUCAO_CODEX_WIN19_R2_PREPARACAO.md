# Codex — EXP-04 / WIN19-R2: refinamento da preparação (não executar testes)

A primeira entrega WIN-19 foi revisada e aceita **documentalmente**, não como execução/homologação. O ZIP recebido (`EXP-04-WIN19-preparacao.zip`) possui SHA-256 `6e12aedee7e1ed26bf95b4b02d12fc1289428f00f97139b672fd55c391befd72`, CRC válido e 19 vínculos `PROVISORIO_SEM_FONTE`. O JUnit EXP-04 original de 2.842 casos/19 falhas/7 skips continua ausente desta entrega.

**Objetivo da R2:** fechar as lacunas do plano independente, deixando o preflight somente leitura e futuros ensaios prontos para avaliação separada, SEM rodá-los.

## Trabalhos autorizados (somente nos artefatos de preparação, fora da candidata)

1. Preservar a matriz de 19 IDs, os quatro eixos (vínculo, funcional, nativo e DACL) e todos os estados `NÃO_VALIDADO`. Não confirmar vínculos por semelhança textual, resultados Linux ou cleanup.
2. Formalizar um checklist de obtenção e custódia do JUnit EXP-04 original, dos 19 nodeids exatos, dos sete skips e da versão/manifesto que originou cada teste. `extrair_junit_historico.py` deve produzir índice de apoio, sem aprovar automaticamente.
3. Complementar o cenário **WIN-14** até o fluxo `gravar_pacote` com autoridade, recibo e sentinelas. Não reduzir a cobertura ao componente `conferir_fontes`.
4. Complementar o **WIN-16** até o fluxo CLI/documento sintético com conflito reproduzível, evidência de bloqueio e ausência de exportação. Não usar mock para fabricar conflito.
5. Para **WIN-03**, apresentar estratégia SEGURA e limitada de cobertura do erro nativo, ou registrar essa ramificação como não demonstrável sem instrumentação. Não induzir chamadas perigosas com ponteiros inválidos; não atribuir PASS ao ramo por NUL ou mock.
6. Revisar precondições e limpeza de **WIN-06–10**, sobretudo o tipo/estado de `evidencias` e `cabecas` após controle positivo; abortar e preservar se a entrada já existir de maneira não prevista. Revisar os dados sintéticos/factories e invariantes de WIN-12/15/16, com inspeção estática apenas.
7. Revisar proteção contra substituição e limpeza de links: nunca seguir o link para excluir destinos, nunca executar remoção recursiva de alvo externo; preservar área e JUnit em caso de divergência.
8. Especificar executor futuro com Python 3.12, `-B`, cache desabilitado, basetemp novo e exclusivo fora do Git, 470 hashes antes/depois, controle positivo, API/Win32 capturados imediatamente, relatório persistido antes da asserção, comparação integral dos bytes e custódia de evidências brutas/sanitizadas. **Não implementar um comando que execute testes sem autorização futura.**
9. Revisar o preflight `preflight_win19.py/.ps1`: ele pode apenas inventariar NTFS, token, privilégio, Developer Mode, alias existente, Git e hashes. O código de saída 0 NÃO equivale a `prontidao_para_executar`; revisar a apresentação de impedimentos.
10. Manter `ESPECIFICACAO_DACL_PROPOSTA.md` como **PARA_APROVAÇÃO**. Separar decisões ainda abertas de READ_CONTROL, WRITE_DAC/OWNER, fonte original imutável, herança, exceções administrativas, tokens distintos e política de criação/replace. Nenhum `Set-Acl`, `icacls` de alteração, criação de conta, elevação ou mudança do SO.

## Proibições

Não executar novos testes, pytest ou coleta; não executar preflight nativo nesta R2; não criar symlinks/junctions/contas; não modificar o motor, executor, candidata R1-FIX, seus 470 arquivos ou Git anterior; não abrir/limpar resíduos antigos; sem commit, push, PR, merge, publicação ou conversões reais.

## Entregáveis

- `RELATORIO_R2.md` com mudanças, limites e paradas.
- `MATRIZ_WIN19_RECONCILIADA_R2.csv` (19 IDs, todos ainda provisórios salvo fonte nova realmente apresentada).
- `FICHAS_TESTES_NATIVOS_WIN19_R2.json` e cenários complementados **não executados**.
- `PLANO_NATIVO_WIN19_R2.md` com preflight revisado, ensaios futuros e critérios de aceitação por controle/eixo.
- `ESPECIFICACAO_DACL_PROPOSTA_R2.md` com quadro de decisões pendentes.
- Manifesto SHA-256 do pacote R2, diff da preparação e confirmação da candidata 470 preservada conforme evidência disponível.

**Parar após produzir a R2.** Pedir revisão do usuário antes de qualquer preflight Windows ou execução de testes.
