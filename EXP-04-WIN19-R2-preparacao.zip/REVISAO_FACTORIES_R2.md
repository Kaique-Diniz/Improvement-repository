# Inspeção estática das factories e imports — R2

Nenhum código proposto foi importado/executado. Revisão contra fontes da R1-FIX
com 470 hashes; sintaxe/JSON/CSV são conferências estruturais, não testes.

| Controle | Entradas/invariantes conferidas por leitura | Limite/parada |
|---|---|---|
| WIN06–10 | RepositorioVinculosJSON cria raiz interna; revisar revisão zero e somente lock residual vazio; evidencias/cabecas ausentes nesta factory. | Objeto inesperado aborta/preserva sem exclusão; runtime Windows não validado. |
| WIN12 | IdentidadeOrigem, EvidenciaVinculo, VinculoDocumental, origens SHA, HMAC, revisar/ler fonte e snapshot de registro/chave/cabeças. | Confirmar validação completa em futura rodada; não foi coletado/executado. |
| WIN14 | PacotePrivado exige quatro catálogos, inventário exato e fontes ligadas às origens; mínimo com uma unidade sem dívida é permitido por conferir_pacote. Autoridade externa à raiz do repo; submeter em ambiente sintetico. | Atesto só fixture, não finanças privadas; segredo efêmero somente futuro; nenhuma DACL configurada. |
| WIN15 | Três leitores sintéticos, código 9999/LAB e gabarito/manifesto SHA; opt-in salva três canônicos. | Oracle derivado do leitor só para opção/contrato; não aprova extração ou política. |
| WIN16 | Cadastro real aceita W045A(9999), seis rótulos nas faixas x, unidade A/0001, documento em duas linhas, rodapé1de1. Resolver documental acusa conflito de dois válidos. Origem, IDs/normalização e ressalvas declaradas sem ler saída do leitor. | Esperado depende do contrato de fragmentos/float x,y do pypdf; só execução futura poderá confirmar. Não fabricar esperado a partir de resultado observado para obter PASS. |

Imports: conftest recusa conversor/examples em cache fora da candidata; verifica
resolução antes de importar e origem no início/fim de casos e sessão. CLI usa
cwd/PYTHONPATH da candidata, -B e UTF-8. O futuro executor deve conferir também
hashes de helpers/factories R2 efetivamente usados e dependências. Eventual
conflito de import ou divergência de 470 hashes bloqueia em vez de ajustar sys.path
silenciosamente depois de carregar código incorreto.

suporte_nativo.py é helper exclusivo desta preparação. Não modifica temporarios.py
nem usa o motor de exclusão como oráculo. Qualquer divergência preserva laboratório;
segurança nativa do helper permanece não demonstrada até revisão e ensaio autorizado.
