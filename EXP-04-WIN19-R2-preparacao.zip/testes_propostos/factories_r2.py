"""Factories fabricadas, não executadas na R2; nenhum documento privado.

WIN14: a autoridade é de aplicação e restrita a este laboratório. Não cria
contas, não implanta ACL e não aprova política de cobrança ou DACL.
WIN16: PDF e gabarito são construídos dos mesmos dados declarados, mas o
gabarito NÃO é saída do leitor sob teste nem resultado de monkeypatch.
"""
from datetime import datetime, timezone
from hashlib import sha256
import json
import secrets


def preparar_simulacao(root, conteudo):
    from conversor.adapters.billing_authority import AutoridadeHMAC
    from conversor.adapters.private_simulation_json import RepositorioSimulacoesJSON
    from conversor.application.billing_ports import CredencialOperador
    from conversor.application.billing_evaluation import normalizar_entrada
    from conversor.application.simulation_inventory import inventariar
    from conversor.domain.canonical import LoteCanonico, Origem, Unidade
    from conversor.domain.billing_evaluation import EntradaSimulacao
    from conversor.domain.private_simulation import (AtestoCompletude, CatalogoImpedimentos,
                                                    FontePrivada, PacotePrivado)
    authority_dir = root/'autoridade'; authority_dir.mkdir()
    credencial = CredencialOperador(secrets.token_hex(32))
    (authority_dir/'chave.bin').write_bytes(secrets.token_bytes(32))
    (authority_dir/'operadores.json').write_text(json.dumps(dict(schema_version='1.0', concessoes=[dict(
        responsavel_id='operador_sintetico', credencial_sha256=sha256(credencial.segredo.encode()).hexdigest(),
        acoes=['submeter'], condominio_ids=['cond_sintetico'], ambientes=['sintetico'])])), encoding='utf-8')
    autoridade = AutoridadeHMAC(authority_dir)
    local = root/'fonte_sintetica.bin'; local.write_bytes(conteudo)
    origin = Origem(arquivo_id='fonte_sintetica', sha256=sha256(conteudo).hexdigest(),
                   leitor_versao='win19_fixture_v2', pagina=1, linha=1, identificador='linha_1')
    unit = Unidade(id='unidade_sintetica', condominio_id='cond_sintetico', administradora_id='adm_sintetica',
                   bloco_original='A', unidade_original='0001', chave_normalizada='A/1',
                   normalizador_versao='win19_fixture_v2', origem=origin)
    entrada = normalizar_entrada(EntradaSimulacao(lote=LoteCanonico(unidades=(unit,), boletos=()),
        fatos=(), ocorrencias_anteriores=(), coberturas_apontamentos=()))
    catalogos = tuple(CatalogoImpedimentos(id='catalogo_'+cat, categoria=cat,
        condominio_id='cond_sintetico', ocorrencias=(), origens=(origin,))
        for cat in ('leitura','auditoria_lote','titularidade','documentos'))
    # Pacote deliberadamente mínimo: unidade + quatro catálogos, sem cobrança.
    # Os atestos descrevem somente a completude desta pequena fixture fabricada.
    pacote = PacotePrivado(id='pacote_positivo', condominio_id='cond_sintetico', ambiente='sintetico',
        entrada=entrada, catalogos=catalogos, inventario=inventariar(entrada,catalogos),
        fontes=(FontePrivada(arquivo_id=origin.arquivo_id,caminho=str(local),sha256=origin.sha256,
                             tamanho=len(conteudo),papel='evidencia'),),
        atesto=AtestoCompletude(em=datetime(2026,11,18,tzinfo=timezone.utc),data_ref='2026-11-09',
            fundamento='Completo somente para esta fixture fabricada; sem autorização operacional',
            evidencia_id='win19_fixture',inventario_conferido=True,fontes_e_paginas_conferidas=True,
            catalogos_externos_completos=True,ausencias_conferidas=True))
    repo = RepositorioSimulacoesJSON(root/'simulacoes', repositorio_id='win19_sintetico',
                                    ambiente='sintetico', autoridade=autoridade, timeout=0.1)
    return repo, autoridade, credencial, pacote, local


def _id(prefixo, *partes):
    # Especificação pública de IDs estáveis; não chama o leitor ou seu helper.
    return prefixo+':'+sha256('\x1f'.join(partes).encode('utf-8')).hexdigest()


def preparar_cli_conflito(root, *, conflito):
    """Cadastro W045A posicionado: um titular de contato, CPF e CNPJ conflitantes.

    O controle positivo usa só um documento. Origem/linhas/ressalvas são
    declaradas a partir da tabela de coordenadas, não extraídas pelo leitor.
    """
    from examples.fase3.layouts_sinteticos import pdf_posicionado
    from conversor.domain.canonical import (Origem, Unidade, Pessoa, Documento,
        EvidenciaDocumento, Contato, Endereco, LoteCanonico, RessalvaLeitura)
    root.mkdir()
    registros = [(31,810,'W045A CONDOMINIO SINTETICO (9999)'), (31,790,'Cadastro de unidades'),
        (31,770,'Unidade'), (91,770,'Nome/Telefone/Celular'), (241,770,'Tipo'),
        (346,770,'Endereço'), (534,770,'CPF/CNPJ'), (609,770,'E-mail'),
        (31,740,'0001 TORRE A'), (91,740,'PESSOA SINTETICA'), (241,740,'Proprietario'),
        (534,740,'00000000191')]
    if conflito:
        registros.append((534,720,'00000000000191'))
    registros.append((31,24,'1 de 1'))
    pdf = pdf_posicionado([registros]); (root/'cadastro.pdf').write_bytes(pdf)
    digest = sha256(pdf).hexdigest()
    def origem(numero):
        return Origem(arquivo_id='cadastro_sintetico',sha256=digest,
            leitor_versao='cadastro_fl_real_v1@1',pagina=1,linha=numero,identificador=f'p1_l{numero}')
    unit_id = _id('uni_real','cond_sintetico','A/1')
    unit = Unidade(id=unit_id,condominio_id='cond_sintetico',administradora_id='adm_sintetica',
        bloco_original='A',unidade_original='0001',chave_normalizada='A/1',
        normalizador_versao='identidade_real_v1',origem=origem(9))
    campos = [('nome',10),('tipo',11),('documento',12)] + ([('documento',13)] if conflito else [])
    docs = [Documento(tipo='cpf',valor='00000000191')]
    if conflito:
        docs.append(Documento(tipo='cnpj',valor='00000000000191'))
    pessoa = Pessoa(id=_id('pes_real',unit_id,'pessoa sintetica'),unidade_id=unit_id,
        nome='PESSOA SINTETICA',documento=None,relacao_unidade='contato_unidade',origem=origem(9),
        evidencias_documentais=tuple(EvidenciaDocumento(documento=d,origem=origem(12+i)) for i,d in enumerate(docs)),
        contato=Contato(endereco=Endereco(),origem=origem(9)))
    valores = []
    for campo,numero in campos:
        x,y,texto = registros[numero-1]
        valores.append(json.dumps(dict(campo=campo,texto=texto,origem=origem(numero).model_dump(mode='json'),
                                       x=float(x),y=float(y)),ensure_ascii=False))
    ressalvas = tuple(RessalvaLeitura(codigo=code,registro_id=unit_id,origens=(origem(9),),
        gravidade='informativo' if code=='CADASTRO_CAMPOS_ORIGINAIS' else 'alerta',
        valores_originais=tuple(valores) if code=='CADASTRO_CAMPOS_ORIGINAIS' else ()) for code in
        ('ENDERECO_AUSENTE','CADASTRO_CAMPOS_ORIGINAIS','TELEFONE_AUSENTE_OU_NAO_VALIDADO','EMAIL_AUSENTE_OU_NAO_VALIDADO'))
    esperado = LoteCanonico(unidades=(unit,),boletos=(),pessoas=(pessoa,),ressalvas=ressalvas)
    raw = esperado.model_dump_json().encode('utf-8'); (root/'gabarito.json').write_bytes(raw)
    config = dict(finalidade='validacao_privada_fase3',natureza='sintetica',autorizacao_id='win19_fixture',casos=[dict(
        id='conflito' if conflito else 'positivo',fonte=dict(arquivo_id='cadastro_sintetico',sha256=digest),
        arquivo='cadastro.pdf',gabarito='gabarito.json',gabarito_sha256=sha256(raw).hexdigest(),
        leitor_id='cadastro_fl_real_v1',leitor_versao='1',formato_id='cadastro_fl_real_v1',
        condominio_id='cond_sintetico',administradora_id='adm_sintetica',codigo_condominio='9999',data_ref='2026-11-09')])
    manifest = root/'manifesto.json'; manifest.write_text(json.dumps(config),encoding='utf-8')
    return manifest, esperado
