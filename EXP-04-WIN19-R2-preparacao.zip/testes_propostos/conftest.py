"""Preparação apenas: nada roda sem revisão/autorização posterior explícita."""
import os
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import stat
import sys
import pytest


def conferir_imports(root):
    """Rejeita cache/imports de outra candidata; não importa o produto para medir."""
    for name, module in tuple(sys.modules.items()):
        if name == 'conversor' or name.startswith('conversor.') or name == 'examples' or name.startswith('examples.'):
            expected = root/'src' if name.startswith('conversor') else root
            origins = ([getattr(module, '__file__', None)] if getattr(module, '__file__', None)
                       else list(getattr(module, '__path__', ())))
            if not origins:
                raise pytest.UsageError('ORIGEM_IMPORT_INDISPONIVEL')
            for origin in origins:
                path = Path(origin).absolute()
                if not path.is_relative_to(expected):
                    raise pytest.UsageError('IMPORT_DE_OUTRA_CANDIDATA')
                for parent in (path, *path.parents):
                    st = parent.lstat()
                    if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
                        raise pytest.UsageError('IMPORT_CONTEM_REDIRECIONAMENTO')


def pytest_addoption(parser):
    parser.addoption('--win19-plano-revisado', action='store_true', default=False)
    parser.addoption('--win19-candidata', default=None)


def pytest_configure(config):
    config.addinivalue_line('markers', 'win19(id, eixo): vínculo lógico proposto; não confirma vínculo histórico')
    if config.getoption('--win19-plano-revisado') and os.name == 'nt':
        root = config.getoption('--win19-candidata')
        if not root:
            raise pytest.UsageError('CANDIDATA_NAO_INFORMADA')
        package = Path(__file__).absolute().parents[1]
        manifest = package/'REFERENCIA_R1_FIX_470_SHA256.json'
        raw = manifest.read_bytes()
        if sha256(raw).hexdigest() != 'a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c':
            raise pytest.UsageError('MANIFESTO_REFERENCIA_DIVERGENTE')
        spec = importlib.util.spec_from_file_location('win19_preflight_guard', package/'tools/preflight_win19.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        expected = json.loads(raw)['arquivos']
        if len(expected) != 470 or module.hashes(Path(root)) != expected:
            raise pytest.UsageError('INTEGRIDADE_CANDIDATA_DIVERGENTE')
        root = Path(root).absolute()
        conferir_imports(root)
        sys.path.insert(0, str(root))
        sys.path.insert(0, str(root/'src'))
        origin = importlib.util.find_spec('conversor').origin
        if Path(origin).absolute() != root/'src/conversor/__init__.py':
            raise pytest.UsageError('RESOLUCAO_IMPORT_DIVERGENTE')
        config._win19_integrity = (module, root, expected)


def pytest_sessionfinish(session, exitstatus):
    state = getattr(session.config, '_win19_integrity', None)
    if state:
        module, root, expected = state
        try:
            conferir_imports(root)
            intact = module.hashes(root) == expected
        except Exception:
            intact = False
        if not intact:
            session.exitstatus = 2


def pytest_collection_modifyitems(config, items):
    allowed = config.getoption('--win19-plano-revisado') and os.name == 'nt'
    if not allowed:
        reason = 'PREPARACAO_SEM_AUTORIZACAO_OU_WINDOWS; NAO_VALIDADO'
        for item in items:
            item.add_marker(pytest.mark.skip(reason=reason))


def conferir_area_lab(tmp_path, config):
    root = Path(config.getoption('--win19-candidata')).absolute()
    if not tmp_path.is_absolute() or tmp_path.is_relative_to(root) or root.is_relative_to(tmp_path):
        pytest.fail('AREA_INVALIDA_OU_SOBREPOE_CANDIDATA', pytrace=False)
    for node in (tmp_path, *tmp_path.parents):
        st = node.lstat()
        if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
            pytest.fail('AREA_CONTEM_LINK_REPARSE', pytrace=False)
        if os.path.lexists(node/'.git'):
            pytest.fail('AREA_DENTRO_GIT', pytrace=False)
        if os.path.lexists(node/'HEAD') and os.path.lexists(node/'objects') and os.path.lexists(node/'refs'):
            pytest.fail('AREA_COM_METADADOS_GIT_BARE', pytrace=False)


@pytest.fixture
def lab(tmp_path, request):
    # Esta fixture só é avaliada após a marca de proteção de coleção acima.
    if not request.config.getoption('--win19-plano-revisado') or os.name != 'nt':
        pytest.skip('PREPARACAO_APENAS; NAO_VALIDADO')
    candidate = request.config.getoption('--win19-candidata')
    if not candidate:
        pytest.fail('CANDIDATA_NAO_INFORMADA', pytrace=False)
    conferir_area_lab(tmp_path, request.config)
    # Conferência do manifesto é pré-condição do roteiro; não confiar só no HEAD.
    root = Path(candidate).absolute()
    conferir_imports(root)
    marker = request.node.get_closest_marker('win19')
    control = marker.args[0] if marker else request.node.callspec.params['id_']
    request.node.user_properties.append(('win19_id_proposto', control))
    request.node.user_properties.append(('DACL_efetiva', 'NÃO_VALIDADO'))
    return tmp_path


@pytest.fixture(autouse=True)
def evidencia_persistente(request, tmp_path):
    """Metadados escritos antes do teste, inclusive para falhas posteriores.

    O futuro executor deve custodiar/copiar a área e JUnit ANTES de limpeza.
    Não são serializados argumentos, exceções brutas, credenciais nem caminhos.
    """
    if not request.config.getoption('--win19-plano-revisado') or os.name != 'nt':
        yield
        return
    conferir_area_lab(tmp_path, request.config)
    path = tmp_path/'win19-eventos.jsonl'
    if os.path.lexists(path):
        pytest.fail('EVIDENCIA_PREEXISTENTE_PRESERVAR', pytrace=False)
    first = True
    def persistir(dados):
        nonlocal first
        with path.open('x' if first else 'a', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps(dados, ensure_ascii=True, allow_nan=False)+'\n')
            stream.flush()
            os.fsync(stream.fileno())
        first = False
    request.node._win19_persistir = persistir
    from suporte_nativo import definir_observador
    definir_observador(persistir)
    persistir(dict(etapa='INICIO', estado='NÃO_VALIDADO', DACL='NÃO_VALIDADO'))
    try:
        yield
        conferir_imports(Path(request.config.getoption('--win19-candidata')).absolute())
    finally:
        definir_observador(None)
