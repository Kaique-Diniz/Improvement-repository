"""Cenários propostos e NÃO EXECUTADOS. Só entradas fabricadas neste módulo.

Não importa testes/fixtures da suíte legada. Não instala ACL, privilégio ou
política. WIN14/16 propõem fluxos completos, ainda sem execução/validação.
Os resultados nunca autorizam homologação DACL nem reconciliação histórica.
"""
import ctypes
from ctypes import wintypes
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import pytest
from suporte_nativo import identidade, remover_entrada_propria

SENTINELA = b'WIN19_SENTINELA_EXTERNA_FABRICADA_NAO_MODIFICAR\x00\xff'


def registrar(request, eixo, **flags):
    dados = dict(eixo=eixo, DACL_efetiva='NÃO_VALIDADO', **flags)
    request.node._win19_persistir(dados)
    request.node.user_properties.append(('win19_evidencia', json.dumps(dados, ensure_ascii=True)))


def arquivo(root, name='sintetico.bin', data=SENTINELA):
    p = root/name
    p.write_bytes(data)
    return p


def snapshot(root):
    result = {}
    stack = [root]
    while stack:
        folder = stack.pop()
        for p in folder.iterdir():
            st = p.lstat()
            assert not (stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400)
            if stat.S_ISDIR(st.st_mode):
                stack.append(p)
            else:
                assert stat.S_ISREG(st.st_mode)
                result[p.relative_to(root).as_posix()] = p.read_bytes()
    return result


class LinkSintetico:
    def __init__(self, link, target, *, directory=False):
        self.link, self.target, self.directory = link, target, directory
    def __enter__(self):
        if os.path.lexists(self.link):
            raise AssertionError('ENTRADA_PREEXISTENTE_PRESERVAR_AREA')
        for parent in self.link.parents:
            st = parent.lstat()
            if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
                raise AssertionError('ANCESTRAL_INESPERADO_PRESERVAR_AREA')
        try:
            self.link.symlink_to(self.target, target_is_directory=self.directory)
        except OSError as exc:
            code = getattr(exc, 'winerror', None)
            if os.name == 'nt' and code == 1314:
                pytest.skip('WIN19_SYMLINK_1314; CONTROLE_NAO_VALIDADO')
            pytest.fail('CRIACAO_LINK_ERRO_INESPERADO_'+str(code), pytrace=False)
        self.identity = identidade(self.link)
        assert self.link.is_symlink()
        assert self.link.resolve(strict=True) == self.target.resolve(strict=True)
        return self.link
    def __exit__(self, *exc):
        if exc[0] is not None:
            return False  # Preservar link/área para auditoria em qualquer falha.
        if not os.path.lexists(self.link):
            raise AssertionError('LINK_DESAPARECEU_DURANTE_TESTE_PRESERVAR_AREA')
        remover_entrada_propria(self.link, self.identity,
                               diretorio=self.directory, reparse=True)


def evidencia(path, *, baseline=False):
    from conversor.adapters.windows_acl_evidence import coletar_evidencia_acl
    # Estes são rótulos SINTÉTICOS, não SIDs reais ou leitura de política efetiva.
    ace = dict(sid='PAPEL_SINTETICO', access_mask=0x110085, ace_flags=0)
    extra = dict(baseline_owner_sid='PAPEL_SINTETICO', baseline_aces=[dict(ace, ace_flags=0x10)]) if baseline else {}
    return coletar_evidencia_acl(str(path), str(path), owner_sid='PAPEL_SINTETICO',
                                group_sid=None, aces=[ace], **extra)


@pytest.mark.win19('WIN-01', 'diagnostico')
def test_win01_nao_autoriza(lab, request):
    p = arquivo(lab)
    ev = evidencia(p)
    assert ev['caminho_coincide'] is True
    assert ev['autoriza_acesso'] is False and ev['aplicada_ao_leitor'] is False
    assert p.read_bytes() == SENTINELA
    registrar(request, 'diagnostico', autoriza=False, aplicada_ao_leitor=False, bytes_preservados=True)


@pytest.mark.win19('WIN-02', 'api_nativa')
def test_win02_alias_real(lab, request):
    from conversor.adapters import windows_acl_evidence as wae
    p = arquivo(lab, 'Arquivo_Sintetico_Com_Nome_Longuissimo.bin')
    fn = ctypes.WinDLL('kernel32', use_last_error=True).GetShortPathNameW
    fn.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
    fn.restype = wintypes.DWORD
    buf = ctypes.create_unicode_buffer(32768)
    n = fn(str(p), buf, len(buf))
    error = ctypes.get_last_error() if not n else None
    registrar(request, 'observacao', controle='WIN-02', api='GetShortPathNameW',
              win32=error, retorno=n, tamanho_buffer=len(buf))
    assert 0 < n < len(buf), 'GET_SHORT_PATH_FALHOU_'+str(error)
    alias = buf.value
    if alias.lower() == str(p).lower():
        pytest.skip('ALIAS_8_3_INDISPONIVEL; NAO_VALIDADO')
    other = arquivo(lab, 'Outro_Arquivo_Com_Nome_Longuissimo.bin')
    assert Path(alias).read_bytes() == SENTINELA
    assert wae._mesmo_path_normalizado(alias, str(p)) is True
    assert wae._mesmo_path_normalizado(alias, str(other)) is False
    assert wae._mesmo_path_normalizado(str(lab/'ausente'), str(p)) is False
    assert p.read_bytes() == other.read_bytes() == SENTINELA
    registrar(request, 'api_nativa', alias_real=True, bytes_preservados=True)


@pytest.mark.win19('WIN-03', 'api_nativa')
def test_win03_ordinal_real(lab, request):
    from conversor.adapters.windows_acl_evidence import _compare_string_ordinal_ignore_case as compare
    # O caminho Windows da candidata chama Kernel32 real; nenhum monkeypatch.
    results = [compare(a,b) for a,b in [('ação.TXT','AÇÃO.txt'),('a','b'),('b','a'),
                ('a\U0001f600x','a\U0001f600y'),('a\U0001f600x','a\U0001f600x'),('ß','ss')]]
    registrar(request,'observacao',controle='WIN-03',retornos_ordinal=results,
              ramo_erro_API_real='NÃO_VALIDADO_SEM_INSTRUMENTACAO')
    assert results[:3] == [0,-1,1] and results[3] != 0 and results[4] == 0 and results[5] != 0
    with pytest.raises(OSError):
        compare('a\0b', 'a')
    registrar(request, 'api_nativa', ordinal=True, nao_BMP=True, nul_recusado=True,
              erro_API_induzido_real=False, ramo_erro_nativo='NÃO_VALIDADO_SEM_INSTRUMENTACAO')


@pytest.mark.win19('WIN-04', 'comparador_diagnostico')
def test_win04_hardlink(lab, request):
    from conversor.adapters.windows_acl_evidence import _mesmo_path_normalizado
    p = arquivo(lab)
    link = lab/'segundo_nome.bin'
    os.link(p, link)  # Erro inesperado não vira skip genérico.
    own_identity = identidade(link)
    try:
        a, b = p.stat(), link.stat()
        assert a.st_ino != 0 and (a.st_dev, a.st_ino) == (b.st_dev, b.st_ino)
        assert a.st_nlink >= 2 and p != link
        assert _mesmo_path_normalizado(str(p), str(link)) is False
        assert p.read_bytes() == link.read_bytes() == SENTINELA
    except BaseException:
        raise  # Preservar entrada e sentinelas em qualquer divergência.
    else:
        remover_entrada_propria(link, own_identity)
    assert p.read_bytes() == SENTINELA
    registrar(request, 'comparador_diagnostico', mesmo_file_id=True, caminhos_distintos=True,
              leitor_producao_testado=False)


@pytest.mark.win19('WIN-05', 'diagnostico')
def test_win05_baseline_sem_autorizacao(lab, request):
    p = arquivo(lab)
    ev = evidencia(p, baseline=True)
    assert ev['analise_baseline']['somente_heranca'] is True
    assert ev['autoriza_acesso'] is False and ev['aplicada_ao_leitor'] is False
    assert p.read_bytes() == SENTINELA
    registrar(request, 'diagnostico', baseline=True, autoriza=False, bytes_preservados=True)


@pytest.mark.parametrize('id_,name,directory', [
    ('WIN-06','registro.json',False), ('WIN-07','chave.bin',False), ('WIN-08','escrita.lock',False),
    ('WIN-09','evidencias',True), ('WIN-10','cabecas',True)], ids=['WIN-06','WIN-07','WIN-08','WIN-09','WIN-10'])
def test_win06_a_win10_link_bbz(lab, request, id_, name, directory):
    from conversor.adapters.document_links_json import RepositorioVinculosJSON
    from conversor.readers.text_support import ErroLeitura
    area = lab/'area'; area.mkdir()
    r = RepositorioVinculosJSON(area)
    assert not any(r.raiz.iterdir()), 'FIXTURE_AREA_NAO_EXCLUSIVA_PRESERVAR'
    assert r.consultar().revisao == 0  # Controle positivo ANTES de introduzir link.
    # Estado previsto na revisão 0: sem registro/chave/evidências/cabeças.
    # Não remover diretórios preexistentes, mesmo vazios, para forçar o cenário.
    layout = {}
    for child in r.raiz.iterdir():
        st = child.lstat()
        if (child.name != 'escrita.lock' or not stat.S_ISREG(st.st_mode)
                or getattr(st, 'st_file_attributes', 0) & 0x400
                or child.read_bytes() != b''):
            raise AssertionError('FIXTURE_LAYOUT_INESPERADO_PRESERVAR_AREA')
        layout[child.name] = identidade(child)
    registrar(request, 'precondicao', controle=id_, revisao_positiva=0,
              evidencias_ausentes=True, cabecas_ausentes=True, lock_residual_vazio=bool(layout))
    external = lab/'externa'; external.mkdir()
    target = external/'destino'
    if directory:
        target.mkdir(); arquivo(target)
    else:
        target.write_bytes(SENTINELA)
    before = snapshot(external)
    entry = r.raiz/name
    if os.path.lexists(entry):
        assert name == 'escrita.lock' and name in layout, 'ENTRADA_INESPERADA_PRESERVAR'
        remover_entrada_propria(entry, layout[name])
    with LinkSintetico(entry, target, directory=directory):
        with pytest.raises(ErroLeitura) as error:
            r.consultar()
        registrar(request, 'observacao', controle=id_, recusa_observada=True,
                  sentinelas_preservadas=snapshot(external) == before)
        assert SENTINELA.decode('latin1') not in str(error.value)
        assert str(lab) not in str(error.value)
        assert snapshot(external) == before
    assert snapshot(external) == before
    registrar(request, 'link_nativo', id=id_, link_criado=True, alvo_inalterado=True)


@pytest.mark.win19('WIN-11', 'git')
def test_win11_git_separado(lab, request):
    import subprocess
    from conversor.adapters.document_links_json import RepositorioVinculosJSON
    from conversor.readers.text_support import ErroLeitura
    regular = lab/'regular'; regular.mkdir()
    assert RepositorioVinculosJSON(regular).consultar().revisao == 0
    root = lab/'git_sintetico'; root.mkdir()
    p = subprocess.run(['git','init',str(root)], capture_output=True, timeout=20)
    assert p.returncode == 0, 'GIT_SINTETICO_NAO_CRIADO'
    witness = arquivo(root)
    with pytest.raises(ErroLeitura):
        RepositorioVinculosJSON(root/'area')
    assert witness.read_bytes() == SENTINELA and not (root/'area').exists()
    registrar(request, 'git', recusa=True, symlink_exigido=False)


@pytest.mark.win19('WIN-11', 'link_nativo')
def test_win11_ancestral(lab, request):
    from conversor.adapters.document_links_json import RepositorioVinculosJSON
    from conversor.readers.text_support import ErroLeitura
    from conversor.web.app import criar_app
    external = lab/'externa'; external.mkdir(); arquivo(external)
    before = snapshot(external)
    with LinkSintetico(lab/'link', external, directory=True) as link:
        with pytest.raises(ErroLeitura):
            RepositorioVinculosJSON(link/'novo')
        with pytest.raises(RuntimeError, match='AREA_PRIVADA_NAO_PODE_SER_LINK'):
            criar_app(link/'app', acesso='4'*64)  # Chave literal de laboratório, não segredo real.
        assert snapshot(external) == before
        assert not (external/'novo').exists() and not (external/'app').exists()
    registrar(request, 'link_nativo', ancestral_recusado=True, alvo_inalterado=True)


@pytest.mark.win19('WIN-12', 'componente_fonte')
def test_win12_mesmos_bytes(lab, request):
    from datetime import datetime, timezone
    from conversor.adapters.document_links_json import RepositorioVinculosJSON
    from conversor.domain.document_links import IdentidadeOrigem, EvidenciaVinculo, VinculoDocumental
    from conversor.domain.canonical import Origem
    from conversor.readers.text_support import ErroLeitura
    area = lab/'area'; area.mkdir(); r = RepositorioVinculosJSON(area)
    digest = r.guardar_fonte(SENTINELA)
    reference = r.guardar_fonte(SENTINELA+b'_REFERENCIA')
    identity = IdentidadeOrigem(administradora_id='adm_sintetica', empreendimento='LABORATORIO SINTETICO',
                               codigo_original='9999', bloco_literal='A', unidade_literal='0001')
    now = datetime(2026,11,18,tzinfo=timezone.utc)
    evidence = tuple(EvidenciaVinculo(papel=role, conciliacao_sha256='3'*64,
        origem=Origem(arquivo_id=role+'_sintetico',sha256=value,leitor_versao='laboratorio-1',
                      pagina=1,linha=1,identificador=role+'_linha'))
        for role,value in (('financeiro',digest),('referencia',reference)))
    record = VinculoDocumental(id=identity.id,identidade=identity,codigos_observados=('9999',),
        condominio_destino_id='cond_sintetico',codigo_destino='9999',versao=1,estado='candidato',
        nome_financeiro_hmac=r.impressao('PESSOA SINTETICA'),perfil_versao='laboratorio-1',
        perfil_sha256='2'*64,evidencias=evidence,recibos_historicos=('recibo_sintetico',),
        registrado_em=now,atualizado_em=now,motivo='Fixture exclusivamente sintetica')
    r.candidatar((record,),revisao_esperada=0,responsavel='PAPEL_LABORATORIO',sessao_sha256='4'*64)
    assert r.consultar().revisao == 1
    assert r.ler_fonte(digest) == SENTINELA
    target = arquivo(lab, 'externa.bin')
    entry = r.fontes/(digest+'.bin')
    own_identity = identidade(entry)
    assert entry.read_bytes() == target.read_bytes() == SENTINELA
    stable_before = {str(p.relative_to(r.raiz)):p.read_bytes()
                    for p in (r.path, r.key, *r.cabecas.iterdir()) if p.is_file()}
    remover_entrada_propria(entry, own_identity)
    with LinkSintetico(entry, target):
        with pytest.raises(ErroLeitura):
            r.ler_fonte(digest)
        with pytest.raises(ErroLeitura):
            r.consultar()
        registrar(request, 'observacao', controle='WIN-12', ler_e_reabrir_recusados=True,
                  alvo_inalterado=target.read_bytes() == SENTINELA)
        assert target.read_bytes() == SENTINELA
        assert all((r.raiz/rel).read_bytes() == data for rel,data in stable_before.items())
    registrar(request, 'fonte_e_acervo', bytes_iguais=True, rejeicao=True,
              reabertura_consultar_com_acervo_completo=True)


@pytest.mark.win19('WIN-13', 'link_nativo')
@pytest.mark.parametrize('externo', [False, True], ids=['interno','externo'])
def test_win13_fonte(lab, request, externo):
    from conversor.adapters.protected_sources import FontesLocaisProtegidas
    from conversor.readers.contracts import FonteProtegida
    from conversor.readers.text_support import ErroLeitura
    area = lab/'area'; area.mkdir()
    target = arquivo(lab if externo else area, 'sentinela.bin')
    source = FonteProtegida(arquivo_id='sintetico', sha256=sha256(SENTINELA).hexdigest())
    if not externo:
        assert FontesLocaisProtegidas(area, {'sintetico':'sentinela.bin'}).ler(source) == SENTINELA
    else:
        arquivo(area, 'controle_regular.bin')
        assert FontesLocaisProtegidas(area, {'sintetico':'controle_regular.bin'}).ler(source) == SENTINELA
        assert target.read_bytes() == SENTINELA
    code = 'FONTE_FORA_DA_AREA_AUTORIZADA' if externo else 'FONTE_CONTEM_LINK'
    with LinkSintetico(area/'link.bin', target):
        with pytest.raises(ErroLeitura) as error:
            FontesLocaisProtegidas(area, {'sintetico':'link.bin'}).ler(source)
        assert str(error.value) == code
        assert target.read_bytes() == SENTINELA
    registrar(request, 'link_nativo', recusa=True, alvo_externo=externo, bytes_preservados=True)


@pytest.mark.win19('WIN-14', 'fluxo_simulacao')
def test_win14_gravar_pacote_autoridade_recibo(lab, request):
    from factories_r2 import preparar_simulacao
    from conversor.application.simulation_inventory import conferir_pacote
    from conversor.adapters.private_simulation_json import conferir_fontes
    from conversor.application.ports import ErroAplicacao
    from conversor.domain.private_simulation import ReciboPrivado
    repo, authority, credential, positive, local = preparar_simulacao(lab, SENTINELA)
    # Controle REAL: modelo -> inventário -> fontes -> autoridade -> recibo -> releitura.
    conferir_pacote(positive); conferir_fontes(positive)
    repo.gravar_pacote(positive, credencial=credential)
    reloaded = repo.carregar_pacote(positive.id)
    body = repo.raiz/'pacote-pacote_positivo.json'
    anchor = repo.ancoras/body.name
    receipt = ReciboPrivado.model_validate_json(anchor.read_bytes())
    authority.verificar(receipt.model_dump(mode='json',exclude={'assinatura'}), receipt.assinatura,
                        dominio='artefato-privado-1.0')
    registrar(request,'precondicao',controle='WIN-14',recibo_verificado=True,
              positivo_recarregado=reloaded==positive,corpo_corresponde=receipt.sha256==sha256(body.read_bytes()).hexdigest())
    assert reloaded == positive and receipt.sha256 == sha256(body.read_bytes()).hexdigest()
    assert receipt.responsavel_id == 'operador_sintetico'
    before_repo, before_anchors = snapshot(repo.raiz), snapshot(repo.ancoras)
    external = lab/'externa'; external.mkdir(); target = arquivo(external)
    before_external = snapshot(external)
    # Mesmo pacote válido com novo ID. Revalidar antes de trocar apenas a fonte.
    attack = type(positive).model_validate(positive.model_dump()|{'id':'pacote_link'})
    conferir_pacote(attack); conferir_fontes(attack)
    own_identity = identidade(local)
    assert local.read_bytes() == target.read_bytes() == SENTINELA
    remover_entrada_propria(local, own_identity)
    with LinkSintetico(local, target):
        with pytest.raises(ErroAplicacao) as caught:
            repo.gravar_pacote(attack, credencial=credential)
        unchanged = (snapshot(repo.raiz)==before_repo and snapshot(repo.ancoras)==before_anchors
                     and snapshot(external)==before_external)
        registrar(request,'observacao',controle='WIN-14',gravacao_recusada=True,
                  codigo_esperado=str(caught.value)=='CAMINHO_COM_LINK_NAO_PERMITIDO',
                  corpo_recibo_sentinelas_inalterados=unchanged)
        assert str(caught.value) == 'CAMINHO_COM_LINK_NAO_PERMITIDO'
        assert unchanged
        assert not (repo.raiz/'pacote-pacote_link.json').exists()
        assert not (repo.ancoras/'pacote-pacote_link.json').exists()
    assert snapshot(external) == before_external
    registrar(request,'fluxo_simulacao',gravar_pacote_com_autoridade_real_testado=True,
              recibo_positivo_verificado=True,ataque_sem_corpo_e_recibo=True,DACL_validada=False)


def lote_com_conflito():
    from conversor.domain.canonical import Origem, Unidade, Pessoa, Documento, EvidenciaDocumento, LoteCanonico
    origin = Origem(arquivo_id='sintetica', sha256='1'*64, leitor_versao='laboratorio-1',
                    pagina=1, linha=1, identificador='linha_sintetica_1')
    unit = Unidade(id='unidade_sintetica', condominio_id='cond_sintetico', administradora_id='adm_sintetica',
        bloco_original='TORRE SINTETICA', unidade_original='0001', chave_normalizada='sintetica:0001',
        normalizador_versao='laboratorio-1', origem=origin)
    p = Pessoa(id='pessoa_sintetica', unidade_id=unit.id, nome='PESSOA SINTETICA', origem=origin,
        relacao_unidade='titular_sintetico',
        documento=Documento(tipo='cpf', valor='00000000191'), evidencias_documentais=(
            EvidenciaDocumento(documento=Documento(tipo='cnpj',valor='00000000000191'),
                               origem=origin, titular_id='pessoa_sintetica'),))
    return LoteCanonico(unidades=(unit,), boletos=(), pessoas=(p,)), p


@pytest.mark.win19('WIN-16', 'fluxo_cli_documental')
def test_win16_cli_pdf_conflito_sem_mock(lab, request):
    import subprocess
    import sys
    from factories_r2 import preparar_cli_conflito
    from conversor.export.contract import LinhaExportacao
    from pydantic import ValidationError
    candidate = Path(request.config.getoption('--win19-candidata')).absolute()
    inputs = []
    for conflict in (False, True):
        root = lab/('conflito' if conflict else 'positivo')
        manifest, expected = preparar_cli_conflito(root, conflito=conflict)
        before = snapshot(root)
        environment = os.environ.copy()
        environment.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',
                           PYTHONPATH=str(candidate/'src')+os.pathsep+str(candidate))
        process = subprocess.run([sys.executable,'-B','-m','conversor.validacao_leitores',
            '--raiz',str(root),'--manifesto',str(manifest),'--saida',str(root/'resultado')],
            cwd=candidate,env=environment,capture_output=True,timeout=60)
        # Persistir resumo e SHA das saídas ANTES de avaliar asserções.
        registrar(request,'observacao_cli',controle='WIN-16',conflito=conflict,retorno=process.returncode,
                  stdout_sha256=sha256(process.stdout).hexdigest(),stderr_sha256=sha256(process.stderr).hexdigest())
        # Saídas brutas ficam somente no laboratório sintético para custódia posterior.
        (lab/('conflito' if conflict else 'positivo')).joinpath('stdout.bruto').write_bytes(process.stdout)
        (root/'stderr.bruto').write_bytes(process.stderr)
        report = json.loads((root/'resultado/relatorio_leitores.json').read_text(encoding='utf-8'))
        item = report['casos'][0]
        safe = all(token not in process.stdout+process.stderr for token in
                   (b'00000000191',b'00000000000191',str(lab).encode('utf-8')))
        unchanged = all((root/rel).read_bytes()==data for rel,data in before.items())
        registrar(request,'observacao_cli',controle='WIN-16',conflito=conflict,
                  total_divergencias=item.get('total_campos_divergentes'),
                  fontes_gabarito_preservados=unchanged,saida_sem_documentos_ou_caminhos=safe,
                  revisao_humana=item.get('status')=='revisao_humana')
        assert process.returncode == (2 if conflict else 0)
        assert item['status'] == ('revisao_humana' if conflict else 'comparacao_confere')
        assert item['total_campos_divergentes'] == 0
        assert item['unidades'] == item['pessoas'] == 1 and item['boletos'] == 0
        assert safe and unchanged and report['homologado_producao'] is False
        assert not list((root/'resultado').glob('*.canonico.json'))
        assert not list(root.rglob('*.xlsx'))
        if conflict:
            audit = json.loads((root/'resultado/conflito.revisao_documental.json').read_text(encoding='utf-8'))
            occurrences = [o for o in audit['ocorrencias'] if o['codigo']=='DOCUMENTOS_CONFLITANTES']
            registrar(request,'observacao_cli',controle='WIN-16',ocorrencias_conflito=len(occurrences),
                      auditoria_nao_homologada=audit['homologado_producao'] is False)
            assert len(occurrences) == 1 and audit['homologado_producao'] is False
            assert {(e['documento']['tipo'],e['documento']['valor']) for e in occurrences[0]['evidencias_documentais']} == {
                ('cpf','00000000191'),('cnpj','00000000000191')}
            # O CLI é deliberadamente SEM exportação. Verificar também a barreira
            # pública do DTO de exportação sobre o gabarito independente conflitante.
            with pytest.raises(ValidationError,match='REVISAO_HUMANA'):
                LinhaExportacao(processamento_id='win19_sintetico',registro_id=expected.unidades[0].id,
                    tipo='cadastral',nm_cedente_cedente='SINTETICO',cedente='0001',pessoa=expected.pessoas[0])
        inputs.append(before)
    registrar(request,'fluxo_cli_documental',CLI_real=True,PDF_sintetico_posicionado=True,
              conflito_lido_sem_mock=True,gabarito_independente_do_leitor=True,
              exportacao_DTO_recusada=True,exportacao_operacional_executada=False)


@pytest.mark.win19('WIN-17', 'funcional_json')
def test_win17_roundtrip(lab, request):
    from conversor.application.reading import resultado_leitura
    from conversor.adapters.private_json import escrever_json
    lote, _ = lote_com_conflito()
    result = resultado_leitura(lote, processamento_id='win19_sintetico')
    occ = next(o for o in result.ocorrencias if o.codigo == 'DOCUMENTOS_CONFLITANTES')
    dest = lab/'auditoria.json'; escrever_json(dest, occ.model_dump(mode='json'))
    raw = dest.read_bytes()
    assert type(occ).model_validate_json(raw) == occ
    expected = (json.dumps(occ.model_dump(mode='json'), ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)+'\n').encode('utf-8')
    assert raw == expected and dest.read_bytes() == raw
    registrar(request, 'funcional_json', roundtrip=True, bytes_preservados=True, DACL_validada=False)


@pytest.mark.win19('WIN-18', 'dacl_pendente')
def test_win18_protocolo_aguarda_politica(lab):
    pytest.skip('POLITICA_DACL_PARA_APROVACAO; TOKENS_DISTINTOS_NAO_PROVISIONADOS; NAO_VALIDADO')


@pytest.mark.win19('WIN-19', 'dacl_pendente')
def test_win19_protocolo_aguarda_politica(lab):
    pytest.skip('POLITICA_DACL_PARA_APROVACAO; TOKENS_DISTINTOS_NAO_PROVISIONADOS; NAO_VALIDADO')


def preparar_manifesto_opcao(root):
    """Fixture de opção de saída. Gabarito de contrato, NÃO oracle financeiro."""
    from examples.fase2.gerar_demo import pdf_sintetico
    from conversor.validacao_leitores import ManifestoValidacao, _ContextosDeclarados
    from conversor.adapters.protected_sources import FontesLocaisProtegidas
    from conversor.readers.operational import RegistroLeitores
    texts = {
        'habita': ['Inadimplencia Atualizada\nCondominio: 9999 - LAB\nAdministradora: ADM-LAB\nCodigo Condominio: 9999\n'
            'Bloco: DEP  Unidade: 000001  TITULAR SINTETICO  CPF: (ausente)\n'
            '10000001  17/09/26  202609  94  COTA 100,00 2,00 1,00 103,00\n'
            'Total do boleto: 100,00 2,00 1,00 103,00\nTotal da Unidade: 100,00 2,00 1,00 103,00'],
        'fl': ['FL CONDOMINIOS - Relatorio W002A\nW002A CONDOMINIO EDIFICIO LAB (AMOSTRA SINTETICA)\n'
            'Inadimplencia com composicao\n0001 TORRE A - TITULAR SINTETICO\n'
            'Venc. Comp. Cod. Descricao Valor Saldo\n17/09/26 09/2026 900001 COTA 200,00 200,00\n'
            'FIM DO RELATORIO: 1 UNIDADES E 1 BOLETOS'],
        'cadastro': ['W045A CONDOMINIO EDIFICIO LAB (AMOSTRA SINTETICA)\n'
            '0001 TORRE A  TITULAR SINTETICO  Proprietario  Rua Exemplo, 1  (vazio)  win19@example.invalid\n+55 11 90000-0001'],
    }
    (root/'fontes').mkdir(); (root/'gabaritos').mkdir()
    cases = []
    for family, pages in texts.items():
        data = pdf_sintetico(pages)
        (root/'fontes'/(family+'.pdf')).write_bytes(data)
        cases.append(dict(id=family, fonte=dict(arquivo_id=family,sha256=sha256(data).hexdigest()),
            arquivo='fontes/'+family+'.pdf', gabarito='gabaritos/'+family+'.json', gabarito_sha256='0'*64,
            leitor_id='cadastro_fl_sintetico_v1' if family=='cadastro' else family+'_composicao_sintetico_v1',
            formato_id='fmt_'+family, condominio_id='cond_lab', administradora_id='adm_lab',
            codigo_condominio='9999' if family=='habita' else 'LAB', data_ref='2026-10-20'))
    data = dict(finalidade='validacao_privada_fase3', natureza='sintetica',autorizacao_id='win19_fixture',casos=cases)
    config = ManifestoValidacao.model_validate(data)
    reader = RegistroLeitores(FontesLocaisProtegidas(root,{c.fonte.arquivo_id:c.arquivo for c in config.casos}),
                              _ContextosDeclarados(config.casos))
    for item, case in zip(cases,config.casos):
        canonical = reader.obter(case.leitor_id,case.leitor_versao).ler(case.fonte,
                    formato_id=case.formato_id,condominio_id=case.condominio_id)
        raw = canonical.model_dump_json().encode('utf-8')
        (root/case.gabarito).write_bytes(raw)
        item['gabarito_sha256'] = sha256(raw).hexdigest()
    path=root/'manifesto.json';path.write_text(json.dumps(data),encoding='utf-8')
    return path


@pytest.mark.win19('WIN-15', 'funcional_opcao')
def test_win15_opcao_explicita(lab, request):
    from conversor.validacao_leitores import executar_validacao
    manifest = preparar_manifesto_opcao(lab)
    before = {n:sha256((lab/n).read_bytes()).hexdigest() for n in ('manifesto.json',
        'fontes/habita.pdf','fontes/fl.pdf','fontes/cadastro.pdf')}
    a = executar_validacao(lab,manifest,lab/'sem_canonicos')
    b = executar_validacao(lab,manifest,lab/'com_canonicos',salvar_canonicos=True)
    assert all(c['status']=='comparacao_confere' for c in a['casos']+b['casos'])
    assert not list((lab/'sem_canonicos').glob('*.canonico.json'))
    assert len(list((lab/'com_canonicos').glob('*.canonico.json'))) == 3
    assert a['homologado_producao'] is b['homologado_producao'] is False
    assert all(sha256((lab/n).read_bytes()).hexdigest()==h for n,h in before.items())
    registrar(request, 'funcional_opcao', padrao_sem_canonicos=True, opt_in_canonicos=3,
              gabarito_financeiro_independente=False, DACL_validada=False)
