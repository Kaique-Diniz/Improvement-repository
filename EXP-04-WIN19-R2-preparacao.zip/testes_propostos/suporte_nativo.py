"""Suporte de ensaio R2, NÃO EXECUTADO. Não é código do produto.

Exclusão por handle, sem seguir a entrada reparse. Não remove árvores.
Qualquer identidade/ancestral inesperado interrompe e preserva a área.
As rotinas somente poderão ser chamadas numa rodada Windows autorizada.
"""
import ctypes
from ctypes import wintypes as w
import os
from pathlib import Path
import stat
import time

_observador = None


def definir_observador(funcao):
    global _observador
    _observador = funcao


class ImpedimentoFixture(RuntimeError):
    pass


class Informacao(ctypes.Structure):
    _fields_ = [('atributos', w.DWORD), ('criacao', w.FILETIME),
                ('acesso', w.FILETIME), ('escrita', w.FILETIME),
                ('volume', w.DWORD), ('tamanho_alto', w.DWORD),
                ('tamanho_baixo', w.DWORD), ('links', w.DWORD),
                ('indice_alto', w.DWORD), ('indice_baixo', w.DWORD)]


def _api():
    if os.name != 'nt':
        raise ImpedimentoFixture('WINDOWS_NATIVO_OBRIGATORIO')
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, ctypes.c_void_p,
                            w.DWORD, w.DWORD, w.HANDLE]
    k.CreateFileW.restype = w.HANDLE
    k.GetFileInformationByHandle.argtypes = [w.HANDLE, ctypes.POINTER(Informacao)]
    k.GetFileInformationByHandle.restype = w.BOOL
    k.SetFileInformationByHandle.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD]
    k.SetFileInformationByHandle.restype = w.BOOL
    k.CloseHandle.argtypes = [w.HANDLE]
    k.CloseHandle.restype = w.BOOL
    return k


def _falhar(api, code):
    # Não acrescentar str(OSError), caminhos ou nomes privados.
    if _observador is not None:
        _observador(dict(etapa='SUPORTE_FIXTURE',api=api,win32=code,
                         estado='FALHOU_PRESERVAR_AREA',DACL='NÃO_VALIDADO'))
    raise ImpedimentoFixture('FIXTURE_'+api+'_'+str(code)+'_PRESERVAR_AREA')


def _abrir(k, p, acesso, share):
    # OPEN_EXISTING, BACKUP_SEMANTICS | OPEN_REPARSE_POINT, sem truncar/criar.
    h = k.CreateFileW(str(p), acesso, share, None, 3, 0x02200000, None)
    if h == ctypes.c_void_p(-1).value or h is None:
        code = ctypes.get_last_error()
        _falhar('CreateFileW', code)
    return h


def _info(k, h):
    value = Informacao()
    if not k.GetFileInformationByHandle(h, ctypes.byref(value)):
        code = ctypes.get_last_error()
        _falhar('GetFileInformationByHandle', code)
    ident = (value.volume, value.indice_alto, value.indice_baixo)
    if not (value.indice_alto or value.indice_baixo):
        raise ImpedimentoFixture('IDENTIDADE_INDISPONIVEL_PRESERVAR_AREA')
    return ident, value.atributos


def _fechar(k, h):
    if not k.CloseHandle(h):
        code = ctypes.get_last_error()
        _falhar('CloseHandle', code)


def identidade(p):
    """Fotografia da entrada, não do alvo; não prova DACL ou imutabilidade."""
    k = _api()
    h = _abrir(k, p, 0x80, 0x7)  # READ_ATTRIBUTES, share R/W/DELETE.
    try:
        return _info(k, h)
    finally:
        _fechar(k, h)


def remover_entrada_propria(p, esperado, *, diretorio=False, reparse=False):
    """Somente entrada previamente identificada. Sem recurse/resolve/rmtree.

    Os ancestrais ficam presos sem FILE_SHARE_DELETE durante a operação;
    a entrada é aberta sem seguir reparse e comparada antes de marcar exclusão.
    Impedimento de leitura/compartilhamento é falha, nunca autorização alternativa.
    """
    p = Path(p)
    if not p.is_absolute() or '..' in p.parts:
        raise ImpedimentoFixture('CAMINHO_INVALIDO_PRESERVAR_AREA')
    k = _api()
    pins = []
    h = None
    try:
        for parent in reversed(p.parents):
            st = parent.lstat()
            if not stat.S_ISDIR(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
                raise ImpedimentoFixture('ANCESTRAL_INESPERADO_PRESERVAR_AREA')
            pin = _abrir(k, parent, 0x80000000, 0x3)  # GENERIC_READ, sem SHARE_DELETE.
            pins.append(pin)
            _, attrs = _info(k, pin)
            if not attrs & 0x10 or attrs & 0x400:
                raise ImpedimentoFixture('ANCESTRAL_REDIRECIONADO_PRESERVAR_AREA')
        h = _abrir(k, p, 0x10080, 0x3)  # DELETE | READ_ATTRIBUTES, sem SHARE_DELETE.
        ident, attrs = _info(k, h)
        if ((ident, attrs) != esperado or bool(attrs & 0x10) != diretorio
                or bool(attrs & 0x400) != reparse):
            raise ImpedimentoFixture('ENTRADA_SUBSTITUIDA_PRESERVAR_AREA')
        # FileDispositionInfo(4) usa BOOLEAN de um byte; não BOOL de quatro.
        flag = ctypes.c_ubyte(1)
        if not k.SetFileInformationByHandle(h, 4, ctypes.byref(flag), ctypes.sizeof(flag)):
            code = ctypes.get_last_error()
            _falhar('SetFileInformationByHandle', code)
    finally:
        # Tentar fechar TODOS os handles, inclusive se outro fechamento falhar.
        erros = []
        for pin in ([h] if h is not None else []) + list(reversed(pins)):
            try:
                _fechar(k, pin)
            except ImpedimentoFixture as error:
                erros.append(error)
        if erros:
            raise erros[0]
    # Uma única solicitação de exclusão; observação limitada do término pendente.
    for attempt in range(6):
        try:
            p.lstat()
        except FileNotFoundError:
            return
        except OSError:
            raise ImpedimentoFixture('AUSENCIA_NAO_COMPROVADA_PRESERVAR_AREA') from None
        if attempt < 5:
            time.sleep(0.02)
    raise ImpedimentoFixture('EXCLUSAO_NAO_CONCLUIDA_PRESERVAR_AREA')
