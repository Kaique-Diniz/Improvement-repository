# WIN19-R2 — plano para revisão, sem execução

Data: 18/11/2026. Nenhum preflight, teste, coleta pytest, link, conta ou DACL
foi executado/criado nesta R2. Todos os 19 vínculos seguem provisórios e todos
os eixos funcional, nativo e DACL seguem NÃO_VALIDADO.

## Portões e custódia

A: preparação R2 entregue para revisão. B: preflight SOMENTE LEITURA depende
de aprovação específica do roteiro e caminhos. C: ensaios sintéticos BLOQUEADOS
até revisão de código/factories, trilha de diagnóstico e autorização futura.
D: acesso entre tokens/DACL BLOQUEADO até política e ambiente aprovados.
E: homologação/conversões reais/publicação/merge BLOQUEADOS.

CHECKLIST_CUSTODIA_JUNIT_R2.json descreve a obtenção dos originais EXP-04:
XML, log, relatório, 19 nodeids, sete motivos de skip, versão/448 hashes e
cadeia de custódia. Não executar o extrator nem confirmar vínculos nesta R2.
O extrator distingue nodeid candidato de nodeid confirmado e não aprova vínculos.
Revisor deve conferir contadores, duplicatas, parâmetros, traceback e versão.

## Preflight somente leitura, ainda não autorizado

Os scripts tools/preflight_win19.py/.ps1 continuam apenas inventário: Git,
470 hashes antes/depois, Windows/Python3.12/UTF-8, tipo/capacidades do volume
real de montagem, token via TOKEN_QUERY, Developer Mode lido e alias existente.
Nenhuma criação/limpeza de área, link, conta, ACL, privilégio ou arquivo de log.
A saída JSON é agregada, sem caminhos pessoais, SID, SDDL ou nomes de conta.
A área futura deve ser nova, direta sob LocalAppData registrado, fora do Git
e sem sobreposição às candidatas; existência prévia bloqueia e preserva.
Não contornar políticas do PowerShell para rodá-lo. Não instalar dependências.

Saída 0 significa COLETA CONCLUÍDA, inclusive com impedimentos. Examinar a
lista impedimentos e coleta_concluida; prontidao_para_executar fica false.
Volume não NTFS, ACL persistente não confirmada, symlink não demonstrado, alias
indisponível, política/tokens/originais ausentes são explícitos. Developer Mode
ou privilégio observado não provam criação de link. Erros operacionais, elevação
ou divergência de hashes retornam 2. Nenhum retorno abre os portões C/D/E.
PowerShell 5.1 e APIs nativas permanecem sem nova execução nesta R2.

## Especificação do executor futuro (não implementado)

Não é fornecido lançador nem comando pytest nesta entrega. A futura autorização
deve nomear candidata, hashes dos testes de preparação, área e custodiante.

1. Python 3.12, UTF-8 só no processo, -B, PYTHONDONTWRITEBYTECODE=1,
   plugin de cache pytest desabilitado e sem gravação/coleta na candidata.
   Não instalar dependências, usar configuração Git global ou coletar legado.
   Sem xdist/paralelismo: casos sequenciais e observador exclusivo por caso.
2. Reservar área WIN19 exclusiva, absoluta e curta, fora de Git/documentos/
   candidatas/resíduos. Basetemp NOVO inexistente e de uso único. Não entregar
   a pytest um diretório com conteúdo: pytest pode apagar basetemp existente.
   Guardar identidade da área, verificar ancestrais sem reparse e sobreposições.
3. Conferir SHA do manifesto de referência a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c
   e todos os 470 arquivos/extras ANTES e DEPOIS; também registrar bytes/hashes
   dos cenários R2 efetivamente executados, dependências e comando. HEAD não basta.
4. Recusar módulos conversor/examples já importados de outra candidata;
   resolver origem antes de importar e conferi-la após cada caso. Processo CLI
   recebe PYTHONPATH da candidata conferida, cwd correspondente e -B.
5. Controle positivo válido antes de cada adversarial. Falha de fixture não é
   aprovação de segurança. 1314 somente no cenário dependente de symlink;
   outros erros são falha/impedimento identificado, nunca skip amplo.
6. Persistir diagnóstico e fsync ANTES de cada asserção relevante: fase,
   operação/API, retorno e código capturado imediatamente, capacidade real,
   preservação integral de bytes e snapshots. Não usar str(OSError) bruto em
   resumo partilhável. Se a aplicação não expõe a API/código de origem, registrar
   API_NAO_OBSERVAVEL e manter esse subeixo NÃO_VALIDADO; não inventar código.
   O suporte proposto já persiste falhas das próprias APIs; não é instrumentação
   do motor. Completar a trilha por caso na revisão do executor antes de rodar.
7. O conftest propõe evento INICIO/fsync e verificação de imports; WIN06–10/12/14/16
   têm observações intermediárias. Isso NÃO substitui executor resistente a
   interrupção nem evidência primária da API do produto. Não há execução R2.
8. JUnit, relatório parcial e brutos devem ficar em área de evidências fora
   do basetemp; copiar eventos antes de qualquer limpeza. Sanitizado separado
   com SHA raw/derivado, sem dados pessoais, caminhos, SIDs, chaves ou tokens.
   Relatório parcial existe mesmo com falha ou interrupção; não marcar sucesso.
9. Em falha de sentinela, identidade, origem/import, hash, API inesperada ou
   limpeza incompleta: interromper, preservar laboratório e JUnit. Nunca varrer
   resíduos antigos ou remover destinos externos. Sucesso funcional não homologa
   DACL e nenhum skip é PASS. Sem restauração/descarte automático de divergências.

## Cenários por controle

WIN01/05: flags diagnósticas e baseline fabricado; não são leitura DACL real.
WIN02: alias 8.3 verdadeiro, arquivo diferente e bytes completos; sem alias,
subcontrole NÃO_VALIDADO, sem nome curto artificial como substituto.
WIN03: ordinal nativo Unicode/case/não-BMP proposto. NUL é recusa anterior à
API. Ramo de erro real NÃO_VALIDADO_SEM_INSTRUMENTACAO: não há indução segura
demonstrada com buffers/contagens válidos no wrapper atual. Não chamar API com
ponteiro inválido, forçar memória, mockar retorno nem modificar produção para
fabricar PASS. Exigir revisão específica se esse ramo for condição de aceite.
WIN04: hardlink com file ID comum e nomes distintos; contrato do comparador
ACL diagnóstico, sem impor rejeição universal ao leitor de produção ID+SHA.

WIN06–10: raiz interna exclusiva de RepositorioVinculosJSON, revisão zero;
inspecionar layout após consultar. Registro/chave/evidencias/cabecas devem estar
ausentes nesta factory mínima. Só lock residual regular e vazio é previsto.
Diretório evidencias/cabecas inesperadamente existente, link quebrado, arquivo
ou lock não vazio ABORTA/PRESERVA; não apagar para forçar o cenário. A remoção
de lock próprio conferido e dos links usa identidade e handle sem seguir reparse.

WIN11 separa Git sintético de ancestral simbólico. WIN12 prepara acervo/evento,
HMAC e fontes pelos fluxos reais, registra positivo e preserva registro/chave/
cabeças antes/depois de substituir só a fonte própria por link de mesmos bytes.
WIN13 separa link interno/externo; espera FONTE_CONTEM_LINK versus
FONTE_FORA_DA_AREA_AUTORIZADA pela ordem do leitor, sem equiparar a DACL.

WIN14 agora propõe gravar_pacote real, não SimpleNamespace/conferir_fontes
isolado. Factory mínima válida: uma unidade, quatro catálogos revisados da
fixture, inventário/atesto sintéticos, autoridade HMAC e credencial efêmera
somente da aplicação de laboratório. Nenhuma regra de cobrança é aprovada.
Gravar/recarregar positivo, verificar assinatura e SHA do recibo; depois novo
ID válido com fonte trocada por link. Espera CAMINHO_COM_LINK_NAO_PERMITIDO,
sem novo corpo/recibo, bytes antigos e sentinela externa intactos. Não partilhar
chave, credencial ou política bruta. Não prova isolamento DACL da autoridade.

WIN15 mantém opção explícita em três PDFs sintéticos. Gabarito derivado do
leitor só para contrato de saída, não oráculo financeiro independente. Revisão
estática registrou domínios, códigos, SHA e opções; sem validar factory em runtime.
WIN16 propõe PDF W045A posicionado com dois documentos fabricados válidos; CLI
real em subprocesso, sem mock. Controle de um documento deve retornar 0. Conflito
deve retornar 2/revisao_humana com zero diferenças contra gabarito declarativo
construído sem executar leitor, preservar auditoria CPF/CNPJ e inputs, nenhum
canônico/XLSX. DTO de exportação deve recusar pessoa conflitante. O CLI é de
validação, sem exportação operacional; ausência de XLSX nele não aprova todos os
fluxos do MVP. Coordenadas/linhas/IDs/ressalvas requerem futura validação de runtime.
WIN17 verifica roundtrip JSON/bytes, não proteção DACL.
WIN18/19 continuam protocolos marcados pendentes, sem código de impersonação,
sem acesso entre contas e sem chmod como prova NTFS.

Expansão PREVISTA: 21 casos para 19 IDs (WIN11 e WIN13 em dois subcasos),
apenas contagem estrutural, NÃO coleta. WIN14/16 continuam um caso cada, com
positivo/adversarial internos. Nenhum caso executado ou aprovado nesta R2.

## Segurança da preparação e reconstrução futura

LinkSintetico rejeita lexists antes de criar, guarda identidade da entrada e
preserva em exceção. Suporte proposto abre a entrada OPEN_REPARSE_POINT,
compara file ID/atributos e prende ancestrais sem SHARE_DELETE durante remoção
por handle; não há recurse/resolve para excluir alvo. Poll de ausência: seis
observações, uma única solicitação de exclusão. Falha CloseHandle ou ausência
não comprovada aborta. O helper também é candidato, não prova validada Windows.
Recursos normais do laboratório ficam preservados até custódia/revisão.

Não é necessária nova reconstrução da R1-FIX para a R2: preparação externa.
Se futuramente aprovada reconstrução isolada, destino inexistente, base
770d062d29c4361d6932592883df9339bb4089bc, pacote R1-FIX preservado e os mesmos
470 hashes. LF imposto em variáveis GIT_CONFIG_COUNT/KEY_n/VALUE_n só do processo,
com append e restauração em finally, antes de Python e Git descendentes.
Não usar git config persistente nem converter bytes divergentes silenciosamente.

PARE após revisar. Qualquer preflight, coleta ou execução nativa requer nova
autorização específica. DACL PARA_APROVAÇÃO e conversões reais BLOQUEADAS.
