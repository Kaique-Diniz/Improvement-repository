> FONTE HISTÓRICA DA PRIMEIRA PREPARAÇÃO. Nesta cópia R2, consulte RELATORIO_R2.md e PROVENIENCIA_R2.json para verificações atuais. Nenhum resultado antigo foi reexecutado.

# EXP-04 / WIN-19 — proveniência, reconciliação e limites da primeira entrega

Data documental: 18/11/2026. Etapa exclusivamente de preparação, sem executar
novos testes. Homologação DACL e controles WIN-01…WIN-19 permanecem NÃO_VALIDADO.
Conversões reais continuam BLOQUEADAS. Não se retomou a falha de reconstrução
anterior: o usuário encerrou a R1-FIX com ressalvas e definiu esta nova etapa.

## 1. Materiais efetivamente recebidos

Foram recebidos e lidos integralmente:

- ENCERRAMENTO_R1_FIX_2026-11-18.md;
- INSTRUCOES_CODEX_VALIDACAO_INDEPENDENTE_WIN19.md;
- MATRIZ_WIN19_REFERENCIA.csv (UTF-8 com BOM, CRLF, 19 linhas lógicas).

As cópias em fontes_recebidas preservam os bytes originais. O CSV derivado foi
parseado como UTF-8-sig/`;`, sem modificar a matriz recebida. Os respectivos
SHA-256 estão em MANIFESTO_EVIDENCIAS_WIN19.json, com origem e locais sanitizados.
A matriz recebida é MODELO INICIAL; não são resultados observados.

O termo declara dois ZIPs Windows auditados por quem o emitiu, com hashes:

| Material | SHA-256 declarado | Situação nesta tarefa |
|---|---|---|
| R1-FIX-EVIDENCIAS-WINDOWS.zip | e93946268ab7404a81c26ff65f578c799853d13554ab4a4dcae6b2169fc08632 | Não recebido; CRC/JUnit/recibos não refeitos pelo Codex |
| R1-FIX-SUITE39-WINDOWS.zip | 9ffe6e9890e59858d043334ef7f1b59d1d92a1b5bd82a4e17507492d0c8d20bd | Não recebido; CRC/JUnit/relatório não refeitos pelo Codex |

Esses hashes são DECLARAÇÕES de origem, distintos de hashes calculados localmente.
Não os apresentar como arquivos disponíveis/verificados nesta entrega.

## 2. Candidata e vínculo com o encerramento

O pacote local EXP-04-R1-FIX-candidata.zip tem SHA-256
`1fe4edaf22deab3b6ae7143e3969b810e91421a3c5467b45685ad3baa750e345`,
conferido localmente e igual ao termo. Seu manifesto VERSAO_R1_FIX_SHA256.json
(cópia REFERENCIA_R1_FIX_470_SHA256.json) tem SHA-256
`a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`,
também calculado localmente e igual ao declarado para as execuções Windows.

Os 470 caminhos da candidata local foram conferidos. Foi criada worktree
separada de preparação e reconstruída a mesma referência: 470 hashes iguais,
sem arquivos WIN19 dentro dela. Baseline detached
`770d062d29c4361d6932592883df9339bb4089bc`. Nenhuma mudança em motor/executor,
parsers, regras, perfis, contrato XLSX, cadastro, política ou bloqueio.

Essa igualdade vincula a referência documental aos bytes locais, mas NÃO
reproduz por si a checagem dos 470 arquivos no computador Windows do usuário:
os ZIPs de evidência citados não contêm toda a candidata. O limite foi preservado.

## 3. Histórico original e reconciliação dos 19 vínculos

A fonte necessária é o JUnit/log/relatório bruto EXP-04 da rodada de 2.842 casos,
19 falhas e sete skips, com versão/manifesto, integridade e proveniência Windows.
Ela não foi recebida/localizada. O próprio termo confirma que os nodeids/motivos
individuais originais não estavam nos materiais então revisados.

Confrontos realmente realizados:

1. As 19 linhas do CSV recebido coincidem textualmente com as 19 correspondências
   propostas em tools/exp04_win/casos_historicos.json: API 5, LINK 9, MODO 3, CHMOD 2.
2. Os testes propostos existem na referência R1-FIX e foram examinados por AST,
   asserções, parametrização e condições de plataforma; linhas e hashes registrados.
3. Foram comparados nós AST de cada função com o BPQ-04: isto distingue alteração
   do teste e condicionamento POSIX/Windows, sem presumir igualdade pelo nome.
4. Três JUnit LOCAIS LINUX existentes foram indexados. Nodeids propostos neles
   encontrados não confirmam falhas Windows originais. Origem/contagens e relações
   textuais estão em INDICE_JUNIT_CONSULTADOS.json. Um XML antigo malformado foi
   detectado em área de evidências: seu hash foi registrado, sem correção, extração
   parcial ou uso para pareamento. Nenhuma evidência foi sobrescrita.

Resultado da reconciliação: **0 VINCULO_CONFIRMADO, 0 VINCULO_DIVERGENTE aferido,
19 PROVISORIO_SEM_FONTE**. Zero divergentes não significa equivalência provada:
simplesmente não há fonte original para confrontar. Campos nodeid_historico_exato,
hash_evidencia_nativa e sete motivos originais permanecem vazios/não fornecidos.

O extrator tools/extrair_junit_historico.py foi preparado, NÃO executado sobre
uma fonte Windows inexistente. Não confirma vínculos automaticamente. Ele usa
parser protegido, preserva IDs exatos conhecidos/parâmetros e representa IDs
não listados por hash, evitando divulgar parâmetros privados. Tracebacks/motivos
originais devem ser examinados em custódia privada, junto da versão e integridade,
antes de compartilhar uma cópia sanitizada. Contagens agregadas nunca bastam.

## 4. Encerramento R1-FIX tratado como evidência documental fornecida

O termo registra: isolado 1 PASS; R1 três PASS; cleanup 36 PASS/3 SKIP/zero falhas;
CreateFileW/32 com GENERIC_READ/0x3, auxiliar ativo e nove bytes íntegros após
liberação; limpeza REMOVIDO, 124 exclusões/124 ausências/zero falhas, integridade
final verdadeira. Isso é transcrição do documento recebido, NÃO nova execução.
As rodadas se sobrepõem; não somar como testes únicos.

Skips explicitados no termo (só aquela suíte de cleanup):

- interrupção POSIX;
- errno POSIX;
- symlink nativo não exercitado por WinError 1314.

Não são os nove controles LINK históricos e não reconciliam os sete skips EXP-04.
Nenhum dos 36 PASS foi transportado para teste_funcional, controle_nativo ou DACL
na nova matriz. Todos permanecem NÃO_VALIDADO; resultado_nativo = NAO_EXECUTADO.
A declaração de sucesso operacional da limpeza não é comprovação de isolamento.

## 5. Achados de inspeção das asserções

O inventário completo por função/linha está em INVENTARIO_ASSERCOES_WIN19.json.
A matriz revisada separa vínculo, teste funcional, controle nativo e DACL.

- WIN-01/05: evidência ACL recebe owner/ACEs sintéticos e retorna flags False;
  prova um contrato diagnóstico, não leitura/verificação de política efetiva.
- WIN-02: nome curto construído + monkeypatch não prova um alias 8.3 real. A
  proposta exige GetShortPathNameW real; ausência de alias continua NÃO_VALIDADO.
- WIN-03: comparação real só no Windows; o fluxo Linux casefold não prova Kernel32.
  NUL recusado não é prova de retorno de erro de API. Esse ramo nativo requer plano.
- WIN-04: hardlink tem a mesma identidade/bytes, mas o comparador diagnóstico
  rejeita nomes distintos. Não impor esse contrato ao leitor de produção por ID+SHA.
  O legado transforma qualquer OSError de criação em skip; a proposta não faz isso.
- WIN-06…10: sentinela textual legada não cobre adequadamente diretórios externos;
  a proposta usa arquivos e diretórios reais, snapshots e bytes integrais.
- WIN-11: o legado mistura Git e link; um skip não aprova o conjunto. Proposta separa.
- WIN-12: o legado não compara sentinela depois da recusa; a proposta cria acervo
  assinado por APIs reais, compara bytes e testa consultar/ler_fonte antes/depois.
- WIN-13: rejeição de escape antecede a rejeição explícita de symlink. Não exigir
  o mesmo código de erro para alvo interno e externo à área autorizada.
- WIN-14: o teste original usa fluxo gravar_pacote completo. O código independente
  preparado cobre conferir_fontes; o protocolo complementar completo permanece
  obrigatório. Não promover subcomponente a aprovação de fluxo integral.
- WIN-15: condição POSIX 0600 e propriedade de pendência Windows preservadas;
  gabarito derivado do leitor só serve ao contrato de opção/comparação, não finanças.
- WIN-16: preserva verificações documentais; proposta sem mock cobre domínio,
  retenção/exportação/escritor, faltando a origem real de conflito pelo CLI integral.
- WIN-17: roundtrip JSON não comprova DACL após criação/replace.
- WIN-18/19: chmod e skips POSIX são inadequados para provar permissões NTFS.
  O legado é NÃO_APLICÁVEL como mecanismo Windows, segurança segue NÃO_VALIDADO.

A inspeção de writer/reader não mostrou integração comprovada de política DACL.
Uma docstring de private_permissions não substitui o caminho de chamada real.
Não alterar motor nem instalar ACL genérica para obter PASS. A proposta de política
está expressamente PARA_APROVAÇÃO, por papel/objeto/operação, incluindo lacunas.

## 6. Preparação entregue e validação realizada

Entregues matriz de 19 linhas, 19 fichas de teste, código proposto independente,
plano nativo/preflight somente leitura, política DACL proposta e manifestos.
Prevista expansão de 21 casos para 19 IDs (WIN-11 e WIN-13 possuem subcasos).
Essa quantidade vem da inspeção estática, NÃO de pytest --collect-only.

Verificações desta tarefa: leitura dos três documentos, parsing CSV/JSON/XML
existentes, AST/sintaxe em memória, comparação de hash e preservação. Não foram
executados testes novos, coleta pytest, sondas nativas, criação de symlink/hardlink,
preflight Windows, acesso entre contas, alteração de ACL/Developer Mode ou instalação.
Os marcadores WIN-18/19 não fazem tentativas de acesso: dependem da política aprovada.

Duas lacunas de automação integral (WIN-14/16) e o ramo de erro da API foram
explicitados em código/matriz/fichas/plano. Isso é uma preparação para revisão,
não uma suíte de homologação completa ou resultado nativo aprovado.

## 7. Decisão e ponto de parada

A reconciliação histórica NÃO está concluída por ausência de fonte primária.
A preparação está disponível para revisão; controles, DACL e homologação seguem
NÃO_VALIDADO. Próximas dependências: originais EXP-04, roteiro/precondições revisados,
complementos de cenário e política aprovada antes de acesso real entre contas.

Preservação final comprovada em PRESERVACAO_FINAL.json. Nenhum commit, push,
merge, PR, publicação ou desbloqueio operacional. Residual histórico não acessado.
Parar nesta entrega, conforme a instrução recebida; executar somente com nova
revisão/autorização expressa dos casos e do ambiente.
