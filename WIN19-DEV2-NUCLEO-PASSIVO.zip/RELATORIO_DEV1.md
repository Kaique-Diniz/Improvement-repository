# WIN19 DEV-1 — código implementado e autotestes sintéticos

27/11/2026 — America/Sao_Paulo.
IMPLEMENTADO_E_AUTOTESTADO_NO_CODEX_AGUARDANDO_AUDITORIA_INDEPENDENTE.
Não é homologação Windows, aceitação dos riscos ou autorização operacional.

## 1. Autorização e isolamento demonstrados antes da criação

Pedido expresso DEV-1 e autorização agrupada recebidos: U01–U04, PY/Python 3.12,
biblioteca padrão, BT01 e importação/autotestes sintéticos dos seis módulos novos.
U05/U06/U07 continuam não autorizadas. Esta é nova autorização restrita, sem
reescrever a situação histórica D5 ou conferir autoridade a declarações fictícias.

Python observado antes de criar: 3.12.14.
Raiz nova: /workspace/work/WIN19-DEV1-NUCLEO-PASSIVO.
Antes de criar, verificadas ancestralidades /, /workspace, /workspace/work como
diretórios regulares, sem symlink ou marcadores .git/HEAD/commondir/objects/refs.
Raiz inexistente, fora do checkout /workspace/Improvement-repository e das
candidatas/custódias e sem nome de sincronização nos ancestrais.
Apenas evidência de isolamento desta área Codex; não prova G09/NTFS ou políticas
do Windows do custodiante. Nenhum Git, clone, branch ou worktree usado.

Nenhuma instalação/toolchain/terceiro; somente o inventário fechado. As verificações
de área e as ferramentas de entrega podem ler os arquivos autorizados para
tamanhos/hashes: isso não introduz IO no núcleo, que é exclusivamente em memória.
Nenhum arquivo privado do usuário ou host Windows foi acessado.

## 2. Implementação efetiva

A: SHA-256/confronto de bytes fornecidos, sem abrir arquivos; coincidência declarada
não autentica origem. B: referência/contexto declarados, sem autenticar pessoas/
host ou inferir autorização. D: JSON sintético estrito/limitado, sem consumidor
operacional R1. E: modelo de eventos fornecidos, sem relógio ativo/processos.
F: projeção por lista fechada, sem payload bruto, persistência/envio ou impressão.

Sete estados G10 representados e eixos separados. Resultado estruturalmente válido
pode registrar impedimento e sempre conserva inconclusão material/encerramento
não comprovado. Nenhum estado DESTINO_APROVADO, nem flags configuráveis para true.
Núcleo não integra produto, C ou qualquer API Windows.

Exatamente 12 arquivos de fonte/documentação/testes autorizados foram criados
antes do relatório/manifesto: seis módulos, LEIA-ME e cinco tests. Nenhum
__init__.py, cache, config operacional, helper/runner, log/JUnit ou arquivo
extra foi incluído. Namespace package padrão Python permite importação sem
ampliar o inventário. Saída completa dos testes está neste relatório, não em
arquivo de log adicional.

## 3. Detalhes internos delegados e limites escolhidos

- Classes/enumerações congeladas e tipos exatos: motivos seguros, sem coerção de
  bool para contagem ou inferência de poder a partir de metadados.
- Contrato separado WIN19-DEV1-SINTETICO-1: nove campos fechados e marcadores
  sintéticos. Não finge validar o payload operacional H3-F-R1.
- Máximo 16.384 bytes UTF-8 sem BOM, 256 nós, profundidade 12, 16 verificações
  com IDs S01–S16 únicos. JSON é decodificado só após limite em bytes; limites
  de árvore são aplicados depois. Recursão/erro recebem resultado conservador.
  Volume limitado não é garantia de tempo total ou limite rígido de memória.
- Máximo 32 eventos; duração fornecida finita/não decrescente de 0 a 1.000.000.000:
  apenas limite conservador de dado sintético, não timeout ou autorização real.
- Até 32 campos no registro; referências apenas REF_SINTETICA_A/B; campos/valores
  desconhecidos não ecoados; contagens limitadas e motivos adversos preservados.
- Primeira transição/evento inválidos encerram redução sem aplicar os restantes.
  Declaração de fechamento ou de observação jamais comprova recurso real.
- Sem linguagem alternativa, instalação, rede, subprocess, shell, ambiente,
  leitura de host/cliente/arquivo, temporizador ou ação de encerramento no núcleo.

Escolhas internas reversíveis feitas dentro da delegação DEV-1. Questões históricas
D3T-Q01–Q12 continuam abertas nos assuntos de autoridade, legitimidade, validade
real, localização privada, duração real, encerramento, Windows, C e portões.

## 4. Autotestes realmente executados

Comando único, diretório atual na raiz DEV-1:

python -B -m unittest discover -s tests -p 'test_*.py' -v

Ambiente desta rodada: Linux do Codex, Python 3.12.14, biblioteca padrão.
Resultado unittest: 79 executados / 79 PASS / 0 FAIL / 0 ERROR / 0 SKIP,
0.010s segundo o próprio unittest, código de saída 0. Duração do harness não é
limite temporal do núcleo ou evidência de processo/provider real.
Uma única rodada; nenhum código foi alterado depois dela.

| Arquivo de autoteste | Métodos executados |
|---|---:|
| test_origem_contexto.py | 14 |
| test_recepcao.py | 33 |
| test_eventos.py | 17 |
| test_registro.py | 12 |
| test_fluxo_passivo_sintetico.py | 3 |
| Total | 79 |

Incluídos os casos mínimos: estrutura sintética válida, ausência, truncamento/
corrupção, tamanho, duplicatas, extras, identidade divergente, contexto sem
autoridade comprovada, interrupção, fechamento incerto, transições inválidas,
sanitização e ausência do estado de aprovação. Fluxo integral somente em memória,
com hashes/declarações/eventos fictícios. Nenhum dado real ou fixture documental.
Nenhum caso foi omitido/convertido em skip; falhas históricas não reexecutadas.

### Saída integral sanitizada da rodada real

```text
test_booleano_nao_e_duracao (test_eventos.EventosTests.test_booleano_nao_e_duracao) ... ok
test_duracao_decrescente_preserva_ultima_valida (test_eventos.EventosTests.test_duracao_decrescente_preserva_ultima_valida) ... ok
test_duracao_nan_recusada (test_eventos.EventosTests.test_duracao_nan_recusada) ... ok
test_duracao_negativa_recusada (test_eventos.EventosTests.test_duracao_negativa_recusada) ... ok
test_fechamento_antes_termino_recusado (test_eventos.EventosTests.test_fechamento_antes_termino_recusado) ... ok
test_fechamento_declarado_nao_comprova (test_eventos.EventosTests.test_fechamento_declarado_nao_comprova) ... ok
test_incerteza_posterior_preserva_adverso (test_eventos.EventosTests.test_incerteza_posterior_preserva_adverso) ... ok
test_interrupcao_preservada (test_eventos.EventosTests.test_interrupcao_preservada) ... ok
test_limite_de_eventos (test_eventos.EventosTests.test_limite_de_eventos) ... ok
test_objeto_arbitrario_nao_ecoado (test_eventos.EventosTests.test_objeto_arbitrario_nao_ecoado) ... ok
test_parada_no_primeiro_erro_sem_aplicar_fim (test_eventos.EventosTests.test_parada_no_primeiro_erro_sem_aplicar_fim) ... ok
test_reinicio_apos_termino_invalido (test_eventos.EventosTests.test_reinicio_apos_termino_invalido) ... ok
test_sem_eventos_nao_inventa_inicio (test_eventos.EventosTests.test_sem_eventos_nao_inventa_inicio) ... ok
test_termino_apos_interrupcao_nao_apaga_adverso (test_eventos.EventosTests.test_termino_apos_interrupcao_nao_apaga_adverso) ... ok
test_termino_sem_inicio_invalido (test_eventos.EventosTests.test_termino_sem_inicio_invalido) ... ok
test_tipo_evento_string_nao_aceito_como_enum (test_eventos.EventosTests.test_tipo_evento_string_nao_aceito_como_enum) ... ok
test_traco_normal_somente_fornecido (test_eventos.EventosTests.test_traco_normal_somente_fornecido) ... ok
test_fluxo_adverso_preserva_divergencia_e_interrupcao (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_fluxo_adverso_preserva_divergencia_e_interrupcao) ... ok
test_fluxo_integral_em_memoria_nao_autoriza (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_fluxo_integral_em_memoria_nao_autoriza) ... ok
test_sete_estados_sem_aprovacao (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_sete_estados_sem_aprovacao) ... ok
test_constructor_nao_aceita_aprovacao (test_origem_contexto.OrigemContextoTests.test_constructor_nao_aceita_aprovacao) ... ok
test_contexto_ausente (test_origem_contexto.OrigemContextoTests.test_contexto_ausente) ... ok
test_contexto_booleano_nao_e_inteiro (test_origem_contexto.OrigemContextoTests.test_contexto_booleano_nao_e_inteiro) ... ok
test_contexto_campo_extra_nao_ecoado (test_origem_contexto.OrigemContextoTests.test_contexto_campo_extra_nao_ecoado) ... ok
test_contexto_referencia_fora_lista (test_origem_contexto.OrigemContextoTests.test_contexto_referencia_fora_lista) ... ok
test_declaracao_completa_nunca_autoriza (test_origem_contexto.OrigemContextoTests.test_declaracao_completa_nunca_autoriza) ... ok
test_declaracao_negativa_insuficiente (test_origem_contexto.OrigemContextoTests.test_declaracao_negativa_insuficiente) ... ok
test_hash_conhecido_sem_autenticidade (test_origem_contexto.OrigemContextoTests.test_hash_conhecido_sem_autenticidade) ... ok
test_hash_divergente (test_origem_contexto.OrigemContextoTests.test_hash_divergente) ... ok
test_hash_excesso_tamanho (test_origem_contexto.OrigemContextoTests.test_hash_excesso_tamanho) ... ok
test_hash_maiusculo_recusado (test_origem_contexto.OrigemContextoTests.test_hash_maiusculo_recusado) ... ok
test_hash_tipo_estrito (test_origem_contexto.OrigemContextoTests.test_hash_tipo_estrito) ... ok
test_referencia_invalida_nao_ecoada (test_origem_contexto.OrigemContextoTests.test_referencia_invalida_nao_ecoada) ... ok
test_sem_referencia (test_origem_contexto.OrigemContextoTests.test_sem_referencia) ... ok
test_aprovacao_destino_true_rejeitada (test_recepcao.RecepcaoTests.test_aprovacao_destino_true_rejeitada) ... ok
test_ausencia_bytes_vazios (test_recepcao.RecepcaoTests.test_ausencia_bytes_vazios) ... ok
test_ausencia_none (test_recepcao.RecepcaoTests.test_ausencia_none) ... ok
test_bom_recusado (test_recepcao.RecepcaoTests.test_bom_recusado) ... ok
test_campo_inesperado (test_recepcao.RecepcaoTests.test_campo_inesperado) ... ok
test_campo_obrigatorio_ausente (test_recepcao.RecepcaoTests.test_campo_obrigatorio_ausente) ... ok
test_cardinalidade_excessiva (test_recepcao.RecepcaoTests.test_cardinalidade_excessiva) ... ok
test_chave_duplicada_aninhada (test_recepcao.RecepcaoTests.test_chave_duplicada_aninhada) ... ok
test_chave_duplicada_raiz (test_recepcao.RecepcaoTests.test_chave_duplicada_raiz) ... ok
test_contexto_sem_autorizacao_comprovada (test_recepcao.RecepcaoTests.test_contexto_sem_autorizacao_comprovada) ... ok
test_documento_real_recusado (test_recepcao.RecepcaoTests.test_documento_real_recusado) ... ok
test_entrada_texto_em_vez_de_bytes (test_recepcao.RecepcaoTests.test_entrada_texto_em_vez_de_bytes) ... ok
test_estado_destino_aprovado_nao_existe_no_contrato (test_recepcao.RecepcaoTests.test_estado_destino_aprovado_nao_existe_no_contrato) ... ok
test_estrutura_sintetica_valida_sem_verdade_material (test_recepcao.RecepcaoTests.test_estrutura_sintetica_valida_sem_verdade_material) ... ok
test_fechamento_true_declarado_nao_comprova_recurso (test_recepcao.RecepcaoTests.test_fechamento_true_declarado_nao_comprova_recurso) ... ok
test_identidade_divergente_preserva_estrutura_sem_atribuicao (test_recepcao.RecepcaoTests.test_identidade_divergente_preserva_estrutura_sem_atribuicao) ... ok
test_ids_verificacao_duplicados (test_recepcao.RecepcaoTests.test_ids_verificacao_duplicados) ... ok
test_impedimento_coerente_e_validavel_como_registro_adverso (test_recepcao.RecepcaoTests.test_impedimento_coerente_e_validavel_como_registro_adverso) ... ok
test_impedimento_incoerente_rejeitado (test_recepcao.RecepcaoTests.test_impedimento_incoerente_rejeitado) ... ok
test_infinity_rejeitado (test_recepcao.RecepcaoTests.test_infinity_rejeitado) ... ok
test_inteiro_nao_substitui_booleano (test_recepcao.RecepcaoTests.test_inteiro_nao_substitui_booleano) ... ok
test_json_adicional_nao_recortado (test_recepcao.RecepcaoTests.test_json_adicional_nao_recortado) ... ok
test_json_corrompido (test_recepcao.RecepcaoTests.test_json_corrompido) ... ok
test_json_grande (test_recepcao.RecepcaoTests.test_json_grande) ... ok
test_json_truncado (test_recepcao.RecepcaoTests.test_json_truncado) ... ok
test_nan_rejeitado (test_recepcao.RecepcaoTests.test_nan_rejeitado) ... ok
test_overflow_float_rejeitado (test_recepcao.RecepcaoTests.test_overflow_float_rejeitado) ... ok
test_payload_preservado_integralmente (test_recepcao.RecepcaoTests.test_payload_preservado_integralmente) ... ok
test_profundidade_excessiva (test_recepcao.RecepcaoTests.test_profundidade_excessiva) ... ok
test_quantidade_nos_excessiva (test_recepcao.RecepcaoTests.test_quantidade_nos_excessiva) ... ok
test_recursao_parser_contida (test_recepcao.RecepcaoTests.test_recursao_parser_contida) ... ok
test_referencia_hash_invalida (test_recepcao.RecepcaoTests.test_referencia_hash_invalida) ... ok
test_utf8_invalido (test_recepcao.RecepcaoTests.test_utf8_invalido) ... ok
test_adversos_validos_preservados (test_registro.RegistroTests.test_adversos_validos_preservados) ... ok
test_booleano_nao_e_contagem (test_registro.RegistroTests.test_booleano_nao_e_contagem) ... ok
test_chave_nao_string (test_registro.RegistroTests.test_chave_nao_string) ... ok
test_chaves_e_payload_privados_sinteticos_descartados (test_registro.RegistroTests.test_chaves_e_payload_privados_sinteticos_descartados) ... ok
test_destino_aprovado_nao_e_estado (test_registro.RegistroTests.test_destino_aprovado_nao_e_estado) ... ok
test_entrada_nao_mutada (test_registro.RegistroTests.test_entrada_nao_mutada) ... ok
test_none_resulta_conservador (test_registro.RegistroTests.test_none_resulta_conservador) ... ok
test_referencia_arbitraria_nao_ecoada (test_registro.RegistroTests.test_referencia_arbitraria_nao_ecoada) ... ok
test_referencia_fechada_permitida (test_registro.RegistroTests.test_referencia_fechada_permitida) ... ok
test_registro_grande (test_registro.RegistroTests.test_registro_grande) ... ok
test_tentativa_de_aprovacao_preserva_motivo_e_false (test_registro.RegistroTests.test_tentativa_de_aprovacao_preserva_motivo_e_false) ... ok
test_valor_arbitrario_em_campo_permitido_nao_ecoado (test_registro.RegistroTests.test_valor_arbitrario_em_campo_permitido_nao_ecoado) ... ok

----------------------------------------------------------------------
Ran 79 tests in 0.010s

OK
```

## 5. Revisão estática local autorizada

Os 11 arquivos Python foram analisados com ast.parse antes da rodada, sem import
de produto/C; seis módulos importam apenas dataclasses/enum/hashlib/hmac/json/math
e relativos novos. Conferidas ausências de open/print/eval/exec/import dinâmico,
input e compile diretos no núcleo; revisão estática complementar dos novos
arquivos, não prova formal de ausência de vulnerabilidade. Autotestes importaram
somente módulos novos e biblioteca padrão. Nenhum cache gerado com -B.

Checks de inventário/hashes após testes confirmam os mesmos 12 arquivos testados,
nenhum código alterado após 79 PASS. Asserções/testes são parte da autorização
sintética DEV-1, não P1/P2 formal, Windows, N02–N04, DACL ou homologação.

## 6. Cobertura resumida M-C01–M-C14

| Controle | Cobertura DEV-1, não aprovação operacional | Implementação e limite | Evidência local |
|---|---|---|---|
| M-C01 | PARCIAL | origem.conferir compara bytes/digest fornecidos; sem ler/certificar origem, carregamento ou legitimidade. | hash conhecido/divergente/tipo/limite e fluxo sintético |
| M-C02 | PARCIAL | contexto representa referências sintéticas; nenhuma autorização real é criada ou autenticada. | declaração completa/insuficiente/ausente e fluxo |
| M-C03 | DEPENDENTE_EXTERNO_NAO_IMPLEMENTADO | Nenhuma autenticação/competência real de pessoa/operador; somente declaração booleana. | teste comprova que declaração completa nunca autoriza, não identidade real |
| M-C04 | DEPENDENTE_EXTERNO_NAO_IMPLEMENTADO | Nenhuma consulta ao host/ambiente/Windows, dependência nativa ou legitimidade institucional. | conferência Python/BT01 só para DEV-1, não para observação do custodiante |
| M-C05 | PARCIAL | E aceita início fornecido e distingue fase; não observa início real. | sem eventos, início fornecido e transições inválidas |
| M-C06 | COBERTO_PASSIVAMENTE | JSON sintético em memória com tipos/estrutura/bytes/árvore limitados; não é contrato real R1. | estrutura sintética e casos negativos de codificação/tamanho/duplicatas/tipos |
| M-C07 | COBERTO_PASSIVAMENTE | Ausência, possível incompletude e corrupção classificadas sem objeto normal falso. | None/vazio/truncado/corrompido, sem eco de entrada |
| M-C08 | COBERTO_PASSIVAMENTE | Compatibilidade sintética e atribuição por digest declarativo conservadoras. | flags, estados, campos, IDs, cardinalidade, divergência e coerência de impedimento |
| M-C09 | COBERTO_PASSIVAMENTE | Extras/JSON adicional não recortados; F descarta campos desconhecidos sem ocultar motivo adverso. | campo extra, objetos concatenados e sanitização negativa |
| M-C10 | PARCIAL | Interrupção fornecida e primeiro evento inválido preservados, sem cancelar/controlar processo. | interrupção, término posterior e parada da redução no erro |
| M-C11 | DEPENDENTE_EXTERNO_NAO_IMPLEMENTADO | Só valida duração fornecida finita/limitada/monótona; nenhum relógio/timeout global real. | duração negativa/NaN/booleana/decrescente, sem comprovar tempo real |
| M-C12 | PARCIAL | Fechamento declarado, falha/incerteza e término fornecido separados; nenhum recurso real fechado. | fechamento/incerteza e término não promovem encerramento comprovado |
| M-C13 | COBERTO_PASSIVAMENTE | Projeção fechada em memória, sem persistir/transmitir/ecoar payload ou mensagens livres. | campos/valores/referências inesperados e tentativas de flags true |
| M-C14 | COBERTO_PASSIVAMENTE | Flags de aprovação/autoridade/prontidão constantes false; enum G10 sem DESTINO_APROVADO. | constructor recusa flag, projeção recusa true e fluxo conserva false |

COBERTO_PASSIVAMENTE significa comportamento no contrato sintético e limitado
de DEV-1, não controle real aprovado/implementado no ambiente do custodiante.
PARCIAL indica representação sem observação/prova material. Controles externos
não estão implementados; nenhum objeto de sucesso fabricado para supri-los.

## 7. Arquivos testados e hashes

| Arquivo efetivamente implementado/documentado/testado | Bytes | SHA-256 após a rodada |
|---|---:|---|
| [alternativa_python/LEIA-ME.md](alternativa_python/LEIA-ME.md) | 6572 | 712cf2a44e6e03708321526aa8b47ff2ebe7865a6ee6b466d52be0373e2a51f4 |
| [alternativa_python/contexto.py](alternativa_python/contexto.py) | 1705 | 175f71a22f0b9f83df57ebe3ad2ec35affb438d2d174d892b2eb550e25779d06 |
| [alternativa_python/contratos.py](alternativa_python/contratos.py) | 4775 | db4b2199a98c9e3f0c334826e881b53c61adf7410a21bfaa2a32c0127aaf66dd |
| [alternativa_python/eventos.py](alternativa_python/eventos.py) | 3602 | 70ba9d7f1100238d093ea049f32d1d697433cb483bc5c36b8d7ad33f4424d2d3 |
| [alternativa_python/origem.py](alternativa_python/origem.py) | 982 | b1c174950f78bb9fed86a32a1e2411fbf38f458eecf7826836834e15be745eb5 |
| [alternativa_python/recepcao.py](alternativa_python/recepcao.py) | 6652 | 4b5a91198ed992843c3e36c6d364434404a97e48befb7571c2a8384397ba6080 |
| [alternativa_python/registro.py](alternativa_python/registro.py) | 3996 | 54daeb741f66ff0b1e54c8c784c843fa6f115028fc3d7a37e7f3ea7e526960eb |
| [tests/test_eventos.py](tests/test_eventos.py) | 4717 | bfb10b69378eafc187fd25a24e7b18cc74ab7e671cd0c3176e3f75ee540d5ba3 |
| [tests/test_fluxo_passivo_sintetico.py](tests/test_fluxo_passivo_sintetico.py) | 3852 | ddc8bb7ca3d3ec74925cb262c0020bc390f7586b642962fe565bd96992c08cb8 |
| [tests/test_origem_contexto.py](tests/test_origem_contexto.py) | 3540 | 524f0bd5ed19d2d432c1efa3ab6ddec070e16f73509b899dbbf214791a559f6e |
| [tests/test_recepcao.py](tests/test_recepcao.py) | 7276 | 9a92b3fb79e5f2f7f5adfe20dd49475a5073c4cf0e6b16681141f9bb5286f59c |
| [tests/test_registro.py](tests/test_registro.py) | 3657 | 5b3062e9a5d77344b3103260c60f30a4b6dc17f670451369a820f4167fa14ca8 |

RELATORIO_DEV1.md é o 13º arquivo coberto por MANIFESTO_SHA256_DEV1.
Manifesto lista sha256;bytes;arquivo dos 13 outros arquivos e não se inclui.
Hash/tamanho do manifesto e do único ZIP final local são informados na entrega
externa, evitando autorreferência. ZIP conterá somente os 14 arquivos, com
estrutura alternativa_python/tests preservada; sem publicação ou Git.

## 8. Proveniência e preservação

Autorização DEV-1: 11.827 bytes, SHA-256
185d783bc52b12e08e66ed352323befb621db89d429261970f8c586ad1dae05d.
Parecer D5: 4.216 bytes, SHA-256
eb8f947aefeed59293e6634bf0f20919b77fd384fcb838bec508939dce429748.
D5 manifesto confere; original D5/ZIP e anexos preservados nos 17 objetos abaixo.
Hashes identificam bytes locais, não assinatura/competência institucional,
tempo forense ou todos os computadores. Nenhuma fonte histórica foi editada;
nenhum Git ou operação sobre candidatas/produção/C/Windows realizado.

| Fonte preservada | Bytes | SHA-256 |
|---|---:|---|
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/SEPARACAO_PORTOES_P1_P6.md | 28178 | 22bfb05ce8dbb1ec4e31c4758671a31ff9a555b07661c1d3499d553b7a27b349 |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/INVENTARIO_ARTEFATOS_FISICOS_CANDIDATOS.csv | 22377 | 58d1dcef0d1d8609bac9c69ffa52a2fe43b64fb6b0dc45a5218bfc71c1fa940f |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/MATRIZ_UNIDADES_U01_U07.csv | 6955 | e2c2309799c3bd75c79325419ce7c96fa72a2aa9cee3abbcc5b2c1718f445857 |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/RELATORIO_H3_O_D5.md | 7792 | a8025d4ddbc49e16a7da7cd4654869a24e2b6c79c1bb7396e305e8d3b580089b |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/DECISAO_DOCUMENTAL_PROPOSTA_H3_O_D5.md | 5206 | e13d911f5209fe44e8a8647f21531b1837c3b96de047994d70d9b93fde9544ae |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/MANIFESTO_SHA256_H3_O_D5 | 1374 | 5aa18ede9602333dd40f16be780be004c110e2d0477f1cada0a2dc70d6ff9ce2 |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/INDICE_ENTREGA_H3_O_D5.md | 25790 | 9b19b1ed1f32bbcad1782896c40e10d4e385ef0deceb49862f244069244bb20f |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/ALTERNATIVAS_BASE_E_AREA_DE_TRABALHO.md | 5801 | 4efd11d7a87e01bb4bfd244342166298c22af8e28ba6e06b0c3eceb852b459ee |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/CRITERIOS_ACEITACAO_E_INTERRUPCAO.md | 11061 | 7e4faf7fb4abf7bc488d9653a2a13ce6ca4525c89eaec0eef048088ba080aeec |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/MATRIZ_DECISOES_D3T_Q01_Q12.csv | 22627 | 5e92848ce71ec5d6893e1f3c5f6335b59cdef71ee6fdd0cfdde7190ae19b9f23 |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/LIMITES_PROVENIENCIA_PRIVACIDADE.md | 5727 | edd2ff41e17894c19d1d02fc8dd72ffeea54d350a4c4073eb479e303fdb80099 |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/MATRIZ_OPERACOES_PERMITIDAS_PROIBIDAS.csv | 16814 | 53053358e4840bfa960e048654fe2b2b6813156c1a74519e34684e1da2ad5e0c |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/MATRIZ_COBERTURA_G10_MC01_MC14.csv | 78640 | d51c3c71e76f2bad8241a2c2dbc670ac709285e291ef87fce217a556fe3754dc |
| WIN19-H3-O-D5-DELIBERACAO-IMPLEMENTACAO-20261127/TERMO_DELIBERACAO_U01_U07.md | 5897 | cb77c86e9b259893e366a7baac2846dca012aa0a6cac345a446da999ca4b1149 |
| WIN19-H3-O-D5-deliberacao-implementacao.zip | 64641 | 3f4aed18aae25b5e5d2722fcca0cf20663ff5938dd2fd6415160c70738cd5c2f |
| AUTORIZACAO_AGRUPADA_CODEX_WIN19_DEV1_2026-11-27.md | 11827 | 185d783bc52b12e08e66ed352323befb621db89d429261970f8c586ad1dae05d |
| PARECER_INDEPENDENTE_WIN19_H3_O_D5_2026-11-27.md | 4216 | eb8f947aefeed59293e6634bf0f20919b77fd384fcb838bec508939dce429748 |

As ressalvas de proveniência D4 90/92 e D3-T 74/75 continuam com seus alcances,
inclusive textos brutos ausentes ao auditor. Não reivindicar autenticação
independente dos 109 objetos históricos nem transferir conferência do executor
para o auditor. Parecer D5 aceita preparação documental e esta autorização
posterior permite somente o novo núcleo/autotestes, não altera evidência antiga.

## 9. Riscos, pendências e estados

R01–R09 permanecem riscos potenciais abertos; R03/R07 ALTA continuam bloqueadores
da observação até solução própria. Dependências N02–N04 continuam não verificadas
(15 registros: seis N02, quatro N03, cinco N04); N01 somente antigos bytes R1.
Não se testou identidade física, concorrência, confinamento, direitos efetivos,
Windows, links, WMI, ACL/DACL, host, timeout global ou encerramento de processo/
provider/COM/RPC. Autoteste sintético não substitui evidência financeira privada.

Limites do software: não é sandbox contra Python adversarial no mesmo processo;
referências/declarações/flag de estrutura não autenticam fatos; marcador sintético
não prova origem factual. F não autentica a verdade de metadados fornecidos,
nem promete apagar buffers/logs. Nenhuma observação real é permitida com DEV-1.
Nova necessidade de arquivo/dep/API/captura/privado/C exige pedido delimitado,
sem inclusão ou segunda rodada fora do escopo.

| Item | Estado preservado |
|---|---|
| L-D01 | ALTERNATIVA_A_OBSERVACAO_LIMITADA |
| L-D02 | CLASSIFICACOES_DELIBERADAS_11_DE_11 |
| DEV1_U01_U04 | DESENVOLVIMENTO_ISOLADO_AUTORIZADO_POR_ESTE_PEDIDO |
| DEV1_TESTES_UNITARIOS_SINTETICOS | AUTORIZADOS_POR_ESTE_PEDIDO |
| U05_U06_U07 | NAO_AUTORIZADAS |
| G09 | INDISPENSAVEL_NAO_COMPROVADO |
| G10 | INDISPENSAVEL_NAO_COMPROVADO_PARA_EXECUCAO_REAL |
| L-D06 | PENDENTE |
| CONTRATO_EXTERNO_REAL | NAO_IMPLEMENTADO |
| H3-F-R1 | INALTERADA_EXECUCAO_NAO_AUTORIZADA |
| R01_A_R09 | RISCO_POTENCIAL_ABERTO |
| N02_A_N04 | NAO_VERIFICADO |
| WIN01_A_WIN19 | NAO_VALIDADO |
| DACL | NAO_VALIDADO |
| H3-C/H3-S/H4 | NAO_AUTORIZADAS |
| P1_A_P6 | SEM_AUTORIZACAO_OPERACIONAL_NESTA_ETAPA |
| CONVERSOES_REAIS | BLOQUEADAS |
| PRONTIDAO_OPERACIONAL | false |

L-D01 e onze classificações L-D02 preservados, sem reabertura. Frente G09/L-D06
independente continua privada. Política H3-E de custodiante principal e
coadministradores por autorização específica preservada; retenção vinculada à H4,
máximo inicial 180 dias apenas após futura cópia fiel aceita/verificada; revisões
60/120/180 e antecipada se H4 concluir; prorrogação expressa justificada e nenhuma
exclusão automática. Nenhum prazo/marco/agenda iniciado.

## 10. Ponto de parada

Código e autotestes locais concluídos com resultado real 79 PASS.
Auditoria independente de código/testes/limites permanece pendente.
Não iniciar outra rodada, C, Windows, P1–P6, MVP, custódia, Git ou publicação.
