"""Contratos DEV-1 exclusivamente sintéticos; nenhuma aprovação operacional."""
from dataclasses import dataclass
from enum import StrEnum

VERSAO = "WIN19-DEV1-SINTETICO-1"
MAX_BYTES = 16_384
MAX_NOS = 256
MAX_PROFUNDIDADE = 12
MAX_VERIFICACOES = 16
MAX_EVENTOS = 32
MAX_CAMPOS_REGISTRO = 32
MAX_TEXTO_CONTEXTO = 32
MAX_DURACAO_FORNECIDA = 1_000_000_000


class EstadoG10(StrEnum):
    EVIDENCIA_RECEBIDA_VALIDAVEL = "EVIDENCIA_RECEBIDA_VALIDAVEL"
    EVIDENCIA_INCOMPLETA = "EVIDENCIA_INCOMPLETA"
    EVIDENCIA_AUSENTE = "EVIDENCIA_AUSENTE"
    EVIDENCIA_INCOMPATIVEL = "EVIDENCIA_INCOMPATIVEL"
    EXECUCAO_INTERROMPIDA = "EXECUCAO_INTERROMPIDA"
    ENCERRAMENTO_NAO_COMPROVADO = "ENCERRAMENTO_NAO_COMPROVADO"
    RESULTADO_INCONCLUSIVO = "RESULTADO_INCONCLUSIVO"


class Motivo(StrEnum):
    SOMENTE_SINTETICO = "SOMENTE_SINTETICO"
    SEM_CONTEUDO = "SEM_CONTEUDO"
    TIPO_ENTRADA_INVALIDO = "TIPO_ENTRADA_INVALIDO"
    LIMITE_EXCEDIDO = "LIMITE_EXCEDIDO"
    CODIFICACAO_INVALIDA = "CODIFICACAO_INVALIDA"
    JSON_INCOMPLETO = "JSON_INCOMPLETO"
    JSON_INVALIDO = "JSON_INVALIDO"
    CHAVE_DUPLICADA = "CHAVE_DUPLICADA"
    VALOR_NAO_JSON = "VALOR_NAO_JSON"
    ESTRUTURA_INCOMPATIVEL = "ESTRUTURA_INCOMPATIVEL"
    ORIGEM_NAO_AUTENTICADA = "ORIGEM_NAO_AUTENTICADA"
    ORIGEM_DIVERGENTE = "ORIGEM_DIVERGENTE"
    REFERENCIA_ORIGEM_INVALIDA = "REFERENCIA_ORIGEM_INVALIDA"
    AUTORIZACAO_NAO_COMPROVADA = "AUTORIZACAO_NAO_COMPROVADA"
    CONTEXTO_AUSENTE = "CONTEXTO_AUSENTE"
    CONTEXTO_INVALIDO = "CONTEXTO_INVALIDO"
    CONTEXTO_INSUFICIENTE = "CONTEXTO_INSUFICIENTE"
    ENCERRAMENTO_INCERTO = "ENCERRAMENTO_INCERTO"
    INTERRUPCAO_FORNECIDA = "INTERRUPCAO_FORNECIDA"
    EVENTO_INVALIDO = "EVENTO_INVALIDO"
    TRANSICAO_INVALIDA = "TRANSICAO_INVALIDA"
    DURACAO_INVALIDA = "DURACAO_INVALIDA"
    CAMPO_REGISTRO_INVALIDO = "CAMPO_REGISTRO_INVALIDO"
    CAMPOS_DESCARTADOS = "CAMPOS_DESCARTADOS"
    APROVACAO_INDEVIDA = "APROVACAO_INDEVIDA"
    IMPEDIMENTO_DECLARADO = "IMPEDIMENTO_DECLARADO"
    ENTRADA_FLUXO_INVALIDA = "ENTRADA_FLUXO_INVALIDA"
    REGISTRO_INDISPONIVEL = "REGISTRO_INDISPONIVEL"


class Referencia(StrEnum):
    SINTETICA_A = "REF_SINTETICA_A"
    SINTETICA_B = "REF_SINTETICA_B"


class EstadoOrigem(StrEnum):
    COINCIDE_COM_DECLARADO = "COINCIDE_COM_DECLARADO"
    DIVERGE = "DIVERGE"
    SEM_REFERENCIA = "SEM_REFERENCIA"
    REFERENCIA_INVALIDA = "REFERENCIA_INVALIDA"
    ENTRADA_INVALIDA = "ENTRADA_INVALIDA"


class EstadoContexto(StrEnum):
    DECLARACAO_COMPLETA = "DECLARACAO_COMPLETA_NAO_COMPROVADA"
    SEM_DECLARACAO = "SEM_DECLARACAO"
    DECLARACAO_INVALIDA = "DECLARACAO_INVALIDA"
    DECLARACAO_INSUFICIENTE = "DECLARACAO_INSUFICIENTE"


class TipoEvento(StrEnum):
    INICIO_DECLARADO = "INICIO_DECLARADO"
    INICIO_OBSERVADO_FORNECIDO = "INICIO_OBSERVADO_FORNECIDO"
    SAIDA_FORNECIDA = "SAIDA_FORNECIDA"
    INTERRUPCAO_FORNECIDA = "INTERRUPCAO_FORNECIDA"
    TERMINO_FORNECIDO = "TERMINO_FORNECIDO"
    RECURSOS_INCERTOS = "RECURSOS_INCERTOS"
    FECHAMENTO_DECLARADO = "FECHAMENTO_DECLARADO"


class FaseEvento(StrEnum):
    INICIAL = "INICIAL"
    INICIADO = "INICIADO"
    COM_SAIDA = "COM_SAIDA"
    INTERROMPIDO = "INTERROMPIDO"
    TERMINADO = "TERMINADO"


class SemAprovacao:
    """Propriedades constantes, não argumentos configuráveis pelo chamador."""
    __slots__ = ()

    @property
    def destino_aprovado(self) -> bool:
        return False

    @property
    def custodia_autorizada(self) -> bool:
        return False

    @property
    def operacao_autorizada(self) -> bool:
        return False

    @property
    def origem_autenticada(self) -> bool:
        return False

    @property
    def autorizacao_comprovada(self) -> bool:
        return False

    @property
    def encerramento_comprovado(self) -> bool:
        return False

    @property
    def prontidao_operacional(self) -> bool:
        return False


@dataclass(frozen=True, slots=True)
class ReferenciaOrigem(SemAprovacao):
    estado: EstadoOrigem
    sha256_calculado: str | None


@dataclass(frozen=True, slots=True)
class ContextoPassivo(SemAprovacao):
    estado: EstadoContexto
    referencia: Referencia | None
    motivos: tuple[Motivo, ...]


@dataclass(frozen=True, slots=True)
class ResultadoRecepcao(SemAprovacao):
    estados: tuple[EstadoG10, ...]
    motivos: tuple[Motivo, ...]
    valido_estruturalmente: bool = False
    quantidade_verificacoes: int = 0


@dataclass(frozen=True, slots=True)
class Evento:
    tipo: TipoEvento
    duracao_fornecida: int | float | None = None


@dataclass(frozen=True, slots=True)
class ResumoEventos(SemAprovacao):
    fase: FaseEvento
    estados: tuple[EstadoG10, ...]
    motivos: tuple[Motivo, ...]
    quantidade_eventos: int
    quantidade_aplicados: int
    interrupcao_fornecida: bool
    termino_fornecido: bool
    fechamento_declarado: bool
    duracao_fornecida: int | float | None


@dataclass(frozen=True, slots=True)
class RegistroIntegrado(SemAprovacao):
    """Projeção DEV-2 imutável, derivada internamente; não é atestado."""
    estados: tuple[str, ...]
    motivos: tuple[str, ...]
    quantidade_verificacoes: int
    quantidade_eventos: int
    referencia: str | None
    validade_estrutural: bool
    campos_descartados: int

    def como_dict(self) -> dict:
        # Cada exportação é independente; mutar a cópia não altera o resultado.
        return {
            "versao_registro": "WIN19-DEV2-REGISTRO-1",
            "estados": list(self.estados), "motivos": list(self.motivos),
            "quantidade_verificacoes": self.quantidade_verificacoes,
            "quantidade_eventos": self.quantidade_eventos,
            "referencia": self.referencia,
            "validade_estrutural": self.validade_estrutural,
            "campos_descartados": self.campos_descartados,
            "destino_aprovado": False, "custodia_autorizada": False,
            "operacao_autorizada": False, "prontidao_operacional": False,
            "origem_autenticada": False, "autorizacao_comprovada": False,
            "encerramento_comprovado": False,
        }


@dataclass(frozen=True, slots=True)
class ResultadoFluxo(SemAprovacao):
    origem: ReferenciaOrigem | None
    contexto: ContextoPassivo | None
    recepcao: ResultadoRecepcao | None
    eventos: ResumoEventos | None
    estados: tuple[EstadoG10, ...]
    motivos: tuple[Motivo, ...]
    registro: RegistroIntegrado | None

    @property
    def valido_estruturalmente(self) -> bool:
        return (self.recepcao is not None
                and self.recepcao.valido_estruturalmente is True)

    @property
    def registro_disponivel(self) -> bool:
        return self.registro is not None
