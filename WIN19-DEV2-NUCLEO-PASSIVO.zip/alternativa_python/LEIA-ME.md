# WIN19 DEV-2 — integração offline passiva

27/11/2026. Python 3.12, somente biblioteca padrão, BT01 Codex.
Código e autotestes sintéticos autorizados para DEV-2; nenhuma liberação operacional.

## API pública nova

alternativa_python.fluxo.executar_fluxo(entrada) retorna ResultadoFluxo congelado.
A entrada deve ser dict exato com quatro chaves exatas:
- conteudo: bytes sintéticos ou None, limitado a 16.384 bytes por A/D;
- sha256_esperado: digest declarado ou None, nunca prova de origem legítima;
- contexto: declaração sintética em dict fechado ou None, nunca autoridade;
- eventos: lista/tupla de Evento fornecidos, no máximo 32, sem observação própria.

Não admite validade_estrutural, autorização, destino, payload livre, registro ou
objetos prontos de componentes como campos do envelope. Chaves/tipos de envelope
incompatíveis são recusados; componentes não executados ficam None, sem simular
resultados. Para subentradas, os contratos exatos e limites DEV-1 são preservados.
Strings referencia/finalidade de contexto agora têm limite de 32 caracteres antes
do confronto; isso não cria legitimidade ou novo campo de dado privado.

A é chamada com os bytes fornecidos; B representa a declaração; D produz o
ResultadoRecepcao efetivo; E reduz os eventos; F projeta somente dados derivados.
A validade do resultado e do registro é derivada de D, não de campo livre.
Divergência de hash, contexto insuficiente ou evento inválido não apagam a
validade estritamente estrutural do JSON: preservam motivos/estados adversos e
não comprovam nenhum fato ou autorização.

O objeto reúne origem/contexto/recepcao/eventos e estados/motivos fechados.
ResultadoFluxo.registro é RegistroIntegrado imutável ou None se falhar a montagem.
registro.como_dict() exporta cópia independente com flags sempre false. Alterar
essa cópia não altera o resultado. Contagens/referências/estados/motivos/validade
precisam corresponder aos componentes produzidos pelo fluxo.

Montagem incompatível ou exceção comum na projeção preserva os estados adversos,
adiciona REGISTRO_INDISPONIVEL e EVIDENCIA_INCOMPATIVEL e retorna registro=None.
Não ecoa a exceção nem fabrica registro de sucesso; falhas fatais do host não
são cobertas. O núcleo não é sandbox contra Python hostil no mesmo processo,
monkeypatching ou adulteração por reflexão; os testes de falha são injeções
sintéticas limitadas, não prova de segurança universal.

## Compatibilidade e semântica

As APIs públicas DEV-1 e os 79 testes antigos permanecem. sanitizar(dict) continua
sendo projeção sem autenticar validade declarada quando chamado diretamente;
a integração usa o caminho interno novo _projetar_integrado e verifica coerência.
Esse caminho não aceita metadados livres para substituir o retorno real de D.
Dois motivos novos: ENTRADA_FLUXO_INVALIDA e REGISTRO_INDISPONIVEL.
Os sete estados G10 e o contrato JSON sintético WIN19-DEV1-SINTETICO-1 não mudam.
Registro integrado tem versão WIN19-DEV2-REGISTRO-1, diferente da projeção legada.
Nenhuma dessas estruturas é contrato real da H3-F-R1 ou prova factual.

Os cinco arquivos de testes DEV-1, RELATORIO_DEV1.md e MANIFESTO_SHA256_DEV1 são
cópias históricas intactas. O manifesto antigo autentica os bytes DEV-1 no ZIP
original, não a árvore modificada DEV-2. Para esta entrega usar exclusivamente
MANIFESTO_SHA256_DEV2, que cobre todos os outros 19 arquivos, inclusive a cópia
histórica do manifesto antigo. Não aplicar o manifesto antigo aos módulos DEV-2
nem herdar hashes/aprovações/sintaxe de outro pacote.

## Testes autorizados DEV-2

Na raiz DEV-2:
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 python -B -m unittest discover -s tests -p 'test_*.py' -v

Sete arquivos de testes, cinco históricos sem alteração e dois novos. Somente
unittest/biblioteca padrão e módulos novos isolados. Sem instalação, serviços,
rede, Git, relógio/processo ativo, Windows, WMI, ACL/DACL, JUnit ou dados reais.
Verificação de IO dos testes cobre os caminhos sintéticos exercitados e revisão
estática, não é certificação universal de efeitos de execução.

G09/G10 operacional não comprovados; L-D06 pendente, R01–R09 abertos, R03/R07 ALTA,
N02–N04 não verificados. U05/U06/U07 não autorizadas; C/H3-F-R1 inalterada e não
executada; P1–P6 sem liberação operacional, conversões bloqueadas e prontidão false.
Relatório e diferenças fornecem os resultados efetivamente executados e os limites.
Sem publicação, Git, integração ao MVP, DEV-3, inspeção ou custódia automáticos.

---

## Referência histórica: LEIA-ME DEV-1

O texto abaixo é a documentação de origem, anterior às extensões descritas acima.
Seu inventário de 14 arquivos e seis módulos refere-se apenas ao DEV-1 original.

# WIN19 DEV-1 — núcleo passivo sintético

Python 3.12, somente biblioteca padrão. U01–U04 implementadas exclusivamente como
biblioteca passiva nesta área BT01 do Codex. U05/U06/U07 não autorizadas.
Nenhuma integração com conversor, H3-F-R1 ou Windows. Não é sandbox para código
Python adversarial; as entradas admitidas são tipos primitivos/contratos fechados,
e o chamador continua responsável por fornecer apenas material sintético.

## APIs e fronteiras

- origem.conferir(bytes, sha256_esperado=None): SHA-256 de bytes fornecidos, no
  máximo 16.384 bytes. Digest esperado exige 64 hexadecimais minúsculos.
  Coincidir com declaração não autentica origem, carregamento ou autoridade.
- contexto.avaliar(dict | None): exige seis campos fechados. Referências somente
  REF_SINTETICA_A/REF_SINTETICA_B, finalidade OBSERVACAO_LIMITADA e quatro booleanos:
  autorizacao_declarada, operador_declarado, escopo_declarado, vigencia_declarada.
  Declaração completa continua não comprovada; nenhum prazo ou pessoa reais.
- recepcao.receber(bytes | None, sha256_esperado=None, contexto=None): classifica
  JSON em memória no contrato WIN19-DEV1-SINTETICO-1 abaixo. Não recebe caminho,
  lê arquivo ou captura canal. Não é consumidor do contrato operacional H3-F-R1.
- eventos.resumir(list[Evento] | tuple[Evento,...]): reduz eventos fornecidos.
  Início declarado/observado-fornecido, saída, interrupção, término, incerteza e
  fechamento declarado. Nenhuma observação própria ou interferência em processos.
- registro.sanitizar(dict | None): projeção por allowlist; somente enumerações,
  contagens limitadas e duas referências sintéticas. Sem payload, erros livres,
  digest bruto, caminhos, pessoas, contas, SIDs ou credenciais.
- contratos: tipos congelados, enums fechados e propriedades constantes false
  para destino/custódia/operação/autenticidade/autorização/fechamento/prontidão.

Não usar APIs com dados reais ou JUnit. Um marcador sintético não prova a origem
factual dos dados; nesta entrega apenas entradas fabricadas são usadas.

## Contrato de recepção sintético e versionado

Objeto único com exatamente nove campos:
versao (string WIN19-DEV1-SINTETICO-1), sintetico (true), documento_real (false),
resultado (INCONCLUSIVO ou IMPEDIMENTO), verificacoes (lista não vazia),
recursos_encerrados (booleano ou null), destino_aprovado (false),
custodia_autorizada (false) e operacao_autorizada (false).

Cada verificação tem exatamente id S01–S16 único e estado de
NAO_EXECUTADO/INCONCLUSIVO/IMPEDIMENTO/OBSERVADO_SINTETICO.
O resultado IMPEDIMENTO é obrigatório se e somente se houver esse estado na lista.
OBSERVADO_SINTETICO é declaração fictícia para o teste, nunca aprovação material.

Limites delegados: 16 KiB de bytes UTF-8 estritos sem BOM, 256 nós JSON,
profundidade 12 e até 16 verificações. Duplicatas em qualquer nível, NaN/Infinity,
overflow não finito, conteúdo adicional, estrutura/tipos/flags incompatíveis são
recusados. Ausência difere de fragmento; diagnóstico de possível incompletude
sintática não comprova truncamento de transporte. Exceções não ecoam o payload.
A árvore é limitada após decodificação; a entrada em bytes já está limitada antes.
Isso limita volume computacional, não garante um tempo máximo de execução.

EVIDENCIA_RECEBIDA_VALIDAVEL significa apenas estrutura sintética apta à revisão,
não verdade material ou vínculo real autenticado. Hash divergente preserva
valido_estruturalmente mas classifica atribuição incompatível. Nenhuma referência
autorreferente comprova legitimidade. O contexto ausente/inadequado fica explícito.

Sete estados externos: EVIDENCIA_RECEBIDA_VALIDAVEL, EVIDENCIA_INCOMPLETA,
EVIDENCIA_AUSENTE, EVIDENCIA_INCOMPATIVEL, EXECUCAO_INTERROMPIDA,
ENCERRAMENTO_NAO_COMPROVADO, RESULTADO_INCONCLUSIVO.
Eixos podem coexistir; não há DESTINO_APROVADO como estado.
Todas as respostas permanecem inconclusivas para execução/segurança reais.

## Eventos e registro

Máximo de 32 eventos por redução; tipo Evento/TipoEvento exatos. Não há relógio,
sleep, timeout ativo, processo ou supervisor. Duração finita fornecida entre
zero e 1.000.000.000, não decrescente quando presente, é só limite de dado
sintético: não é orçamento ou autorização de execução real.
Início precede saída/interrupção/término. Não há reinício após término.
Primeiro evento/duração/transição inválidos interrompe a redução, preservando
estado anterior e motivo seguro; eventos posteriores não são aplicados.
Fechamento fornecido/declarado não comprova recursos; sua incerteza permanece.
Quantidade recebida é limitada ao máximo quando a entrada excede o limite.

Registro admite estados/motivos, quantidade_verificacoes (0–16),
quantidade_eventos (0–32), referencia fechada, validade_estrutural e flags de
não aprovação. Booleano não é contagem. Até 32 campos de entrada; excesso recusa
o conjunto conservadoramente. Campos descartados são contados (com limite),
nunca copiados. Tentativa de flag true é recusada com APROVACAO_INDEVIDA e false.
Motivo/estado desconhecidos não são ecoados; dados adversos conhecidos permanecem.
F não verifica por si a origem factual do que o chamador declara estruturalmente
válido. Sanitização não apaga memória/logs/host nem comprova privacidade universal.

## Verificação autorizada no Codex

Na raiz DEV-1, comando:
python -B -m unittest discover -s tests -p 'test_*.py' -v

Os cinco arquivos tests usam somente unittest, biblioteca padrão e os seis módulos
novos. Tudo em memória e com dados fictícios. Não há teste do produto, import do
conversor, leitura privada, API Windows ou validação formal P2/P3/P4/P5/P6.
Não adicionar __init__.py: o pacote usa namespace Python, mantendo o inventário
fechado. -B evita caches. Nenhuma instalação necessária/autorizada.

## Estados e preservação

Autorização DEV-1 permite desenvolvimento/autotestes locais, não C, host,
observação, custódia ou publicação. G09/G10 continuam sem comprovação para execução
real, L-D06 pendente, R01–R09 abertos (R03/R07 ALTA), N02–N04 não verificados;
N01 antiga só se aplica aos bytes R1.
H3-F-R1 inalterada e não autorizada; WIN01–WIN19/DACL não validados; H3-C/H3-S/H4
não autorizadas; conversões reais bloqueadas e prontidao_operacional=false.

Auditar código/testes/resultados/manifesto e parar. O ZIP local autorizado contém
somente 14 arquivos; nenhuma publicação/Git é permitida nesta rodada.
