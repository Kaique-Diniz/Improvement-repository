"""E: reduz somente eventos entregues em memória; não usa relógio/processos."""
import math
from .contratos import (
    MAX_EVENTOS, MAX_DURACAO_FORNECIDA, Evento, FaseEvento, TipoEvento,
    EstadoG10, Motivo, ResumoEventos,
)


def resumir(eventos: list[Evento] | tuple[Evento, ...]) -> ResumoEventos:
    fase = FaseEvento.INICIAL
    aplicados = 0
    interrompida = termino = fechamento = False
    duracao = None
    motivos = [Motivo.SOMENTE_SINTETICO, Motivo.ENCERRAMENTO_INCERTO]
    invalido = False
    if type(eventos) not in (list, tuple):
        recebidos = 0
        motivos.append(Motivo.TIPO_ENTRADA_INVALIDO)
        invalido = True
        sequencia = ()
    elif len(eventos) > MAX_EVENTOS:
        recebidos = MAX_EVENTOS
        motivos.append(Motivo.LIMITE_EXCEDIDO)
        invalido = True
        sequencia = ()
    else:
        recebidos = len(eventos)
        sequencia = eventos
    for evento in sequencia:
        if type(evento) is not Evento or type(evento.tipo) is not TipoEvento:
            motivos.append(Motivo.EVENTO_INVALIDO)
            invalido = True
            break
        d = evento.duracao_fornecida
        if d is not None and (
            type(d) not in (int, float)
            or not 0 <= d <= MAX_DURACAO_FORNECIDA
            or not math.isfinite(d)
            or (duracao is not None and d < duracao)
        ):
            motivos.append(Motivo.DURACAO_INVALIDA)
            invalido = True
            break
        tipo = evento.tipo
        inicio = tipo in {TipoEvento.INICIO_DECLARADO,
                          TipoEvento.INICIO_OBSERVADO_FORNECIDO}
        permitido = (
            (inicio and fase == FaseEvento.INICIAL)
            or (tipo == TipoEvento.SAIDA_FORNECIDA and fase == FaseEvento.INICIADO)
            or (tipo == TipoEvento.INTERRUPCAO_FORNECIDA
                and fase in {FaseEvento.INICIADO, FaseEvento.COM_SAIDA})
            or (tipo == TipoEvento.TERMINO_FORNECIDO
                and fase in {FaseEvento.INICIADO, FaseEvento.COM_SAIDA,
                             FaseEvento.INTERROMPIDO})
            or (tipo == TipoEvento.RECURSOS_INCERTOS and fase != FaseEvento.INICIAL)
            or (tipo == TipoEvento.FECHAMENTO_DECLARADO
                and fase == FaseEvento.TERMINADO and not fechamento)
        )
        if not permitido:
            motivos.append(Motivo.TRANSICAO_INVALIDA)
            invalido = True
            break
        if inicio:
            fase = FaseEvento.INICIADO
        elif tipo == TipoEvento.SAIDA_FORNECIDA:
            fase = FaseEvento.COM_SAIDA
        elif tipo == TipoEvento.INTERRUPCAO_FORNECIDA:
            fase = FaseEvento.INTERROMPIDO
            interrompida = True
            motivos.append(Motivo.INTERRUPCAO_FORNECIDA)
        elif tipo == TipoEvento.TERMINO_FORNECIDO:
            fase = FaseEvento.TERMINADO
            termino = True
        elif tipo == TipoEvento.FECHAMENTO_DECLARADO:
            fechamento = True
        elif tipo == TipoEvento.RECURSOS_INCERTOS:
            fechamento = False
        if d is not None:
            duracao = d
        aplicados += 1
    estados = []
    if interrompida:
        estados.append(EstadoG10.EXECUCAO_INTERROMPIDA)
    if invalido:
        estados.append(EstadoG10.EVIDENCIA_INCOMPATIVEL)
    estados.extend((EstadoG10.ENCERRAMENTO_NAO_COMPROVADO,
                    EstadoG10.RESULTADO_INCONCLUSIVO))
    return ResumoEventos(fase, tuple(estados), tuple(dict.fromkeys(motivos)),
                         recebidos, aplicados, interrompida, termino,
                         fechamento, duracao)
