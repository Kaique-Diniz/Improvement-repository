"""Integração passiva DEV-2: somente primitivas/contratos sintéticos em memória."""
from . import origem, contexto, recepcao, eventos, registro
from .contratos import (
    EstadoG10, EstadoOrigem, Motivo, ResultadoFluxo, RegistroIntegrado,
)

_CAMPOS = frozenset({"conteudo", "sha256_esperado", "contexto", "eventos"})


def _registro_coerente(reg, r, e, c, estados, motivos):
    if type(reg) is not RegistroIntegrado:
        return False
    if (type(reg.estados) is not tuple or type(reg.motivos) is not tuple
            or any(type(v) is not str for v in reg.estados + reg.motivos)
            or type(reg.quantidade_verificacoes) is not int
            or type(reg.quantidade_eventos) is not int
            or type(reg.validade_estrutural) is not bool
            or type(reg.campos_descartados) is not int
            or (reg.referencia is not None and type(reg.referencia) is not str)):
        return False
    validade = r is not None and r.valido_estruturalmente is True
    ref = c.referencia.value if c is not None and c.referencia is not None else None
    return (
        reg.estados == tuple(s.value for s in estados)
        and reg.motivos == tuple(m.value for m in motivos)
        and reg.quantidade_verificacoes == (r.quantidade_verificacoes if r else 0)
        and reg.quantidade_eventos == (e.quantidade_aplicados if e else 0)
        and reg.validade_estrutural is validade and reg.referencia == ref
        and reg.campos_descartados == 0
    )


def _finalizar(a, b, d, e, estados, motivos):
    estados = tuple(dict.fromkeys(tuple(estados) + (
        EstadoG10.ENCERRAMENTO_NAO_COMPROVADO, EstadoG10.RESULTADO_INCONCLUSIVO)))
    motivos = tuple(dict.fromkeys(tuple(motivos) + (
        Motivo.SOMENTE_SINTETICO, Motivo.ORIGEM_NAO_AUTENTICADA,
        Motivo.AUTORIZACAO_NAO_COMPROVADA, Motivo.ENCERRAMENTO_INCERTO)))
    try:
        reg = registro._projetar_integrado(d, e, b, estados, motivos)
        if not _registro_coerente(reg, d, e, b, estados, motivos):
            raise ValueError("REGISTRO_INTERNO_INCOMPATIVEL")
    except Exception:
        # Apenas a fronteira de montagem: não ecoar exceção/payload e não
        # fabricar registro de sucesso. Falhas fatais do host não são cobertas.
        reg = None
        estados = tuple(dict.fromkeys(
            estados + (EstadoG10.EVIDENCIA_INCOMPATIVEL,)))
        motivos = tuple(dict.fromkeys(
            motivos + (Motivo.REGISTRO_INDISPONIVEL,)))
    return ResultadoFluxo(a, b, d, e, estados, motivos, reg)


def executar_fluxo(entrada: dict) -> ResultadoFluxo:
    """Quatro campos exatos; nenhuma validade/autoridade/flag livre é admitida."""
    if (type(entrada) is not dict or len(entrada) != len(_CAMPOS)
            or any(type(k) is not str for k in entrada)
            or set(entrada) != _CAMPOS):
        # Componentes não executados permanecem None, não respostas simuladas.
        return _finalizar(None, None, None, None,
                          (EstadoG10.EVIDENCIA_INCOMPATIVEL,),
                          (Motivo.ENTRADA_FLUXO_INVALIDA,))
    conteudo = entrada["conteudo"]
    esperado = entrada["sha256_esperado"]
    a = origem.conferir(conteudo, esperado)
    b = contexto.avaliar(entrada["contexto"])
    d = recepcao.receber(conteudo, sha256_esperado=esperado, contexto=b)
    e = eventos.resumir(entrada["eventos"])
    motivos = d.motivos + b.motivos + e.motivos
    estados = d.estados + e.estados
    if a.estado == EstadoOrigem.DIVERGE:
        motivos += (Motivo.ORIGEM_DIVERGENTE,)
        estados += (EstadoG10.EVIDENCIA_INCOMPATIVEL,)
    elif a.estado == EstadoOrigem.REFERENCIA_INVALIDA:
        motivos += (Motivo.REFERENCIA_ORIGEM_INVALIDA,)
        estados += (EstadoG10.EVIDENCIA_INCOMPATIVEL,)
    return _finalizar(a, b, d, e, estados, motivos)
