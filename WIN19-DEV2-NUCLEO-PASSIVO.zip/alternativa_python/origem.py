"""A: identidade atual de bytes sintéticos em memória, sem leitura de arquivo."""
import hashlib
import hmac
from .contratos import MAX_BYTES, EstadoOrigem, ReferenciaOrigem


def conferir(conteudo: bytes, sha256_esperado: str | None = None) -> ReferenciaOrigem:
    if type(conteudo) is not bytes or len(conteudo) > MAX_BYTES:
        return ReferenciaOrigem(EstadoOrigem.ENTRADA_INVALIDA, None)
    calculado = hashlib.sha256(conteudo).hexdigest()
    if sha256_esperado is None:
        return ReferenciaOrigem(EstadoOrigem.SEM_REFERENCIA, calculado)
    if (type(sha256_esperado) is not str or len(sha256_esperado) != 64
            or any(c not in "0123456789abcdef" for c in sha256_esperado)):
        return ReferenciaOrigem(EstadoOrigem.REFERENCIA_INVALIDA, calculado)
    estado = (EstadoOrigem.COINCIDE_COM_DECLARADO
              if hmac.compare_digest(calculado, sha256_esperado)
              else EstadoOrigem.DIVERGE)
    return ReferenciaOrigem(estado, calculado)
