"""F: allowlist de projeção em memória, sem IO ou eco de dados arbitrários."""
from .contratos import (
    EstadoG10, Motivo, Referencia, MAX_VERIFICACOES, MAX_EVENTOS,
    MAX_CAMPOS_REGISTRO, ContextoPassivo, ResultadoRecepcao,
    ResumoEventos, RegistroIntegrado,
)

_FLAGS = (
    "destino_aprovado", "custodia_autorizada", "operacao_autorizada",
    "prontidao_operacional", "origem_autenticada",
    "autorizacao_comprovada", "encerramento_comprovado",
)
_ENTRADAS = frozenset({
    "estados", "motivos", "quantidade_verificacoes", "quantidade_eventos",
    "referencia", "validade_estrutural",
}) | frozenset(_FLAGS)


def _tokens(valor, enum):
    if type(valor) not in (list, tuple) or len(valor) > 32:
        return [], False
    permitidos = {item.value for item in enum}
    saida = []
    correto = True
    for item in valor:
        if type(item) is enum:
            token = item.value
        elif type(item) is str and item in permitidos:
            token = item
        else:
            correto = False
            continue
        if token not in saida:
            saida.append(token)
    return saida, correto


def sanitizar(entrada: dict | None) -> dict:
    saida = {
        "versao_registro": "WIN19-DEV1-REGISTRO-1",
        "estados": [], "motivos": [], "quantidade_verificacoes": 0,
        "quantidade_eventos": 0, "referencia": None,
        "validade_estrutural": False, "campos_descartados": 0,
        **{campo: False for campo in _FLAGS},
    }
    motivos = []
    if type(entrada) is not dict:
        entrada = {}
        motivos.append(Motivo.TIPO_ENTRADA_INVALIDO.value)
    elif len(entrada) > MAX_CAMPOS_REGISTRO:
        saida["campos_descartados"] = MAX_CAMPOS_REGISTRO
        entrada = {}
        motivos.append(Motivo.LIMITE_EXCEDIDO.value)
    if any(type(k) is not str for k in entrada):
        saida["campos_descartados"] = len(entrada)
        entrada = {}
        motivos.append(Motivo.CAMPO_REGISTRO_INVALIDO.value)
    desconhecidos = sum(1 for k in entrada
                       if type(k) is not str or k not in _ENTRADAS)
    saida["campos_descartados"] += desconhecidos
    if desconhecidos:
        motivos.append(Motivo.CAMPOS_DESCARTADOS.value)
    for campo, enum in (("estados", EstadoG10), ("motivos", Motivo)):
        if campo in entrada:
            valores, correto = _tokens(entrada[campo], enum)
            saida[campo] = valores
            if not correto:
                motivos.append(Motivo.CAMPO_REGISTRO_INVALIDO.value)
    for campo, limite in (("quantidade_verificacoes", MAX_VERIFICACOES),
                          ("quantidade_eventos", MAX_EVENTOS)):
        if campo in entrada:
            valor = entrada[campo]
            if type(valor) is int and 0 <= valor <= limite:
                saida[campo] = valor
            else:
                motivos.append(Motivo.CAMPO_REGISTRO_INVALIDO.value)
    if "validade_estrutural" in entrada:
        if type(entrada["validade_estrutural"]) is bool:
            saida["validade_estrutural"] = entrada["validade_estrutural"]
        else:
            motivos.append(Motivo.CAMPO_REGISTRO_INVALIDO.value)
    if "referencia" in entrada:
        ref = entrada["referencia"]
        if type(ref) is Referencia:
            saida["referencia"] = ref.value
        elif type(ref) is str and ref in {r.value for r in Referencia}:
            saida["referencia"] = ref
        elif ref is not None:
            motivos.append(Motivo.CAMPO_REGISTRO_INVALIDO.value)
    for campo in _FLAGS:
        if campo in entrada and entrada[campo] is not False:
            motivos.append(Motivo.APROVACAO_INDEVIDA.value)
    saida["estados"] = list(dict.fromkeys(
        saida["estados"] + [EstadoG10.ENCERRAMENTO_NAO_COMPROVADO.value,
                           EstadoG10.RESULTADO_INCONCLUSIVO.value]))
    saida["motivos"] = list(dict.fromkeys(
        saida["motivos"] + motivos
        + [Motivo.SOMENTE_SINTETICO.value,
           Motivo.ORIGEM_NAO_AUTENTICADA.value,
           Motivo.AUTORIZACAO_NAO_COMPROVADA.value]))
    return saida


def _projetar_integrado(recepcao, eventos, contexto, estados, motivos):
    """Uso interno do coordenador; não recebe validade livre do chamador."""
    if (recepcao is not None and type(recepcao) is not ResultadoRecepcao
            or eventos is not None and type(eventos) is not ResumoEventos
            or contexto is not None and type(contexto) is not ContextoPassivo
            or type(estados) is not tuple
            or any(type(v) is not EstadoG10 for v in estados)
            or type(motivos) is not tuple
            or any(type(v) is not Motivo for v in motivos)):
        raise ValueError("CONTRATO_INTERNO_INVALIDO")
    validade = (recepcao is not None
                and recepcao.valido_estruturalmente is True)
    referencia = contexto.referencia if contexto is not None else None
    dados = sanitizar({
        "estados": estados, "motivos": motivos,
        "quantidade_verificacoes": (recepcao.quantidade_verificacoes
                                   if recepcao is not None else 0),
        "quantidade_eventos": (eventos.quantidade_aplicados
                               if eventos is not None else 0),
        "referencia": referencia, "validade_estrutural": validade,
    })
    return RegistroIntegrado(
        tuple(dados["estados"]), tuple(dados["motivos"]),
        dados["quantidade_verificacoes"], dados["quantidade_eventos"],
        dados["referencia"], validade, dados["campos_descartados"],
    )
