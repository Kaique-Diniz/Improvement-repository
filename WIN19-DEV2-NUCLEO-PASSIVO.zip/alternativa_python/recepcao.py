"""D: contrato sintético DEV-1; não é consumidor operacional da H3-F-R1."""
import json
import math
from .contratos import (
    VERSAO, MAX_BYTES, MAX_NOS, MAX_PROFUNDIDADE, MAX_VERIFICACOES,
    ContextoPassivo, EstadoContexto, EstadoG10, EstadoOrigem, Motivo,
    ResultadoRecepcao,
)
from .origem import conferir

_CAMPOS = frozenset({
    "versao", "sintetico", "documento_real", "resultado", "verificacoes",
    "recursos_encerrados", "destino_aprovado",
    "custodia_autorizada", "operacao_autorizada",
})
_FLAGS = ("destino_aprovado", "custodia_autorizada", "operacao_autorizada")
_IDS = frozenset(f"S{i:02d}" for i in range(1, MAX_VERIFICACOES + 1))
_ESTADOS = frozenset({
    "NAO_EXECUTADO", "INCONCLUSIVO", "IMPEDIMENTO", "OBSERVADO_SINTETICO",
})


class _ChaveDuplicada(ValueError):
    pass


class _ValorNaoJSON(ValueError):
    pass


def _objeto(pares):
    obj = {}
    for k, v in pares:
        if k in obj:
            raise _ChaveDuplicada()
        obj[k] = v
    return obj


def _constante(_):
    raise _ValorNaoJSON()


def _real(texto):
    numero = float(texto)
    if not math.isfinite(numero):
        raise _ValorNaoJSON()
    return numero


def _arvore_limitada(obj):
    pendentes = [(obj, 1)]
    contagem = 0
    while pendentes:
        atual, nivel = pendentes.pop()
        contagem += 1
        if contagem > MAX_NOS or nivel > MAX_PROFUNDIDADE:
            return False
        if type(atual) is dict:
            pendentes.extend((v, nivel + 1) for v in atual.values())
        elif type(atual) is list:
            pendentes.extend((v, nivel + 1) for v in atual)
    return True


def _formato(obj):
    if type(obj) is not dict or set(obj) != _CAMPOS:
        return False
    if (type(obj["versao"]) is not str or obj["versao"] != VERSAO
            or obj["sintetico"] is not True or obj["documento_real"] is not False
            or any(obj[k] is not False for k in _FLAGS)
            or (obj["recursos_encerrados"] is not None
                and type(obj["recursos_encerrados"]) is not bool)
            or type(obj["resultado"]) is not str
            or obj["resultado"] not in {"INCONCLUSIVO", "IMPEDIMENTO"}):
        return False
    itens = obj["verificacoes"]
    if type(itens) is not list or not 1 <= len(itens) <= MAX_VERIFICACOES:
        return False
    ids = set()
    impedimento = False
    for item in itens:
        if (type(item) is not dict or set(item) != {"id", "estado"}
                or type(item["id"]) is not str or item["id"] not in _IDS
                or item["id"] in ids or type(item["estado"]) is not str
                or item["estado"] not in _ESTADOS):
            return False
        ids.add(item["id"])
        impedimento = impedimento or item["estado"] == "IMPEDIMENTO"
    return (obj["resultado"] == "IMPEDIMENTO") == impedimento


def _resposta(estado, motivos, valido=False, quantidade=0):
    return ResultadoRecepcao(
        (estado, EstadoG10.ENCERRAMENTO_NAO_COMPROVADO,
         EstadoG10.RESULTADO_INCONCLUSIVO),
        tuple(dict.fromkeys(motivos)), valido, quantidade,
    )


def receber(conteudo: bytes | None, *, sha256_esperado: str | None = None,
            contexto: ContextoPassivo | None = None) -> ResultadoRecepcao:
    """Valida estrutura sintética, sem certificar vínculo, contexto ou fatos."""
    base = (Motivo.SOMENTE_SINTETICO, Motivo.ORIGEM_NAO_AUTENTICADA,
            Motivo.AUTORIZACAO_NAO_COMPROVADA, Motivo.ENCERRAMENTO_INCERTO)
    if conteudo is None or (type(conteudo) is bytes and not conteudo):
        return _resposta(EstadoG10.EVIDENCIA_AUSENTE, base + (Motivo.SEM_CONTEUDO,))
    if type(conteudo) is not bytes:
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.TIPO_ENTRADA_INVALIDO,))
    if len(conteudo) > MAX_BYTES:
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.LIMITE_EXCEDIDO,))
    try:
        texto = conteudo.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.CODIFICACAO_INVALIDA,))
    if texto.startswith("\ufeff"):
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.CODIFICACAO_INVALIDA,))
    try:
        obj = json.loads(texto, object_pairs_hook=_objeto,
                         parse_constant=_constante, parse_float=_real)
    except _ChaveDuplicada:
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.CHAVE_DUPLICADA,))
    except _ValorNaoJSON:
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.VALOR_NAO_JSON,))
    except json.JSONDecodeError as erro:
        incompleto = (erro.pos >= len(texto.rstrip())
                      or erro.msg.startswith("Unterminated string"))
        return _resposta(
            EstadoG10.EVIDENCIA_INCOMPLETA if incompleto
            else EstadoG10.EVIDENCIA_INCOMPATIVEL,
            base + (Motivo.JSON_INCOMPLETO if incompleto else Motivo.JSON_INVALIDO,),
        )
    except (RecursionError, ValueError, OverflowError):
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.LIMITE_EXCEDIDO,))
    if not _arvore_limitada(obj):
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.LIMITE_EXCEDIDO,))
    if not _formato(obj):
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (Motivo.ESTRUTURA_INCOMPATIVEL,))
    quantidade = len(obj["verificacoes"])
    origem = conferir(conteudo, sha256_esperado)
    if origem.estado in {EstadoOrigem.DIVERGE, EstadoOrigem.REFERENCIA_INVALIDA}:
        motivo = (Motivo.ORIGEM_DIVERGENTE if origem.estado == EstadoOrigem.DIVERGE
                  else Motivo.REFERENCIA_ORIGEM_INVALIDA)
        return _resposta(EstadoG10.EVIDENCIA_INCOMPATIVEL,
                         base + (motivo,), True, quantidade)
    motivos = base
    if contexto is None:
        motivos += (Motivo.CONTEXTO_AUSENTE,)
    elif type(contexto) is not ContextoPassivo:
        motivos += (Motivo.CONTEXTO_INVALIDO,)
    elif type(contexto.estado) is not EstadoContexto:
        motivos += (Motivo.CONTEXTO_INVALIDO,)
    elif contexto.estado != EstadoContexto.DECLARACAO_COMPLETA:
        motivos += (Motivo.CONTEXTO_INSUFICIENTE,)
    if obj["resultado"] == "IMPEDIMENTO":
        motivos += (Motivo.IMPEDIMENTO_DECLARADO,)
    return _resposta(EstadoG10.EVIDENCIA_RECEBIDA_VALIDAVEL,
                     motivos, True, quantidade)
