import unittest
from alternativa_python.origem import conferir
from alternativa_python.contexto import avaliar
from alternativa_python.contratos import (
    MAX_BYTES, EstadoOrigem, EstadoContexto, Motivo, ReferenciaOrigem,
)


def declaracao():
    return {
        "referencia": "REF_SINTETICA_A", "finalidade": "OBSERVACAO_LIMITADA",
        "autorizacao_declarada": True, "operador_declarado": True,
        "escopo_declarado": True, "vigencia_declarada": True,
    }


class OrigemContextoTests(unittest.TestCase):
    def test_hash_conhecido_sem_autenticidade(self):
        r = conferir(b"abc", "ba7816bf8f01cfea414140de5dae2223"
                     "b00361a396177a9cb410ff61f20015ad")
        self.assertEqual(r.estado, EstadoOrigem.COINCIDE_COM_DECLARADO)
        self.assertFalse(r.origem_autenticada)
        self.assertFalse(r.operacao_autorizada)

    def test_hash_divergente(self):
        self.assertEqual(conferir(b"abc", "0" * 64).estado, EstadoOrigem.DIVERGE)

    def test_referencia_invalida_nao_ecoada(self):
        r = conferir(b"abc", "SEGREDO_SINTETICO")
        self.assertEqual(r.estado, EstadoOrigem.REFERENCIA_INVALIDA)
        self.assertNotIn("SEGREDO_SINTETICO", repr(r))

    def test_sem_referencia(self):
        self.assertEqual(conferir(b"").estado, EstadoOrigem.SEM_REFERENCIA)

    def test_hash_excesso_tamanho(self):
        r = conferir(b"x" * (MAX_BYTES + 1))
        self.assertEqual(r.estado, EstadoOrigem.ENTRADA_INVALIDA)
        self.assertIsNone(r.sha256_calculado)

    def test_hash_tipo_estrito(self):
        self.assertEqual(conferir(bytearray(b"a")).estado,
                         EstadoOrigem.ENTRADA_INVALIDA)

    def test_hash_maiusculo_recusado(self):
        self.assertEqual(conferir(b"a", "A" * 64).estado,
                         EstadoOrigem.REFERENCIA_INVALIDA)

    def test_contexto_ausente(self):
        r = avaliar(None)
        self.assertEqual(r.estado, EstadoContexto.SEM_DECLARACAO)
        self.assertFalse(r.autorizacao_comprovada)

    def test_declaracao_completa_nunca_autoriza(self):
        r = avaliar(declaracao())
        self.assertEqual(r.estado, EstadoContexto.DECLARACAO_COMPLETA)
        self.assertFalse(r.autorizacao_comprovada)
        self.assertFalse(r.destino_aprovado)
        self.assertFalse(r.prontidao_operacional)
        self.assertIn(Motivo.AUTORIZACAO_NAO_COMPROVADA, r.motivos)

    def test_declaracao_negativa_insuficiente(self):
        d = declaracao()
        d["autorizacao_declarada"] = False
        self.assertEqual(avaliar(d).estado, EstadoContexto.DECLARACAO_INSUFICIENTE)

    def test_contexto_campo_extra_nao_ecoado(self):
        d = declaracao()
        d["segredo"] = "NAO_ECOAR_SINTETICO"
        r = avaliar(d)
        self.assertEqual(r.estado, EstadoContexto.DECLARACAO_INVALIDA)
        self.assertNotIn("NAO_ECOAR_SINTETICO", repr(r))

    def test_contexto_booleano_nao_e_inteiro(self):
        d = declaracao()
        d["vigencia_declarada"] = 1
        self.assertEqual(avaliar(d).estado, EstadoContexto.DECLARACAO_INVALIDA)

    def test_contexto_referencia_fora_lista(self):
        d = declaracao()
        d["referencia"] = "REFERENCIA_PRIVADA_SINTETICA"
        r = avaliar(d)
        self.assertIsNone(r.referencia)
        self.assertNotIn("REFERENCIA_PRIVADA_SINTETICA", repr(r))

    def test_constructor_nao_aceita_aprovacao(self):
        with self.assertRaises(TypeError):
            ReferenciaOrigem(EstadoOrigem.SEM_REFERENCIA, None,
                             destino_aprovado=True)
