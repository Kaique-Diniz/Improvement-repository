import json
import unittest
from alternativa_python.registro import sanitizar
from alternativa_python.contratos import EstadoG10, Motivo, Referencia


class RegistroTests(unittest.TestCase):
    def test_chaves_e_payload_privados_sinteticos_descartados(self):
        d = {"payload": "SEGREDO_SINTETICO", "caminho": "CAMINHO_SINTETICO",
             "sid": "SID_SINTETICO", "credencial": "TOKEN_SINTETICO"}
        r = sanitizar(d)
        texto = json.dumps(r)
        for segredo in d.values():
            self.assertNotIn(segredo, texto)
        self.assertEqual(r["campos_descartados"], 4)
        self.assertIn(Motivo.CAMPOS_DESCARTADOS.value, r["motivos"])

    def test_valor_arbitrario_em_campo_permitido_nao_ecoado(self):
        r = sanitizar({"motivos": ["ERRO_PRIVADO_SINTETICO"]})
        self.assertNotIn("ERRO_PRIVADO_SINTETICO", json.dumps(r))
        self.assertIn(Motivo.CAMPO_REGISTRO_INVALIDO.value, r["motivos"])

    def test_tentativa_de_aprovacao_preserva_motivo_e_false(self):
        flags = ["destino_aprovado", "custodia_autorizada", "operacao_autorizada",
                 "prontidao_operacional", "origem_autenticada",
                 "autorizacao_comprovada", "encerramento_comprovado"]
        r = sanitizar({k: True for k in flags})
        self.assertTrue(all(r[k] is False for k in flags))
        self.assertIn(Motivo.APROVACAO_INDEVIDA.value, r["motivos"])

    def test_booleano_nao_e_contagem(self):
        r = sanitizar({"quantidade_verificacoes": True})
        self.assertEqual(r["quantidade_verificacoes"], 0)
        self.assertIn(Motivo.CAMPO_REGISTRO_INVALIDO.value, r["motivos"])

    def test_referencia_fechada_permitida(self):
        self.assertEqual(sanitizar({"referencia": Referencia.SINTETICA_A})["referencia"],
                         "REF_SINTETICA_A")

    def test_referencia_arbitraria_nao_ecoada(self):
        r = sanitizar({"referencia": "PESSOA_SINTETICA_NAO_ECOAR"})
        self.assertIsNone(r["referencia"])
        self.assertNotIn("PESSOA_SINTETICA_NAO_ECOAR", json.dumps(r))

    def test_chave_nao_string(self):
        r = sanitizar({("chave",): "NAO_ECOAR_SINTETICO"})
        self.assertEqual(r["campos_descartados"], 1)
        self.assertNotIn("NAO_ECOAR_SINTETICO", json.dumps(r))

    def test_registro_grande(self):
        r = sanitizar({f"x{i}": "SINTETICO" for i in range(33)})
        self.assertIn(Motivo.LIMITE_EXCEDIDO.value, r["motivos"])
        self.assertEqual(r["campos_descartados"], 32)

    def test_destino_aprovado_nao_e_estado(self):
        r = sanitizar({"estados": ["DESTINO_APROVADO"]})
        self.assertNotIn("DESTINO_APROVADO", r["estados"])
        self.assertFalse(r["destino_aprovado"])

    def test_adversos_validos_preservados(self):
        r = sanitizar({"estados": [EstadoG10.EXECUCAO_INTERROMPIDA,
                                  EstadoG10.EVIDENCIA_INCOMPATIVEL],
                       "motivos": [Motivo.ORIGEM_DIVERGENTE],
                       "quantidade_eventos": 2})
        self.assertIn(EstadoG10.EXECUCAO_INTERROMPIDA.value, r["estados"])
        self.assertIn(Motivo.ORIGEM_DIVERGENTE.value, r["motivos"])
        self.assertEqual(r["quantidade_eventos"], 2)

    def test_entrada_nao_mutada(self):
        d = {"estados": ["EVIDENCIA_AUSENTE"], "quantidade_eventos": 0}
        antes = json.dumps(d, sort_keys=True)
        sanitizar(d)
        self.assertEqual(json.dumps(d, sort_keys=True), antes)

    def test_none_resulta_conservador(self):
        r = sanitizar(None)
        self.assertIn(Motivo.TIPO_ENTRADA_INVALIDO.value, r["motivos"])
        self.assertIn(EstadoG10.RESULTADO_INCONCLUSIVO.value, r["estados"])
