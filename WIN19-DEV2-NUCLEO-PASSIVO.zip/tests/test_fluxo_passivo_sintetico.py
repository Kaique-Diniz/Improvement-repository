import json
import unittest
from alternativa_python.origem import conferir
from alternativa_python.contexto import avaliar
from alternativa_python.recepcao import receber
from alternativa_python.eventos import resumir
from alternativa_python.registro import sanitizar
from alternativa_python.contratos import VERSAO, EstadoG10, Motivo, Evento, TipoEvento


class FluxoPassivoTests(unittest.TestCase):
    def test_fluxo_integral_em_memoria_nao_autoriza(self):
        dados = {
            "versao": VERSAO, "sintetico": True, "documento_real": False,
            "resultado": "INCONCLUSIVO",
            "verificacoes": [{"id": "S01", "estado": "OBSERVADO_SINTETICO"}],
            "recursos_encerrados": True, "destino_aprovado": False,
            "custodia_autorizada": False, "operacao_autorizada": False,
        }
        b = json.dumps(dados).encode("utf-8")
        origem = conferir(b)
        contexto = avaliar({
            "referencia": "REF_SINTETICA_A", "finalidade": "OBSERVACAO_LIMITADA",
            "autorizacao_declarada": True, "operador_declarado": True,
            "escopo_declarado": True, "vigencia_declarada": True,
        })
        recepcao = receber(b, sha256_esperado=origem.sha256_calculado,
                          contexto=contexto)
        eventos = resumir([Evento(TipoEvento.INICIO_DECLARADO, 0),
                           Evento(TipoEvento.SAIDA_FORNECIDA, 1),
                           Evento(TipoEvento.TERMINO_FORNECIDO, 2),
                           Evento(TipoEvento.FECHAMENTO_DECLARADO, 2)])
        registro = sanitizar({
            "estados": recepcao.estados + eventos.estados,
            "motivos": recepcao.motivos + eventos.motivos,
            "quantidade_verificacoes": recepcao.quantidade_verificacoes,
            "quantidade_eventos": eventos.quantidade_aplicados,
            "referencia": contexto.referencia,
            "validade_estrutural": recepcao.valido_estruturalmente,
        })
        self.assertTrue(registro["validade_estrutural"])
        self.assertEqual(registro["referencia"], "REF_SINTETICA_A")
        self.assertFalse(registro["destino_aprovado"])
        self.assertFalse(registro["autorizacao_comprovada"])
        self.assertFalse(registro["encerramento_comprovado"])
        self.assertFalse(registro["prontidao_operacional"])
        self.assertIn(EstadoG10.ENCERRAMENTO_NAO_COMPROVADO.value, registro["estados"])
        self.assertEqual(conferir(b).sha256_calculado, origem.sha256_calculado)

    def test_fluxo_adverso_preserva_divergencia_e_interrupcao(self):
        b = json.dumps({
            "versao": VERSAO, "sintetico": True, "documento_real": False,
            "resultado": "INCONCLUSIVO",
            "verificacoes": [{"id": "S01", "estado": "INCONCLUSIVO"}],
            "recursos_encerrados": None, "destino_aprovado": False,
            "custodia_autorizada": False, "operacao_autorizada": False,
        }).encode("utf-8")
        r = receber(b, sha256_esperado="0" * 64)
        e = resumir([Evento(TipoEvento.INICIO_DECLARADO),
                     Evento(TipoEvento.INTERRUPCAO_FORNECIDA)])
        registro = sanitizar({"estados": r.estados + e.estados,
                              "motivos": r.motivos + e.motivos,
                              "payload": "CONTEUDO_SINTETICO_NAO_ECOAR"})
        self.assertIn(EstadoG10.EVIDENCIA_INCOMPATIVEL.value, registro["estados"])
        self.assertIn(EstadoG10.EXECUCAO_INTERROMPIDA.value, registro["estados"])
        self.assertIn(Motivo.ORIGEM_DIVERGENTE.value, registro["motivos"])
        self.assertNotIn("CONTEUDO_SINTETICO_NAO_ECOAR", json.dumps(registro))
        self.assertFalse(registro["operacao_autorizada"])

    def test_sete_estados_sem_aprovacao(self):
        self.assertEqual(len(EstadoG10), 7)
        self.assertNotIn("DESTINO_APROVADO", {r.value for r in EstadoG10})
