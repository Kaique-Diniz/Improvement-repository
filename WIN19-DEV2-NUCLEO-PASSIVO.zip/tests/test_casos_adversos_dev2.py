import json
import unittest
from dataclasses import replace
from unittest.mock import patch
from alternativa_python.fluxo import executar_fluxo
from alternativa_python.contratos import (
    VERSAO, MAX_TEXTO_CONTEXTO, Evento, TipoEvento as T,
    EstadoG10 as G, Motivo as M, EstadoContexto,
)


def documento():
    return {
        "versao": VERSAO, "sintetico": True, "documento_real": False,
        "resultado": "INCONCLUSIVO",
        "verificacoes": [{"id": "S01", "estado": "INCONCLUSIVO"}],
        "recursos_encerrados": None, "destino_aprovado": False,
        "custodia_autorizada": False, "operacao_autorizada": False,
    }


def entrada():
    return {
        "conteudo": json.dumps(documento()).encode(),
        "sha256_esperado": None,
        "contexto": {
            "referencia": "REF_SINTETICA_B", "finalidade": "OBSERVACAO_LIMITADA",
            "autorizacao_declarada": True, "operador_declarado": True,
            "escopo_declarado": True, "vigencia_declarada": True,
        },
        "eventos": [Evento(T.INICIO_DECLARADO)],
    }


class CasosAdversosTests(unittest.TestCase):
    def test_json_muito_profundo(self):
        d = entrada()
        d["conteudo"] = b"[" * 1500 + b"0" + b"]" * 1500
        r = executar_fluxo(d)
        self.assertIn(M.LIMITE_EXCEDIDO, r.motivos)
        self.assertFalse(r.valido_estruturalmente)

    def test_json_chave_duplicada_aninhada(self):
        d = entrada()
        d["conteudo"] = b'{"x":{"id":1,"id":2}}'
        self.assertIn(M.CHAVE_DUPLICADA, executar_fluxo(d).motivos)

    def test_constantes_nao_json(self):
        for constante in (b"NaN", b"Infinity", b"-Infinity"):
            with self.subTest(constante=constante):
                d = entrada()
                d["conteudo"] = b'{"x":' + constante + b"}"
                self.assertIn(M.VALOR_NAO_JSON, executar_fluxo(d).motivos)

    def test_utf8_invalido(self):
        d = entrada()
        d["conteudo"] = b"\xff"
        self.assertIn(M.CODIFICACAO_INVALIDA, executar_fluxo(d).motivos)

    def test_json_raiz_nao_objeto(self):
        d = entrada()
        d["conteudo"] = b"true"
        self.assertFalse(executar_fluxo(d).valido_estruturalmente)

    def test_colecao_excede_nos(self):
        d = entrada()
        d["conteudo"] = b"[" + b"0," * 299 + b"0]"
        self.assertIn(M.LIMITE_EXCEDIDO, executar_fluxo(d).motivos)

    def test_inteiro_extremo_nega_estrutura_sem_vazamento(self):
        d = entrada()
        d["conteudo"] = b'{"x":' + b"9" * 8000 + b"}"
        r = executar_fluxo(d)
        self.assertFalse(r.valido_estruturalmente)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
        self.assertNotIn("9" * 100, repr(r))

    def test_conteudo_tipo_python_incompativel(self):
        d = entrada()
        d["conteudo"] = ["PAYLOAD_SINTETICO_NAO_ECOAR"]
        r = executar_fluxo(d)
        self.assertIn(M.TIPO_ENTRADA_INVALIDO, r.motivos)
        self.assertNotIn("PAYLOAD_SINTETICO_NAO_ECOAR", repr(r))

    def test_subclasse_de_dict_nao_invoca_getitem_hostil(self):
        class DictSintetico(dict):
            def __getitem__(self, key):
                raise AssertionError("NAO_DEVE_SER_CHAMADO")
        r = executar_fluxo(DictSintetico(entrada()))
        self.assertIn(M.ENTRADA_FLUXO_INVALIDA, r.motivos)
        self.assertIsNone(r.recepcao)

    def test_chave_nao_string_em_contexto(self):
        d = entrada()
        d["contexto"] = {1: "CONTEXTO_SINTETICO_NAO_ECOAR"}
        r = executar_fluxo(d)
        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INVALIDA)
        self.assertNotIn("CONTEXTO_SINTETICO_NAO_ECOAR", repr(r))

    def test_hash_referencia_tipo_incompativel(self):
        d = entrada()
        d["sha256_esperado"] = ["HASH_SINTETICO_INVALIDO"]
        r = executar_fluxo(d)
        self.assertIn(M.REFERENCIA_ORIGEM_INVALIDA, r.motivos)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
        self.assertNotIn("HASH_SINTETICO_INVALIDO", repr(r))

    def test_referencia_contexto_desconhecida_nao_ecoada(self):
        d = entrada()
        d["contexto"]["referencia"] = "REFERENCIA_SINTETICA_FORA_LISTA"
        r = executar_fluxo(d)
        self.assertIn(M.CONTEXTO_INVALIDO, r.motivos)
        self.assertIsNone(r.registro.referencia)

    def test_duracao_negativa(self):
        d = entrada()
        d["eventos"] = [Evento(T.INICIO_DECLARADO, -1)]
        self.assertIn(M.DURACAO_INVALIDA, executar_fluxo(d).motivos)

    def test_duracoes_nao_finitas(self):
        for duracao in (float("nan"), float("inf"), float("-inf")):
            with self.subTest(duracao=duracao):
                d = entrada()
                d["eventos"] = [Evento(T.INICIO_DECLARADO, duracao)]
                r = executar_fluxo(d)
                self.assertIn(M.DURACAO_INVALIDA, r.motivos)
                self.assertFalse(r.encerramento_comprovado)

    def test_booleano_nao_e_duracao(self):
        d = entrada()
        d["eventos"] = [Evento(T.INICIO_DECLARADO, True)]
        self.assertIn(M.DURACAO_INVALIDA, executar_fluxo(d).motivos)

    def test_duracao_regressiva(self):
        d = entrada()
        d["eventos"] = [Evento(T.INICIO_DECLARADO, 5), Evento(T.SAIDA_FORNECIDA, 4)]
        r = executar_fluxo(d)
        self.assertIn(M.DURACAO_INVALIDA, r.motivos)
        self.assertEqual(r.eventos.quantidade_aplicados, 1)

    def test_evento_tipo_invalido(self):
        d = entrada()
        d["eventos"] = [{"tipo": "INICIO_DECLARADO"}]
        r = executar_fluxo(d)
        self.assertIn(M.EVENTO_INVALIDO, r.motivos)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)

    def test_ids_duplicados_em_verificacoes(self):
        d = entrada()
        p = documento()
        p["verificacoes"] *= 2
        d["conteudo"] = json.dumps(p).encode()
        self.assertFalse(executar_fluxo(d).valido_estruturalmente)

    def test_resultado_diverge_de_impedimento(self):
        d = entrada()
        p = documento()
        p["verificacoes"][0]["estado"] = "IMPEDIMENTO"
        d["conteudo"] = json.dumps(p).encode()
        self.assertFalse(executar_fluxo(d).valido_estruturalmente)

    def test_validade_extra_no_payload_recusada(self):
        d = entrada()
        p = documento()
        p["validade_estrutural"] = True
        d["conteudo"] = json.dumps(p).encode()
        r = executar_fluxo(d)
        self.assertFalse(r.valido_estruturalmente)
        self.assertFalse(r.registro.validade_estrutural)

    def test_montagem_de_registro_retorna_tipo_invalido(self):
        with patch("alternativa_python.fluxo.registro._projetar_integrado",
                   return_value={"payload": "SEGREDO_SINTETICO_DEV2"}):
            r = executar_fluxo(entrada())
        self.assertIsNone(r.registro)
        self.assertIn(M.REGISTRO_INDISPONIVEL, r.motivos)
        self.assertNotIn("SEGREDO_SINTETICO_DEV2", repr(r))

    def test_montagem_de_registro_adiciona_texto_arbitrario(self):
        original = executar_fluxo(entrada()).registro
        falso = replace(original, motivos=("ERRO_SINTETICO_NAO_ECOAR",))
        with patch("alternativa_python.fluxo.registro._projetar_integrado",
                   return_value=falso):
            r = executar_fluxo(entrada())
        self.assertIsNone(r.registro)
        self.assertNotIn("ERRO_SINTETICO_NAO_ECOAR", repr(r))

    def test_contexto_textual_excessivo_recusado(self):
        d = entrada()
        d["contexto"]["referencia"] = "X" * (MAX_TEXTO_CONTEXTO + 1)
        r = executar_fluxo(d)
        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INVALIDA)
        self.assertIsNone(r.registro.referencia)
        self.assertFalse(r.autorizacao_comprovada)

    def test_autorizacao_comprovada_forjada_no_contexto(self):
        d = entrada()
        d["contexto"]["autorizacao_comprovada"] = True
        r = executar_fluxo(d)
        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INVALIDA)
        self.assertFalse(r.autorizacao_comprovada)
        self.assertFalse(r.registro.autorizacao_comprovada)
