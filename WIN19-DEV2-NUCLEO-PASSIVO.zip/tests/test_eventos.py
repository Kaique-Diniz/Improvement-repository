import unittest
from alternativa_python.eventos import resumir
from alternativa_python.contratos import (
    MAX_EVENTOS, Evento, TipoEvento as T, FaseEvento, EstadoG10, Motivo,
)


class EventosTests(unittest.TestCase):
    def test_sem_eventos_nao_inventa_inicio(self):
        r = resumir([])
        self.assertEqual(r.fase, FaseEvento.INICIAL)
        self.assertFalse(r.termino_fornecido)
        self.assertEqual(r.quantidade_aplicados, 0)
        self.assertFalse(r.encerramento_comprovado)

    def test_traco_normal_somente_fornecido(self):
        r = resumir([Evento(T.INICIO_OBSERVADO_FORNECIDO, 0),
                     Evento(T.SAIDA_FORNECIDA, 2),
                     Evento(T.TERMINO_FORNECIDO, 3)])
        self.assertEqual(r.fase, FaseEvento.TERMINADO)
        self.assertEqual(r.quantidade_aplicados, 3)
        self.assertEqual(r.duracao_fornecida, 3)
        self.assertFalse(r.operacao_autorizada)

    def test_interrupcao_preservada(self):
        r = resumir([Evento(T.INICIO_DECLARADO), Evento(T.INTERRUPCAO_FORNECIDA)])
        self.assertEqual(r.fase, FaseEvento.INTERROMPIDO)
        self.assertIn(EstadoG10.EXECUCAO_INTERROMPIDA, r.estados)
        self.assertFalse(r.encerramento_comprovado)

    def test_termino_apos_interrupcao_nao_apaga_adverso(self):
        r = resumir([Evento(T.INICIO_DECLARADO), Evento(T.INTERRUPCAO_FORNECIDA),
                     Evento(T.TERMINO_FORNECIDO)])
        self.assertTrue(r.termino_fornecido)
        self.assertIn(EstadoG10.EXECUCAO_INTERROMPIDA, r.estados)

    def test_fechamento_declarado_nao_comprova(self):
        r = resumir([Evento(T.INICIO_DECLARADO), Evento(T.TERMINO_FORNECIDO),
                     Evento(T.FECHAMENTO_DECLARADO)])
        self.assertTrue(r.fechamento_declarado)
        self.assertFalse(r.encerramento_comprovado)
        self.assertIn(EstadoG10.ENCERRAMENTO_NAO_COMPROVADO, r.estados)

    def test_termino_sem_inicio_invalido(self):
        r = resumir([Evento(T.TERMINO_FORNECIDO)])
        self.assertIn(Motivo.TRANSICAO_INVALIDA, r.motivos)
        self.assertEqual(r.quantidade_aplicados, 0)
        self.assertFalse(r.termino_fornecido)

    def test_reinicio_apos_termino_invalido(self):
        r = resumir([Evento(T.INICIO_DECLARADO), Evento(T.TERMINO_FORNECIDO),
                     Evento(T.INICIO_DECLARADO)])
        self.assertEqual(r.fase, FaseEvento.TERMINADO)
        self.assertEqual(r.quantidade_aplicados, 2)
        self.assertIn(Motivo.TRANSICAO_INVALIDA, r.motivos)

    def test_duracao_negativa_recusada(self):
        r = resumir([Evento(T.INICIO_DECLARADO, -1)])
        self.assertIn(Motivo.DURACAO_INVALIDA, r.motivos)
        self.assertEqual(r.fase, FaseEvento.INICIAL)

    def test_duracao_nan_recusada(self):
        r = resumir([Evento(T.INICIO_DECLARADO, float("nan"))])
        self.assertIn(Motivo.DURACAO_INVALIDA, r.motivos)

    def test_duracao_decrescente_preserva_ultima_valida(self):
        r = resumir([Evento(T.INICIO_DECLARADO, 4), Evento(T.SAIDA_FORNECIDA, 3)])
        self.assertIn(Motivo.DURACAO_INVALIDA, r.motivos)
        self.assertEqual(r.duracao_fornecida, 4)
        self.assertEqual(r.quantidade_aplicados, 1)

    def test_limite_de_eventos(self):
        r = resumir([Evento(T.INICIO_DECLARADO)] * (MAX_EVENTOS + 1))
        self.assertIn(Motivo.LIMITE_EXCEDIDO, r.motivos)
        self.assertEqual(r.quantidade_aplicados, 0)

    def test_objeto_arbitrario_nao_ecoado(self):
        r = resumir(["EVENTO_PRIVADO_SINTETICO"])
        self.assertIn(Motivo.EVENTO_INVALIDO, r.motivos)
        self.assertNotIn("EVENTO_PRIVADO_SINTETICO", repr(r))

    def test_tipo_evento_string_nao_aceito_como_enum(self):
        r = resumir([Evento("INICIO_DECLARADO")])
        self.assertIn(Motivo.EVENTO_INVALIDO, r.motivos)

    def test_booleano_nao_e_duracao(self):
        r = resumir([Evento(T.INICIO_DECLARADO, True)])
        self.assertIn(Motivo.DURACAO_INVALIDA, r.motivos)

    def test_fechamento_antes_termino_recusado(self):
        r = resumir([Evento(T.INICIO_DECLARADO), Evento(T.FECHAMENTO_DECLARADO)])
        self.assertIn(Motivo.TRANSICAO_INVALIDA, r.motivos)

    def test_incerteza_posterior_preserva_adverso(self):
        r = resumir([Evento(T.INICIO_DECLARADO), Evento(T.TERMINO_FORNECIDO),
                     Evento(T.FECHAMENTO_DECLARADO), Evento(T.RECURSOS_INCERTOS)])
        self.assertFalse(r.fechamento_declarado)
        self.assertIn(EstadoG10.ENCERRAMENTO_NAO_COMPROVADO, r.estados)

    def test_parada_no_primeiro_erro_sem_aplicar_fim(self):
        r = resumir([Evento(T.SAIDA_FORNECIDA), Evento(T.TERMINO_FORNECIDO)])
        self.assertFalse(r.termino_fornecido)
        self.assertEqual(r.quantidade_aplicados, 0)
