import hashlib
import json
import unittest
from dataclasses import FrozenInstanceError, replace
from unittest.mock import patch
from alternativa_python.fluxo import executar_fluxo
from alternativa_python.contratos import (
    VERSAO, MAX_BYTES, MAX_EVENTOS, Evento, TipoEvento as T,
    EstadoG10 as G, EstadoContexto, Motivo as M, ResultadoFluxo,
)


def documento():
    return {
        "versao": VERSAO, "sintetico": True, "documento_real": False,
        "resultado": "INCONCLUSIVO",
        "verificacoes": [{"id": "S01", "estado": "OBSERVADO_SINTETICO"}],
        "recursos_encerrados": None, "destino_aprovado": False,
        "custodia_autorizada": False, "operacao_autorizada": False,
    }


def contexto():
    return {
        "referencia": "REF_SINTETICA_A", "finalidade": "OBSERVACAO_LIMITADA",
        "autorizacao_declarada": True, "operador_declarado": True,
        "escopo_declarado": True, "vigencia_declarada": True,
    }


def entrada():
    b = json.dumps(documento()).encode("utf-8")
    return {"conteudo": b, "sha256_esperado": hashlib.sha256(b).hexdigest(),
            "contexto": contexto(), "eventos": [Evento(T.INICIO_DECLARADO)]}


class FluxoIntegradoTests(unittest.TestCase):
    def test_fluxo_sintetico_valido_tipado(self):
        r = executar_fluxo(entrada())
        self.assertIs(type(r), ResultadoFluxo)
        self.assertTrue(r.valido_estruturalmente)
        self.assertTrue(r.registro_disponivel)
        self.assertIn(G.EVIDENCIA_RECEBIDA_VALIDAVEL, r.estados)
        self.assertFalse(r.origem_autenticada)

    def test_entrada_ausente_sem_objeto_de_sucesso(self):
        d = entrada()
        d["conteudo"] = None
        r = executar_fluxo(d)
        self.assertFalse(r.valido_estruturalmente)
        self.assertIn(G.EVIDENCIA_AUSENTE, r.estados)

    def test_json_incompativel(self):
        d = entrada()
        d["conteudo"] = b"{}"
        r = executar_fluxo(d)
        self.assertFalse(r.valido_estruturalmente)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)

    def test_json_incompleto(self):
        d = entrada()
        d["conteudo"] = b'{"versao":'
        r = executar_fluxo(d)
        self.assertIn(G.EVIDENCIA_INCOMPLETA, r.estados)
        self.assertFalse(r.registro.validade_estrutural)

    def test_hash_divergente_nao_apaga_estrutura_validada(self):
        d = entrada()
        d["sha256_esperado"] = "0" * 64
        r = executar_fluxo(d)
        self.assertTrue(r.valido_estruturalmente)
        self.assertIn(M.ORIGEM_DIVERGENTE, r.motivos)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
        self.assertFalse(r.origem_autenticada)

    def test_contexto_insuficiente(self):
        d = entrada()
        d["contexto"]["autorizacao_declarada"] = False
        r = executar_fluxo(d)
        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INSUFICIENTE)
        self.assertIn(M.CONTEXTO_INSUFICIENTE, r.motivos)
        self.assertFalse(r.autorizacao_comprovada)

    def test_contexto_completo_continua_nao_autenticado(self):
        r = executar_fluxo(entrada())
        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_COMPLETA)
        self.assertFalse(r.contexto.autorizacao_comprovada)
        self.assertIn(M.AUTORIZACAO_NAO_COMPROVADA, r.motivos)

    def test_evento_interrompido(self):
        d = entrada()
        d["eventos"].append(Evento(T.INTERRUPCAO_FORNECIDA))
        r = executar_fluxo(d)
        self.assertIn(G.EXECUCAO_INTERROMPIDA, r.estados)
        self.assertIn(G.EXECUCAO_INTERROMPIDA.value, r.registro.estados)

    def test_evento_fora_de_ordem(self):
        d = entrada()
        d["eventos"] = [Evento(T.TERMINO_FORNECIDO)]
        r = executar_fluxo(d)
        self.assertIn(M.TRANSICAO_INVALIDA, r.motivos)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
        self.assertTrue(r.valido_estruturalmente)  # Só o JSON foi validado.

    def test_recursos_incerto_apos_fechamento_declarado(self):
        d = entrada()
        d["eventos"] += [Evento(T.TERMINO_FORNECIDO),
                        Evento(T.FECHAMENTO_DECLARADO),
                        Evento(T.RECURSOS_INCERTOS)]
        r = executar_fluxo(d)
        self.assertFalse(r.encerramento_comprovado)
        self.assertFalse(r.eventos.fechamento_declarado)
        self.assertIn(G.ENCERRAMENTO_NAO_COMPROVADO, r.estados)

    def test_validade_forjada_no_envelope_rejeitada(self):
        d = entrada()
        d["validade_estrutural"] = True
        r = executar_fluxo(d)
        self.assertIsNone(r.recepcao)
        self.assertFalse(r.valido_estruturalmente)
        self.assertFalse(r.registro.validade_estrutural)
        self.assertIn(M.ENTRADA_FLUXO_INVALIDA, r.motivos)

    def test_autorizacao_operacional_forjada_no_envelope(self):
        d = entrada()
        d["operacao_autorizada"] = True
        r = executar_fluxo(d)
        self.assertFalse(r.operacao_autorizada)
        self.assertIn(M.ENTRADA_FLUXO_INVALIDA, r.motivos)

    def test_destino_aprovado_forjado_no_payload(self):
        d = entrada()
        p = documento()
        p["destino_aprovado"] = True
        d["conteudo"] = json.dumps(p).encode()
        r = executar_fluxo(d)
        self.assertFalse(r.valido_estruturalmente)
        self.assertFalse(r.registro.destino_aprovado)

    def test_dados_livres_nao_permitidos_nao_ecoam(self):
        d = entrada()
        d["payload_livre"] = "SEGREDO_SINTETICO_DEV2"
        r = executar_fluxo(d)
        self.assertIsNone(r.origem)
        self.assertNotIn("SEGREDO_SINTETICO_DEV2", repr(r))
        self.assertNotIn("SEGREDO_SINTETICO_DEV2", json.dumps(r.registro.como_dict()))

    def test_combinacao_preserva_todos_os_adversos(self):
        d = entrada()
        d["conteudo"] = b'{"versao":'
        d["sha256_esperado"] = "0" * 64
        d["eventos"].append(Evento(T.INTERRUPCAO_FORNECIDA))
        r = executar_fluxo(d)
        self.assertIn(G.EVIDENCIA_INCOMPLETA, r.estados)
        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
        self.assertIn(G.EXECUCAO_INTERROMPIDA, r.estados)
        self.assertIn(M.ORIGEM_DIVERGENTE, r.motivos)

    def test_payload_extra_sintetico_nao_aparece_no_registro(self):
        d = entrada()
        p = documento()
        p["dados"] = "NAO_ECOAR_DEV2_SINTETICO"
        d["conteudo"] = json.dumps(p).encode()
        r = executar_fluxo(d)
        self.assertNotIn("NAO_ECOAR_DEV2_SINTETICO", repr(r))
        self.assertNotIn("NAO_ECOAR_DEV2_SINTETICO",
                         json.dumps(r.registro.como_dict()))

    def test_limite_de_bytes(self):
        d = entrada()
        d["conteudo"] = b" " * (MAX_BYTES + 1)
        r = executar_fluxo(d)
        self.assertIn(M.LIMITE_EXCEDIDO, r.motivos)
        self.assertFalse(r.valido_estruturalmente)

    def test_limite_de_eventos(self):
        d = entrada()
        d["eventos"] = [Evento(T.INICIO_DECLARADO)] * (MAX_EVENTOS + 1)
        r = executar_fluxo(d)
        self.assertIn(M.LIMITE_EXCEDIDO, r.motivos)
        self.assertEqual(r.registro.quantidade_eventos, 0)

    def test_consistencia_entre_resultado_e_registro(self):
        d = entrada()
        d["eventos"].append(Evento(T.SAIDA_FORNECIDA))
        r = executar_fluxo(d)
        self.assertEqual(r.registro.estados, tuple(e.value for e in r.estados))
        self.assertEqual(r.registro.motivos, tuple(m.value for m in r.motivos))
        self.assertIs(r.registro.validade_estrutural, r.valido_estruturalmente)
        self.assertEqual(r.registro.quantidade_verificacoes,
                         r.recepcao.quantidade_verificacoes)
        self.assertEqual(r.registro.quantidade_eventos,
                         r.eventos.quantidade_aplicados)

    def test_caminho_integrado_nao_abre_arquivo_nem_imprime(self):
        d = entrada()
        with patch("builtins.open", side_effect=AssertionError("IO_NAO_PERMITIDO")) as op:
            with patch("builtins.print") as imprimir:
                r = executar_fluxo(d)
        self.assertTrue(r.registro_disponivel)
        op.assert_not_called()
        imprimir.assert_not_called()

    def test_fluxo_completo_com_todas_as_flags_false(self):
        d = entrada()
        d["eventos"] += [Evento(T.SAIDA_FORNECIDA, 1),
                        Evento(T.TERMINO_FORNECIDO, 2),
                        Evento(T.FECHAMENTO_DECLARADO, 2)]
        r = executar_fluxo(d)
        for nome in ("destino_aprovado", "custodia_autorizada", "operacao_autorizada",
                     "prontidao_operacional", "origem_autenticada",
                     "autorizacao_comprovada", "encerramento_comprovado"):
            with self.subTest(flag=nome):
                self.assertIs(getattr(r, nome), False)
                self.assertIs(r.registro.como_dict()[nome], False)

    def test_exportacao_mutavel_nao_modifica_resultado_imutavel(self):
        r = executar_fluxo(entrada())
        exportado = r.registro.como_dict()
        exportado["destino_aprovado"] = True
        exportado["estados"].append("DESTINO_APROVADO")
        self.assertFalse(r.registro.destino_aprovado)
        self.assertNotIn("DESTINO_APROVADO", r.registro.estados)
        with self.assertRaises(FrozenInstanceError):
            r.registro.validade_estrutural = False

    def test_envelope_invalido_nao_fabrica_resultados_de_componentes(self):
        r = executar_fluxo(None)
        self.assertIsNone(r.origem)
        self.assertIsNone(r.contexto)
        self.assertIsNone(r.recepcao)
        self.assertIsNone(r.eventos)
        self.assertFalse(r.registro.validade_estrutural)

    def test_falha_de_montagem_nao_ecoada_nem_vira_sucesso(self):
        d = entrada()
        d["eventos"].append(Evento(T.INTERRUPCAO_FORNECIDA))
        with patch("alternativa_python.fluxo.registro._projetar_integrado",
                   side_effect=ValueError("ERRO_SINTETICO_NAO_ECOAR")):
            r = executar_fluxo(d)
        self.assertFalse(r.registro_disponivel)
        self.assertIsNone(r.registro)
        self.assertIn(M.REGISTRO_INDISPONIVEL, r.motivos)
        self.assertIn(G.EXECUCAO_INTERROMPIDA, r.estados)
        self.assertNotIn("ERRO_SINTETICO_NAO_ECOAR", repr(r))

    def test_registro_que_forge_validade_e_recusado(self):
        correto = executar_fluxo(entrada()).registro
        adulterado = replace(correto, validade_estrutural=False)
        with patch("alternativa_python.fluxo.registro._projetar_integrado",
                   return_value=adulterado):
            r = executar_fluxo(entrada())
        self.assertTrue(r.valido_estruturalmente)  # Retorno real de D.
        self.assertIsNone(r.registro)  # Não aceita registro divergente.
        self.assertIn(M.REGISTRO_INDISPONIVEL, r.motivos)

    def test_bytes_contexto_e_eventos_do_chamador_preservados(self):
        d = entrada()
        b = bytes(d["conteudo"])
        ctx = dict(d["contexto"])
        evs = list(d["eventos"])
        executar_fluxo(d)
        self.assertEqual(d["conteudo"], b)
        self.assertEqual(d["contexto"], ctx)
        self.assertEqual(d["eventos"], evs)
