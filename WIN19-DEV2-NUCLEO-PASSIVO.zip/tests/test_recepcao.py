import json
import unittest
from alternativa_python.recepcao import receber
from alternativa_python.contexto import avaliar
from alternativa_python.contratos import MAX_BYTES, VERSAO, EstadoG10, Motivo


def payload():
    return {
        "versao": VERSAO, "sintetico": True, "documento_real": False,
        "resultado": "INCONCLUSIVO",
        "verificacoes": [{"id": "S01", "estado": "OBSERVADO_SINTETICO"}],
        "recursos_encerrados": None, "destino_aprovado": False,
        "custodia_autorizada": False, "operacao_autorizada": False,
    }


def codificar(obj):
    return json.dumps(obj, ensure_ascii=True).encode("utf-8")


class RecepcaoTests(unittest.TestCase):
    def test_estrutura_sintetica_valida_sem_verdade_material(self):
        r = receber(codificar(payload()))
        self.assertTrue(r.valido_estruturalmente)
        self.assertEqual(r.estados[0], EstadoG10.EVIDENCIA_RECEBIDA_VALIDAVEL)
        self.assertEqual(r.quantidade_verificacoes, 1)
        self.assertFalse(r.destino_aprovado)
        self.assertFalse(r.origem_autenticada)
        self.assertFalse(r.autorizacao_comprovada)
        self.assertIn(EstadoG10.RESULTADO_INCONCLUSIVO, r.estados)

    def test_ausencia_none(self):
        self.assertEqual(receber(None).estados[0], EstadoG10.EVIDENCIA_AUSENTE)

    def test_ausencia_bytes_vazios(self):
        self.assertEqual(receber(b"").estados[0], EstadoG10.EVIDENCIA_AUSENTE)

    def test_json_truncado(self):
        r = receber(b'{"versao":')
        self.assertEqual(r.estados[0], EstadoG10.EVIDENCIA_INCOMPLETA)
        self.assertIn(Motivo.JSON_INCOMPLETO, r.motivos)

    def test_json_corrompido(self):
        self.assertEqual(receber(b"{erro}").estados[0],
                         EstadoG10.EVIDENCIA_INCOMPATIVEL)

    def test_json_grande(self):
        r = receber(b" " * (MAX_BYTES + 1))
        self.assertIn(Motivo.LIMITE_EXCEDIDO, r.motivos)
        self.assertFalse(r.valido_estruturalmente)

    def test_chave_duplicada_raiz(self):
        r = receber(b'{"versao":"a","versao":"b"}')
        self.assertIn(Motivo.CHAVE_DUPLICADA, r.motivos)

    def test_chave_duplicada_aninhada(self):
        r = receber(b'{"x":{"y":1,"y":2}}')
        self.assertIn(Motivo.CHAVE_DUPLICADA, r.motivos)

    def test_nan_rejeitado(self):
        self.assertIn(Motivo.VALOR_NAO_JSON, receber(b'{"x":NaN}').motivos)

    def test_infinity_rejeitado(self):
        self.assertIn(Motivo.VALOR_NAO_JSON, receber(b'{"x":Infinity}').motivos)

    def test_overflow_float_rejeitado(self):
        self.assertIn(Motivo.VALOR_NAO_JSON, receber(b'{"x":1e999}').motivos)

    def test_campo_inesperado(self):
        p = payload()
        p["host"] = "HOST_SINTETICO_NAO_ECOAR"
        r = receber(codificar(p))
        self.assertIn(Motivo.ESTRUTURA_INCOMPATIVEL, r.motivos)
        self.assertNotIn("HOST_SINTETICO_NAO_ECOAR", repr(r))

    def test_campo_obrigatorio_ausente(self):
        p = payload()
        del p["destino_aprovado"]
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_inteiro_nao_substitui_booleano(self):
        p = payload()
        p["sintetico"] = 1
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_aprovacao_destino_true_rejeitada(self):
        p = payload()
        p["destino_aprovado"] = True
        r = receber(codificar(p))
        self.assertEqual(r.estados[0], EstadoG10.EVIDENCIA_INCOMPATIVEL)
        self.assertFalse(r.destino_aprovado)

    def test_documento_real_recusado(self):
        p = payload()
        p["documento_real"] = True
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_utf8_invalido(self):
        self.assertIn(Motivo.CODIFICACAO_INVALIDA, receber(b"\xff").motivos)

    def test_bom_recusado(self):
        self.assertIn(Motivo.CODIFICACAO_INVALIDA,
                      receber(b"\xef\xbb\xbf" + codificar(payload())).motivos)

    def test_json_adicional_nao_recortado(self):
        self.assertEqual(receber(codificar(payload()) + b"{}").estados[0],
                         EstadoG10.EVIDENCIA_INCOMPATIVEL)

    def test_estado_destino_aprovado_nao_existe_no_contrato(self):
        p = payload()
        p["verificacoes"][0]["estado"] = "DESTINO_APROVADO"
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_ids_verificacao_duplicados(self):
        p = payload()
        p["verificacoes"] *= 2
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_cardinalidade_excessiva(self):
        p = payload()
        p["verificacoes"] = [{"id": f"S{i:02d}", "estado": "INCONCLUSIVO"}
                            for i in range(1, 18)]
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_profundidade_excessiva(self):
        self.assertIn(Motivo.LIMITE_EXCEDIDO,
                      receber(b"[" * 20 + b"0" + b"]" * 20).motivos)

    def test_quantidade_nos_excessiva(self):
        self.assertIn(Motivo.LIMITE_EXCEDIDO,
                      receber(b"[" + b"0," * 299 + b"0]").motivos)

    def test_recursao_parser_contida(self):
        self.assertIn(Motivo.LIMITE_EXCEDIDO,
                      receber(b"[" * 1500 + b"0" + b"]" * 1500).motivos)

    def test_identidade_divergente_preserva_estrutura_sem_atribuicao(self):
        r = receber(codificar(payload()), sha256_esperado="0" * 64)
        self.assertTrue(r.valido_estruturalmente)
        self.assertEqual(r.estados[0], EstadoG10.EVIDENCIA_INCOMPATIVEL)
        self.assertIn(Motivo.ORIGEM_DIVERGENTE, r.motivos)

    def test_referencia_hash_invalida(self):
        r = receber(codificar(payload()), sha256_esperado="NAO_E_HASH")
        self.assertIn(Motivo.REFERENCIA_ORIGEM_INVALIDA, r.motivos)

    def test_contexto_sem_autorizacao_comprovada(self):
        r = receber(codificar(payload()), contexto=avaliar(None))
        self.assertTrue(r.valido_estruturalmente)
        self.assertFalse(r.autorizacao_comprovada)
        self.assertIn(Motivo.CONTEXTO_INSUFICIENTE, r.motivos)

    def test_impedimento_coerente_e_validavel_como_registro_adverso(self):
        p = payload()
        p["resultado"] = "IMPEDIMENTO"
        p["verificacoes"][0]["estado"] = "IMPEDIMENTO"
        r = receber(codificar(p))
        self.assertTrue(r.valido_estruturalmente)
        self.assertIn(Motivo.IMPEDIMENTO_DECLARADO, r.motivos)
        self.assertFalse(r.operacao_autorizada)

    def test_impedimento_incoerente_rejeitado(self):
        p = payload()
        p["verificacoes"][0]["estado"] = "IMPEDIMENTO"
        self.assertFalse(receber(codificar(p)).valido_estruturalmente)

    def test_entrada_texto_em_vez_de_bytes(self):
        self.assertIn(Motivo.TIPO_ENTRADA_INVALIDO, receber("{}").motivos)

    def test_fechamento_true_declarado_nao_comprova_recurso(self):
        p = payload()
        p["recursos_encerrados"] = True
        r = receber(codificar(p))
        self.assertTrue(r.valido_estruturalmente)
        self.assertFalse(r.encerramento_comprovado)
        self.assertIn(EstadoG10.ENCERRAMENTO_NAO_COMPROVADO, r.estados)

    def test_payload_preservado_integralmente(self):
        b = codificar(payload())
        antes = bytes(b)
        receber(b)
        self.assertEqual(b, antes)
