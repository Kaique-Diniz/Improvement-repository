# WIN19 DEV-2 — integração passiva implementada e testada

27/11/2026 — America/Sao_Paulo.
DEV2=IMPLEMENTADO_AGUARDANDO_AUDITORIA.
Não é homologação operacional, Windows, DACL ou liberação de observação/custódia.

## 1. Resultado concreto

Implementada executar_fluxo em alternativa_python/fluxo.py: A/B/D/E/F coordenados
apenas em memória, envelope com quatro campos exatos (conteudo, sha256_esperado,
contexto, eventos). ResultadoFluxo tipado, componentes gerados internamente e
RegistroIntegrado imutável. Nenhuma validade/autoridade livre aceita na entrada.
Metadados declarados, estrutura validada e falta de prova factual são separados.

Estados adversos combinados sem perda, inclusive hash divergente com JSON
incompleto e evento interrompido. A validade do resultado e do registro consulta
o retorno efetivo de D, não campo do chamador. Registro com tipo/contagem/estado/
motivo/referência/validade incompatíveis é recusado. Erro comum na montagem gera
registro=None, REGISTRO_INDISPONIVEL e EVIDENCIA_INCOMPATIVEL, sem eco de exceção.

Resultado final: 129 PASS, 0 FAIL, 0 ERROR, 0 SKIP. Desse total, 79 testes são
os originais intactos e 50 são novos (26 integração e 24 adversariais).
São métodos unittest; subcasos não são somados como testes independentes.
Nenhum código alterado após a última execução completa.

## 2. Verificação da base e do que já existia na retomada

Antes de desenvolver: ZIP DEV-1 de 27.962 bytes com hash
472c059824aa42af6847de3234d4fef546078a8015707f927905d97ee48cc4cc
e manifesto 416c6c3ac0708921f7931943cd760a36f70f39d0996597b2d076aad81f2416dd
autenticados. Quatorze entradas/CRC e 13 tamanhos/hashes correspondentes; seis
módulos/cinco tests, sem extras/links/travessia. Cópia byte a byte para raiz nova
/workspace/work/WIN19-DEV2-NUCLEO-PASSIVO. DEV-1 original e ZIP nunca editados.

Na retomada solicitada pelo usuário, foi conferido no disco: 15 arquivos copiados/
adicionados até então, fluxo.py presente, contratos/registro já modificados,
cinco testes antigos intactos, sem os dois testes novos ainda. Isso confirmou
trabalho efetivamente salvo, sem presumir conclusão de etapas faltantes.
A primeira regressão registrada antes da retomada passou 79 testes. Após a
retomada, reforçado contexto e repetida regressão 79 com saída integral abaixo;
depois escritos os dois novos arquivos/LEIA-ME e executada suíte completa 129.
Repetições não aumentam o número de casos únicos.

Python 3.12.14 observado, raiz nova e ancestrais regulares sem links/marcadores
Git, fora de checkout/candidatas/custódia/sincronização indicada. Nenhum Git
executado. Isolamento e ausência de operações são relato/conferência do executor
no Codex, não prova forense do Windows ou atestado de todo o host.

## 3. Arquivos modificados/adicionados

Modificados somente na cópia: contexto.py, contratos.py, registro.py e LEIA-ME.md.
Origem.py, recepcao.py e eventos.py idênticos; as cinco fontes de teste DEV-1,
RELATORIO_DEV1.md e MANIFESTO_SHA256_DEV1 também idênticos.
Novos: fluxo.py, tests/test_fluxo_integrado_dev2.py, tests/test_casos_adversos_dev2.py,
RELATORIO_DEV2.md, DIFERENCAS_DEV1_DEV2.md e MANIFESTO_SHA256_DEV2.
Total: 20 arquivos, sete módulos, sete arquivos de tests; sem caches/temporários/
configuração/serviço/runner/pacote instalável.

DIFERENCAS_DEV1_DEV2.md contém tabela de hashes de todos os originais e o diff
integral dos quatro arquivos alterados e três adições de código/testes.
O manifesto DEV-1 copiado é evidência histórica, não verificador da árvore DEV-2:
os módulos modificados naturalmente diferem de seus hashes antigos.
Usar MANIFESTO_SHA256_DEV2 para os 19 outros arquivos, inclusive a cópia histórica
do manifesto antigo. Não há autorreferência nem modificação desse manifesto antigo.

## 4. Mudanças e problemas de integração tratados

- A chamada manual podia transportar validade declarada ao sanitizador legada.
  Agora o caminho integrado só deriva essa validade da execução de D e verifica
  o registro correspondente; campos de injeção no envelope são recusados.
  Isso não torna o sanitizador direto um autenticador universal.
- Dados adversos antes combinados manualmente são unidos em tuplas fechadas sem
  perder incompatibilidade/incompletude/interrupção e motivos de origem/contexto.
- A montagem não é considerada bem-sucedida só por retornar objeto. Projeção
  incompatível/falha deixa registro ausente e motivo seguro, sem falso sucesso.
- Registro integrado congelado evita que mutação de uma cópia exportada altere
  a evidência tipada produzida pelo fluxo; não é criptografia ou sandbox.
- Contexto: guarda conservadora de 32 caracteres antes de confronto das duas
  strings declarativas. Referências/finalidade válidas e semântica de autoridade
  não mudam; tratamento preventivo de texto excessivo, sem alegar ataque real.

API/semântica DEV-1 preservadas e 79 testes não editados. Dois motivos e tipos
novos são aditivos. Sete estados G10 e schema sintético original permanecem.
Limites 16 KiB/256 nós/profundidade 12/16 verificações/32 eventos são preservados;
duração fornecida não é timeout. Nova versão de registro integrado é explícita.
Nenhum defeito real de Windows, C, isolamento ou DACL foi diagnosticado/corrigido.

## 5. Execuções reais e resultados

Comando em ambas as execuções documentadas integralmente a seguir, na raiz DEV-2:
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 python -B -m unittest discover -s tests -p 'test_*.py' -v

Ambiente: Linux Codex, Python 3.12.14, biblioteca padrão/unittest.
Sem instalação, processos auxiliares, rede/serviços ou Git.
Contagem de tempo é do harness unittest, não relógio/prova de execução no núcleo.

| Rodada | Originais | Novos | Total | PASS | FAIL | ERROR | SKIP | Exit | Duração unittest |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Regressão na retomada, antes dos novos tests | 79 | 0 | 79 | 79 | 0 | 0 | 0 | 0 | 0.004s |
| Completa final | 79 | 50 | 129 | 129 | 0 | 0 | 0 | 0 | 0.022s |

### Saída integral da regressão da retomada

```text
test_booleano_nao_e_duracao (test_eventos.EventosTests.test_booleano_nao_e_duracao) ... ok
test_duracao_decrescente_preserva_ultima_valida (test_eventos.EventosTests.test_duracao_decrescente_preserva_ultima_valida) ... ok
test_duracao_nan_recusada (test_eventos.EventosTests.test_duracao_nan_recusada) ... ok
test_duracao_negativa_recusada (test_eventos.EventosTests.test_duracao_negativa_recusada) ... ok
test_fechamento_antes_termino_recusado (test_eventos.EventosTests.test_fechamento_antes_termino_recusado) ... ok
test_fechamento_declarado_nao_comprova (test_eventos.EventosTests.test_fechamento_declarado_nao_comprova) ... ok
test_incerteza_posterior_preserva_adverso (test_eventos.EventosTests.test_incerteza_posterior_preserva_adverso) ... ok
test_interrupcao_preservada (test_eventos.EventosTests.test_interrupcao_preservada) ... ok
test_limite_de_eventos (test_eventos.EventosTests.test_limite_de_eventos) ... ok
test_objeto_arbitrario_nao_ecoado (test_eventos.EventosTests.test_objeto_arbitrario_nao_ecoado) ... ok
test_parada_no_primeiro_erro_sem_aplicar_fim (test_eventos.EventosTests.test_parada_no_primeiro_erro_sem_aplicar_fim) ... ok
test_reinicio_apos_termino_invalido (test_eventos.EventosTests.test_reinicio_apos_termino_invalido) ... ok
test_sem_eventos_nao_inventa_inicio (test_eventos.EventosTests.test_sem_eventos_nao_inventa_inicio) ... ok
test_termino_apos_interrupcao_nao_apaga_adverso (test_eventos.EventosTests.test_termino_apos_interrupcao_nao_apaga_adverso) ... ok
test_termino_sem_inicio_invalido (test_eventos.EventosTests.test_termino_sem_inicio_invalido) ... ok
test_tipo_evento_string_nao_aceito_como_enum (test_eventos.EventosTests.test_tipo_evento_string_nao_aceito_como_enum) ... ok
test_traco_normal_somente_fornecido (test_eventos.EventosTests.test_traco_normal_somente_fornecido) ... ok
test_fluxo_adverso_preserva_divergencia_e_interrupcao (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_fluxo_adverso_preserva_divergencia_e_interrupcao) ... ok
test_fluxo_integral_em_memoria_nao_autoriza (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_fluxo_integral_em_memoria_nao_autoriza) ... ok
test_sete_estados_sem_aprovacao (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_sete_estados_sem_aprovacao) ... ok
test_constructor_nao_aceita_aprovacao (test_origem_contexto.OrigemContextoTests.test_constructor_nao_aceita_aprovacao) ... ok
test_contexto_ausente (test_origem_contexto.OrigemContextoTests.test_contexto_ausente) ... ok
test_contexto_booleano_nao_e_inteiro (test_origem_contexto.OrigemContextoTests.test_contexto_booleano_nao_e_inteiro) ... ok
test_contexto_campo_extra_nao_ecoado (test_origem_contexto.OrigemContextoTests.test_contexto_campo_extra_nao_ecoado) ... ok
test_contexto_referencia_fora_lista (test_origem_contexto.OrigemContextoTests.test_contexto_referencia_fora_lista) ... ok
test_declaracao_completa_nunca_autoriza (test_origem_contexto.OrigemContextoTests.test_declaracao_completa_nunca_autoriza) ... ok
test_declaracao_negativa_insuficiente (test_origem_contexto.OrigemContextoTests.test_declaracao_negativa_insuficiente) ... ok
test_hash_conhecido_sem_autenticidade (test_origem_contexto.OrigemContextoTests.test_hash_conhecido_sem_autenticidade) ... ok
test_hash_divergente (test_origem_contexto.OrigemContextoTests.test_hash_divergente) ... ok
test_hash_excesso_tamanho (test_origem_contexto.OrigemContextoTests.test_hash_excesso_tamanho) ... ok
test_hash_maiusculo_recusado (test_origem_contexto.OrigemContextoTests.test_hash_maiusculo_recusado) ... ok
test_hash_tipo_estrito (test_origem_contexto.OrigemContextoTests.test_hash_tipo_estrito) ... ok
test_referencia_invalida_nao_ecoada (test_origem_contexto.OrigemContextoTests.test_referencia_invalida_nao_ecoada) ... ok
test_sem_referencia (test_origem_contexto.OrigemContextoTests.test_sem_referencia) ... ok
test_aprovacao_destino_true_rejeitada (test_recepcao.RecepcaoTests.test_aprovacao_destino_true_rejeitada) ... ok
test_ausencia_bytes_vazios (test_recepcao.RecepcaoTests.test_ausencia_bytes_vazios) ... ok
test_ausencia_none (test_recepcao.RecepcaoTests.test_ausencia_none) ... ok
test_bom_recusado (test_recepcao.RecepcaoTests.test_bom_recusado) ... ok
test_campo_inesperado (test_recepcao.RecepcaoTests.test_campo_inesperado) ... ok
test_campo_obrigatorio_ausente (test_recepcao.RecepcaoTests.test_campo_obrigatorio_ausente) ... ok
test_cardinalidade_excessiva (test_recepcao.RecepcaoTests.test_cardinalidade_excessiva) ... ok
test_chave_duplicada_aninhada (test_recepcao.RecepcaoTests.test_chave_duplicada_aninhada) ... ok
test_chave_duplicada_raiz (test_recepcao.RecepcaoTests.test_chave_duplicada_raiz) ... ok
test_contexto_sem_autorizacao_comprovada (test_recepcao.RecepcaoTests.test_contexto_sem_autorizacao_comprovada) ... ok
test_documento_real_recusado (test_recepcao.RecepcaoTests.test_documento_real_recusado) ... ok
test_entrada_texto_em_vez_de_bytes (test_recepcao.RecepcaoTests.test_entrada_texto_em_vez_de_bytes) ... ok
test_estado_destino_aprovado_nao_existe_no_contrato (test_recepcao.RecepcaoTests.test_estado_destino_aprovado_nao_existe_no_contrato) ... ok
test_estrutura_sintetica_valida_sem_verdade_material (test_recepcao.RecepcaoTests.test_estrutura_sintetica_valida_sem_verdade_material) ... ok
test_fechamento_true_declarado_nao_comprova_recurso (test_recepcao.RecepcaoTests.test_fechamento_true_declarado_nao_comprova_recurso) ... ok
test_identidade_divergente_preserva_estrutura_sem_atribuicao (test_recepcao.RecepcaoTests.test_identidade_divergente_preserva_estrutura_sem_atribuicao) ... ok
test_ids_verificacao_duplicados (test_recepcao.RecepcaoTests.test_ids_verificacao_duplicados) ... ok
test_impedimento_coerente_e_validavel_como_registro_adverso (test_recepcao.RecepcaoTests.test_impedimento_coerente_e_validavel_como_registro_adverso) ... ok
test_impedimento_incoerente_rejeitado (test_recepcao.RecepcaoTests.test_impedimento_incoerente_rejeitado) ... ok
test_infinity_rejeitado (test_recepcao.RecepcaoTests.test_infinity_rejeitado) ... ok
test_inteiro_nao_substitui_booleano (test_recepcao.RecepcaoTests.test_inteiro_nao_substitui_booleano) ... ok
test_json_adicional_nao_recortado (test_recepcao.RecepcaoTests.test_json_adicional_nao_recortado) ... ok
test_json_corrompido (test_recepcao.RecepcaoTests.test_json_corrompido) ... ok
test_json_grande (test_recepcao.RecepcaoTests.test_json_grande) ... ok
test_json_truncado (test_recepcao.RecepcaoTests.test_json_truncado) ... ok
test_nan_rejeitado (test_recepcao.RecepcaoTests.test_nan_rejeitado) ... ok
test_overflow_float_rejeitado (test_recepcao.RecepcaoTests.test_overflow_float_rejeitado) ... ok
test_payload_preservado_integralmente (test_recepcao.RecepcaoTests.test_payload_preservado_integralmente) ... ok
test_profundidade_excessiva (test_recepcao.RecepcaoTests.test_profundidade_excessiva) ... ok
test_quantidade_nos_excessiva (test_recepcao.RecepcaoTests.test_quantidade_nos_excessiva) ... ok
test_recursao_parser_contida (test_recepcao.RecepcaoTests.test_recursao_parser_contida) ... ok
test_referencia_hash_invalida (test_recepcao.RecepcaoTests.test_referencia_hash_invalida) ... ok
test_utf8_invalido (test_recepcao.RecepcaoTests.test_utf8_invalido) ... ok
test_adversos_validos_preservados (test_registro.RegistroTests.test_adversos_validos_preservados) ... ok
test_booleano_nao_e_contagem (test_registro.RegistroTests.test_booleano_nao_e_contagem) ... ok
test_chave_nao_string (test_registro.RegistroTests.test_chave_nao_string) ... ok
test_chaves_e_payload_privados_sinteticos_descartados (test_registro.RegistroTests.test_chaves_e_payload_privados_sinteticos_descartados) ... ok
test_destino_aprovado_nao_e_estado (test_registro.RegistroTests.test_destino_aprovado_nao_e_estado) ... ok
test_entrada_nao_mutada (test_registro.RegistroTests.test_entrada_nao_mutada) ... ok
test_none_resulta_conservador (test_registro.RegistroTests.test_none_resulta_conservador) ... ok
test_referencia_arbitraria_nao_ecoada (test_registro.RegistroTests.test_referencia_arbitraria_nao_ecoada) ... ok
test_referencia_fechada_permitida (test_registro.RegistroTests.test_referencia_fechada_permitida) ... ok
test_registro_grande (test_registro.RegistroTests.test_registro_grande) ... ok
test_tentativa_de_aprovacao_preserva_motivo_e_false (test_registro.RegistroTests.test_tentativa_de_aprovacao_preserva_motivo_e_false) ... ok
test_valor_arbitrario_em_campo_permitido_nao_ecoado (test_registro.RegistroTests.test_valor_arbitrario_em_campo_permitido_nao_ecoado) ... ok

----------------------------------------------------------------------
Ran 79 tests in 0.004s

OK
```

### Saída integral da execução completa final

```text
test_autorizacao_comprovada_forjada_no_contexto (test_casos_adversos_dev2.CasosAdversosTests.test_autorizacao_comprovada_forjada_no_contexto) ... ok
test_booleano_nao_e_duracao (test_casos_adversos_dev2.CasosAdversosTests.test_booleano_nao_e_duracao) ... ok
test_chave_nao_string_em_contexto (test_casos_adversos_dev2.CasosAdversosTests.test_chave_nao_string_em_contexto) ... ok
test_colecao_excede_nos (test_casos_adversos_dev2.CasosAdversosTests.test_colecao_excede_nos) ... ok
test_constantes_nao_json (test_casos_adversos_dev2.CasosAdversosTests.test_constantes_nao_json) ... ok
test_conteudo_tipo_python_incompativel (test_casos_adversos_dev2.CasosAdversosTests.test_conteudo_tipo_python_incompativel) ... ok
test_contexto_textual_excessivo_recusado (test_casos_adversos_dev2.CasosAdversosTests.test_contexto_textual_excessivo_recusado) ... ok
test_duracao_negativa (test_casos_adversos_dev2.CasosAdversosTests.test_duracao_negativa) ... ok
test_duracao_regressiva (test_casos_adversos_dev2.CasosAdversosTests.test_duracao_regressiva) ... ok
test_duracoes_nao_finitas (test_casos_adversos_dev2.CasosAdversosTests.test_duracoes_nao_finitas) ... ok
test_evento_tipo_invalido (test_casos_adversos_dev2.CasosAdversosTests.test_evento_tipo_invalido) ... ok
test_hash_referencia_tipo_incompativel (test_casos_adversos_dev2.CasosAdversosTests.test_hash_referencia_tipo_incompativel) ... ok
test_ids_duplicados_em_verificacoes (test_casos_adversos_dev2.CasosAdversosTests.test_ids_duplicados_em_verificacoes) ... ok
test_inteiro_extremo_nega_estrutura_sem_vazamento (test_casos_adversos_dev2.CasosAdversosTests.test_inteiro_extremo_nega_estrutura_sem_vazamento) ... ok
test_json_chave_duplicada_aninhada (test_casos_adversos_dev2.CasosAdversosTests.test_json_chave_duplicada_aninhada) ... ok
test_json_muito_profundo (test_casos_adversos_dev2.CasosAdversosTests.test_json_muito_profundo) ... ok
test_json_raiz_nao_objeto (test_casos_adversos_dev2.CasosAdversosTests.test_json_raiz_nao_objeto) ... ok
test_montagem_de_registro_adiciona_texto_arbitrario (test_casos_adversos_dev2.CasosAdversosTests.test_montagem_de_registro_adiciona_texto_arbitrario) ... ok
test_montagem_de_registro_retorna_tipo_invalido (test_casos_adversos_dev2.CasosAdversosTests.test_montagem_de_registro_retorna_tipo_invalido) ... ok
test_referencia_contexto_desconhecida_nao_ecoada (test_casos_adversos_dev2.CasosAdversosTests.test_referencia_contexto_desconhecida_nao_ecoada) ... ok
test_resultado_diverge_de_impedimento (test_casos_adversos_dev2.CasosAdversosTests.test_resultado_diverge_de_impedimento) ... ok
test_subclasse_de_dict_nao_invoca_getitem_hostil (test_casos_adversos_dev2.CasosAdversosTests.test_subclasse_de_dict_nao_invoca_getitem_hostil) ... ok
test_utf8_invalido (test_casos_adversos_dev2.CasosAdversosTests.test_utf8_invalido) ... ok
test_validade_extra_no_payload_recusada (test_casos_adversos_dev2.CasosAdversosTests.test_validade_extra_no_payload_recusada) ... ok
test_booleano_nao_e_duracao (test_eventos.EventosTests.test_booleano_nao_e_duracao) ... ok
test_duracao_decrescente_preserva_ultima_valida (test_eventos.EventosTests.test_duracao_decrescente_preserva_ultima_valida) ... ok
test_duracao_nan_recusada (test_eventos.EventosTests.test_duracao_nan_recusada) ... ok
test_duracao_negativa_recusada (test_eventos.EventosTests.test_duracao_negativa_recusada) ... ok
test_fechamento_antes_termino_recusado (test_eventos.EventosTests.test_fechamento_antes_termino_recusado) ... ok
test_fechamento_declarado_nao_comprova (test_eventos.EventosTests.test_fechamento_declarado_nao_comprova) ... ok
test_incerteza_posterior_preserva_adverso (test_eventos.EventosTests.test_incerteza_posterior_preserva_adverso) ... ok
test_interrupcao_preservada (test_eventos.EventosTests.test_interrupcao_preservada) ... ok
test_limite_de_eventos (test_eventos.EventosTests.test_limite_de_eventos) ... ok
test_objeto_arbitrario_nao_ecoado (test_eventos.EventosTests.test_objeto_arbitrario_nao_ecoado) ... ok
test_parada_no_primeiro_erro_sem_aplicar_fim (test_eventos.EventosTests.test_parada_no_primeiro_erro_sem_aplicar_fim) ... ok
test_reinicio_apos_termino_invalido (test_eventos.EventosTests.test_reinicio_apos_termino_invalido) ... ok
test_sem_eventos_nao_inventa_inicio (test_eventos.EventosTests.test_sem_eventos_nao_inventa_inicio) ... ok
test_termino_apos_interrupcao_nao_apaga_adverso (test_eventos.EventosTests.test_termino_apos_interrupcao_nao_apaga_adverso) ... ok
test_termino_sem_inicio_invalido (test_eventos.EventosTests.test_termino_sem_inicio_invalido) ... ok
test_tipo_evento_string_nao_aceito_como_enum (test_eventos.EventosTests.test_tipo_evento_string_nao_aceito_como_enum) ... ok
test_traco_normal_somente_fornecido (test_eventos.EventosTests.test_traco_normal_somente_fornecido) ... ok
test_autorizacao_operacional_forjada_no_envelope (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_autorizacao_operacional_forjada_no_envelope) ... ok
test_bytes_contexto_e_eventos_do_chamador_preservados (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_bytes_contexto_e_eventos_do_chamador_preservados) ... ok
test_caminho_integrado_nao_abre_arquivo_nem_imprime (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_caminho_integrado_nao_abre_arquivo_nem_imprime) ... ok
test_combinacao_preserva_todos_os_adversos (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_combinacao_preserva_todos_os_adversos) ... ok
test_consistencia_entre_resultado_e_registro (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_consistencia_entre_resultado_e_registro) ... ok
test_contexto_completo_continua_nao_autenticado (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_contexto_completo_continua_nao_autenticado) ... ok
test_contexto_insuficiente (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_contexto_insuficiente) ... ok
test_dados_livres_nao_permitidos_nao_ecoam (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_dados_livres_nao_permitidos_nao_ecoam) ... ok
test_destino_aprovado_forjado_no_payload (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_destino_aprovado_forjado_no_payload) ... ok
test_entrada_ausente_sem_objeto_de_sucesso (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_entrada_ausente_sem_objeto_de_sucesso) ... ok
test_envelope_invalido_nao_fabrica_resultados_de_componentes (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_envelope_invalido_nao_fabrica_resultados_de_componentes) ... ok
test_evento_fora_de_ordem (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_evento_fora_de_ordem) ... ok
test_evento_interrompido (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_evento_interrompido) ... ok
test_exportacao_mutavel_nao_modifica_resultado_imutavel (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_exportacao_mutavel_nao_modifica_resultado_imutavel) ... ok
test_falha_de_montagem_nao_ecoada_nem_vira_sucesso (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_falha_de_montagem_nao_ecoada_nem_vira_sucesso) ... ok
test_fluxo_completo_com_todas_as_flags_false (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_fluxo_completo_com_todas_as_flags_false) ... ok
test_fluxo_sintetico_valido_tipado (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_fluxo_sintetico_valido_tipado) ... ok
test_hash_divergente_nao_apaga_estrutura_validada (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_hash_divergente_nao_apaga_estrutura_validada) ... ok
test_json_incompativel (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_json_incompativel) ... ok
test_json_incompleto (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_json_incompleto) ... ok
test_limite_de_bytes (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_limite_de_bytes) ... ok
test_limite_de_eventos (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_limite_de_eventos) ... ok
test_payload_extra_sintetico_nao_aparece_no_registro (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_payload_extra_sintetico_nao_aparece_no_registro) ... ok
test_recursos_incerto_apos_fechamento_declarado (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_recursos_incerto_apos_fechamento_declarado) ... ok
test_registro_que_forge_validade_e_recusado (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_registro_que_forge_validade_e_recusado) ... ok
test_validade_forjada_no_envelope_rejeitada (test_fluxo_integrado_dev2.FluxoIntegradoTests.test_validade_forjada_no_envelope_rejeitada) ... ok
test_fluxo_adverso_preserva_divergencia_e_interrupcao (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_fluxo_adverso_preserva_divergencia_e_interrupcao) ... ok
test_fluxo_integral_em_memoria_nao_autoriza (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_fluxo_integral_em_memoria_nao_autoriza) ... ok
test_sete_estados_sem_aprovacao (test_fluxo_passivo_sintetico.FluxoPassivoTests.test_sete_estados_sem_aprovacao) ... ok
test_constructor_nao_aceita_aprovacao (test_origem_contexto.OrigemContextoTests.test_constructor_nao_aceita_aprovacao) ... ok
test_contexto_ausente (test_origem_contexto.OrigemContextoTests.test_contexto_ausente) ... ok
test_contexto_booleano_nao_e_inteiro (test_origem_contexto.OrigemContextoTests.test_contexto_booleano_nao_e_inteiro) ... ok
test_contexto_campo_extra_nao_ecoado (test_origem_contexto.OrigemContextoTests.test_contexto_campo_extra_nao_ecoado) ... ok
test_contexto_referencia_fora_lista (test_origem_contexto.OrigemContextoTests.test_contexto_referencia_fora_lista) ... ok
test_declaracao_completa_nunca_autoriza (test_origem_contexto.OrigemContextoTests.test_declaracao_completa_nunca_autoriza) ... ok
test_declaracao_negativa_insuficiente (test_origem_contexto.OrigemContextoTests.test_declaracao_negativa_insuficiente) ... ok
test_hash_conhecido_sem_autenticidade (test_origem_contexto.OrigemContextoTests.test_hash_conhecido_sem_autenticidade) ... ok
test_hash_divergente (test_origem_contexto.OrigemContextoTests.test_hash_divergente) ... ok
test_hash_excesso_tamanho (test_origem_contexto.OrigemContextoTests.test_hash_excesso_tamanho) ... ok
test_hash_maiusculo_recusado (test_origem_contexto.OrigemContextoTests.test_hash_maiusculo_recusado) ... ok
test_hash_tipo_estrito (test_origem_contexto.OrigemContextoTests.test_hash_tipo_estrito) ... ok
test_referencia_invalida_nao_ecoada (test_origem_contexto.OrigemContextoTests.test_referencia_invalida_nao_ecoada) ... ok
test_sem_referencia (test_origem_contexto.OrigemContextoTests.test_sem_referencia) ... ok
test_aprovacao_destino_true_rejeitada (test_recepcao.RecepcaoTests.test_aprovacao_destino_true_rejeitada) ... ok
test_ausencia_bytes_vazios (test_recepcao.RecepcaoTests.test_ausencia_bytes_vazios) ... ok
test_ausencia_none (test_recepcao.RecepcaoTests.test_ausencia_none) ... ok
test_bom_recusado (test_recepcao.RecepcaoTests.test_bom_recusado) ... ok
test_campo_inesperado (test_recepcao.RecepcaoTests.test_campo_inesperado) ... ok
test_campo_obrigatorio_ausente (test_recepcao.RecepcaoTests.test_campo_obrigatorio_ausente) ... ok
test_cardinalidade_excessiva (test_recepcao.RecepcaoTests.test_cardinalidade_excessiva) ... ok
test_chave_duplicada_aninhada (test_recepcao.RecepcaoTests.test_chave_duplicada_aninhada) ... ok
test_chave_duplicada_raiz (test_recepcao.RecepcaoTests.test_chave_duplicada_raiz) ... ok
test_contexto_sem_autorizacao_comprovada (test_recepcao.RecepcaoTests.test_contexto_sem_autorizacao_comprovada) ... ok
test_documento_real_recusado (test_recepcao.RecepcaoTests.test_documento_real_recusado) ... ok
test_entrada_texto_em_vez_de_bytes (test_recepcao.RecepcaoTests.test_entrada_texto_em_vez_de_bytes) ... ok
test_estado_destino_aprovado_nao_existe_no_contrato (test_recepcao.RecepcaoTests.test_estado_destino_aprovado_nao_existe_no_contrato) ... ok
test_estrutura_sintetica_valida_sem_verdade_material (test_recepcao.RecepcaoTests.test_estrutura_sintetica_valida_sem_verdade_material) ... ok
test_fechamento_true_declarado_nao_comprova_recurso (test_recepcao.RecepcaoTests.test_fechamento_true_declarado_nao_comprova_recurso) ... ok
test_identidade_divergente_preserva_estrutura_sem_atribuicao (test_recepcao.RecepcaoTests.test_identidade_divergente_preserva_estrutura_sem_atribuicao) ... ok
test_ids_verificacao_duplicados (test_recepcao.RecepcaoTests.test_ids_verificacao_duplicados) ... ok
test_impedimento_coerente_e_validavel_como_registro_adverso (test_recepcao.RecepcaoTests.test_impedimento_coerente_e_validavel_como_registro_adverso) ... ok
test_impedimento_incoerente_rejeitado (test_recepcao.RecepcaoTests.test_impedimento_incoerente_rejeitado) ... ok
test_infinity_rejeitado (test_recepcao.RecepcaoTests.test_infinity_rejeitado) ... ok
test_inteiro_nao_substitui_booleano (test_recepcao.RecepcaoTests.test_inteiro_nao_substitui_booleano) ... ok
test_json_adicional_nao_recortado (test_recepcao.RecepcaoTests.test_json_adicional_nao_recortado) ... ok
test_json_corrompido (test_recepcao.RecepcaoTests.test_json_corrompido) ... ok
test_json_grande (test_recepcao.RecepcaoTests.test_json_grande) ... ok
test_json_truncado (test_recepcao.RecepcaoTests.test_json_truncado) ... ok
test_nan_rejeitado (test_recepcao.RecepcaoTests.test_nan_rejeitado) ... ok
test_overflow_float_rejeitado (test_recepcao.RecepcaoTests.test_overflow_float_rejeitado) ... ok
test_payload_preservado_integralmente (test_recepcao.RecepcaoTests.test_payload_preservado_integralmente) ... ok
test_profundidade_excessiva (test_recepcao.RecepcaoTests.test_profundidade_excessiva) ... ok
test_quantidade_nos_excessiva (test_recepcao.RecepcaoTests.test_quantidade_nos_excessiva) ... ok
test_recursao_parser_contida (test_recepcao.RecepcaoTests.test_recursao_parser_contida) ... ok
test_referencia_hash_invalida (test_recepcao.RecepcaoTests.test_referencia_hash_invalida) ... ok
test_utf8_invalido (test_recepcao.RecepcaoTests.test_utf8_invalido) ... ok
test_adversos_validos_preservados (test_registro.RegistroTests.test_adversos_validos_preservados) ... ok
test_booleano_nao_e_contagem (test_registro.RegistroTests.test_booleano_nao_e_contagem) ... ok
test_chave_nao_string (test_registro.RegistroTests.test_chave_nao_string) ... ok
test_chaves_e_payload_privados_sinteticos_descartados (test_registro.RegistroTests.test_chaves_e_payload_privados_sinteticos_descartados) ... ok
test_destino_aprovado_nao_e_estado (test_registro.RegistroTests.test_destino_aprovado_nao_e_estado) ... ok
test_entrada_nao_mutada (test_registro.RegistroTests.test_entrada_nao_mutada) ... ok
test_none_resulta_conservador (test_registro.RegistroTests.test_none_resulta_conservador) ... ok
test_referencia_arbitraria_nao_ecoada (test_registro.RegistroTests.test_referencia_arbitraria_nao_ecoada) ... ok
test_referencia_fechada_permitida (test_registro.RegistroTests.test_referencia_fechada_permitida) ... ok
test_registro_grande (test_registro.RegistroTests.test_registro_grande) ... ok
test_tentativa_de_aprovacao_preserva_motivo_e_false (test_registro.RegistroTests.test_tentativa_de_aprovacao_preserva_motivo_e_false) ... ok
test_valor_arbitrario_em_campo_permitido_nao_ecoado (test_registro.RegistroTests.test_valor_arbitrario_em_campo_permitido_nao_ecoado) ... ok

----------------------------------------------------------------------
Ran 129 tests in 0.022s

OK
```

## 6. Cobertura e verificações

79 métodos originais preservados. 26 novos testes de integração cobrem os vinte
itens mínimos autorizados, além de coerência/imutabilidade/falha de registro/
preservação da entrada. 24 adversariais independentes cobrem tipos, limites,
profundidade, duplicatas, não finitos, referências, transições e corrupção da
montagem via mock sintético. Não usar essas injeções como prova de resistência
universal a Python hostil ou comprometimento do mesmo processo.

Leitura ast dos novos bytes: imports do núcleo limitados a biblioteca padrão
(dataclasses/enum/hashlib/hmac/json/math) e relativos próprios. Sem open/print/
eval/exec/input/compile/import dinâmico diretos no núcleo, Windows, rede, shell,
subprocess, relógio/ambiente, host ou persistência. Teste com open/print bloqueados
cobre caminho integrado exercitado, não comprova todos os efeitos possíveis.
Ferramentas de entrega leem somente fontes/artefatos autorizados para hash/diff;
isso não cria acesso a arquivo dentro da biblioteca.

| M-C | Cobertura somente passiva sintética | Implementação/limite |
|---|---|---|
| M-C01 | PARCIAL | Confronto atual de bytes/hash declarados integrado; não autentica carregamento/autoria. |
| M-C02 | PARCIAL | Contexto é produzido por B a partir de declaração; nenhuma autoridade criada. |
| M-C03 | EXTERNO_NAO_IMPLEMENTADO | Sem autenticar pessoa/competência/legitimidade reais. |
| M-C04 | EXTERNO_NAO_IMPLEMENTADO | Sem host/Windows ou autenticação de ambiente. |
| M-C05 | PARCIAL | Eventos fornecidos não demonstram início real. |
| M-C06 | COBERTO_PASSIVAMENTE | D valida JSON sintético; integração deriva validade efetiva e F correspondente. |
| M-C07 | COBERTO_PASSIVAMENTE | Ausência/incompletude/corrupção preservadas; envelope inválido deixa componentes None. |
| M-C08 | COBERTO_PASSIVAMENTE | Estrutura/atribuição/coerência de projeção conferidas, sem verdade factual. |
| M-C09 | COBERTO_PASSIVAMENTE | Extras e texto livre recusados sem eco/recorte para aceitar. |
| M-C10 | PARCIAL | Interrupções/falhas fornecidas preservadas, sem controlar processo. |
| M-C11 | EXTERNO_NAO_IMPLEMENTADO | Nenhum timeout global/medição real; duração é dado fornecido. |
| M-C12 | PARCIAL | Término/fechamento declarados não comprovam recurso; falha de registro explícita. |
| M-C13 | COBERTO_PASSIVAMENTE | Registro imutável e minimizado; exportação independente, sem persistência. |
| M-C14 | COBERTO_PASSIVAMENTE | Nenhum estado/registro confere aprovação, custódia ou operação. |

COBERTO_PASSIVAMENTE não significa G10 operacional implementado ou validação
formal P1–P6. Nenhum resultado sintético autentica origem/pessoa/host, encerra
recursos ou aprova destino.

## 7. Identidade dos arquivos após a suíte completa

| Arquivo exercitado/preservado na árvore final | Bytes | SHA-256 após teste completo |
|---|---:|---|
| MANIFESTO_SHA256_DEV1 | 1299 | 416c6c3ac0708921f7931943cd760a36f70f39d0996597b2d076aad81f2416dd |
| RELATORIO_DEV1.md | 26569 | 4ed7cac6e8f66555c9c714b41813519b54b63de194486c3b234eaa8e7730d045 |
| alternativa_python/LEIA-ME.md | 11389 | ea60400112bd10c832c7ddd53ed616af32450e3c6d6061053f27472b42d3edf6 |
| alternativa_python/contexto.py | 1856 | 6a62bda132a156e171a2c3254f3f95ac465849f39ed1bfe714197468fb0dcf7a |
| alternativa_python/contratos.py | 6689 | cf724fe267a5f18cc2bd02b5d78eaad4c238abfad1c0b514e4c35160b3b8fabe |
| alternativa_python/eventos.py | 3602 | 70ba9d7f1100238d093ea049f32d1d697433cb483bc5c36b8d7ad33f4424d2d3 |
| alternativa_python/fluxo.py | 3804 | 6ccc4ba17aa3d889846199a17288f250171fe15fff4dea0c2b2aec93974161ca |
| alternativa_python/origem.py | 982 | b1c174950f78bb9fed86a32a1e2411fbf38f458eecf7826836834e15be745eb5 |
| alternativa_python/recepcao.py | 6652 | 4b5a91198ed992843c3e36c6d364434404a97e48befb7571c2a8384397ba6080 |
| alternativa_python/registro.py | 5516 | b3924ce1a2c209e8b8e5b55222be480dd6fce6c5baa4ef0e9a8ecc9a415d8d50 |
| tests/test_casos_adversos_dev2.py | 8056 | e6cd98fc1663058220e4c65e65d856a9d3a4d6959c61982762baed679996d97d |
| tests/test_eventos.py | 4717 | bfb10b69378eafc187fd25a24e7b18cc74ab7e671cd0c3176e3f75ee540d5ba3 |
| tests/test_fluxo_integrado_dev2.py | 11056 | c96cdb9bc06897384b9570f43c28cc87b7cf362ff3dd3b000be809fed7f029c6 |
| tests/test_fluxo_passivo_sintetico.py | 3852 | ddc8bb7ca3d3ec74925cb262c0020bc390f7586b642962fe565bd96992c08cb8 |
| tests/test_origem_contexto.py | 3540 | 524f0bd5ed19d2d432c1efa3ab6ddec070e16f73509b899dbbf214791a559f6e |
| tests/test_recepcao.py | 7276 | 9a92b3fb79e5f2f7f5adfe20dd49475a5073c4cf0e6b16681141f9bb5286f59c |
| tests/test_registro.py | 3657 | 5b3062e9a5d77344b3103260c60f30a4b6dc17f670451369a820f4167fa14ca8 |

Os 17 arquivos acima foram congelados por comparação de bytes/hash após a suíte.
Os três arquivos de evidência novos são adicionados depois, sem alterar código,
testes ou LEIA-ME. Manifesto novo e único ZIP local terão identidades externas
informadas na entrega para evitar autorreferência.

## 8. Proveniência e preservação

Instrução DEV-2 recebida, 13.554 bytes:
dc752208a7425e1493121b197aad311e2a91dba1be56cd2939948b99010f5660.
Parecer DEV-1, 11.609 bytes:
2546735644ffc623bb0ab005d368a32180e03350e59d79827d7c00f6154d13f1.
Conferências de bytes são locais, sem atestado institucional de autoria/tempo.

Parecer do usuário relata reprodução independente do DEV-1 em Python 3.13.5:
79 originais e 14 suplementares em duas execuções, 93 aprovações no auditor.
Não são 93 casos do Codex nem prova 3.12 ou Windows. Não foram recebidos os logs
primários daqueles testes suplementares. A presente evidência é nova execução
3.12.14 no Codex de 129 casos DEV-2, separada das declarações anteriores.

| Origem preservada | Bytes | SHA-256 local |
|---|---:|---|
| WIN19-DEV1-NUCLEO-PASSIVO/RELATORIO_DEV1.md | 26569 | 4ed7cac6e8f66555c9c714b41813519b54b63de194486c3b234eaa8e7730d045 |
| WIN19-DEV1-NUCLEO-PASSIVO/MANIFESTO_SHA256_DEV1 | 1299 | 416c6c3ac0708921f7931943cd760a36f70f39d0996597b2d076aad81f2416dd |
| WIN19-DEV1-NUCLEO-PASSIVO/tests/test_origem_contexto.py | 3540 | 524f0bd5ed19d2d432c1efa3ab6ddec070e16f73509b899dbbf214791a559f6e |
| WIN19-DEV1-NUCLEO-PASSIVO/tests/test_eventos.py | 4717 | bfb10b69378eafc187fd25a24e7b18cc74ab7e671cd0c3176e3f75ee540d5ba3 |
| WIN19-DEV1-NUCLEO-PASSIVO/tests/test_fluxo_passivo_sintetico.py | 3852 | ddc8bb7ca3d3ec74925cb262c0020bc390f7586b642962fe565bd96992c08cb8 |
| WIN19-DEV1-NUCLEO-PASSIVO/tests/test_registro.py | 3657 | 5b3062e9a5d77344b3103260c60f30a4b6dc17f670451369a820f4167fa14ca8 |
| WIN19-DEV1-NUCLEO-PASSIVO/tests/test_recepcao.py | 7276 | 9a92b3fb79e5f2f7f5adfe20dd49475a5073c4cf0e6b16681141f9bb5286f59c |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/recepcao.py | 6652 | 4b5a91198ed992843c3e36c6d364434404a97e48befb7571c2a8384397ba6080 |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/registro.py | 3996 | 54daeb741f66ff0b1e54c8c784c843fa6f115028fc3d7a37e7f3ea7e526960eb |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/contratos.py | 4775 | db4b2199a98c9e3f0c334826e881b53c61adf7410a21bfaa2a32c0127aaf66dd |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/contexto.py | 1705 | 175f71a22f0b9f83df57ebe3ad2ec35affb438d2d174d892b2eb550e25779d06 |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/origem.py | 982 | b1c174950f78bb9fed86a32a1e2411fbf38f458eecf7826836834e15be745eb5 |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/LEIA-ME.md | 6572 | 712cf2a44e6e03708321526aa8b47ff2ebe7865a6ee6b466d52be0373e2a51f4 |
| WIN19-DEV1-NUCLEO-PASSIVO/alternativa_python/eventos.py | 3602 | 70ba9d7f1100238d093ea049f32d1d697433cb483bc5c36b8d7ad33f4424d2d3 |
| WIN19-DEV1-NUCLEO-PASSIVO.zip | 27962 | 472c059824aa42af6847de3234d4fef546078a8015707f927905d97ee48cc4cc |
| Texto colado.txt | 13554 | dc752208a7425e1493121b197aad311e2a91dba1be56cd2939948b99010f5660 |
| PARECER_INDEPENDENTE_WIN19_DEV1_2026-11-27.md | 11609 | 2546735644ffc623bb0ab005d368a32180e03350e59d79827d7c00f6154d13f1 |

DEV-1/ZIP e anexos conferidos antes/depois; nenhum histórico foi regravado.
As antigas ressalvas de proveniência 90/92 e 74/75 permanecem, sem reivindicar
autenticação independente dos 109 objetos de preparação anteriores.
Não houve consulta/alteração de C, produto, Windows, JUnit, ACL/DACL ou cliente.

## 9. Riscos, limites e parada

Biblioteca recebe somente material sintético, não dados reais. Não é sandbox
contra código/objetos Python hostis, monkeypatch/reflexão no mesmo processo.
RegistroIntegrado ou DTO criados diretamente por chamador não são certificados
de origem; a garantia de derivação descrita é a do ponto de entrada executar_fluxo.
Falha fatal de host não tem garantia de gerar retorno sanitizado.

Formato JSON limitado não é verdade factual; origem/contexto continuam declarados.
Duração/encerramento reais, identidade física/confinamento e proteção efetiva
não são implementados. N02–N04 continuam com quinze registros não verificados,
R01–R09 abertos e R03/R07 ALTA; N01 só vale para os antigos bytes R1.
G09/L-D06 e decisões privadas não foram preenchidos/solicitados.
Nenhuma regra financeira/cadastral/formato A/B/XLSX foi operada ou modificada.

| Item | Estado |
|---|---|
| DEV1 | ACEITO_TECNICAMENTE_ESCOPO_PASSIVO_SINTETICO_COM_RESSALVAS |
| DEV2 | IMPLEMENTADO_AGUARDANDO_AUDITORIA |
| L-D01 | ALTERNATIVA_A_OBSERVACAO_LIMITADA |
| L-D02 | CLASSIFICACOES_DELIBERADAS_11_DE_11 |
| G09 | INDISPENSAVEL_NAO_COMPROVADO |
| G10_OPERACIONAL | NAO_COMPROVADO |
| L-D06 | PENDENTE |
| CONTRATO_EXTERNO_REAL | NAO_IMPLEMENTADO |
| H3-F-R1 | INALTERADA_EXECUCAO_NAO_AUTORIZADA |
| R01_A_R09 | RISCO_POTENCIAL_ABERTO |
| N02_A_N04 | NAO_VERIFICADO |
| WIN01_A_WIN19 | NAO_VALIDADO |
| DACL | NAO_VALIDADO |
| U05_U06_U07 | NAO_AUTORIZADAS |
| H3-C | NAO_AUTORIZADA |
| H3-S | NAO_AUTORIZADA |
| H4 | NAO_AUTORIZADA |
| P1_A_P6 | SEM_LIBERACAO_OPERACIONAL |
| CONVERSOES_REAIS | BLOQUEADAS |
| PRONTIDAO_OPERACIONAL | false |

Política H3-E preservada, sem custódia iniciada: usuário como custodiante principal,
coadministradores específicos por autorização, alterações de acesso/movimentação/
exclusão só por ato próprio. Retenção vinculada à H4 com máximo inicial 180 dias
somente após futura cópia fiel aceita/verificada; revisões 60/120/180 e antecipada
se H4 terminar, prorrogação expressa justificada, nenhuma exclusão automática.

Código/testes DEV-2 concluídos neste escopo, auditoria independente pendente.
Sem publicação, Git, Windows, MVP, DEV-3 automático, inspeção ou custódia.
