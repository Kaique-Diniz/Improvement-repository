# WIN19 DEV-2 — diferenças integrais em relação ao DEV-1

27/11/2026. Código passivo/sintético; sem Git ou patch aplicado em origem.
DEV-1 original e ZIP permanecem íntegros. Esta comparação usa difflib sobre
arquivos explicitamente autorizados, não histórico Git.

## Inventário de alterações

Dos 14 arquivos copiados, dez continuam byte a byte idênticos e quatro mudam
somente nesta cópia. Adicionadas seis entradas autorizadas, total 20 arquivos.
Dos seis módulos originais: contexto/contratos/registro alterados; origem/
recepcao/eventos idênticos. Nenhum dos cinco testes históricos foi alterado.

- contexto.py: limite de 32 caracteres para referencia/finalidade antes do
  confronto; tipo, seis campos, finalidade e ausência de autoridade preservados.
- contratos.py: MAX_TEXTO_CONTEXTO, dois motivos fechados novos e tipos imutáveis
  RegistroIntegrado/ResultadoFluxo; sete estados/flags false e contratos anteriores
  mantidos. como_dict devolve cópia independente; validade consulta recepção real.
- registro.py: imports e caminho interno _projetar_integrado; usa dados derivados
  e validade da recepção. sanitizar mantém assinatura/corpo e limite histórico
  de não autenticar declarações quando usado diretamente.
- LEIA-ME: cabeçalho DEV-2, API, guardas e limites novos; texto antigo identificado
  explicitamente como documentação histórica DEV-1.
- fluxo.py: coordenador A/B/D/E/F em memória, envelope fechado, origem/contexto/
  recepção/eventos produzidos internamente, união de adversos e projeção coerente.
  Montagem falha retorna registro=None e motivos seguros, sem dados livres.
- Dois testes novos: 26 métodos de integração e 24 adversariais.
- Novos RELATORIO_DEV2, este documento e MANIFESTO_DEV2 são evidências de entrega.

Nenhuma mudança incompatível intencional das APIs DEV-1: os 79 testes passam sem
edição. Motivos/tipos novos são aditivos. Rejeição de texto longo em contexto
endurece entradas que já eram inválidas; não muda referências válidas.
API integrada nova aceita somente quatro campos e não aceita validade livre.
A projeção direta legada mantém a semântica anterior, que não é autenticação.

## Arquivos originais confrontados

| Arquivo DEV-1 na cópia DEV-2 | Situação | SHA-256 origem | SHA-256 atual |
|---|---|---|---|
| MANIFESTO_SHA256_DEV1 | IDENTICO | 416c6c3ac0708921f7931943cd760a36f70f39d0996597b2d076aad81f2416dd | 416c6c3ac0708921f7931943cd760a36f70f39d0996597b2d076aad81f2416dd |
| RELATORIO_DEV1.md | IDENTICO | 4ed7cac6e8f66555c9c714b41813519b54b63de194486c3b234eaa8e7730d045 | 4ed7cac6e8f66555c9c714b41813519b54b63de194486c3b234eaa8e7730d045 |
| alternativa_python/LEIA-ME.md | ALTERADO NA COPIA | 712cf2a44e6e03708321526aa8b47ff2ebe7865a6ee6b466d52be0373e2a51f4 | ea60400112bd10c832c7ddd53ed616af32450e3c6d6061053f27472b42d3edf6 |
| alternativa_python/contexto.py | ALTERADO NA COPIA | 175f71a22f0b9f83df57ebe3ad2ec35affb438d2d174d892b2eb550e25779d06 | 6a62bda132a156e171a2c3254f3f95ac465849f39ed1bfe714197468fb0dcf7a |
| alternativa_python/contratos.py | ALTERADO NA COPIA | db4b2199a98c9e3f0c334826e881b53c61adf7410a21bfaa2a32c0127aaf66dd | cf724fe267a5f18cc2bd02b5d78eaad4c238abfad1c0b514e4c35160b3b8fabe |
| alternativa_python/eventos.py | IDENTICO | 70ba9d7f1100238d093ea049f32d1d697433cb483bc5c36b8d7ad33f4424d2d3 | 70ba9d7f1100238d093ea049f32d1d697433cb483bc5c36b8d7ad33f4424d2d3 |
| alternativa_python/origem.py | IDENTICO | b1c174950f78bb9fed86a32a1e2411fbf38f458eecf7826836834e15be745eb5 | b1c174950f78bb9fed86a32a1e2411fbf38f458eecf7826836834e15be745eb5 |
| alternativa_python/recepcao.py | IDENTICO | 4b5a91198ed992843c3e36c6d364434404a97e48befb7571c2a8384397ba6080 | 4b5a91198ed992843c3e36c6d364434404a97e48befb7571c2a8384397ba6080 |
| alternativa_python/registro.py | ALTERADO NA COPIA | 54daeb741f66ff0b1e54c8c784c843fa6f115028fc3d7a37e7f3ea7e526960eb | b3924ce1a2c209e8b8e5b55222be480dd6fce6c5baa4ef0e9a8ecc9a415d8d50 |
| tests/test_eventos.py | IDENTICO | bfb10b69378eafc187fd25a24e7b18cc74ab7e671cd0c3176e3f75ee540d5ba3 | bfb10b69378eafc187fd25a24e7b18cc74ab7e671cd0c3176e3f75ee540d5ba3 |
| tests/test_fluxo_passivo_sintetico.py | IDENTICO | ddc8bb7ca3d3ec74925cb262c0020bc390f7586b642962fe565bd96992c08cb8 | ddc8bb7ca3d3ec74925cb262c0020bc390f7586b642962fe565bd96992c08cb8 |
| tests/test_origem_contexto.py | IDENTICO | 524f0bd5ed19d2d432c1efa3ab6ddec070e16f73509b899dbbf214791a559f6e | 524f0bd5ed19d2d432c1efa3ab6ddec070e16f73509b899dbbf214791a559f6e |
| tests/test_recepcao.py | IDENTICO | 9a92b3fb79e5f2f7f5adfe20dd49475a5073c4cf0e6b16681141f9bb5286f59c | 9a92b3fb79e5f2f7f5adfe20dd49475a5073c4cf0e6b16681141f9bb5286f59c |
| tests/test_registro.py | IDENTICO | 5b3062e9a5d77344b3103260c60f30a4b6dc17f670451369a820f4167fa14ca8 | 5b3062e9a5d77344b3103260c60f30a4b6dc17f670451369a820f4167fa14ca8 |

## Novos arquivos de implementação/testes

| Novo arquivo funcional | Bytes | SHA-256 testado |
|---|---:|---|
| alternativa_python/fluxo.py | 3804 | 6ccc4ba17aa3d889846199a17288f250171fe15fff4dea0c2b2aec93974161ca |
| tests/test_fluxo_integrado_dev2.py | 11056 | c96cdb9bc06897384b9570f43c28cc87b7cf362ff3dd3b000be809fed7f029c6 |
| tests/test_casos_adversos_dev2.py | 8056 | e6cd98fc1663058220e4c65e65d856a9d3a4d6959c61982762baed679996d97d |

RELATORIO_DEV2.md, DIFERENCAS_DEV1_DEV2.md e MANIFESTO_SHA256_DEV2 são os três novos
artefatos de evidência; não são código. O manifesto novo cobre 19 outros arquivos
e não se inclui. Sua própria identidade é informada externamente.
O manifesto DEV-1 copiado é histórico e não verifica a árvore modificada DEV-2.

## Diff integral de código, testes e LEIA-ME

Os blocos a seguir incluem cada linha alterada nos quatro arquivos existentes e
cada linha dos três novos arquivos funcionais. Não truncados; nenhum diff de
si próprio/relatório/manifesto é gerado para evitar autorreferência.

### alternativa_python/LEIA-ME.md

```diff
--- DEV1/alternativa_python/LEIA-ME.md
+++ DEV2/alternativa_python/LEIA-ME.md
@@ -1,3 +1,86 @@
+# WIN19 DEV-2 — integração offline passiva
+
+27/11/2026. Python 3.12, somente biblioteca padrão, BT01 Codex.
+Código e autotestes sintéticos autorizados para DEV-2; nenhuma liberação operacional.
+
+## API pública nova
+
+alternativa_python.fluxo.executar_fluxo(entrada) retorna ResultadoFluxo congelado.
+A entrada deve ser dict exato com quatro chaves exatas:
+- conteudo: bytes sintéticos ou None, limitado a 16.384 bytes por A/D;
+- sha256_esperado: digest declarado ou None, nunca prova de origem legítima;
+- contexto: declaração sintética em dict fechado ou None, nunca autoridade;
+- eventos: lista/tupla de Evento fornecidos, no máximo 32, sem observação própria.
+
+Não admite validade_estrutural, autorização, destino, payload livre, registro ou
+objetos prontos de componentes como campos do envelope. Chaves/tipos de envelope
+incompatíveis são recusados; componentes não executados ficam None, sem simular
+resultados. Para subentradas, os contratos exatos e limites DEV-1 são preservados.
+Strings referencia/finalidade de contexto agora têm limite de 32 caracteres antes
+do confronto; isso não cria legitimidade ou novo campo de dado privado.
+
+A é chamada com os bytes fornecidos; B representa a declaração; D produz o
+ResultadoRecepcao efetivo; E reduz os eventos; F projeta somente dados derivados.
+A validade do resultado e do registro é derivada de D, não de campo livre.
+Divergência de hash, contexto insuficiente ou evento inválido não apagam a
+validade estritamente estrutural do JSON: preservam motivos/estados adversos e
+não comprovam nenhum fato ou autorização.
+
+O objeto reúne origem/contexto/recepcao/eventos e estados/motivos fechados.
+ResultadoFluxo.registro é RegistroIntegrado imutável ou None se falhar a montagem.
+registro.como_dict() exporta cópia independente com flags sempre false. Alterar
+essa cópia não altera o resultado. Contagens/referências/estados/motivos/validade
+precisam corresponder aos componentes produzidos pelo fluxo.
+
+Montagem incompatível ou exceção comum na projeção preserva os estados adversos,
+adiciona REGISTRO_INDISPONIVEL e EVIDENCIA_INCOMPATIVEL e retorna registro=None.
+Não ecoa a exceção nem fabrica registro de sucesso; falhas fatais do host não
+são cobertas. O núcleo não é sandbox contra Python hostil no mesmo processo,
+monkeypatching ou adulteração por reflexão; os testes de falha são injeções
+sintéticas limitadas, não prova de segurança universal.
+
+## Compatibilidade e semântica
+
+As APIs públicas DEV-1 e os 79 testes antigos permanecem. sanitizar(dict) continua
+sendo projeção sem autenticar validade declarada quando chamado diretamente;
+a integração usa o caminho interno novo _projetar_integrado e verifica coerência.
+Esse caminho não aceita metadados livres para substituir o retorno real de D.
+Dois motivos novos: ENTRADA_FLUXO_INVALIDA e REGISTRO_INDISPONIVEL.
+Os sete estados G10 e o contrato JSON sintético WIN19-DEV1-SINTETICO-1 não mudam.
+Registro integrado tem versão WIN19-DEV2-REGISTRO-1, diferente da projeção legada.
+Nenhuma dessas estruturas é contrato real da H3-F-R1 ou prova factual.
+
+Os cinco arquivos de testes DEV-1, RELATORIO_DEV1.md e MANIFESTO_SHA256_DEV1 são
+cópias históricas intactas. O manifesto antigo autentica os bytes DEV-1 no ZIP
+original, não a árvore modificada DEV-2. Para esta entrega usar exclusivamente
+MANIFESTO_SHA256_DEV2, que cobre todos os outros 19 arquivos, inclusive a cópia
+histórica do manifesto antigo. Não aplicar o manifesto antigo aos módulos DEV-2
+nem herdar hashes/aprovações/sintaxe de outro pacote.
+
+## Testes autorizados DEV-2
+
+Na raiz DEV-2:
+PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 python -B -m unittest discover -s tests -p 'test_*.py' -v
+
+Sete arquivos de testes, cinco históricos sem alteração e dois novos. Somente
+unittest/biblioteca padrão e módulos novos isolados. Sem instalação, serviços,
+rede, Git, relógio/processo ativo, Windows, WMI, ACL/DACL, JUnit ou dados reais.
+Verificação de IO dos testes cobre os caminhos sintéticos exercitados e revisão
+estática, não é certificação universal de efeitos de execução.
+
+G09/G10 operacional não comprovados; L-D06 pendente, R01–R09 abertos, R03/R07 ALTA,
+N02–N04 não verificados. U05/U06/U07 não autorizadas; C/H3-F-R1 inalterada e não
+executada; P1–P6 sem liberação operacional, conversões bloqueadas e prontidão false.
+Relatório e diferenças fornecem os resultados efetivamente executados e os limites.
+Sem publicação, Git, integração ao MVP, DEV-3, inspeção ou custódia automáticos.
+
+---
+
+## Referência histórica: LEIA-ME DEV-1
+
+O texto abaixo é a documentação de origem, anterior às extensões descritas acima.
+Seu inventário de 14 arquivos e seis módulos refere-se apenas ao DEV-1 original.
+
 # WIN19 DEV-1 — núcleo passivo sintético

 Python 3.12, somente biblioteca padrão. U01–U04 implementadas exclusivamente como
```

### alternativa_python/contexto.py

```diff
--- DEV1/alternativa_python/contexto.py
+++ DEV2/alternativa_python/contexto.py
@@ -1,5 +1,7 @@
 """B: metadados declarados não são autenticação nem autorização."""
-from .contratos import ContextoPassivo, EstadoContexto, Motivo, Referencia
+from .contratos import (
+    ContextoPassivo, EstadoContexto, Motivo, Referencia, MAX_TEXTO_CONTEXTO,
+)

 _CAMPOS = frozenset({
     "referencia", "finalidade", "autorizacao_declarada",
@@ -19,8 +21,10 @@
         return ContextoPassivo(EstadoContexto.DECLARACAO_INVALIDA, None,
                                base + (Motivo.CONTEXTO_INVALIDO,))
     if (type(dados["referencia"]) is not str
+            or len(dados["referencia"]) > MAX_TEXTO_CONTEXTO
             or dados["referencia"] not in {r.value for r in Referencia}
             or type(dados["finalidade"]) is not str
+            or len(dados["finalidade"]) > MAX_TEXTO_CONTEXTO
             or dados["finalidade"] != "OBSERVACAO_LIMITADA"
             or any(type(dados[k]) is not bool for k in _BOOLEANOS)):
         return ContextoPassivo(EstadoContexto.DECLARACAO_INVALIDA, None,
```

### alternativa_python/contratos.py

```diff
--- DEV1/alternativa_python/contratos.py
+++ DEV2/alternativa_python/contratos.py
@@ -9,6 +9,7 @@
 MAX_VERIFICACOES = 16
 MAX_EVENTOS = 32
 MAX_CAMPOS_REGISTRO = 32
+MAX_TEXTO_CONTEXTO = 32
 MAX_DURACAO_FORNECIDA = 1_000_000_000


@@ -49,6 +50,8 @@
     CAMPOS_DESCARTADOS = "CAMPOS_DESCARTADOS"
     APROVACAO_INDEVIDA = "APROVACAO_INDEVIDA"
     IMPEDIMENTO_DECLARADO = "IMPEDIMENTO_DECLARADO"
+    ENTRADA_FLUXO_INVALIDA = "ENTRADA_FLUXO_INVALIDA"
+    REGISTRO_INDISPONIVEL = "REGISTRO_INDISPONIVEL"


 class Referencia(StrEnum):
@@ -160,3 +163,51 @@
     termino_fornecido: bool
     fechamento_declarado: bool
     duracao_fornecida: int | float | None
+
+
+@dataclass(frozen=True, slots=True)
+class RegistroIntegrado(SemAprovacao):
+    """Projeção DEV-2 imutável, derivada internamente; não é atestado."""
+    estados: tuple[str, ...]
+    motivos: tuple[str, ...]
+    quantidade_verificacoes: int
+    quantidade_eventos: int
+    referencia: str | None
+    validade_estrutural: bool
+    campos_descartados: int
+
+    def como_dict(self) -> dict:
+        # Cada exportação é independente; mutar a cópia não altera o resultado.
+        return {
+            "versao_registro": "WIN19-DEV2-REGISTRO-1",
+            "estados": list(self.estados), "motivos": list(self.motivos),
+            "quantidade_verificacoes": self.quantidade_verificacoes,
+            "quantidade_eventos": self.quantidade_eventos,
+            "referencia": self.referencia,
+            "validade_estrutural": self.validade_estrutural,
+            "campos_descartados": self.campos_descartados,
+            "destino_aprovado": False, "custodia_autorizada": False,
+            "operacao_autorizada": False, "prontidao_operacional": False,
+            "origem_autenticada": False, "autorizacao_comprovada": False,
+            "encerramento_comprovado": False,
+        }
+
+
+@dataclass(frozen=True, slots=True)
+class ResultadoFluxo(SemAprovacao):
+    origem: ReferenciaOrigem | None
+    contexto: ContextoPassivo | None
+    recepcao: ResultadoRecepcao | None
+    eventos: ResumoEventos | None
+    estados: tuple[EstadoG10, ...]
+    motivos: tuple[Motivo, ...]
+    registro: RegistroIntegrado | None
+
+    @property
+    def valido_estruturalmente(self) -> bool:
+        return (self.recepcao is not None
+                and self.recepcao.valido_estruturalmente is True)
+
+    @property
+    def registro_disponivel(self) -> bool:
+        return self.registro is not None
```

### alternativa_python/registro.py

```diff
--- DEV1/alternativa_python/registro.py
+++ DEV2/alternativa_python/registro.py
@@ -1,7 +1,8 @@
 """F: allowlist de projeção em memória, sem IO ou eco de dados arbitrários."""
 from .contratos import (
     EstadoG10, Motivo, Referencia, MAX_VERIFICACOES, MAX_EVENTOS,
-    MAX_CAMPOS_REGISTRO,
+    MAX_CAMPOS_REGISTRO, ContextoPassivo, ResultadoRecepcao,
+    ResumoEventos, RegistroIntegrado,
 )

 _FLAGS = (
@@ -98,3 +99,31 @@
            Motivo.ORIGEM_NAO_AUTENTICADA.value,
            Motivo.AUTORIZACAO_NAO_COMPROVADA.value]))
     return saida
+
+
+def _projetar_integrado(recepcao, eventos, contexto, estados, motivos):
+    """Uso interno do coordenador; não recebe validade livre do chamador."""
+    if (recepcao is not None and type(recepcao) is not ResultadoRecepcao
+            or eventos is not None and type(eventos) is not ResumoEventos
+            or contexto is not None and type(contexto) is not ContextoPassivo
+            or type(estados) is not tuple
+            or any(type(v) is not EstadoG10 for v in estados)
+            or type(motivos) is not tuple
+            or any(type(v) is not Motivo for v in motivos)):
+        raise ValueError("CONTRATO_INTERNO_INVALIDO")
+    validade = (recepcao is not None
+                and recepcao.valido_estruturalmente is True)
+    referencia = contexto.referencia if contexto is not None else None
+    dados = sanitizar({
+        "estados": estados, "motivos": motivos,
+        "quantidade_verificacoes": (recepcao.quantidade_verificacoes
+                                   if recepcao is not None else 0),
+        "quantidade_eventos": (eventos.quantidade_aplicados
+                               if eventos is not None else 0),
+        "referencia": referencia, "validade_estrutural": validade,
+    })
+    return RegistroIntegrado(
+        tuple(dados["estados"]), tuple(dados["motivos"]),
+        dados["quantidade_verificacoes"], dados["quantidade_eventos"],
+        dados["referencia"], validade, dados["campos_descartados"],
+    )
```

### alternativa_python/fluxo.py

```diff
--- /dev/null
+++ DEV2/alternativa_python/fluxo.py
@@ -0,0 +1,77 @@
+"""Integração passiva DEV-2: somente primitivas/contratos sintéticos em memória."""
+from . import origem, contexto, recepcao, eventos, registro
+from .contratos import (
+    EstadoG10, EstadoOrigem, Motivo, ResultadoFluxo, RegistroIntegrado,
+)
+
+_CAMPOS = frozenset({"conteudo", "sha256_esperado", "contexto", "eventos"})
+
+
+def _registro_coerente(reg, r, e, c, estados, motivos):
+    if type(reg) is not RegistroIntegrado:
+        return False
+    if (type(reg.estados) is not tuple or type(reg.motivos) is not tuple
+            or any(type(v) is not str for v in reg.estados + reg.motivos)
+            or type(reg.quantidade_verificacoes) is not int
+            or type(reg.quantidade_eventos) is not int
+            or type(reg.validade_estrutural) is not bool
+            or type(reg.campos_descartados) is not int
+            or (reg.referencia is not None and type(reg.referencia) is not str)):
+        return False
+    validade = r is not None and r.valido_estruturalmente is True
+    ref = c.referencia.value if c is not None and c.referencia is not None else None
+    return (
+        reg.estados == tuple(s.value for s in estados)
+        and reg.motivos == tuple(m.value for m in motivos)
+        and reg.quantidade_verificacoes == (r.quantidade_verificacoes if r else 0)
+        and reg.quantidade_eventos == (e.quantidade_aplicados if e else 0)
+        and reg.validade_estrutural is validade and reg.referencia == ref
+        and reg.campos_descartados == 0
+    )
+
+
+def _finalizar(a, b, d, e, estados, motivos):
+    estados = tuple(dict.fromkeys(tuple(estados) + (
+        EstadoG10.ENCERRAMENTO_NAO_COMPROVADO, EstadoG10.RESULTADO_INCONCLUSIVO)))
+    motivos = tuple(dict.fromkeys(tuple(motivos) + (
+        Motivo.SOMENTE_SINTETICO, Motivo.ORIGEM_NAO_AUTENTICADA,
+        Motivo.AUTORIZACAO_NAO_COMPROVADA, Motivo.ENCERRAMENTO_INCERTO)))
+    try:
+        reg = registro._projetar_integrado(d, e, b, estados, motivos)
+        if not _registro_coerente(reg, d, e, b, estados, motivos):
+            raise ValueError("REGISTRO_INTERNO_INCOMPATIVEL")
+    except Exception:
+        # Apenas a fronteira de montagem: não ecoar exceção/payload e não
+        # fabricar registro de sucesso. Falhas fatais do host não são cobertas.
+        reg = None
+        estados = tuple(dict.fromkeys(
+            estados + (EstadoG10.EVIDENCIA_INCOMPATIVEL,)))
+        motivos = tuple(dict.fromkeys(
+            motivos + (Motivo.REGISTRO_INDISPONIVEL,)))
+    return ResultadoFluxo(a, b, d, e, estados, motivos, reg)
+
+
+def executar_fluxo(entrada: dict) -> ResultadoFluxo:
+    """Quatro campos exatos; nenhuma validade/autoridade/flag livre é admitida."""
+    if (type(entrada) is not dict or len(entrada) != len(_CAMPOS)
+            or any(type(k) is not str for k in entrada)
+            or set(entrada) != _CAMPOS):
+        # Componentes não executados permanecem None, não respostas simuladas.
+        return _finalizar(None, None, None, None,
+                          (EstadoG10.EVIDENCIA_INCOMPATIVEL,),
+                          (Motivo.ENTRADA_FLUXO_INVALIDA,))
+    conteudo = entrada["conteudo"]
+    esperado = entrada["sha256_esperado"]
+    a = origem.conferir(conteudo, esperado)
+    b = contexto.avaliar(entrada["contexto"])
+    d = recepcao.receber(conteudo, sha256_esperado=esperado, contexto=b)
+    e = eventos.resumir(entrada["eventos"])
+    motivos = d.motivos + b.motivos + e.motivos
+    estados = d.estados + e.estados
+    if a.estado == EstadoOrigem.DIVERGE:
+        motivos += (Motivo.ORIGEM_DIVERGENTE,)
+        estados += (EstadoG10.EVIDENCIA_INCOMPATIVEL,)
+    elif a.estado == EstadoOrigem.REFERENCIA_INVALIDA:
+        motivos += (Motivo.REFERENCIA_ORIGEM_INVALIDA,)
+        estados += (EstadoG10.EVIDENCIA_INCOMPATIVEL,)
+    return _finalizar(a, b, d, e, estados, motivos)
```

### tests/test_fluxo_integrado_dev2.py

```diff
--- /dev/null
+++ DEV2/tests/test_fluxo_integrado_dev2.py
@@ -0,0 +1,265 @@
+import hashlib
+import json
+import unittest
+from dataclasses import FrozenInstanceError, replace
+from unittest.mock import patch
+from alternativa_python.fluxo import executar_fluxo
+from alternativa_python.contratos import (
+    VERSAO, MAX_BYTES, MAX_EVENTOS, Evento, TipoEvento as T,
+    EstadoG10 as G, EstadoContexto, Motivo as M, ResultadoFluxo,
+)
+
+
+def documento():
+    return {
+        "versao": VERSAO, "sintetico": True, "documento_real": False,
+        "resultado": "INCONCLUSIVO",
+        "verificacoes": [{"id": "S01", "estado": "OBSERVADO_SINTETICO"}],
+        "recursos_encerrados": None, "destino_aprovado": False,
+        "custodia_autorizada": False, "operacao_autorizada": False,
+    }
+
+
+def contexto():
+    return {
+        "referencia": "REF_SINTETICA_A", "finalidade": "OBSERVACAO_LIMITADA",
+        "autorizacao_declarada": True, "operador_declarado": True,
+        "escopo_declarado": True, "vigencia_declarada": True,
+    }
+
+
+def entrada():
+    b = json.dumps(documento()).encode("utf-8")
+    return {"conteudo": b, "sha256_esperado": hashlib.sha256(b).hexdigest(),
+            "contexto": contexto(), "eventos": [Evento(T.INICIO_DECLARADO)]}
+
+
+class FluxoIntegradoTests(unittest.TestCase):
+    def test_fluxo_sintetico_valido_tipado(self):
+        r = executar_fluxo(entrada())
+        self.assertIs(type(r), ResultadoFluxo)
+        self.assertTrue(r.valido_estruturalmente)
+        self.assertTrue(r.registro_disponivel)
+        self.assertIn(G.EVIDENCIA_RECEBIDA_VALIDAVEL, r.estados)
+        self.assertFalse(r.origem_autenticada)
+
+    def test_entrada_ausente_sem_objeto_de_sucesso(self):
+        d = entrada()
+        d["conteudo"] = None
+        r = executar_fluxo(d)
+        self.assertFalse(r.valido_estruturalmente)
+        self.assertIn(G.EVIDENCIA_AUSENTE, r.estados)
+
+    def test_json_incompativel(self):
+        d = entrada()
+        d["conteudo"] = b"{}"
+        r = executar_fluxo(d)
+        self.assertFalse(r.valido_estruturalmente)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+
+    def test_json_incompleto(self):
+        d = entrada()
+        d["conteudo"] = b'{"versao":'
+        r = executar_fluxo(d)
+        self.assertIn(G.EVIDENCIA_INCOMPLETA, r.estados)
+        self.assertFalse(r.registro.validade_estrutural)
+
+    def test_hash_divergente_nao_apaga_estrutura_validada(self):
+        d = entrada()
+        d["sha256_esperado"] = "0" * 64
+        r = executar_fluxo(d)
+        self.assertTrue(r.valido_estruturalmente)
+        self.assertIn(M.ORIGEM_DIVERGENTE, r.motivos)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+        self.assertFalse(r.origem_autenticada)
+
+    def test_contexto_insuficiente(self):
+        d = entrada()
+        d["contexto"]["autorizacao_declarada"] = False
+        r = executar_fluxo(d)
+        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INSUFICIENTE)
+        self.assertIn(M.CONTEXTO_INSUFICIENTE, r.motivos)
+        self.assertFalse(r.autorizacao_comprovada)
+
+    def test_contexto_completo_continua_nao_autenticado(self):
+        r = executar_fluxo(entrada())
+        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_COMPLETA)
+        self.assertFalse(r.contexto.autorizacao_comprovada)
+        self.assertIn(M.AUTORIZACAO_NAO_COMPROVADA, r.motivos)
+
+    def test_evento_interrompido(self):
+        d = entrada()
+        d["eventos"].append(Evento(T.INTERRUPCAO_FORNECIDA))
+        r = executar_fluxo(d)
+        self.assertIn(G.EXECUCAO_INTERROMPIDA, r.estados)
+        self.assertIn(G.EXECUCAO_INTERROMPIDA.value, r.registro.estados)
+
+    def test_evento_fora_de_ordem(self):
+        d = entrada()
+        d["eventos"] = [Evento(T.TERMINO_FORNECIDO)]
+        r = executar_fluxo(d)
+        self.assertIn(M.TRANSICAO_INVALIDA, r.motivos)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+        self.assertTrue(r.valido_estruturalmente)  # Só o JSON foi validado.
+
+    def test_recursos_incerto_apos_fechamento_declarado(self):
+        d = entrada()
+        d["eventos"] += [Evento(T.TERMINO_FORNECIDO),
+                        Evento(T.FECHAMENTO_DECLARADO),
+                        Evento(T.RECURSOS_INCERTOS)]
+        r = executar_fluxo(d)
+        self.assertFalse(r.encerramento_comprovado)
+        self.assertFalse(r.eventos.fechamento_declarado)
+        self.assertIn(G.ENCERRAMENTO_NAO_COMPROVADO, r.estados)
+
+    def test_validade_forjada_no_envelope_rejeitada(self):
+        d = entrada()
+        d["validade_estrutural"] = True
+        r = executar_fluxo(d)
+        self.assertIsNone(r.recepcao)
+        self.assertFalse(r.valido_estruturalmente)
+        self.assertFalse(r.registro.validade_estrutural)
+        self.assertIn(M.ENTRADA_FLUXO_INVALIDA, r.motivos)
+
+    def test_autorizacao_operacional_forjada_no_envelope(self):
+        d = entrada()
+        d["operacao_autorizada"] = True
+        r = executar_fluxo(d)
+        self.assertFalse(r.operacao_autorizada)
+        self.assertIn(M.ENTRADA_FLUXO_INVALIDA, r.motivos)
+
+    def test_destino_aprovado_forjado_no_payload(self):
+        d = entrada()
+        p = documento()
+        p["destino_aprovado"] = True
+        d["conteudo"] = json.dumps(p).encode()
+        r = executar_fluxo(d)
+        self.assertFalse(r.valido_estruturalmente)
+        self.assertFalse(r.registro.destino_aprovado)
+
+    def test_dados_livres_nao_permitidos_nao_ecoam(self):
+        d = entrada()
+        d["payload_livre"] = "SEGREDO_SINTETICO_DEV2"
+        r = executar_fluxo(d)
+        self.assertIsNone(r.origem)
+        self.assertNotIn("SEGREDO_SINTETICO_DEV2", repr(r))
+        self.assertNotIn("SEGREDO_SINTETICO_DEV2", json.dumps(r.registro.como_dict()))
+
+    def test_combinacao_preserva_todos_os_adversos(self):
+        d = entrada()
+        d["conteudo"] = b'{"versao":'
+        d["sha256_esperado"] = "0" * 64
+        d["eventos"].append(Evento(T.INTERRUPCAO_FORNECIDA))
+        r = executar_fluxo(d)
+        self.assertIn(G.EVIDENCIA_INCOMPLETA, r.estados)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+        self.assertIn(G.EXECUCAO_INTERROMPIDA, r.estados)
+        self.assertIn(M.ORIGEM_DIVERGENTE, r.motivos)
+
+    def test_payload_extra_sintetico_nao_aparece_no_registro(self):
+        d = entrada()
+        p = documento()
+        p["dados"] = "NAO_ECOAR_DEV2_SINTETICO"
+        d["conteudo"] = json.dumps(p).encode()
+        r = executar_fluxo(d)
+        self.assertNotIn("NAO_ECOAR_DEV2_SINTETICO", repr(r))
+        self.assertNotIn("NAO_ECOAR_DEV2_SINTETICO",
+                         json.dumps(r.registro.como_dict()))
+
+    def test_limite_de_bytes(self):
+        d = entrada()
+        d["conteudo"] = b" " * (MAX_BYTES + 1)
+        r = executar_fluxo(d)
+        self.assertIn(M.LIMITE_EXCEDIDO, r.motivos)
+        self.assertFalse(r.valido_estruturalmente)
+
+    def test_limite_de_eventos(self):
+        d = entrada()
+        d["eventos"] = [Evento(T.INICIO_DECLARADO)] * (MAX_EVENTOS + 1)
+        r = executar_fluxo(d)
+        self.assertIn(M.LIMITE_EXCEDIDO, r.motivos)
+        self.assertEqual(r.registro.quantidade_eventos, 0)
+
+    def test_consistencia_entre_resultado_e_registro(self):
+        d = entrada()
+        d["eventos"].append(Evento(T.SAIDA_FORNECIDA))
+        r = executar_fluxo(d)
+        self.assertEqual(r.registro.estados, tuple(e.value for e in r.estados))
+        self.assertEqual(r.registro.motivos, tuple(m.value for m in r.motivos))
+        self.assertIs(r.registro.validade_estrutural, r.valido_estruturalmente)
+        self.assertEqual(r.registro.quantidade_verificacoes,
+                         r.recepcao.quantidade_verificacoes)
+        self.assertEqual(r.registro.quantidade_eventos,
+                         r.eventos.quantidade_aplicados)
+
+    def test_caminho_integrado_nao_abre_arquivo_nem_imprime(self):
+        d = entrada()
+        with patch("builtins.open", side_effect=AssertionError("IO_NAO_PERMITIDO")) as op:
+            with patch("builtins.print") as imprimir:
+                r = executar_fluxo(d)
+        self.assertTrue(r.registro_disponivel)
+        op.assert_not_called()
+        imprimir.assert_not_called()
+
+    def test_fluxo_completo_com_todas_as_flags_false(self):
+        d = entrada()
+        d["eventos"] += [Evento(T.SAIDA_FORNECIDA, 1),
+                        Evento(T.TERMINO_FORNECIDO, 2),
+                        Evento(T.FECHAMENTO_DECLARADO, 2)]
+        r = executar_fluxo(d)
+        for nome in ("destino_aprovado", "custodia_autorizada", "operacao_autorizada",
+                     "prontidao_operacional", "origem_autenticada",
+                     "autorizacao_comprovada", "encerramento_comprovado"):
+            with self.subTest(flag=nome):
+                self.assertIs(getattr(r, nome), False)
+                self.assertIs(r.registro.como_dict()[nome], False)
+
+    def test_exportacao_mutavel_nao_modifica_resultado_imutavel(self):
+        r = executar_fluxo(entrada())
+        exportado = r.registro.como_dict()
+        exportado["destino_aprovado"] = True
+        exportado["estados"].append("DESTINO_APROVADO")
+        self.assertFalse(r.registro.destino_aprovado)
+        self.assertNotIn("DESTINO_APROVADO", r.registro.estados)
+        with self.assertRaises(FrozenInstanceError):
+            r.registro.validade_estrutural = False
+
+    def test_envelope_invalido_nao_fabrica_resultados_de_componentes(self):
+        r = executar_fluxo(None)
+        self.assertIsNone(r.origem)
+        self.assertIsNone(r.contexto)
+        self.assertIsNone(r.recepcao)
+        self.assertIsNone(r.eventos)
+        self.assertFalse(r.registro.validade_estrutural)
+
+    def test_falha_de_montagem_nao_ecoada_nem_vira_sucesso(self):
+        d = entrada()
+        d["eventos"].append(Evento(T.INTERRUPCAO_FORNECIDA))
+        with patch("alternativa_python.fluxo.registro._projetar_integrado",
+                   side_effect=ValueError("ERRO_SINTETICO_NAO_ECOAR")):
+            r = executar_fluxo(d)
+        self.assertFalse(r.registro_disponivel)
+        self.assertIsNone(r.registro)
+        self.assertIn(M.REGISTRO_INDISPONIVEL, r.motivos)
+        self.assertIn(G.EXECUCAO_INTERROMPIDA, r.estados)
+        self.assertNotIn("ERRO_SINTETICO_NAO_ECOAR", repr(r))
+
+    def test_registro_que_forge_validade_e_recusado(self):
+        correto = executar_fluxo(entrada()).registro
+        adulterado = replace(correto, validade_estrutural=False)
+        with patch("alternativa_python.fluxo.registro._projetar_integrado",
+                   return_value=adulterado):
+            r = executar_fluxo(entrada())
+        self.assertTrue(r.valido_estruturalmente)  # Retorno real de D.
+        self.assertIsNone(r.registro)  # Não aceita registro divergente.
+        self.assertIn(M.REGISTRO_INDISPONIVEL, r.motivos)
+
+    def test_bytes_contexto_e_eventos_do_chamador_preservados(self):
+        d = entrada()
+        b = bytes(d["conteudo"])
+        ctx = dict(d["contexto"])
+        evs = list(d["eventos"])
+        executar_fluxo(d)
+        self.assertEqual(d["conteudo"], b)
+        self.assertEqual(d["contexto"], ctx)
+        self.assertEqual(d["eventos"], evs)
```

### tests/test_casos_adversos_dev2.py

```diff
--- /dev/null
+++ DEV2/tests/test_casos_adversos_dev2.py
@@ -0,0 +1,202 @@
+import json
+import unittest
+from dataclasses import replace
+from unittest.mock import patch
+from alternativa_python.fluxo import executar_fluxo
+from alternativa_python.contratos import (
+    VERSAO, MAX_TEXTO_CONTEXTO, Evento, TipoEvento as T,
+    EstadoG10 as G, Motivo as M, EstadoContexto,
+)
+
+
+def documento():
+    return {
+        "versao": VERSAO, "sintetico": True, "documento_real": False,
+        "resultado": "INCONCLUSIVO",
+        "verificacoes": [{"id": "S01", "estado": "INCONCLUSIVO"}],
+        "recursos_encerrados": None, "destino_aprovado": False,
+        "custodia_autorizada": False, "operacao_autorizada": False,
+    }
+
+
+def entrada():
+    return {
+        "conteudo": json.dumps(documento()).encode(),
+        "sha256_esperado": None,
+        "contexto": {
+            "referencia": "REF_SINTETICA_B", "finalidade": "OBSERVACAO_LIMITADA",
+            "autorizacao_declarada": True, "operador_declarado": True,
+            "escopo_declarado": True, "vigencia_declarada": True,
+        },
+        "eventos": [Evento(T.INICIO_DECLARADO)],
+    }
+
+
+class CasosAdversosTests(unittest.TestCase):
+    def test_json_muito_profundo(self):
+        d = entrada()
+        d["conteudo"] = b"[" * 1500 + b"0" + b"]" * 1500
+        r = executar_fluxo(d)
+        self.assertIn(M.LIMITE_EXCEDIDO, r.motivos)
+        self.assertFalse(r.valido_estruturalmente)
+
+    def test_json_chave_duplicada_aninhada(self):
+        d = entrada()
+        d["conteudo"] = b'{"x":{"id":1,"id":2}}'
+        self.assertIn(M.CHAVE_DUPLICADA, executar_fluxo(d).motivos)
+
+    def test_constantes_nao_json(self):
+        for constante in (b"NaN", b"Infinity", b"-Infinity"):
+            with self.subTest(constante=constante):
+                d = entrada()
+                d["conteudo"] = b'{"x":' + constante + b"}"
+                self.assertIn(M.VALOR_NAO_JSON, executar_fluxo(d).motivos)
+
+    def test_utf8_invalido(self):
+        d = entrada()
+        d["conteudo"] = b"\xff"
+        self.assertIn(M.CODIFICACAO_INVALIDA, executar_fluxo(d).motivos)
+
+    def test_json_raiz_nao_objeto(self):
+        d = entrada()
+        d["conteudo"] = b"true"
+        self.assertFalse(executar_fluxo(d).valido_estruturalmente)
+
+    def test_colecao_excede_nos(self):
+        d = entrada()
+        d["conteudo"] = b"[" + b"0," * 299 + b"0]"
+        self.assertIn(M.LIMITE_EXCEDIDO, executar_fluxo(d).motivos)
+
+    def test_inteiro_extremo_nega_estrutura_sem_vazamento(self):
+        d = entrada()
+        d["conteudo"] = b'{"x":' + b"9" * 8000 + b"}"
+        r = executar_fluxo(d)
+        self.assertFalse(r.valido_estruturalmente)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+        self.assertNotIn("9" * 100, repr(r))
+
+    def test_conteudo_tipo_python_incompativel(self):
+        d = entrada()
+        d["conteudo"] = ["PAYLOAD_SINTETICO_NAO_ECOAR"]
+        r = executar_fluxo(d)
+        self.assertIn(M.TIPO_ENTRADA_INVALIDO, r.motivos)
+        self.assertNotIn("PAYLOAD_SINTETICO_NAO_ECOAR", repr(r))
+
+    def test_subclasse_de_dict_nao_invoca_getitem_hostil(self):
+        class DictSintetico(dict):
+            def __getitem__(self, key):
+                raise AssertionError("NAO_DEVE_SER_CHAMADO")
+        r = executar_fluxo(DictSintetico(entrada()))
+        self.assertIn(M.ENTRADA_FLUXO_INVALIDA, r.motivos)
+        self.assertIsNone(r.recepcao)
+
+    def test_chave_nao_string_em_contexto(self):
+        d = entrada()
+        d["contexto"] = {1: "CONTEXTO_SINTETICO_NAO_ECOAR"}
+        r = executar_fluxo(d)
+        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INVALIDA)
+        self.assertNotIn("CONTEXTO_SINTETICO_NAO_ECOAR", repr(r))
+
+    def test_hash_referencia_tipo_incompativel(self):
+        d = entrada()
+        d["sha256_esperado"] = ["HASH_SINTETICO_INVALIDO"]
+        r = executar_fluxo(d)
+        self.assertIn(M.REFERENCIA_ORIGEM_INVALIDA, r.motivos)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+        self.assertNotIn("HASH_SINTETICO_INVALIDO", repr(r))
+
+    def test_referencia_contexto_desconhecida_nao_ecoada(self):
+        d = entrada()
+        d["contexto"]["referencia"] = "REFERENCIA_SINTETICA_FORA_LISTA"
+        r = executar_fluxo(d)
+        self.assertIn(M.CONTEXTO_INVALIDO, r.motivos)
+        self.assertIsNone(r.registro.referencia)
+
+    def test_duracao_negativa(self):
+        d = entrada()
+        d["eventos"] = [Evento(T.INICIO_DECLARADO, -1)]
+        self.assertIn(M.DURACAO_INVALIDA, executar_fluxo(d).motivos)
+
+    def test_duracoes_nao_finitas(self):
+        for duracao in (float("nan"), float("inf"), float("-inf")):
+            with self.subTest(duracao=duracao):
+                d = entrada()
+                d["eventos"] = [Evento(T.INICIO_DECLARADO, duracao)]
+                r = executar_fluxo(d)
+                self.assertIn(M.DURACAO_INVALIDA, r.motivos)
+                self.assertFalse(r.encerramento_comprovado)
+
+    def test_booleano_nao_e_duracao(self):
+        d = entrada()
+        d["eventos"] = [Evento(T.INICIO_DECLARADO, True)]
+        self.assertIn(M.DURACAO_INVALIDA, executar_fluxo(d).motivos)
+
+    def test_duracao_regressiva(self):
+        d = entrada()
+        d["eventos"] = [Evento(T.INICIO_DECLARADO, 5), Evento(T.SAIDA_FORNECIDA, 4)]
+        r = executar_fluxo(d)
+        self.assertIn(M.DURACAO_INVALIDA, r.motivos)
+        self.assertEqual(r.eventos.quantidade_aplicados, 1)
+
+    def test_evento_tipo_invalido(self):
+        d = entrada()
+        d["eventos"] = [{"tipo": "INICIO_DECLARADO"}]
+        r = executar_fluxo(d)
+        self.assertIn(M.EVENTO_INVALIDO, r.motivos)
+        self.assertIn(G.EVIDENCIA_INCOMPATIVEL, r.estados)
+
+    def test_ids_duplicados_em_verificacoes(self):
+        d = entrada()
+        p = documento()
+        p["verificacoes"] *= 2
+        d["conteudo"] = json.dumps(p).encode()
+        self.assertFalse(executar_fluxo(d).valido_estruturalmente)
+
+    def test_resultado_diverge_de_impedimento(self):
+        d = entrada()
+        p = documento()
+        p["verificacoes"][0]["estado"] = "IMPEDIMENTO"
+        d["conteudo"] = json.dumps(p).encode()
+        self.assertFalse(executar_fluxo(d).valido_estruturalmente)
+
+    def test_validade_extra_no_payload_recusada(self):
+        d = entrada()
+        p = documento()
+        p["validade_estrutural"] = True
+        d["conteudo"] = json.dumps(p).encode()
+        r = executar_fluxo(d)
+        self.assertFalse(r.valido_estruturalmente)
+        self.assertFalse(r.registro.validade_estrutural)
+
+    def test_montagem_de_registro_retorna_tipo_invalido(self):
+        with patch("alternativa_python.fluxo.registro._projetar_integrado",
+                   return_value={"payload": "SEGREDO_SINTETICO_DEV2"}):
+            r = executar_fluxo(entrada())
+        self.assertIsNone(r.registro)
+        self.assertIn(M.REGISTRO_INDISPONIVEL, r.motivos)
+        self.assertNotIn("SEGREDO_SINTETICO_DEV2", repr(r))
+
+    def test_montagem_de_registro_adiciona_texto_arbitrario(self):
+        original = executar_fluxo(entrada()).registro
+        falso = replace(original, motivos=("ERRO_SINTETICO_NAO_ECOAR",))
+        with patch("alternativa_python.fluxo.registro._projetar_integrado",
+                   return_value=falso):
+            r = executar_fluxo(entrada())
+        self.assertIsNone(r.registro)
+        self.assertNotIn("ERRO_SINTETICO_NAO_ECOAR", repr(r))
+
+    def test_contexto_textual_excessivo_recusado(self):
+        d = entrada()
+        d["contexto"]["referencia"] = "X" * (MAX_TEXTO_CONTEXTO + 1)
+        r = executar_fluxo(d)
+        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INVALIDA)
+        self.assertIsNone(r.registro.referencia)
+        self.assertFalse(r.autorizacao_comprovada)
+
+    def test_autorizacao_comprovada_forjada_no_contexto(self):
+        d = entrada()
+        d["contexto"]["autorizacao_comprovada"] = True
+        r = executar_fluxo(d)
+        self.assertEqual(r.contexto.estado, EstadoContexto.DECLARACAO_INVALIDA)
+        self.assertFalse(r.autorizacao_comprovada)
+        self.assertFalse(r.registro.autorizacao_comprovada)
```

## Preservação e parada

Nenhum código alterado depois da execução completa de 129 testes; documentos de
evidência gerados depois não modificam código ou testes. C/H3-F-R1, produto,
Windows, dados privados, Git, publicação e custódia não foram operados.
Auditoria independente desta entrega pendente; sem DEV-3 automático.
