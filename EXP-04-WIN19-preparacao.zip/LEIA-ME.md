# EXP-04 / WIN-19 — primeira entrega para revisão

**PREPARAÇÃO, SEM EXECUÇÃO NOVA.** Não rodar os testes por inferência da entrega.
A execução depende da revisão/autorização do usuário. A política DACL está
PARA_APROVAÇÃO; nenhum teste entre contas, ACL ou privilégio foi alterado/exercitado.

## Entregáveis principais

- RELATORIO_PROVENIENCIA_WIN19.md — fontes, o que foi conferido e o que falta.
- MATRIZ_WIN19_RECONCILIADA.csv — 19 linhas, todos vínculos PROVISORIO_SEM_FONTE;
  eixos separados, nenhum controle promovido por cleanup/Linux/inspeção.
- PLANO_NATIVO_WIN19.md — pré-condições, casos independentes, limites e parada.
- ESPECIFICACAO_DACL_PROPOSTA.md — papéis, objetos, operações, integração e decisões.
- MANIFESTO_EVIDENCIAS_WIN19.json — hashes calculados versus apenas declarados;
  locais sanitizados, sem documentos reais, nomes de conta, SIDs ou SDDL.

## Apoio à auditoria

- fontes_recebidas/ — cópias byte a byte dos três anexos, sem reescrita.
- fontes_consultadas/ — mapa/documentação antigos PROVISÓRIOS, não evidência nativa.
- REFERENCIA_R1_FIX_470_SHA256.json — mesma referência e SHA declarados no termo.
- RECONCILIACAO_WIN19.json — 0 confirmados, 19 provisórios, sem JUnit Windows original.
- INVENTARIO_ASSERCOES_WIN19.json — asserções/linhas/AST versus BPQ-04.
- FICHAS_TESTES_NATIVOS_WIN19.json — 19 protocolos propostos, inclusive DACL bloqueada.
- INDICE_JUNIT_CONSULTADOS.json — JUnit locais Linux, sem aprovação Windows;
  um XML antigo inválido foi preservado sem ser usado para pareamento.
- testes_propostos/ — código de cenários independentes com entradas sintéticas,
  sem importar testes/fixtures legados. Inclui limites explicitamente descritos.
  Não foi executado nem coletado. A trava padrão impede avaliação dos corpos.
- tools/preflight_win19.ps1 e .py — somente leitura; nenhum dado pessoal na saída;
  não cria link/alias/pasta/conta, não altera registro, ACL ou política.
- tools/extrair_junit_historico.py — índice protegido/sanitizado, sem declarar
  origem Windows por contagem ou confirmar vínculos automaticamente.
- PRESERVACAO_FINAL.json — candidatos, pacotes e Git anteriores preservados.
- VERIFICACAO_PREPARACAO.json — somente estrutura/sintaxe em memória, não testes.
- MANIFESTO_ARQUIVOS_ENTREGA_SHA256.json — hashes da entrega, exceto ele próprio.

## O que permanece pendente

Os dois ZIPs Windows citados no encerramento não foram anexados; seus hashes
não foram recalculados pelo Codex. O JUnit EXP-04 original (19 falhas/sete skips)
ainda está ausente. Não confundir com o fechamento 36 PASS/3 SKIP de cleanup.
O manifesto local de 470 caminhos coincide com o SHA declarado no termo, mas
isso não reproduz a verificação dos arquivos no computador Windows do usuário.

Os cenários novos precisam de revisão antes de executar. WIN-14/16 e a falha
real da API têm complementos explícitos; WIN-18/19 dependem da política e tokens
reais aprovados. Não interpretar os marcadores bloqueados como testes de acesso.
A quantidade prevista de 21 casos expande 19 IDs; não é coleta efetuada.

Em rodada futura, usar Python 3.12/UTF-8, sem bytecode/cache dentro da candidata
(PYTHONDONTWRITEBYTECODE=1 e -B; pytest -p no:cacheprovider), basetemp novo curto
exclusivo fora do Git, manifests 470 antes/depois e sanitização de cópias de logs.
Não passar uma pasta preexistente de dados a --basetemp: pytest pode apagá-la.
Esta entrega não oferece um lançador automático nem executa tal comando.

Sem commit, push, merge, PR ou publicação. Residual antigo não acessado.
Homologação DACL/Windows NÃO_VALIDADO e conversões reais BLOQUEADAS.
