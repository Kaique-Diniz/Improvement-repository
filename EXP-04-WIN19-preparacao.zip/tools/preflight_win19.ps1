param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Candidata,
    [Parameter(Mandatory=$true)][string]$Manifesto,
    [Parameter(Mandatory=$true)][string]$AreaPrevista
)
$ErrorActionPreference = 'Stop'
# Somente o ambiente deste processo; restaurado ao sair. Não altera registro/políticas.
$Utf8Anterior = [Environment]::GetEnvironmentVariable('PYTHONUTF8', 'Process')
$BytecodeAnterior = [Environment]::GetEnvironmentVariable('PYTHONDONTWRITEBYTECODE', 'Process')
try {
    $env:PYTHONUTF8 = '1'
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $Sonda = Join-Path $PSScriptRoot 'preflight_win19.py'
    & $Python -B $Sonda --candidata $Candidata --manifesto $Manifesto --area-prevista $AreaPrevista
    $CodigoPreflight = $LASTEXITCODE
}
finally {
    [Environment]::SetEnvironmentVariable('PYTHONUTF8', $Utf8Anterior, 'Process')
    [Environment]::SetEnvironmentVariable('PYTHONDONTWRITEBYTECODE', $BytecodeAnterior, 'Process')
}
if ($CodigoPreflight -ne 0) { throw 'WIN19_PREFLIGHT_BLOQUEADO_VER_JSON_SANITIZADO' }
