"""Extrair índices do JUnit sem executar testes nem confirmar vínculo automaticamente.

Mensagens/tracebacks brutos NÃO são impressos. Nodeids fora da lista proposta
são representados por SHA; devem ser inspecionados em custódia privada antes
 de partilha. Contagens não provam origem Windows ou correspondência histórica.
"""
import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
import re
from defusedxml import ElementTree as ET


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--junit',type=Path,required=True)
    p.add_argument('--referencia',type=Path,required=True)
    a=p.parse_args()
    try:
        reference=list(csv.DictReader(a.referencia.read_text(encoding='utf-8-sig').splitlines(),delimiter=';'))
        known={r['nodeid_proposto_D2']:r['id'] for r in reference}
        raw=a.junit.read_bytes()
        if len(raw)>32*1024*1024:raise ValueError()
        root=ET.fromstring(raw);cases=[]
        for c in root.iter('testcase'):
            name=c.get('classname','').replace('.','/')+'.py::'+c.get('name','')
            failed=c.find('failure');error=c.find('error');skip=c.find('skipped')
            event=failed if failed is not None else error
            status='FALHOU' if event is not None else 'NÃO_VALIDADO' if skip is not None else 'APROVADO_NO_JUNIT_NAO_ATRIBUIDO_A_CONTROLE'
            row=dict(id_proposto=known.get(name),nodeid_exato=name if name in known else None,
                     nodeid_sha256=sha256(name.encode('utf-8')).hexdigest(),estado_no_arquivo=status,
                     mensagem_sha256=sha256((event.text or '').encode('utf-8')).hexdigest() if event is not None else None,
                     motivo_skip_sha256=sha256((skip.get('message','')+(skip.text or '')).encode('utf-8')).hexdigest() if skip is not None else None)
            if event is not None:
                # Só números Win32, não o restante da mensagem privada.
                row['win32_mencionados']=sorted({int(n) for n in re.findall(r'\[WinError (\d+)\]',event.text or '')})
            cases.append(row)
        output={'junit_sha256':sha256(raw).hexdigest(),'casos':cases,'quantidade':len(cases),
                'falhas_erros':sum(c['estado_no_arquivo']=='FALHOU' for c in cases),
                'skips':sum(c['estado_no_arquivo']=='NÃO_VALIDADO' for c in cases),
                'origem_windows_comprovada':False,'vinculo_historico':'PROVISORIO_SEM_FONTE_VALIDADA',
                'homologacao_DACL':'NÃO_VALIDADO','observacao':'Revisor deve conferir origem, versão, parâmetros, tracebacks e sete motivos; igualdade textual não basta.'}
        print(json.dumps(output,ensure_ascii=True));return 0
    except Exception:
        print('{"estado":"BLOQUEADO","codigo":"JUNIT_OU_REFERENCIA_INVALIDOS"}');return 2


if __name__=='__main__':raise SystemExit(main())
