"""Preparação apenas: nada roda sem revisão/autorização posterior explícita."""
import os
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import stat
import sys
import pytest


def pytest_addoption(parser):
    parser.addoption('--win19-plano-revisado', action='store_true', default=False)
    parser.addoption('--win19-candidata', default=None)


def pytest_configure(config):
    config.addinivalue_line('markers', 'win19(id, eixo): vínculo lógico proposto; não confirma vínculo histórico')
    if config.getoption('--win19-plano-revisado') and os.name == 'nt':
        root = config.getoption('--win19-candidata')
        if not root:
            raise pytest.UsageError('CANDIDATA_NAO_INFORMADA')
        package = Path(__file__).absolute().parents[1]
        manifest = package/'REFERENCIA_R1_FIX_470_SHA256.json'
        raw = manifest.read_bytes()
        if sha256(raw).hexdigest() != 'a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c':
            raise pytest.UsageError('MANIFESTO_REFERENCIA_DIVERGENTE')
        spec = importlib.util.spec_from_file_location('win19_preflight_guard', package/'tools/preflight_win19.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        expected = json.loads(raw)['arquivos']
        if len(expected) != 470 or module.hashes(Path(root)) != expected:
            raise pytest.UsageError('INTEGRIDADE_CANDIDATA_DIVERGENTE')
        config._win19_integrity = (module, Path(root), expected)


def pytest_sessionfinish(session, exitstatus):
    state = getattr(session.config, '_win19_integrity', None)
    if state:
        module, root, expected = state
        try:
            intact = module.hashes(root) == expected
        except Exception:
            intact = False
        if not intact:
            session.exitstatus = 2


def pytest_collection_modifyitems(config, items):
    allowed = config.getoption('--win19-plano-revisado') and os.name == 'nt'
    if not allowed:
        reason = 'PREPARACAO_SEM_AUTORIZACAO_OU_WINDOWS; NAO_VALIDADO'
        for item in items:
            item.add_marker(pytest.mark.skip(reason=reason))


@pytest.fixture
def lab(tmp_path, request):
    # Esta fixture só é avaliada após a marca de proteção de coleção acima.
    if not request.config.getoption('--win19-plano-revisado') or os.name != 'nt':
        pytest.skip('PREPARACAO_APENAS; NAO_VALIDADO')
    candidate = request.config.getoption('--win19-candidata')
    if not candidate:
        pytest.fail('CANDIDATA_NAO_INFORMADA', pytrace=False)
    for node in (tmp_path, *tmp_path.parents):
        st = node.lstat()
        if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
            pytest.fail('AREA_CONTEM_LINK_REPARSE', pytrace=False)
        if os.path.lexists(node/'.git'):
            pytest.fail('AREA_DENTRO_GIT', pytrace=False)
    # Conferência do manifesto é pré-condição do roteiro; não confiar só no HEAD.
    root = Path(candidate).absolute()
    sys.path.insert(0, str(root))
    sys.path.insert(0, str(root/'src'))
    marker = request.node.get_closest_marker('win19')
    control = marker.args[0] if marker else request.node.callspec.params['id_']
    request.node.user_properties.append(('win19_id_proposto', control))
    request.node.user_properties.append(('DACL_efetiva', 'NÃO_VALIDADO'))
    return tmp_path
