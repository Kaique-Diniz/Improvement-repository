# Plano nativo WIN-01 a WIN-19 — PRIMEIRA ENTREGA, NÃO EXECUTADO

## Ponto de parada e natureza

Esta entrega prepara reconciliação, matriz, scripts e cenários; não autoriza
sua execução. A candidata R1-FIX de 470 caminhos foi reconstruída em worktree
Linux separada, SEM alterar um único arquivo da referência. Todos os artefatos
WIN19 ficam fora dela. Não foi executado pytest, sequer coleta de casos, nem
preflight nativo, sonda de link, acesso entre contas ou operação DACL.

Recebidos os três documentos do usuário. O fechamento 1 PASS/3 PASS/36 PASS +
3 SKIP é documentado pelo termo, não executado novamente nem convertido em
aprovação WIN19. A suíte de cleanup, seus sete nativos e os 19 vínculos têm
objetivos diferentes. Nenhuma soma dessas quantidades significa cobertura única.

A matriz mantém 19 PROVISORIO_SEM_FONTE; faltam JUnit/log/relatório originais
EXP-04 com 2.842 casos/19 falhas/7 skips. Não confundir com os 38 históricos
BPQ-04 ou os 39 casos de cleanup. Fichas em FICHAS_TESTES_NATIVOS_WIN19.json.

## 1. Pré-validação somente leitura — revisar antes de usar

`tools/preflight_win19.ps1` chama `preflight_win19.py` com Python 3.12/UTF-8,
sem instalar, criar pastas, links, aliases, contas, ACLs ou arquivos de log.
O script só emite JSON sanitizado no stdout. Não expõe nomes/SIDs/SDDL/caminhos
pessoais. Não lê conteúdo de documentos privados nem o residual histórico.

Verifica os 470 hashes e extras, ancestrais sem links/reparse, baseline Git,
resumo/hash do estado Git, Windows/build, tipo/capacidade do volume, elevação e
estado do privilégio symlink do token (TOKEN_QUERY), Developer Mode só por
consulta e alias 8.3 de um arquivo JÁ EXISTENTE. Repete hashes após a coleta.
Não chama AdjustTokenPrivileges, Set-Acl, fsutil de alteração ou ferramentas
que exijam elevar privilégios. Não interpreta capacidades como segurança aprovada.

A área prevista deve ser uma filha NOVA `WIN19-...` do LocalAppData registrado
no Shell, sem sobreposição à candidata. O preflight não a cria. Se já existir,
preserva e bloqueia para evitar reutilização. Repetições sem mudanças de ambiente
não acumulam efeitos. Token elevado bloqueia. ReFS é inventariado, mas o plano
atual de DACL exige NTFS; uma variante ReFS precisa de revisão, não mudança do volume.

Privilégio ausente/Developer Mode desativado apenas indicam capacidade observada.
Não provar symlink pela leitura do token nem concluir que um alias novo será
gerado porque um alias existente foi observado. A futura criação sintética é
outro passo, ainda condicionado à revisão. WinError 1314 segue NÃO_VALIDADO.

Exemplo para FUTURA pré-validação, após revisão, em PowerShell comum:

```powershell
# Ajustar somente caminhos locais; não executar testes nesta primeira entrega.
$Python = 'C:\caminho\venv\Scripts\python.exe'
$Pacote = Join-Path $env:LOCALAPPDATA 'WIN19-preparacao'
$Candidata = Join-Path $env:LOCALAPPDATA 'WIN19-candidata'
$Manifesto = Join-Path $Pacote 'REFERENCIA_R1_FIX_470_SHA256.json'
$AreaPrevista = Join-Path $env:LOCALAPPDATA 'WIN19-LAB-IDENTIFICADOR_NOVO'
& (Join-Path $Pacote 'tools\preflight_win19.ps1') -Python $Python -Candidata $Candidata -Manifesto $Manifesto -AreaPrevista $AreaPrevista
```

Nenhuma alteração de política de execução do PowerShell é instruída. Se a
política impedir rodar o script, registrar impedimento; não usar Bypass para
contornar a política nem mudar configuração persistente. `prontidao_para_executar`
permanece false até a revisão/autorizações externas; retorno 0 do preflight só
significa coleta concluída, não aprovação de controles.

## 2. Reconstrução futura e LF em Git descendente

Preservar todas as candidatas existentes. Se for necessária nova reconstrução
Windows, usar o pacote R1-FIX já aprovado de SHA-256
`1fe4edaf22deab3b6ae7143e3969b810e91421a3c5467b45685ad3baa750e345`,
base `770d062d29c4361d6932592883df9339bb4089bc`, destino NOVO.
O presente pacote WIN19 não altera/reempacota aquela candidata nem corrige seu motor.

Impor `core.autocrlf=false` e `core.eol=lf` no ambiente do processo ANTES de
worktree add E antes de iniciar o reconstrutor Python, para atingir também
os Git descendentes. Uma chamada `git -c` no worktree add isoladamente não basta.
Procedimento a revisar, sem alterar configuração persistente:

1. Guardar em memória os valores/existência de GIT_CONFIG_COUNT e dos novos pares
   GIT_CONFIG_KEY_n/GIT_CONFIG_VALUE_n; não imprimir valores existentes.
2. Ler o count atual n (zero se ausente), adicionar dois pares: core.autocrlf=false
   e core.eol=lf, count n+2. Não sobrescrever pares preexistentes.
3. Dentro de try, executar worktree add detached e o reconstrutor original
   com esse ambiente herdado por Python e subprocessos Git.
4. No finally, restaurar exatamente os valores anteriores/remover variáveis
   antes inexistentes. Não executar git config --global/--local.
5. Conferir todos os 470 hashes. Em divergência, preservar tentativa e bloquear;
   não sobrescrever arquivos divergentes, converter quebras silenciosamente ou
   considerar HEAD sozinho como prova dos bytes.

Nenhuma reconstrução Windows foi executada nesta primeira entrega.

## 3. Ensaios independentes preparados

Código em `testes_propostos/`, sem importar testes ou fixtures da suíte legada.
Usa as APIs reais da candidata e entradas geradas do zero, somente sintéticas.
A geração de PDF usa o utilitário público `examples.fase2.gerar_demo.pdf_sintetico`.
Não há execução, coleta nem aprovação desse código nesta etapa. A conferência
realizada foi só AST/sintaxe em memória e inspeção dos contratos de entrada.

Existem 19 IDs lógicos, com expansão PREVISTA de 21 casos: WIN-11 separa Git e
symlink; WIN-13 separa link interno/externo. Isso não é coleta executada.
WIN-18/19 são marcadores BLOQUEADOS e protocolos para política/tokens; não há
código de impersonação, mudança de ACL ou tentativa entre contas.

Proteção contra execução acidental: sem `--win19-plano-revisado` OU sem Windows,
a coleção proposta é marcada NÃO_VALIDADO por skip. Essa flag é só uma trava
operacional, NÃO substitui a autorização explícita do usuário. A futura execução
confere os 470 hashes antes de carregar a candidata e após a sessão; mudança
faz o processo falhar. O basetemp futuro deve ser novo, curto, sintético e fora
Git; o roteiro não cria nem limpa essa área automaticamente nesta entrega.

### API — WIN-01 a WIN-05

Usar Kernel32 real e a implementação Windows da candidata, sem monkeypatch.
Alias 8.3 efetivo, ordinal Unicode/não BMP, hardlink com mesmo file ID e nomes
diferentes. WIN-01/05 testam flags diagnósticas e baseline sintético; NÃO leem
DACL efetiva. NUL recusado e normalização de caminho inexistente cobrem falha
fechada de entrada/metadados, NÃO comprovam retorno 0 forçado de CompareStringOrdinal.
Esse ramo de falha de API real continua pendente de estratégia segura revisada;
mocks desse retorno só seriam testes de instrumentação, sem aprovar o controle.
Não propor entrada de ponteiro inválido ou corrupção de memória para induzir falha.

### LINK — WIN-06 a WIN-14

Cada caso começa com controle positivo sem link, insere um link real e exige
recusa + bytes/snapshot externo iguais. Os cinco alvos BBZ incluem diretórios
reais externos para evidencias/cabecas, não só links para um arquivo.
O helper só transforma WinError 1314 em NÃO_VALIDADO; outros erros falham.
O symlink deve estar efetivamente criado e apontar ao alvo controlado.

Remover apenas a entrada de link recém-criada, com identidade conferida; não
usar rmtree, resolver caminho para apagar destino ou limpar árvores de terceiros.
Preservar laboratório e evidências quando houver troca de identidade/divergência.
Não criar links para arquivos privados, candidatos auditados ou resíduos antigos.

WIN-12 cria fonte e acervo/evento assinado por APIs reais; verifica consultar
antes do ataque e recusa em ler_fonte/consultar depois. WIN-14 cobre conferir_fontes, faltando gravar_pacote com
autoridade/recibo reais. As fichas especificam esses complementos obrigatórios.
Aprovação do componente NÃO aprova o fluxo integral. WIN-13 exige códigos
diferentes conforme destino: interno -> FONTE_CONTEM_LINK; externo ->
FONTE_FORA_DA_AREA_AUTORIZADA, pela ordem real de validação da candidata.

Junction externa deve ter ensaio adicional separado (JUNC-EXTRA), não contado
como um dos nove symlinks. Após revisão, criar somente junction de laboratório,
provar reparse e destino, exigir recusa do leitor e bytes externos iguais;
remover só a junction. Junction interna e raízes redirecionadas exigem contrato
explícito adicional; não impor rejeição universal nem mudar leitor nesta etapa.

### MODO/CHMOD — WIN-15 a WIN-19

WIN-15 testa opt-in de canônicos em três PDFs sintéticos e preservação das fontes.
Seu gabarito é derivado do leitor apenas para o contrato do comparador/opção;
não prova extração financeira, identidade real ou DACL.
WIN-16 testa conflito no domínio/exportação/escritor sem mock; falta o CLI
integral com origem documental que produza conflito de verdade, conforme ficha.
WIN-17 testa roundtrip e bytes do JSON. Não inferir proteção de 0600, replace ou
sucesso desses fluxos. A política DACL proposta é entrega separada PARA_APROVAÇÃO.

WIN-18/19: testes POSIX legados podem ser NÃO_APLICÁVEL no Windows, mas o controle
Windows continua NÃO_VALIDADO. Os protocolos nativos DACL-FONTE/DACL-RAIZ
preveem operador autorizado e outra conta/token real, positivos e negativos,
READ/WRITE/CREATE/DELETE/RENAME, ancestrais, aliases e proteção após replace.
Não há tentativa entre contas nesta entrega; política e ambiente ainda requerem aprovação.

## 4. Evidência, sanitização e decisões futuras

Para cada subcaso, produzir JUnit/log/JSON, fonte/versão/manifesto 470, capacidade
observada, API/código imediato, sentinelas/bytes antes/depois, decisões separadas.
Persistir o diagnóstico mesmo em falha de asserção; não depender de happy-path.
Não aceitar prints de dicionário ACL completo (pode conter canonical_path/SIDs).
Compartilhar apenas campos agregados/rótulos e cópias sanitizadas. Preservar raw
em custódia privada, fora do Git; registrar hashes do raw e derivado sem expor
nomes/SIDs/SDDL/caminhos. Revisar todos os erros inesperados antes de compartilhar.

Não existe lançador automático dos 19 nesta entrega: os comandos de execução
serão fechados após revisão das lacunas e da política. Isso evita executar
provas parciais como uma suíte supostamente homologadora. Verificar também
modelos/factories propostos antes de executá-los: não foram testados aqui.

Critérios APROVADO/FALHOU/NÃO_VALIDADO/NÃO_APLICÁVEL aplicam-se a cada eixo:
funcional, nativo, DACL e vínculo. NÃO_APLICÁVEL não conta como PASS. Falha de
sentinela/hash/origem interrompe e preserva evidência; 1314 ou ausência de alias
não demonstram rejeição. Ausência de vínculo bloqueia homologação histórica,
mas não impede preparar cenários novos claramente nomeados como propostos.

## 5. Revisão necessária antes de prosseguir

- Obter/custodiar originais EXP-04 e seus 19 nodeids/sete skips, ou manter provisório.
- Revisar pré-validação e capacidade de Windows sem mudar o computador atual.
- Revisar código/fichas, completar os fluxos WIN-14/16 e a falha nativa da API.
- Aprovar política e ambiente para DACL-FONTE/RAIZ antes de qualquer segunda conta.
- Aprovar novo roteiro de execução e coleta; nenhuma execução está implícita nesta entrega.

PARE AQUI nesta primeira etapa. Sem testes novos, alteração de candidato,
privilégios, políticas, commit/push/merge/publicação ou desbloqueio operacional.
