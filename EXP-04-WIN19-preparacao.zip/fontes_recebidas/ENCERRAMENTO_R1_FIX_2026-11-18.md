# EXP-04 — Termo técnico de encerramento da rodada R1-FIX

**Data:** 18/11/2026  
**Objeto:** R1-FIX, validação isolada, três testes R1 e suíte complementar de 39 casos  
**Decisão:** **ENCERRADA A RODADA CONTROLADA COM RESSALVAS** — NÃO equivale a homologação Windows/DACL.  
**Natureza:** registro documental local; **nenhum commit, push, merge ou publicação foi realizado por esta formalização**.

## 1. Proveniência dos materiais

| Fonte recebida | SHA-256 (pacote) | Alcance da conferência |
|---|---|---|
| `EXP-04-R1-FIX-candidata.zip` | `1fe4edaf22deab3b6ae7143e3969b810e91421a3c5467b45685ad3baa750e345` | CRC, manifesto e patch/fixture estática; não é execução Windows |
| `R1-FIX-EVIDENCIAS-WINDOWS.zip` | `e93946268ab7404a81c26ff65f578c799853d13554ab4a4dcae6b2169fc08632` | CRC, relatórios/JUnit e hashes dos arquivos listados nos recibos R1-FIX |
| `R1-FIX-SUITE39-WINDOWS.zip` | `9ffe6e9890e59858d043334ef7f1b59d1d92a1b5bd82a4e17507492d0c8d20bd` | CRC, JUnit e relatório da execução dos 39 casos |

**Baseline Git declarado:** `770d062d29c4361d6932592883df9339bb4089bc` (BPQ-04).  
**Candidata:** 470 caminhos no manifesto `VERSAO_R1_FIX_SHA256.json`; 469 hashes idênticos à referência R1 e um arquivo da fixture modificado (`tools/exp04_win/test_cleanup_windows.py`), conforme artefatos da candidata.  
**Manifesto SHA-256 usado nas execuções Windows:** `a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`.  
**Limite:** os ZIPs de evidências não contêm os 470 arquivos; a verificação por arquivo foi executada e relatada no Windows, não refeita independentemente a partir dos ZIPs de evidências.

## 2. Resultados nativos e reprodutibilidade

| Rodada | Coletados | PASS | SKIP | FAIL/ERROR | Estado da execução |
|---|---:|---:|---:|---:|---|
| Isolado da fixture | 1 | 1 | 0 | 0 | APROVADO |
| Três testes R1 | 3 | 3 | 0 | 0 | APROVADO |
| Suíte complementar de 39 | 39 | 36 | 3 | 0 | Execução concluída; cobertura NÃO_VALIDADA |

As duas primeiras rodadas produziram recibos `r1fix-validacao.json` com hashes dos JSON/JUnit. Conferido `CreateFileW` e código nativo **32** no cenário de conflito, acesso auxiliar `GENERIC_READ` (`0x80000000`) e compartilhamento `0x3`; o auxiliar permaneceu ativo durante a tentativa. Após liberá-lo, a comparação integral dos **9 bytes** sintéticos foi positiva. A alteração da fixture não modificou o motor nem a política DACL.

A suíte de 39 foi selecionada usando o executor da candidata com um *override da lista de casos em memória*, sem mudança de arquivos versionados. O JUnit registra **36 PASS, 3 SKIP e nenhum FAIL/ERROR**. A limpeza do contêiner da suíte foi registrada como `REMOVIDO`, com **124 exclusões solicitadas, 124 ausências confirmadas e zero falhas**. O relatório também marca `integridade_final=true`, 470 hashes, `homologacao_windows_integral=false`.

### Skips explicitamente preservados

1. `tools/exp04_win/test_cleanup_regressoes.py::test_interrupcao_posix_gera_falha_publica_e_fecha_recursos` — `INJECAO_POSIX; controle Windows NAO_VALIDADO`.
2. `tools/exp04_win/test_cleanup_regressoes.py::test_posix_errno_remocao_preservado_antes_fechamentos` — `INJECAO_POSIX; controle Windows NAO_VALIDADO`.
3. `tools/exp04_win/test_cleanup_windows.py::test_windows_reparse_nunca_percorre_destino[symlink]` — `WIN01_SYMLINK_SEM_PRIVILEGIO_1314; rejeicao de links NAO_VALIDADA`.

O terceiro skip foi corroborado por uma tentativa independente de criação de symlink no PowerShell, relatada pelo usuário como **WinError 1314**. O teste de segurança correspondente **não foi exercitado**; o erro de privilégio não representa reprovação nem aprovação do motor.

## 3. Escopo da decisão e limites

**Concluído:** correção mínima da fixture; teste isolado; os três casos R1; 36 aprovações na suíte de 39 (com sobreposição parcial aos casos R1, sem soma entre rodadas); integridade registrada; limpeza dos temporários dessa suíte registrada.  
**Não concluído:** rejeição de symlink no ambiente atual; reconciliação dos 19 nodeids históricos; comprovação da política DACL efetiva no fluxo real; validação entre contas; homologação Windows integral.  
**Os 19 controles históricos permanecem NÃO_VALIDADO.** A matriz `docs/EXP_04_WIN_MATRIZ_19.md` e `tools/exp04_win/casos_historicos.json` fornecem correspondências **provisórias D2**, não uma transcrição dos nodeids das 19 falhas do JUnit EXP-04 original. O histórico menciona 2.842 coletados, 19 falhas e 7 skips, mas os nodeids e motivos individuais originais não constam dos materiais revisados nesta etapa.

Distinguir sempre:
- `estado_execucao = APROVADO`: subprocesso/rodada terminou sem falhas de execução.
- `estado_testes = NÃO_VALIDADO`: há cobertura ignorada.
- `estado_seguranca_windows = NÃO_VALIDADO` e `homologacao_windows_integral = false`: **não há autorização operacional**.

## 4. Deliberação

**ENCERRAR** a R1-FIX exclusivamente como rodada controlada executada e documentada. **NÃO APROVAR** homologação geral DACL, desbloqueio de conversões reais, merge, publicação ou limpeza manual de resíduos de rodadas anteriores. Preservar os ZIPs/recibos e seus SHA-256 como trilha de auditoria; não alterar evidências retroativamente.

A próxima tarefa é a **validação independente da matriz WIN-01…WIN-19**, em worktree/cenário sintético separados, conforme `INSTRUCOES_CODEX_VALIDACAO_INDEPENDENTE_WIN19.md`. A aprovação dos 19 vínculos e dos controles DACL exige novas provas, não extrapolação dos 36 PASS da suíte de cleanup.
