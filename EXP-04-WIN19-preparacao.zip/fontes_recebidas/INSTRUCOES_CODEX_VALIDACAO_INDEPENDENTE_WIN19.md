# Instruções ao Codex — validação independente da matriz EXP-04 WIN-01 a WIN-19

**Status da instrução:** plano de trabalho preparado para execução controlada, sem autorização de publicação ou alteração funcional.  
**Base documental:** `ENCERRAMENTO_R1_FIX_2026-11-18.md`, `docs/EXP_04_WIN_MATRIZ_19.md`, `tools/exp04_win/casos_historicos.json`, JUnit e JSON Windows auditados.  
**Candidata de referência:** R1-FIX com **470 hashes**, baseline Git `770d062d29c4361d6932592883df9339bb4089bc`.  
**Regra central:** 36 PASS da suíte de cleanup **não homologam** estes 19 controles nem a DACL.

## Missão e resultado esperado

Produzir evidências independentes, individualizadas e rastreáveis para cada `WIN-01` a `WIN-19`, separando **(a) reconciliação histórica do vínculo**, **(b) execução funcional Windows**, **(c) prova nativa de segurança/isolamento e DACL efetiva**. Nenhuma coluna pode ser preenchida como APROVADO a partir de um comentário, mock, execução Linux, resultado de outro teste, um skip ou um inventário de ACEs.

**Não executar automaticamente testes destrutivos, não elevar privilégios, não mudar políticas e não modificar o motor.** Preparar artefatos de pré-validação primeiro; a etapa Windows real requer ambiente de teste autorizado e revisão dos pré-requisitos.

## Fase 0 — Congelar evidência, escopo e origem

1. Registrar SHA-256 do pacote/candidata, manifesto de 470 arquivos, Python, versão Windows, tipo de volume (NTFS/ReFS), contexto da conta, flags de criação de symlink e estado Git. Preservar a R1-FIX validada; usar **nova worktree isolada** e resultados fora do Git. Usar Python 3.12 e `PYTHONUTF8=1` sem alterações permanentes de Git/Windows. Se reconstruir no Windows, impor `core.autocrlf=false` e `core.eol=lf` **também nas chamadas Git descendentes**, somente no escopo do processo. Comparar hashes antes/depois.
2. Solicitar/localizar o JUnit, log e relatório bruto originais da rodada Windows da EXP-04 com **2.842 coletados, 19 falhas, 7 skips**. Validar integridade e extrair os **nodeids exatos, tracebacks e motivos individuais dos 7 skips**, sem inferir correspondências da contagem agregada.
3. Confrontar cada falha histórica com o nodeid proposto em `tools/exp04_win/casos_historicos.json`. Marcar `VINCULO_CONFIRMADO`, `VINCULO_DIVERGENTE` ou `PROVISORIO_SEM_FONTE`. **Sem JUnit histórico, não declarar reconciliação concluída**. Manter as 19 linhas, com discrepâncias explícitas, sem alterar o histórico silenciosamente.
4. Examinar linha a linha os contratos originais e a correção D2/R1-FIX. Distinguir teste legado, código de produção e helper diagnóstico. Registrar qual código estava sob teste e se o nodeid atual ainda representa a mesma asserção.

**Entrega-gatilho:** quadro inicial de proveniência, 19 vínculos e lacunas. Se os arquivos históricos não forem verificáveis, continuar apenas a preparação dos testes nativos como cenários propostos, mas bloquear a homologação da correspondência histórica e registrar `PROVISORIO_SEM_FONTE`.

## Fase 1 — Matriz individual de 19 controles

Usar `MATRIZ_WIN19_REFERENCIA.csv` como **modelo inicial**, não como resultado observado. Preencher para cada caso: ID, grupo, nodeid histórico exato e proposto, versão/commit, teste e asserção, pré-condição nativa, artefato/JUnit, resultado funcional Windows, motivo de skip, resultado de segurança nativa, resultado DACL, divergência histórica, responsável/revisor, hash das evidências e decisão justificada.

| ID | Grupo | Nodeid provisório D2 | Objetivo | Situação atual |
|---|---|---|---|---|
| WIN-01 | API | `tests/test_acl_evidence.py::test_evidencia_sempre_hardcoded_false` | Diagnóstico ACL não autoriza acesso por padrão | NÃO_VALIDADO |
| WIN-02 | API | `tests/test_acl_evidence.py::test_normalizacao_8_3_expande_nome_curto` | Normalização de nome curto 8.3 | NÃO_VALIDADO |
| WIN-03 | API | `tests/test_acl_evidence.py::test_comparacao_de_caminho_e_case_insensitive_ordinal` | Comparação ordinal case-insensitive | NÃO_VALIDADO |
| WIN-04 | API | `tests/test_acl_evidence.py::test_hardlink_e_rejeitado_na_comparacao_de_caminho` | Hardlink distinto do caminho esperado | NÃO_VALIDADO |
| WIN-05 | API | `tests/test_acl_evidence.py::test_evidencia_com_baseline_registra_artefato_mas_nao_autoriza` | Evidência de baseline sem autorização implícita | NÃO_VALIDADO |
| WIN-06 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]` | Symlink em registro.json | NÃO_VALIDADO |
| WIN-07 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]` | Symlink em chave.bin | NÃO_VALIDADO |
| WIN-08 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]` | Symlink em escrita.lock | NÃO_VALIDADO |
| WIN-09 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]` | Symlink em evidencias | NÃO_VALIDADO |
| WIN-10 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]` | Symlink em cabecas | NÃO_VALIDADO |
| WIN-11 | LINK | `tests/bbz/test_persistent_links.py::test_raiz_link_ancestral_e_git_recusados` | Raiz/link ancestral e Git | NÃO_VALIDADO |
| WIN-12 | LINK | `tests/bbz/test_persistent_links.py::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada` | Fonte em symlink com bytes idênticos | NÃO_VALIDADO |
| WIN-13 | LINK | `tests/phase3/test_protected_sources.py::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]` | Fonte protegida via link | NÃO_VALIDADO |
| WIN-14 | LINK | `tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[symlink]` | Isolamento local contra symlink | NÃO_VALIDADO |
| WIN-15 | MODO | `tests/phase3/test_private_validation.py::test_canonicos_so_por_opcao_explicita_na_area_privada` | Canônicos somente por opção explícita | NÃO_VALIDADO |
| WIN-16 | MODO | `tests/phase3/test_private_validation.py::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida` | Conflito documental e auditoria protegida | NÃO_VALIDADO |
| WIN-17 | MODO | `tests/test_documents.py::test_auditoria_documental_persiste_em_json_protegido` | Persistência de auditoria JSON | NÃO_VALIDADO |
| WIN-18 | CHMOD | `tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[permissao_fonte]` | Permissão de fonte simulada por chmod | NÃO_VALIDADO |
| WIN-19 | CHMOD | `tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[permissao_raiz]` | Permissão de raiz simulada por chmod | NÃO_VALIDADO |

**Grupos:** API (5), LINK (9), MODO (3), CHMOD (2). Os nove LINK não equivalem ao único skip de symlink da suíte de cleanup; são cenários históricos diferentes e exigem evidências próprias.

## Fase 2 — Provas independentes Windows (sem dados reais)

### API: WIN-01 a WIN-05

- Provar a assinatura real `kernel32!CompareStringOrdinal`, parâmetros corretos em UTF-16 e interpretação do retorno; conferir fail-closed quando a API está indisponível ou retorna erro. Não basta passar sob mock.
- Para WIN-02, exigir um alias **8.3 real** retornado por `GetShortPathNameW`; se o volume não fornecer alias, marcar `NÃO_VALIDADO/ALIAS_8_3_INDISPONIVEL` sem inventar um nome curto. Registrar volume/capacidade sem imprimir caminho privado.
- Para WIN-03, executar comparação ordinal real com case-insensitive, Unicode e sufixo após símbolo não BMP; não substituir por `casefold()`.
- Para WIN-04, criar dois nomes hardlink sintéticos, comprovar mesmo file ID e caminhos distintos, comparar conforme o contrato diagnóstico; não interpretar esse comparador como verificação de identidade de origem na produção.
- Para WIN-01/05, demonstrar que a criação de evidência ACL e eventual baseline **não autorizam acesso**, inclusive em casos negativos; a sonda `coletar_evidencia_acl` declara `aplicada_ao_leitor=false`.

### Links: WIN-06 a WIN-14

- Executar cada cenário individual com link **efetivamente criado**, prova de que aponta para sentinela externa sintética, tentativa do fluxo alvo, recusa observada, byte-a-byte do destino inalterado e limpeza restrita ao artefato criado.
- Cobrir os cinco alvos BBZ (`registro.json`, `chave.bin`, `escrita.lock`, `evidencias`, `cabecas`), raiz/link ancestral/Git, fonte em link com bytes iguais, fonte protegida e simulação privada.
- **WinError 1314 no Windows atual já foi observado.** Se o processo não puder criar symlink, registrar `NÃO_VALIDADO`; não aceitar skip como rejeição. Preparar rodada específica em **ambiente Windows autorizado** (sem concessão automática de privilégio e sem elevação no computador atual). Junction não substitui symlink; deve ter linha de evidência separada.
- Confirmar que falhas não expõem caminhos, credenciais nem conteúdo real, e que erros inesperados não viram skip.

### MODO: WIN-15 a WIN-17

- Reexecutar asserções de canônicos por opção explícita, conflito documental/auditoria e persistência de JSON **como controles funcionais**. Provar integridade da informação e não inclusão de conteúdo privado em logs.
- Não inferir isolamento NTFS de `st_mode`, `0600`, gravação JSON com `replace` ou da passagem desses testes. Registrar propriedades `DACL_WINDOWS_NAO_VALIDADA` até existir prova separada de acesso real.

### CHMOD: WIN-18 e WIN-19

- Reconhecer que `chmod`/bits POSIX não exercitam DACL Windows. Os casos POSIX podem ser `NÃO_APLICÁVEL_AO_WINDOWS` como testes originais, **sem receber APROVADO** na coluna de segurança Windows.
- Projetar **casos nativos adicionais**, vinculados a WIN-18 e WIN-19, que exercitem negação efetiva de acesso à fonte e à raiz por token de outra conta autorizada para o laboratório, sem alterar DACL fora da área sintética. Testar falha fechada e preservação de dados.

## Fase 3 — Homologação DACL independente (etapa separada da suíte)

**Não existe, nos pacotes auditados, comprovação de uma política DACL integrada ao escritor/leitor real.** O inventário `tools/exp04_win/ntfs.py`/`inventario_ntfs.ps1` declara explicitamente `acesso_outro_usuario_testado=false`, `dacl_efetiva_homologada=false` e `politica_integrada_ao_escritor=false`. Uma lista de ACEs não determina, sozinha, o acesso efetivo.

Antes de executar, o Codex deve apresentar para aprovação **uma especificação de política esperada**: quais arquivos e diretórios sintéticos, quais papéis autorizados/não autorizados, quais operações (`READ`, `WRITE`, `DELETE`, criação/rename) devem ser permitidas ou negadas, e como o fluxo real instala/verifica essas permissões. **Não inventar requisitos nem aplicar ACL genérica para obter PASS.**

Protocolo, após aprovação do ambiente e da política:

1. Criar diretório **exclusivo e sintético** em volume NTFS controlado, fora de qualquer Git e de documentos de clientes. Não usar pastas de produção nem resíduos antigos.
2. Executar o fluxo real que cria JSON/arquivos e a área de leitura protegida. Capturar características sanitizadas de ACL, herança, dono e versão da política, sem SIDs, nomes de conta, SDDL, caminhos ou segredos nos artefatos compartilhados.
3. Com dois **tokens/contas distintos** legitimamente provisionados para o laboratório (operador autorizado e usuário não autorizado), testar operações positivas e negativas efetivas; registrar o código de acesso negado e o hash dos bytes antes/depois. Não presumir isolamento por ACE isolada ou ausência de uma regra visível.
4. Verificar arquivo **e diretórios ancestrais**, herança, acesso por hardlinks/junctions/symlinks, substituição concorrente e persistência da proteção após escrita atômica/`replace`, de forma sintética e com limites controlados.
5. Encerrar handles e limpar somente a área sintética criada pela execução, com diagnóstico se houver falha. Jamais limpar o residual histórico ou ajustar o ambiente real para passar testes.
6. Se a política não estiver integrada ao fluxo, ou não existir segunda conta/token, classificar `DACL_NÃO_VALIDADO / EVIDENCIA_INSUFICIENTE` e propor tarefa funcional separada; **não transformar o inventário NTFS em prova de isolamento**.

## Fase 4 — Critérios de aprovação e bloqueios

Cada uma das 19 linhas precisa ter **dois estados independentes**, `teste_funcional` e `controle_nativo` (e campo separado `DACL_efetiva` quando pertinente), além do estado do vínculo histórico. Valores permitidos: `APROVADO`, `FALHOU`, `NÃO_VALIDADO`, `NÃO_APLICÁVEL` (apenas quando justificável, nunca contado como PASS). Registrar a fonte da prova e seu hash. Condições:

- `APROVADO`: pré-condição realmente satisfeita + asserção relevante executada em Windows + evidência nativa autenticada, íntegra e verificável; para DACL, teste real de acesso entre tokens e política aprovada.
- `NÃO_VALIDADO`: skip, erro 1314, alias 8.3 ausente, falta de JUnit histórico, política não especificada, ambiente sem conta alternativa ou evidência incompleta.
- `FALHOU`: assert não satisfeita, vazamento de sentinela/dados, modificação de alvo externo, quebra de isolamento, falha não tratada, divergência de hashes ou execução inesperada.
- `NÃO_APLICÁVEL`: teste estritamente POSIX como mecanismo de `chmod`; propor controle nativo substituto, sem promover aprovação.

**Não aceitar** contagem total verde que omite skips. Não somar 39 testes de cleanup, 19 casos históricos e sete testes nativos em um mesmo indicador sem deduplicação. Não prometer homologação integral enquanto qualquer controle exigido permanecer `NÃO_VALIDADO`.

## Fase 5 — Entregáveis do Codex

Na **primeira entrega, somente preparação/reconciliação (sem alterar a candidata ou executar testes novos)**:

1. `RELATORIO_PROVENIENCIA_WIN19.md`: fontes/hashes, nodeids históricos confrontados, o que falta e estado do escopo.
2. `MATRIZ_WIN19_RECONCILIADA.csv` (19 linhas): IDs, vínculos, asserções, estados separados, motivo, origem de evidência. Não preencher lacunas por inferência.
3. `PLANO_NATIVO_WIN19.md` + roteiro PowerShell idempotente de **preflight somente leitura**, com requisitos de Python 3.12, NTFS, symlink e 8.3, sem elevação nem mudança de políticas.
4. `ESPECIFICACAO_DACL_PROPOSTA.md`: política esperada por papel/objeto/operação e dependências de integração real, **marcada PARA_APROVAÇÃO**, sem implementar permissões por suposição.
5. `MANIFESTO_EVIDENCIAS_WIN19.json`: hashes dos materiais usados e locais sanitizados dos arquivos de evidência; não incluir documentos reais, nomes, SIDs, SDDL ou caminhos pessoais.

Após revisão/autorização da preparação, executar os casos em Windows autorizado e entregar JUnit/log/JSON por caso, matriz consolidada, comparação de hashes 470 antes/depois, verificação de temporários, justificativas individuais de skips e relatório de riscos residuais.

**Restrições permanentes:** nenhuma alteração no motor, parser, cadastro, políticas financeiras, 30 colunas, perfis ou conversões; nenhuma elevação automática, mudança persistente do Git, ACL, Developer Mode ou política Windows; sem dados privados reais; sem commit/push/merge/publicação; conversões reais continuam BLOQUEADAS; homologação DACL continua NÃO_VALIDADO até prova independente revisada.

**Ponto de parada obrigatório:** encerrar a primeira entrega com as fontes, a matriz provisória/reconciliada, o roteiro seguro e a proposta de política — **não executar a fase nativa de risco nem promover estados sem nova aprovação**.
