"""CAPTURADOR EXTERNO PROPOSTO, NÃO EXECUTADO/VALIDADO EM WINDOWS.

Não é a sonda: após autorização futura, cria somente uma área nova de evidência.
Nunca importa o produto/preflight; executa a sonda em processo isolado separado.
Sem ACL, chmod, symlinks, remoção ou alteração de configuração persistente.
"""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys


class Bloqueio(Exception):
    pass


def hash_bytes(raw):
    return sha256(raw).hexdigest()


def regular(path, directory=False):
    if not path.is_absolute() or '..' in path.parts:
        raise Bloqueio('CAMINHO_INVALIDO')
    for p in (*reversed(path.parents),path):
        s=p.lstat()
        if stat.S_ISLNK(s.st_mode) or getattr(s,'st_file_attributes',0)&0x400:
            raise Bloqueio('LINK_REPARSE_RECUSADO')
        if p!=path and not stat.S_ISDIR(s.st_mode):
            raise Bloqueio('ANCESTRAL_INVALIDO')
    if not (stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode)):
        raise Bloqueio('TIPO_INVALIDO')
    return path


def fora_git(path):
    for p in (path,*path.parents):
        if os.path.lexists(p/'.git') or (os.path.lexists(p/'objects') and
                any(os.path.lexists(p/n) for n in ('HEAD','refs','config'))):
            raise Bloqueio('EVIDENCIA_OU_PREPARACAO_EM_GIT')


def instante():
    return dict(utc=datetime.now(timezone.utc).isoformat(),
                local_com_fuso=datetime.now().astimezone().isoformat())


class Custodia:
    def __init__(self,root):
        # A raiz é inexistente, aprovada pelo chamador e nunca reutilizada.
        root.mkdir()  # Herança padrão; não configurar uma DACL nem prometer proteção.
        self.root=root
        s=root.lstat();self.identity=(s.st_dev,s.st_ino)
        self.files={}

    def conferir(self):
        regular(self.root,True)
        s=self.root.lstat()
        if not self.identity[1]:raise Bloqueio('IDENTIDADE_AREA_NAO_DISPONIVEL')
        if (s.st_dev,s.st_ino)!=self.identity:
            raise Bloqueio('AREA_EVIDENCIA_SUBSTITUIDA_PRESERVAR')

    def abrir(self,name):
        self.conferir()
        if not re.fullmatch(r'[a-z0-9_.-]+',name):raise Bloqueio('NOME_INVALIDO')
        return (self.root/name).open('xb',buffering=0)

    def bytes(self,name,raw):
        with self.abrir(name) as stream:
            remaining=memoryview(raw)
            while remaining:
                n=stream.write(remaining)
                if not n:raise Bloqueio('ESCRITA_INCOMPLETA_PRESERVAR')
                remaining=remaining[n:]
            os.fsync(stream.fileno())
        if (self.root/name).read_bytes()!=raw:raise Bloqueio('GRAVACAO_NAO_CORRESPONDE')
        self.registrar(name)

    def json(self,name,value):
        raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf-8')
        self.bytes(name,raw)

    def registrar(self,name):
        self.conferir()
        raw=regular(self.root/name).read_bytes()
        self.files[name]=dict(bytes=len(raw),sha256=hash_bytes(raw))


def sanitizar(report):
    """Não copiar caminhos, comando, stderr, credenciais ou payload arbitrário."""
    bools=('integridade_antes','integridade_depois','head_confere','git_raiz_confere',
        'token_elevado','area_criada','ACL_alterada','prontidao_para_executar',
        'alias_existente_observado','symlink_privilegio_presente','symlink_privilegio_habilitado',
        'symlink_criacao_testada','developer_mode_somente_leitura','coleta_concluida',
        'utf8_ativo','bytecode_desabilitado','python_isolado','site_desabilitado',
        'git_traces_herdados','git_config_local_revisada','git_hooks_desabilitados')
    ints=('hashes_antes_conferidos','hashes_depois_conferidos','testes_executados',
          'status_git_registros','git_variaveis_herdadas','codigo_sonda_alias')
    codes=('estado','codigo','versao_preparacao','git_ambiente_politica',
           'portao_C','portao_D','portao_E','politica_DACL','autorizacao_testes')
    out={}
    for k in bools:
        if k in report:
            if type(report[k]) is not bool:raise Bloqueio('TIPO_JSON_NAO_PREVISTO')
            out[k]=report[k]
    for k in ints:
        if k in report:
            if report[k] is not None and (type(report[k]) is not int or report[k]<0):
                raise Bloqueio('TIPO_JSON_NAO_PREVISTO')
            out[k]=report[k]
    for k in codes:
        if k in report:
            if not isinstance(report[k],str) or not re.fullmatch(r'[A-Z0-9_-]{1,160}',report[k]):
                raise Bloqueio('CODIGO_JSON_NAO_PREVISTO')
            out[k]=report[k]
    for k in ('manifesto_sha256','preflight_python_sha256','status_git_sha256','git_executavel_sha256','git_head','baseline_esperado'):
        if k in report:
            if not isinstance(report[k],str) or not re.fullmatch(r'(?:[0-9a-f]{40}|[0-9a-f]{64})',report[k]):
                raise Bloqueio('HASH_JSON_INVALIDO')
            out[k]=report[k]
    # Só valores conhecidos; não transportar campos novos sem revisão.
    if report.get('DACL_efetiva')!='NÃO_VALIDADO':raise Bloqueio('DACL_ESTADO_INVALIDO')
    out['DACL_efetiva']='NÃO_VALIDADO'
    if 'impedimentos' in report:
        items=report['impedimentos']
        if not isinstance(items,list) or len(items)>64 or any(not isinstance(x,str) or
                not re.fullmatch(r'[A-Z0-9_; -]{1,180}',x) for x in items):
            raise Bloqueio('IMPEDIMENTOS_NAO_PREVISTOS')
        out['impedimentos']=items
    return out


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('preparacao','candidata','area-prevista','evidencias','git'):
        parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--custodiante',required=True)
    parser.add_argument('--autorizacao-id',required=True)
    parser.add_argument('--autorizar-captura-e-uma-execucao',action='store_true')
    a=parser.parse_args()
    custody=None;creation_attempted=False;status='NAO_CONCLUIDO';code=None;rc=None;report=None
    try:
        if not a.autorizar_captura_e_uma_execucao:raise Bloqueio('AUTORIZACAO_FUTURA_OBRIGATORIA')
        if os.name!='nt' or sys.version_info[:2]!=(3,12):raise Bloqueio('WINDOWS_PYTHON312_OBRIGATORIOS')
        if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.utf8_mode):
            raise Bloqueio('RUNTIME_ISOLADO_OBRIGATORIO')
        if any(k.upper().startswith('GIT_') for k in os.environ):raise Bloqueio('GIT_VARIAVEL_HERDADA_NAO_AUTORIZADA')
        for label in (a.custodiante,a.autorizacao_id):
            if not re.fullmatch(r'[A-Z][A-Z0-9_-]{2,79}',label) or label in {'A_DESIGNAR','PENDENTE','MODELO'}:
                raise Bloqueio('RESPONSAVEL_OU_AUTORIZACAO_INVALIDOS')
        prep=regular(a.preparacao,True);fora_git(prep)
        regular(a.candidata,True);regular(a.git)
        local=regular(Path(os.environ.get('LOCALAPPDATA','')),True);fora_git(local)
        root=a.evidencias
        if not root.is_absolute() or '..' in root.parts or root.parent!=local or not root.name.startswith('WIN19-CUSTODIA-'):
            raise Bloqueio('AREA_CUSTODIA_INVALIDA')
        if os.path.lexists(root):raise Bloqueio('AREA_CUSTODIA_EXISTENTE_PRESERVAR')
        if root==a.area_prevista or root==prep or root==a.candidata or any(root.is_relative_to(p) or p.is_relative_to(root) for p in (prep,a.candidata)):
            raise Bloqueio('AREAS_SOBREPOSTAS')
        pins=json.loads(regular(prep/'HASHES_PREFLIGHT_PORTAO_B.json').read_bytes())['arquivos']
        for name,expected in pins.items():
            p=regular(prep/name)
            if hash_bytes(p.read_bytes())!=expected:raise Bloqueio('PREPARACAO_DIVERGENTE')
        creation_attempted=True
        custody=Custodia(root)
        custody.json('inicio_privado.json',dict(natureza='CUSTODIA_PRIVADA_NAO_HOMOLOGACAO',
            inicio=instante(),custodiante=a.custodiante,autorizacao_id=a.autorizacao_id,
            candidata=str(a.candidata),area_prevista=str(a.area_prevista),
            python=sys.version,python_executavel_sha256=hash_bytes(Path(sys.executable).read_bytes()),
            scripts_sha256=pins,manifesto_entrega_sha256=hash_bytes((prep/'MANIFESTO_PORTAO_B_SHA256.json').read_bytes()),
            politica_DACL='PARA_APROVACAO',DACL_efetiva='NÃO_VALIDADO'))
        command=[sys.executable,'-I','-S','-B','-X','utf8',str(prep/'tools/preflight_win19.py'),
            '--candidata',str(a.candidata),'--manifesto',str(prep/'REFERENCIA_R1_FIX_470_SHA256.json'),
            '--area-prevista',str(a.area_prevista),'--git',str(a.git)]
        # Handles de arquivos exclusivos, sem pipeline textual PowerShell.
        # Popen só recebe o ambiente Python atual; a SONDA cria outro ambiente,
        # positivo e sem herança para as suas três consultas Git locais.
        with custody.abrir('stdout_bruto.bin') as stdout, custody.abrir('stderr_bruto.bin') as stderr:
            status='LANCAMENTO_TENTADO_NAO_CONCLUIDO'
            try:
                result=subprocess.run(command,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,
                                      cwd=prep,timeout=180,check=False)
                rc=result.returncode
            except subprocess.TimeoutExpired:
                code='TIMEOUT_SONDA_INTEGRIDADE_FINAL_NAO_COMPROVADA'
                # subprocess.run encerra/aguarda seu filho direto. Não afirmar
                # que todos os descendentes Git também foram encerrados.
            finally:
                os.fsync(stdout.fileno());os.fsync(stderr.fileno())
        custody.registrar('stdout_bruto.bin');custody.registrar('stderr_bruto.bin')
        if code is None:
            raw=(root/'stdout_bruto.bin').read_bytes()
            if len(raw)>1024*1024:raise Bloqueio('SAIDA_EXCESSIVA_PRESERVAR')
            report=json.loads(raw.decode('utf-8'))
            if not isinstance(report,dict):raise Bloqueio('JSON_INVALIDO_PRESERVAR')
            custody.json('json_normalizado_privado.json',report)
            sanitized=sanitizar(report)
            custody.json('relatorio_sanitizado.json',dict(natureza='EVIDENCIA_B_NAO_HOMOLOGACAO',
                resultado_sonda=sanitized,custodiante=a.custodiante,autorizacao_id=a.autorizacao_id))
            if rc==0 and report.get('coleta_concluida') is True:
                status='COLETA_ENCERRADA_REQUER_REVISAO'
            else:
                code='SONDA_BLOQUEADA_OU_RETORNO_DIVERGENTE'
            if custody.files['stderr_bruto.bin']['bytes']:
                code='STDERR_PRESENTE_REQUER_REVISAO_PRIVADA'
        if code is None and (rc!=0 or report.get('prontidao_para_executar') is not False or
                any(report.get('portao_'+g)!='BLOQUEADO' for g in 'CDE')):
            status='BLOQUEADO';code='ESTADOS_DE_SEGURANCA_DIVERGENTES'
    except Bloqueio as error:
        code=str(error)
    except KeyboardInterrupt:
        code='INTERRUPCAO_PRESERVAR_EVIDENCIAS'
    except Exception:
        code='CAPTURA_ERRO_OPERACIONAL_PRESERVAR'
    finally:
        if custody is not None:
            try:
                # Registrar também brutos parciais que já existirem em falha.
                for name in ('stdout_bruto.bin','stderr_bruto.bin'):
                    if os.path.lexists(custody.root/name):custody.registrar(name)
                custody.json('fim_privado.json',dict(fim=instante(),estado=status if code is None else 'BLOQUEADO',codigo=code,retorno_sonda=rc,
                    descendentes_git_encerrados='NAO_COMPROVADO_SE_TIMEOUT_OU_INTERRUPCAO',
                    C='BLOQUEADO',D='BLOQUEADO',E='BLOQUEADO',DACL='NÃO_VALIDADO'))
                custody.json('cadeia_sha256.json',dict(arquivos=dict(custody.files),
                    excluido='cadeia_sha256.json',raw='BYTES_ORIGINAIS_STDOUT_STDERR',
                    normalizacao='UTF8 estrito; JSON parse/dump sort_keys indent2 ensure_ascii; LF final, sem BOM',
                    sanitizacao='LISTA_POSITIVA_DE_CAMPOS_TIPADOS; sem stderr/caminhos/comando',
                    custodiante=a.custodiante,autorizacao_id=a.autorizacao_id))
            except Exception:
                code='CUSTODIA_FINAL_INCOMPLETA_PRESERVAR'
    print(json.dumps(dict(estado=status if code is None else 'BLOQUEADO',codigo=code,
        retorno_sonda=rc,custodia_inicializada=custody is not None,
        criacao_area_custodia_tentada=creation_attempted,prontidao_para_executar=False,
        C='BLOQUEADO',D='BLOQUEADO',E='BLOQUEADO',DACL='NÃO_VALIDADO'),ensure_ascii=True))
    return 0 if code is None else 2


if __name__=='__main__':raise SystemExit(main())
