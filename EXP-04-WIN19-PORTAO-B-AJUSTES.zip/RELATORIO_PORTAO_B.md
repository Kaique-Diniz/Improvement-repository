# Ajustes do Portão B — relatório técnico para revisão

18/11/2026. Instrução principal INSTRUCOES_CODEX_WIN19_PORTAO_B_AJUSTES.md;
fundamentação PARECER_TECNICO_WIN19_PORTAO_B_2026-11-18.md. Fontes preservadas.

B-R1: root de confiança externo. ZIP pinado antes de extração e comando/manifesto
pinados fora do pacote antes de invocar. Verificador externo acompanha a entrega,
sem estar dentro do ZIP que referencia e sem invocar scripts. Entrada revisada
fixa pasta, recusa materiais/diretórios extras, reparse e código fora da lista.
Inventário interno não é apresentado como autenticação da própria fonte.

B-R2: sonda recusa TODO GIT_* herdado, inclusive configuração/traces. Três
subprocessos recebem dicionário positivo explícito, executável absoluto, sem
credenciais/auth/rede, stdinNUL, captura e timeout. Global/sistemaNUL só no filho;
config local é lida/validada por lista restritiva, sem includes/drivers/condições
não revistas. Sem alteração persistente ou limpeza silenciosa do ambiente pai.

B-R3: capturador proposto SEPARADO da sonda grava uma área própria nova só após
aprovação futura. Início durável antes de lançar filho, raw binário stdout/stderr,
normalização e sanitização identificadas, fim/chain em finally, fsync e releitura.
CUSTODIANTE_USUARIO designa o solicitante; papel/retenção/destino precisam de aceite
antes da execução. ID e flag não são consentimento. Nenhum dado de cliente usado.

B-R4: nenhuma execução ou parsing PowerShell5.1. Documentado parsing somente de
cópias sintéticas como eventual etapa sujeita a autorização própria; não invocar,
dot-source ou avaliar scripts. Sintaxe Python não comprova compatibilidade nativa.

Alterações efetivas estão somente nesta cópia externa. Matriz19, manifesto470,
proposta DACL e checklist histórico conservam bytes anteriores. R1-FIX, 27worktrees,
refs, arquivos anteriores e17ZIPs são conferidos em PRESERVACAO_PORTAO_B.json.
O ZIP B anterior e entrada original auditada permanecem intactos.

Conferências realizadas: leitura/AST e compilação em memória, JSON/CSV, hashes/CRC
local e Git de preservação. Zero preflight (inclusive Linux), coleta pytest,
execução capturador/entrada/helper, teste Windows/DACL/symlink ou alteração de
privilégios/ACLs/registro/contas/políticas. Não há instalação ou runner C.

Riscos residuais: caminhos/config devem estar estáveis; sem prova antissubstituição
por handles; compatibilidade PS5.1 e semântica nativeGit/captura/falhas/durabilidade
não validadas; timeout não comprova encerramento de descendentes e falta de energia
pode impedir recibo final. Erro/incompletude bloqueia e preserva, nunca apaga/resume
como PASS. Saída0 do capturador só indica que o fluxo terminou para revisão.

CRITERIOS_ACEITACAO_PORTAO_B.csv mantém B01–B22, atualizando apenas pinagem,
ambiente e custódia. Modelo é NÃO_EXECUTADO, responsável definido por papel e sem
resultados inventados. JUnit EXP04 original2842/19/7 e seus motivos continuam
pendentes;19 PROVISORIO_SEM_FONTE; eixos funcional/nativo/DACL NÃO_VALIDADO.
C/D/E, homologação e conversões reais continuam BLOQUEADOS.

DIFF_PREPARACAO_PORTAO_B.patch compara esta nova cópia com a entrega anterior,
incluindo arquivos novos; não aplicar sobre candidata. Manifesto cobre arquivos
e diff, excluindo a si próprio; diff exclui a si e manifesto por autorreferência.
Verificador externo e SHA concreto do ZIP/entrada/manifesto são entregues ao lado.

PARE PARA REVISÃO. Não houve commit/push/merge/PR/publicação. A vedação expressa
atual de publicação foi respeitada. Nenhuma execução futura foi autorizada.
