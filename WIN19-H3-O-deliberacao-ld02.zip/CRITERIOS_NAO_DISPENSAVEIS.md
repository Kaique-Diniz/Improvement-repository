# H3-O — critérios não dispensáveis por escolha de classificação

27/11/2026. Regras de proteção/legitimidade preservadas, sem requisitos aprovados
ou materialmente demonstrados. Propor G09/G10 indispensáveis não equivale a ratificá-los.

## Separar as três dimensões

Classificação é o papel proposto do requisito na finalidade A. Evidência material
é prova legítima de seu atendimento, por objeto/identidade/operação pertinente.
Autorização é manifestação operacional válida para método/escopo/tempo/operador
específicos. As dimensões não se substituem, inclusive com onze aprovações futuras.
A matriz correspondente preserva estado não deliberado, ausência de comprovação
material por esta entrega e operação não autorizada em cada G.

## Garantias e políticas que não se tornam opcionais

- Legitimidade de operador/ambiente, competência e escopo autorizado não são inferidos
  de versão PS5.1, não elevação ou aprovação documental. G09 depende de L-D03/L-D04/L-D11.
- Separação de áreas proibidas permanece obrigatória. G05 decide nível de evidência
  e portão, não uma dispensa da proibição; L-D06 continua necessária. Nenhum caminho
  privado será incorporado ao instrumento/código para contornar a lacuna.
- R03: atributos/releituras não fixam objeto físico, não eliminam corrida nem
  asseguram que a própria leitura fique no escopo. Se identidade estável for
  indispensável, rever projeto antes de observar; indício não é autorização.
- R07: metadados de segurança ancestral não são acesso efetivo ou proteção futura.
  Ausência de allow amplo não aprova proteção. G08 posterior não dispensa tratamento
  prévio de qualquer risco que afete a segurança da própria observação.
- Privacidade: não dispensar proteção porque G06 é diagnóstico, não desabilitar
  logs/auditoria/ferramentas/serviços, não isentar automaticamente shares administrativos.
- G10: não iniciar observação sem tratamento adequado de fonte/vínculo de execução,
  recepção sanitizada, resultado ausente/incompleto/extra/incompatível, interrupção,
  recursos incertos, fechamento e duração total. Aceitar classificação não adota
  contrato H3-L, não implementa consumidor e não escolhe prazo ou supervisão.
- G11: somente portão próprio pode autorizar acesso ao JUnit/cópia/movimentação/
  sanitização/descarte/criação de destino. H3-C é independente e continua não autorizada.

## Conflito de classificação e segurança

Se ajuste/rejeição/concordância vier acompanhada de exigência incompatível com
uma condição de segurança da leitura, registrar conflito, motivação e dependências;
propor revisão técnica/projeto e manter bloqueio. Não resolver por redução silenciosa
de proteção, execução para descobrir o ambiente ou interpretação de silêncio como
aceite. Eventual decisão parcial só afeta os IDs expressamente decididos.

## Riscos e pendências preservados

| Risco | Severidade histórica | Classificação |
|---|---|---|
| H3G-R01 | MEDIA | RISCO_POTENCIAL |
| H3G-R02 | MEDIA | RISCO_POTENCIAL |
| H3G-R03 | ALTA | RISCO_POTENCIAL |
| H3G-R04 | MEDIA | RISCO_POTENCIAL |
| H3G-R05 | MEDIA | RISCO_POTENCIAL |
| H3G-R06 | MEDIA | RISCO_POTENCIAL |
| H3G-R07 | ALTA | RISCO_POTENCIAL |
| H3G-R08 | MEDIA | RISCO_POTENCIAL |
| H3G-R09 | MEDIA | RISCO_POTENCIAL |

R03/R07 ALTA; demais sete MEDIA. N02/N03 ALTA e N04 MEDIA permanecem NAO_VERIFICADO.
N01 apenas sintaxe R1 conforme relato anterior do usuário; não runtime, host,
provedores, fechamento ou segurança. D01–D04 são mudanças textuais, não eficácia
funcional. V01–V10 continuam sem execução de inspeção. Nenhum risco é aceito por
aprovar o papel documental de uma garantia. Nenhuma API, mock ou teste foi executado.
