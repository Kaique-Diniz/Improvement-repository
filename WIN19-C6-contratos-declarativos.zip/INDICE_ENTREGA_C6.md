# WIN19-C6 — materialização declarativa para revisão independente

23/11/2026, data de referência America/Sao_Paulo. Versão dos seis contratos:
**0.1.0-proposta-c5**. Estado: **MATERIALIZADO; REVISÃO INDEPENDENTE DOS BYTES PENDENTE**.
Não é aprovação estrutural, semântica, operacional, nativa ou DACL.

## Escopo e isolamento

Criados exatamente seis arquivos em `contratos_c/` e somente este índice e
`MANIFESTO_SHA256_C6` na raiz. Diretório novo e exclusivo:
`/workspace/work/WIN19-C6-CONTRATOS-20261123`.
Os diretórios ancestrais foram examinados por leitura de metadados, sem Git;
não foram encontrados marcadores `.git` nesses ancestrais. Nenhum link foi criado.
A escrita ficou nesta pasta; não houve criação de worktree nem escrita na candidata,
no produto, nas fontes C5 ou nas entregas anteriores. Não houve medição Windows
nova dos 470 arquivos nem acesso à custódia privada do Portão B.

A autorização C6 abrange dados declarativos e dois documentos de custódia. Não
abrange ZIP, publicação, Categoria B, execução ou validação por código. Não foram
criados outros artefatos de entrega, scripts, fixtures, runners ou dependências.

## Arquivos finais e origem

Todos abaixo usam a versão exata indicada. SHA-256 e bytes são dos arquivos escritos;
não são hashes de instâncias de execução ou evidências Windows.

| Caminho relativo | Bytes | SHA-256 | Documento C5 principal |
|---|---:|---|---|
| contratos_c/evento.schema.json | 10180 | 682edd46b9bd41d70a25f7341ef6844c7adcd005686982cadf5eb81f152f567d | CONTRATO_EVENTO_PROPOSTO.md |
| contratos_c/mensagem.schema.json | 10938 | d64e545a02524f6bce02c3541518a7d04c04ad886cdd8198514327bd5be32e98 | CONTRATO_MENSAGEM_ACK_PROPOSTO.md |
| contratos_c/estados.json | 13013 | 27c3f56e9e657afb4743f18dadead8de05e234d8d5eb5318cb48ab68dae3ea77 | CONTRATO_ESTADOS_PROPOSTO.md |
| contratos_c/relatorio.schema.json | 20836 | ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6 | CONTRATO_RELATORIO_PROPOSTO.md |
| contratos_c/cobertura_21.csv | 5305 | 5a7e77e6ce8690e6153b512482db859184d3d8533e40a5e11e0bfd8a65ebf599 | CONTRATO_COBERTURA_21_PROPOSTO.md |
| contratos_c/vetores_de_contrato.json | 10711 | ed00b1e28d07ca669ccc488bd3d5c403cb64768da554e187bfeba64ceca9a447 | CONTRATO_VETORES_SINTETICOS_PROPOSTO.md |

A BASE comum rege os seis. ESCOPO_EXATO, RISCOS, CONFERENCIA e parecer independente
C5 complementam cada origem. O manifesto cobre os seis arquivos e este índice,
excluindo apenas a si próprio. Seu SHA-256 será informado na conversa, evitando
autorrecursão de hashes. Não é assinatura digital ou atestação de custódia Windows.

## Fontes consultadas e identidade documental

Os dez documentos C5 abaixo foram lidos na pasta preservada
`WIN19-C5-CONTRATOS-DOCUMENTAIS-20261119`, externa ao produto. Não foram copiados
para esta entrega. Manifesto C5 conferido por hashes dos 17 arquivos cobertos:
`b8a3a391097ce220b7764d3f368e2cf85cbd0eeb4b260e98d99a96794e505af5`.

| Fonte C5 | Bytes | SHA-256 |
|---|---:|---|
| BASE_COMUM_E_VERSIONAMENTO_C5.md | 10176 | 602f11ee0edeac245353daf4663d135492b4f90246bb1f2bb142ee75334cd6f8 |
| CONTRATO_EVENTO_PROPOSTO.md | 6798 | d5d1322d38a90071db86d91beb271138d7ac7ed9820b2be178281c696a51358a |
| CONTRATO_MENSAGEM_ACK_PROPOSTO.md | 6409 | f918f3502c3c215b6663d9058bf8acd730eb3279f6a76cb52cd5e08beea7ce9c |
| CONTRATO_ESTADOS_PROPOSTO.md | 9044 | 83879120ac482357a28b4897fb02467a800190b351f91bca9b7d2f03cecec614 |
| CONTRATO_RELATORIO_PROPOSTO.md | 11537 | 982c73c3a59558cb94e6a5feccdad392642e111518a892f1f105aec8a27608ce |
| CONTRATO_COBERTURA_21_PROPOSTO.md | 7347 | 2a0a74c2a5464cbaddede4a09538802c21b5e8b5c2472d403b52e085d704dcb1 |
| CONTRATO_VETORES_SINTETICOS_PROPOSTO.md | 9008 | a84a075ae4ac0ed5990ae5665c8e1bee428f1b0430ad75343e9c333aae450ff1 |
| ESCOPO_EXATO_AUTORIZACAO_FUTURA_A.md | 4289 | 87032ef88517e67d38476d90244cc163bada43521446620e1b424e8d0fb82022 |
| RISCOS_E_DECISOES_PENDENTES_C5.md | 6281 | 837f90bed7240978b7989045105b12109035f6ef561295ca3a5a515ddde4d68a |
| CONFERENCIA_DOCUMENTAL.md | 2918 | 11823994fa2740486159a27d3c643610a3b0d3a9c773e9ee7ae866441e3e328b |

Instrução C6 recebida, `Texto colado.txt`: 9767 bytes, SHA-256
`c13e2ae207beb95aae7ce6e23d3ad5bf90f93b46b00dd42962d22c2e69f4dab5`.
Parecer `PARECER_INDEPENDENTE_WIN19_C5_2026-11-23.md`: 7845 bytes, SHA-256
`b3f2488d282d654469dff24405e4939a06365340f109874df8bda00769e59ed7`.
A autorização C6 supera a pendência de CRIAÇÃO dos seis arquivos mencionada nas
fontes históricas; não muda a autorização de testes nem o marco documental C5.

O alias `MATRIZ_C2_AUDITADA` conserva a referência C5 à matriz documental
`WIN19-C1-C2-COMPLEMENTACAO-20261118/MATRIZ_C2_ATUALIZADA.csv`, SHA-256 novamente
conferido `bacea89f2b5c0e33f47d15fdd8405573d8fe2a038c7e865182f1bfceb44715fd`.
Isso não a converte em fonte primária, JUnit ou histórico confirmado.

## Materialização e conferência documental

- Três schemas propostos para Draft 2020-12 offline, sem `$schema`/`$id`, URL,
  referência entre arquivos ou consumidor implícito. `estados.json` declara
  `DRAFT_2020_12_OFFLINE_C5`. Consumidor genérico não recebe compatibilidade presumida.
- Objetos de instância fechados; presença obrigatória, nulidade e enums descritos
  nas fontes. Fragmentos internos de restrição compõem objetos fechados; não são
  objetos de instância adicionais. Sem defaults ou preenchimento automático.
- Tipos comuns copiados literalmente, por operação textual, nos três schemas.
  Bloco de `ID` até `CustodiaRef`, inclusive, com SHA-256 idêntico nas três cópias:
  `9905fd31551d9f50c78e6afc0e8db491d9b03b489f04fc557713df9f51405329`.
  Isso comprova igualdade desses bytes, não correção do desenho ou de seu consumo.
- Referências de schema lidas como texto: exclusivamente `#/$defs/` locais.
  A inspeção das dependências não identificou ciclos: tipos escalares/listas;
  HashDeclarado; HashNaoFabricado; Observacao/Esperado; FalhaSegura/CustodiaRef;
  composições próprias de mensagem/relatório. Sem resolvedor executado.
- Eventos não contêm resultado PASS/FAIL/SKIP. Observado e esperado permanecem
  distintos; ausência usa estado/null/motivo; falha de persistência é declaração.
- Mensagens distinguem referência, ACK declarado e incidente. Um hash ausente não
  constitui correspondência; igualdade entre peças não é calculada pelo schema.
  Não há transporte, flush, fsync, endpoint ou promessa de disco.
- Catálogo de estados: taxonomias independentes e 43 relações documentais obtidas
  pela expansão literal dos pares da seção 3 do contrato de estados. Os aliases
  `ROT_*` e `REGRA_TRANSICOES_C5` identificam essas relações e sua seção de origem;
  não são regras executáveis. Fundamentos usam as categorias documentais C5.
  Não foram acrescentados pares de transição nem ações. Marco C5 mantido.
- Relatório: cardinalidade 21; WIN-03 preserva duas afirmações, com ramo de erro
  nativo bloqueado; WIN-18/19 mantêm PORTAO_D e eixos NÃO_VALIDADO. Não há agregado
  PASS ou homologação. Condicionais declarativas não constituem julgador executável.
- Cobertura: 22 linhas físicas incluindo cabeçalho; 13 separadores no cabeçalho,
  correspondendo às 14 colunas especificadas. Contagem textual: 21 subcasos únicos,
  19 WIN, API=5, LINK=11, MODO=3, CHMOD=2; WIN-11/13 A/B. Afirmações e bloqueios
  copiados da tabela C5, com pipe interno. Sem nodeids ou seletores de pytest.
- Dez vetores V01–V10 explicitamente sintéticos. V01/V02/V05 são eventos completos;
  V09 mensagem completa. V03/V04/V06/V07/V08/V10 são projeções tipadas, sem tentativa
  de tratá-las como relatórios completos de 21 casos. Não são fixtures executáveis.
  Em V01, true é indicador fabricado HELPER, não flag de autorização do produto.
  V07 não inventa primeira causa; V08 não inventa API/código da falha de cleanup.
- Escrita literal UTF-8, sem BOM; leitura dos bytes iniciais e LF final dos seis;
  busca textual sem CR. Sem normalização de fonte histórica. Conferência de texto,
  não parsing JSON/CSV ou validação estrutural dos arquivos.
- Conteúdo limitado a aliases, enums e modelos; sem documentos reais, nomes de
  pessoas/clientes, caminhos pessoais, credenciais ou valores financeiros privados.
  Buscas textuais adicionais não localizaram padrões de segredo, CPF/CNPJ formatado,
  caminhos pessoais ou URLs nos seis arquivos. Não é prova forense de privacidade.

## Divergências, limites e pendências

Nenhuma divergência documental impeditiva foi identificada nesta conferência;
os seis arquivos foram materializados, nenhum ficou bloqueado na criação. Nenhum
campo de instância, enum, cardinalidade de escopo ou semântica C5 foi deliberadamente
substituído. Os nomes internos de `$defs`, aliases editoriais e a disposição textual
expressam a proposta, sem serem evidência de implementação Categoria B.

A conferência NÃO incluiu parsing, validação sintática/estrutural por runtime,
validador JSON Schema, verificação automatizada das regras entre registros, testes,
APIs Windows, observação do produto ou evidência factual. Possíveis erros de
transcrição, restrição excessiva/insuficiente e interpretação do dialeto ainda
precisam de auditoria independente dos bytes e decisão separada de validação.

Cardinalidade de array não comprova conjunto exato ou unicidade por chave;
`uniqueItems` de objetos não resolve esse problema. A associação WIN/subcaso,
conjunto de afirmações, referência existente, sequência íntegra, correlação/hash,
autorização legítima e integridade/custódia factual continuam S/P, sem comprovação.
As guardas de forma não tornam PASS legítimo por preenchimento de rótulos e IDs.
Capacidade e precondições, prova primária e eixos efetivamente exercitados exigem
revisão externa. SKIP, setup falho, zero, true ou ausência de exceção não provam
segurança. ACK declarado não prova persistência. Limites de bytes totais, fluxo,
timeout, retenção e demais orçamentos permanecem PARA_REVISÃO, sem valores novos.

## Estados preservados e parada

`prontidao_para_executar=false`; `autorizacao_testes=PENDENTE`;
`runner_C=NÃO_IMPLEMENTADO`; `WIN01–WIN19=NÃO_VALIDADO`;
`vinculos_historicos=PROVISORIO_SEM_FONTE`; revisor histórico PENDENTE;
`T01/T06=ESPECIFICADO`; `T02=BLOQUEADO`; `T03/T04/T05/T07=PARCIAL`;
`DACL=NÃO_VALIDADO`; `D01–D10=PARA_APROVAÇÃO`; `C/D/E=BLOQUEADOS`;
`CONVERSOES_REAIS=BLOQUEADAS`.

Baseline preservado: `770d062d29c4361d6932592883df9339bb4089bc`, referência R1-FIX
470 arquivos, sem nova medição Windows. Sem Python, PowerShell, pytest, parser,
validador, script auxiliar novo, instalação, configuração, alteração de ACL/DACL,
privilégio ou conta. Não houve commit, push, merge, publicação ou ZIP.
Parada na entrega declarativa para auditoria dos seis arquivos. Não iniciar B,
ensaios, recuperação de JUnit, repetição do Portão B ou qualquer atividade do Portão C.
