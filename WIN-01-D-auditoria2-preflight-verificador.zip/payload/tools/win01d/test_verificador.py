"""Links estáticos e reparse simulado: não substituem junction nativa Windows."""
import hashlib
import importlib.util
from pathlib import Path
import os
import stat
from types import SimpleNamespace

import pytest
from tests.windows_support import criar_symlink

SCRIPT = Path(__file__).with_name('reconstruir.py')
spec = importlib.util.spec_from_file_location('rebuild_test', SCRIPT)
rebuild = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rebuild)


@pytest.fixture
def tree(tmp_path, monkeypatch):
    root = tmp_path / 'tree'; root.mkdir()
    (root / 'src').mkdir(); (root / 'src' / 'a.txt').write_bytes(b'sintetico')
    expected = {'arquivos': {'src/a.txt': hashlib.sha256(b'sintetico').hexdigest()}}
    monkeypatch.setattr(rebuild.subprocess, 'check_output', lambda *a, **kw: rebuild.BASE)
    return root, expected


def test_arvore_regular_confere(tree):
    root, expected = tree
    assert rebuild.verificar(root, expected)['hashes'] == 'OK'


@pytest.mark.parametrize('kind', ['broken', 'file', 'directory', 'cache'])
def test_symlink_extra_nao_e_ignorado(tree, tmp_path, kind):
    root, expected = tree
    outside = tmp_path / 'outside'
    if kind == 'file': outside.write_bytes(b'fora')
    elif kind == 'directory': outside.mkdir()
    link = root / 'extra'
    if kind == 'cache':
        (root / '__pycache__').mkdir(); link = root / '__pycache__' / 'extra'
    criar_symlink(link, outside, target_is_directory=kind == 'directory')
    with pytest.raises(RuntimeError): rebuild.verificar(root, expected)


def test_pai_simbolico_nao_pode_ser_usado_para_hash(tree, tmp_path, monkeypatch):
    root, expected = tree
    (root / 'src' / 'a.txt').unlink(); (root / 'src').rmdir()
    outside = tmp_path / 'outside'; outside.mkdir(); (outside / 'a.txt').write_bytes(b'sintetico')
    criar_symlink(root / 'src', outside, target_is_directory=True)
    def nao_ler(_): pytest.fail('Nao ler arquivo externo atraves de pai simbolico')
    monkeypatch.setattr(rebuild, 'sha', nao_ler)
    with pytest.raises(RuntimeError): rebuild.verificar(root, expected)


def test_raiz_simbolica_nao_pode_ser_resolvida(tree, tmp_path):
    root, expected = tree
    alias = tmp_path / 'alias'; criar_symlink(alias, root, target_is_directory=True)
    with pytest.raises(RuntimeError): rebuild.verificar(alias, expected)


def test_arquivo_regular_extra_e_recusado(tree):
    root, expected = tree
    (root / 'extra.txt').write_bytes(b'extra')
    with pytest.raises(RuntimeError): rebuild.verificar(root, expected)


@pytest.mark.parametrize('name', ['../escape', '/absoluto', 'C:/escape', 'src/../a.txt', 'src\\a.txt'])
def test_manifesto_nao_pode_escapar_da_raiz(tree, name):
    root, expected = tree
    expected['arquivos'] = {name: expected['arquivos']['src/a.txt']}
    with pytest.raises(RuntimeError): rebuild.verificar(root, expected)


def test_reparse_windows_simulado_nao_e_atravessado(tree, monkeypatch):
    root, expected = tree
    original = Path.lstat
    def lstat(path, *args, **kwargs):
        result = original(path, *args, **kwargs)
        if path == root / 'src':
            return SimpleNamespace(st_mode=result.st_mode, st_file_attributes=0x400)
        return result
    monkeypatch.setattr(Path, 'lstat', lstat)
    with pytest.raises(RuntimeError): rebuild.verificar(root, expected)


def test_reparse_extra_simulado_em_diretorio(tree, monkeypatch):
    root, expected = tree
    (root / 'extra-dir').mkdir()
    original = Path.lstat
    def lstat(path, *args, **kwargs):
        result = original(path, *args, **kwargs)
        if path == root / 'extra-dir':
            return SimpleNamespace(st_mode=result.st_mode, st_file_attributes=0x400)
        return result
    monkeypatch.setattr(Path, 'lstat', lstat)
    with pytest.raises(RuntimeError): rebuild.verificar(root, expected)


def test_ancestrais_futuros_permitidos_sem_link(tmp_path):
    assert rebuild.ancestrais_existentes_seguros(tmp_path / 'novos' / 'pais') == tmp_path


def test_ancestral_quebrado_recusado_antes_de_criar(tmp_path):
    alias = tmp_path / 'alias'; criar_symlink(alias, tmp_path / 'ausente', target_is_directory=True)
    with pytest.raises(RuntimeError):
        rebuild.ancestrais_existentes_seguros(alias / 'novo')
    assert not (tmp_path / 'ausente').exists()
