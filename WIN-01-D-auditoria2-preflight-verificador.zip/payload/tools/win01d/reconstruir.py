"""Reconstrói a candidata D em destino novo, sem commits, rede ou instalação."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import stat
import tempfile

BASE = '770d062d29c4361d6932592883df9339bb4089bc'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def no_sem_link(path):
    info = path.lstat()  # Inclui symlinks quebrados; não usar exists/is_file antes.
    if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
        raise RuntimeError('LINK_OU_REPARSE_NAO_PERMITIDO')
    if hasattr(path, 'is_junction') and path.is_junction():
        raise RuntimeError('JUNCTION_NAO_PERMITIDA')
    return info


def cadeia_segura(path):
    path = Path(os.path.abspath(path))  # Nunca resolve symlinks antes de inspecionar.
    for parent in reversed((path, *path.parents)):
        info = no_sem_link(parent)
        if parent != path and not stat.S_ISDIR(info.st_mode):
            raise RuntimeError('PAI_NAO_DIRETORIO')
    return path


def ancestrais_existentes_seguros(path):
    path = Path(os.path.abspath(path))
    while True:
        try:
            no_sem_link(path)
        except FileNotFoundError:
            parent = path.parent
            if parent == path:
                raise RuntimeError('ANCESTRAL_INDISPONIVEL')
            path = parent
        else:
            return cadeia_segura(path)


def caminho_manifesto(root, name):
    if not isinstance(name, str) or not name or ':' in name or '\\' in name:
        raise RuntimeError('CAMINHO_MANIFESTO_INVALIDO')
    if Path(name).is_absolute() or any(p in ('', '.', '..', '.git') for p in name.split('/')):
        raise RuntimeError('CAMINHO_MANIFESTO_INVALIDO')
    return cadeia_segura(root / name)


def arvore_sem_links(root, expected):
    pending = [root]
    while pending:
        current = pending.pop()
        no_sem_link(current)
        with os.scandir(current) as entries:
            for entry in entries:
                p = current / entry.name
                info = no_sem_link(p)
                rel = p.relative_to(root)
                if rel.as_posix() == '.git':
                    continue  # Metadados legítimos do Git; seu nó já foi inspecionado.
                if stat.S_ISDIR(info.st_mode):
                    pending.append(p)  # Nenhum link/reparse é enfileirado.
                elif stat.S_ISREG(info.st_mode):
                    cache = any(part in ('__pycache__', '.pytest_cache') for part in rel.parts)
                    if not cache and rel.as_posix() not in expected:
                        raise RuntimeError('ARQUIVOS_EXTRAS')
                else:
                    raise RuntimeError('NO_NAO_REGULAR')


def verificar(root, spec):
    root = cadeia_segura(root)
    if not stat.S_ISDIR(no_sem_link(root).st_mode):
        raise RuntimeError('RAIZ_NAO_DIRETORIO')
    paths = {name: caminho_manifesto(root, name) for name in spec['arquivos']}
    # Varredura ocorre antes do Git/hashes; links extras e caches não escapam por filtros.
    arvore_sem_links(root, paths)
    head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    if head != BASE:
        raise RuntimeError('BASE_INESPERADA')
    for name, expected in spec['arquivos'].items():
        p = cadeia_segura(paths[name])
        if not stat.S_ISREG(no_sem_link(p).st_mode) or sha(p) != expected:
            raise RuntimeError('HASH_DIVERGENTE: ' + name)
        cadeia_segura(p)
    return {'base': head, 'arquivos_verificados': len(spec['arquivos']), 'hashes': 'OK'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pacote', type=Path, required=True)
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--destino', type=Path)
    parser.add_argument('--verificar', type=Path)
    args = parser.parse_args()
    package = cadeia_segura(args.pacote)
    spec_path = caminho_manifesto(package, 'VERSAO_D_SHA256.json')
    spec = json.loads(spec_path.read_text(encoding='utf-8'))
    if spec['base'] != BASE:
        raise RuntimeError('MANIFESTO_BASE_INESPERADA')
    if args.verificar:
        print(json.dumps(verificar(args.verificar, spec)))
        return
    if not args.repo or not args.destino:
        parser.error('requer --repo e --destino ou --verificar')
    target = Path(os.path.abspath(args.destino))
    ancestrais_existentes_seguros(target.parent)
    if target.exists() or target.is_symlink():
        raise RuntimeError('DESTINO_PREEXISTENTE')
    for name, expected in spec['payload'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts or ':' in name or '\\' in name:
            raise RuntimeError('CAMINHO_INVALIDO')
        if sha(caminho_manifesto(package / 'payload', name)) != expected:
            raise RuntimeError('PAYLOAD_CORROMPIDO')
    subprocess.run(['git', '-C', str(args.repo), 'cat-file', '-e', BASE + '^{commit}'], check=True)
    subprocess.run(['git', '-C', str(args.repo), '-c', 'core.autocrlf=false', 'worktree', 'add', '--detach', str(target), BASE], check=True)
    for name in spec['payload']:
        p = target / name; before = spec['antes'].get(name)
        ancestrais_existentes_seguros(p.parent)
        if before is None:
            if p.exists() or p.is_symlink():
                raise RuntimeError('COLISAO_INESPERADA')
        elif not stat.S_ISREG(no_sem_link(cadeia_segura(p)).st_mode) or sha(p) != before:
            raise RuntimeError('BASE_COM_BYTES_DIFERENTES')
    for name in sorted(spec['payload']):
        p = target / name; data = caminho_manifesto(package / 'payload', name).read_bytes()
        p.parent.mkdir(parents=True, exist_ok=True)
        cadeia_segura(p.parent)
        if name not in spec['antes']:
            with p.open('xb') as stream:
                stream.write(data)
        else:
            if sha(p) != spec['antes'][name]:
                raise RuntimeError('ALTERACAO_CONCORRENTE')
            with tempfile.NamedTemporaryFile(dir=p.parent, delete=False) as stream:
                temp = Path(stream.name); stream.write(data)
            try:
                os.replace(temp, p)
            finally:
                temp.unlink(missing_ok=True)
    print(json.dumps(verificar(target, spec)))


if __name__ == '__main__':
    main()
