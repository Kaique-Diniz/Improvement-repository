"""Regressões do preflight. Integração PS 5.1 só é executável no Windows real."""
import importlib.util
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace

import pytest

SCRIPT = Path(__file__).with_name('preflight_git.py')
spec = importlib.util.spec_from_file_location('preflight_git', SCRIPT)
preflight = importlib.util.module_from_spec(spec)
spec.loader.exec_module(preflight)


def test_diretorio_externo_com_stderr_esperado(tmp_path):
    assert preflight.classificar(tmp_path) == (preflight.FORA, 0)
    assert preflight.classificar(tmp_path / 'novo' / 'resultados') == (preflight.FORA, 0)
    cli = subprocess.run([sys.executable, str(SCRIPT), str(tmp_path)], capture_output=True, text=True)
    assert cli.returncode == 0 and cli.stdout.strip() == preflight.FORA and cli.stderr == ''


def test_repositorio_e_gitdir_vinculado_recusados(tmp_path):
    repo = tmp_path / 'repo'
    subprocess.run(['git', 'init', '--quiet', '--initial-branch=teste', str(repo)], check=True)
    assert preflight.classificar(repo / 'novos' / 'resultados') == (preflight.DENTRO, 10)
    linked = tmp_path / 'linked'; linked.mkdir()
    (linked / '.git').write_text('gitdir: ' + str(repo / '.git'), encoding='utf-8')
    assert preflight.classificar(linked) == (preflight.DENTRO, 10)
    assert preflight.classificar(repo / '.git') == (preflight.DENTRO, 10)


def test_git_corrompido_nao_e_confundido_com_externo(tmp_path):
    subprocess.run(['git', 'init', '--quiet', '--initial-branch=teste', str(tmp_path)], check=True)
    (tmp_path / '.git' / 'config').write_text('[invalido', encoding='utf-8')
    assert preflight.classificar(tmp_path) == (preflight.ERRO, 2)


@pytest.mark.parametrize('code,message', [(128, b'fatal: bad config: CAMINHO_PRIVADO'),
                                         (1, b'erro inesperado'), (0, b'')])
def test_respostas_inesperadas_bloqueiam(tmp_path, code, message):
    def runner(*args, **kwargs):
        return SimpleNamespace(returncode=code, stdout=b'', stderr=message)
    assert preflight.classificar(tmp_path, executar=runner) == (preflight.ERRO, 2)


@pytest.mark.parametrize('exc', [FileNotFoundError('CAMINHO_PRIVADO'), PermissionError('SEGREDO'),
                               subprocess.TimeoutExpired('git privado', 15)])
def test_falhas_operacionais_nao_vazam_excecao(tmp_path, exc):
    def runner(*args, **kwargs):
        raise exc
    assert preflight.classificar(tmp_path, executar=runner) == (preflight.ERRO, 2)


def test_limite_filesystem_externo_conhecido(tmp_path):
    def runner(*args, **kwargs):
        assert kwargs['capture_output'] and kwargs['env']['LC_ALL'] == 'C'
        return SimpleNamespace(returncode=128, stdout=b'', stderr=(
            b'fatal: not a git repository (or any parent up to mount point /)\n'
            b'Stopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).\n'))
    assert preflight.classificar(tmp_path, executar=runner) == (preflight.FORA, 0)


def test_caminho_existente_nao_diretorio_recusado(tmp_path):
    path = tmp_path / 'arquivo'; path.write_bytes(b'sintetico')
    assert preflight.classificar(path) == (preflight.ERRO, 2)


@pytest.mark.skipif(sys.platform != 'win32' or not shutil.which('powershell.exe'),
                    reason='Windows PowerShell 5.1 nativo indisponivel; NAO_VALIDADO')
def test_integracao_powershell_51_com_error_action_stop():
    result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-File',
                             str(SCRIPT.with_name('test_preflight_ps51.ps1')), '-Python', sys.executable],
                            capture_output=True, text=True, timeout=60)
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'diretorio_externo: APROVADO' in result.stdout
    assert 'git_config_invalida: ERRO_OPERACIONAL' in result.stdout
    assert 'git_ausente: ERRO_OPERACIONAL' in result.stdout


def test_head_ausente_em_ancestral_nao_e_externo(tmp_path):
    repo = tmp_path / 'repo'
    subprocess.run(['git', 'init', '--quiet', '--initial-branch=teste', str(repo)], check=True)
    nested = repo / 'sub'; nested.mkdir()
    assert preflight.classificar(nested) == (preflight.DENTRO, 10)
    (repo / '.git' / 'HEAD').unlink()
    assert preflight.classificar(nested / 'resultados') == (preflight.ERRO, 2)


def test_bare_com_head_ausente_fica_bloqueado(tmp_path):
    subprocess.run(['git', 'init', '--bare', '--quiet', str(tmp_path)], check=True)
    assert preflight.classificar(tmp_path) == (preflight.DENTRO, 10)
    (tmp_path / 'HEAD').unlink()
    assert preflight.classificar(tmp_path) == (preflight.ERRO, 2)


def test_gitdir_quebrado_fica_bloqueado(tmp_path):
    (tmp_path / '.git').write_text('gitdir: /diretorio-inexistente-sintetico', encoding='utf-8')
    assert preflight.classificar(tmp_path) == (preflight.ERRO, 2)
