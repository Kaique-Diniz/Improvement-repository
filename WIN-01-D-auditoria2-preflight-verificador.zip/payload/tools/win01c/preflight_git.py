"""Classifica a área de evidências; stdout só contém código seguro, nunca stderr Git."""
import os
from pathlib import Path
import re
import subprocess
import sys

FORA = 'FORA_DO_GIT'
DENTRO = 'EVIDENCIAS_DENTRO_DO_GIT'
ERRO = 'PREFLIGHT_GIT_ERRO_OPERACIONAL'


def tem_metadados_git(path):
    """Inspeciona marcadores sem seguir .git, mesmo se HEAD ou gitdir estiverem danificados."""
    for parent in (path, *path.parents):
        def presente(name):
            try:
                (parent / name).lstat()
                return True
            except FileNotFoundError:
                return False
        if presente('.git'):
            return True
        # Assinatura conservadora de repositório bare, inclusive sem HEAD.
        if sum(presente(n) for n in ('objects', 'refs', 'HEAD', 'config')) >= 2:
            return True
    return False


def classificar(caminho, *, executar=None):
    executar = subprocess.run if executar is None else executar
    try:
        lexical = Path(os.path.abspath(caminho))
        metadados = tem_metadados_git(lexical)
        existing = lexical.resolve()
        metadados = tem_metadados_git(existing) or metadados
        while not existing.exists():
            parent = existing.parent
            if parent == existing:
                return ERRO, 2
            existing = parent
        if not existing.is_dir():
            return ERRO, 2
        env = os.environ.copy()
        env['LC_ALL'] = 'C'
        env['LANGUAGE'] = 'C'
        result = executar(['git', '-C', str(existing), 'rev-parse', '--absolute-git-dir'],
                         capture_output=True, env=env, timeout=15)
        if result.returncode == 0:
            # Inclui worktrees principais/vinculadas, diretórios .git e repositórios bare.
            return (DENTRO, 10) if result.stdout.strip() else (ERRO, 2)
        message = result.stderr.decode('utf-8', errors='replace').strip()
        expected = message == 'fatal: not a git repository (or any of the parent directories): .git'
        boundary = re.fullmatch(
            r'fatal: not a git repository \(or any parent up to mount point [^\r\n]+\)\r?\n'
            r'Stopping at filesystem boundary \(GIT_DISCOVERY_ACROSS_FILESYSTEM not set\)\.', message)
        if result.returncode == 128 and not result.stdout.strip() and (expected or boundary) and not metadados:
            return FORA, 0
        return ERRO, 2
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired):
        return ERRO, 2


def main():
    status, code = classificar(sys.argv[1]) if len(sys.argv) == 2 else (ERRO, 2)
    print(status)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
