# WIN-01-D — revisão 2 dos controles de auditoria

Esta candidata está em worktree Linux separada /workspace/work/win-01-d-auditoria2, sobre 770d062d29c4361d6932592883df9339bb4089bc. Foi reconstruída pelos 451 hashes do ZIP D publicado antes de qualquer alteração. A, C, D auditada, suas reconstruções e pacotes anteriores não foram modificados. Não houve commit, push, PR, merge ou publicação.

## Reprodução e correção do preflight

A regressão real de Git sintético confirmou: antes da correção, o repositório era recusado, mas remover .git/HEAD fazia seu descendente receber FORA_DO_GIT. Também foi reproduzida a falha num bare sem HEAD. O helper agora inspeciona .git por lstat em todos os ancestrais lexicais e resolvidos, inclusive marcadores quebrados. Para bare, considera conservadoramente a existência de ao menos dois dos marcadores objects/refs/HEAD/config. Esses marcadores não autorizam nada: se Git falhar em reconhecer o repositório, impedem a classificação como externo.

Git válido continua EVIDENCIAS_DENTRO_DO_GIT/10. Metadados danificados e erros operacionais são PREFLIGHT_GIT_ERRO_OPERACIONAL/2. FORA_DO_GIT/0 só é possível com exit 128, diagnóstico conhecido em locale C, stdout vazio e nenhum marcador nos ancestrais. Timeouts, configuração inválida, Git ausente e respostas inesperadas continuam bloqueados. O stderr segue capturado no subprocesso Python; não se alterou ErrorActionPreference nem o wrapper PowerShell.

## Reprodução e correção do verificador

Antes, oito regressões falharam (somando preflight e verificador), incluindo link quebrado, link extra para diretório, link em cache, raiz/pai simbólico e reparse simulado. A nova verificação:

- Não resolve raiz/pacote antes de inspecionar os ancestrais.
- Usa lstat em cada nó e rejeita S_ISLNK, FILE_ATTRIBUTE_REPARSE_POINT e is_junction quando disponível.
- Rejeita caminhos do manifesto absolutos, com .., .git ou formas de escape Windows.
- Confere todos os pais de cada caminho esperado antes de ler hashes.
- Percorre a árvore por scandir, sem enfileirar nós de link/reparse; links extras ou quebrados não desaparecem por is_file/exists.
- Examina links também em caches; só tolera arquivos regulares de caches. Exclui a travessia interna dos metadados Git legítimos na raiz depois de inspecionar seu nó .git. Um .git simbólico/reparse é recusado; um gitdir regular de worktree vinculada permanece permitido.
- Rejeita arquivos extras e nós especiais. Mantém comparação de todos os hashes e da base.
- Na reconstrução, confere também payload e pais existentes antes de criar arquivos; destino preexistente continua recusado.

O verificador novo conferiu com sucesso os 451 hashes da reconstrução D anterior, sem modificar seus arquivos. A nova candidata tem manifesto próprio, com os acréscimos da revisão. Foram adicionados testes de arquivo regular válido, extras, caminhos inválidos, symlink de arquivo/diretório/raiz/pai/cache, link quebrado e atributos reparse simulados.

Limite: a inspeção documentada trata uma árvore estática sob guarda do auditor. Não é um sandbox nem prova de imunidade contra troca concorrente maliciosa de diretórios entre lstat/scandir/open; nenhuma garantia atômica Windows ou isolamento entre usuários/processos foi adicionada. Reparse/junction foi exercitado sinteticamente no Linux; execução nativa Windows continua pendente. Não converter esses testes em homologação de segurança NTFS.

## Escopo preservado

Nenhum arquivo src, regra de negócio, leitor, teste histórico ou as três correções POSIX foram alterados em relação ao ZIP D recebido. DACL_WINDOWS_NAO_VALIDADA e os onze skips Windows relatados permanecem pendências independentes. Alterações anteriores em C/D só aparecem no diff agregado contra a base, não são novas correções desta revisão.

Os únicos arquivos anteriores alterados nesta revisão são tools/win01c/preflight_git.py, tools/win01c/test_preflight_git.py e tools/win01d/reconstruir.py. O teste tools/win01d/test_verificador.py é novo; a documentação desta pasta também é nova. Os testes reais de links usam o helper sintético já existente: se Windows não puder criá-los por erro 1314, serão explicitamente não validados, sem enfraquecer o verificador.

## Validação

Focados finais: 41 aprovados, 1 ignorado, zero falhas/erros em Linux/Python 3.12.14. Único skip: integração Windows PowerShell 5.1 indisponível no executor. A primeira rodada de regressão, antes da implementação, tinha 8 falhas/20 aprovações/1 skip; os logs são preservados. Rodadas intermediárias são sobrepostas.

Suíte completa Linux executada após focados aprovados, selecionando tests integral, testes de preflight, guards POSIX e verificador. Resultado em resultado.json e completa.xml/log. PYTHONUTF8=0, sem -X utf8; dependências existentes e nenhuma instalação automática. PowerShell 5.1 e Windows real não foram executados.

Diff desta revisão é relativo ao ZIP D publicado e inclui todos os arquivos novos. Pacote novo local, com manifesto SHA-256 interno e de versão completa, será entregue para conferência antes de qualquer reconstrução Windows. O pacote D e seus 451 hashes históricos não são sobrescritos.


Resultado final: **2717 passed, 1 skipped, 1 warning em 192,51 s**; zero falhas/erros, 2718 casos na rodada completa. O único skip é PowerShell 5.1 nativo; o warning é a depreciação Starlette/AnyIO conhecida. Sintaxe: 276 arquivos Python compilados em memória, sem erro; pip check e git diff --check sem erro. Não somar as execuções focadas às completas.
