# Reconstrução da revisão 2 — somente após auditoria independente

A revisão utiliza o mesmo baseline 770d062d29c4361d6932592883df9339bb4089bc. Não aplicar sobre as worktrees A/C/D ou a candidata Windows de 451 hashes. Extrair o novo ZIP em diretório novo; conferir seu SHA-256 externo e MANIFESTO_PACOTE_SHA256.json antes de confiar no manifest/payload. Não instalar dependências ou alterar políticas pelo procedimento.

Usar Python 3.12 existente e um checkout que já possua a base:

```powershell
$PacoteWin01D2 = 'PREENCHER_PASTA_NOVA_DO_PACOTE_EXTRAIDO'
$RepoWin01D2 = 'PREENCHER_CHECKOUT_GIT_EXISTENTE'
$DestinoWin01D2 = Join-Path $env:LOCALAPPDATA 'ConversorWIN01D-Auditoria2-Nova'
py -3.12 (Join-Path $PacoteWin01D2 'reconstruir.py') --pacote "$PacoteWin01D2" --repo "$RepoWin01D2" --destino "$DestinoWin01D2"
py -3.12 (Join-Path $PacoteWin01D2 'reconstruir.py') --pacote "$PacoteWin01D2" --verificar "$DestinoWin01D2"
```

Manifesto VERSAO_D_SHA256.json atualizado: confere todo o conteúdo da versão, não só HEAD ou arquivos modificados. A verificação recusa links/reparse points e pais simbólicos, extras e hashes divergentes. Diretório destino existente é recusado; nenhuma remoção/recriação silenciosa. O checkout usa core.autocrlf=false somente na chamada para preservar os bytes, sem mudar configuração persistente. Logs/venv/documentos devem ficar fora da worktree reconstruída; caches regulares Python/pytest não constituem arquivos candidatos, mas links neles são recusados.

A raiz deve ser acessível por caminho sem links/junctions/reparse points também nos ancestrais. Um caminho com junction conhecida não é aceito silenciosamente: escolher um caminho direto após revisão. Uma falha deixa o destino para diagnóstico. Não modificar o destino ou os manifestos para fazê-los passar.

A inspeção não garante atomicidade contra mudanças concorrentes hostis da árvore. Verificar antes/depois das rodadas em árvore estática privada sob guarda do auditor. DACL e isolamento do SO continuam não comprovados; os skips nativos anteriores não são aprovações.

A execução PowerShell 5.1 nativa continua pendente e deve ser registrada separadamente. Não iniciar execução Windows até a auditoria do novo pacote. Os arquivos antigos, seus testes e seus logs permanecem referência imutável.
