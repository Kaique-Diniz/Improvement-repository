# WIN19-H3-F — índice, proveniência e hashes

24/11/2026 — America/Sao_Paulo.
Pasta exclusivamente documental: /workspace/work/WIN19-H3-F-VERIFICACAO-DESTINO-20261124,
externa ao Git e às candidatas. Não é destino de custódia e não existe local
Windows criado por esta preparação.

## Nove arquivos

1. [RELATORIO_H3_F.md](RELATORIO_H3_F.md) — escopo, decisões e resultado documental.
2. [COMANDO_WINDOWS_VERIFICACAO_DESTINO.md](COMANDO_WINDOWS_VERIFICACAO_DESTINO.md)
   — único bloco PowerShell proposto; não executado nem validado por parser.
3. [REVISAO_ESTATICA_COMANDO.md](REVISAO_ESTATICA_COMANDO.md) — operações de consulta,
   efeitos, paradas e pontos para auditoria; não equivale a teste do código.
4. [MATRIZ_V01_V10_H3_F.csv](MATRIZ_V01_V10_H3_F.csv) — dez critérios e sua cobertura;
   estado real de cada um NAO_EXECUTADO, proteção NAO_VERIFICADA.
5. [MATRIZ_IMPEDIMENTOS_H3_F.md](MATRIZ_IMPEDIMENTOS_H3_F.md) — falhas, códigos,
   inconclusões e paradas sem remediação automática.
6. [MODELO_SAIDA_SANITIZADA_H3_F.md](MODELO_SAIDA_SANITIZADA_H3_F.md) — formato de
   JSON descrito por chaves/tipos, sem instância ou resultado fictício.
7. [LIMITACOES_E_DECISOES_H3_F.md](LIMITACOES_E_DECISOES_H3_F.md) — limitações,
   pendências e portões preservados.
8. INDICE_ENTREGA_H3_F.md — este registro de fontes e bytes.
9. [MANIFESTO_SHA256_H3_F](MANIFESTO_SHA256_H3_F) — oito arquivos anteriores;
   não se autorreferencia. Hash do manifesto informado na conversa.

## Instrução e parecer

Instrução primária recebida: Texto colado.txt, EXP-04 / WIN19 — H3-F, datada de
24/11/2026, 15.477 bytes; SHA-256
9af7caf38c5ddb3819fb19beb23e2d3edc5f661e0687792da58bb0f2a8b8da4c.
Nenhum trecho recebido foi executado; fonte usada como autorização e escopo.

Referência obrigatória recebida e lida integralmente:
PARECER_INDEPENDENTE_WIN19_H3_E_2026-11-24.md, 8.598 bytes, SHA-256
cefc1e7e3c254c0883edc462c2fc41b193d4e7f4aebf564085a12b2edc75f326,
igual à referência da instrução. Aceita H3-E documentalmente com ressalvas de
escopo e verificação operacional pendente. Fundamenta a separação entre leitura
futura do ancestral, proteção do objeto futuro e autorização operacional H3-C.
Suas referências ao ZIP/manifesto e aos sete documentos H3-E coincidem com os
artefatos preservados. O parecer não foi copiado para a nova pasta nem tratado
como autorização de Windows, acesso ao XML ou testes. Seus limites probatórios e
pendências materiais constam no relatório e nas limitações desta H3-F.

## Fontes H3-E consultadas e preservadas

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| CHECKLIST_VERIFICACAO_DESTINO_LOCAL.md | 4817 | f356057688ef7b704f8e74687480b10cf709cd4c5706c839639c936a5e640e88 |
| POLITICA_CUSTODIA_LOCAL.md | 3466 | b3991e85e4f7eb49b88cd86f40103a8ac3f28b97ef51326b46bbcf5924138107 |
| PENDENCIAS_PARA_H3_C.md | 3512 | 66c707b5680a8c2b637bf00ef583357f8b200a2a88169cbc8e1fa38d4e412d66 |
| REQUISITOS_PROCEDIMENTO_COPIA_FIEL.md | 4100 | 7837fff7b9f37484f52855802b834c14539235781a10c9ef32a69f39e303f12e |
| MATRIZ_DECISOES_ATUALIZACAO_PROPOSTA.csv | 15942 | 893077b3131bde3a027fcbeaf73b3329204267084224afef4a4e22dee49c0854 |

Manifesto H3-E: SHA-256
71fba7f8808106efb50215a8287a4b24e38de9c75fb31c4afab63c5094d866d1.
Os sete documentos cobertos e o manifesto foram conferidos; fontes permanecem
iguais. Pacote H3-E anterior, 17.366 bytes, SHA-256
d1031c9adc098b6a23bbbcf0bb61fa955e640bcce060552345b8ea9f6bc17f32,
e pacote H3-D, 18.282 bytes, SHA-256
df301dc2dfb10a45e803d5154b49097561352cd10cee341acb58e7daf2f2f472,
preservados, sem alteração/publicação nova. Não há cópia de contratos/fontes aqui.

## Hash do texto PowerShell, sem executar ou analisar sintaxe

Documento COMANDO_WINDOWS_VERIFICACAO_DESTINO.md, bloco único identificado pelos
marcadores HTML INICIO_BLOCO_POWERSHELL_H3_F e FIM_BLOCO_POWERSHELL_H3_F.
Extrair apenas os bytes após a linha literal de abertura da cerca powershell e
antes da linha de fechamento dessa cerca; excluir cercas/marcadores e incluir
o último LF do código. UTF-8 sem BOM, somente LF, nenhum CR, sem normalização.
Extração por delimitadores documentais, não parsing da linguagem PowerShell.

Tamanho: 19771 bytes. SHA-256:
8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4.
Hash não demonstra funcionamento, compatibilidade, segurança ou aprovação.
Não foi criado .ps1 nem código de teste/simulação.

## Conferências atuais e parada

Somente leitura das fontes documentais, edição do texto proposto e cálculo de
hashes/tamanhos/manifesto com utilitários locais e Python -I -B/stdlib. Nenhum
parser PowerShell, XML, teste, comando Windows ou conteúdo do JUnit foi usado.
Matriz apenas documental; não é pytest ou evidência de consulta de permissões.
Sem criação de custódia, cópia, política/ACL/conta/privilégio, runner, ZIP,
commit/push/merge/publicação. H3-C/H3-S/H4 não autorizadas e demais bloqueios
permanecem conforme LIMITACOES_E_DECISOES_H3_F.md. Parar para revisão independente.
