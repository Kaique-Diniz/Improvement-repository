# H3-F — matriz de impedimentos, inconclusões e parada

24/11/2026. Especificação estática; nenhum caso foi provocado ou simulado.
Os códigos são constantes públicas, não trechos de exceção. Se houver parada,
critérios ainda não abordados permanecem NAO_EXECUTADO. V10 consolida sem aprovar.

| Condição futura | Critério e código/identificação | Estado proposto e ação |
|---|---|---|
| PowerShell diferente de Windows Desktop 5.1 | V01 H3F_AMBIENTE_INCOMPATIVEL | IMPEDIMENTO; parar antes de pedir caminho |
| Sessão remota ou elevada observável | V01 H3F_SESSAO_REMOTA_DETECTADA / H3F_SESSAO_ELEVADA_FORA_DO_ESCOPO | IMPEDIMENTO; não tentar nova sessão elevada nem instalar assistência |
| Contexto/consulta do ambiente indisponível | V01 H3F_CONTEXTO_LOCAL_INDISPONIVEL ou falha genérica | INCONCLUSIVO; parar sem revelar identidade |
| Caminho inválido/ambíguo, relativo, UNC, dispositivo, alias textual não aceito | V03 H3F_CAMINHO_INVALIDO_OU_AMBIGUO / H3F_COMPONENTE_AMBIGUO / H3F_NORMALIZACAO_NAO_IDENTICA | IMPEDIMENTO; não normalizar para outro alvo nem procurar alternativa |
| Ancestral inacessível, erro 3 ou falha de metadados | Critério corrente + H3F_CONSULTA_LOCAL_FALHOU_SEM_DETALHES_PUBLICOS | INCONCLUSIVO; parar; não interpretar como inexistência |
| Root inválida, reparse/junction/symlink | V03 H3F_RAIZ_INACESSIVEL_OU_REDIRECIONADA / H3F_REPARSE_DETECTADO | IMPEDIMENTO; não seguir redirecionamento |
| Ancestral existente não é diretório | V03 H3F_ANCESTRAL_NAO_DIRETORIO | IMPEDIMENTO; não criar ou corrigir caminho |
| Unidade remota/removível | V02 H3F_VOLUME_REMOTO / H3F_VOLUME_REMOVIVEL | IMPEDIMENTO; sem conexão ou fallback |
| Unidade ou mapeamento físico desconhecido | V02 H3F_VOLUME_NAO_IDENTIFICADO / H3F_MAPEAMENTO_FISICO_AMBIGUO / H3F_DISCO_FISICO_NAO_IDENTIFICADO | INCONCLUSIVO; parar, sem dependência ou elevação adicional |
| Barramento externo/remoto reconhecido | V02 H3F_BARRAMENTO_INCOMPATIVEL | IMPEDIMENTO; não escolher outro disco automaticamente |
| Barramento sem base suficiente | V02 H3F_NATUREZA_FISICA_NAO_DEMONSTRADA | INCONCLUSIVO; parar |
| Disco local/barramento compatível observados, posição interna não certificada | V02 H3F_DISCO_LOCAL_OBSERVADO_INTERNO_NAO_CERTIFICADO | INCONCLUSIVO; apenas consultas locais independentes seguras continuam, sem liberar custódia |
| Git/worktree/.git ou sinais de metadados danificados/bare | V04 H3F_COMPONENTE_GIT / H3F_GIT_OU_WORKTREE_DETECTADO / H3F_METADADOS_GIT_AMBIGUOS | IMPEDIMENTO; sem Git, leitura de config, hooks ou reparo |
| Ausência de marcadores Git conhecidos | V04 H3F_SEM_MARCADOR_COMUM_SEPARACAO_GIT_NAO_CERTIFICADA | INCONCLUSIVO; sem supor que repositório arbitrariamente danificado é externo seguro |
| Área proibida conhecida/confronto privado pendente | V05 H3F_REFERENCIAS_PRIVADAS_AREAS_VEDADAS_NAO_FORNECIDAS | INCONCLUSIVO nesta versão; nenhum caminho privado fornecido ao código. Identificação privada posterior de sobreposição é impedimento, sem executar nova busca |
| Sincronização ou compartilhamento incompatível incidente | V06 H3F_INDICADOR_SINCRONIZACAO_INCIDENTE / H3F_COMPARTILHAMENTO_INCIDENTE | IMPEDIMENTO, inclusive share administrativo; não desabilitar serviços ou mudar exposição |
| Indicador/share ambíguo ou consulta indisponível | V06 H3F_INDICADOR_SINCRONIZACAO_AMBIGUO / H3F_SHARE_METADADO_INCOMPLETO / H3F_SHARE_CAMINHO_AMBIGUO / falha genérica | INCONCLUSIVO; parar sem imprimir share/caminho |
| Ausência de indicadores conhecidos | V06 H3F_AUSENCIA_INDICADORES_NAO_PROVA_AUSENCIA_EXPOSICAO | INCONCLUSIVO; sem garantia absoluta |
| Consulta ACL indisponível ou exige privilégio não disponível | V07 + falha genérica sanitizada | INCONCLUSIVO; parar, sem elevar ou habilitar privilégios |
| DACL nula do ancestral | V08 H3F_DACL_NULA_ANCESTRAL | IMPEDIMENTO; não modificar proteção |
| Permissões possivelmente excessivas por allow amplo | V08 H3F_CONCESSAO_AMPLA_REQUER_REVISAO_PRIVADA | INCONCLUSIVO e bloqueio de avanço; deny/grupos/efetividade exigem revisão, sem falsa conclusão de acesso |
| Proteção efetiva de XML/parciais/registros ou papéis não demonstrada | V08 H3F_PROTECAO_FUTURA_E_PAPEIS_NAO_DEMONSTRADOS | INCONCLUSIVO; parar, não criar objeto para testar |
| Destino já existe ou aparece durante avaliação | V09 H3F_DESTINO_JA_EXISTENTE / H3F_COLISAO_OU_ALTERACAO_OBSERVADA | IMPEDIMENTO; não sobrescrever, excluir ou mover |
| Alteração de atributos/presença/reparse observável | V03 H3F_ALTERACAO_OU_REDIRECIONAMENTO | IMPEDIMENTO; não repetir automaticamente. Substituição com mesmos atributos pode escapar, como limitação |
| Exceção operacional inesperada | Critério corrente + H3F_CONSULTA_LOCAL_FALHOU_SEM_DETALHES_PUBLICOS | INCONCLUSIVO; cessar consultas e emitir resumo sem erro bruto |
| Falha ao encerrar recurso consultado | V10 H3F_RECURSO_CONSULTA_NAO_ENCERRADO, além de eventual falha do critério | INCONCLUSIVO, ou preservar IMPEDIMENTO já existente; nunca sucesso silencioso |
| Resultado inconclusivo ou critérios não executados | V10 H3F_CONSOLIDACAO_INCOMPLETA | AVALIACAO_INCOMPLETA; nenhuma aprovação do destino |

Nenhum cenário autoriza criação, sobrescrita, cópia do XML, alteração de ACL/DACL,
owner, conta, política ou privilégio, instalação, reexecução elevada, busca de outro
local, exclusão ou contorno. Após parada, somente consolidação sanitizada e
encerramento controlado de recursos. Os códigos não documentam um fato ocorrido
nesta preparação; seu significado é prospectivo.
