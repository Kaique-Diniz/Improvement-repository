# H3-F — revisão estática do texto PowerShell proposto

24/11/2026. Leitura humana do texto, sem parser, lint, testes sintáticos, execução
ou simulação. Não equivale à comprovação de compatibilidade PowerShell 5.1.

## Operações de consulta e seus limites

| Trecho/função | Operação proposta | Efeitos/limitações considerados |
|---|---|---|
| Invoke-H3FProposta, inicialização | Objetos em memória e preferência de erro no escopo da função | Sem configuração persistente; não usa preferências globais ou ambiente persistente |
| V01 | Versão, plataforma, indicadores da sessão, WindowsIdentity/principal, nome de máquina em memória | Sem logon, impersonação deliberada ou privilégio novo; identidade da sessão não prova legitimidade institucional; rejeita sessão elevada/remota observável |
| Read-Host | Entrada explícita única e privada no host local | Sem padrão nem pedido de caminho no chat; host privado é precondição futura, não garantida pelo código |
| Validação do texto/Path.GetFullPath | Operações de string, nomes e sintaxe nominal | Não resolve identidade física; rejeita UNC, namespaces de dispositivo, relativo, separador alternativo, pontos/espaços finais, nomes reservados e til; limite conservador 240 caracteres |
| DriveInfo + Get-H3LocalRows/V02 | Metadados de unidade local, associação lógica-partição e disco/barramento | Fixed não certifica interno; mapeamento múltiplo/indisponível para; barramento externo/remoto impede; barramento compatível continua inconclusivo |
| Get-H3LocalRows | System.Management em namespaces locais fixos, consultas WMI de leitura | Endereço somente ponto local, EnablePrivileges=false, sem credencial ou conexão externa. Pode ativar provider local; falhas não instalam módulos nem elevam |
| Get-H3Attributes/Assert-H3Chain | File.GetAttributes em raiz, componentes e marcadores diretamente incidentes | Não lê conteúdo. Não trata acesso negado/erro 3 como ausência. Interrompe em reparse e divergência observável; sem pin por handle ou garantia contra corrida entre consultas |
| V04 | Presença de .git arquivo/diretório e combinação de HEAD/config/objects/refs/commondir | Não lê conteúdos/configuração, não chama Git/hooks, não varre recursivamente. Metadados danificados/sinais combinados bloqueiam; ausência dos sinais conhecidos não certifica separação |
| V05 | Registro de pendência documental | Não recebe nomes históricos presumidos, não varre computador e não faz busca alternativa; referências privadas não fornecidas implicam inconclusão |
| V06 | Variáveis de processo OneDrive conhecidas e Win32_Share local | Apenas leitura de strings/metadados, sem consulta a nuvem, SMB remoto ou outros hosts. Share administrativo incidente também bloqueia; ausência de indicadores não prova ausência de exposição |
| V07 | Directory.GetAccessControl, proprietário/grupo/regras/herança/grupos do contexto em memória | Apenas leitura das seções Access/Owner/Group; não consulta SACL, não altera ACL, owner ou token; não escreve resultado privado |
| V08 | Inspeção conservadora do descritor e concessões amplas | DACL nula é impedimento; allow amplo exige revisão privada, sem concluir efetividade ignorando deny/grupos. Mesmo sem sinal amplo, objeto futuro/papéis mantêm inconclusão |
| V09 | Observação da primeira ausência e releitura de fronteira | Não cria/testa escrita ou elimina; partes abaixo da primeira ausência não são individualmente observadas. Estado não elimina colisão futura |
| V10/ConvertTo-Json | Consolidação e serialização somente de constantes/estados/versão | Nenhum caminho, máquina, conta, SID, ACL, erro bruto, disco ou volume é incorporado ao retorno |
| finally | Dispose dos recursos consultados e liberação de referências | Falha de encerramento é sinalizada e impede conclusão completa; liberação não garante apagamento forense da memória |

## Escritas e outros efeitos que não estão no bloco

Não há comando de criar diretório/arquivo, cópia, exclusão, Set-Acl, alteração de
herança/owner, política, serviço, conta, privilégios, registro ou ambiente persistente.
Não há Git, processo auxiliar, script externo, Add-Type/compilação, instalação,
importação do conversor, parsing XML, Start-Transcript, log, arquivo temporário,
redirecionamento para arquivo ou teste de permissão por escrita.

Read-Host/ConvertTo-Json interagem com console; objetos e variáveis existem na
memória do processo. Consultas podem acionar providers e auditoria/logs internos
do Windows/host, fora do controle do texto. Portanto “somente leitura” descreve
as operações solicitadas pelo bloco, não uma promessa de ausência de qualquer
efeito interno do sistema operacional. Não desabilitar auditoria ou captura para
contornar requisitos; contexto inadequado deve impedir a execução futura.

## Paradas e cobertura realista

Caminho/ambiente inválido, consulta falha, ancestral inacessível, reparse, alteração,
Git, share/nuvem incidente, destino existente ou DACL nula interrompem o percurso.
Condições não avaliáveis necessárias à segurança da próxima consulta também param.
Uma pendência documental ou limitação sem novo acesso inseguro é registrada; isso
não libera operação. Em particular, dados físicos locais observados não provam
que um disco seja interno, mas a classificação Fixed local permite apenas consultas
locais subsequentes, sem transformar V02 em aprovação. Nunca se atravessa um
redirecionamento conscientemente detectado.

V05 e V08 não poderão ser confirmadas por esta versão: sem referências privadas
não há confronto das áreas vedadas; sem objeto futuro não há prova de proteção.
V02/V04/V06 também ficam inconclusivas mesmo na rota de consultas concluídas.
V10 conserva essas inconclusões. A rota genérica de “sem impedimento identificado”
define a semântica do formato, mas não é alcançável pela configuração proposta
atual; não se reduz a um teste verde nem aprova o local.

Os timeouts de WMI são limites solicitados às interfaces, não prazo total garantido
contra provider bloqueado. Limite de 256 objetos evita enumeração ilimitada;
nenhuma tentativa de repetição, processo de cancelamento invasivo ou execução
elevada é oferecida. Sem recursos de consulta disponíveis, retorna inconclusão.

## Pontos para auditoria antes de liberar execução

Conferir compatibilidade do texto, namespaces/tipos disponíveis, descarte de recursos,
semântica de atributos/erros, abrangência limitada de marcadores Git, mapeamento
físico e saída em host privado. Nada disso foi testado nesta etapa. Qualquer futura
validação sintática ou execução requer autorização própria. O parecer H3-E
obrigatório foi recebido, autenticado e lido. Suas ressalvas de proteção, papéis,
validade operacional e futura cópia permanecem abertas; não são testes do bloco.
