# WIN19-H3-F — preparação da verificação local do destino

24/11/2026 — America/Sao_Paulo.
H3-F=PROCEDIMENTO_PROPOSTO_AGUARDANDO_REVISAO.
Verificação real do destino=NAO_EXECUTADA; proteção efetiva=NAO_VERIFICADA.

## Entrega e alcance

Preparados exclusivamente os oito documentos técnicos/documentais e o manifesto.
O código PowerShell 5.1 está como texto em COMANDO_WINDOWS_VERIFICACAO_DESTINO.md,
sem .ps1, runner, fixture ou pacote. Não foi executado, submetido a parser, teste
sintático, simulação, demonstração ou ensaio Windows. A revisão feita é leitura
estática do texto e das fontes documentais, sem certificar correção em runtime.

O bloco exige um único caminho privado, informado localmente, sem padrão. Recusa
formas remotas/dispositivos/relativas e componentes ambíguos; distingue ancestral
existente, primeira ausência observada e sufixo não consultado. Não cria o destino.
Consultas propostas: contexto local, metadados de disco, componentes/indicadores
Git, indicadores locais de sincronização/compartilhamento e ACL do ancestral.
Nenhum conteúdo XML, Git, serviço externo ou outro computador é acessado.

V01–V10 têm estados individuais e códigos fixos sanitizados. Confirmações são
limitadas à observação indicada: contexto não prova legitimidade, leitura ACL não
prova acesso efetivo e ausência nominal não prova exclusividade futura. Esta versão
conservadora não pode aprovar o destino: V05 depende de referências privadas não
fornecidas; V08 não certifica um objeto inexistente; V02, V04 e V06 também preservam
as limitações do método. O retorno normal completo será incompleto ou impedido,
com critérios posteriores NAO_EXECUTADO quando houver parada antecipada.

## Decisões preservadas

Custodiante principal: usuário. Identidade, legitimidade e responsabilidades reais
são de registro privado, não autenticadas pelo código. Coadministradores específicos
exigem autorização prévia; operações sensíveis dependem de aprovação específica do
custodiante e não há participação automática na cópia inicial.

Computador Windows do custodiante, disco interno, local novo/exclusivo fora de
Git, R1-FIX, C5–C8, custódias anteriores e sincronização. Caminho exato permanece
privado e não escolhido pela entrega. Assistência remota retirada; não instalar,
configurar ou exigir ferramentas remotas, nem autorizar compartilhamento/transferência.

Retenção ligada à H4, máximo inicial 180 dias após cópia fiel aceita, revisões nos
dias 60/120/180 e revisão antecipada ao concluir H4. Prorrogação expressa e
justificada; nenhuma exclusão automática. Não houve marco/contagem nem agenda.
Validade da futura autorização de cópia continua separada do prazo de retenção.

## Parecer obrigatório consultado e autenticado

PARECER_INDEPENDENTE_WIN19_H3_E_2026-11-24.md foi recebido durante a preparação,
lido integralmente e conferido: 8.598 bytes, SHA-256
cefc1e7e3c254c0883edc462c2fc41b193d4e7f4aebf564085a12b2edc75f326,
idêntico ao exigido. Aceita H3-E documentalmente com ressalvas de escopo e
verificação operacional pendente; recomenda apenas preparar/revisar a inspeção
local de leitura, antes de autorização própria. Não concede execução ou custódia.

Preservadas suas ressalvas: caminho/proteção ainda não demonstrados, formalização
privada de papéis e registros, compatibilidade institucional dos 180 dias,
validade operacional separada e método de cópia futuro. Integridade documental
não prova ausência independente de operações nem proteção no Windows. A H3-E
possui cinco situações consolidadas de política aprovada e onze linhas com
estado_politica aprovado, sem contradição: várias linhas continuam parciais ou
pendentes. Nenhuma dessas contagens representa resultado WIN ou aprovação técnica.
A instrução H3-E específica não foi reautenticada pelo revisor; seu limite foi
registrado no parecer, sem transferir esta ausência à integridade do ZIP.

## Integridade e operações atuais

Bloco PowerShell: 19771 bytes UTF-8 sem BOM, finais LF, hash
8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4.
Extração exata documentada no comando e no índice, sem análise gramatical.
Manifesto cobre os oito documentos, exclui a si e tem hash informado na conversa.
Somente criação da pasta documental externa ao Git e escrita dos documentos/
manifesto foram feitas; ela não é destino de custódia. Fontes H3-E e pacotes
anteriores preservados. Sem ZIP, publicação, commit, push ou merge.
Sem Windows, XML, testes, ACL, conta, privilégio, política, criação de custódia ou
cópia. Parar para revisão independente; nenhuma execução está autorizada.
