# H3-O-D4 — R03/R07 antes de qualquer observação

27/11/2026 — America/Sao_Paulo. Proposta documental de escopo; sem autorização de implementar, validar ou executar.

## Estado de evidência

R03 e R07 conservam severidade ALTA e RISCO_POTENCIAL_ABERTO. Não há exploração
ou mitigação material demonstradas nesta etapa. Nenhuma aceitação de risco foi
dada pelo custodiante. Classificações G02/G07 diagnósticas não autorizam risco
de acesso fora do escopo nem leitura sem proteção indispensável.

R1 B027–064/B136–157/B197–230/B319–325 lê nomes/atributos e revalida. B283–314 lê
ACL ancestral, owner/grupo/regras; B326–331 mantém limites de V08. Sem identidade
física estável ou direitos efetivos comprovados. O núcleo externo não corrige
essas propriedades automaticamente.

## R03 — propriedade que não pode ser dispensada

Leitura e resolução de nomes só podem alcançar objetos/informações legitimamente
em escopo. Incluir no futuro exame o alvo, ancestrais mínimos necessários, aliases,
redirecionamento e metadados de volume/provider/host que o método consultar.
Não tratar autorização de um caminho como autorização de inventariar toda a máquina.

Janela de risco textual: a guarda observa atributo; uma troca pode ocorrer antes
da consulta seguinte; GetAttributes/GetAccessControl podem resolver objeto diverso;
releitura posterior pode observar diferença ou atributo igual/restaurado.
Detectar depois não desfaz a leitura indevida. Hash e repetição de atributos não
provam que a consulta se manteve no mesmo objeto.

Uma alteração específica C pode ser dispensável apenas se desenho auditado e prova
independente suficientemente forte demonstrarem limites seguros das leituras,
escopo legitimamente observável e estabilidade/confinamento necessários durante
a operação. Declaração “computador pessoal/local”, ausência de ataque conhecido
ou falta de reparse numa observação não bastam. Nenhuma dessas provas foi obtida.

Se isso exigir método físico de identidade/ancestrais, handles/pinning ou outras
garantias de resolução, registrar alteração C bloqueadora até projeto/autorização/
implementação/validação próprios. Não selecionar API, flag, direito de abertura,
compartilhamento ou fechamento aqui. O pedido do núcleo não inclui esse método.

## R07 — propriedade que não pode ser dispensada

Proteção pertinente à própria leitura/entrada/captura/registro precisa estar
demonstrada antes de produzir informação privada. Diferenciar owner/grupo,
DACL ancestral, herança possível, direitos efetivos por identidade/objeto/operação,
proteção do objeto futuro e legitimidade institucional. Contar Allow/Deny não
avalia direitos efetivos; sessão não elevada não é comprovação de isolamento.

Uma alteração específica C pode ser dispensável se prova independente aceita
demonstrar a proteção e legitimidade de acesso indispensáveis no escopo real
de observação. Não basta DACL lida em V07, ausência de allow amplo, nome da pasta,
chmod ou boolean do JSON. A prova não está presente.

Se o método de leitura não oferecer proteção necessária sem alteração, projeto
específico C/R07 é bloqueador de P5. Não alterar ACL/privilégio ou realizar teste
entre contas para satisfazer o critério. Não preencher política DACL, papéis
nominais ou SIDs no pedido técnico.

## Critérios propostos de aceitação, falha e incerteza

| Tema | Aceitação futura da propriedade, não observada | Falha conhecida | Evidência inconclusiva e efeito |
|---|---|---|---|
| Alcance da leitura | Autoridade/escopo e todos os objetos/metadados necessários delimitados legitimamente | Acesso/leitura fora da autorização | Escopo/cobertura ausentes impedem início dependente |
| Continuidade física quando indispensável | Método e prova suficientes de confinamento/identidade durante operações pertinentes | Redirecionamento/troca incompatível | Atributos/nomes sem prova suficiente não promovem segurança |
| Separação L-D06 | Referências privadas, cobertura e método aceitos para sete classes antes de ler | Sobreposição conhecida com área vedada | L-D06/ref ausentes mantêm bloqueio; ausência de .git não prova |
| Proteção da própria leitura | Evidência independente pertinente por objeto/operação/identidade e contexto | Exposição/acesso incompatível ou proteção insuficiente conhecida | DACL ancestral/contadores sem efetividade não bastam |
| Recursos/privacidade | Evidência de tratamento seguro e fechamento pertinente, limites explícitos | Falha conhecida de descarte/captura indevida | Término/flag isolados não certificam; incerteza suspende continuidade |
| Objeto futuro | Portão próprio se houver futura custódia | Criação/cópia não autorizadas | Não tentar demonstrar proteção de objeto inexistente por leitura de ancestral |

Impedimento conhecido e ausência de prova são categorias distintas, mas ambas
bloqueiam ação que exige garantia não satisfeita. O risco potencial não é
exploração comprovada; a inexistência de prova de exploração não é segurança.

## Consequência para o escopo proposto

A06/A08 continuam condicionais quanto ao mecanismo, obrigatórias quanto à segurança
da observação. Se necessárias, alterações C devem ser pedidas separadamente.
A07/A09/A11/A12 não podem ser rebaixadas a melhorias opcionais quando o escopo
real delas depender. Nenhuma se resolve implantando apenas D/E/F ou validando
sintaxe N01.

P4 examina suficiência das provas/método antes de considerar P5; não executa C
para obter a própria legitimidade. P4 não aprova destino nem H3-C. Proteção
exclusiva da futura cópia pode esperar P6; proteção indispensável da leitura não.

Sem testes, handles, APIs, consultas, novas políticas ou dados privados nesta
entrega. H3-F-R1 permanece inalterada, não autorizada e requer revisão adicional.
