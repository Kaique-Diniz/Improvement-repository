# H3-O-D4 — fronteira com governança privada

27/11/2026 — America/Sao_Paulo. Proposta documental de escopo; sem autorização de implementar, validar ou executar.

## Frente independente

H3-O-D3-G continua independente. Esta entrega não executa, substitui, presume
conclusão ou preenche os registros dessa frente. G09 permanece indispensável e
não comprovado; L-D06 pendente. L-D01=A e L-D02=11 classificações aprovadas não
são reabertas nem convertidas em evidência material.

A/B somente especificam a interface de referências abstratas a provas futuras.
O núcleo não cria autoridade, comprova institucionalmente operador/host ou decide
cobertura de áreas. Não há referências privadas efetivas preenchidas.

## Dependências preservadas

| ID | Requisito/classe preservado | Estado de origem preservado |
|---|---|---|
| G09-R01 | Legitimidade do computador/ambiente local | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R02 | Competência do operador | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R03 | Identidade/papel do responsável | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R04 | Ausência de assistência remota no escopo | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R05 | Condição sem elevação | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R06 | Versão/modalidade PowerShell | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R07 | Origem/integridade do código | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R08 | Dependências .NET/WMI/resolução | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R09 | Separação de Git/áreas proibidas | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R10 | Privacidade/confidencialidade/registro | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R11 | Escopo efetivamente autorizado | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| G09-R12 | Validade e regras de interrupção | PLANO_DOCUMENTAL_SEM_COMPROVACAO_MATERIAL |
| LD06-C01 | Repositórios Git | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |
| LD06-C02 | Worktrees | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |
| LD06-C03 | Candidata R1-FIX | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |
| LD06-C04 | Áreas C5–C8 | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |
| LD06-C05 | Custódias anteriores | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |
| LD06-C06 | Portão B | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |
| LD06-C07 | Outras áreas historicamente vedadas | PLANO_SEM_CONFRONTO_MATERIAL;L-D06=PENDENTE |


## Interface conceitual e dados proibidos nesta entrega

Uma futura referência abstrata poderia identificar proveniência legítima, papel
funcional, escopo de decisão, validade, cobertura e limite de confiança. Recepção
de referência não é sua autenticação nem autorização de coletar conteúdo. O
método legítimo de confronto precisa projeto/decisão próprios, sem divulgar valor.

Não solicitar nem incluir caminhos privados, SIDs, nomes de contas/pessoas,
identidades de coadministradores, inventários internos, dados de clientes,
conteúdo JUnit, detalhes individuais de ACL ou credenciais. Não descobrir esses
valores por Git, scan, WMI, leitura de diretório ou execução C. Os modelos técnicos
não são meio para coletar dados do host.

Sete classes L-D06 preservadas, nenhuma dispensada: Git; worktrees; R1-FIX; C5–C8;
custódias anteriores; Portão B; outras áreas legitimamente vedadas. Ausência de
marcadores Git não comprova separação. V04 é indicador incompleto; V05 não
confronta referências no texto R1. G05 classificada dependente de decisão não
libera o acesso enquanto a prova suficiente faltar.

## Ausência, incompatibilidade e autoautorização

Referência ausente/ambígua é inconclusiva, não aprovação nem prova de fraude.
Referência contraditória/fora da autoridade impede atribuição e ação dependente.
Nenhuma evidência pode ser obtida por observar C para satisfazer a precondição
que faltava para autorizar essa observação. Segurança necessária deve anteceder
leitura/captura; referência à futura revisão não substitui prova.

Não usar resultado de outra suíte, 470 hashes R1-FIX ou sintaxe R1 para comprovar
legitimidade material, separação, novo código ou fechamento. Nenhum usuário/host
é considerado válido por inferência ou conveniência.

## Custódia e privacidade

H3-E preservada: usuário como custodiante principal; coadministradores apenas com autorização específica. Alterações de acesso, movimentações e exclusões exigem autorização prévia específica. Assistência remota adiada/não autorizada. Retenção vinculada à H4, máximo inicial de 180 dias somente após futura cópia fiel aceita e verificada; revisões 60/120/180 e antecipada se H4 terminar; prorrogação expressa justificada e nenhuma exclusão automática. Nenhum marco/prazo/agenda iniciado. Validade operacional é decisão separada.

F representa resumo mínimo, sem persistência automática ou arquivo privado.
Implantar F não decide destinatário, local/proteção de armazenamento ou retenção
de evidência real. Captura ativa/durabilidade exigem decisão e autorização próprias.
Não desabilitar auditoria/segurança, limpar logs/memória para ocultar falha nem
apagar origem. Resultado adverso permanece fato, ainda que não publicável.

## Pendências privadas, sem pedido de dados

Continuam pendentes, quando pertinentes: legitimidade e competência, papéis/
responsabilidades, referências/cobertura L-D06, compatibilidade institucional,
privacidade/exposição/proteção, regras de falha/registro, validade e futura
autorização limitada. Custodiante/autoridades legítimas devem tratar privadamente
seu conteúdo. A presente entrega não solicita que dados sensíveis sejam enviados
ao Codex. Não há formalização privada legítima presumida ou decisão nova.
