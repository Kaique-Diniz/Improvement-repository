# H3-O-D4 — núcleo mínimo de implementação futura proposto

27/11/2026 — America/Sao_Paulo. Proposta documental de escopo; sem autorização de implementar, validar ou executar.

## Recomendação submetida à auditoria, não escolha aprovada

Recomendar inicialmente artefatos independentes A/B/D/E/F: interfaces mínimas de
origem/contexto, recepção conservadora de conteúdo fornecido, representação de
eventos/encerramento incerto e resumo sanitizado. A independência é requisito
de projeto futuro, não propriedade demonstrada hoje. C é fronteira de integração
apenas documental, excluída da implementação inicial.

O primeiro pedido poderia admitir código desses artefatos, se expressamente
autorizado, com lista concreta de arquivos/base/área/identidade antes de iniciar.
Não incluir lançamento, importação/dot-source, carregamento de função, chamada
final R1, coleta do host ou integração operacional com C. Isso permite auditar o
núcleo sem ampliar por implicação o acesso a dados/ambiente do custodiante.
Não escolhe linguagem, codec, canal, biblioteca, tecnologia de supervisão ou
mecanismo de encerramento; essas escolhas permanecem D3T-Q.

## Artefatos lógicos e responsabilidades

| Artefato lógico proposto | Escopo submetível separadamente | Exclusão que limita a proposta |
|---|---|---|
| LOG-A | Confronto dos bytes/referências explicitamente fornecidos e versão; divergências preservadas | Sem buscar fonte, interpretar Markdown como código ou garantir carregamento real |
| LOG-B | Interface abstrata de autorização/escopo/validade/competência previamente legítimos; falta/contradição impeditivas | Sem cadastrar identidades privadas, consultar Git/host ou criar autoridade |
| LOG-D | Recepção de conteúdo fornecido; compatibilidade/completude/vínculo; sete estados e limites | Sem captura automática, parser ou schema criado nesta fase documental; futuro desenvolvimento exige autorização |
| LOG-E | Modelo de eventos, fases desconhecidas, duração e recursos incertos com origem dos eventos explícita | Sem iniciar processo, impor timeout, encerrar provider, watchdog, supervisor ou kill |
| LOG-F | Representação mínima de estados/motivos/proveniência e adversos sem dados privados | Sem gravar/capturar automaticamente, criar custódia, transcrever sessão ou apagar origem |

Os identificadores LOG não são nomes de módulos executáveis ou caminhos aprovados.
Nomes físicos, base de implementação, tecnologia e área permitida permanecem em
aberto no instrumento. Qualquer implementação futura terá identidade e manifesto
próprios. Não se herda N01 ou integridade/resultado das candidatas históricas.

## Interfaces conceituais

I01: A entrega a B/D identidade e limites da fonte; I02: B entrega vínculos/limites
legítimos a D/E/F; I03: B recebe referências da governança privada independente;
I04: C poderia fornecer conteúdo/eventos a D/E somente em integração futura
autorizada; I05: D usa origem/vínculo/eventos de A/B/E; I06: D entrega estado/motivo
mínimo a F; I07: E confronta eventos e contexto, sem comandar C; I08: E entrega
incertezas/falhas a F; I09: F representa esses dados ao destinatário legitimamente
definido. São relações documentais, não protocolos/canais executáveis existentes.

Metadado recebido como declaração deve permanecer declaração. Fonte, autorização,
início, término, falha e fechamento só recebem qualificativo “observado/comprovado”
quando evidência suficiente o sustentar. Um ID de correlação não é assinatura.
Modelo E passivo não cumpre por si a necessidade de duração/encerramento reais.
Logo, implementar o núcleo não demonstra G10 completo em contexto operacional.

## Seis tratamentos prévios e alterações C

A01–A05/A10 são seis propostas de tratamento antes de observação, não seis ordens
de editar as 383 linhas R1. Sua matriz D4 responde individualmente propriedade,
oferta atual, solução externa, necessidade C, superfície/privilégio, decisões,
aceitação/evidência, risco residual e autorização de implementar.

Receber ausência/incompatibilidade, reconhecer fase desconhecida, separar recursos
e impedir aprovação podem ser responsabilidades externas. Se a solução externa
não cobrir identidade, segurança de leitura, tempo ou encerramento necessários,
deve-se propor subescopo específico C/ativo e manter a execução bloqueada.
Não afirmar suficiência do núcleo passivo apenas por ele existir.

## Condicionais preservadas e prioridade R03/R07

A06/A08: projeto de identidade/confinamento e proteção pertinente exige análise
prioritária. Se indispensável e não suprido por prova independente suficiente,
mudar C torna-se requisito bloqueador da futura execução. Sem handles/APIs/flags
ou política DACL escolhidos.

A07/A09: interface abstrata B/A pode estar no núcleo, porém confronto material
L-D06 e resolução real do host não são implementados por escrever interface.
A11/A12: WMI/exposição continuam fora do núcleo; se o método futuro mantiver tais
consultas, suas dependências e escopo exigem decisão/evidência próprios.
Nenhuma condicional é melhoria opcional por falta de prova em contrário.

## Exclusões justificadas

A13: telemetria adicional não indispensável aumenta superfície/privacidade e é
diferida; eventos mínimos indispensáveis continuam exigidos.
A15: precisão extra da heurística não é necessária ao núcleo; manter recusa
conservadora não certifica separação nem dispensa L-D06.
A14: reserva/criação exclusiva, cópia fiel, proteção futura, parciais e custódia
pertencem somente a portões posteriores. Proteção indispensável da própria
leitura não pode ser adiada sob essa categoria.

Excluídos: criar/reservar destino, ler/copiar/mover/sanitizar/excluir JUnit/XML;
H3-C/H3-S/H4; contas/ACLs/DACLs/privilégios; testes entre contas; coleta ou inventário
privado; políticas financeiras/cadastrais; conversões reais; runner; captura ativa,
supervisor/watchdog/término forçado e alterações persistentes de host.
Se uma característica adicional for indispensável à segurança, novo pedido
específico, sem inclusão automática no núcleo.

## Contrato mínimo G10 — catorze dimensões

| Dimensão do escopo | Critério documental proposto |
|---|---|
| Identidade de rodada | Vínculo legítimo com fonte/autorização/instância; nenhum ID efetivo criado ou inferido |
| Origem dos dados | Fonte e canal identificáveis com limite de confiança, sem tomar rótulo próprio como prova |
| Completude | Conteúdo completo distinto de ausência/fragmento; nenhum objeto normal fabricado |
| Estrutura admissível | Contrato de versão decidido; R1 é referência dos 12 campos/10 V/7 limitações, não formato novo implementado |
| Dados adicionais | Não recortar, selecionar último objeto, descartar prefixo/erro ou apagar adverso para compatibilizar |
| Campos incompatíveis | Tipos/valores/duplicatas/extras/versão divergentes não sofrem coerção silenciosa |
| Recepção versus verdade | Recebimento validável não comprova fatos, segurança ou legitimidade institucional |
| Processo versus recursos | Término observado não prova provider, COM/RPC, host ou todos os recursos fechados |
| Interrupção | Pedido, efeito e término distintos; sem ação operacional escolhida ou retry |
| Registro sanitizado | Fatos/motivos mínimos, sem valores privados; conteúdo adverso protegido legitimamente |
| Impedimentos | Contradição conhecida impede atribuição ou ação pertinente; registro pode ser validável como prova de impedimento |
| Inconclusões | Ausência/ambiguidade/limite de prova impedem promoção e ação dependente |
| Versão do contrato | Versão executável futura não definida nem adotada; revisão dos bytes exige nova identidade e auditoria |
| Aceitação/limites | Critérios P1–P6 separados; nenhuma saída aprova destino ou autoriza custódia |

Estados externos preservados: EVIDENCIA_RECEBIDA_VALIDAVEL, EVIDENCIA_INCOMPLETA,
EVIDENCIA_AUSENTE, EVIDENCIA_INCOMPATIVEL, EXECUCAO_INTERROMPIDA,
ENCERRAMENTO_NAO_COMPROVADO e RESULTADO_INCONCLUSIVO.
Recepção, execução, encerramento e interpretação são eixos que podem coexistir.
Um objeto compatível pode registrar impedimento ou fechamento falho e continuar
sem conclusão favorável. Exit zero não demonstra segurança.

As regras completas/tipos/condições históricas D3-T foram preservadas literalmente
na matriz M-C, com escopo D4 aditivo; nada foi adotado ou validado. Não criar
schema/parser/consumidor/captura agora, nem corrigir o resultado para torná-lo válido.

## Prontidão e portões

A implementação, se autorizada, precisa P1 de novos bytes e P2 próprio; N02–N04 e
segurança prévia em P3/P4 quando pertinentes. P5 inspeção e P6 destino/custódia
continuam decisões operacionais independentes. Os portões não são uma sequência
automática de execução. Sem solução suficiente para as condições reais, núcleo
implementado ainda deixa H3-F-R1 não autorizada e prontidão false.
