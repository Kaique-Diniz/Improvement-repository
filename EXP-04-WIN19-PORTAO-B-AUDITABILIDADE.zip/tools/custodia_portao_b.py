"""CAPTURADOR EXTERNO PROPOSTO, NÃO EXECUTADO/VALIDADO EM WINDOWS.

Não é a sonda: após autorização futura, cria somente uma área nova de evidência.
Nunca importa o produto/preflight; executa a sonda em processo isolado separado.
Sem ACL, chmod, symlinks, remoção ou alteração de configuração persistente.
"""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys


class Bloqueio(Exception):
    pass


def hash_bytes(raw):
    return sha256(raw).hexdigest()


def regular(path, directory=False):
    if not path.is_absolute() or '..' in path.parts:
        raise Bloqueio('CAMINHO_INVALIDO')
    for p in (*reversed(path.parents),path):
        s=p.lstat()
        if stat.S_ISLNK(s.st_mode) or getattr(s,'st_file_attributes',0)&0x400:
            raise Bloqueio('LINK_REPARSE_RECUSADO')
        if p!=path and not stat.S_ISDIR(s.st_mode):
            raise Bloqueio('ANCESTRAL_INVALIDO')
    if not (stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode)):
        raise Bloqueio('TIPO_INVALIDO')
    return path


def fora_git(path):
    for p in (path,*path.parents):
        if os.path.lexists(p/'.git') or (os.path.lexists(p/'objects') and
                any(os.path.lexists(p/n) for n in ('HEAD','refs','config'))):
            raise Bloqueio('EVIDENCIA_OU_PREPARACAO_EM_GIT')


def instante():
    return dict(utc=datetime.now(timezone.utc).isoformat(),
                local_com_fuso=datetime.now().astimezone().isoformat())


class Custodia:
    def __init__(self,root):
        # A raiz é inexistente, aprovada pelo chamador e nunca reutilizada.
        root.mkdir()  # Herança padrão; não configurar uma DACL nem prometer proteção.
        self.root=root
        s=root.lstat();self.identity=(s.st_dev,s.st_ino)
        self.files={}

    def conferir(self):
        regular(self.root,True)
        s=self.root.lstat()
        if not self.identity[1]:raise Bloqueio('IDENTIDADE_AREA_NAO_DISPONIVEL')
        if (s.st_dev,s.st_ino)!=self.identity:
            raise Bloqueio('AREA_EVIDENCIA_SUBSTITUIDA_PRESERVAR')

    def abrir(self,name):
        self.conferir()
        if not re.fullmatch(r'[a-z0-9_.-]+',name):raise Bloqueio('NOME_INVALIDO')
        return (self.root/name).open('xb',buffering=0)

    def bytes(self,name,raw):
        with self.abrir(name) as stream:
            remaining=memoryview(raw)
            while remaining:
                n=stream.write(remaining)
                if not n:raise Bloqueio('ESCRITA_INCOMPLETA_PRESERVAR')
                remaining=remaining[n:]
            os.fsync(stream.fileno())
        if (self.root/name).read_bytes()!=raw:raise Bloqueio('GRAVACAO_NAO_CORRESPONDE')
        self.registrar(name)

    def json(self,name,value):
        raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf-8')
        self.bytes(name,raw)

    def registrar(self,name):
        self.conferir()
        raw=regular(self.root/name).read_bytes()
        self.files[name]=dict(bytes=len(raw),sha256=hash_bytes(raw))


SCHEMA_SANITIZADO_VERSION='WIN19_B_SANITIZADO_V2'
FIELD_TYPES={
    'etapa':'enum','testes_executados':'int','area_criada':'bool','ACL_alterada':'bool',
    'prontidao_para_executar':'bool','DACL_efetiva':'enum','politica_DACL':'enum',
    'autorizacao_testes':'enum','conta_identificada_no_relatorio':'bool',
    'significado_saida_0':'enum','portao_C':'enum','portao_D':'enum','portao_E':'enum',
    'versao_preparacao':'enum','baseline_esperado':'hash40',
    'hashes_antes_conferidos':'int','hashes_depois_conferidos':'int',
    'integridade_antes':'bool','integridade_depois':'bool',
    'preflight_python_sha256':'hash64','preparacao_externa_ao_git':'bool',
    'utf8_ativo':'bool','bytecode_desabilitado':'bool','python_isolado':'bool','site_desabilitado':'bool',
    'git_ambiente_politica':'enum','git_variaveis_herdadas':'int','git_traces_herdados':'bool',
    'git_autenticacao_necessaria':'bool','git_config_global_sistema':'enum',
    'git_config_local_revisada':'bool','git_config_arquivos_conferidos':'int',
    'git_hooks_desabilitados':'bool','git_executavel_sha256':'hash64',
    'git_head':'hash40','head_confere':'bool','git_raiz_confere':'bool',
    'status_git_sha256':'hash64','status_git_registros':'int',
    'hashes_conferidos':'int','manifesto_sha256':'hash64','python':'python312','sistema':'enum',
    'windows_build':'build','area_prevista_nova':'bool','area_direta_localappdata':'bool',
    'area_fora_git':'bool','sem_sobreposicao_candidata':'bool','token_elevado':'bool',
    'symlink_privilegio_presente':'bool','symlink_privilegio_habilitado':'bool','symlink_criacao_testada':'bool',
    'sistema_arquivos':'filesystem','persistent_acls_suportadas':'bool','reparse_suportado':'bool',
    'hardlinks_suportados':'bool','volume_candidata':'volume','alias_existente_observado':'bool',
    'codigo_sonda_alias':'int_or_null','alias_sintetico_ainda_nao_testado':'bool',
    'developer_mode_somente_leitura':'bool','hashes_antes_depois_da_coleta':'int',
    'estado':'enum','codigo':'code','codigo_antes_integridade_final':'code',
    'impedimentos':'codes','coleta_concluida':'bool'}
ENUM_VALUES={
    'etapa':['PREFLIGHT_SOMENTE_LEITURA'],'DACL_efetiva':['NÃO_VALIDADO'],
    'politica_DACL':['PARA_APROVACAO'],'autorizacao_testes':['PENDENTE'],
    'significado_saida_0':['SOMENTE_COLETA_CONCLUIDA_MESMO_COM_IMPEDIMENTOS'],
    'portao_C':['BLOQUEADO'],'portao_D':['BLOQUEADO'],'portao_E':['BLOQUEADO'],
    'versao_preparacao':['WIN19-PORTAO-B-AJUSTES'],
    'git_ambiente_politica':['LISTA_POSITIVA_WIN19_B_V1'],'git_config_global_sistema':['NUL'],
    'sistema':['win32'],'estado':['BLOQUEADO','OBSERVACOES_COLETADAS_SEM_AUTORIZACAO_DE_TESTES']}
FILESYSTEM_VALUES=['NTFS','ReFS','FAT','FAT32','exFAT','EXFAT','UDF','CDFS']
CORE_REQUIRED=('etapa','testes_executados','area_criada','ACL_alterada','prontidao_para_executar',
    'DACL_efetiva','politica_DACL','autorizacao_testes','conta_identificada_no_relatorio',
    'significado_saida_0','portao_C','portao_D','portao_E','versao_preparacao','baseline_esperado',
    'hashes_antes_conferidos','hashes_depois_conferidos','integridade_antes','integridade_depois',
    'estado','impedimentos','coleta_concluida')
OPTIONAL_FIELDS=('codigo','codigo_antes_integridade_final')
VOLUME_FIELDS={'sistema_arquivos':'filesystem','persistent_acls_suportadas':'bool',
               'reparse_suportado':'bool','hardlinks_suportados':'bool'}
BUILD_FIELDS={'major':'int','minor':'int','build':'int'}


def sanitizar(report):
    """Esquema V2: não encaminha nomes/valores de chaves extras.

    Só campos conhecidos tipados. Completa exige todos os campos de sucesso;
    parcial é BLOQUEADA e enumera ausências conhecidas sem inventar valores.
    REPROVADO também gera derivado seguro para auditar o motivo, nunca PASS.
    """
    out={};invalid=[];unknown=0
    if type(report) is not dict:
        report={};invalid.append('objeto_raiz')
    unknown+=len(set(report)-set(FIELD_TYPES))
    complete_required=set(FIELD_TYPES)-set(OPTIONAL_FIELDS)

    def scalar(value,kind,key):
        if kind=='bool':return type(value) is bool
        if kind=='int':return type(value) is int and 0<=value<=2147483647
        if kind=='int_or_null':return value is None or (type(value) is int and 0<=value<=2147483647)
        if kind in ('hash40','hash64'):
            return type(value) is str and re.fullmatch('[0-9a-f]{'+('40' if kind=='hash40' else '64')+'}',value) is not None
        if kind=='python312':return type(value) is str and re.fullmatch(r'3\.12\.[0-9]{1,5}',value) is not None
        if kind=='filesystem':return type(value) is str and value in FILESYSTEM_VALUES
        if kind=='enum':return type(value) is str and value in ENUM_VALUES[key]
        if kind=='code':return type(value) is str and re.fullmatch(r'[A-Z0-9_-]{1,160}',value) is not None
        if kind=='codes':
            return type(value) is list and len(value)<=64 and all(type(x) is str and
                re.fullmatch(r'[A-Z0-9_; -]{1,180}',x) is not None for x in value)
        return False

    for key,kind in FIELD_TYPES.items():
        if key not in report:continue
        value=report[key]
        if kind in ('volume','build'):
            fields=VOLUME_FIELDS if kind=='volume' else BUILD_FIELDS
            if type(value) is not dict:
                invalid.append(key);continue
            unknown+=len(set(value)-set(fields));nested={}
            for child,child_kind in fields.items():
                if child not in value or not scalar(value[child],child_kind,child):
                    invalid.append(key+'.'+child)
                else:nested[child]=value[child]
            if kind=='build':
                for child in ('major','build'):
                    if child in nested and nested[child]<1:invalid.append(key+'.'+child)
            out[key]=nested
        elif scalar(value,kind,key):out[key]=value
        else:invalid.append(key)

    # Campos de privacidade/gates são invariantes também em evidência parcial.
    for key in ('area_criada','ACL_alterada','prontidao_para_executar','conta_identificada_no_relatorio'):
        if key in out and out[key] is not False:invalid.append(key)
    if 'testes_executados' in out and out['testes_executados']!=0:invalid.append('testes_executados')
    missing=sorted(complete_required-set(out))
    core_missing=sorted(set(CORE_REQUIRED)-set(out))
    claims_complete=(out.get('coleta_concluida') is True and
        out.get('estado')=='OBSERVACOES_COLETADAS_SEM_AUTORIZACAO_DE_TESTES')
    partial=(out.get('coleta_concluida') is False and out.get('estado')=='BLOQUEADO')
    if claims_complete:
        for key in ('hashes_antes_conferidos','hashes_depois_conferidos','hashes_conferidos','hashes_antes_depois_da_coleta'):
            if out.get(key)!=470:invalid.append(key)
        for key in ('integridade_antes','integridade_depois','preparacao_externa_ao_git',
            'utf8_ativo','bytecode_desabilitado','python_isolado','site_desabilitado','head_confere',
            'git_raiz_confere','git_config_local_revisada','git_hooks_desabilitados','area_prevista_nova',
            'area_direta_localappdata','area_fora_git','sem_sobreposicao_candidata','persistent_acls_suportadas'):
            if out.get(key) is not True:invalid.append(key)
        for key in ('token_elevado','git_traces_herdados','git_autenticacao_necessaria','symlink_criacao_testada'):
            if out.get(key) is not False:invalid.append(key)
        if out.get('git_variaveis_herdadas')!=0:invalid.append('git_variaveis_herdadas')
        if out.get('sistema_arquivos')!='NTFS':invalid.append('sistema_arquivos')
        if out.get('codigo_sonda_alias') is not None:invalid.append('codigo_sonda_alias')
        if not 1<=out.get('git_config_arquivos_conferidos',0)<=3:invalid.append('git_config_arquivos_conferidos')
    elif not partial:invalid.append('estado/coleta_concluida')
    if partial and 'codigo' not in out:invalid.append('codigo')
    state=('REPROVADO' if unknown or invalid or core_missing or (claims_complete and missing)
           else 'COMPLETO_ESTRUTURALMENTE' if claims_complete else 'PARCIAL_BLOQUEADO')
    return dict(schema_version=SCHEMA_SANITIZADO_VERSION,
        validacao_esquema=dict(estado=state,campos_obrigatorios_completa_ausentes=missing,
            campos_basicos_ausentes=core_missing,campos_invalidos=sorted(set(invalid)),
            chaves_inesperadas_quantidade=unknown,nomes_ou_valores_inesperados_transferidos=False,
            aceite_B01_B22='EXIGE_REVISAO_HUMANA_NAO_HOMOLOGACAO'),resultado_sonda=out)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('preparacao','candidata','area-prevista','evidencias','git'):
        parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--custodiante',required=True)
    parser.add_argument('--autorizacao-id',required=True)
    parser.add_argument('--autorizar-captura-e-uma-execucao',action='store_true')
    a=parser.parse_args()
    custody=None;creation_attempted=False;status='NAO_CONCLUIDO';code=None;rc=None;report=None
    try:
        if not a.autorizar_captura_e_uma_execucao:raise Bloqueio('AUTORIZACAO_FUTURA_OBRIGATORIA')
        if os.name!='nt' or sys.version_info[:2]!=(3,12):raise Bloqueio('WINDOWS_PYTHON312_OBRIGATORIOS')
        if not (sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.utf8_mode):
            raise Bloqueio('RUNTIME_ISOLADO_OBRIGATORIO')
        if any(k.upper().startswith('GIT_') for k in os.environ):raise Bloqueio('GIT_VARIAVEL_HERDADA_NAO_AUTORIZADA')
        for label in (a.custodiante,a.autorizacao_id):
            if not re.fullmatch(r'[A-Z][A-Z0-9_-]{2,79}',label) or label in {'A_DESIGNAR','PENDENTE','MODELO'}:
                raise Bloqueio('RESPONSAVEL_OU_AUTORIZACAO_INVALIDOS')
        prep=regular(a.preparacao,True);fora_git(prep)
        regular(a.candidata,True);regular(a.git)
        local=regular(Path(os.environ.get('LOCALAPPDATA','')),True);fora_git(local)
        root=a.evidencias
        if not root.is_absolute() or '..' in root.parts or root.parent!=local or not root.name.startswith('WIN19-CUSTODIA-'):
            raise Bloqueio('AREA_CUSTODIA_INVALIDA')
        if os.path.lexists(root):raise Bloqueio('AREA_CUSTODIA_EXISTENTE_PRESERVAR')
        if root==a.area_prevista or root==prep or root==a.candidata or any(root.is_relative_to(p) or p.is_relative_to(root) for p in (prep,a.candidata)):
            raise Bloqueio('AREAS_SOBREPOSTAS')
        pins=json.loads(regular(prep/'HASHES_PREFLIGHT_PORTAO_B.json').read_bytes())['arquivos']
        for name,expected in pins.items():
            p=regular(prep/name)
            if hash_bytes(p.read_bytes())!=expected:raise Bloqueio('PREPARACAO_DIVERGENTE')
        creation_attempted=True
        custody=Custodia(root)
        inicio_captura=instante()
        custody.json('inicio_privado.json',dict(natureza='CUSTODIA_PRIVADA_NAO_HOMOLOGACAO',
            inicio=inicio_captura,custodiante=a.custodiante,autorizacao_id=a.autorizacao_id,
            candidata=str(a.candidata),area_prevista=str(a.area_prevista),
            python=sys.version,python_executavel_sha256=hash_bytes(Path(sys.executable).read_bytes()),
            scripts_sha256=pins,manifesto_entrega_sha256=hash_bytes((prep/'MANIFESTO_PORTAO_B_SHA256.json').read_bytes()),
            politica_DACL='PARA_APROVACAO',DACL_efetiva='NÃO_VALIDADO'))
        command=[sys.executable,'-I','-S','-B','-X','utf8',str(prep/'tools/preflight_win19.py'),
            '--candidata',str(a.candidata),'--manifesto',str(prep/'REFERENCIA_R1_FIX_470_SHA256.json'),
            '--area-prevista',str(a.area_prevista),'--git',str(a.git)]
        # Handles de arquivos exclusivos, sem pipeline textual PowerShell.
        # Popen só recebe o ambiente Python atual; a SONDA cria outro ambiente,
        # positivo e sem herança para as suas três consultas Git locais.
        with custody.abrir('stdout_bruto.bin') as stdout, custody.abrir('stderr_bruto.bin') as stderr:
            status='LANCAMENTO_TENTADO_NAO_CONCLUIDO'
            try:
                result=subprocess.run(command,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,
                                      cwd=prep,timeout=180,check=False)
                rc=result.returncode
            except subprocess.TimeoutExpired:
                code='TIMEOUT_SONDA_INTEGRIDADE_FINAL_NAO_COMPROVADA'
                # subprocess.run encerra/aguarda seu filho direto. Não afirmar
                # que todos os descendentes Git também foram encerrados.
            finally:
                os.fsync(stdout.fileno());os.fsync(stderr.fileno())
        custody.registrar('stdout_bruto.bin');custody.registrar('stderr_bruto.bin')
        if code is None:
            raw=(root/'stdout_bruto.bin').read_bytes()
            if len(raw)>1024*1024:raise Bloqueio('SAIDA_EXCESSIVA_PRESERVAR')
            report=json.loads(raw.decode('utf-8'))
            if not isinstance(report,dict):raise Bloqueio('JSON_INVALIDO_PRESERVAR')
            custody.json('json_normalizado_privado.json',report)
            sanitized=sanitizar(report)
            custody.json('relatorio_sanitizado.json',dict(natureza='EVIDENCIA_B_NAO_HOMOLOGACAO',
                **sanitized,custodiante=a.custodiante,autorizacao_id=a.autorizacao_id,
                custodia_publica=dict(inicio=inicio_captura,fim_derivacao=instante(),
                    fontes={name:dict(custody.files[name]) for name in
                        ('stdout_bruto.bin','stderr_bruto.bin','json_normalizado_privado.json')})))
            if sanitized['validacao_esquema']['estado']!='COMPLETO_ESTRUTURALMENTE':
                code='ESQUEMA_PARCIAL_OU_REPROVADO_PRESERVAR'
            if code is None and rc==0 and report.get('coleta_concluida') is True:
                status='COLETA_ENCERRADA_REQUER_REVISAO'
            elif code is None:
                code='SONDA_BLOQUEADA_OU_RETORNO_DIVERGENTE'
            if custody.files['stderr_bruto.bin']['bytes']:
                code='STDERR_PRESENTE_REQUER_REVISAO_PRIVADA'
        if code is None and (rc!=0 or report.get('prontidao_para_executar') is not False or
                any(report.get('portao_'+g)!='BLOQUEADO' for g in 'CDE')):
            status='BLOQUEADO';code='ESTADOS_DE_SEGURANCA_DIVERGENTES'
    except Bloqueio as error:
        code=str(error)
    except KeyboardInterrupt:
        code='INTERRUPCAO_PRESERVAR_EVIDENCIAS'
    except Exception:
        code='CAPTURA_ERRO_OPERACIONAL_PRESERVAR'
    finally:
        if custody is not None:
            try:
                # Registrar também brutos parciais que já existirem em falha.
                for name in ('stdout_bruto.bin','stderr_bruto.bin'):
                    if os.path.lexists(custody.root/name):custody.registrar(name)
                custody.json('fim_privado.json',dict(fim=instante(),estado=status if code is None else 'BLOQUEADO',codigo=code,retorno_sonda=rc,
                    descendentes_git_encerrados='NAO_COMPROVADO_SE_TIMEOUT_OU_INTERRUPCAO',
                    C='BLOQUEADO',D='BLOQUEADO',E='BLOQUEADO',DACL='NÃO_VALIDADO'))
                custody.json('cadeia_sha256.json',dict(arquivos=dict(custody.files),
                    excluido='cadeia_sha256.json',raw='BYTES_ORIGINAIS_STDOUT_STDERR',
                    normalizacao='UTF8 estrito; JSON parse/dump sort_keys indent2 ensure_ascii; LF final, sem BOM',
                    sanitizacao='LISTA_POSITIVA_DE_CAMPOS_TIPADOS; sem stderr/caminhos/comando',
                    custodiante=a.custodiante,autorizacao_id=a.autorizacao_id))
            except Exception:
                code='CUSTODIA_FINAL_INCOMPLETA_PRESERVAR'
    print(json.dumps(dict(estado=status if code is None else 'BLOQUEADO',codigo=code,
        retorno_sonda=rc,custodia_inicializada=custody is not None,
        criacao_area_custodia_tentada=creation_attempted,prontidao_para_executar=False,
        C='BLOQUEADO',D='BLOQUEADO',E='BLOQUEADO',DACL='NÃO_VALIDADO'),ensure_ascii=True))
    return 0 if code is None else 2


if __name__=='__main__':raise SystemExit(main())
