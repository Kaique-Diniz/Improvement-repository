> Adendo desta revisão: existe apenas capturador proposto de B, não runner C. Sem execução. As ressalvas C/D abaixo continuam pendentes; proposta WIN14 não aplicada.

# Ressalvas C/D — revisão estática e decisões pendentes

Nenhum teste, coleta, import do produto, sonda ou helper foi executado. Nenhum
arquivo da candidata/R2 anterior ou decisão DACL foi alterado. Não há runner C
nesta entrega e os 21 casos seguem previsão estrutural, não coleta observada.

| Item do parecer | Local inspecionado na R2 | Conclusão e obrigação antes de C |
|---|---|---|
| R1 Runner inexistente | PLANO_NATIVO_WIN19_R2.md; conftest.py:36/63/118 | Gate de pytest, evento INICIO e hashes não são runner. Implementação futura deverá persistir relatório parcial fora de basetemp e preservar JUnit/log/diagnóstico antes de assert, timeout, crash e limpeza; não executar diretamente pytest agora. |
| R2 Helpers | suporte_nativo.py:26–147 | ABI proposto usa DWORD/FILETIME, HANDLE e BOOLEAN1byte em FileDispositionInfo4; flags OPEN_EXISTING, OPEN_REPARSE_POINT, BACKUP_SEMANTICS. Ancestrais GENERIC_READ/share0x3 podem impor precondição de acesso/leitura e bloquear operações legítimas. Não mudar flags nem declarar segurança com AST. Revisar identidade por volume/file ID64 e possível reutilização, atributos mutáveis, semântica de symlink diretório, falhas de fechamento e a espera limitada de seis observações. Exige ensaio dirigido autorizado, sem tocar no motor. |
| R3 WIN06–10/12 | test_win19_independentes.py:172–211 e249–290 | Raiz interna correta e revisão zero; apenas lock próprio regular vazio previsto. Qualquer evidencias/cabecas inesperado aborta/preserva. Remoção por identidade depende do helper não validado. Necessita capacidade real de symlink;1314 é NÃO_VALIDADO. |
| R4 WIN14 | factories_r2.py:14–54; teste:318–361 | Contratos/autoridade/inventário/recibo precisam de runtime futuro. Snapshot atual não cobre toda autoridade. PROPOSTA_WIN14_AUTORIDADE_NAO_APLICADA.patch acrescenta comparação integral em memória da raiz da autoridade antes/depois e boolean sanitizado; não foi aplicada nem executada. |
| R5 WIN16 | factories_r2.py:62–114; teste:380–436 | PDF/gabarito declarativo dependem de ordem de fragmentos, coordenadas, origem, IDs e ressalvas do contrato. Futura divergência exige análise independente, nunca copiar saída do leitor. CLI+DTO não comprovam exportação operacional. |
| R6 Evidência | conftest.py:118–147; suporte_nativo._falhar; WIN16 subprocess.run | Evento INICIO/fsync e diagnósticos pontuais não conservam todas as evidências em falhas. TimeoutExpired pode impedir gravação de stdout/stderr. Distinguir API do helper de API do produto; API não observável fica NÃO_VALIDADO. Observador global exige execução sequencial, sem xdist. |
| R7 DACL | WIN18/19 e ESPECIFICACAO_DACL_PROPOSTA_R2.md | São apenas skips/protocolos. Dez decisões D01–D10 permanecem PARA_APROVAÇÃO; tokens distintos não provisionados, escritor/leitor sem prova da política efetiva. Não aplicar ACL manual e atribuir ao produto. |
| R8 Contagens | Matriz/fichas R2 |19 vínculos provisórios;21 casos previstos; zero coleta e zero novas execuções. Nenhum PASS de cleanup transfere aprovação de segurança. |

## Requisitos mínimos do futuro runner, sem implementação/autorização nesta B

- Python3.12 -B UTF-8, sem cache pytest nem PYTHONPATH/sitecustomize indevido;
  isolar imports antes de carregar produto e conferir origem após caso/sessão.
- Pinagem dos hashes da candidata470 e dos scripts/helpers/factories usados,
  mais versões/dependências e comando completo em custódia privada. Hash inicial
  ou HEAD sozinho não substitui conferência final nem extras.
- Basetemp inexistente, curto, reservado exclusivamente fora de Git/candidatas/
  documentos; pytest pode apagar basetemp preexistente. Não confiar só em prefixo.
  Identidade, ancestrais e posse precisam de conferência; nunca usar o residual.
- Evidências ficam em outra área exclusiva. JUnit/log/JSON parcial devem existir
  ou ter ausência explicitamente registrada antes de limpeza. Persistir observação
  primária de operação/API/código antes de assert; não reconstruir causa pelo nome.
- Preservar sentinelas por bytes integrais e árvore, não somente exists ou hashes.
  Autoridade/credencial de WIN14 só em memória/custódia privada; nunca imprimir,
  usar --showlocals ou empacotar a raiz da autoridade. Compartilhar boolean de
  preservação, não chave, credencial, SID, caminho pessoal ou payload bruto.
- Nunca seguir link para excluir destino. Divergência de identidade/bytes, falha
  CloseHandle, exclusão pendente ou timeout interrompe e preserva laboratório e
  relatório. Não remover registros de terceiros ou reciclar laboratórios anteriores.
- Separar stdout/stderr bruto sob custódia privada de cópia sanitizada com tamanho,
  SHA e cadeia de transformação. Captura textual normalizada é derivada, não raw.
  Não perder evidências em finally/cleanup nem declarar sucesso por falta de arquivo.

## WIN03 e histórico

Ramo de erro real de CompareStringOrdinal continua NÃO_VALIDADO_SEM_INSTRUMENTACAO.
NUL recusado antes da API, mock e ponteiro inválido não são evidência aceitável.
Sem alias8.3 verdadeiro, WIN02 não é validado; privilégio/token/Developer Mode
consultados não comprovam criação de link.1314 fica skip somente no cenário
inviável, com motivo literal, sem aumentar cobertura ou produzir PASS.

CHECKLIST_CUSTODIA_JUNIT_R2.json permanece literal: obter XML/log/relatório EXP04
original2842/19falhas/7skips, versão/manif448 e motivos individuais; extrator é
índice de apoio. Os registros cleanup e BPQ04 de38falhas não substituem a fonte.
19 vínculos permanecem PROVISORIO_SEM_FONTE e os eixos NÃO_VALIDADO.
