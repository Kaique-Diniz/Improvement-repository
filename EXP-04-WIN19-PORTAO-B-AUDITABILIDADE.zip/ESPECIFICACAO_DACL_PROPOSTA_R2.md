# Política DACL proposta — PARA_APROVAÇÃO, NÃO IMPLEMENTADA

Versão de proposta: WIN19-DACL-P1-R2, 18/11/2026. Nenhuma regra desta proposta
constitui requisito aprovado. Não executar acesso entre contas, aplicar ACEs ou
ajustar herança antes da revisão da política E do laboratório. Nenhum comando
Set-Acl, icacls de alteração, AdjustTokenPrivileges ou criação de conta é fornecido.

## 1. Fronteira e papéis a aprovar

Escopo exclusivo: área nova e sintética do laboratório, fora de Git/documentos,
criada pelo fluxo real sob avaliação. Não usar nem limpar resíduos antigos.
Não provar isolamento de produção com ACL instalada manualmente pelo ensaio.

- **O — operador do fluxo**: conta comum que cria/usa o contexto; sem elevação.
  Aplicativo e operador sob o mesmo token NÃO são dois papéis de segurança do SO.
- **U — outro usuário comum não autorizado**: segundo token/conta legitimamente
  provisionado para o laboratório, distinto de O, sem privilégio de backup,
  restauração, tomada de posse ou associação autorizada por grupo. Não criar
  essa conta nem obter credenciais automaticamente nesta etapa.
- **A — revisor**: acesso apenas à exportação SANITIZADA de evidências, se esse
  papel for aprovado. Não conceder leitura de fonte, chave ou JSON privado por padrão.
- **Manutenção do SO/administradores**: exceções a especificar pelo responsável.
  Não presumir isolamento de proprietário, administradores ou SYSTEM. O dono
  pode ter direitos implícitos de READ_CONTROL/WRITE_DAC; a proposta não promete
  impedir que o próprio dono/administrador altere permissões. Esse é um limite
  do modelo de ameaça, não um teste aprovado.

Identidades concretas, grupos e binding conta→papel ficam sob custódia privada
no laboratório. Evidência compartilhada só usa rótulos O/U/A, booleans e hashes;
sem nomes, SIDs, SDDL, senhas ou caminhos pessoais. Verificar em memória que os
tokens realmente diferem, sem publicar seus identificadores.

## 2. Matriz de intenção por objeto e operação (tudo PROPOSTO)

P = permitir, N = negar, R = revisar explicitamente. Sem grant automático.
WRITE/DELETE positivos devem usar cópias descartáveis designadas, não a sentinela
externa nem o documento original. Operações negativas de U devem preservar bytes.

| Objeto sintético | Papel | READ_DATA/listar | WRITE_DATA | CREATE filho | DELETE | RENAME | READ_CONTROL | WRITE_DAC/OWNER |
|---|---|---|---|---|---|---|---|---|
| Raiz/contexto privado do fluxo | O | P | P conforme fluxo | P | P só contexto próprio | P só contexto próprio | P | R, não requisito do aplicativo |
| Raiz/contexto privado do fluxo | U | N | N | N | N | N | R conforme ameaça | N |
| Fonte financeira/cadastral sintética autorizada | O | P | R: original imutável no protocolo | N/A | R: só descarte autorizado | R | P | R |
| Fonte financeira/cadastral sintética autorizada | U | N | N | N/A | N | N | R | N |
| Canônico/JSON de auditoria privado | O | P | P pelo fluxo/replace autorizado | N/A | P só descarte próprio | P pelo fluxo | P | R |
| Canônico/JSON de auditoria privado | U | N | N | N/A | N | N | R | N |
| Chave HMAC de laboratório | O | P pelo processo autorizado | R só criação/rotação aprovada | N/A | R | R | R | R |
| Chave HMAC de laboratório | U/A | N | N | N/A | N | N | R | N |
| Lock, índice e cabeças de laboratório | O | P | P pelo fluxo válido | P nos diretórios próprios | P ao encerrar | P se contrato exigir | P | R |
| Lock, índice e cabeças de laboratório | U | N | N | N | N | N | R | N |
| Evidência agregada sanitizada separada | A | P se aprovado | N | N | N | N | R | N |
| Sentinela externa, criada só para observar links | O | P para verificar | N durante ataque | N durante ataque | N durante ataque | N durante ataque | P | N durante ataque |

N/A significa operação sem sentido para esse tipo de objeto, não aprovação de
DACL. Para fontes, resolver a opção de imutabilidade: O e o aplicativo usam o
mesmo token, logo não se pode prometer negar WRITE a O e permitir ao mesmo token
escrever esse mesmo arquivo sem outra fronteira. Uma eventual separação de
origem/importador/runtime exige política e arquitetura próprias, fora desta fase.

## 3. Semântica nativa que a política deve especificar

- Não usar permissões POSIX/chmod para definir direitos Windows.
- Distinguir DACL NULL (acesso amplo) de DACL vazia (negação, possivelmente
  inadequada ao controle positivo). Ambos exigem avaliação; negação de U sem
  operação positiva de O não prova uma política funcional.
- Herança só segundo política aprovada. Não remover herança ou criar deny amplo
  na máquina para fazer testes passarem. Se a proposta escolhida for uma allowlist
  privada, ela deverá restringir dados a O e exceções expressamente aprovadas,
  sem grants inesperados a grupos amplos. Isso ainda não está decidido/aplicado.
- DELETE do arquivo e DELETE_CHILD do diretório pai interagem. Testar ambos;
  negar só um não garante preservação. RENAME também envolve origem/destino.
- LIST_DIRECTORY negado não prova negação de READ_DATA por caminho conhecido;
  privilégios comuns de travessia podem dispensar checagens de ancestrais.
  Verificar o arquivo e cada diretório, sem presumir que a raiz protege tudo.
- Hardlinks compartilham identidade/DACL, mas têm nomes distintos. Separar o
  comparador ACL diagnóstico (WIN-04) do leitor por ID+SHA e da política física
  de cada repositório. Não impor rejeição universal de hardlink por suposição.
- Symlink e junction exigem provas diferentes. Não habilitar privilégio, mudar
  Developer Mode nem usar junction como substituição de um symlink não criado.
- Não usar sharing violation 32, erro de privilégio 1314, atributo READONLY ou
  bloqueio de arquivo como prova de negação DACL. Encerrar handles antes dos
  casos DACL e testar o mesmo tipo de objeto/atributos sob O e U.

## 4. Dependência de integração real — NÃO COMPROVADA

A inspeção de `private_json.escrever_json` mostra arquivo temporário + fsync +
replace; não uma política DACL Windows explícita. `conferir_local_privado` só
examina bits de modo quando POSIX. `FontesLocaisProtegidas` autoriza por ID,
raiz/caminho, limite e hash; sua implementação examinada não instala uma política
DACL. O Windows aplica a DACL existente ao abrir arquivos, mas isso não demonstra
que o aplicativo criou/verificou uma política privada adequada.

`private_permissions.mesmas_regras` compara listas de ACEs exatamente. A busca
estática não encontrou chamada/importação de consumo dessa função nos fluxos
examinados, além do próprio módulo; a docstring que a chama de “portão” não é
prova de integração. Não modificar essa comparação ou tolerar herança para
aproximá-la do diagnóstico. O módulo windows_acl_evidence continua diagnóstico,
com `autoriza_acesso=false` e `aplicada_ao_leitor=false`.

Se o fluxo real não materializar/verificar a política aprovada, o resultado é
EVIDENCIA_INSUFICIENTE/DACL_NÃO_VALIDADO. Não instalar ACL no laboratório e afirmar
que isso comprova o comportamento do escritor/leitor. Uma mudança funcional
necessária deve ser proposta em tarefa separada, sem implementação nesta entrega.

## 5. Protocolo futuro, somente após aprovação

1. Aprovar matriz, exceções, ameaça, volume NTFS, tokens e operador/custodiante.
2. Congelar manifesto 470, verificar ambiente sem elevação, reservar área nova.
3. O cria artefatos pelo fluxo real; registrar metadados de política sanitizados
   e hashes/bytes de referência. Nenhum raw SID/SDDL no relatório compartilhado.
4. O executa operações positivas em cópias designadas. Se falharem, o ensaio é
   inconclusivo/falhou; não usar U negado como única prova.
5. Fechar handles; U, em sessão/token próprio autorizado, tenta cada operação.
   Registrar API/código Win32 imediatamente, resultado e alteração observada.
   Não usar runas com senha na linha de comando, login automatizado ou impersonação
   por credencial coletada no chat. As contas devem estar provisionadas previamente.
6. Confirmar bytes COMPLETOS e snapshot de árvore inalterados após cada negação.
   Observar proprietário/herança após create e replace; repetir após reabertura.
7. Avaliar ancestrais e aliases com riscos controlados; se faltar capacidade,
   manter controle NÃO_VALIDADO. Não seguir nem apagar alvos de terceiros.
8. Limpar somente recursos próprios identificados após revisão do estado. Falha
   de limpeza preserva laboratório/evidências; nunca limpar o residual anterior.

## 6. Decisões ainda requeridas — sem execução automática

- Aprovar quem é O, U e eventual A, e quais exceções de manutenção são aceitas.
- Aprovar cada R da matriz, imutabilidade de fonte, retenção e descarte.
- Aprovar herança/allowlist esperadas e quem as instala/verifica no fluxo real.
- Confirmar segunda conta comum e custódia privada de identidade/evidências.
- Aprovar quais subcontroles de caminhos/links são necessários para cada objeto.

Até essas decisões e provas reais, DACL efetiva permanece NÃO_VALIDADO em todos
os controles pertinentes. Nenhum arquivo, privilégio, conta ou ACL foi alterado
para esta proposta. Homologação Windows e conversões reais continuam bloqueadas.

## 7. Quadro R2 de decisões abertas — todas PARA_APROVAÇÃO

Nenhum R da matriz anterior foi resolvido implicitamente. N também expressa
intenção proposta, não ACE deny já aprovada ou instalada. Todas as alternativas
abaixo precisam de responsável, decisão escrita, ambiente e critério mensurável.

| Decisão | Questão específica | Estado/impedimento |
|---|---|---|
| D01 READ_CONTROL | O/U/A por objeto podem ler owner/grupo/DACL? Metadados não equivalem a conteúdo. Definir mínimo necessário e custódia de SDDL. | PENDENTE; não interpretar R como permitir |
| D02 WRITE_DAC | Definir direito do owner e processo O, limite real de dono, eventual OWNER RIGHTS e manutenção; não prometer isolamento do mesmo token. | PENDENTE, sem negar/permitir automaticamente |
| D03 WRITE_OWNER | Separar de WRITE_DAC, tomada de posse e privilégios de backup/restauração; definir exceções e ameaça. | PENDENTE; não solicitar privilégio |
| D04 Fonte original imutável | Decidir importador/runtime/operador, retenção, descarte e se existe fronteira distinta. O mesmo token não é dois atores. | PENDENTE; somente cópias sintéticas descartáveis em ensaio |
| D05 Herança | Allowlist, proteção da raiz e filhos, grants amplos, herança em create e replace, proprietário e auditoria. Quem instala/verifica no fluxo real? | PENDENTE; não aplicar ACL manual para provar motor |
| D06 Administradores/SYSTEM | Decidir exceções explícitas e limites; grupo amplo não é exceção automática; acesso extraordinário auditável. | PENDENTE; modelo de ameaça ainda não aprovado |
| D07 Tokens | O e U comuns realmente distintos, grupos/privilegios efetivos, integridade/logon; A só evidência sanitizada. Binding privado com comprovação agregada. | PENDENTE; não criar conta/coletar senha/impersonar |
| D08 CREATE/REPLACE | Quem cria cada objeto, permissões iniciais, temp+rename, proteção após replace/reabertura e ausência de janela indevida. | PENDENTE; escritor sem política explícita não vira aprovado |
| D09 DELETE/RENAME | DELETE do objeto e DELETE_CHILD do pai, nomes origem/destino, alvos hardlink/reparse e limites por repositório. | PENDENTE; compartilhamento 32 não é negação DACL |
| D10 Chaves/registro/retenção | Criação/rotação/descarte de chave, acesso a concessões, locks/cabeças imutáveis e cópias de evidência. | PENDENTE; autoridade de aplicação não implica proteção SO |

O futuro termo deverá preencher todas as células R por papel/objeto/operação,
com decisão, justificativa, aprovador e data. Até lá, WIN18/19 e qualquer alegação
DACL ficam NÃO_VALIDADO/EVIDENCIA_INSUFICIENTE. Não há instrução de Set-Acl,
icacls de alteração, login automatizado ou alteração de privilégios nesta R2.
