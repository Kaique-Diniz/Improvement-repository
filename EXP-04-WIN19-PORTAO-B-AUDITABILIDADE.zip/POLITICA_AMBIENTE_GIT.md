# Ambiente filho Git — lista positiva WIN19_B_V1, somente leitura

Nenhuma consulta Git desta sonda foi executada nesta preparação. A política
abaixo é código proposto por inspeção; não altera ambiente global ou configurações.

## Entrada e rejeição

Qualquer nome de variável herdada que comece com GIT_ (case-insensitive) bloqueia
ANTES das três consultas: inclui GIT_CONFIG_*, GIT_TRACE*, GIT_DIR, GIT_WORK_TREE,
GIT_INDEX_FILE, GIT_COMMON_DIR, GIT_OBJECT_DIRECTORY, GIT_ALTERNATE_OBJECT_DIRECTORIES,
GIT_EXEC_PATH, GIT_ASKPASS, GIT_SSH_COMMAND e famílias futuras. Até valor vazio
é condição não prevista. Não imprimir nomes/valores, apagar variáveis globais ou
continuar com uma limpeza silenciosa. O capturador e a entrada repetem a recusa.

O Git é um executável absoluto fornecido/aprovado pelo operador (sugestão:
%ProgramFiles%\Git\cmd\git.exe). Caminho regular/ancestrais sem reparse e SHA
registrado. Não resolver por PATH herdado. Autenticador, rede e credenciais não
são necessários para HEAD, raiz e status locais e não são encaminhados ao filho.

## Dicionário completo criado para CADA subprocesso Git

| Variável gerada, não herdada | Valor/política |
|---|---|
| SystemRoot | raiz Windows existente validada |
| WINDIR | mesma raiz Windows validada |
| SystemDrive | unidade dessa raiz |
| PATH | somente diretório do git.exe aprovado + Windows\System32 |
| LANG | C |
| LC_ALL | C |
| GIT_CONFIG_NOSYSTEM | 1 |
| GIT_CONFIG_SYSTEM | NUL (dispositivo, sem arquivo persistente) |
| GIT_CONFIG_GLOBAL | NUL (dispositivo, sem arquivo persistente) |
| GIT_ATTR_NOSYSTEM | 1 |
| GIT_TERMINAL_PROMPT | 0 |
| GIT_OPTIONAL_LOCKS | 0 |

Não há env=os.environ, HOME, USERPROFILE, APPDATA, LOCALAPPDATA, XDG_CONFIG_HOME,
TEMP/TMP, proxies, credenciais, ASKPASS, GIT_TRACE ou GIT_CONFIG_COUNT/PARAMETERS
na lista do Git. Ambiente Python do capturador é separado deste dicionário;
a sonda cria explicitamente o ambiente Git e não o herda.

## Três consultas e configuração local

Cada subprocess.run usa explicitamente env=env_git, stdin=DEVNULL,
capture_output=True, timeout20 e executável absoluto. Apenas:
rev-parse HEAD; rev-parse --show-toplevel; status --porcelain=v1 --untracked-files=all.
Opções comuns: --no-optional-locks, -c core.fsmonitor=false,
-c core.untrackedCache=false, -c core.hooksPath=NUL, -c core.attributesFile=NUL.
Sem add/reset/checkout/config --global, hooks ou consulta de rede.

GIT_CONFIG_SYSTEM/GLOBAL não desabilitam a configuração LOCAL. Por isso a sonda
lê, sem executar Git, o .git/gitdir/commondir e config/config.worktree regulares,
com limites de tamanho. Recusa includes, filter/diff/alias e seções/chaves não
previstas, sintaxe ambígua e valores multilinha. A lista aceita somente core,
extensions, remote, branch, user, init e safe, com chaves explicitadas no código.
fsmonitor/hooks/attributes são sobrepostos só na chamada. Não expõe valores de
configuração, URLs ou credenciais. Se uma configuração legítima não for aceita,
PARAR e revisar a lista; não editar a configuração para obter coleta verde.

Metadados devem estar estáveis durante a coleta. Inspeção por caminho não impede
substituição ativa entre leitura e abertura: o limite TOCTOU permanece registrado;
esta política não prova proteção DACL contra outro token ou contra o próprio dono.

Retorno Git não zero/timeout/decodificação inválida bloqueia sem mascarar o erro;
o stderr fica em memória da sonda e não é publicado cru. O JSON usa código seguro.
A sonda tenta conferir470 no finally após integridade inicial válida. Erro de
integridade final conserva bloqueio e eventual código anterior. O relatório
identifica política, zero variáveis herdadas, ausência de traces/autenticação,
config local revisada e SHA do executável, sem divulgar os caminhos.
