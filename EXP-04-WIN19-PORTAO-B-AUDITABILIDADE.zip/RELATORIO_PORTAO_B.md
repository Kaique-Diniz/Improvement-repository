# Portão B — ajuste mínimo de auditabilidade, preparado para revisão

18/11/2026. Instrução principal INSTRUCOES_CODEX_WIN19_PORTAO_B_AJUSTE_AUDITABILIDADE.md;
fundamento PARECER_WIN19_PORTAO_B_AJUSTES_2026-11-18.md, preservados literalmente.

Alteração funcional somente no capturador externo: sanitizar V2 com lista positiva,
tipos exatos/sem coerção, python/plataforma/build, flags de área, volume aninhado e
capacidades, contagem de configsGit. Esquema completo exige todos os campos esperados;
parcial é BLOQUEADA com ausências conhecidas, extras/tipos/invariantes reprovam.
Campos desconhecidos não são aceitos silenciosamente: apenas quantidade, sem
nomes ou valores. Main grava o derivado seguro e mantém retorno bloqueado para
parcial/reprovado. Acrescenta metadados não privados de tempo/SHAs para B21, sem
alterar privacidade de brutos/normalizado. Não é nova execução nem resultado.

A entrada só atualiza o SHA pinado do capturador; HASHES_PREFLIGHT acompanha.
Sonda, wrapper, candidata470, matriz19, DACL e propostaWIN14 não mudaram. Esquema,
contrato de tipos, mapaB01–B22, critérios/protocolo/modelo/roteiro tornam explícita
a origem de cada prova compartilhável. B01 e partes B21 continuam dependentes
de artefatos/atestação externos; JSON sozinho não autentica sua origem.

Verificador PowerShell externo e relação de hashes concretos acompanham o ZIP
como arquivos SEPARADOS, com SHA do verificador também fora do ZIP. Não há
hash autorreferente. O auditor deve receber e revisar esses arquivos, além do ZIP.
PLANO_PARSE_PS51_NAO_EXECUTADO prepara somente ParseFile de cópias textuais,
sem invocação, dot-source ou avaliação dinâmica; exige autorização distinta.

Conferências feitas somente por leitura, AST/compilação em memória e extração
de constantes literais, parsing JSON/CSV, Git de preservação e hashes/CRC de
artefatos. NÃO foi executado sanitizar, capturador, sonda/preflight (nem Linux),
PowerShell/parsing5.1, pytest/coleta ou ensaio nativo/DACL. Esquema JSON auxiliar
não foi validado por execução de casos. Tipagem runtime segue sem prova empírica.

Diff funcional mínimo é entregue separadamente; diff de preparação inclui novos
documentos e metadados. Os hashes dos scripts atualizados são reemitidos. ZIP,
manifesto e entrada anteriores preservados. Registro local confirma470 hashes,
27worktrees e18ZIPs anteriores intactos; isso não revalida a candidata no Windows.

Riscos remanescentes: código novo e esquema ainda não exercitados; PS5.1/nativo,
reparse/TOCTOU, custódia sob falha de energia, encerramento de descendentes e
DACL não demonstrados. JSON inválido/ausente pode impedir derivado; preservar
brutos e classificar bloqueio, sem fabricar campos. Mesmo completo estruturalmente
não aprova B01–B22, DACL, os19 históricos ou operação. A função não torna dados
arbitrários seguros por inferência: todo campo conhecido fora do tipo/formato é
rejeitado; release de derivado ainda depende de revisão humana.

19 PROVISORIO_SEM_FONTE, todos eixos NÃO_VALIDADO, fonte primáriaEXP04 ausente,
C/D/E e conversões reais BLOQUEADOS. Primeira coleta não autorizada. Nenhum
commit/push/merge/PR/publicação, instalação ou mudança de política/privilégio/ACL.
PARE PARA AUDITORIA. A vedação expressa desta etapa foi respeitada.
