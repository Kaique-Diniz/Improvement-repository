# Proposta de parsing PS5.1 — somente após autorização separada

NÃO EXECUTAR nesta entrega. Não é preflight, teste de semântica Windows, DACL
ou execução de comandos do pacote. Nenhum parsing PowerShell foi realizado.

Após revisão/decisão própria, usar PowerShell5.1 comum e diretório sintético
NOVO fora de Git/candidata/documentos/resíduos. Copiar SOMENTE os bytes textuais
de COMANDO_PORTAO_B_NAO_EXECUTADO.ps1, tools/preflight_win19.ps1 e do verificador
EXTERNO para arquivos com sufixo .texto; conferir cada SHA pelo registro externo.
Não dot-source, invocar ou avaliar o conteúdo. Não carregar perfil/alterar política.
A preparação das cópias e retenção da saída são manuais, não executadas aqui.

Bloco futuro de referência, a revisar com caminhos/hashes preenchidos:

```powershell
# SOMENTE PARSING, NAO EXECUTADO. Nao usar este bloco sem autorizacao propria.
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {
    throw 'POWERSHELL_51_OBRIGATORIO'
}
$RaizCopias = Read-Host 'Diretorio sintetico novo aprovado, fora de Git'
$Itens = @(
    @{ rotulo='ENTRADA'; nome='entrada.texto'; hash='PREENCHER_HASH_EXTERNO' },
    @{ rotulo='WRAPPER'; nome='wrapper.texto'; hash='PREENCHER_HASH_EXTERNO' },
    @{ rotulo='VERIFICADOR'; nome='verificador.texto'; hash='PREENCHER_HASH_EXTERNO' }
)
$Resumo = foreach ($Item in $Itens) {
    if ($Item.hash -notmatch '^[0-9a-f]{64}$') { throw 'HASH_EXTERNO_NAO_PREENCHIDO' }
    $Copia = Join-Path $RaizCopias $Item.nome
    if ((Get-FileHash -LiteralPath $Copia -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Item.hash) {
        throw 'COPIA_TEXTUAL_DIVERGENTE'
    }
    $Tokens = $null
    $Erros = $null
    $AstSomente = [System.Management.Automation.Language.Parser]::ParseFile($Copia, [ref]$Tokens, [ref]$Erros)
    $Detalhes = @($Erros | ForEach-Object {
        [pscustomobject]@{
            codigo = $_.ErrorId
            linha = $_.Extent.StartLineNumber
            coluna = $_.Extent.StartColumnNumber
            fim_linha = $_.Extent.EndLineNumber
            fim_coluna = $_.Extent.EndColumnNumber
        }
    })
    [pscustomobject]@{ arquivo=$Item.rotulo; sha256=$Item.hash; erros=$Detalhes; quantidade=$Detalhes.Count }
}
$Resumo | ConvertTo-Json -Depth 8
```

A raiz/cópias devem ser inspecionadas para recusar links/reparse e metadataGit
antes do bloco; sem seguir destino simbólico, sem tocar na candidata. O bloco não
cria/copia/grava arquivos e não executa os textos parseados; não contém operador
de invocação, dot-source nem avaliação dinâmica. Erros completos ficam sob custódia
privada; saída compartilhada só traz IDs/posições/rótulos, não mensagem/tokens/texto.

Aceite: hashes das cópias iguais ao registro externo e zero erros de parsing na
versão5.1 observada. Parsing inválido bloqueia. Zero erros NÃO valida APIs,
redirecionamentos, códigos de retorno, durabilidade, DACL ou prontidão da coleta.
Autorização de parsing não autoriza B/C/D/E, preflight ou captura.
