# Codex — EXP-04 / WIN-19 — Próxima entrega: portão B (preflight somente leitura)

**Status de entrada:** R2 aceita apenas como preparação documental, com ressalvas; 19 vínculos `PROVISORIO_SEM_FONTE`; todos os controles funcionais/nativos/DACL `NÃO_VALIDADO`.

## Trabalho autorizado **nesta entrega**

1. Ler o parecer técnico WIN19-R2 e os artefatos R2 entregues. Conferir a identidade/hash do pacote e os scripts de preflight, mantendo a candidata R1-FIX intacta.
2. Preparar instruções precisas de **preflight somente leitura** para execução futura no Windows, nomeando a candidata R1-FIX existente, o arquivo `REFERENCIA_R1_FIX_470_SHA256.json`, os scripts `preflight_win19.py/.ps1` extraídos numa pasta externa ao Git e uma área `WIN19-*` futura, ainda inexistente, diretamente sob LocalAppData.
3. Demonstrar por inspeção que o preflight não cria área, link, ACL, conta, temporário, JUnit ou altera privilégio. Registrar limite de consultas Win32 e interpretação do código de saída 0: **coleta concluída**, não aprovação ou prontidão.
4. Preparar os critérios de aceite/rejeição do relatório JSON sanitizado, incluindo 470 hashes, HEAD, Git, Python 3.12, token não elevado, volume real, alias 8.3, capacidade/limites de symlink, impedimentos e portões C/D/E bloqueados.
5. Revisar estaticamente o executor futuro, com ênfase em coleta resiliente de evidência anterior às asserções, isolamento de tmp/basetemp, custódia de brutos, imports, helpers de remoção por handle e proteção das sentinelas. Entregar sugestões em diff **somente na preparação externa** quando indispensáveis.
6. Documentar os limites de WIN-14/16 e WIN-03, e preservar os skips por symlink/1314 e os protocolos WIN-18/19 como NÃO_VALIDADO.
7. Manter a solicitação de custódia do JUnit EXP-04 original e dos motivos individuais dos sete skips; sem fonte original, não reconciliar os 19 vínculos por aproximação.

## Proibições

- **Não executar** preflight, pytest, coleta pytest, criação de symlink, experimento de API, acesso entre contas ou teste DACL sem autorização específica posterior.
- Não mudar o motor, produção, a candidata R1-FIX (470 hashes), políticas de segurança, ACL, contas, privilégios, Developer Mode ou Git global.
- Não usar execução administrativa nem automatizar senhas. Não limpar worktrees/laboratórios/resíduos existentes.
- Sem commit, push, PR, merge, publicação ou conversões reais.

## Entrega

Plano do portão B, comando PowerShell ainda **não executado**, checklist dos critérios, diff de preparação se houver e manifesto SHA-256; estado explícito C/D/E **BLOQUEADOS**. Parar após essa entrega para revisão humana.
