# EXP-04 / WIN-19 — Parecer de revisão técnica da preparação R2

**Data:** 18/11/2026  
**Escopo da revisão:** artefatos estáticos recebidos no arquivo `EXP-04-WIN19-R2-preparacao.zip`.  
**Decisão:** **preparação documental aceita, com ressalvas; preflight somente leitura elegível para autorização separada; execução de ensaios, DACL e homologação NÃO autorizadas.**

## 1. Integridade e proveniência

- ZIP recebido: **219.760 bytes**; SHA-256 `535fa9e0fae92ec358edd74a385808170d38570ce0ead3fd715e230715be585b`; 33 entradas; CRC íntegro.
- Manifesto `MANIFESTO_ARQUIVOS_R2_SHA256.json`: **32/32** arquivos com tamanho e hash SHA-256 correspondentes. O próprio manifesto é excluído para evitar autorreferência.
- `MATRIZ_WIN19_RECONCILIADA_R2.csv` lida com separador `;`: **19 identificadores únicos**, WIN-01 a WIN-19, dos quais **19 `PROVISORIO_SEM_FONTE`**, 0 confirmados, e 19 controles funcional/nativo/DACL `NÃO_VALIDADO`.
- Manifesto de referência da R1-FIX preservado: SHA-256 `a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`, com 470 entradas, baseline `770d062d29c4361d6932592883df9339bb4089bc`.
- `PRESERVACAO_R2.json` **declara** 470 arquivos locais preservados, 27 worktrees e 15 ZIPs anteriores. A preservação efetiva desses bens na máquina/workspace do executor não foi reavaliada nesta revisão do ZIP.
- Foram inspecionados os seis scripts Python por leitura e sintaxe AST; **nenhum teste ou preflight Windows foi executado nesta revisão**.

## 2. Pontos aceitos

1. Separação explícita entre prova funcional, API nativa e DACL; nenhum PASS de cleanup reaproveitado.
2. Custódia histórica condicionada ao JUnit EXP-04 original, log, versão e aos motivos literais dos sete skips; o extrator `extrair_junit_historico.py` é apenas índice auxiliar, não confirma nodeids.
3. Reformulação de WIN-14 para propor gravação/releitura real de pacote sintético com HMAC/recibo e ataque por symlink, sem alegar proteção SO.
4. Reformulação de WIN-16 para propor CLI real, PDF fabricado, gabarito declarativo separado e negativa do DTO, sem alegar exportação operacional.
5. WIN-03 preserva explicitamente o ramo de erro nativo não demonstrado, sem usar NUL/entrada inválida como falsa evidência de API.
6. Preflight Python/PowerShell é, pela leitura estática, orientado a consultas e hashes; sua saída 0 significa coleta concluída, não prontidão nem autorização de testes.
7. Política DACL-R2 distingue objeto/pai, DELETE/DELETE_CHILD, herança, owner, READ_CONTROL/WRITE_DAC/WRITE_OWNER e tokens O/U/A, todos ainda **PARA_APROVAÇÃO**.

## 3. Ressalvas e verificações obrigatórias antes dos ensaios

**R1 — Runner de evidências ainda não existe.** O plano especifica coleta sequencial, um basetemp novo e exclusivo, proteção de imports, custódia JUnit/diagnóstico bruto antes de limpeza, hashes dos helpers e de toda a candidata antes/depois. Isso não foi implementado na R2. **Não executar os 21 casos propostos diretamente por pytest.**

**R2 — Helpers nativos não validados em Windows.** `suporte_nativo.py` usa CreateFileW, abertura de ancestrais, identidade por volume/file ID e SetFileInformationByHandle. Revisar ABI/flags, inclusive `GENERIC_READ` nos diretórios ancestrais, semântica da exclusão de symlink e fechamento de todos os handles. Realizar verificação direcionada em área de laboratório previamente autorizada; nenhuma mudança de produção. A sintaxe não prova a segurança do helper.

**R3 — Factory WIN-06–10/12.** Confirmar dinamicamente a estrutura de revisão zero e a remoção por identidade do único lock regular vazio esperado. Se houver qualquer objeto inesperado, não removê-lo para fazer o teste passar. Observar que os ensaios podem depender da criação real de symlink; `WinError 1314` mantém o subcontrole NÃO_VALIDADO.

**R4 — WIN-14.** Validar em runtime o contrato exato de `PacotePrivado`, `gravar_pacote`, autoridade, catálogo, inventário e recibo. Antes do ataque, incluir na evidência de preservação os arquivos sintéticos da autoridade/credenciais de laboratório além do repositório, recibos e sentinela externa. Não transportar segredo bruto à evidência sanitizada. Não equiparar autoridade HMAC a DACL.

**R5 — WIN-16.** Validar no runtime a interpretação do PDF posicionado, as linhas e coordenadas, normalização de IDs/ressalvas e o relatório JSON/CLI. Se um gabarito não corresponder, corrigir a fixture apenas com base no contrato independente e evidência, nunca copiando a saída do leitor para obter PASS. O teste do DTO não substitui o fluxo operacional de exportação.

**R6 — Diagnóstico durante falhas.** `conftest.py` persiste evento INICIO e os helpers registram alguns eventos com fsync, mas não substituem um executor capaz de conservar **todas** as evidências primárias mesmo quando uma asserção, timeout, subprocesso ou remoção falhar. Distinguir API do helper de API do motor.

**R7 — WIN-18/19 não são ensaios DACL.** As funções propostas contêm apenas `pytest.skip` por falta de política/tokens. Não contar esses skips como cobertura. A especificação DACL tem dez decisões ainda abertas (D01–D10); requer aprovação de modelo de ameaça, ACL real aplicada/verificada pelo produto e tokens comuns distintos antes de qualquer ensaio entre contas.

**R8 — 21 casos são previsão de leitura**, não coleta `pytest --collect-only`. Manter `NAO_EXECUTADO` e `NÃO_VALIDADO` até observação em Windows.

## 4. Decisão por portão

| Portão | Decisão após esta revisão |
|---|---|
| A — preparação documental R2 | **ACEITA COM RESSALVAS** |
| B — preflight Windows somente leitura | **ELEGÍVEL para autorização específica**, com caminhos verificados, cópia externa ao Git e sem execução de pytest; retorno 0 não aprova C/D/E |
| C — casos sintéticos nativos | **BLOQUEADO** até runner/evidências, revisão dos helpers/factories e autorização separada |
| D — ensaios DACL entre tokens | **BLOQUEADO** até aprovação de política e laboratório |
| E — homologação/conversões reais/publicação | **BLOQUEADO** |

## 5. Próxima entrega sugerida ao executor

- Propor comando de preflight read-only com caminhos explícitos para **a mesma candidata Windows R1-FIX** (`candidata-lf-v2`) e manifesto SHA-256 de 470; scripts em pasta de preparação externa.
- Especificar os indicadores que interrompem a coleta: elevação, divergência de hashes/HEAD, volume/área incompatíveis, reparse, erro API. Não modificar conta, privilégio, ACL, Git, candidata ou arquivos anteriores.
- Entregar o **roteiro de execução e modelo de evidência para B**, e revisar runner/fixtures dos casos C **sem executá-los**.
- Seguir buscando a fonte primária EXP-04: JUnit de 2.842 testes/19 falhas/7 skips e baseline histórico de 448 arquivos. Não inventar correspondências.

**Limite:** a aprovação documental da R2 não implica aprovação de testes Windows, controles WIN-01–19, política DACL ou desbloqueio operacional.
