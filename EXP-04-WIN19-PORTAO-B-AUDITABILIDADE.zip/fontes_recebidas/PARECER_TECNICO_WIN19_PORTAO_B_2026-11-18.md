# EXP-04 / WIN19-R2 — Parecer técnico sobre Portão B

**Data:** 18/11/2026  
**Objeto:** `EXP-04-WIN19-R2-PORTAO-B.zip` recebido nesta conversa.  
**Decisão:** **Preparação documental aceita com ressalvas; preflight ainda não autorizado para execução.** Os portões C/D/E, testes e DACL seguem bloqueados.

## 1. Integridade e custódia documental

- ZIP: **91.674 bytes**, SHA-256 **`69fdfff9316259012c7ed104bb676720d883553864aebc3084b220ed2cd95741`**, **22 entradas**, CRC íntegro.
- `MANIFESTO_PORTAO_B_SHA256.json`: **21/21** arquivos cobertos, tamanho e SHA-256 correspondentes; o manifesto se exclui.
- `CRITERIOS_ACEITACAO_PORTAO_B.csv`: **22 critérios B01–B22**, identificadores únicos.
- `MATRIZ_WIN19_RECONCILIADA_R2.csv`: **19 controles**, todos `PROVISORIO_SEM_FONTE` e `NÃO_VALIDADO`; não houve reconciliação com JUnit original.
- Matriz, política DACL e manifesto de 470 arquivos **idênticos byte a byte** à preparação R2 recebida anteriormente; hash de referência de 470 arquivos: `a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`.
- Script de preflight Python possui sintaxe AST válida. PowerShell inspecionado por leitura; **não foi executado no PowerShell 5.1 nem no Windows nesta auditoria**.
- O ZIP não inclui os 470 arquivos da candidata Windows; a preservação alegada de worktrees/pacotes no ambiente Codex não é verificável a partir do ZIP.

## 2. Aspectos aceitos

1. Comando futuro é explicitamente não executado e exige uma chave de autorização, que não equivale à aprovação.
2. A sonda verifica hashes iniciais e finais, incluindo extras e caminhos especiais, e conserva reprovação se não comprovar a integridade final.
3. Consulta do Git usa `--no-optional-locks`, `core.fsmonitor=false` e `core.untrackedCache=false`; não executa reset, checkout ou alteração de ACL.
4. Token é consultado com `TOKEN_QUERY`; não há chamada a `AdjustTokenPrivileges` nem criação de symlink.
5. Os scripts consultam LocalAppData, volume, privilégio, alias 8.3 e Developer Mode sem requerer alterações do sistema.
6. Saída `0` significa somente coleta concluída; `prontidao_para_executar=false` e portões C/D/E bloqueados.
7. O plano reconhece limites de TOCTOU, de stdout normalizado e de prova nativa.

## 3. Ressalvas que precisam ser sanadas antes do Portão B

### B-R1 — Integridade do próprio comando de entrada (prioridade alta)

`COMANDO_PORTAO_B_NAO_EXECUTADO.ps1`, linhas 30–44, confere hashes do Python, do wrapper `tools/preflight_win19.ps1` e do manifesto de 470, **mas não verifica seu próprio hash antes da execução**. Seu SHA-256 no pacote recebido é `977e04e3fe3504128e755db13b8eedc894de086cb8ac6ee1fc5e73a06cded25b`.

**Correção exigida:** estabelecer no procedimento externo uma verificação independente do SHA-256 do comando de entrada, preferencialmente com o ZIP pinado antes da extração e uma segunda verificação do arquivo já extraído **antes de invocá-lo**. Não tentar criar uma verificação autorreferente dentro do próprio script como substituto de uma raiz de confiança externa. Fixar também o caminho da pasta de preparação e recusar scripts/materiais inesperados no escopo executável.

### B-R2 — Ambiente herdado dos subprocessos Git (prioridade alta)

`tools/preflight_win19.py`, linhas 204–216, bloqueia seis variáveis de redirecionamento Git e usa opções locais que restringem alterações esperadas. Porém, **não trata** outras famílias de configuração/rastro (`GIT_CONFIG_*`, `GIT_TRACE*` e outras variáveis `GIT_*`), que podem influenciar a execução e em certos casos fazer o Git gravar rastros em disco. O Portão B exige coleta somente leitura.

**Correção exigida:** adotar uma lista positiva de variáveis Git estritamente necessárias ou ambiente filho controlado para as três chamadas Git, mantendo apenas a autenticação/caminho mínimo exigido e deixando demonstrado que variáveis de redirecionamento, configuração, trace e hooks não influenciam nem geram escrita. Reprovar sem tocar no ambiente global quando houver condição não prevista. Validar estaticamente e explicar o tratamento de erros sem expor caminhos privados.

### B-R3 — Evidência durável e responsável pela custódia (prioridade alta)

`ROTEIRO_PORTAO_B.md`, seção 4, e `MODELO_EVIDENCIA_PORTAO_B.json` reconhecem que a saída JSON normalizada e seu SHA em memória **não representam stdout bruto nem custódia durável**. O modelo mantém `custodiante: A_DESIGNAR`, e o comando futuro não salva resultados.

**Correção exigida:** apresentar procedimento separado, não executado, para preservar a evidência em uma pasta nova, fora de Git e das candidatas, especificando responsável, horário com fuso, versão e hash de cada script, resultados stdout/stderr (brutos quando tecnicamente capturados), normalização aplicada, tamanho e SHA-256. Não solicitar à sonda que crie área, arquivo ou teste. A custódia deverá estar aprovada antes da única execução para evitar perder informação.

### B-R4 — Validação em PowerShell 5.1 (ressalva explícita)

Não houve execução nem parsing nativo do wrapper PowerShell 5.1; sua compatibilidade e captura de fluxo são ainda **não comprovadas**. Isso não autoriza testá-lo sobre a candidata: propor revisão estática e, se necessário, ensaio exclusivamente de parsing em sandbox sintético com aprovação própria. Não reclassificar a sonda como validada por leitura.

## 4. Condições de progressão

- **Aceito:** arquivos de preparação e critérios, com as ressalvas registradas.
- **Não autorizado:** executar `COMANDO_PORTAO_B_NAO_EXECUTADO.ps1`, `preflight_win19.ps1`, `preflight_win19.py`, `pytest`, coleta de 21 casos ou testes DACL.
- **Pendente:** revisão corretiva limitada às três ressalvas altas, conferência dos hashes resultantes, prova documental de custódia e uma decisão expressa separada para **uma única execução** do Portão B.
- **Preservado:** candidata R1-FIX de 470 caminhos, matriz dos 19 históricos provisórios, política DACL D01–D10 `PARA_APROVAÇÃO`, portões C/D/E bloqueados, conversões reais bloqueadas, sem commit/push/merge/publicação.

## 5. Limite do parecer

É uma revisão estática do ZIP e de sua correspondência documental. Não prova que o preflight passará em Windows, nem homologa API, symlink, isolamento de contas ou DACL.
