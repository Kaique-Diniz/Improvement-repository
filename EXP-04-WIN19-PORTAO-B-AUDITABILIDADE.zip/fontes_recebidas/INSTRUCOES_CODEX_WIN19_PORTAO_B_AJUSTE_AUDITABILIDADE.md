# EXP-04 / WIN19 — Ajuste mínimo final de auditabilidade do Portão B

Usar como fundamento `PARECER_WIN19_PORTAO_B_AJUSTES_2026-11-18.md` e preservar a preparação já entregue.

**Escopo estrito:** fechar a lacuna entre o JSON sanitizado e os 22 critérios de aceitação, permitindo auditoria independente sem encaminhar campos privados, e disponibilizar a raiz de confiança externa para revisão.

## Tarefas

1. Em `tools/custodia_portao_b.py`, revisar `sanitizar()` com lista positiva e validação estrita de tipos. Incluir os campos não sensíveis que comprovam B02, B09/B10, B12/B13 e B22; para `volume_candidata`, incluir apenas sistema de arquivos e capacidades booleanas previamente definidas, sem caminhos, SIDs, SDDL, hostname ou nome da conta.
2. Impedir que campos desconhecidos sejam silenciosamente aceitos: rejeitar o esquema inesperado ou registrar a presença de chaves desconhecidas de modo restrito, sem transferir valores privados. Prever campos obrigatórios para coletas completas e aceitar evidência parcial como bloqueada quando houver erro.
3. Atualizar protocolo, critérios e modelo de evidência para refletir com exatidão o esquema efetivamente compartilhável. Manter brutos e normalizado em custódia privada; não publicar stdout/stderr privados.
4. Entregar fora do ZIP o verificador PowerShell externo e a relação de hashes externos; fornecer o SHA-256 do verificador também de forma independente para que possa ser auditado antes de uso.
5. Preparar (não executar) uma checagem de sintaxe PS5.1 baseada em `System.Management.Automation.Language.Parser.ParseFile` sobre cópias sintéticas, sem `&`, dot-source ou `Invoke-Expression`; registrar que parsing não valida a semântica Windows.
6. Produzir diff mínimo, inventário/manifesto, hash do novo ZIP, e explicar os arquivos alterados versus preservados.

## Restrições

- Não executar preflight, capturador, PowerShell, pytest ou testes Windows/DACL nesta entrega.
- Não modificar a candidata R1-FIX, o motor, a matriz com 19 vínculos provisórios ou a política DACL não aprovada.
- Não modificar ACLs, privilégios, políticas, Developer Mode ou configurações persistentes.
- Não fazer commit, push, merge, publicação ou desbloquear conversões reais.
- Parar após a entrega corrigida para auditoria e autorização expressa da primeira coleta.
