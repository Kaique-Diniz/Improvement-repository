# EXP-04 / WIN19 — Parecer da preparação corrigida do Portão B

**Data:** 18/11/2026  
**Objeto:** revisão estática da entrega `EXP-04-WIN19-PORTAO-B-AJUSTES.zip` enviada pelo usuário.  
**Decisão:** **integridade documental aprovada; execução do preflight ainda não autorizada**. Preparação tecnicamente avançada, com ajustes residuais de auditoria antes da decisão de execução.

## 1. O que foi conferido independentemente

- ZIP recebido: **119.127 bytes**; SHA-256 `338c1b04079b3597d9460df2a9e7d2d23dcd44662c46edc92b759f7e2e0a0112`.
- 28 entradas; CRC ZIP íntegro; manifesto interno contém **27 entradas**, todas com tamanho e SHA-256 correspondentes.
- SHA-256 do manifesto `MANIFESTO_PORTAO_B_SHA256.json`: `7410707b7a30bc4de1f5010fcd8cc73b86a578f1bfc84af1c1247f6da67456e5`.
- SHA-256 de `COMANDO_PORTAO_B_NAO_EXECUTADO.ps1`: `c4fc54f9b8fc0bdd3659c1d2c37d3c3e9a4ccf76dce9673a5afd29cf5829f5f8`.
- 22 critérios B01 a B22, únicos. Matriz CSV: 19 controles, todos com vínculo `PROVISORIO_SEM_FONTE`, eixos funcional/nativo/DACL `NÃO_VALIDADO` e nativo `NAO_EXECUTADO`.
- Manifesto de referência da R1-FIX: SHA-256 `a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`, 470 caminhos declarados.
- AST Python: `tools/preflight_win19.py` e `tools/custodia_portao_b.py` sintaticamente válidos.
- Não foram executados comandos PowerShell, preflight, Git, capturador, pytest ou ensaios DACL. A integridade da candidata física no Windows não foi verificada nesta revisão.

## 2. Correções anteriores efetivamente presentes na entrega

1. **Pinagem externa planejada (B-R1):** documentação distingue hash do ZIP/comando/manifesto recebido por fora e inventário interno; entrada restringe pasta, material esperado, reparse, hashes e executáveis. Entretanto, o **verificador externo separado e seu hash independente não estão no ZIP recebido**; não foram auditados nesta revisão.
2. **Ambiente Git (B-R2):** recusa explícita de variáveis `GIT_*` herdadas; três consultas Git em `subprocess.run` com dicionário positivo, `stdin=DEVNULL`, timeout, executável absoluto e verificações de configuração Git local. É desenho estático, ainda sem comprovação nativa no Windows.
3. **Custódia (B-R3):** capturador externo separado da sonda; área de evidências nova e exclusiva, `inicio_privado.json`, brutos binários, normalizado, sanitizado, `fim_privado.json` e cadeia SHA-256, com tentativas de `fsync` e releitura. Nenhuma prova empírica de compatibilidade, durabilidade ou DACL é atribuída.
4. **PowerShell 5.1 (B-R4):** compatibilidade não alegada e nenhum parsing nativo executado.

## 3. Pendências verificadas na auditoria estática

### P1 — Lacuna entre os 22 critérios e o relatório sanitizado

A função `sanitizar()` em `tools/custodia_portao_b.py` conserva somente parte dos campos produzidos por `tools/preflight_win19.py`. A cópia compartilhável **não conserva** dados não sensíveis necessários para conferir, sem acesso aos brutos privados, aspectos dos critérios:

- B02: versão exata do Python, plataforma e build do Windows (`python`, `sistema`, `windows_build`).
- B09/B10: `preparacao_externa_ao_git`, `area_prevista_nova`, `area_direta_localappdata`, `area_fora_git`, `sem_sobreposicao_candidata`.
- B12/B13: `sistema_arquivos`, `persistent_acls_suportadas`, `volume_candidata` e capacidades relacionadas.
- B22: `git_config_arquivos_conferidos`.

Esses dados permanecem no JSON privado, mas o protocolo recomenda compartilhar somente a cópia sanitizada e a cadeia de hashes. Para que a auditoria independente dos B01–B22 seja verificável sem publicar caminhos/SIDs/credenciais, ampliar a lista positiva **somente** para campos não sensíveis de tipo e formato estritos, incluindo estrutura aninhada de volumes validada explicitamente. Se preferirem não compartilhar esses campos, documentar critérios que somente o custodiante poderá atestar, com prova assinada e rastreável.

A função também descarta chaves inesperadas sem indicar que foram descartadas; alinhar código e afirmação documental “campo novo ou inesperado não é aceito silenciosamente”, seja reprovando chaves extras não previstas, seja registrando apenas os nomes permitidos/rejeitados, nunca os valores brutos.

### P2 — Raiz de confiança externa não auditada completamente

O ZIP não contém o `WIN19-PORTAO-B-AJUSTES-VERIFICACAO-EXTERNA.ps1` nem o arquivo de hashes externos anunciado como entregue separadamente. É uma separação intencional correta, mas **eles ainda precisam ser anexados para auditoria**, inclusive hash SHA-256 do verificador recebido por canal independente. O inventário do ZIP não autentica sozinho a origem.

### P3 — Execução de PowerShell e fluxo de captura não comprovados

O comando de entrada e seu wrapper não foram parseados no PowerShell 5.1, e o fluxo de custódia/execução não foi testado nativamente. Antes da primeira coleta, exigir parsing controlado de cópia textual **sem invocar** o comando, preflight ou capturador, e aprovar expressamente local/retenção/custodiante e uma única execução. A aprovação de parsing não equivale a aprovação do comportamento nativo.

## 4. Decisão por portão

- **Preparação documental e integridade:** APROVADAS.
- **Portão B — preflight somente leitura com captura em disco:** **AGUARDANDO COMPLEMENTAÇÃO / AUTORIZAÇÃO EXPRESSA**.
- **Portões C/D/E, ensaios DACL, Win-19 e conversões reais:** BLOQUEADOS.
- **R1-FIX (470 arquivos), suíte 39 e evidências anteriores:** não alterar, reconstruir nem reexecutar em razão desta revisão.

## 5. Próxima entrega mínima solicitada ao Codex

1. Corrigir o esquema sanitizado para permitir revisar os 22 critérios sem expor dados privados; versionar o esquema e registrar campos obrigatórios/ausentes/inesperados.
2. Reemitir somente o capturador, a documentação alterada, o diff e os hashes; **não alterar a sonda nem a candidata sem necessidade técnica demonstrada**.
3. Encaminhar **separadamente** o verificador externo e seu arquivo de hashes, bem como o SHA-256 do próprio verificador obtido de registro externo, para conferência independente.
4. Propor o parsing PowerShell 5.1 de cópias apenas, com saída de erros, sem invocação de scripts. Não executar até autorização específica.
5. Não executar preflight, pytest, ensaios, alterações de ACL/privilégios, commit, push, merge ou publicação.

**Nota:** esta é uma revisão estática baseada no ZIP anexado; não é homologação Windows/DACL nem autorização de uso operacional.
