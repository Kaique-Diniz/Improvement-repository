# EXP-04 / WIN19-R2 — Ajustes finais do Portão B, sem execução

**Referência:** parecer `PARECER_TECNICO_WIN19_PORTAO_B_2026-11-18.md`, pacote `EXP-04-WIN19-R2-PORTAO-B.zip`.

**Decisão:** documentos aceitos, mas ainda **não há autorização para executar o preflight Windows**.

## Escopo autorizado desta preparação adicional

1. **Pinagem externa do comando:** preparar verificação antes da invocação do SHA-256 do ZIP e do `COMANDO_PORTAO_B_NAO_EXECUTADO.ps1` já extraído. O SHA do comando original auditado foi `977e04e3fe3504128e755db13b8eedc894de086cb8ac6ee1fc5e73a06cded25b`; se o script for revisado, gerar novo hash e novo manifesto de forma coerente, sem alegar que o próprio script autentica sua fonte.
2. **Ambiente Git controlado:** corrigir a sonda/camada invocadora para não herdar configurações ou traces Git não autorizados (`GIT_CONFIG_*`, `GIT_TRACE*`, além dos redirecionamentos já tratados). Garantir que as três consultas continuem somente leitura, com `--no-optional-locks`, sem alterar configuração persistente nem mascarar falhas. Registrar a política exata do ambiente filho.
3. **Custódia de evidências:** entregar roteiro externo ainda não executado para captura verificável, em local novo fora de Git, da saída, erros, horários com fuso, hashes, versão, transformação bruto→normalizado→sanitizado e responsável definido antes da execução. Separar captura de evidência da sonda somente leitura. Não criar nenhuma área na preparação atual.
4. **Compatibilidade PowerShell 5.1:** relatar limitações ainda não verificadas. Não executar preflight sobre a candidata para demonstrar compatibilidade; se necessário, propor verificação isolada de parsing sujeita a autorização própria.

## Restrições obrigatórias

- Não executar preflight, pytest, `--collect-only`, testes nativos, DACL, symlink nem helpers de exclusão.
- Não alterar o repositório e a candidata R1-FIX (470 arquivos) ou os documentos originais; trabalhar apenas em cópia externa de preparação.
- Não alterar políticas, ACL, registro, Developer Mode, privilégios, contas ou tokens.
- Não importar o produto para preparar a sonda; não usar dados de clientes.
- Não considerar evidências de cleanup como prova dos 19 controles; manter `PROVISORIO_SEM_FONTE` e `NÃO_VALIDADO`.
- Não fazer commit, push, merge ou publicação; conversões reais continuam bloqueadas.

## Entrega

Roteiro Portão B atualizado; wrapper/sonda ajustados se necessário; protocolo de custódia; diff contra a entrega anterior; manifesto SHA-256 e critérios B01–B22 atualizados somente quando pertinente. Relatório separando análise estática, riscos residuais e precondições de execução. **Parar após entregar.**
