# NAO EXECUTADO. Verificar seu hash EXTERNAMENTE antes de invocar.
# A flag nao substitui a autorizacao posterior para captura e UMA execucao B.
param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Git,
    [Parameter(Mandatory=$true)][string]$Candidata,
    [Parameter(Mandatory=$true)][string]$AreaPrevista,
    [Parameter(Mandatory=$true)][string]$Evidencias,
    [Parameter(Mandatory=$true)][string]$AutorizacaoId,
    [string]$Custodiante = 'CUSTODIANTE_USUARIO',
    [switch]$PortaoBAutorizado
)
$ErrorActionPreference = 'Stop'
if (-not $PortaoBAutorizado) { throw 'AGUARDA_AUTORIZACAO_DE_CAPTURA_E_EXECUCAO_UNICA' }
if (@(Get-ChildItem Env: | Where-Object { $_.Name -like 'GIT_*' }).Count -gt 0) {
    throw 'GIT_VARIAVEL_HERDADA_NAO_AUTORIZADA_NAO_LIMPAR_GLOBALMENTE'
}
function Conferir-CaminhoSemReparse([string]$Caminho) {
    if (-not [IO.Path]::IsPathRooted($Caminho)) { throw 'CAMINHO_DEVE_SER_ABSOLUTO' }
    $Atual = [IO.Path]::GetFullPath($Caminho)
    while ($Atual) {
        $Item = Get-Item -LiteralPath $Atual -Force
        if (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'REPARSE_RECUSADO' }
        $Pai = [IO.Path]::GetDirectoryName($Atual)
        if ($Pai -eq $Atual) { break }
        $Atual = $Pai
    }
}
$LocalWIN19 = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::LocalApplicationData)
$PreparacaoEsperada = Join-Path $LocalWIN19 'WIN19-Portao-B-Ajustes\preparacao'
$CandidataEsperada = Join-Path $LocalWIN19 'E4-R1-FIX\candidata-lf-v2'
if (-not [string]::Equals($PSScriptRoot, $PreparacaoEsperada, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'PASTA_PREPARACAO_DIFERENTE_DO_ESCOPO_REVISADO'
}
if (-not [string]::Equals([IO.Path]::GetFullPath($Candidata), $CandidataEsperada, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'CANDIDATA_DIFERENTE_DA_EXISTENTE_REVISADA'
}
Conferir-CaminhoSemReparse $PSScriptRoot
Conferir-CaminhoSemReparse $Python
Conferir-CaminhoSemReparse $Git
Conferir-CaminhoSemReparse $Candidata
# O manifesto foi pinado pelo procedimento EXTERNO. Este bloco apenas confere
# materiais/extras; nao autentica sua propria fonte nem substitui a pinagem externa.
$ManifestoPath = Join-Path $PSScriptRoot 'MANIFESTO_PORTAO_B_SHA256.json'
Conferir-CaminhoSemReparse $ManifestoPath
$Manifesto = ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($ManifestoPath))
$Permitidos = @{}
$DiretoriosPermitidos = @{}
foreach ($Prop in $Manifesto.arquivos.PSObject.Properties) {
    $Permitidos[$Prop.Name] = $Prop.Value
    $Partes = $Prop.Name.Split('/')
    for ($I = 1; $I -lt $Partes.Length; $I++) {
        $DiretoriosPermitidos[([string]::Join('/', $Partes[0..($I - 1)]))] = $true
    }
}
$Encontrados = @{}
$Pastas = New-Object 'System.Collections.Generic.Stack[string]'
$Pastas.Push($PSScriptRoot)
$Executaveis = @('COMANDO_PORTAO_B_NAO_EXECUTADO.ps1', 'tools/preflight_win19.py',
    'tools/preflight_win19.ps1', 'tools/custodia_portao_b.py')
while ($Pastas.Count -gt 0) {
    $Pasta = $Pastas.Pop()
    foreach ($Item in @(Get-ChildItem -LiteralPath $Pasta -Force)) {
        if (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'MATERIAL_REPARSE_RECUSADO' }
        $Rel = $Item.FullName.Substring($PSScriptRoot.Length + 1).Replace('\', '/')
        if ($Item.PSIsContainer) {
            if (-not $DiretoriosPermitidos.ContainsKey($Rel)) { throw 'DIRETORIO_EXTRA_PRESERVAR' }
            $Pastas.Push($Item.FullName); continue
        }
        if ($Rel -eq 'MANIFESTO_PORTAO_B_SHA256.json') { continue }
        if (-not $Permitidos.ContainsKey($Rel)) { throw 'MATERIAL_EXTRA_PRESERVAR' }
        if ($Item.Extension -in @('.py','.ps1','.psm1','.psd1','.exe','.dll','.pyd','.cmd','.bat','.sh') -and
                $Rel -notin $Executaveis) { throw 'ESCOPO_EXECUTAVEL_INESPERADO' }
        if ($Item.Length -ne $Permitidos[$Rel].bytes -or
                (Get-FileHash -LiteralPath $Item.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Permitidos[$Rel].sha256) {
            throw 'HASH_OU_TAMANHO_PREPARACAO_DIVERGENTE'
        }
        $Encontrados[$Rel] = $true
    }
}
if ($Encontrados.Count -ne $Permitidos.Count) { throw 'MATERIAL_AUSENTE_PRESERVAR' }
$Pins = @{
    'tools/preflight_win19.py' = '8c17b2ed2dc08fae2ba1083da272cf3515081fdd69a50818e34fcfbc9d941f3a'
    'tools/preflight_win19.ps1' = '144806b8a84ae115f49448f3b4ad02293a300a11471347fc68272bb720e9b1c0'
    'tools/custodia_portao_b.py' = '3986fb30a9194d406cf1533d4a6098a41f9245a6c9925405246c0d8cb00684e4'
    'REFERENCIA_R1_FIX_470_SHA256.json' = 'a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c'
}
foreach ($Nome in $Pins.Keys) {
    if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $Nome) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Pins[$Nome]) {
        throw 'SUBCOMPONENTE_DIVERGENTE'
    }
}
$Capturador = Join-Path $PSScriptRoot 'tools\custodia_portao_b.py'
& $Python -I -S -B -X utf8 $Capturador --preparacao $PSScriptRoot --candidata $Candidata --git $Git `
    --area-prevista $AreaPrevista --evidencias $Evidencias --custodiante $Custodiante `
    --autorizacao-id $AutorizacaoId --autorizar-captura-e-uma-execucao
if ($LASTEXITCODE -ne 0) { throw 'CAPTURA_OU_SONDA_BLOQUEADA_PRESERVAR_SEM_REPETIR' }
Write-Host 'CAPTURA_ENCERRADA_PARA_REVISAO; NAO_E_HOMOLOGACAO; C/D/E BLOQUEADOS.'
