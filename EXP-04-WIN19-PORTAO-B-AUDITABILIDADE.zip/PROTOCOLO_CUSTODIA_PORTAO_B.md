# Custódia durável externa — proposta NÃO EXECUTADA

## Responsável e autorização antes da única coleta

Responsável designado nesta proposta: USUÁRIO SOLICITANTE, rótulo
CUSTODIANTE_USUARIO. Não há conta nova, token novo ou mensagem externa. O usuário
precisa aceitar formalmente o papel, retenção/destino e procedimento antes da
execução. Se outro responsável assumir, atualizar o rótulo e aprovar o vínculo
em registro privado. Não usar A_DESIGNAR ou PENDENTE para iniciar.

A decisão futura deve autorizar explicitamente: (1) captura/gravação na área
nova de custódia; (2) UMA execução da sonda B. Registrar AutorizacaoId textual
vinculado a essa decisão, nunca criar ID para fingir aprovação. A flag é trava,
não consentimento. Nesta tarefa não existe autorização para executar nada disso.

## Separação de componentes

A SONDA tools/preflight_win19.py permanece somente leitura, emite JSON/stdout
e não cria área, log, temporário, JUnit ou ACL. O WRAPPER da sonda é compatível
por intenção, mas não é o caminho recomendado para captura textual.

O CAPTURADOR tools/custodia_portao_b.py é EXTERNO. Sua única escrita futura é
na própria área de evidências nova. Executa a sonda Python diretamente em outro
processo, com -I -S -B -X utf8, em vez de redirecionar texto no PowerShell.
Nenhum módulo da aplicação/sonda é importado. Não é runner dos21 casos C.

Área futura: %LOCALAPPDATA%\WIN19-CUSTODIA-<GUID>, NOVA, filha direta de LocalAppData,
fora de Git/documentos/candidatas. Nunca reutilizar área, nem apagar/resolver
link ou acessar o residual antigo. A área WIN19-B-<GUID> prevista para ensaios
permanece inexistente: não se confunde com a área de custódia.

A entrada verifica hashes/materiais e recusa ambiente Git herdado. O capturador
repete precondições, verifica caminhos/ancestrais/manifestos, recusa área existente
e sobreposição e usa mkdir padrão herdado (sem chmod/Set-Acl/alterar herança).
Área própria recebe identidade dev/inode e é reconferida antes de cada gravação.
Não prometer DACL de proteção: política continua não aprovada. Ambiente exclusivo,
sem mudança concorrente, precisa de aprovação. A abordagem por caminho não prova
resistência a um atacante com mesmo token; não é helper de exclusão nativa.

## Ordem, formato e persistência

1. Criar só a área nova APÓS autorização; criação exclusiva. Não remover nada.
2. Escrever inicio_privado.json com criação exclusiva, escrita completa, fsync e
   releitura correspondente ANTES de lançar a sonda. Responsável, AutorizacaoId,
   horários UTC e local com offset, candidata/área prevista (privados), Python,
   hashes dos scripts/executável/manifesto. Se falhar, não iniciar a sonda.
3. Abrir stdout_bruto.bin e stderr_bruto.bin com criação exclusiva e modo binário.
   O subprocesso escreve diretamente nesses handles; sem pipeline, decodificação
   ou normalização do PowerShell. Após término/erro, fsync e SHA/tamanho dos brutos.
   Nada de saída privada é impresso no chat por esse caminho.
4. Preservar os brutos ANTES de parsing/classificação. stdout deve ser JSON UTF-8
   estrito e limitado a1MiB. Normalização: parse/dump sort_keys=True, indent2,
   ensure_ascii, LF final, UTF-8 sem BOM -> json_normalizado_privado.json.
5. Criar relatorio_sanitizado.json por lista positiva de campos tipados/códigos;
   nunca copiar stderr, caminhos, comando, payload/credenciais/SID. Campo novo ou
   inesperado não é aceito silenciosamente. Comparar tamanhos/hashes por arquivo.
6. Sempre tentar fim_privado.json e cadeia_sha256.json em finally, inclusive em
   falha/timeout/interrupção. Cadeia inclui raw, normalizado, sanitizado, início/fim,
   hash/tamanho, transformação e responsável; exclui a si própria. O SHA da cadeia
   é registrado separadamente pelo custodiante quando transferi-la.
7. Se parsing, fsync, escrita, comparação, captura ou recibo final falhar, estado
   BLOQUEADO; preservar área inteira. Não remover brutos, tentar novamente na
   mesma área ou transformar ausência de relatório em sucesso.

Limite180s: subprocess.run encerra e aguarda SEU filho direto em timeout. Não
prova encerramento de todos os descendentes Git. Registrar integridade final e
descendentes NÃO_COMPROVADOS, preservar evidências e parar; não reiniciar coleta.
Interrupção/morte abrupta/falta de energia pode impedir recibo final; o início e
brutos já gravados devem ser preservados como parciais, nunca como prova completa.
Se houver erro antes de inicializar custódia, a saída distingue tentativa de
criação de área de custódia inicializada; não presumir inexistência de resíduos.

Nenhuma prova empírica de durabilidade/PowerShell5.1 foi executada nesta tarefa.
fsync e releitura descrevem a intenção do código, não uma garantia de hardware.

## Retenção e partilha

Manter inicio/fim privados, stdout/stderr brutos e JSON normalizado fora de Git,
sem publicação automática. Podem conter caminhos e erros operacionais privados.
Compartilhar SOMENTE cópia sanitizada revisada + cadeia de hashes e metadados
permitidos; nunca enviar a raiz inteira por conveniência. Evidência de ausência
não é evidência de negação de acesso. Custódia não homologa DACL, Windows ou WIN19.
O prazo de retenção e descarte posterior precisa de decisão do custodiante;
nesta preparação nenhum arquivo de evidência ou laboratório foi criado/excluído.

## Adendo de auditabilidade V2

Compartilhar relatorio_sanitizado.json com schema_version V2, diagnóstico de
completude e metadados seguros custodia_publica (início, fim da derivação e hashes).
Seguir AUDITABILIDADE_SANITIZACAO_V2.md e MAPA_CRITERIOS_RELATORIO_V2.csv. Campos
extras/tipos inválidos reprovam; parcial é bloqueada. Não encaminhar nomes/valores
de chaves desconhecidas. Brutos/normalizado/início-fim privados permanecem locais.
A cadeia e a pinagem externa acompanham a cópia sanitizada revisada; horários de
derivação não substituem recibo final de custódia. Nenhum passo foi executado.
