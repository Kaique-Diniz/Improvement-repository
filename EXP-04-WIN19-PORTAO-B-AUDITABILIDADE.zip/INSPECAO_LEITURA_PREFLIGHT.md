# Separação estática das operações — ajustes Portão B

A SONDA não tem mkdir/write/unlink/replace/rmtree, não grava log/temporário/JUnit,
não importa o produto ou pytest e não configura ACL/conta/privilégio. Usa lstat,
read_bytes/listagem/hashes470, Git somente local com env positivo e opções read-only,
consultas de token/volume/alias/registro e finally de integridade. Git global e
sistema são suprimidos só no ambiente do filho. Local não é ignorado: é lido e
recusado se não previsto. Não gerar traces por herança; toda GIT_* herdada bloqueia.

ENTRADA confirma root/material/hash; não autentica a si própria. Sua confiança
vem da verificação EXTERNA antes de invocar. Não muda configurações persistentes.
A cópia Python da sonda é executada diretamente pelo capturador, não importada.
O wrapper da sonda permanece documentado, mas não serve de capturador textual.

CAPTURADOR EXTERNO é o único componente que futuramente escreve: mkdir de UMA
área própria nova, arquivos xb, escrita completa/fsync/releitura e metadados.
Não confundir essa autorização futura de custódia com a natureza somente leitura
da SONDA. Nenhuma área Windows/captura foi criada nesta tarefa.

Somente inspeção AST/sintaxe em memória, JSON/CSV e hashes de preparação; sem
preflight/Linux/Windows, subprocesso da sonda, parsing PS5.1, pytest ou experimento.
GetLastError é capturado na sonda após API; erros Git/timeout/custódia bloqueiam
sem imprimir str(OSError), comando ou caminhos. Não mascarar erro operacional.

Limites: metadados/arquivo por caminho não são locks antissubstituição; exigir
laboratório e configuração estáveis. Não é prova DACL/TOCTOU/privacidade contra
o mesmo token. Escritas do SO/cache/atime não são uma garantia forense desta análise.
PowerShell5.1, processo/handles redirecionados, fsync e durabilidade real não foram
comprovados. Parsing isolado de cópias pode ser proposto com autorização separada;
nenhuma avaliação executável de script é autorizada agora.
