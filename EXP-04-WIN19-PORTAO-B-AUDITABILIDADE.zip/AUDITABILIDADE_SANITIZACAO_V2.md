# Contrato de compartilhamento V2 — não executado

O schema_version WIN19_B_SANITIZADO_V2 versiona o DERIVADO, não altera a sonda.
CONTRATO_SANITIZACAO_V2.json é dicionário extraído por AST/literais do código;
ESQUEMA_SANITIZADO_PORTAO_B_V2.json é esquema auxiliar de intercâmbio. A função
sanitizar é normativa para tipos exatos, sem converter bool/int/float/string.
JSON Schema integer isoladamente não distingue todos os lexemas1/1.0; o código
Python rejeita float mesmo integral. Nenhum validador/função foi executado aqui.

A cópia compartilhável inclui python3.12.x exato, win32, windows_build com três
inteiros, booleanos externos/área/sobreposição, FS e capacidades da raiz/volume
candidata, contagem de configsGit e demais campos tipados produzidos pela sonda.
Volume aceita SOMENTE sistema_arquivos, persistent_acls_suportadas,
reparse_suportado e hardlinks_suportados. Build aceita SOMENTE major/minor/build.
Sem caminho, serial, conta, SID, SDDL, hostname, conteúdo, stdout/stderr ou config.

Três classificações internas, sem aprovação automática:
- COMPLETO_ESTRUTURALMENTE: todos os campos de sucesso tipados e invariantes;
  não equivale a APROVADO, segurança nativa ou aceiteB01–B22.
- PARCIAL_BLOQUEADO: núcleo válido, código seguro, estadoBLOQUEADO/coleta=false;
  enumera campos completos ausentes sem fabricá-los; captura retorna bloqueio.
- REPROVADO: esquema/tipo/invariante inesperado, núcleo ausente, completa com
  campo faltante ou qualquer chave extra. Derivado só conserva dados conhecidos
  tipados e diagnóstico seguro; captura retorna bloqueio, brutos ficam privados.

campos_invalidos e listas de ausência contêm só nomes do contrato conhecido.
Chaves inesperadas (raiz/build/volume) são contadas, SEM nomes nem valores.
Campo desconhecido não desaparece silenciosamente e nunca permite saída de sucesso.
Não transmitir valor inválido de tipo/formato. Campo conhecido tipado que viola
invariante pode permanecer para permitir auditoria, mas classifica REPROVADO.

A camada de custódia acrescenta horário de início e de DERIVAÇÃO, com UTC/fuso,
IDs aprovados e SHA/tamanho de raw/normalizado. Isso não divulga o conteúdo dessas
fontes e não representa término de todo o finally/fechamento da custódia. Esse fim
fica no recibo/chain do protocolo, com revisão/atesto do custodiante. Os brutos e
o normalizado continuam privados. Se não existir JSON íntegro (timeout/crash),
ausência do sanitizado deve ser registrada como bloqueio, não inventar um relatório.

MAPA_CRITERIOS_RELATORIO_V2.csv distingue campos compartilháveis de evidência
EXTERNA: B01 precisa da pinagem/verificador fora do ZIP e B21 da cadeia/aceite do
custodiante. Nenhuma cópia JSON sozinha prova sua origem, 470 arquivos físicos ou
aprovação do Windows. Não exigir encaminhar caminho/valores privados para esses itens.
