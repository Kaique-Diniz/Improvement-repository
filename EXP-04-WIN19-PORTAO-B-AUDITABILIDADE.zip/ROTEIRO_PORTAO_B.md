# Portão B — ajustes de preparação, PARE PARA REVISÃO

Esta entrega não autoriza preflight, pytest/coleta, Windows/DACL, criação de
laboratório ou captura. Não executar os scripts/blocos agora. Fonte principal:
INSTRUCOES_CODEX_WIN19_PORTAO_B_AJUSTES.md; fundamentação no parecer anexo.

## Identidade preservada e caminhos

Pacote B auditado: EXP-04-WIN19-R2-PORTAO-B.zip,91.674bytes,22entradas,
SHA69fdfff9316259012c7ed104bb676720d883553864aebc3084b220ed2cd95741.
Entrada original977e04e3fe3504128e755db13b8eedc894de086cb8ac6ee1fc5e73a06cded25b.
Ambos intactos. Os novos hashes estão no manifesto ajustado e na entrega EXTERNA.

Candidata Windows existente informada pelo usuário:
%LOCALAPPDATA%\E4-R1-FIX\candidata-lf-v2. Não reconstruir, corrigir ou copiar.
Referência470 SHAa3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c,
base770d062d29c4361d6932592883df9339bb4089bc. HEAD não substitui todos os hashes.
O caminho foi confirmado textualmente; nada foi verificado no Windows nesta tarefa.

Nova preparação FUTURA, separada de todas as pastas anteriores:
%LOCALAPPDATA%\WIN19-Portao-B-Ajustes\preparacao. A entrada recusa outra pasta.
ZIP fica FORA dessa pasta; não extrair sobre R2/B existente. Extração manual é
separada da sonda. Escopo executável estrito de quatro arquivos, listado na raiz
de confiança externa; materiais/diretórios extras ou reparse bloqueiam.

Python sugerido, ainda a confirmar no Windows:
%LOCALAPPDATA%\WIN01D-Auditoria\venv\Scripts\python.exe, versão3.12.
Git sugerido: %ProgramFiles%\Git\cmd\git.exe; confirmar instalação confiável,
caminho e SHA do binário em revisão. Não instalar dependências ou ferramentas.
Área prevista inexistente: LocalAppData\WIN19-B-<GUID>.
Área de custódia NOVA: LocalAppData\WIN19-CUSTODIA-<GUID>.
Nenhuma dessas áreas Windows foi criada nesta preparação.

## Ordem futura, SEM EXECUÇÃO AGORA

1. Revisar RAIZ_CONFIANCA_EXTERNA.md. Conferir hashes recebidos fora do ZIP,
   primeiro ZIP ANTES de extrair e depois comando e manifesto extraídos ANTES
   de invocar. O verificador externo concreto é entregue ao lado do ZIP e nunca
   chama scripts nem cria arquivos. Conferir seu SHA independentemente antes.
2. Aceitar responsável CUSTODIANTE_USUARIO, destino/retenção e PROTOCOLO_CUSTODIA_PORTAO_B.md.
   Aprovar captura/gravação e UMA execução B, com identificador ligado à decisão.
   Sem essa decisão, parar. Não usar a flag como autorização implícita.
3. Confirmar precondições: PowerShell comum, caminhos regulares e existentes,
   binários confiáveis, preparação/hash/escopo exatos, nenhuma variável GIT_*
   herdada, metadados Git estáveis, áreas novas. Não alterar env global, ACL,
   privilégios, Developer Mode, contas, tokens, ExecutionPolicy ou Git persistente.
4. Somente após nova autorização, revisar e usar o bloco abaixo. A entrada
   verifica inventário e chama o capturador; este lança a sonda em processo
   isolado e grava evidência em pasta própria. A sonda continua somente leitura.

```powershell
# NAO EXECUTADO. Este bloco permanece BLOQUEADO ate autorizacao especifica.
$ErrorActionPreference = 'Stop'
$LocalWIN19 = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::LocalApplicationData)
$Preparacao = Join-Path $LocalWIN19 'WIN19-Portao-B-Ajustes\preparacao'
$Python = Join-Path $LocalWIN19 'WIN01D-Auditoria\venv\Scripts\python.exe'
$Git = Join-Path $env:ProgramFiles 'Git\cmd\git.exe'
$Candidata = Join-Path $LocalWIN19 'E4-R1-FIX\candidata-lf-v2'
$AreaPrevista = Join-Path $LocalWIN19 ('WIN19-B-' + [guid]::NewGuid().ToString('N'))
$Evidencias = Join-Path $LocalWIN19 ('WIN19-CUSTODIA-' + [guid]::NewGuid().ToString('N'))
# Preencher com identificador da DECISAO aprovada, nao inventar aprovacao.
$AutorizacaoId = 'PENDENTE'
if ($AutorizacaoId -eq 'PENDENTE') { throw 'SEM_AUTORIZACAO_POSTERIOR' }
& (Join-Path $Preparacao 'COMANDO_PORTAO_B_NAO_EXECUTADO.ps1') `
    -Python $Python -Git $Git -Candidata $Candidata -AreaPrevista $AreaPrevista `
    -Evidencias $Evidencias -AutorizacaoId $AutorizacaoId -Custodiante 'CUSTODIANTE_USUARIO' -PortaoBAutorizado
```

Não invocar a sonda/wrapper diretamente para contornar a custódia. Não rodar
pytest ou os21 casos C. Comando e capturador são propostos, não validados no5.1.

## Aceite documental da saída futura

Ver CRITERIOS_ACEITACAO_PORTAO_B.csv, mantendo B01–B22. Exigir470 antes/depois,
HEAD/raiz corretos, Python3.12 -I -S -B -Xutf8, token não elevado, área prevista
nova, volume real/NTFS, inventário de alias/privilégio e ambiente Git controlado.
Os três Git locais usam env explícito, sem autenticação/traces; política exata
em POLITICA_AMBIENTE_GIT.md. Configuração local desconhecida bloqueia, sem editar.

Sonda0 = coleta concluída, NUNCA prontidão. Captura0 = encerrada para REVISÃO,
NUNCA aceite automático de todos os22 critérios ou homologação. Exigir provas de
custódia/horários/fuso/SHA/transformações, sem promover campos ausentes de modelo.
Falha/timeout/JSON inválido/custódia parcial/hashes divergentes: preservar e parar.
Ausência de alias8.3 ou privilégio symlink mantém subcontrole NÃO_VALIDADO;
1314 nunca é PASS. Ramo de erro real WIN03 segue não demonstrado.

B-R4: nenhuma execução/parsing PowerShell5.1 ocorreu. Se necessário, solicitar
autorização separada para APENAS parsing de cópias numa sandbox sintética, com
System.Management.Automation.Language.Parser.ParseFile e inspeção dos erros;
NUNCA &/dot-source/Invoke-Expression, nem sonda/candidata. Isso não foi executado
nem constitui aprovação de comportamento nativo, fluxo de captura ou segurança.

Custódia em disco é distinta da sonda somente leitura e exige aprovação prévia.
Campos/mensagens brutos podem ser privados: não publicar pacote de evidências
sem sanitização/revisão próprias. O runner de evidências C continua inexistente.
19 vínculos PROVISORIO_SEM_FONTE, DACL PARA_APROVAÇÃO/NÃO_VALIDADO, C/D/E e conversões
reais BLOQUEADOS. Parar para revisão; sem commit/push/merge/publicação nesta etapa.

## Revisão atual: auditabilidade V2

A sonda/wrapper e seu ambiente Git foram preservados byte a byte. Só o capturador
e o hash desse subcomponente na entrada mudaram. O esquema V2 e o mapa B01–B22
passam a reger a cópia compartilhável. Completa estrutural não é homologação;
parcial/reprovada bloqueiam o retorno do capturador. Ver protocolo atualizado.

O caminho fixo de preparação continua o já revisado; se ele já existir, preservar
e parar para revisar outro destino versionado. Não sobrescrever extrações antigas.
O verificador EXTERNO e a lista de hashes concretos desta revisão são arquivos
separados ao lado do ZIP e precisam ser enviados ao auditor, não só mencionados.
Seu SHA vem também no registro externo da entrega. Nenhum script se autentica.
PLANO_PARSE_PS51_NAO_EXECUTADO.md prepara parsing de cópias textuais, sem invocação
e sujeito a autorização própria; não foi executado. Primeira coleta B continua
sem autorização, C/D/E e conversões reais bloqueados. Sem publicação nesta etapa.
