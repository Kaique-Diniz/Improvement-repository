# Pinagem EXTERNA — antes de invocar qualquer comando do pacote

Esta preparação não se autentica a si própria. A raiz de confiança é o conjunto
ZIP SHA-256 + comando SHA-256 + manifesto SHA-256 recebido e revisado POR FORA
do ZIP (mensagem de entrega/registro independente). HASHES_PREFLIGHT_PORTAO_B.json
é inventário, não raiz de confiança. Não calcular um hash e confiar nele só
porque o mesmo pacote o informou.

O comando ORIGINAL auditado no Portão B tinha SHA-256
977e04e3fe3504128e755db13b8eedc894de086cb8ac6ee1fc5e73a06cded25b.
Ele foi preservado; a cópia ajustada tem outro hash, informado na entrega externa.

Procedimento FUTURO, NÃO EXECUTADO:

1. Registrar os hashes externos aprovados em canal independente do download.
   Conferir primeiro o ZIP por Get-FileHash -Algorithm SHA256, antes da extração.
   Divergência bloqueia, sem renomear/substituir o original para fazê-lo coincidir.
2. Extrair manualmente em destino NOVO e vazio aprovado, nunca sobre a pasta B/R2
   anterior. Destino fixado nesta revisão:
   %LOCALAPPDATA%\WIN19-Portao-B-Ajustes\preparacao.
   A extração é etapa manual separada; nada é extraído/executado nesta tarefa.
3. Conferir novamente o ZIP e verificar o arquivo já extraído
   COMANDO_PORTAO_B_NAO_EXECUTADO.ps1 pelo SHA EXTERNO, ANTES de invocá-lo.
   Conferir também o SHA EXTERNO de MANIFESTO_PORTAO_B_SHA256.json. Não aceitar
   hashes alternativos obtidos do próprio arquivo potencialmente adulterado.
4. O verificador externo fornecido AO LADO do ZIP não invoca comando, sonda ou
   capturador, não extrai e não cria arquivo. Ele contém os hashes concretos
   finais. Seu próprio SHA também vem na mensagem de entrega. Inspecioná-lo e
   conferir seu SHA por um Get-FileHash digitado separadamente antes de usá-lo;
   não supor confiança por estar fora do ZIP.
5. Rejeitar links/reparse, materiais ausentes/extras e executáveis fora da lista:
   COMANDO_PORTAO_B_NAO_EXECUTADO.ps1, tools/preflight_win19.py,
   tools/preflight_win19.ps1, tools/custodia_portao_b.py. A entrada fixa a pasta,
   percorre diretórios sem seguir reparse e verifica inventário/tamanhos/hashes,
   inclusive diretórios extras. O manifesto confiável lista o material esperado.
6. Repetir a conferência externa imediatamente antes da única invocação aprovada.
   Manter a preparação e os metadados Git sem alterações concorrentes. Essas
   leituras não são pinagem por handle nem prova contra atacante com mesmo token.
7. Só após autorização específica da captura/custódia E uma execução B, invocar
   o comando revisado. Flag e AutorizacaoId são travas/identificação documental,
   não prova de aprovação. Ausência de decisão expressa mantém B bloqueado.

O ZIP não contém seu próprio hash final nem o verificador que o referencia,
para evitar autorreferência. Ambos os hashes concretos são entregues fora dele.
