# H3-O-D5 — preparação da deliberação expressa

27/11/2026 — America/Sao_Paulo. Preparação documental de deliberação; nenhuma autorização de desenvolvimento, importação, teste ou execução.

## Escopo e conclusão

H3_O_D5_INSTRUMENTO_PREPARADO_AGUARDANDO_AUDITORIA.
A instrução atual autoriza só pedido/plano documental. O parecer D4 é fundamento,
não ato de desenvolvimento ou autorização operacional. Nenhum arquivo candidato
foi criado. Somente 14 documentos novos, cinco CSVs e oito Markdown mais manifesto.

## Dez respostas de entrega

1. Unidades iniciais: U01 recepção D, U02 modelo passivo E, U03 representação F e
   U04 interfaces A/B podem ser submetidas separadamente à análise inicial.
   U01–U07 preservadas, 28 opções APROVAR/AJUSTAR/REJEITAR/ADIAR sem marcação.
2. Arquivos físicos candidatos: duas alternativas separadas (PY sete, CS oito),
   descritas abaixo e no inventário com tipo/tecnologia/dependências/dados/
   interfaces/proibições/revisão/unidade/estado. Nenhuma está escolhida ou criada.
3. Área/base: BT01 nova área isolada externa ao Git/custódia recomendável para análise;
   BT02 checkout/worktree futuro expressamente designado; BT03 área de base
   exportada por ato próprio. Raiz/área/base/repositório reais não decididos.
   Especificações históricas são leitura, não código autorizado para editar.
4. Operações candidatas futuras: criar só arquivos novos aprovados, editar só eles,
   documentar, gerar diff/manifesto e submeter à revisão. Cinco candidatas e
   23 exclusões na matriz, nenhuma permissão concedida. Sem importação, testes,
   mocks/fixtures, build, Git ou publicação por implicação.
5. Antes de desenvolver: ato legítimo, tecnologia/estrutura/lista fechada/base/raiz/
   autoridade/validade/limites/dependências/dados e contrato mínimo. Parcelas de
   Q01/Q02/Q03/Q09/Q10/Q12 são bloqueadoras. Nenhuma decisão foi tomada.
6. Posteriores: valores/mecanismos/provas reais de duração, fechamento, identidade/
   confinamento, L-D06/efetividade e WMI podem permanecer para testes/observação
   pertinentes, sem bloquear a simples escrita de modelos passivos legitimamente
   delimitados. Q04/Q05/Q06/Q07/Q08/Q11 não foram encerradas. Detalhes só podem
   ser escolhidos durante projeto se houver delegação expressa; nenhuma concedida.
7. U05/U06 separadas: núcleo não deve invocar/modificar C nem implementar confinamento/
   DACL/handles ou aceitar R03/R07. Necessidade de leitura fora do escopo/proteção
   insuficiente mantém P5 bloqueado até solução própria revisada e comprovada.
8. Critérios definidos: lista/raiz/base/bytes correspondentes, ausência de efeito
   ativo/privado fora do escopo, 14 M-C/7 estados conservadores e preservação de
   adversos/limites; 12 condições objetivas de suspensão. São requisitos futuros,
   não controles implementados ou resultado de testes.
9. Custodiante/autoridade ainda deliberam unidades, variante física, área/base/
   arquivos/operações/dependências/delegações/papéis/validade e ato legítimo.
   G09/G10 não comprovados e L-D06 pendente em frente privada independente;
   não se solicitam caminhos, identidades ou material privado ao Codex.
10. Não há fonte essencial ausente/divergente que impeça preparar este instrumento.
    As ressalvas independentes dos dois Textos colados continuam abertas; não são
    resolvidas pela conferência local nem tratadas como autorização/integridade
    institucional. Todos os bloqueios operacionais permanecem.

## Alternativas físicas propostas, sem criação

PY — Python 3.12/biblioteca padrão como proposta recomendável à análise inicial,
menor infraestrutura de compilação; não compatibilidade validada nem escolha:
alternativa_python/origem.py, alternativa_python/contexto.py, alternativa_python/recepcao.py, alternativa_python/eventos.py, alternativa_python/registro.py, alternativa_python/contratos.py, alternativa_python/LEIA-ME.md.

CS — C#/.NET, alvo/SDK/BCL/JSON ainda a escolher; biblioteca separada, sem integração
PowerShell, com maior requisito de build/auditoria e nenhuma instalação:
alternativa_csharp/Origem.cs, alternativa_csharp/Contexto.cs, alternativa_csharp/Recepcao.cs, alternativa_csharp/Eventos.cs, alternativa_csharp/Registro.cs, alternativa_csharp/Contratos.cs, alternativa_csharp/LEIA-ME.md, alternativa_csharp/Nucleo.csproj.

Todos os caminhos são relativos a RAIZ_A_AUTORIZAR; nenhuma localização real,
configuração operacional ou arquivo de fonte/projeto foi materializado.
Se a autoridade escolher subconjunto, deve fechar dependências/lista coerentes,
sem combinar árvores ou criar arquivos extras silenciosamente.

## Preservação de escopo

11 classificações L-D02 não reabertas; L-D01=A. Quinze tratamentos 6/6/2/1 mantidos;
12 questões técnicas não escolhidas/aprovadas/implementadas/validadas;
14 M-C não adotados/implementados; sete estados sem aprovação automática;
nove riscos abertos, R03/R07 ALTA; 15 N02–N04 não verificados e V01–V10 sem
execução funcional. N01 aplica-se só aos antigos bytes R1.
Os 195 valores históricos de runtime estão preservados no documento de portões.

P1 auditoria estática após implementação autorizada, P2 contrato, P3 nativo,
P4 segurança, P5 observação e P6 destino/custódia exigem atos próprios.
Nem autorizar desenvolvimento ou U07 inicia P1–P6. E passivo não resolve timeout
global/fechamento real; classificador não autentica execução ou aprova destino.

## Integridade e limites

Manifesto D4:
aacc8909b4c3617d5be0b46ee69b1f089fcf2b478149f5d2b29fcb60183c4737.
Parecer D4: 15.118 bytes,
3bcaa3721cd0d1433d283cbd7d522e88b1c855c6c3c10af95e3a737e3f926f5c.
O índice identifica 109 objetos conferidos localmente e preservados em bytes:
nove manifestos/91 documentos, seis entradas de instrução/parecer, três ZIPs anteriores.
Não é autenticação independente do executor, das worktrees ou do host do usuário.

Parecer D4 conferiu independentemente 90/92 sem os bytes de duas instruções;
ressalva histórica D3-T 74/75 permanece. As entradas existem no executor e foram
conferidas localmente, sem retroagir ao alcance do auditor. Hashes não provam
autoria/autoridade/tempo forense. Quatro origens individuais L-D02 permanecem
conferência relatada do auditor, não autenticação própria de originais não recebidos.

Bloco R1: 20.362 bytes/383 LF, UTF-8 sem BOM,
af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5.
Somente texto; nenhum parser PowerShell, patch, importação ou execução.
Sem alteração da candidata, produção, fontes/ZIPs anteriores ou código.

## Política, não execução e parada

H3-E preservada: usuário como custodiante principal; coadministradores apenas com autorização específica. Alterações de acesso, movimentações e exclusões exigem autorização prévia específica. Assistência remota adiada/não autorizada. Retenção vinculada à H4, máximo inicial de 180 dias somente após futura cópia fiel aceita e verificada; revisões 60/120/180 e antecipada se H4 terminar; prorrogação expressa justificada e nenhuma exclusão automática. Nenhum marco/prazo/agenda iniciado. Validade operacional é decisão separada.

Python/biblioteca padrão apenas para documentos, CSV enquanto dados e hashes.
Sem criação de código/scripts/patches/fixtures/executáveis/configuração operacional,
sem import do conversor/candidatos, testes, Windows/PowerShell/WMI/ACL/DACL,
host privado/JUnit, inspeção, Git, ZIP, instalação, privilégio/política ou remoto.
Prontidão false, destino não aprovado e demais estados no documento de decisão.
Entregar para auditoria e parar, sem desenvolver ou iniciar P1–P6/H3-C/H3-S/H4.
