# H3-O-D5 — alternativas de base e área, sem escolha

27/11/2026 — America/Sao_Paulo. Preparação documental de deliberação; nenhuma autorização de desenvolvimento, importação, teste ou execução.

## Raiz e base ainda não autorizadas

RAIZ_A_AUTORIZAR é referência abstrata, não caminho escolhido/existente.
O inventário candidato contém somente caminhos relativos. Não pressupõe src do
conversor, repositório atual, worktree R1-FIX ou pasta de custódia.
Nenhuma área abaixo é criada, inspecionada, clonada ou aprovada nesta etapa.

| Alternativa | Natureza da área | Acesso a repositório | Base documental/de código | Dependências externas | Fontes a ler / fontes intocáveis | Risco de mistura | Versionamento/auditoria | Critério de autorização |
|---|---|---|---|---|---|---|---|---|
| BT01 | Nova área de desenvolvimento isolada, externa ao Git e à custódia; recomendada para análise inicial | Desnecessário para fontes novas do núcleo | D4/D3-T autenticadas como especificações somente leitura; sem importar código do produto ou C | Toolchain da alternativa escolhida, ainda a aprovar; nenhuma instalação | Somente fontes textuais autorizadas; históricos/candidatas/ZIPs/produção não modificáveis | Reduz proximidade com árvore histórica, mas separação/raiz precisam legitimidade própria, não nome de pasta | Diff/manifesto dos novos bytes sem Git; registro de base e auditoria própria | Autoridade aprova raiz/base/lista fechada/tecnologia/validade/limites antes de criar |
| BT02 | Checkout/worktree isolado futuro em repositório expressamente designado | Necessário só se aprovado em ato adicional; nenhum repositório presumido | Revisão/commit exatos a autenticar no portão próprio e especificações documentais aceitas; sem aproveitar árvore histórica inteira por suposição | Git e toolchain aprovados separadamente, não autorizados por desenvolvimento | Lista explícita de fontes permitidas; não editar main/BPQ-04/candidatas/históricos | Maior chance de misturar não rastreados, caches, hooks ou artefatos privados | Requer auditoria de refs/estado e delimitação antes de qualquer Git; commit/push/publicação não concedidos | Novo ato precisa designar repo/revisão/operações Git/isolamento; não escolher caminho agora |
| BT03 | Área isolada futura a partir de base exportada explicitamente autorizada | Pode ser dispensado no desenvolvimento, mas exportação é ato separado | Conjunto fechado de arquivos/base e manifesto autenticados; não cópia automática do workspace | Fonte/exportação/toolchain pertinentes ainda a decidir | Somente itens expressamente autorizados; nenhuma cópia de XML/custódia ou fonte histórica para edição | Mistura de versões e inclusões ocultas se conjunto não for fechado | Manifesto da exportação e dos novos bytes, separando origem/código criado | Aprovar lista/origem/destino da base e permissão de exportação; não copiar/exportar nesta etapa |

BT01 é recomendação técnica de menor acesso necessário, não seleção do custodiante
nem evidência material de separação. A opção Git BT02 não é automaticamente
autorizada por qualquer unidade. Se a base não estiver fechada/autenticável, parar.

## Duas estruturas físicas candidatas

| Variante | Estrutura proposta | Justificativa e impacto | Decisões bloqueadoras antes de desenvolver |
|---|---|---|---|
| PY | alternativa_python com seis fontes .py e LEIA-ME.md, sete entradas AF-PY | Python 3.12/biblioteca padrão como proposta de menor infraestrutura, coerente com núcleo passivo; não implica importação/execução nem prova Windows | Escolher variante/contrato/lista de dependências/arquivos/raiz/base e atos; revisão estática sem importar |
| CS | alternativa_csharp com seis fontes .cs, LEIA-ME.md e Nucleo.csproj, oito AF-CS | C#/.NET propõe biblioteca de tipos explícitos; alvo/SDK e mecanismo JSON ainda não escolhidos; maior superfície de build/restore | Escolher alvo/SDK/dependências e limitar projeto a fontes da lista sem hooks/targets/restore; compilar requer ato próprio |

Recomendação para análise: PY pode reduzir dependências e infraestrutura para o
primeiro recorte passivo. Não é conclusão de compatibilidade nem escolha aprovada.
CS é alternativa separada, não portabilidade já demonstrada ou integração com
PowerShell 5.1. Não fixar target/framework silenciosamente.
As duas árvores não devem ser criadas juntas ou mescladas por padrão.
Nova estrutura/arquivo/configuração exige ajuste e nova lista legitimamente aprovada.

## Regras da base e proteção dos materiais anteriores

H3-F-R1 permanece somente referência textual (bloco de 20.362 bytes/383 LF,
af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5).
Nenhuma das alternativas inclui copiar/importar/carregar esse método como
dependência do núcleo. Não presumir uma branch/commit do projeto como base
autorizada apenas por existir no histórico.

Consultar documentos como referência não autoriza copiá-los para a raiz ou
modificá-los. Se futura base precisar cópia, ela entra em lista e ato separados.
Não incluir Git, varreduras, documentos privados ou snapshots de custódia para
“provar” a separação da área. O ato deve delimitar legitimamente a raiz e os
materiais permitidos sem expor valores privados no pacote compartilhável.

## Parada e estados

BASE_E_AREA=NAO_APROVADAS; ARTEFATOS_FISICOS=PROPOSTOS_NAO_CRIADOS.
Nenhum diretório alternativo, fonte de código, projeto, clone, branch ou worktree
foi criado. Indefinição/divergência de base, raiz, tecnologia ou autoridade
impede iniciar os novos arquivos dependentes. Modelos de deliberação não resolvem
materialmente G09/L-D06 nem desbloqueiam observação/custódia.
