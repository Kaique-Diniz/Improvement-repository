# H3-O-D5 — separação dos portões P1–P6

27/11/2026 — America/Sao_Paulo. Preparação documental de deliberação; nenhuma autorização de desenvolvimento, importação, teste ou execução.

## Autorizar escrever não é autorizar executar nem revisar em P1

Mesmo um futuro ato de desenvolvimento delimitado não se estende automaticamente
a P1–P6. Produzir documentação/diff/manifesto é operação candidata de desenvolvimento;
a auditoria independente de novos bytes P1 é etapa própria posterior, não execução
já concedida. U07 somente delibera a forma/limites do pedido de validação.

| Portão | Escopo e precondições de um pedido futuro | Evidência/limite | Estado atual |
|---|---|---|---|
| P1 | Auditoria estática de novos bytes após implementação expressamente autorizada, com ato de revisão próprio | Diff/lista/manifesto/limites; não demonstra runtime | NAO_INICIADO_NAO_AUTORIZADO_POR_ESTA_ETAPA |
| P2 | Validação do contrato externo, dados/ambiente legítimos e escopo próprios | 14 M-C/7 estados, falhas e incompletude; sem executar C por implicação | NAO_INICIADO_NAO_AUTORIZADO_POR_ESTA_ETAPA |
| P3 | Evidências nativas isoladas N02–N04 por autorização própria | Tipos/providers/semântica reais, não sintaxe antiga ou resultado de outra suíte | NAO_INICIADO_NAO_AUTORIZADO_POR_ESTA_ETAPA |
| P4 | Demonstração da segurança da própria observação, G09/L-D06 e R03/R07 | Prova legítima anterior à leitura; não executar C para se autoautorizar | NAO_INICIADO_NAO_AUTORIZADO_POR_ESTA_ETAPA |
| P5 | Eventual observação local sob novo ato operacional explícito e limitado | Fonte/escopo/ambiente/operador/validade e segurança aceitos; inconclusão não aprova destino | NAO_INICIADO_NAO_AUTORIZADO |
| P6 | Aprovação de destino e custódia em portões independentes | Origem/destino/proteção/bytes/parciais/responsabilidades e ato H3-C próprios | NAO_INICIADO_NAO_AUTORIZADO |


Os portões não formam sequência automática. Segurança/precondições dos próprios
ensaios devem existir antes deles; P4 da observação não legitima retrospectivamente
um teste ou captura não autorizados. Nenhum desses portões começou nesta etapa.

## Núcleo passivo versus garantias reais

A/B/D/E/F podem ser delimitados como fontes de código sem leitura autônoma do
host. Desenvolvê-los ou classificá-los documentalmente não demonstra G09/G10.
E passivo não impõe timeout global, observa processo ou encerra provider/COM/RPC.
D/F não autenticam origem/fatos nem aprovam destino. Integração real exigiria
desenho/ato próprios, sem alterar C ou herdar sua validação por inferência.

U05 permanece fora do pedido inicial; U06 em portão específico. R03/R07
potencialmente bloqueadores de P5 não são aceitos por adiamento. L-D06 continua
pendente, sete classes preservadas; falta de marcador não é prova de separação.

## Quinze dependências detalhadas preservadas

N02=6/N03=4/N04=5. Os treze campos históricos abaixo preservam os 195 valores da
fonte autenticada D3-T, também preservados na D4. Entidade HTML &#124; apenas
representa barra vertical em célula Markdown. Nada foi observado nativamente.
N01 diz respeito somente à sintaxe dos antigos bytes R1, não ao núcleo ou revisão
futuros. Novos bytes precisam identidade/manifesto e validações próprios.

### N02-01 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N02-01 |
| pendencia | H3G-N02 |
| severidade_historica | ALTA |
| linhas_r1 | B072–080 |
| dependencias | System.Management: ConnectionOptions/ManagementScope/EnumerationOptions/ObjectQuery/ManagementObjectSearcher |
| questao_aberta | Presença, construtores e resolução de assemblies/tipos |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Inventário/documentação legítimos podem ser examinados sem H3-F-R1 |
| evidencia_dependente_de_autorizacao_propria | Binding real exige escopo nativo próprio autorizado; não executado |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Resolução pertinente demonstrada com limites, sem instalação ou autoload presumido inofensivo.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N02-02 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N02-02 |
| pendencia | H3G-N02 |
| severidade_historica | ALTA |
| linhas_r1 | B027–039;B145–160 |
| dependencias | File.GetAttributes, Path.GetFullPath/Combine, DriveInfo |
| questao_aberta | Exceções/HResult, sobrecargas e comportamento no ambiente |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Contratos públicos e registros legítimos sem chamar o bloco |
| evidencia_dependente_de_autorizacao_propria | Comportamento do filesystem exige validação nativa separada |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Ausência só na condição contratada; demais erros não viram inexistência ou proteção.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N02-03 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N02-03 |
| pendencia | H3G-N02 |
| severidade_historica | ALTA |
| linhas_r1 | B058–064;B145–156 |
| dependencias | TrimEnd/Split com char; Equals/StartsWith OrdinalIgnoreCase; casts uint32/int |
| questao_aberta | Binding char[]/string e conversões/nulos |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Análise de assinaturas sem execução |
| evidencia_dependente_de_autorizacao_propria | Binder/casts reais precisam autorização nativa específica |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Tipos/limites coerentes e ambiguidade não aceita; comparação textual não apresentada como identidade física.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N02-04 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N02-04 |
| pendencia | H3G-N02 |
| severidade_historica | ALTA |
| linhas_r1 | B126–134 |
| dependencias | WindowsIdentity/WindowsPrincipal/GetCurrent/IsInRole/Dispose |
| questao_aberta | Resolução .NET Framework e contexto/token observável |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Documentação e legitimidade do ambiente em registro privado |
| evidencia_dependente_de_autorizacao_propria | Observação real do contexto/fechamento só em escopo autorizado |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Contexto relatado só no limite demonstrado, sem certificar isolamento ou autoridade institucional.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N02-05 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N02-05 |
| pendencia | H3G-N02 |
| severidade_historica | ALTA |
| linhas_r1 | B285–309 |
| dependencias | Directory.GetAccessControl, GetOwner/GetGroup/GetAccessRules, descritor binário, RawSecurityDescriptor |
| questao_aberta | Sobrecargas Access&#124;Owner&#124;Group, enumerações e propriedades |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Confronto documental sem ler ACL real |
| evidencia_dependente_de_autorizacao_propria | Leitura nativa e qualquer efetividade requerem autorizações distintas; não teste entre contas automático |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Sobrecargas/descritores observados coerentes; DACL efetiva continua separada e não validada.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N02-06 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N02-06 |
| pendencia | H3G-N02 |
| severidade_historica | ALTA |
| linhas_r1 | B081–109;B336–338 |
| dependencias | Get/MoveNext/Current/Dispose e WindowsIdentity.Dispose |
| questao_aberta | Existência/dispatch e falhas de encerramento |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Análise dos contratos e do fluxo textual |
| evidencia_dependente_de_autorizacao_propria | Fechamento/falhas requerem evidência nativa própria, sem invocar H3-F-R1 por consequência |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Falha original e descarte preservados; ausência de prova mantém encerramento não comprovado.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N03-01 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N03-01 |
| pendencia | H3G-N03 |
| severidade_historica | ALTA |
| linhas_r1 | B172–177 |
| dependencias | root\cimv2; Win32_LogicalDiskToPartition; DiskIndex |
| questao_aberta | Disponibilidade/associação, zero/um/vários/nulo e permissões |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Informação legítima de versão/provider pode existir sem execução do bloco |
| evidencia_dependente_de_autorizacao_propria | Consultar associação é operação nativa própria e não autorizada aqui |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Zero/vários/nulo/erro permanecem inconclusivos; um resultado só sustenta a observação limitada.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N03-02 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N03-02 |
| pendencia | H3G-N03 |
| severidade_historica | ALTA |
| linhas_r1 | B178–195 |
| dependencias | root\cimv2 Win32_DiskDrive Index/InterfaceType/MediaType; root\Microsoft\Windows\Storage MSFT_Disk Number/BusType/IsOffline |
| questao_aberta | Mínimo documental Windows 8/Server 2012 não prova provider/acesso; nulos/offline/índices/bus |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Documentação e inventário legítimo sem consulta |
| evidencia_dependente_de_autorizacao_propria | Correspondência real e natureza física exigem evidência separada; Fixed não basta |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Dados divergentes/nulos/offline/desconhecidos mantêm ramos conservadores; Fixed não certifica interno.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N03-03 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N03-03 |
| pendencia | H3G-N03 |
| severidade_historica | ALTA |
| linhas_r1 | B265–281 |
| dependencias | root\cimv2; Win32_Share; Path/Type inclusive administrativos |
| questao_aberta | Metadados parciais/nulos, permissão, exposição; D04 não executada |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Política/inventário privado já legítimos sem consulta |
| evidencia_dependente_de_autorizacao_propria | WMI real requer autorização própria; sem remover/isentar share para obter aprovação |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Path/Type ausente não vira ausência de share; administrativo incidente não é dispensado.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N03-04 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N03-04 |
| pendencia | H3G-N03 |
| severidade_historica | ALTA |
| linhas_r1 | B065–110 |
| dependencias | Escopos locais e opções Timeout/EnablePrivileges/Rewindable, limite de registros |
| questao_aberta | Conexão implícita/provider/COM/RPC/MoveNext/Dispose; prazo global não garantido |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Revisão de contrato e requisitos de duração sem executar |
| evidencia_dependente_de_autorizacao_propria | Duração/efeitos/fechamento nativos exigem método próprio; não elevar ou instalar |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Sem elevação/alteração de políticas; timeouts parciais não aprovam globalidade; incerteza bloqueia continuidade.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N04-01 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N04-01 |
| pendencia | H3G-N04 |
| severidade_historica | MEDIA |
| linhas_r1 | B004–025 |
| dependencias | Estados ordenados e objeto flow compartilhados; helpers aninhados |
| questao_aberta | Escopo e propagação das mutações |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Inspeção textual de variáveis sem mocks ou exemplos executados |
| evidencia_dependente_de_autorizacao_propria | Semântica real exige validação nativa própria, ainda não autorizada |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Estados/códigos refletem fatos e critérios alcançados; não inventar evento para completar coleção.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N04-02 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N04-02 |
| pendencia | H3G-N04 |
| severidade_historica | MEDIA |
| linhas_r1 | B070–110;B173–180 |
| dependencias | List[object], ToArray e @(), enumeração |
| questao_aberta | Cardinalidade, unrolling, limite e dados em memória |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Conferência textual da intenção |
| evidencia_dependente_de_autorizacao_propria | Zero/um/vários e comportamento de binder não foram simulados; autorização própria futura |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Cardinalidade e objetos não colapsados/coagidos; adicionais tratados como incompatibilidade.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N04-03 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N04-03 |
| pendencia | H3G-N04 |
| severidade_historica | MEDIA |
| linhas_r1 | B022–025;B093–107;B332–345 |
| dependencias | Stop-H3, throw/catch/finally e encerramento |
| questao_aberta | Parada controlada, exceção sobreposta e atribuição V03/V09 |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Presença textual D01–D04 conhecida sem execução |
| evidencia_dependente_de_autorizacao_propria | Eficácia de falhas/fechamento precisa validação separada; sem convertê-la em teste autorizado agora |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Falha primária e de fechamento distinguíveis; não prometer JSON em fatal de host.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N04-04 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N04-04 |
| pendencia | H3G-N04 |
| severidade_historica | MEDIA |
| linhas_r1 | B319–368 |
| dependencias | Revalidação e consolidação acumulada de V01–V10 |
| questao_aberta | Coerência real de estados/códigos e incompletude |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Grafo nominal/estático sem simular execuções |
| evidencia_dependente_de_autorizacao_propria | Confronto em execução precisa escopo próprio e contrato externo |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Impedimento prevalece na consolidação interna; encerramento/recepção seguem eixos próprios.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


### N04-05 — registro histórico não verificado

| Campo | Valor preservado |
|---|---|
| id | N04-05 |
| pendencia | H3G-N04 |
| severidade_historica | MEDIA |
| linhas_r1 | B369–383 |
| dependencias | Objeto de 12 propriedades e ConvertTo-Json Depth 8 |
| questao_aberta | Saída única/completa, tipos, codificação de captura e falhas fora do try |
| conferencia_documental | CONFERIDO_ESTATICAMENTE |
| sintaxe_do_bloco | SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1 |
| comportamento | COMPORTAMENTO_NATIVO_NAO_VERIFICADO |
| estado_pendencia | NAO_VERIFICADO |
| evidencia_possivel_sem_executar_h3_f_r1 | Contrato textual pode ser revisado sem H3-F-R1 |
| evidencia_dependente_de_autorizacao_propria | Serialização/contexto real e vínculo com rodada precisam evidência operacional específica |
| execucao_atual | NAO_EXECUTADA |

Critério futuro já especificado: Um objeto compatível pode relatar impedimento; silêncio/zero/sintaxe não são aprovação, closure separada.

Limite: Permanece NAO_VERIFICADO; impede uso do método que necessite desta propriedade; não preencher por sintaxe, outra suíte ou resultado de outro ambiente. Se revisão futura remover dependência, exige nova auditoria e identidade, não edição da história.

Autorização necessária: NAO_AUTORIZADA; requer escopo nativo/contratual próprio, sem invocar H3-F-R1, inspeção ou custódia por implicação.

Estado D5: NAO_VERIFICADO; NAO_EXECUTADA. Não é pré-condição para escrever modelos passivos sem API real, mas é bloqueador da futura ação que dependa da propriedade. Nada executado.


## Retenção e decisões posteriores

H3-E preservada: usuário como custodiante principal; coadministradores apenas com autorização específica. Alterações de acesso, movimentações e exclusões exigem autorização prévia específica. Assistência remota adiada/não autorizada. Retenção vinculada à H4, máximo inicial de 180 dias somente após futura cópia fiel aceita e verificada; revisões 60/120/180 e antecipada se H4 terminar; prorrogação expressa justificada e nenhuma exclusão automática. Nenhum marco/prazo/agenda iniciado. Validade operacional é decisão separada.

P6/H3-C/H3-S/H4 não autorizados; não criar destino ou ler/copiar/sanitizar/mover/
descartar XML. Não iniciar qualquer marco de custódia por preparar pedido.
Nenhum P1–P4 aceito no futuro liberaria P5 ou P6 automaticamente.
