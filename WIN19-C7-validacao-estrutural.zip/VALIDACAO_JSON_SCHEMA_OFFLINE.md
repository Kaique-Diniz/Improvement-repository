# C7-03 — JSON Schema offline

23/11/2026. Biblioteca preexistente jsonschema 4.26.0; classe selecionada diretamente
`Draft202012Validator`, sem descoberta de dialeto a partir de `$schema`/`$id`.
Draft 2020-12 confirmado pelos recursos locais de jsonschema-specifications.
Nenhum pacote instalado e nenhum acesso de rede durante as validações.

## Métodos e alcance

- check_schema sobre cada schema JSON interpretável, usando metaschemas embarcados.
- Registry com retrieval externo sempre recusado nas validações de instância.
- Audit hook do processo proíbe sockets, subprocessos, ctypes e imports conversor;
  leitura limitada à área C7 e ao prefixo do runtime; escrita só na área temporária.
- Busca estrutural de `$ref`, destinos no `$defs` do próprio schema e ciclos.
- Avaliação efetiva de required/additionalProperties/type/enum/const, allOf,
  oneOf, anyOf, not e if/then/else nas instâncias e mutações sintéticas descritas.
  As sondas não são exploração exaustiva de todas as combinações possíveis.
- Nenhuma avaliação de cardinalidades/condicionais do relatório integral: bloqueada.

Evento: metaschema VALIDO; 54 ocorrências de referências locais examinadas.
Mensagem: metaschema VALIDO; 60 ocorrências de referências locais examinadas.
Nenhum destino externo, inexistente ou ciclo observado nos dois schemas avaliados.
Relatório: BLOQUEADO por sintaxe, sem contagem formal de referências interpretadas.
As demais três peças são dados/CSV, não candidatas ao metaschema de JSON Schema.

## Resultado das 28 sondas de schema

| ID | Schema | Validade esperada | Validade observada | Concorda |
| --- | --- | --- | --- | --- |
| EVENTO_EXTRA | evento.schema.json | False | False | True |
| EVENTO_FALTA_ID | evento.schema.json | False | False | True |
| EVENTO_VERSAO | evento.schema.json | False | False | True |
| EVENTO_SEQ_ZERO | evento.schema.json | False | False | True |
| BOOLEANO_TEXTO | evento.schema.json | False | False | True |
| OBSERVADO_NULL | evento.schema.json | False | False | True |
| TIPO_DESCONHECIDO | evento.schema.json | False | False | True |
| EVIDENCIA_DUPLICADA | evento.schema.json | False | False | True |
| FUNCIONAL_ALVO_NULL | evento.schema.json | False | False | True |
| AUSENCIA_COM_VALOR | evento.schema.json | False | False | True |
| AUSENCIA_SEM_MOTIVO | evento.schema.json | False | False | True |
| BOOLEANO_FALSE_NAO_E_PASS | evento.schema.json | True | True | True |
| WIN32_ZERO_NAO_E_PASS | evento.schema.json | True | True | True |
| PERSISTENCIA_MODELO | evento.schema.json | True | True | True |
| PERSISTENCIA_SEM_DECLARACAO | evento.schema.json | False | False | True |
| PERSISTENCIA_CAMADA_INVALIDA | evento.schema.json | False | False | True |
| MENSAGEM_EXTRA_DISCO | mensagem.schema.json | False | False | True |
| REFERENCIA_SEM_ALVO | mensagem.schema.json | False | False | True |
| CORRESPONDENCIA_COM_HASH_NULL | mensagem.schema.json | False | False | True |
| ACK_DECLARADO_HASH_AUSENTE_NAO_VERIFICADO | mensagem.schema.json | True | True | True |
| ACK_SEM_CONFIRMACAO | mensagem.schema.json | False | False | True |
| ACK_SEMANTICA_DISCO | mensagem.schema.json | False | False | True |
| INCIDENTE_SEM_ALVO | mensagem.schema.json | True | True | True |
| INCIDENTE_CORRESPONDENCIA | mensagem.schema.json | False | False | True |
| HASH_FABRICADO_MODELO | evento.schema.json | True | True | True |
| HASH_FABRICADO_REGISTRO | evento.schema.json | False | False | True |
| LIMITE_ACK_ID_DIVERGENTE | mensagem.schema.json | True | True | True |
| LIMITE_WIN_SUBCASO_DIVERGENTE | evento.schema.json | True | True | True |

Vinte estruturas proibidas foram rejeitadas; oito estruturas previstas foram
aceitas. Nas duas sondas LIMITE_*, a aceitação estrutural é intencionalmente
registrada como limite: não comprova consistência entre IDs nem correlação de ACK.
False e zero válidos em observações continuam valores, sem converter-se em PASS.

## Evidência formal e caminhos dos erros

Os registros abaixo são resultados reais da última invocação C7. Caminhos de
instância e schema são pointers relativos ao objeto avaliado. Não são caminhos
privados de arquivos. Mensagens contêm somente valores sintéticos.

```json
{
  "schemas": [
    {
      "arquivo": "evento.schema.json",
      "status": "VALIDO",
      "metaschema": "Draft202012Validator.check_schema sem erros",
      "refs": [
        {
          "path": "/properties/versao_contrato/$ref",
          "destino": "#/$defs/Versao",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/natureza/$ref",
          "destino": "#/$defs/NaturezaRegistro",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/evento_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/execucao_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/sequencia/$ref",
          "destino": "#/$defs/Seq",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/etapa_origem/$ref",
          "destino": "#/$defs/Etapa",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/controle_win/anyOf/0/$ref",
          "destino": "#/$defs/Win",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/subcaso_id/anyOf/0/$ref",
          "destino": "#/$defs/Subcaso",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/afirmacao_id/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/instante_utc/$ref",
          "destino": "#/$defs/Tempo",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/motivo_instante/anyOf/0/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/observado/$ref",
          "destino": "#/$defs/Observacao",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/esperado/$ref",
          "destino": "#/$defs/Esperado",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/lacunas/$ref",
          "destino": "#/$defs/ListaCodigos",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/primeira_falha/anyOf/0/$ref",
          "destino": "#/$defs/FalhaSegura",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/falhas_adicionais/items/$ref",
          "destino": "#/$defs/FalhaSegura",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/integridade_referencia/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/custodia/$ref",
          "destino": "#/$defs/CustodiaRef",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/0/then/properties/controle_win/$ref",
          "destino": "#/$defs/Win",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/0/then/properties/subcaso_id/$ref",
          "destino": "#/$defs/Subcaso",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/0/then/properties/afirmacao_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/1/then/properties/motivo_instante/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/5/then/properties/integridade_referencia/$ref",
          "destino": "#/$defs/HashNaoFabricado",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/5/then/properties/custodia/properties/integridade/$ref",
          "destino": "#/$defs/HashNaoFabricado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ListaRefs/items/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ListaCodigos/items/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ValorPresente/oneOf/4/properties/valor/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/properties/sha256/anyOf/0/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/properties/fonte_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/properties/revisao_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/1/then/properties/sha256/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/1/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/2/then/properties/sha256/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/2/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/2/then/properties/revisao_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/3/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/3/then/properties/revisao_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashNaoFabricado/allOf/0/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/properties/tipo/$ref",
          "destino": "#/$defs/TipoValor",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/properties/motivo/anyOf/0/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/properties/evidencia_refs/$ref",
          "destino": "#/$defs/ListaRefs",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/then/allOf/0/$ref",
          "destino": "#/$defs/ValorPresente",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/else/properties/motivo/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/properties/tipo/$ref",
          "destino": "#/$defs/TipoValor",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/properties/fonte_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/then/allOf/0/$ref",
          "destino": "#/$defs/ValorPresente",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/fase/$ref",
          "destino": "#/$defs/Etapa",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/codigo_seguro/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/codigo_original/$ref",
          "destino": "#/$defs/Observacao",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/evidencia_refs/$ref",
          "destino": "#/$defs/ListaRefs",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/CustodiaRef/properties/registro_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/CustodiaRef/properties/integridade/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/CustodiaRef/allOf/1/then/properties/registro_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        }
      ],
      "ciclos": false,
      "operadores": [
        "additionalProperties",
        "allOf",
        "anyOf",
        "const",
        "else",
        "enum",
        "if",
        "not",
        "oneOf",
        "required",
        "then",
        "type"
      ],
      "issues": []
    },
    {
      "arquivo": "mensagem.schema.json",
      "status": "VALIDO",
      "metaschema": "Draft202012Validator.check_schema sem erros",
      "refs": [
        {
          "path": "/properties/versao_contrato/$ref",
          "destino": "#/$defs/Versao",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/natureza/$ref",
          "destino": "#/$defs/NaturezaRegistro",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/mensagem_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/execucao_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/sequencia_mensagem/$ref",
          "destino": "#/$defs/Seq",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/evento_ref/anyOf/0/$ref",
          "destino": "#/$defs/ReferenciaEvento",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/mensagem_origem_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/confirmacao/anyOf/0/$ref",
          "destino": "#/$defs/AckDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/incidente/anyOf/0/$ref",
          "destino": "#/$defs/IncidenteCorrelacao",
          "resolvido_localmente": true
        },
        {
          "path": "/properties/custodia/$ref",
          "destino": "#/$defs/CustodiaRef",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/0/then/properties/evento_ref/$ref",
          "destino": "#/$defs/ReferenciaEvento",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/1/then/properties/evento_ref/$ref",
          "destino": "#/$defs/ReferenciaEvento",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/1/then/properties/mensagem_origem_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/1/then/properties/confirmacao/$ref",
          "destino": "#/$defs/AckDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/2/then/properties/incidente/$ref",
          "destino": "#/$defs/IncidenteCorrelacao",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/3/then/properties/evento_ref/properties/hash_evento/properties/sha256/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/3/then/properties/confirmacao/anyOf/1/properties/hash_evento/properties/sha256/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/4/then/properties/evento_ref/anyOf/1/properties/hash_evento/$ref",
          "destino": "#/$defs/HashNaoFabricado",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/4/then/properties/confirmacao/anyOf/1/properties/hash_evento/$ref",
          "destino": "#/$defs/HashNaoFabricado",
          "resolvido_localmente": true
        },
        {
          "path": "/allOf/4/then/properties/custodia/properties/integridade/$ref",
          "destino": "#/$defs/HashNaoFabricado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ReferenciaEvento/properties/evento_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ReferenciaEvento/properties/sequencia_evento/$ref",
          "destino": "#/$defs/Seq",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ReferenciaEvento/properties/hash_evento/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/AckDeclarado/properties/confirmacao_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/AckDeclarado/properties/mensagem_confirmada_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/AckDeclarado/properties/evento_id/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/AckDeclarado/properties/sequencia_evento/$ref",
          "destino": "#/$defs/Seq",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/AckDeclarado/properties/hash_evento/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/IncidenteCorrelacao/properties/mensagem_refs/$ref",
          "destino": "#/$defs/ListaRefs",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/IncidenteCorrelacao/properties/evidencia_refs/$ref",
          "destino": "#/$defs/ListaRefs",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ListaRefs/items/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ListaCodigos/items/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/ValorPresente/oneOf/4/properties/valor/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/properties/sha256/anyOf/0/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/properties/fonte_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/properties/revisao_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/1/then/properties/sha256/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/1/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/2/then/properties/sha256/$ref",
          "destino": "#/$defs/SHA",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/2/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/2/then/properties/revisao_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/3/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashDeclarado/allOf/3/then/properties/revisao_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/HashNaoFabricado/allOf/0/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/properties/tipo/$ref",
          "destino": "#/$defs/TipoValor",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/properties/motivo/anyOf/0/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/properties/evidencia_refs/$ref",
          "destino": "#/$defs/ListaRefs",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/then/allOf/0/$ref",
          "destino": "#/$defs/ValorPresente",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Observacao/else/properties/motivo/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/properties/tipo/$ref",
          "destino": "#/$defs/TipoValor",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/properties/fonte_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/then/allOf/0/$ref",
          "destino": "#/$defs/ValorPresente",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/Esperado/then/properties/fonte_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/fase/$ref",
          "destino": "#/$defs/Etapa",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/codigo_seguro/$ref",
          "destino": "#/$defs/CodigoSeguro",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/codigo_original/$ref",
          "destino": "#/$defs/Observacao",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/FalhaSegura/properties/evidencia_refs/$ref",
          "destino": "#/$defs/ListaRefs",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/CustodiaRef/properties/registro_ref/anyOf/0/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/CustodiaRef/properties/integridade/$ref",
          "destino": "#/$defs/HashDeclarado",
          "resolvido_localmente": true
        },
        {
          "path": "/$defs/CustodiaRef/allOf/1/then/properties/registro_ref/$ref",
          "destino": "#/$defs/ID",
          "resolvido_localmente": true
        }
      ],
      "ciclos": false,
      "operadores": [
        "additionalProperties",
        "allOf",
        "anyOf",
        "const",
        "else",
        "enum",
        "if",
        "not",
        "oneOf",
        "required",
        "then",
        "type"
      ],
      "issues": []
    },
    {
      "arquivo": "relatorio.schema.json",
      "status": "BLOQUEADO",
      "motivo": "JSON_INVALIDO; metaschema e instâncias integrais não avaliados"
    }
  ],
  "sondas_schema": [
    {
      "id": "EVENTO_EXTRA",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/",
          "schema_path": "/additionalProperties",
          "validator": "additionalProperties",
          "mensagem": "Additional properties are not allowed ('resultado' was unexpected)"
        }
      ]
    },
    {
      "id": "EVENTO_FALTA_ID",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/",
          "schema_path": "/required",
          "validator": "required",
          "mensagem": "'evento_id' is a required property"
        }
      ]
    },
    {
      "id": "EVENTO_VERSAO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/versao_contrato",
          "schema_path": "/properties/versao_contrato/const",
          "validator": "const",
          "mensagem": "'0.1.0-proposta-c5' was expected"
        }
      ]
    },
    {
      "id": "EVENTO_SEQ_ZERO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/sequencia",
          "schema_path": "/properties/sequencia/minimum",
          "validator": "minimum",
          "mensagem": "0 is less than the minimum of 1"
        }
      ]
    },
    {
      "id": "BOOLEANO_TEXTO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/observado",
          "schema_path": "/properties/observado/then/allOf/0/oneOf",
          "validator": "oneOf",
          "mensagem": "{'estado': 'OBSERVADO', 'tipo': 'BOOLEANO', 'valor': 'true', 'motivo': None, 'origem': 'HELPER', 'evidencia_refs': ['EVI_MODELO_01']} is not valid under any of the given schemas"
        }
      ]
    },
    {
      "id": "OBSERVADO_NULL",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/observado",
          "schema_path": "/properties/observado/then/allOf/0/oneOf",
          "validator": "oneOf",
          "mensagem": "{'estado': 'OBSERVADO', 'tipo': 'BOOLEANO', 'valor': None, 'motivo': None, 'origem': 'HELPER', 'evidencia_refs': ['EVI_MODELO_01']} is not valid under any of the given schemas"
        }
      ]
    },
    {
      "id": "TIPO_DESCONHECIDO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/observado/tipo",
          "schema_path": "/properties/observado/properties/tipo/enum",
          "validator": "enum",
          "mensagem": "'NOVO' is not one of ['BOOLEANO', 'INTEIRO', 'CODIGO_WIN32', 'NTSTATUS_HEX', 'CODIGO_APLICACAO', 'ROTULO', 'AUSENTE']"
        },
        {
          "path": "/observado",
          "schema_path": "/properties/observado/then/allOf/0/oneOf",
          "validator": "oneOf",
          "mensagem": "{'estado': 'OBSERVADO', 'tipo': 'NOVO', 'valor': True, 'motivo': None, 'origem': 'HELPER', 'evidencia_refs': ['EVI_MODELO_01']} is not valid under any of the given schemas"
        }
      ]
    },
    {
      "id": "EVIDENCIA_DUPLICADA",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/observado/evidencia_refs",
          "schema_path": "/properties/observado/properties/evidencia_refs/uniqueItems",
          "validator": "uniqueItems",
          "mensagem": "['EVI_MODELO_01', 'EVI_MODELO_01'] has non-unique elements"
        }
      ]
    },
    {
      "id": "FUNCIONAL_ALVO_NULL",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/controle_win",
          "schema_path": "/allOf/0/then/properties/controle_win/enum",
          "validator": "enum",
          "mensagem": "None is not one of ['WIN-01', 'WIN-02', 'WIN-03', 'WIN-04', 'WIN-05', 'WIN-06', 'WIN-07', 'WIN-08', 'WIN-09', 'WIN-10', 'WIN-11', 'WIN-12', 'WIN-13', 'WIN-14', 'WIN-15', 'WIN-16', 'WIN-17', 'WIN-18', 'WIN-19']"
        }
      ]
    },
    {
      "id": "AUSENCIA_COM_VALOR",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/observado/valor",
          "schema_path": "/properties/observado/else/properties/valor/type",
          "validator": "type",
          "mensagem": "False is not of type 'null'"
        }
      ]
    },
    {
      "id": "AUSENCIA_SEM_MOTIVO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/observado/motivo",
          "schema_path": "/properties/observado/else/properties/motivo/type",
          "validator": "type",
          "mensagem": "None is not of type 'string'"
        }
      ]
    },
    {
      "id": "BOOLEANO_FALSE_NAO_E_PASS",
      "schema": "evento.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "WIN32_ZERO_NAO_E_PASS",
      "schema": "evento.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "PERSISTENCIA_MODELO",
      "schema": "evento.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "PERSISTENCIA_SEM_DECLARACAO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/persistencia_registro",
          "schema_path": "/allOf/4/then/properties/persistencia_registro/const",
          "validator": "const",
          "mensagem": "'FALHA_DECLARADA' was expected"
        }
      ]
    },
    {
      "id": "PERSISTENCIA_CAMADA_INVALIDA",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/primeira_falha/camada",
          "schema_path": "/allOf/4/then/properties/primeira_falha/properties/camada/enum",
          "validator": "enum",
          "mensagem": "'HELPER' is not one of ['OBSERVADOR', 'TRANSPORTE']"
        }
      ]
    },
    {
      "id": "MENSAGEM_EXTRA_DISCO",
      "schema": "mensagem.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/",
          "schema_path": "/additionalProperties",
          "validator": "additionalProperties",
          "mensagem": "Additional properties are not allowed ('persistido' was unexpected)"
        }
      ]
    },
    {
      "id": "REFERENCIA_SEM_ALVO",
      "schema": "mensagem.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/evento_ref",
          "schema_path": "/allOf/0/then/properties/evento_ref/type",
          "validator": "type",
          "mensagem": "None is not of type 'object'"
        }
      ]
    },
    {
      "id": "CORRESPONDENCIA_COM_HASH_NULL",
      "schema": "mensagem.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/evento_ref/hash_evento/sha256",
          "schema_path": "/allOf/3/then/properties/evento_ref/properties/hash_evento/properties/sha256/type",
          "validator": "type",
          "mensagem": "None is not of type 'string'"
        }
      ]
    },
    {
      "id": "ACK_DECLARADO_HASH_AUSENTE_NAO_VERIFICADO",
      "schema": "mensagem.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "ACK_SEM_CONFIRMACAO",
      "schema": "mensagem.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/confirmacao",
          "schema_path": "/allOf/1/then/properties/confirmacao/type",
          "validator": "type",
          "mensagem": "None is not of type 'object'"
        }
      ]
    },
    {
      "id": "ACK_SEMANTICA_DISCO",
      "schema": "mensagem.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/confirmacao",
          "schema_path": "/properties/confirmacao/anyOf",
          "validator": "anyOf",
          "mensagem": "{'confirmacao_id': 'CONF_MODELO', 'mensagem_confirmada_ref': 'MSG_ORIGEM_MODELO', 'evento_id': 'EV_MODELO_01', 'sequencia_evento': 1, 'hash_evento': {'estado': 'NAO_DISPONIVEL', 'sha256': None, 'fonte_ref': None, 'revisao_ref': None}, 'semantica': 'PERSISTIDO'} is not valid under any of the given schemas"
        },
        {
          "path": "/confirmacao/semantica",
          "schema_path": "/allOf/1/then/properties/confirmacao/properties/semantica/const",
          "validator": "const",
          "mensagem": "'RECEBIMENTO_DECLARADO_SEM_PROVA_DE_DISCO' was expected"
        }
      ]
    },
    {
      "id": "INCIDENTE_SEM_ALVO",
      "schema": "mensagem.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "INCIDENTE_CORRESPONDENCIA",
      "schema": "mensagem.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/correlacao",
          "schema_path": "/allOf/2/then/properties/correlacao/enum",
          "validator": "enum",
          "mensagem": "'CORRESPONDENCIA_DECLARADA' is not one of ['NAO_VERIFICADA', 'INCONSISTENTE']"
        },
        {
          "path": "/evento_ref",
          "schema_path": "/allOf/3/then/properties/evento_ref/type",
          "validator": "type",
          "mensagem": "None is not of type 'object'"
        }
      ]
    },
    {
      "id": "HASH_FABRICADO_MODELO",
      "schema": "evento.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "HASH_FABRICADO_REGISTRO",
      "schema": "evento.schema.json",
      "esperado_valido": false,
      "observado_valido": false,
      "coincide": true,
      "erros": [
        {
          "path": "/integridade_referencia/estado",
          "schema_path": "/allOf/5/then/properties/integridade_referencia/allOf/1/properties/estado/not",
          "validator": "not",
          "mensagem": "'FABRICADO_PARA_ILUSTRACAO' should not be valid under {'const': 'FABRICADO_PARA_ILUSTRACAO'}"
        }
      ]
    },
    {
      "id": "LIMITE_ACK_ID_DIVERGENTE",
      "schema": "mensagem.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    },
    {
      "id": "LIMITE_WIN_SUBCASO_DIVERGENTE",
      "schema": "evento.schema.json",
      "esperado_valido": true,
      "observado_valido": true,
      "coincide": true,
      "erros": []
    }
  ],
  "retrievals_externos": []
}
```

A conformidade ao metaschema verifica a forma do schema, não sua adequação à
política nem os fatos declarados. Aprovação estrutural não autentica autorização,
hash, custódia, persistência, isolamento ou evidência primária.
