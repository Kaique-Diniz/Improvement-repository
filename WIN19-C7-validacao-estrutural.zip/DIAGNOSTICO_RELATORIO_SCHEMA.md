# C7-01 — diagnóstico do schema de relatório

23/11/2026. Fonte imutável: `contratos_c/relatorio.schema.json`, 20.836 bytes,
SHA-256 `ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6`.
Examinada uma cópia íntegra; origem e cópia permaneceram com o mesmo hash.

## Reprodução confirmada

Parser stdlib JSON do Python 3.12.14, UTF-8 estrito, chaves repetidas e constantes
não JSON recusadas. Erro integral observado:

```text
JSONDecodeError: Expecting property name enclosed in double quotes:
line 39 column 5 (char 3110)
```

Linha/coluna base um. Deslocamento de caracteres base zero: 3110; bytes UTF-8 base
zero: 3118. Nenhum desses números é código Win32 ou resultado de controle WIN.

## Delimitação

A primeira condicional abre na linha 34, dentro do array `allOf` da linha 33.
Na saída da linha 37, o rastreamento lexical, respeitando strings/escapes, conserva:
raiz L1; array L33; item L34/C5; `then` L34/C88; `properties` L34/C103; `casos`
L37/C16. Os três fechamentos `}}}` da linha 38 deixam o item L34/C5 aberto.
A vírgula seguinte é interpretada como separador de propriedade desse objeto;
a abertura `{` de L39/C5 aparece onde o parser exige um nome entre aspas.
O rastreamento encontra ainda `]` de L48/C3 incompatível com esse objeto aberto.
Esse segundo sintoma decorre do mesmo fechamento ausente; não é comprovação de
um segundo defeito independente.

Trecho original, sem correção:

```text
L38     }}},
L39     {"if": {"properties": {"natureza": {"const": "REGISTRO_DECLARADO"}}}, ...
```

## Busca de erros após o ponto inicial

Foram interpretados dois fragmentos intactos, com JSONDecoder.raw_decode a partir
das aberturas efetivamente existentes, sem inserir ou remover bytes:

```json
[
  {
    "fragmento": "SEGUNDA_CONDICIONAL_L39",
    "inicio_caracteres": 3110,
    "fim_caracteres": 4395,
    "status": "VALIDO_COMO_FRAGMENTO",
    "nota": "Não é validação do schema integral nem correção aplicada"
  },
  {
    "fragmento": "OBJETO_DEFS_L49",
    "inicio_caracteres": 4412,
    "fim_caracteres": 20815,
    "status": "VALIDO_COMO_FRAGMENTO",
    "nota": "Não é validação do schema integral nem correção aplicada"
  }
]
```

A segunda condicional e o objeto `$defs` são sintaticamente interpretáveis como
fragmentos. Não foi observado novo erro nesses recortes. Isso não demonstra
completude sintática/semântica do schema integral após uma eventual correção.
Não houve concatenação em uma versão corrigida, aplicação de patch, avaliação do
metaschema integral de relatório ou validação de relatórios contra ele.

## Classificação e impacto

Sintaxe: INVALIDO. Arquivo C7: REPROVADO_ESTRUTURALMENTE. Metaschema e instâncias
integrais: BLOQUEADO por JSON inválido. Nenhuma mensagem de metaschema é inventada.
O perfil offline não é a causa desse erro: a falha antecede a seleção do dialeto.
Evento/mensagem/estados/CSV/vetores não dependem de `$ref` externo ao relatório e
puderam ser avaliados independentemente.

Correção textual candidata: um fechamento `}` adicional antes da vírgula de L38.
É uma proposta sintática para C6-R1, não uma aprovação semântica. Ver documento
específico da proposta. O arquivo original e sua cópia não foram modificados.
