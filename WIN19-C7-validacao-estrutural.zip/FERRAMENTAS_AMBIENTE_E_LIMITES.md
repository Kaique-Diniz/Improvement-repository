# C7 — ferramentas, ambiente e reprodução

23/11/2026. Linux, Python 3.12.14 preexistente. Não foram instalados pacotes.
Ferramenta temporária independente C7 criada no diretório de trabalho externo;
não é runner/observador/supervisor C, módulo do produto ou componente Categoria B.
Não executa dados fornecidos: JSON/CSV são somente lidos e interpretados.

```json
{
  "python": "3.12.14",
  "executavel": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python",
  "plataforma": "linux",
  "isolated": 1,
  "dont_write_bytecode": true,
  "dialeto": "Draft 2020-12 selecionado explicitamente",
  "rede": "retrieval recusado e socket bloqueado por audit hook",
  "ferramenta_sha256": "412469108d3719254d17c48aa1261cfd7fff9d776eaa61f76a922f378e4cf152"
}
```

## Origem das bibliotecas

Distribuições já disponíveis no prefixo do runtime Codex. Nome/versão e raiz
observados via importlib.metadata; os hashes abaixo correspondem ao texto METADATA
reencodificado em UTF-8. Isso identifica a instalação local observada; não é
verificação de assinatura de fornecedor ou reconstrução independente dos wheels.
A biblioteca jsonschema é a implementação instalada usada para Draft 2020-12;
não houve instalação ou substituição por implementação improvisada de metaschema.

```json
[
  {
    "nome": "jsonschema",
    "versao": "4.26.0",
    "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
    "metadata_sha256": "05b189866ca98a96da3934bf6b83687ced3ff85325273b77e16b705f6d8b26d2"
  },
  {
    "nome": "referencing",
    "versao": "0.37.0",
    "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
    "metadata_sha256": "c93b00e6ab1524fd60848376604c189a114374776475c25a31d57be47b29de6a"
  },
  {
    "nome": "jsonschema-specifications",
    "versao": "2025.9.1",
    "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
    "metadata_sha256": "35abd41757f32b4ea24756920ded47b70173d77cbc052a5a6d3ab583b2e8d89d"
  },
  {
    "nome": "attrs",
    "versao": "26.1.0",
    "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
    "metadata_sha256": "4cd40e690f23bf37cbcad34efd6758e062df1df07c86833f7e3ce95bf1fa38cc"
  },
  {
    "nome": "rpds-py",
    "versao": "2026.6.3",
    "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
    "metadata_sha256": "f8be7b17da3980b2c48596941411a43c70ac41b1e2d530aa531f2c15eab2eb1c"
  }
]
```

## Isolamento aplicado

Python `-I -B`: diretório corrente/PYTHONPATH externos não entram como fonte de
imports da aplicação; bytecode não é gravado. A ferramenta não importa conversor.
Os schemas são passados à classe Draft202012Validator explicitamente. Metaschemas
embarcam na instalação; Registry de instâncias recusa retrieval externo. O audit
hook proíbe socket.*, subprocess.*, ctypes.*, os.system/exec/posix_spawn, imports
conversor e abertura de arquivos fora da área C7/prefixo do runtime. Escrita só na
área temporária C7. Foram observadas zero solicitações de retrieval externo.

Essas medidas são restrições do processo de validação, não sandbox de kernel,
comprovação contra código arbitrário malicioso ou prova de isolamento Windows.
Nenhum arquivo recebido foi importado ou executado. Não foram consultadas
candidatas, fontes de moradores, custódias privadas, contas ou ACLs. Sem Git,
configuração persistente, preflight Windows, pytest ou implementação de Categoria B.

## Parsing estrito e negativas

Usado UTF-8 com errors=strict; recusa explícita de BOM; object_pairs_hook recusa
propriedades duplicadas; parse_constant recusa NaN/Infinity; json.loads recusa
conteúdo após o documento. parse_float ainda recusa resultado não finito da
representação local. `1e999` é número lexicalmente permitido em JSON: sua recusa
é limite da representação float deste parser, não alegação de sintaxe JSON inválida.
Nenhum dos contratos recebidos contém esse caso ou foi normalizado por isso.

```json
[
  {
    "id": "DUPLICADA",
    "rejeitado": true,
    "erro": {
      "tipo": "StrictError",
      "mensagem": "PROPRIEDADE_DUPLICADA:a"
    }
  },
  {
    "id": "NAN",
    "rejeitado": true,
    "erro": {
      "tipo": "StrictError",
      "mensagem": "CONSTANTE_NAO_JSON:NaN"
    }
  },
  {
    "id": "INFINITY",
    "rejeitado": true,
    "erro": {
      "tipo": "StrictError",
      "mensagem": "CONSTANTE_NAO_JSON:Infinity"
    }
  },
  {
    "id": "MENOS_INFINITY",
    "rejeitado": true,
    "erro": {
      "tipo": "StrictError",
      "mensagem": "CONSTANTE_NAO_JSON:-Infinity"
    }
  },
  {
    "id": "BOM",
    "rejeitado": true,
    "erro": {
      "tipo": "StrictError",
      "mensagem": "BOM_PROIBIDO"
    }
  },
  {
    "id": "UTF8_INVALIDO",
    "rejeitado": true,
    "erro": {
      "tipo": "UnicodeDecodeError",
      "mensagem": "'utf-8' codec can't decode byte 0xff in position 6: invalid start byte"
    }
  },
  {
    "id": "CONTEUDO_ADICIONAL",
    "rejeitado": true,
    "erro": {
      "tipo": "JSONDecodeError",
      "mensagem": "Extra data: line 1 column 4 (char 3)",
      "linha": 1,
      "coluna": 4,
      "offset_caracteres": 3
    }
  },
  {
    "id": "TRUNCADO",
    "rejeitado": true,
    "erro": {
      "tipo": "JSONDecodeError",
      "mensagem": "Expecting value: line 1 column 6 (char 5)",
      "linha": 1,
      "coluna": 6,
      "offset_caracteres": 5
    }
  },
  {
    "id": "OVERFLOW_FLOAT_LOCAL",
    "rejeitado": true,
    "erro": {
      "tipo": "StrictError",
      "mensagem": "NUMERO_NAO_FINITO_NO_PARSER"
    }
  }
]
```

## Reprodução e evidência da ferramenta

Invocação real da rodada final, sem pytest:

```text
python -I -B /workspace/work/win19-c7-trabalho-p4L0UV/validacao_independente_c7.py
```

A área de trabalho contém cópias íntegras C6 e os registros intermediários. Os
relatórios finais são arquivos separados, sem .py executável distribuído. A fonte
exata da ferramenta utilizada está transcrita abaixo como evidência textual
inerte. Seu SHA-256 é o campo ferramenta_sha256 acima. Para reproduzir em outra
área externa autorizada, será necessário adaptar somente o caminho WORK e refazer
primeiro as verificações de integridade do ZIP/manifesto e a cópia exclusiva.
A adaptação produzirá outro hash da ferramenta, que deverá ser registrado.
Não executar o bloco por automação ou tratá-lo como autorização de outro portão.
A invocação inicial, preservada na área temporária, precedeu o reforço das checagens;
os números entregues são exclusivamente da invocação final transcrita.

## Transcrição integral da ferramenta independente final

```python
"""Ferramenta independente e temporária C7; não é runner C nem código do produto."""
import sys, pathlib, os, json, csv, io, copy, hashlib, importlib.metadata, platform, re, math
WORK = pathlib.Path('/workspace/work/win19-c7-trabalho-p4L0UV')
ROOT = WORK / 'copias_C6'
PREFIX = pathlib.Path(sys.prefix).resolve()
def guard(event, args):
    if event.startswith(('socket.', 'subprocess.', 'ctypes.')) or event in {'os.system', 'os.exec', 'os.posix_spawn'}:
        raise RuntimeError('OPERACAO_FORA_ESCOPO_C7')
    if event == 'import' and (args[0] == 'conversor' or args[0].startswith('conversor.')):
        raise RuntimeError('IMPORT_PRODUTO_PROIBIDO')
    if event == 'open' and isinstance(args[0], (str, bytes)):
        p = pathlib.Path(args[0]).resolve()
        write = bool(args[2] & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if write and not p.is_relative_to(WORK): raise RuntimeError('ESCRITA_FORA_AREA_C7')
        if not write and not (p.is_relative_to(WORK) or p.is_relative_to(PREFIX)):
            raise RuntimeError('LEITURA_FORA_ESCOPO_C7')
sys.addaudithook(guard)
import jsonschema, referencing, jsonschema_specifications
from jsonschema import Draft202012Validator
from referencing import Registry
class StrictError(ValueError): pass
def pairs(ps):
    result = {}
    for key, value in ps:
        if key in result: raise StrictError('PROPRIEDADE_DUPLICADA:' + key)
        result[key] = value
    return result
def constant(value): raise StrictError('CONSTANTE_NAO_JSON:' + value)
def finite_float(value):
    result=float(value)
    if not math.isfinite(result): raise StrictError('NUMERO_NAO_FINITO_NO_PARSER')
    return result
def strict(b):
    if b.startswith(b'\xef\xbb\xbf'): raise StrictError('BOM_PROIBIDO')
    return json.loads(b.decode('utf-8', errors='strict'), object_pairs_hook=pairs, parse_constant=constant, parse_float=finite_float)
def sha(b): return hashlib.sha256(b).hexdigest()
def pointer(path): return '/' + '/'.join(str(i).replace('~','~0').replace('/','~1') for i in path)
def error(e):
    result = {'tipo':type(e).__name__, 'mensagem':str(e)}
    if isinstance(e, json.JSONDecodeError): result.update(linha=e.lineno,coluna=e.colno,offset_caracteres=e.pos)
    return result
OUT = {'ambiente': {'python':platform.python_version(), 'executavel':sys.executable, 'plataforma':sys.platform, 'isolated':sys.flags.isolated,'dont_write_bytecode':sys.dont_write_bytecode,'dialeto':'Draft 2020-12 selecionado explicitamente','rede':'retrieval recusado e socket bloqueado por audit hook','ferramenta_sha256':sha(pathlib.Path(__file__).read_bytes())}, 'bibliotecas':[], 'parsing':[], 'schemas':[], 'fragmentos_relatorio':[], 'vetores':[], 'negativos_parser':[], 'sondas_schema':[], 'editorial':[], 'semantica':[]}
for name in ('jsonschema','referencing','jsonschema-specifications','attrs','rpds-py'):
    d = importlib.metadata.distribution(name)
    metadata = d.read_text('METADATA')
    OUT['bibliotecas'].append({'nome':name,'versao':d.version,'raiz':str(d.locate_file('')),'metadata_sha256':sha(metadata.encode('utf-8'))})
DOCS = {}
for file in sorted((ROOT / 'contratos_c').glob('*.json')):
    b=file.read_bytes(); row={'arquivo':file.name,'bytes':len(b),'sha256':sha(b),'utf8':True,'sem_BOM':not b.startswith(b'\xef\xbb\xbf'),'LF_final':b.endswith(b'\n'),'sem_CR':b'\r' not in b}
    try:
        b.decode('utf-8',errors='strict'); DOCS[file.name]=strict(b)
        row['status']='VALIDO' if isinstance(DOCS[file.name],dict) else 'INVALIDO'
        row['raiz_objeto']=isinstance(DOCS[file.name],dict)
    except (ValueError,UnicodeError) as e:
        row.update(status='INVALIDO',erro=error(e))
        if isinstance(e,UnicodeError): row['utf8']=False
        if isinstance(e,json.JSONDecodeError): row['erro']['offset_bytes_utf8']=len(b.decode('utf-8')[:e.pos].encode('utf-8'))
    OUT['parsing'].append(row)
for name,b in [('DUPLICADA',b'{"a":1,"a":2}'),('NAN',b'{"a":NaN}'),('INFINITY',b'{"a":Infinity}'),('MENOS_INFINITY',b'{"a":-Infinity}'),('BOM',b'\xef\xbb\xbf{}'),('UTF8_INVALIDO',b'{"a":"\xff"}'),('CONTEUDO_ADICIONAL',b'{} {}'),('TRUNCADO',b'{"a":'),('OVERFLOW_FLOAT_LOCAL',b'{"a":1e999}')]:
    try: strict(b); OUT['negativos_parser'].append({'id':name,'rejeitado':False})
    except (ValueError,UnicodeError) as e: OUT['negativos_parser'].append({'id':name,'rejeitado':True,'erro':error(e)})
# Apenas fragmentos intactos do texto inválido; nenhuma versão corrigida é criada.
text=(ROOT/'contratos_c/relatorio.schema.json').read_bytes().decode('utf-8')
lines=text.splitlines(keepends=True)
decoder=json.JSONDecoder(object_pairs_hook=pairs,parse_constant=constant,parse_float=finite_float)
for label,start in [('SEGUNDA_CONDICIONAL_L39',sum(map(len,lines[:38]))+4),('OBJETO_DEFS_L49',text.index('{',text.index('"$defs":')))]:
    try:
        obj,end=decoder.raw_decode(text,start)
        OUT['fragmentos_relatorio'].append({'fragmento':label,'inicio_caracteres':start,'fim_caracteres':end,'status':'VALIDO_COMO_FRAGMENTO','nota':'Não é validação do schema integral nem correção aplicada'})
    except ValueError as e: OUT['fragmentos_relatorio'].append({'fragmento':label,'status':'INVALIDO','erro':error(e)})
retrievals=[]
def no_network(uri):
    retrievals.append(uri)
    raise RuntimeError('REFERENCIA_EXTERNA_PROIBIDA')
registry=Registry(retrieve=no_network)
VALIDATORS={}
def walk(obj,path=()):
    if isinstance(obj,dict):
        yield path,obj
        for k,v in obj.items(): yield from walk(v,path+(k,))
    elif isinstance(obj,list):
        for i,v in enumerate(obj): yield from walk(v,path+(i,))
for name in ('evento.schema.json','mensagem.schema.json','relatorio.schema.json'):
    if name not in DOCS:
        OUT['schemas'].append({'arquivo':name,'status':'BLOQUEADO','motivo':'JSON_INVALIDO; metaschema e instâncias integrais não avaliados'})
        continue
    schema=DOCS[name]; refs=[]; operators=set(); graph={k:set() for k in schema['$defs']}; issues=[]
    for path,obj in walk(schema):
        operators.update(k for k in obj if k in ('allOf','oneOf','anyOf','not','if','then','else','required','additionalProperties','enum','const','type','minItems','maxItems'))
        if any(k in obj for k in ('$schema','$id','$dynamicRef','default','$data','contentEncoding','contentSchema')): issues.append({'path':pointer(path),'tipo':'PERFIL_OFFLINE_DIVERGENTE'})
        if '$ref' in obj:
            ref=obj['$ref']; target=ref.removeprefix('#/$defs/')
            ok=ref.startswith('#/$defs/') and target in schema['$defs'] and '/' not in target
            refs.append({'path':pointer(path+('$ref',)),'destino':ref,'resolvido_localmente':ok})
            if not ok: issues.append({'path':pointer(path),'tipo':'REF_INVALIDA'})
            if len(path)>=2 and path[0]=='$defs' and path[1] in graph and ok: graph[path[1]].add(target)
    def visit(n,anc):
        if n in anc: raise ValueError('CICLO_DE_REFS')
        for child in graph[n]: visit(child,anc|{n})
    for n in graph: visit(n,set())
    try:
        Draft202012Validator.check_schema(schema)
        if issues: raise ValueError('PERFIL_REF_INVALIDO')
        VALIDATORS[name]=Draft202012Validator(schema,registry=registry)
        OUT['schemas'].append({'arquivo':name,'status':'VALIDO','metaschema':'Draft202012Validator.check_schema sem erros','refs':refs,'ciclos':False,'operadores':sorted(operators),'issues':issues})
    except Exception as e: OUT['schemas'].append({'arquivo':name,'status':'INVALIDO','erro':error(e),'issues':issues})
HEADER='versao_contrato;subcaso_id;controle_win;grupo;afirmacoes_previstas;eixo_funcional;eixo_nativo;eixo_dacl;estado_execucao;vinculo_historico;revisao_historica;bloqueios_previstos;fonte_planejamento_ref;natureza'.split(';')
PLAN=[
('WIN-01','API','FLAGS_DIAGNOSTICAS','T04_AMBIENTE_PENDENTE'),('WIN-02','API','ALIAS_REAL|NOMES_DISTINTOS','ALIAS_8_3_NAO_DEMONSTRADO'),('WIN-03','API','UNICODE_ORDINAL|ERRO_API_NATIVA','T02_ERRO_API_NATIVA_BLOQUEADO'),('WIN-04','API','POSITIVOS_IDENTIDADE|HARDLINK_NOME_DISTINTO','T03_IDENTIDADE_PENDENTE'),('WIN-05','API','BASELINE_SEM_AUTORIZACAO','T04_AMBIENTE_PENDENTE'),('WIN-06','LINK','LINK_REGISTRO','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-07','LINK','LINK_CHAVE','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-08','LINK','LINK_LOCK','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-09','LINK','LINK_EVIDENCIAS','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-10','LINK','LINK_CABECAS','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-11-A','LINK','RAIZ_GIT','T04_AMBIENTE_PENDENTE'),('WIN-11-B','LINK','ANCESTRAL_REPOSITORIO|ANCESTRAL_APP','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-12','LINK','FONTE_LINK_MESMOS_BYTES','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-13-A','LINK','FONTE_LINK_INTERNA','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-13-B','LINK','FONTE_LINK_EXTERNA','CAPACIDADE_SYMLINK_PENDENTE'),('WIN-14','LINK','AUTORIDADE_CORPO_RECIBO','T05_SNAPSHOT_PENDENTE'),('WIN-15','MODO','OPCAO_CANONICOS','T04_AMBIENTE_PENDENTE'),('WIN-16','MODO','CLI_DOCUMENTOS|DTO_ISOLADO','T06_DEPENDENCIAS_PENDENTES'),('WIN-17','MODO','AUDITORIA_ROUNDTRIP','T04_AMBIENTE_PENDENTE'),('WIN-18','CHMOD','PROTOCOLO_DACL_FONTE','PORTAO_D'),('WIN-19','CHMOD','PROTOCOLO_DACL_RAIZ','PORTAO_D')]
b=(ROOT/'contratos_c/cobertura_21.csv').read_bytes()
rows=list(csv.reader(io.StringIO(b.decode('utf-8',errors='strict'),newline=''),delimiter=';',strict=True))
expected=[]
for sub,group,claims,block in PLAN:
    win=sub[:6]
    expected.append(['0.1.0-proposta-c5',sub,win,group,claims,*(['NÃO_VALIDADO']*3),'NAO_EXECUTADO','PROVISORIO_SEM_FONTE','PENDENTE','AUTORIZACAO_TESTES_PENDENTE|'+block,'MATRIZ_C2_AUDITADA','PLANEJAMENTO_NAO_EXECUTADO'])
csv_ok=rows==[HEADER]+expected and not b.startswith(b'\xef\xbb\xbf') and b'\r' not in b and b.endswith(b'\n')
OUT['csv']={'status':'VALIDO' if csv_ok else 'INVALIDO','cabecalho_exato':rows[0]==HEADER,'colunas_por_registro':[len(r) for r in rows],'registros':len(rows)-1,'subcasos_unicos':len({r[1] for r in rows[1:]}),'WIN_unicos':len({r[2] for r in rows[1:]}),'grupos':{g:sum(r[3]==g for r in rows[1:]) for g in ('API','LINK','MODO','CHMOD')},'todas_linhas_iguais_C5':csv_ok}
vectors=DOCS['vetores_de_contrato.json']; states=DOCS['estados.json']
by_id={v['vetor_id']:v for v in vectors['vetores']}
def check(label,condition,group='semantica',note=None):
    OUT[group].append({'id':label,'status':'VALIDO' if condition else 'INVALIDO','nota':note})
check('CATALOGO_DEZ_VETORES',set(vectors)=={'versao_contrato','natureza','referencias_modelo','vetores'} and vectors['natureza']=='SINTETICO_NAO_EXECUTADO' and len(by_id)==len(vectors['vetores'])==10 and set(by_id)=={f'V{i:02}' for i in range(1,11)},'editorial')
allowed_keys={'vetor_id','natureza','tipo_exemplo','exemplo','interpretacao','expectativa_documental','proibicao_inferencia'}
for v in vectors['vetores']:
    check('ROTULOS_'+v['vetor_id'],set(v)==allowed_keys and v['natureza']=='SINTETICO_NAO_EXECUTADO' and v['interpretacao']=='MODELO_SEM_EVIDENCIA_REAL' and v['expectativa_documental'] in ('ADMISSIVEL_COMO_MODELO','INCONCLUSIVO_COMO_EVIDENCIA'),'editorial')
    if v['vetor_id'] in ('V01','V02','V05','V09'):
        name='mensagem.schema.json' if v['vetor_id']=='V09' else 'evento.schema.json'
        errors=list(VALIDATORS[name].iter_errors(v['exemplo']))
        OUT['vetores'].append({'vetor':v['vetor_id'],'tipo':v['tipo_exemplo'],'metodo':'JSON_SCHEMA_DRAFT_2020_12','status':'VALIDO' if not errors else 'INVALIDO','schema':name,'erros':[{'path':pointer(e.absolute_path),'schema_path':pointer(e.absolute_schema_path),'validator':e.validator,'mensagem':e.message} for e in errors]})
# Projeções editoriais: verificações independentes de chaves/tipos, sem criar um schema de relatório substituto.
axis={'NÃO_VALIDADO','APROVADO','FALHOU'}
def projection(p):
    fields={'controle_win','subcaso_id','afirmacao_id','resultado_ensaio','funcional','nativo','DACL','fundamento','bloqueios'}
    return isinstance(p,dict) and set(p)==fields and p['controle_win'] in {r[2] for r in expected} and p['subcaso_id'] in {r[1] for r in expected} and p['controle_win']==p['subcaso_id'][:6] and isinstance(p['afirmacao_id'],str) and re.fullmatch(r'[A-Z][A-Z0-9_-]{0,63}',p['afirmacao_id']) is not None and p['resultado_ensaio'] in states['taxonomias']['resultado_ensaio'] and all(p[k] in axis for k in ('funcional','nativo','DACL')) and p['fundamento'] in ('MODELO_SINTETICO','NENHUM') and codes(p['bloqueios'])
def ids(value):
    return isinstance(value,list) and all(isinstance(v,str) and re.fullmatch(r'[A-Z][A-Z0-9_-]{0,63}',v) for v in value) and len(set(value))==len(value)
def codes(value):
    return isinstance(value,list) and all(isinstance(v,str) and re.fullmatch(r'[A-Z][A-Z0-9_]{0,95}',v) for v in value) and len(set(value))==len(value)
def component(name,value):
    schema={'$defs':DOCS['evento.schema.json']['$defs'],'$ref':'#/$defs/'+name}
    return Draft202012Validator(schema,registry=registry).is_valid(value)
for vid in ('V03','V04','V06','V07','V08','V10'):
    p=by_id[vid]['exemplo']; ok=True
    if vid in ('V03','V04'): ok=projection(p)
    elif vid=='V06': ok=set(p)=={'controle_win','subcaso_id','estado','observado','evidencia_refs','resultado_ensaio','funcional','nativo','DACL'} and p['estado']=='INDISPONIVEL_DECLARADA' and p['observado']['tipo']=='CODIGO_WIN32' and p['observado']['valor']==1314 and component('Observacao',p['observado']) and p['resultado_ensaio']=='SKIP' and all(p[k]=='NÃO_VALIDADO' for k in ('funcional','nativo','DACL'))
    elif vid=='V07': ok=set(p)=={'estado','precondicoes','interrupcoes','primeira_falha','falhas_adicionais','encerramento_comprovado','saidas_parciais_refs'} and p['estado']=='TIMEOUT' and p['encerramento_comprovado'] is None and p['primeira_falha'] is None and p['precondicoes']==p['falhas_adicionais']==[] and len(p['interrupcoes'])==1 and p['interrupcoes'][0]=={'tipo':'TIMEOUT','fase':'OPERACAO','evidencia_refs':['EVI_PARCIAL_MODELO'],'detalhe_seguro':'TIMEOUT_MODELO'} and p['saidas_parciais_refs']==['EVI_PARCIAL_MODELO']
    elif vid=='V08': ok=set(p)=={'estado','remocao_comprovada','residuo_preservado','evidencia_refs','falhas','resultado_funcional'} and p['estado']=='FALHOU' and p['remocao_comprovada'] is False and p['residuo_preservado'] is True and p['falhas']==[] and p['resultado_funcional']=='NÃO_VALIDADO' and p['evidencia_refs']==['EVI_PARCIAL_MODELO']
    elif vid=='V10': ok=set(p)=={'casos_modelados','situacao_cobertura','homologacao'} and len(p['casos_modelados'])==3 and all(projection(c) for c in p['casos_modelados']) and p['casos_modelados'][:2]==[by_id['V03']['exemplo'],by_id['V04']['exemplo']] and p['casos_modelados'][2]=={'controle_win':'WIN-18','subcaso_id':'WIN-18','afirmacao_id':'PROTOCOLO_DACL_FONTE','resultado_ensaio':'BLOQUEADO','funcional':'NÃO_VALIDADO','nativo':'NÃO_VALIDADO','DACL':'NÃO_VALIDADO','fundamento':'NENHUM','bloqueios':['PORTAO_D']} and p['situacao_cobertura']=='PARCIAL' and p['homologacao']=='NAO_CONCEDIDA_PELO_CONTRATO'
    OUT['vetores'].append({'vetor':vid,'tipo':by_id[vid]['tipo_exemplo'],'metodo':'CONFERENCIA_EDITORIAL_INDEPENDENTE','status':'VALIDO' if ok else 'INVALIDO','nota':'Não avaliado como instância integral de relatório'})
# Sondas puramente estruturais em cópias em memória, sem executar o conteúdo.
def probe(label,schema,obj,expected_valid):
    errors=list(VALIDATORS[schema].iter_errors(obj))
    OUT['sondas_schema'].append({'id':label,'schema':schema,'esperado_valido':expected_valid,'observado_valido':not errors,'coincide':(not errors)==expected_valid,'erros':[{'path':pointer(e.absolute_path),'schema_path':pointer(e.absolute_schema_path),'validator':e.validator,'mensagem':e.message} for e in errors]})
e=by_id['V01']['exemplo']; m=by_id['V09']['exemplo']
def mutate(obj,path,value=None,remove=False):
    x=copy.deepcopy(obj); dest=x
    for k in path[:-1]: dest=dest[k]
    if remove: del dest[path[-1]]
    else: dest[path[-1]]=value
    return x
for label,path,value,remove in [('EVENTO_EXTRA',['resultado'],'PASS',False),('EVENTO_FALTA_ID',['evento_id'],None,True),('EVENTO_VERSAO',['versao_contrato'],'9',False),('EVENTO_SEQ_ZERO',['sequencia'],0,False),('BOOLEANO_TEXTO',['observado','valor'],'true',False),('OBSERVADO_NULL',['observado','valor'],None,False),('TIPO_DESCONHECIDO',['observado','tipo'],'NOVO',False),('EVIDENCIA_DUPLICADA',['observado','evidencia_refs'],['EVI_MODELO_01','EVI_MODELO_01'],False),('FUNCIONAL_ALVO_NULL',['controle_win'],None,False)]: probe(label,'evento.schema.json',mutate(e,path,value,remove),False)
probe('AUSENCIA_COM_VALOR','evento.schema.json',mutate(by_id['V02']['exemplo'],['observado','valor'],False),False)
probe('AUSENCIA_SEM_MOTIVO','evento.schema.json',mutate(by_id['V02']['exemplo'],['observado','motivo'],None),False)
probe('BOOLEANO_FALSE_NAO_E_PASS','evento.schema.json',mutate(e,['observado','valor'],False),True)
winzero=copy.deepcopy(e); winzero['observado'].update(tipo='CODIGO_WIN32',valor=0)
probe('WIN32_ZERO_NAO_E_PASS','evento.schema.json',winzero,True)
fp=copy.deepcopy(e); fp.update(tipo_evento='FALHA_PERSISTENCIA',completude_observacao='INCOMPLETA',persistencia_registro='FALHA_DECLARADA',primeira_falha={'fase':'PERSISTENCIA','codigo_seguro':'FALHA_MODELO','camada':'OBSERVADOR','codigo_original':copy.deepcopy(e['observado']),'evidencia_refs':['EVI_MODELO_01']})
probe('PERSISTENCIA_MODELO','evento.schema.json',fp,True)
probe('PERSISTENCIA_SEM_DECLARACAO','evento.schema.json',mutate(fp,['persistencia_registro'],'NAO_ALEGADA'),False)
probe('PERSISTENCIA_CAMADA_INVALIDA','evento.schema.json',mutate(fp,['primeira_falha','camada'],'HELPER'),False)
probe('MENSAGEM_EXTRA_DISCO','mensagem.schema.json',mutate(m,['persistido'],True),False)
probe('REFERENCIA_SEM_ALVO','mensagem.schema.json',mutate(m,['evento_ref'],None),False)
probe('CORRESPONDENCIA_COM_HASH_NULL','mensagem.schema.json',mutate(m,['correlacao'],'CORRESPONDENCIA_DECLARADA'),False)
ack=copy.deepcopy(m); ack.update(tipo='ACK_DECLARADO',mensagem_origem_ref='MSG_ORIGEM_MODELO',confirmacao={'confirmacao_id':'CONF_MODELO','mensagem_confirmada_ref':'MSG_ORIGEM_MODELO','evento_id':'EV_MODELO_01','sequencia_evento':1,'hash_evento':copy.deepcopy(m['evento_ref']['hash_evento']),'semantica':'RECEBIMENTO_DECLARADO_SEM_PROVA_DE_DISCO'})
probe('ACK_DECLARADO_HASH_AUSENTE_NAO_VERIFICADO','mensagem.schema.json',ack,True)
probe('ACK_SEM_CONFIRMACAO','mensagem.schema.json',mutate(ack,['confirmacao'],None),False)
probe('ACK_SEMANTICA_DISCO','mensagem.schema.json',mutate(ack,['confirmacao','semantica'],'PERSISTIDO'),False)
incident=copy.deepcopy(m); incident.update(tipo='INCIDENTE_CORRELACAO',evento_ref=None,incidente={'codigo':'ACK_NAO_APRESENTADO','mensagem_refs':[],'evidencia_refs':[]})
probe('INCIDENTE_SEM_ALVO','mensagem.schema.json',incident,True)
probe('INCIDENTE_CORRESPONDENCIA','mensagem.schema.json',mutate(incident,['correlacao'],'CORRESPONDENCIA_DECLARADA'),False)
modelhash={'estado':'FABRICADO_PARA_ILUSTRACAO','sha256':'1'*64,'fonte_ref':'EVI_MODELO_01','revisao_ref':None}
h=mutate(e,['integridade_referencia'],modelhash)
probe('HASH_FABRICADO_MODELO','evento.schema.json',h,True)
probe('HASH_FABRICADO_REGISTRO','evento.schema.json',mutate(h,['natureza'],'REGISTRO_DECLARADO'),False)
# Contraexemplos delimitam a expressividade; aceitação estrutural é esperada e não é coerência.
probe('LIMITE_ACK_ID_DIVERGENTE','mensagem.schema.json',mutate(ack,['confirmacao','evento_id'],'EV_OUTRO_MODELO'),True)
probe('LIMITE_WIN_SUBCASO_DIVERGENTE','evento.schema.json',mutate(e,['subcaso_id'],'WIN-02'),True)
common=DOCS['evento.schema.json']['$defs']
check('DEFS_EVENTO_MENSAGEM_IDENTICAS',all(DOCS['mensagem.schema.json']['$defs'][k]==v for k,v in common.items()))
check('VERSOES_COMUNS',states['versao_contrato']==vectors['versao_contrato']==common['Versao']['const']=='0.1.0-proposta-c5')
check('DIALETO_EXPLICITO',states['dialeto_schemas']=='DRAFT_2020_12_OFFLINE_C5')
check('OBSERVACAO_SEPARADA_ESPERADO',common['Observacao']['required']!=common['Esperado']['required'])
check('43_RELACOES_SEM_EFEITOS',len(states['transicoes_documentais'])==43 and len({t['transicao_id'] for t in states['transicoes_documentais']})==43 and all(set(t)=={'transicao_id','dimensao','origem','destino','fundamento','referencia_regra','efeito'} and t['efeito']=='NENHUM' and t['origem'] in states['taxonomias'][t['dimensao']] and t['destino'] in states['taxonomias'][t['dimensao']] for t in states['transicoes_documentais']))
check('NAO_HA_SKIP_PARA_PASS',all(not(t['origem']=='SKIP' and t['destino']=='PASS') for t in states['transicoes_documentais']))
marco=states['marco_C5']
check('MARCO_19_CONTROLES_NAO_VALIDADOS',len(marco['controles'])==19 and {c['controle_win'] for c in marco['controles']}=={r[2] for r in expected} and all(c['estado']=='NÃO_VALIDADO' for c in marco['controles']))
check('BLOQUEIOS_PRESERVADOS',marco['runner']=='NÃO_IMPLEMENTADO' and marco['testes']=='PENDENTE' and marco['prontidao_para_executar'] is False and marco['vinculos_historicos']=='PROVISORIO_SEM_FONTE' and marco['dacl']=='NÃO_VALIDADO' and marco['politica_dacl']=='PARA_APROVAÇÃO' and marco['portoes']=={'C':'BLOQUEADOS','D':'BLOQUEADOS','E':'BLOQUEADOS'} and marco['conversoes_reais']=='BLOQUEADAS')
check('PROJECOES_WIN03_WIN18_BLOQUEADAS',by_id['V04']['exemplo']['resultado_ensaio']=='BLOQUEADO' and by_id['V10']['exemplo']['casos_modelados'][2]['DACL']=='NÃO_VALIDADO')
check('SEM_AGREGADO_HOMOLOGACAO_NO_MODELO',by_id['V10']['exemplo']['homologacao']=='NAO_CONCEDIDA_PELO_CONTRATO')
check('REFERENCIAS_MODELO', {r['referencia_id'] for r in vectors['referencias_modelo']}=={'EVI_MODELO_01','REGRA_MODELO_01','EVI_PARCIAL_MODELO'} and all(r['classe']=='MODELO_SINTETICO' and component('HashDeclarado',r['integridade']) for r in vectors['referencias_modelo']))
check('TAXONOMIAS_C5', states['taxonomias']=={'desenho':['ESPECIFICADO','PARCIAL','BLOQUEADO'],'implementacao':['NÃO_IMPLEMENTADO','IMPLEMENTACAO_DECLARADA','IMPLEMENTACAO_REVISADA_DOCUMENTALMENTE'],'autorizacao':['PENDENTE','AUTORIZADA_DECLARADA','NEGADA','REVOGADA'],'execucao':['NAO_INICIADA','PREPARACAO_DECLARADA','EM_ANDAMENTO_DECLARADO','ENCERRADA_DECLARADA','BLOQUEADA','INTERROMPIDA','TIMEOUT','CRASH','INCONCLUSIVA'],'resultado_ensaio':['NAO_EXECUTADO','PASS','FAIL','SKIP','BLOQUEADO','INCONCLUSIVO'],'resultado_funcional':['NÃO_VALIDADO','APROVADO','FALHOU'],'resultado_nativo':['NÃO_VALIDADO','APROVADO','FALHOU'],'resultado_dacl':['NÃO_VALIDADO','APROVADO','FALHOU'],'custodia':['NAO_DEFINIDA','DECLARADA','REVISAO_DOCUMENTAL','INCOMPLETA'],'integridade':['NAO_DISPONIVEL','DECLARADO','CONFERIDO_DOCUMENTALMENTE','DIVERGENTE','FABRICADO_PARA_ILUSTRACAO'],'cleanup':['NAO_SOLICITADO','NAO_INICIADO','CONCLUSAO_DECLARADA','NAO_COMPROVADO','FALHOU','RESIDUO_PRESERVADO'],'sentinelas':['NAO_OBSERVADAS','PRESERVACAO_DECLARADA','DIVERGENCIA_DECLARADA','INCONCLUSIVAS'],'vinculo_historico':['PROVISORIO_SEM_FONTE'],'revisao_historica':['PENDENTE']})
state_fields={'versao_contrato','natureza_catalogo','dialeto_schemas','taxonomias','etapas_origem','tipos_evento','transicoes_documentais','marco_C5','referencias_documentais'}
check('ESTADOS_RAIZ_FECHADA',set(states)==state_fields and states['natureza_catalogo']=='PROPOSTA_DECLARATIVA','editorial')
check('ETAPAS_TIPOS_EVENTO',states['etapas_origem']==common['Etapa']['enum'] and states['tipos_evento']==DOCS['evento.schema.json']['properties']['tipo_evento']['enum'],'editorial')
check('MARCO_CAMPOS_E_TECNICOS',set(marco)=={'desenho_tecnico','runner','testes','prontidao_para_executar','controles','vinculos_historicos','dacl','politica_dacl','portoes','conversoes_reais'} and marco['desenho_tecnico']=={'T01':'ESPECIFICADO','T02':'BLOQUEADO','T03':'PARCIAL','T04':'PARCIAL','T05':'PARCIAL','T06':'ESPECIFICADO','T07':'PARCIAL'} and all(set(c)=={'controle_win','estado'} for c in marco['controles']),'editorial')
transitions={
'desenho':[('PARCIAL','ESPECIFICADO'),('ESPECIFICADO','PARCIAL'),('PARCIAL','BLOQUEADO'),('ESPECIFICADO','BLOQUEADO'),('BLOQUEADO','PARCIAL')],
'implementacao':[('NÃO_IMPLEMENTADO','IMPLEMENTACAO_DECLARADA'),('IMPLEMENTACAO_DECLARADA','IMPLEMENTACAO_REVISADA_DOCUMENTALMENTE')],
'autorizacao':[('PENDENTE','AUTORIZADA_DECLARADA'),('PENDENTE','NEGADA'),('AUTORIZADA_DECLARADA','REVOGADA')],
'execucao':[('NAO_INICIADA','PREPARACAO_DECLARADA'),('PREPARACAO_DECLARADA','EM_ANDAMENTO_DECLARADO'),('PREPARACAO_DECLARADA','BLOQUEADA')]+[('EM_ANDAMENTO_DECLARADO',x) for x in ('ENCERRADA_DECLARADA','INTERROMPIDA','TIMEOUT','CRASH','INCONCLUSIVA')],
'resultado_ensaio':[('NAO_EXECUTADO',x) for x in ('PASS','FAIL','SKIP','BLOQUEADO','INCONCLUSIVO')],
'resultado_funcional':[('NÃO_VALIDADO',x) for x in ('APROVADO','FALHOU')],
'resultado_nativo':[('NÃO_VALIDADO',x) for x in ('APROVADO','FALHOU')],
'resultado_dacl':[('NÃO_VALIDADO',x) for x in ('APROVADO','FALHOU')],
'custodia':[('NAO_DEFINIDA','DECLARADA'),('DECLARADA','REVISAO_DOCUMENTAL'),('DECLARADA','INCOMPLETA'),('REVISAO_DOCUMENTAL','INCOMPLETA')],
'integridade':[('NAO_DISPONIVEL','DECLARADO'),('DECLARADO','CONFERIDO_DOCUMENTALMENTE'),('DECLARADO','DIVERGENTE')],
'cleanup':[('NAO_INICIADO',x) for x in ('CONCLUSAO_DECLARADA','NAO_COMPROVADO','FALHOU','RESIDUO_PRESERVADO')],
'sentinelas':[('NAO_OBSERVADAS',x) for x in ('PRESERVACAO_DECLARADA','DIVERGENCIA_DECLARADA','INCONCLUSIVAS')]}
expected_edges={(d,a,b) for d,ps in transitions.items() for a,b in ps}
actual_edges={(t['dimensao'],t['origem'],t['destino']) for t in states['transicoes_documentais']}
check('TRANSICOES_CONJUNTO_EXATO_C5',actual_edges==expected_edges and len(actual_edges)==len(states['transicoes_documentais'])==43)
refs=states['referencias_documentais']; editorial_refs={r['referencia_id'] for r in refs}
check('REFERENCIAS_ESTADOS_FECHADAS',len(editorial_refs)==len(refs) and all(set(r)=={'referencia_id','classe','integridade','versao_rotulo'} and component('ID',r['referencia_id']) and r['classe'] in ('DOCUMENTO_REFERENCIA','MODELO_SINTETICO') and component('HashDeclarado',r['integridade']) and (r['versao_rotulo'] is None or component('ID',r['versao_rotulo'])) for r in refs),'editorial')
check('TRANSICOES_CAMPOS_REFERENCIAS',all(component('ID',t['transicao_id']) and t['referencia_regra'] in editorial_refs and t['fundamento'] in ('DOCUMENTO_REVISAO','REGISTRO_AUTORIZACAO','EVIDENCIA_EXECUCAO','CORRECAO_RASTREAVEL','REGISTRO_CUSTODIA') for t in states['transicoes_documentais']),'editorial')
check('CATALOGO_FONTE_CSV',all(r[12] in editorial_refs for r in expected))
check('ENUMS_COMUNS_CATALOGO',common['HashDeclarado']['properties']['estado']['enum']==states['taxonomias']['integridade'] and common['CustodiaRef']['properties']['estado']['enum']==states['taxonomias']['custodia'])
check('REFERENCIAS_MODELO_CHAVES_TIPOS',all(set(r)=={'referencia_id','classe','integridade'} and component('ID',r['referencia_id']) for r in vectors['referencias_modelo']),'editorial')
type_by_id={'V01':'EVENTO_COMPLETO','V02':'EVENTO_COMPLETO','V03':'AFIRMACAO_EDITORIAL','V04':'AFIRMACAO_EDITORIAL','V05':'EVENTO_COMPLETO','V06':'CAPACIDADE_EDITORIAL','V07':'EXECUCAO_EDITORIAL','V08':'CLEANUP_EDITORIAL','V09':'MENSAGEM_COMPLETA','V10':'RELATORIO_EDITORIAL'}
check('VETORES_VARIANTES_CODIGOS',all(v['tipo_exemplo']==type_by_id[v['vetor_id']] and component('CodigoSeguro',v['proibicao_inferencia']) for v in vectors['vetores']),'editorial')
check('PROJECOES_CODIGOS_REFS',projection(by_id['V03']['exemplo']) and projection(by_id['V04']['exemplo']) and ids(by_id['V06']['exemplo']['evidencia_refs']) and ids(by_id['V07']['exemplo']['saidas_parciais_refs']) and ids(by_id['V08']['exemplo']['evidencia_refs']) and all(projection(p) for p in by_id['V10']['exemplo']['casos_modelados']),'editorial')
# Sondas negativas de consistência declarativa são distintas das sondas de JSON Schema.
OUT['negativos_editoriais']=[]
bad=mutate(by_id['V04']['exemplo'],['funcional'],'PROMOVIDO')
OUT['negativos_editoriais'].append({'id':'PROJECAO_ENUM_INVALIDO','rejeitado':not projection(bad)})
bad=mutate(by_id['V04']['exemplo'],['extra'],'MODELO')
OUT['negativos_editoriais'].append({'id':'PROJECAO_CAMPO_EXTRA','rejeitado':not projection(bad)})
bad=mutate(by_id['V04']['exemplo'],['subcaso_id'],'WIN-02')
OUT['negativos_editoriais'].append({'id':'PROJECAO_PAR_WIN_INCOERENTE','rejeitado':not projection(bad)})
bad=mutate(by_id['V04']['exemplo'],['bloqueios'],['CODIGO','CODIGO'])
OUT['negativos_editoriais'].append({'id':'PROJECAO_CODIGO_DUPLICADO','rejeitado':not projection(bad)})
OUT['retrievals_externos']=retrievals
OUT['hashes_copias_depois']=[{'arquivo':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(ROOT.rglob('*')) if p.is_file()]
(WORK/'resultados_estruturais.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:OUT[k] for k in ('ambiente','parsing','fragmentos_relatorio','csv','vetores','editorial','semantica','retrievals_externos')},ensure_ascii=False,indent=2))
print('SCHEMAS',[(s['arquivo'],s['status']) for s in OUT['schemas']])
print('SONDAS',len(OUT['sondas_schema']),'COINCIDENCIAS',sum(s['coincide'] for s in OUT['sondas_schema']))
```
