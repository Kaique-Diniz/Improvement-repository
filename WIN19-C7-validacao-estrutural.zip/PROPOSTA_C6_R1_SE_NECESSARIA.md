# Proposta C6-R1 — não aplicada

23/11/2026. Exige autorização própria, novo diretório/arquivo e revisão independente.
O arquivo C6 publicado, a cópia usada em C7 e seus manifestos permanecem intactos.

## Alteração textual mínima recomendada

No fechamento da primeira condicional do allOf raiz, inserir um único `}` antes
da vírgula da linha 38. Proposta de diff, como texto, não como patch aplicado:

```diff
--- C6/contratos_c/relatorio.schema.json
+++ C6-R1-proposta/contratos_c/relatorio.schema.json
@@ -38,2 +38,2 @@
-    }}},
+    }}}},
     {"if": {"properties": {"natureza": {"const": "REGISTRO_DECLARADO"}}}, "then": {"properties": {
```

A intenção é fechar o objeto condicional ainda aberto, sem substituir campos,
valores, operadores, enums, guardas ou estados. A proposta não foi aplicada nem
avaliada como schema completo em memória ou em arquivo. Os fragmentos intactos
L39 e L49 foram apenas interpretados separadamente para delimitar a falha.

## Fronteira sintática/semântica

Adicionar o delimitador faltante visa tornar interpretável a estrutura pretendida;
não é nova regra de autorização, mudança de política ou correção de comportamento
Windows. Ainda assim a interpretação e as guardas integrais precisam de validação
após autorização: não se promete que a inserção seja suficiente para aprovação
formal ou que não haja outras divergências. A versão proposta atual identifica o
perfil C5; a nomenclatura/versionamento da revisão corrigida deve ser aprovada,
sem coerção silenciosa e sem sobrescrever a origem.

## Condições de uma autorização C6-R1

1. Nomear o caminho novo e autorizar somente a correção sintática delimitada.
2. Preservar os bytes C6 originais; produzir novo arquivo, diff e hash/tamanho reais.
3. Repetir parsing estrito e check_schema Draft 2020-12 offline do novo arquivo.
4. Conferir as referências locais, aciclicidade e tipos comuns contra evento e
   mensagem; avaliar required/closure/condicionais/cardinalidades do relatório.
5. Usar modelos completos sintéticos autorizados para conferir 21 casos, conjunto
   exato separado, falta de evidência, preparação falha, SKIP, eixos independentes,
   bloqueios WIN-03/18/19 e ausência de agregado homologador.
6. Registrar qualquer achado adicional, sem expandir silenciosamente a correção.
7. Manter produto, candidatas, DACL, histórico provisório e conversões bloqueados.

Não foi produzido hash de arquivo corrigido inexistente, nem se autorizou execução
WIN, implementação do runner C ou publicação. Parar para revisão desta proposta.
