# C7-05 — consistência declarativa, separada da estrutura

23/11/2026. Conferência sobre dados e relações documentais. Não comprova veracidade,
autoria, custódia, autorização ou segurança. Resultado global deste eixo: PARCIAL,
pois o schema integral de relatório não pode ser interpretado.

## Relações efetivamente verificadas

| Verificação | Estado | Ressalva |
| --- | --- | --- |
| DEFS_EVENTO_MENSAGEM_IDENTICAS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| VERSOES_COMUNS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| DIALETO_EXPLICITO | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| OBSERVACAO_SEPARADA_ESPERADO | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| 43_RELACOES_SEM_EFEITOS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| NAO_HA_SKIP_PARA_PASS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| MARCO_19_CONTROLES_NAO_VALIDADOS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| BLOQUEIOS_PRESERVADOS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| PROJECOES_WIN03_WIN18_BLOQUEADAS | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| SEM_AGREGADO_HOMOLOGACAO_NO_MODELO | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| REFERENCIAS_MODELO | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| TAXONOMIAS_C5 | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| TRANSICOES_CONJUNTO_EXATO_C5 | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| CATALOGO_FONTE_CSV | VALIDO | Conferência declarativa limitada às peças interpretáveis |
| ENUMS_COMUNS_CATALOGO | VALIDO | Conferência declarativa limitada às peças interpretáveis |

| Conferência editorial | Estado |
| --- | --- |
| CATALOGO_DEZ_VETORES | VALIDO |
| ROTULOS_V01 | VALIDO |
| ROTULOS_V02 | VALIDO |
| ROTULOS_V03 | VALIDO |
| ROTULOS_V04 | VALIDO |
| ROTULOS_V05 | VALIDO |
| ROTULOS_V06 | VALIDO |
| ROTULOS_V07 | VALIDO |
| ROTULOS_V08 | VALIDO |
| ROTULOS_V09 | VALIDO |
| ROTULOS_V10 | VALIDO |
| ESTADOS_RAIZ_FECHADA | VALIDO |
| ETAPAS_TIPOS_EVENTO | VALIDO |
| MARCO_CAMPOS_E_TECNICOS | VALIDO |
| REFERENCIAS_ESTADOS_FECHADAS | VALIDO |
| TRANSICOES_CAMPOS_REFERENCIAS | VALIDO |
| REFERENCIAS_MODELO_CHAVES_TIPOS | VALIDO |
| VETORES_VARIANTES_CODIGOS | VALIDO |
| PROJECOES_CODIGOS_REFS | VALIDO |

## Leitura dos achados

A versão comum é 0.1.0-proposta-c5. As definições comuns dos schemas interpretáveis
coincidem, incluindo enums de integridade/custódia; etapas/tipos de evento coincidem
com estados. As 43 arestas foram confrontadas com os pares propostos em C5, têm
identificadores únicos, fundamentos previstos e efeito NENHUM. Origem/destino
pertencem à mesma taxonomia. Não há aresta SKIP→PASS nem execução de transições.

WIN-03 mantém o ramo nativo bloqueado no CSV e modelos; WIN-18/19 não recebem
aprovação DACL. Ausência usa null/estado/motivo, com rejeições estruturais de
combinações inconsistentes. ACK declarado admite hash indisponível apenas sem
alegar correspondência; hashes null não são comparados como prova de igualdade.
Timeout, crash e setup pertencem a estados/declarações distintos; V05/V07/V08
ilustram preparação falha, interrupção e cleanup sem gerar aprovação de segurança.
Não houve execução de timeout, crash, API, cleanup de laboratório ou persistência.

## Limites S/P demonstrados

LIMITE_ACK_ID_DIVERGENTE foi aceito pelo schema de mensagem: IDs redundantes não
são comparados dinamicamente. LIMITE_WIN_SUBCASO_DIVERGENTE foi aceito pelo schema
de evento: os enums individuais não garantem seu par. São limites explicitamente
previstos na C5, não prova de que tais dados sejam semanticamente válidos. As
verificações editoriais separadas rejeitam pares incoerentes nas projeções.

Também não são comprovados por schema: unicidade por chave em objetos, conjunto
exato de 21 casos por mera cardinalidade, ordem factual, existência/autenticidade
de referências, bytes de hash, autorização legítima, ACK durável e fonte primária.
Nenhum default promove estados. Os nomes de 19 controles e os modelos não
confirmam os vínculos históricos, que permanecem PROVISORIO_SEM_FONTE.

## Verificações impedidas ou fora do escopo

- Confronto estrutural dos três schemas e seus campos/guardas integrais: BLOQUEADO
  no relatório; definições textualmente copiadas não substituem interpretação formal.
- Comportamento do relatório para 20/21/22 casos, guardas de SKIP/preparação,
  autorização real e eixos DACL: não avaliado integralmente; depende de C6-R1.
- Fatos de execução, metadados Windows, DACL efetiva, prova de persistência,
  custódia privada e JUnit original: NÃO_VALIDADO e não autorizados nesta C7.
- Limites globais de bytes/tempo/fluxo/retenção: PARA_REVISÃO; nenhum valor novo
  foi inserido nos contratos para facilitar o processamento.
