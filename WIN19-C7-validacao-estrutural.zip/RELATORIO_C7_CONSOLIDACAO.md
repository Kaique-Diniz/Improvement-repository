# WIN19-C7 — consolidação da validação estrutural isolada

23/11/2026 — America/Sao_Paulo. Procedimentos independentes em Linux/Python 3.12.14,
sem módulos do produto, Windows, pytest, runner C, Git ou resolução por rede.

**O conjunto obrigatório C6 está REPROVADO_ESTRUTURALMENTE:** o schema de relatório
não é JSON interpretável. Cinco arquivos concluíram as verificações estruturais
aplicáveis sem divergências observadas; isso não aprova controles de segurança.

## Resultado individual

| Contrato | Sintaxe | Metaschema | Estado C7 | Alcance |
| --- | --- | --- | --- | --- |
| evento.schema.json | VALIDO | VALIDO | APROVADO_ESTRUTURALMENTE | Draft 2020-12; V01/V02/V05 conformes; sondas estruturais limitadas |
| mensagem.schema.json | VALIDO | VALIDO | APROVADO_ESTRUTURALMENTE | Draft 2020-12; V09 conforme; correlação factual não demonstrada |
| estados.json | VALIDO | NAO_APLICAVEL_DADO | APROVADO_ESTRUTURALMENTE | Contrato editorial; taxonomias e 43 relações; sem schema próprio |
| relatorio.schema.json | INVALIDO | BLOQUEADO | REPROVADO_ESTRUTURALMENTE | JSONDecodeError L39 C5; validação formal integral impedida |
| cobertura_21.csv | VALIDO | NAO_APLICAVEL_CSV | APROVADO_ESTRUTURALMENTE | CSV estrito; cabeçalho/14 colunas/21 registros/19 WIN; tabela C5 |
| vetores_de_contrato.json | VALIDO | NAO_APLICAVEL_CATALOGO | APROVADO_ESTRUTURALMENTE | 4 exemplos completos por schema; 6 projeções pelo contrato editorial |

`NAO_APLICAVEL_*` descreve o método: estados, CSV e catálogo de vetores não são
schemas. Não significa validação formal do relatório, nem verificação dispensada
por conveniência. Seus formatos foram examinados por parsing e verificações do
contrato editorial, com os limites indicados nos relatórios específicos.

## Execução e achados

1. ZIP C6: 19.872 bytes, oito entradas exatas, nomes únicos/seguros, sem links
   nos metadados, CRC íntegro. Manifesto: 727 bytes, sete registros exatos; todos
   os tamanhos e hashes confirmados antes de criar cópias em pasta exclusiva.
2. Cinco JSON: quatro interpretáveis; relatório inválido L39/C5, offset de
   caracteres 3110, offset de bytes UTF-8 3118, ambos base zero. Mensagem real:
   `Expecting property name enclosed in double quotes`.
3. Duas validações efetivas de metaschema Draft 2020-12 concluídas sem erros.
   Schema de relatório: BLOQUEADO por sintaxe, sem validação formal integral.
   Fragmentos intactos posteriores foram interpretados separadamente; isso não
   produz versão corrigida nem demonstra aprovação do schema completo.
4. CSV: cabeçalho exato, 14 colunas por linha, 21 registros/21 subcasos/19 WIN,
   grupos API=5, LINK=11, MODO=3, CHMOD=2; pares e conteúdos confrontados com C5.
5. V01/V02/V05/V09 conformes aos schemas de evento/mensagem. V03/V04/V06/V07/
   V08/V10 examinados como projeções editoriais; nenhum completado artificialmente.
6. Rodada final de sondas independentes: 28 avaliações de schema, sendo 20
   rejeições previstas e 8 aceitações previstas; 28 resultados concordantes.
   Inclui dois contraexemplos admitidos estruturalmente que delimitam regras S.
   Nove verificações negativas do parser e quatro editoriais rejeitaram suas
   entradas. São verificações da C7, não 41 testes WIN ou resultado pytest.
7. Dezenove verificações editoriais e quinze relações declarativas registradas,
   sem divergências nas peças interpretáveis. O confronto integral envolvendo
   os três schemas permanece PARCIAL porque o relatório não pode ser interpretado.
8. Originais e cópias: oito arquivos novamente idênticos por bytes/hash; ZIP e
   manifesto C6 preservados. A candidata R1-FIX não foi acessada nesta validação.

A validação foi executada em duas invocações da ferramenta temporária: uma inicial
e outra ampliada para checar mais relações, tipos e entradas negativas. Os números
acima são da última invocação, não soma das rodadas. Não houve alteração dos
contratos entre elas nem correção aplicada para obter resultados favoráveis.

## Impacto e encaminhamento

O erro sintático impede qualquer uso formal do schema integral de relatório e
bloqueia a aprovação estrutural do conjunto. A proposta é inserir apenas um `}`
no fechamento da primeira condicional de `allOf`, submetida a C6-R1 separada.
Nenhuma versão corrigida foi gravada, avaliada integralmente ou aprovada nesta C7.
A falha ocorreu na materialização C6 e foi preservada; não será corrigida sem a
revisão autorizada. Ver DIAGNOSTICO_RELATORIO_SCHEMA e PROPOSTA_C6_R1_SE_NECESSARIA.

## Preservação dos bytes

ZIP antes/depois: `ee9cd82da311ef8ea003f3eba249a1c9967d46cd258a10dd813e706848e82f3a`.
Manifesto antes/depois: `a72a1800441cdb1b4e1a156759a1e45eb7ae1c3f29d674146403f26a179bc796`.

| Arquivo | Bytes antes/depois | SHA-256 antes = original depois = cópia depois |
| --- | --- | --- |
| INDICE_ENTREGA_C6.md | 11055 | fced95145e89d6d85a6670549b3bec1c90c58f2d821ea8cbe0e878bedefc8bd6 |
| MANIFESTO_SHA256_C6 | 727 | a72a1800441cdb1b4e1a156759a1e45eb7ae1c3f29d674146403f26a179bc796 |
| contratos_c/cobertura_21.csv | 5305 | 5a7e77e6ce8690e6153b512482db859184d3d8533e40a5e11e0bfd8a65ebf599 |
| contratos_c/estados.json | 13013 | 27c3f56e9e657afb4743f18dadead8de05e234d8d5eb5318cb48ab68dae3ea77 |
| contratos_c/evento.schema.json | 10180 | 682edd46b9bd41d70a25f7341ef6844c7adcd005686982cadf5eb81f152f567d |
| contratos_c/mensagem.schema.json | 10938 | d64e545a02524f6bce02c3541518a7d04c04ad886cdd8198514327bd5be32e98 |
| contratos_c/relatorio.schema.json | 20836 | ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6 |
| contratos_c/vetores_de_contrato.json | 10711 | ed00b1e28d07ca669ccc488bd3d5c403cb64768da554e187bfeba64ceca9a447 |

A igualdade é evidência local de preservação dos bytes examinados; não atesta o
host Windows, a custódia privada ou fatos anteriores que não foram medidos.

## Estados preservados

Portão B encerrado documentalmente; C5 especificada documentalmente; C6 materializada
com ressalvas. Runner C NÃO_IMPLEMENTADO; autorização de testes PENDENTE;
WIN-01–WIN-19/DACL NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE; T01/T06 ESPECIFICADO;
T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL; política D01–D10 PARA_APROVAÇÃO;
C/D/E BLOQUEADOS; conversões reais BLOQUEADAS; prontidão para ensaios false.

Entrega encerrada para revisão independente. Sem ZIP, publicação, commit, push,
merge, worktree, alteração de produto, dependências, privilégios, ACLs ou contas.
