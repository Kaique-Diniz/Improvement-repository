# C7-04 — dez vetores sintéticos

23/11/2026. Todos permanecem SINTETICO_NAO_EXECUTADO. Os rótulos C7 VALIDO/INVALIDO
referem-se à estrutura/contrato editorial; não são PASS/FAIL de ensaio Windows.

| Vetor | Tipo | Método | Resultado C7 |
| --- | --- | --- | --- |
| V01 | EVENTO_COMPLETO | JSON_SCHEMA_DRAFT_2020_12 | VALIDO |
| V02 | EVENTO_COMPLETO | JSON_SCHEMA_DRAFT_2020_12 | VALIDO |
| V03 | AFIRMACAO_EDITORIAL | CONFERENCIA_EDITORIAL_INDEPENDENTE | VALIDO |
| V04 | AFIRMACAO_EDITORIAL | CONFERENCIA_EDITORIAL_INDEPENDENTE | VALIDO |
| V05 | EVENTO_COMPLETO | JSON_SCHEMA_DRAFT_2020_12 | VALIDO |
| V06 | CAPACIDADE_EDITORIAL | CONFERENCIA_EDITORIAL_INDEPENDENTE | VALIDO |
| V07 | EXECUCAO_EDITORIAL | CONFERENCIA_EDITORIAL_INDEPENDENTE | VALIDO |
| V08 | CLEANUP_EDITORIAL | CONFERENCIA_EDITORIAL_INDEPENDENTE | VALIDO |
| V09 | MENSAGEM_COMPLETA | JSON_SCHEMA_DRAFT_2020_12 | VALIDO |
| V10 | RELATORIO_EDITORIAL | CONFERENCIA_EDITORIAL_INDEPENDENTE | VALIDO |

V01/V02/V05 foram submetidos integralmente ao schema de evento; V09 ao de mensagem.
V03/V04 são projeções de afirmações; V06 de capacidade; V07 de execução; V08 de
cleanup; V10 de relatório parcial. As seis projeções foram examinadas por chaves,
tipos, enumerações e relações documentais aplicáveis. Não foi construído schema
integral substituto de relatório nem adicionados campos às projeções.

O catálogo possui as quatro chaves propostas, os dez IDs únicos e as referências
de modelo permitidas. As projeções preservam ausências explícitas, SKIP fabricado,
timeout sem conclusão comprovada, resíduo preservado e resultados de eixos
independentes. V04 e a projeção WIN-18 de V10 permanecem bloqueadas/NÃO_VALIDADO.
O true de V01 é indicador fabricado HELPER; o 1314 de V06 é modelo, não erro nativo
medido. V03/V10 ilustram resultado funcional favorável sem comprovar execução.

## Evidência por vetor

```json
[
  {
    "vetor": "V01",
    "tipo": "EVENTO_COMPLETO",
    "metodo": "JSON_SCHEMA_DRAFT_2020_12",
    "status": "VALIDO",
    "schema": "evento.schema.json",
    "erros": []
  },
  {
    "vetor": "V02",
    "tipo": "EVENTO_COMPLETO",
    "metodo": "JSON_SCHEMA_DRAFT_2020_12",
    "status": "VALIDO",
    "schema": "evento.schema.json",
    "erros": []
  },
  {
    "vetor": "V05",
    "tipo": "EVENTO_COMPLETO",
    "metodo": "JSON_SCHEMA_DRAFT_2020_12",
    "status": "VALIDO",
    "schema": "evento.schema.json",
    "erros": []
  },
  {
    "vetor": "V09",
    "tipo": "MENSAGEM_COMPLETA",
    "metodo": "JSON_SCHEMA_DRAFT_2020_12",
    "status": "VALIDO",
    "schema": "mensagem.schema.json",
    "erros": []
  },
  {
    "vetor": "V03",
    "tipo": "AFIRMACAO_EDITORIAL",
    "metodo": "CONFERENCIA_EDITORIAL_INDEPENDENTE",
    "status": "VALIDO",
    "nota": "Não avaliado como instância integral de relatório"
  },
  {
    "vetor": "V04",
    "tipo": "AFIRMACAO_EDITORIAL",
    "metodo": "CONFERENCIA_EDITORIAL_INDEPENDENTE",
    "status": "VALIDO",
    "nota": "Não avaliado como instância integral de relatório"
  },
  {
    "vetor": "V06",
    "tipo": "CAPACIDADE_EDITORIAL",
    "metodo": "CONFERENCIA_EDITORIAL_INDEPENDENTE",
    "status": "VALIDO",
    "nota": "Não avaliado como instância integral de relatório"
  },
  {
    "vetor": "V07",
    "tipo": "EXECUCAO_EDITORIAL",
    "metodo": "CONFERENCIA_EDITORIAL_INDEPENDENTE",
    "status": "VALIDO",
    "nota": "Não avaliado como instância integral de relatório"
  },
  {
    "vetor": "V08",
    "tipo": "CLEANUP_EDITORIAL",
    "metodo": "CONFERENCIA_EDITORIAL_INDEPENDENTE",
    "status": "VALIDO",
    "nota": "Não avaliado como instância integral de relatório"
  },
  {
    "vetor": "V10",
    "tipo": "RELATORIO_EDITORIAL",
    "metodo": "CONFERENCIA_EDITORIAL_INDEPENDENTE",
    "status": "VALIDO",
    "nota": "Não avaliado como instância integral de relatório"
  }
]
```

## Rejeições editoriais em cópias em memória

```json
[
  {
    "id": "PROJECAO_ENUM_INVALIDO",
    "rejeitado": true
  },
  {
    "id": "PROJECAO_CAMPO_EXTRA",
    "rejeitado": true
  },
  {
    "id": "PROJECAO_PAR_WIN_INCOERENTE",
    "rejeitado": true
  },
  {
    "id": "PROJECAO_CODIGO_DUPLICADO",
    "rejeitado": true
  }
]
```

As rejeições acima são de verificações editoriais independentes: enum desconhecido,
chave extra, par WIN/subcaso incoerente e código repetido. Não são rejeições pelo
schema integral de relatório, que permanece inválido. Nenhum vetor C6 foi alterado.
