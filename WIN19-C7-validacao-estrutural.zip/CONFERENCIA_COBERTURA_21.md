# C7 — cobertura declarativa 21/19

23/11/2026. CSV lido em UTF-8 estrito, sem BOM/CR, com LF final. csv.reader stdlib,
delimitador explícito `;`, strict=True, sem Sniffer, interpretação de fórmulas ou
seletores de pytest. Cabeçalho e cada uma das 21 linhas comparados ao conteúdo
fechado da tabela C5. Nenhum campo/linha adicional observado.

```json
{
  "status": "VALIDO",
  "cabecalho_exato": true,
  "colunas_por_registro": [
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14,
    14
  ],
  "registros": 21,
  "subcasos_unicos": 21,
  "WIN_unicos": 19,
  "grupos": {
    "API": 5,
    "LINK": 11,
    "MODO": 3,
    "CHMOD": 2
  },
  "todas_linhas_iguais_C5": true
}
```

As duplicações por controle são exclusivamente WIN-11-A/B e WIN-13-A/B; todos os
subcasos são únicos. Correspondência controle/subcaso conferida linha a linha.
Afirmações e bloqueios separados por pipe preservam o planejamento, não comandos.
WIN-03 inclui UNICODE_ORDINAL e ERRO_API_NATIVA, com bloqueio nativo explícito.
WIN-18/19 mantêm PORTAO_D; todas as 21 linhas têm AUTORIZACAO_TESTES_PENDENTE,
três eixos NÃO_VALIDADO, estado NAO_EXECUTADO, vínculo PROVISORIO_SEM_FONTE e
revisão PENDENTE. Fonte MATRIZ_C2_AUDITADA existe no catálogo editorial de estados;
a referência não autentica o JUnit Windows histórico.

Estado C7: APROVADO_ESTRUTURALMENTE para este CSV e o contrato de planejamento.
Nenhum resultado observado, vínculo primário ou autorização foi acrescentado.
