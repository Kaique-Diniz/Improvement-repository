# WIN19-C7 — índice da entrega para auditoria

23/11/2026 — America/Sao_Paulo. Diretório exclusivo de relatórios:
`/workspace/work/WIN19-C7-VALIDACAO-20261123`.
Área temporária separada de execução independente:
`/workspace/work/win19-c7-trabalho-p4L0UV`, com cópias C6 e evidências intermediárias.
Nenhum arquivo foi escrito na candidata, no Git ou na origem C6.

## Documentos entregues

1. [RELATORIO_C7_CONSOLIDACAO.md](RELATORIO_C7_CONSOLIDACAO.md) — resultados, impacto, preservação antes/depois.
2. [MATRIZ_C7_VALIDACAO_6_ARQUIVOS.csv](MATRIZ_C7_VALIDACAO_6_ARQUIVOS.csv) — estados individuais e limites por arquivo.
3. [DIAGNOSTICO_RELATORIO_SCHEMA.md](DIAGNOSTICO_RELATORIO_SCHEMA.md) — erro real, offsets, delimitação e fragmentos.
4. [VALIDACAO_JSON_SCHEMA_OFFLINE.md](VALIDACAO_JSON_SCHEMA_OFFLINE.md) — metaschema, referências, 28 sondas e erros.
5. [VALIDACAO_VETORES_V01_V10.md](VALIDACAO_VETORES_V01_V10.md) — quatro completos e seis projeções editoriais.
6. [CONFERENCIA_COBERTURA_21.md](CONFERENCIA_COBERTURA_21.md) — CSV estrito, pares, quantidades e bloqueios.
7. [CONSISTENCIA_SEMANTICA_C7.md](CONSISTENCIA_SEMANTICA_C7.md) — relações declarativas, distinção E/S/P e lacunas.
8. [FERRAMENTAS_AMBIENTE_E_LIMITES.md](FERRAMENTAS_AMBIENTE_E_LIMITES.md) — origem/versões, isolamento, negativas do
   parser e transcrição textual inerte da ferramenta independente utilizada.
9. [PROPOSTA_C6_R1_SE_NECESSARIA.md](PROPOSTA_C6_R1_SE_NECESSARIA.md) — diff proposto de um delimitador, não aplicado.
10. [PENDENCIAS_E_DECISAO_C7.md](PENDENCIAS_E_DECISAO_C7.md) — bloqueios e ponto de parada.
11. INDICE_ENTREGA.md — este documento e origem da tarefa.
12. [MANIFESTO_SHA256_C7](MANIFESTO_SHA256_C7) — bytes/SHA-256 dos onze documentos; exclui apenas a si.

Não há contrato C6 reescrito, arquivo executável, runner, fixture ativa ou cópia de
custódia privada nos documentos entregues. Trechos Python/JSON/diff em Markdown
são evidência textual, não componentes ativos a instalar ou executar como produto.

## Proveniência da tarefa

Instrução C7 recebida, Texto colado.txt, 11.222 bytes, SHA-256
`51858a69a133b6b0524f5770a48f9824069e104bf038e05b36a75a201ee07b47`.
Parecer independente C6 recebido, 7.120 bytes, SHA-256
`6da60b1e09613cbad94fb0b66c2b471b54e69a866daf02af2ad5041256b04742`.
Ambos foram lidos como documentos; a instrução é a referência de execução, e o
parecer fundamenta os limites sem autorizar atividades adicionais.

Fonte C6 local: WIN19-C6-contratos-declarativos.zip, 19.872 bytes, SHA-256
`ee9cd82da311ef8ea003f3eba249a1c9967d46cd258a10dd813e706848e82f3a`.
Manifesto C6: 727 bytes, SHA-256
`a72a1800441cdb1b4e1a156759a1e45eb7ae1c3f29d674146403f26a179bc796`.
Oito nomes exatos sem duplicação/travessia/links; CRC e 7/7 registros conferidos.
Os oito originais e cópias continuaram idênticos ao fim da validação.

## Decisão e preservação

Cinco arquivos concluíram as verificações estruturais aplicáveis; o schema de
relatório é REPROVADO_ESTRUTURALMENTE por sintaxe e seu metaschema está BLOQUEADO.
Não declarar o pacote integralmente aprovado. Não atribuir resultado de controle
WIN a qualquer número das sondas C7.

R1-FIX não acessada/alterada; Portão B e custódia privada preservados sem nova
coleta; runner NÃO_IMPLEMENTADO; 19 vínculos PROVISORIO_SEM_FONTE;
WIN/DACL NÃO_VALIDADO; autorização de ensaios PENDENTE; prontidão false;
T01/T06 ESPECIFICADO, T02 BLOQUEADO, T03/T04/T05/T07 PARCIAL; D01–D10 PARA_APROVAÇÃO;
C/D/E e conversões reais BLOQUEADOS. Sem instalação, configuração, ACL, contas,
privilégios, worktree, Git, commit, push, merge, publicação ou ZIP nesta C7.
Parar para revisão independente; não aplicar a proposta C6-R1.
