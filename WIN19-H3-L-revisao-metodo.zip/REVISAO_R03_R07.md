# H3-L — identidade física, concorrência e proteção efetiva

26/11/2026. R03/R07 continuam RISCO_POTENCIAL, severidade ALTA. Leitura de projeto;
nenhum handle/API novo, inspeção, acesso entre contas ou código foi executado.

## R03 — observação nominal não é identidade permanente

GetAttributes e Assert-H3Chain (B027–064) consultam nomes/atributos. Validação de
componentes, raiz, reparse e releituras (B136–157/B197–230/B319–325) pode detectar
alteração nos instantes observados. Não fixa o ID físico dos objetos nem vincula
uma consulta à seguinte por handle. Entre duas consultas pode ocorrer substituição
com atributos iguais, alteração de ancestral, redirecionamento/alias ou colisão.
SUBST não é excluído por rejeitar nomes com ~. Reparse não observado não prova
impossibilidade de substituição intermediária. Não foi demonstrado contorno real.

Para o Nível A, é legítimo relatar apenas o que as APIs retornaram para nomes
consultados numa janela temporal, se a execução for futuramente autorizada e sua
evidência vinculável. Não afirmar que todas as consultas viram o mesmo objeto,
que formam snapshot atômico ou que a ausência continuará válida. O bloco não
registra timestamps individuais; início/fim externos delimitariam a janela, não
atestariam o instante de cada leitura. Evidência atual é apenas estática.

Para esse relato limitado, identidade imutável não é requisito lógico da afirmação
restrita. Contudo, o risco de acessar objeto redirecionado durante uma leitura de
ACL/WMI não é resolvido pelo rebaixamento da afirmação: a segurança da eventual
execução e a legitimidade do escopo continuam precondições separadas, sem aceite
implícito. Não executar enquanto sua revisão e decisões estiverem pendentes.

Afirmações sobre objeto físico estável, isolamento, exclusividade durante cópia,
revalidação segura e preservação de origem/destino do Nível B exigem método próprio.
Se forem indispensáveis antes da observação, o desenho precisa revisão adicional.
Handles/pinning/APIs de identidade, direitos/compartilhamento/fechamento e limites
seriam desenvolvimento futuro sujeito a autorização e auditoria próprias.
Não são propostas implementadas; não se alteram flags, motor ou código histórico.

## R07 — cinco camadas que permanecem distintas

1. Metadados de segurança retornados pela API, sujeitos à identidade nominal R03.
2. DACL do ancestral existente, com owner/grupo e regras explícitas/herdadas.
3. Interpretação de regras herdáveis e do contexto observado.
4. Acesso efetivo de uma identidade para determinada operação/objeto.
5. Proteção do destino futuro, da cópia, parciais e registros e direitos dos papéis.

B283–314 lê Access/Owner/Group, regras, grupos e descritor binário, mantendo detalhes
em memória. Contar allow amplo e deny não é AccessCheck: não calcula generic
mapping, direitos, ordem de regras, token/grupos/privilegios ou acesso efetivo de
coadministradores. Uma sessão não elevada não prova isolamento. Regras herdáveis
não são prova de como um objeto futuro efetivamente será criado/protegido.

V08 (B326–331) impede se DACL nula, quando esse ramo é alcançado; allow amplo exige
revisão, e demais casos continuam inconclusivos por proteção/papéis futuros não
demonstrados. Falha anterior na leitura pode deixar V08 não executado, não aprovado.
Não usar ausência de allow amplo como cumprimento da política de custódia.

Após uma eventual inspeção limitada, poderão permanecer inconclusivos: identidade
do ancestral, direitos efetivos, herança aplicada ao objeto futuro, legitimidade
dos papéis, exposição ao longo do tempo e proteção da futura cópia. Nenhuma dessas
lacunas é encerrada por JSON completo ou sintaxe válida do script.

## Controles posteriores de cópia fiel

H3-E requer identidade/estabilidade e preservação da origem, criação independente
exclusiva sem reparse/sobrescrita, comparação integral de bytes/tamanho/hash,
encerramento demonstrado e proteção de parciais/evidências. SHA-256 coincidente
não prova autenticidade histórica. Inspeção prévia não fornece essas garantias
sozinha. Método e termo H3-C próprios ainda são necessários, sem criar destino,
ler/copy/sanitizar XML, mudar ACL ou testar outra conta nesta H3-L.

## Decisão delimitada

Há utilidade documental independente em conhecer indícios e lacunas de um ambiente;
não há certificação de custódia. Precisam ser decididas finalidade e garantias
indispensáveis antes de autorizar qualquer método. R03/R07 não foram aceitos,
reduzidos ou encerrados. Proteção efetiva continua NAO_VERIFICADA.
