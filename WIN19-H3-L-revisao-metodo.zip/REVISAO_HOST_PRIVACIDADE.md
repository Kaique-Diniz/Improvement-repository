# H3-L — ambiente, exposição e privacidade

26/11/2026. Confronto documental R04/R05/R06/R08/R09; todos RISCO_POTENCIAL, MEDIA.
Nenhuma máquina, perfil, provider, share, ACL ou diretório privado foi inspecionado.

| Item | Método/limite R1 | Registro privado necessário | Limite compartilhável |
|---|---|---|---|
| R04 volume, B159–195 | DriveInfo Fixed só permite consultas; índices/bus compatíveis não autenticam disco interno; InterfaceType/MediaType não fecham a prova | Evidência legítima do volume e de sua natureza; correspondência entre providers | Apenas conclusão qualificada/referência autorizada, sem identificador de máquina ou inventário físico |
| R05 Git/áreas, B232–251/B316–318 | Marcadores são heurística; referências não recebidas mantêm V05 inconclusivo | Inventário legítimo de Git/worktrees, R1-FIX, C5–C8, custódias/Portão B e demais áreas proibidas, e método delimitado de confronto | Não publicar caminhos completos ou inventário interno; não inferir por nomes ou executar Git/varredura |
| R06 sincronização/shares, B253–281 | OneDrive do processo e Win32_Share são parciais; Type/Path nulos não são ausência; D04 preservada | Política de exposição e inventário legitimamente disponível; decisão técnica sobre ambiente | Não publicar shares/caminhos; não isentar administrativos. Incidência pode impedir a inspeção sob a política atual |
| R08 console/host, B138/B332–383 | Read-Host visível; JSON normal sanitizado não cobre histórico, captura, ErrorRecords ou buffers/memória | Responsáveis, destinatários e canais legítimos de recepção/preservação | Não compartilhar captura/transcrição bruta ou caminho errado; revisão de minimização/autorização separada |
| R09 resolução, B014/B070/B120/B138/B383 | New-Object não qualificado pode ser sombreado; qualificação de módulo pode causar autoload | Proveniência de host/PowerShell/.NET/módulos/perfis e configuração atual pertinentes | Informar somente limites/conclusões; versão do host não autentica módulos efetivamente usados |

Não modificar PSModulePath, perfis, política de execução, privilégio, auditoria,
logs, ferramentas de segurança, serviços ou compartilhamentos. Não propor sua
desativação para fazer inspeção passar. Exceção técnica a shares administrativos,
se considerada futuramente, exige decisão expressa, fundamentada e revisada própria;
nenhuma isenção foi aplicada ou proposta automaticamente nesta H3-L.

## Informação privada e legitimidade

Ficam privados: caminho proposto, referências históricas, contas/SIDs, operador e
coadministradores, identificação de computador, inventários e evidências internas,
registro legítimo de autorização e obrigações institucionais. A matriz de decisões
marca onde formalizar, sem pedir conteúdo no chat. Não inserir caminhos privados
no código atual, índice compartilhável, exemplos ou futuros resultados públicos.
Nenhuma credencial ou dado de cliente é necessário a esta revisão.

Não há leitura de JUnit/XML; conteúdo da fonte histórica não é evidência necessária
para o Nível A. O Portão B e sua custódia privada não são reabertos. SHA-256 ou nome
semelhante não reconstituem proveniência histórica ou identidade do operador.

## Histórico, captura e memória

Sessão privada e não remota é precondição ainda não comprovada. Texto digitado em
Read-Host, saída do host e exceções podem aparecer em captura/transcrição, memória
ou registros externos ao JSON. Não se declara que toda entrada em Read-Host integra
necessariamente o histórico de comandos; depende do host/captura e não foi observado.
Limpar referências não promete apagamento forense. Não apagar logs/evidências para
alegar privacidade. Exposição suspeita exige suspensão e decisão legítima separada.

## Governança independente

H3-J resolve documentalmente apenas o meio público do ZIP H3-F-R1 específico;
proveniência anterior, identidade/horário real do push e conformidade institucional
continuam pendentes nos limites H3-I/H3-J. Publicação H3-H é distinta. Autorizações
posteriores de transferência de ZIP não autorizam operação/inspeção Windows.
A H3-L não consulta GitHub nem reavalia publicações para promover segurança.
