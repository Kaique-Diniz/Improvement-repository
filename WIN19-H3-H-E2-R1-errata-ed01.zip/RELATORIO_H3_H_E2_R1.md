# H3-H-E2-R1 — correção documental ED-01

26/11/2026 — America/Sao_Paulo. Errata aditiva, aguardando auditoria independente.

## Objetivo, fonte e resultado

A ED-01 é tratada por adendo externo, sem editar a H3-H-E2 aceita com ressalva.
O JSON completo da primeira tentativa foi apresentado anteriormente pelo usuário
na conversa, conforme a instrução R1 e o parecer independente. O insumo documental
usado na E2 não o incorporou integralmente. A falta naquele insumo não permite
concluir inexistência na conversa. A redação anterior generalizou indevidamente
essa limitação; a errata delimita a afirmação e registra os vinte campos.

A fonte direta desta materialização é a seção 4 da instrução R1 recebida do
usuário em 26/11/2026. O bloco já foi formatado para a instrução: não se afirma
identidade byte a byte com console, assinatura, horário confiável ou recuperação
independente da mensagem primária. O parecer fundamenta ED-01; não é autorização
para execução. Não foi registrado o caminho inválido nem inventado horário.

## Primeira tentativa — registro integral DERIVADO

`RESULTADO_PRIMEIRA_TENTATIVA_DERIVADO.json` tem 746 bytes;
SHA-256 `44652cf46839661e4913712ebcb5bb1d381d27a28bd0046b74cfd4304b8d91e0`.
UTF-8 sem BOM, indentação de dois espaços e LF final. Contém exclusivamente os
vinte campos recebidos, com valores e tipos preservados. Esse hash identifica
somente a cópia documental nova, não os bytes históricos da saída Windows.

| Campo | Valor transcrito | Tipo JSON |
|---|---|---|
| `etapa` | `"WIN19-H3-H"` | `string` |
| `versao_auxiliar` | `"20261124-proposta-1"` | `string` |
| `ambiente_parser` | `"WINDOWS_POWERSHELL_51_DESKTOP"` | `string` |
| `versao_powershell` | `"5.1.26100.10068"` | `string` |
| `api_parser_disponivel` | `true` | `boolean` |
| `parser_assembly_nome` | `"System.Management.Automation"` | `string` |
| `parser_assembly_versao` | `"3.0.0.0"` | `string` |
| `fonte_sha256_conferida` | `false` | `boolean` |
| `fonte_tamanho_bytes` | `null` | `null` |
| `bloco_sha256_conferido` | `false` | `boolean` |
| `bloco_tamanho_bytes` | `null` | `null` |
| `bloco_linhas` | `null` | `null` |
| `parser_invocado` | `false` | `boolean` |
| `parsing_concluido` | `false` | `boolean` |
| `quantidade_erros` | `null` | `null` |
| `erros_sintaticos` | `[]` | `array` |
| `resultado_sintatico` | `"FONTE_NAO_AUTENTICADA"` | `string` |
| `codigo_impedimento` | `"H3H_CAMINHO_FONTE_INVALIDO"` | `string` |
| `script_analisado_executado` | `false` | `boolean` |
| `recursos_leitura_fechados` | `true` | `boolean` |

Conforme o usuário: ambiente PS5.1 Desktop identificado e API disponível, mas
caminho recusado antes da autenticação da fonte e da invocação do parser.
`PRIMEIRA_TENTATIVA=INTERROMPIDA_POR_CAMINHO_INVALIDO`;
`RESULTADO_SINTATICO=FONTE_NAO_AUTENTICADA`;
`PARSER_INVOKADO=false` (rótulo documental de `parser_invocado`);
`QUANTIDADE_ERROS=null`.
Não é falha sintática. A lista vazia não prova validade: nenhum erro sintático
foi medido. As flags de não execução e recursos fechados são informadas, sem
monitoramento independente; não comprovam descarte WMI ou atividade do host.

## Segunda tentativa — registro separado preservado

O JSON histórico de 714 bytes conserva o SHA-256
`83bb042a0ce388c38f1ca2e01187030a867719a3b907e845e0faaf69a408e1c0`.
Conforme evidência do usuário: Windows PowerShell 5.1.26100.10068 Desktop,
fonte/bloco conferidos por flags, bloco R1 com 20.362 bytes/383 linhas,
parser invocado e concluído, `SINTAXE_VALIDA_PS51`, zero erros,
`script_analisado_executado=false`. Os digests calculados no Windows não constam
no JSON. Não se promove autenticação independente, runtime, segurança ou DACL.
As duas tentativas não foram fundidas em resultado único.

## Conferências documentais e preservação

Antes e depois, os oito documentos E2 e seu manifesto foram conferidos por
tamanho, SHA-256 e comparação integral de bytes. O ZIP histórico permaneceu
idêntico; as fontes documentais R1, H3-H, H3-G e H3-J lidas também permaneceram
idênticas. A matriz E2 mantém T01 e todos os estados históricos sem edição.
A matriz ED01 nova contém doze verificações documentais e não resultados de testes.

Apenas biblioteca padrão Python em Linux para leitura, JSON/CSV como dados,
comparação e materialização de documentos. Isso não executa parsing PowerShell,
auxiliar, código H3-F-R1, WMI ou ensaio Windows. Sem instalação, teste do produto,
ACL/DACL, acesso ao destino, JUnit, custódia, Git, ZIP ou publicação.

## Decisão proposta e parada

`H3-H-E2-R1=ERRATA_PREPARADA_AGUARDANDO_AUDITORIA`.
`ED01=CORRECAO_DOCUMENTAL_PROPOSTA`; não se declara a ressalva encerrada pela
própria entrega. N01 permanece restrito à sintaxe R1 conforme evidência do usuário;
N02–N04 e os nove riscos continuam abertos. Estados e limites constam no documento
próprio. Entregar sete arquivos e seus hashes e parar, sem iniciar outras etapas.
