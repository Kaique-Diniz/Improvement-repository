# H3-H-E2-R1 — índice, integridade e rastreabilidade

26/11/2026 — America/Sao_Paulo.
Pasta nova externa ao Git: /workspace/work/WIN19-H3-H-E2-R1-ERRATA-ED01-20261126/.
Não é diretório de custódia ou repositório de evidência primária Windows.

## Sete arquivos desta entrega

1. [RELATORIO_H3_H_E2_R1.md](RELATORIO_H3_H_E2_R1.md): contexto, vinte campos,
   interpretação individual e resultado documental proposto.
2. [ERRATA_ED01_H3_H_E2.md](ERRATA_ED01_H3_H_E2.md): trechos afetados, redação
   corretiva e complemento T01 por adendo, sem modificar fontes.
3. [RESULTADO_PRIMEIRA_TENTATIVA_DERIVADO.json](RESULTADO_PRIMEIRA_TENTATIVA_DERIVADO.json):
   somente os vinte campos, valores e tipos recebidos, DERIVADO.
4. [MATRIZ_CONFRONTO_ED01.csv](MATRIZ_CONFRONTO_ED01.csv): doze registros,
   ED01-01 a ED01-12, distinguindo CONFERIDO_DOCUMENTALMENTE,
   INFORMADO_PELO_USUARIO e NAO_VERIFICADO. Não são resultados funcionais.
5. [LIMITES_E_ESTADOS_PRESERVADOS.md](LIMITES_E_ESTADOS_PRESERVADOS.md): proveniência,
   N01 restrito, N02–N04 não verificados, nove riscos e bloqueios.
6. INDICE_ENTREGA_H3_H_E2_R1.md: este inventário e referências autenticadas localmente.
7. [MANIFESTO_SHA256_H3_H_E2_R1](MANIFESTO_SHA256_H3_H_E2_R1): seis linhas,
   SHA-256/tamanho/nome dos seis anteriores, exclui a si próprio. Seu hash é
   informado na entrega em chat; não há ciclo de hashes ou arquivo extra.

## Identidades dos cinco documentos anteriores ao índice

| Documento | Bytes | SHA-256 |
|---|---:|---|
| `ERRATA_ED01_H3_H_E2.md` | 4081 | `1600ffb1b5deb3e155448d49a9e99f5282b9c42417ef7fe9a2653f9b373e2e6d` |
| `LIMITES_E_ESTADOS_PRESERVADOS.md` | 4799 | `ba07e67f90d406596273c1894f09df8e9b8312fdb33ed548eb8a771ecef45c15` |
| `MATRIZ_CONFRONTO_ED01.csv` | 3111 | `2a2cf24e2d370bbaa6dde88736816b09630555e18ef686fdeb5b8c51d69d0813` |
| `RELATORIO_H3_H_E2_R1.md` | 5004 | `5da7a3d11d76e7fd5730a83b3958aae08d8b17e32ce4ca25b4e413d6aae46c45` |
| `RESULTADO_PRIMEIRA_TENTATIVA_DERIVADO.json` | 746 | `44652cf46839661e4913712ebcb5bb1d381d27a28bd0046b74cfd4304b8d91e0` |

O hash do novo JSON identifica somente a cópia DERIVADA atual; não é hash da
saída original Windows. UTF-8 sem BOM, LF final e indentação de dois espaços;
valores e tipos comparados ao bloco da seção 4 da instrução, sem metadados adicionais.
A segunda tentativa não foi copiada para esta pasta nem modificada.

## Fontes diretas desta R1

| Fonte | Bytes | SHA-256 local |
|---|---:|---|
| Texto colado.txt, instrução H3-H-E2-R1, recebido em 26/11/2026 | 11958 | 4a9f9ab0e3a66f695c3af90aa369df75a902760ae216483cd4755f9970b65232 |
| PARECER_INDEPENDENTE_WIN19_H3_H_E2_2026-11-26 (1).md | 10507 | 88b7782d14d402e861e94a5ed567ed2fb6130f939c913e5185f78b1cbaad70bd |

O anexo com sufixo (1) corresponde ao parecer obrigatório sem esse sufixo; bytes
iguais à cópia já conferida. O primeiro JSON é fornecido integralmente na instrução
R1; a data de apresentação é informada pelo usuário, sem inventar hora exata.
O parecer fundamenta a correção e não autentica bytes de console. As fontes não
são incluídas como arquivos extras nesta entrega de sete itens.

## Fonte histórica H3-H-E2 conferida antes e depois

Pasta preservada: /workspace/work/WIN19-H3-H-E2-EVIDENCIA-PARSING-20261126/.

| Documento E2 | Bytes | SHA-256 |
|---|---:|---|
| `ATUALIZACAO_PENDENCIAS_H3_G.md` | 10932 | `5c5490154fd9c0d76f6517131a571c3bfbc0666b7fef3cd0017e8f1cc72cc68e` |
| `DECISAO_DOCUMENTAL_PROPOSTA.md` | 2586 | `c074f5dd6b2b9a6731dea2fe0971faa77bd73f4d9b7625796a789b70101d78a2` |
| `INDICE_ENTREGA_H3_H_E2.md` | 5150 | `3a08d18ed62747f9bfa824334fc2e4ec2ba53d76c84bcd43df307231f35882ba` |
| `LIMITES_E_PROVENIENCIA_EVIDENCIA.md` | 3375 | `bc42cc2ccf93fe4d7b8ac4c24abc2dfcc5467418be8c0d85fd2725b4dfc5487d` |
| `MATRIZ_VALIDACAO_SINTATICA.csv` | 9620 | `50234f96d8262685486c792e9ffdcaf745247de69561756e772cbdfcf959c980` |
| `REGISTRO_RESULTADO_PARSING.md` | 4134 | `116ecd8b5fecaaedcffb2821558f29882cd2a1f086bd551bff570cdb26f2b82f` |
| `RELATORIO_H3_H_E2.md` | 3929 | `68c6f9ff0cce008ed7c1a2b0478473e9dce009ba87d685cdd769898d9bff2aab` |
| `RESULTADO_PARSING_SANITIZADO.json` | 714 | `83bb042a0ce388c38f1ca2e01187030a867719a3b907e845e0faaf69a408e1c0` |
| `MANIFESTO_SHA256_H3_H_E2` | 821 | `7584d9763249217655f35569ae9f763c08e793cf65bfa6193bb6137f1527562c` |

O manifesto E2 foi autenticado pelo hash obrigatório e os oito tamanhos/hashes
coincidem. Após a materialização, comparação integral confirmou os mesmos bytes.
ZIP E2 histórico preservado: 19.740 bytes, SHA-256
`df2000a58018355fe06ccc56f0ab4f4ef00aacbd0c6c208bb5ea91108f24a116`.
Nenhum documento, matriz, manifesto ou pacote histórico foi regenerado.

Referência do insumo E2 original: Texto colado.txt, 9.989 bytes, SHA-256
`c41b7570f0ebd26147c7f88c7b7e7d2a2785066029524e3c63bddce927b31e40`.
Aquele insumo contém apenas o JSON completo da segunda tentativa e narrativa da
primeira; o primeiro objeto integral é materializado agora pela instrução R1.
Não se confunde falta no insumo com ausência na conversa relatada pelo usuário.

## Método e parada

Somente operações documentais em Linux com biblioteca padrão Python:
leitura e hashes, JSON/CSV como dados, escrita exclusiva em pasta nova e comparação
antes/depois. Sem execução de PowerShell ou parser nativo, produto, teste ou Windows.
Não foram criados ZIP, script ou log operacional; nenhum Git, commit, push, merge
ou publicação. ERRATA_PREPARADA_AGUARDANDO_AUDITORIA, não homologação.
Parar para auditoria independente; sem inspeção de destino, H3-C, H3-S ou H4.
