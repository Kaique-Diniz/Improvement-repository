# H3-H-E2-R1 — limites, riscos e estados preservados

26/11/2026. Esta errata é documental e aditiva, com decisão de aceitação pendente.

## Proveniência e separação das tentativas

Primeira: objeto completo de vinte campos, copiado da seção 4 da instrução R1
enviada pelo usuário, que informa apresentação anterior na conversa. O parecer
independente relata a mesma existência. O insumo E2 original não incorporou o
objeto integral. Essa limitação de entrada não prova ausência na conversa.
Não se recuperaram bytes do console, mensagem primária autenticada, assinatura,
identidade de máquina ou horário confiável. Não há caminho privado no derivado.

Primeira tentativa: fonte não autenticada, caminho inválido, parser não invocado,
quantidade de erros null e lista vazia. Não houve medição de erros. API disponível
e assembly informado não provam sintaxe válida. O hash do DERIVADO é novo.

Segunda: JSON E2 preservado. Flags de conferência de fonte/bloco e zero erros
são evidência informada pelo usuário; não trazem os digests efetivamente medidos
no Windows nem auto-hash do auxiliar. Versão do auxiliar não autentica seus bytes.
As flags de não execução e recursos fechados não atestam toda atividade do host
nem descartes WMI do código R1. Não se cria resultado único para ambas tentativas.

## Estados documentais obrigatórios

| Item | Estado e qualificação |
|---|---|
| H3-H-E2 | ACEITA_DOCUMENTALMENTE_COM_RESSALVA_ED01 |
| H3-H-E2-R1 | ERRATA_PREPARADA_AGUARDANDO_AUDITORIA |
| ED01 | CORRECAO_DOCUMENTAL_PROPOSTA |
| PRIMEIRA_TENTATIVA | FONTE_NAO_AUTENTICADA |
| Sequência da primeira | INTERROMPIDA_POR_CAMINHO_INVALIDO; parser_invocado=false; quantidade_erros=null |
| SEGUNDA_TENTATIVA | SINTAXE_VALIDA_PS51_CONFORME_EVIDENCIA |
| ERROS_SINTATICOS_SEGUNDA_TENTATIVA | 0, conforme usuário |
| H3G-N01 | SINTAXE_VALIDADA_POR_PARSER_NATIVO_PS51, somente bloco H3-F-R1 e conforme usuário |
| H3G-N02 | NAO_VERIFICADO — tipos/sobrecargas .NET em runtime |
| H3G-N03 | NAO_VERIFICADO — providers e propriedades WMI |
| H3G-N04 | NAO_VERIFICADO — arrays, escopo e JSON do runtime R1 |

## Nove riscos abertos

Todos mantêm RISCO_POTENCIAL;
na matriz E2 original o estado é RISCO_POTENCIAL_PRESERVADO. As descrições abaixo
são resumos, não substituem os campos substantivos históricos preservados.

| ID | Estado | Risco resumido |
|---|---|---|
| H3G-R01 | RISCO_POTENCIAL | Inicialização/serialização fora do tratamento principal |
| H3G-R02 | RISCO_POTENCIAL | Limites de tempo e efeitos de providers WMI |
| H3G-R03 | RISCO_POTENCIAL | Identidade física, aliases e substituição entre consultas |
| H3G-R04 | RISCO_POTENCIAL | Correspondência entre providers e natureza interna do disco |
| H3G-R05 | RISCO_POTENCIAL | Marcadores Git parciais e referências históricas ausentes |
| H3G-R06 | RISCO_POTENCIAL | Indicadores parciais de sincronização e compartilhamentos |
| H3G-R07 | RISCO_POTENCIAL | DACL do ancestral não comprova acesso efetivo ao objeto futuro |
| H3G-R08 | RISCO_POTENCIAL | Privacidade de entrada, buffers, memória e captura do host |
| H3G-R09 | RISCO_POTENCIAL | Resolução de comandos e carregamento de módulos |

Os quatro defeitos H3-G materializados documentalmente na H3-F-R1 não recebem
aprovação funcional por esta errata ou pela validade sintática da segunda tentativa.
H3-F original e auxiliar não recebem promoção de sintaxe por extensão do N01 R1.

## Bloqueios operacionais inalterados

| Item | Estado |
|---|---|
| H3-F-R1_EXECUCAO_FUNCIONAL | NAO_EXECUTADA |
| VERIFICACAO_REAL_DESTINO | NAO_AUTORIZADA; NAO_EXECUTADA |
| PROTECAO_EFETIVA | NAO_VERIFICADA |
| H3-C | NAO_AUTORIZADA |
| H3-S | NAO_AUTORIZADA |
| H4 | NAO_AUTORIZADA |
| WIN01_A_WIN19 | NAO_VALIDADO |
| DACL | NAO_VALIDADO |
| RUNNER_C | NAO_IMPLEMENTADO |
| PORTOES_C_D_E | BLOQUEADOS |
| CONVERSOES_REAIS | BLOQUEADAS |
| PRONTIDAO_PARA_EXECUTAR | false |
| Vínculos históricos | PROVISORIO_SEM_FONTE |

## Governança, custódia e parada

H3-I/H3-J conservam suas pendências independentes de proveniência primária,
ator/horário real do push e conformidade institucional. O encerramento documental
restrito do meio público H3-F-R1 na H3-J não cobre a publicação H3-H distinta.
A R1 não autentica retroativamente mensagens nem autoriza nova publicação.
Papéis privados, retenção e diretórios de custódia não são alterados ou acessados.

Nenhuma execução PowerShell, auxiliar, parser nativo, código H3-F-R1, WMI,
Windows/DACL, teste, inspeção de destino, operação JUnit ou custódia. Nenhuma
alteração em Git, código, branches, commits, ACLs, políticas ou históricos.
Sem ZIP, script, log operacional, publicação ou início automático de outra etapa.
