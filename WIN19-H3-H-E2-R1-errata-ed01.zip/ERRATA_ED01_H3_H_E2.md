# Errata ED-01 — adendo à H3-H-E2

26/11/2026. Correção documental proposta para auditoria; nenhuma substituição de
arquivo histórico. Aplicar esta leitura complementar às referências abaixo.

## E-01 — relatório, seção “Tentativas e consistência”, linhas 22–24

Fonte: RELATORIO_H3_H_E2.md, 3.929 bytes, SHA-256
`68c6f9ff0cce008ed7c1a2b0478473e9dce009ba87d685cdd769898d9bff2aab`.
Trecho: “Não há JSON completo dessa tentativa”.

Redação corretiva por adendo:

> O JSON completo da primeira tentativa foi apresentado anteriormente pelo usuário nesta conversa. Esse registro não foi incorporado à consolidação documental H3-H-E2 original. O resultado corresponde a uma interrupção por caminho inválido, anterior à autenticação da fonte e à invocação do parser.

A existência anterior é informada pelo usuário e corroborada documentalmente
pelo parecer. A instrução R1 agora fornece o objeto completo para materialização.
Não se afirma recuperação independente da mensagem original ou de bytes de console.

## E-02 — registro das tentativas, tabela “Fonte e sequência informada”, linha 16

Fonte: REGISTRO_RESULTADO_PARSING.md, 4.134 bytes, SHA-256
`116ecd8b5fecaaedcffb2821558f29882cd2a1f086bd551bff570cdb26f2b82f`.
A linha “Primeira | Relato textual” descreve o insumo efetivamente utilizado na E2,
mas é incompleta como narrativa da evidência disponível na conversa.

Complemento: há transcrição completa de vinte campos em JSON fornecida pelo
usuário; não há captura primária autenticada do console nesta entrega. A primeira
tentativa tem fonte não autenticada, parser não invocado, erros não medidos
(`null`), resultado FONTE_NAO_AUTENTICADA e impedimento H3H_CAMINHO_FONTE_INVALIDO.
A segunda permanece em documento próprio, SINTAXE_VALIDA_PS51, zero erros
conforme evidência recebida. Nenhuma conclusão sintática da segunda se transfere
à primeira. Não corrigir `null` para zero nem denominar a primeira falha sintática.

## E-03 — complemento à T01, sem editar a matriz

Fonte: MATRIZ_VALIDACAO_SINTATICA.csv, 9.620 bytes, SHA-256
`50234f96d8262685486c792e9ffdcaf745247de69561756e772cbdfcf959c980`.
T01 (linha física 2), limite histórico: “Sem JSON completo, horario, quantidade de
erros ou caminho da primeira tentativa; nao reconstruir tais dados”.

Preservar todos os valores e a classificação histórica de T01. O complemento é:

| Aspecto complementar T01 | Registro R1 |
|---|---|
| Disponibilidade | JSON completo fornecido pelo usuário; vinte campos transcritos na instrução R1 |
| Entrada | Caminho recusado, sem reproduzir o caminho privado |
| Fonte | Não autenticada; fonte_sha256_conferida=false |
| Parser | Não invocado; parsing_concluido=false |
| Erros sintáticos | Não medidos; quantidade_erros=null; lista vazia sem inferência de validade |
| Proveniência | Transcrição do usuário, sem autenticação primária dos bytes Windows |
| Horário | Exato não informado; não reconstruído |
| Estado | Interrupção por entrada inválida; não falha sintática |

Os valores detalhados estão no novo JSON DERIVADO e na matriz ED01. A matriz
histórica não recebe edição nem substituição retroativa de status.

## E-04 — alcance da frase do índice, linha 41

Fonte: INDICE_ENTREGA_H3_H_E2.md, 5.150 bytes, SHA-256
`3a08d18ed62747f9bfa824334fc2e4ec2ba53d76c84bcd43df307231f35882ba`.
“Não foi criado JSON da primeira tentativa” continua verdadeiro para a entrega
E2 original. Agora a R1 cria uma cópia DERIVADA externa. A frase não deve ser
interpretada como inexistência do registro na conversa. O índice histórico e seu
manifesto permanecem íntegros; não é necessário regenerá-los.

## Resultado documental delimitado

A correção trata de completude e proveniência. Não altera o JSON da segunda
tentativa nem a sintaxe R1 informada; não comprova runtime ou segurança.
O parecer independente fundamenta a proposta; a aceitação desta errata depende
de auditoria própria. Não repetir parser nem qualquer comando Windows.
