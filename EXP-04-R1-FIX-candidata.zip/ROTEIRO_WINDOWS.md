# R1-FIX — validação nativa isolada, depois três casos somente se PASS

A candidata/pacote R1 anteriores ficam intactos. Extrair o novo pacote em pasta
NOVA fora do Git. Usar Windows real, Python 3.12 e dependências já disponíveis.
Não instalar, elevar privilégios ou alterar políticas. Não usar o residual antigo.

Ajustar `$Repo`, `$Pacote` e `$Python`. O baseline é BPQ-04. LF é imposto apenas
na operação worktree add; nenhuma configuração persistente é alterada.

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'E4-R1-FIX'
$Pacote = Join-Path $Root 'pacote'
$C = Join-Path $Root 'candidata'
$EI = Join-Path $Root 'resultado-isolado'
$ET = Join-Path $Root 'resultado-tres'
$Repo = Join-Path $HOME 'Conversor-MVP-BPQ04'
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe'
$Base = '770d062d29c4361d6932592883df9339bb4089bc'
if (Test-Path -LiteralPath $C) { throw 'CANDIDATA_JA_EXISTE' }
if (Test-Path -LiteralPath $EI) { throw 'EVIDENCIA_ISOLADA_JA_EXISTE' }
if (Test-Path -LiteralPath $ET) { throw 'EVIDENCIA_AGREGADA_JA_EXISTE' }
if (-not (Test-Path -LiteralPath $Pacote)) { throw 'PACOTE_AUSENTE' }
if (-not (Test-Path -LiteralPath $Python)) { throw 'PYTHON_AUSENTE' }
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
& git -c core.autocrlf=false -c core.eol=lf -C $Repo worktree add --detach $C $Base
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_NAO_CRIADA' }
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_NAO_CONFERIDA' }
New-Item -ItemType Directory -Path $EI | Out-Null

# Somente o teste afetado; o executor confere hashes antes/depois.
& $Python -B (Join-Path $Pacote 'validar_r1fix.py') --pacote $Pacote --candidata $C --evidencias $EI --escopo isolado
$Isolado = $LASTEXITCODE
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'HASH_APOS_ISOLADO_DIVERGENTE' }
if ($Isolado -ne 3) { throw 'ISOLADO_SEM_PASS_PRESERVAR_EVIDENCIAS_E_PARAR' }

# Só haverá recibo se o caso passou sem skips, API/Win32 são os esperados,
# bytes conferidos, auxiliar encerrado e temporário removido.
$Selos = @(Get-ChildItem -LiteralPath $EI -Filter 'r1fix-validacao.json' -Recurse -File)
if ($Selos.Count -ne 1) { throw 'RECIBO_ISOLADO_AUSENTE_OU_AMBIGUO' }
New-Item -ItemType Directory -Path $ET | Out-Null
& $Python -B (Join-Path $Pacote 'validar_r1fix.py') --pacote $Pacote --candidata $C --evidencias $ET --escopo tres --isolado $Selos[0].FullName
$Tres = $LASTEXITCODE
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'HASH_APOS_TRES_DIVERGENTE' }
if ($Tres -ne 3) { throw 'TRES_SEM_PASS_PRESERVAR_EVIDENCIAS_E_PARAR' }
```

O lançador NÃO tem opção para os 39, Linux ou suíte completa. O isolado seleciona
um nodeid; a etapa posterior, exatamente os três nodeids originais da R1.
Usa `-x` para parar na primeira falha. O motor/executor original não foi alterado:
a seleção existe apenas em memória no lançador externo. No relatório interno,
o nome do escopo é `complementares`, mas a coleta esperada é 1 ou 3, não os 36
complementares históricos. Asserções incorretas não são transformadas em skips.

Não rodar os três se o isolado não produzir PASS. O lançador verifica o recibo,
os arquivos originais de evidência e o SHA do manifesto da candidata antes de
permitir essa segunda etapa. Os hashes de referência são os 470 da R1 preservada;
a R1-FIX tem 470 também, com somente o hash do arquivo de testes alterado.

## Evidências geradas em cada execução

Dentro do diretório novo `execucao-...`, fora do Git:

- `r1fix-diagnostico.json`: criado antes das asserções de API/código; contém
  acesso/share, PRONTO, estado do processo antes/depois, primeira_falha e contadores.
- `r1fix-comparacao.json`: após liberar o auxiliar e ler o arquivo inteiro;
  igualdade integral, tamanho, encerramento e retorno do auxiliar; não contém bytes.
- `complementares.xml` e `.log`: JUnit/log da seleção de um ou três testes.
- `relatorio.json`: estado dos testes, integridade e limpeza, com ressalva de segurança.
- `r1fix-validacao.json`: só criado se TODOS os critérios desta etapa foram atendidos.

O teste requer `--junitxml` apontando para pasta existente fora de qualquer Git;
o executor faz isso automaticamente. O JSON usa criação exclusiva e flush/fsync,
sem sobrescrever arquivo existente. As propriedades do JUnit também são registradas
antes das asserções de API/código. Se falhar antes da comparação de bytes, esse
JSON de comparação pode não existir: registrar NAO_EXECUTADO, nunca presumir integridade.

O auxiliar sinaliza PRONTO depois de CreateFileW retornar handle válido e aguarda
stdin até ser liberado no finally. As verificações exigem processo ativo antes e
depois da tentativa. A asserção exige CreateFileW/32 real do diagnóstico; GetLastError
continua capturado imediatamente pelo motor inalterado. Divergência: parar,
preservar JSON/JUnit e não adaptar a asserção para aceitar outra API/código.

Retorno 2: bloqueio/falha/critério não atendido. Retorno 3: critérios desta seleção
atendidos no Windows, MAS DACL e homologação geral seguem NÃO_VALIDADO. Não remover
manualmente temporários com falha nem acessar o residual antigo. Conversões reais
dos quatro novos condomínios permanecem BLOQUEADAS. Sem commit/push/merge/publicação.
