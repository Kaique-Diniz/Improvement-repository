# EXP-04 — R1-FIX

Pacote LOCAL para revisao; sem publicacao. Candidata isolada com 470 arquivos,
apenas um arquivo alterado contra R1. Os outros 469 hashes permanecem iguais.

- RELATORIO_R1_FIX.md e RESULTADOS_R1_FIX.json: resultado BLOQUEADO por ausencia
  de Windows nativo. Nao foram produzidos novos PASS/FAIL, APIs/codigos observados
  ou JUnit Windows; nenhum teste foi executado nesta tarefa.
- R1_PARA_R1_FIX.patch: diff incremental integral, somente fixture/acesso e
  observabilidade exigida no teste afetado. Nao aplicar na candidata preservada.
- payload/tools/exp04_win/test_cleanup_windows.py: arquivo revisado integral.
- VERSAO_R1_FIX_SHA256.json: hashes de todos os 470 arquivos da nova candidata.
- REFERENCIA_R1_470_SHA256.json: hashes da candidata R1 preservada.
- EXP04_R1_FIX_COMPLETO.patch e BASELINE_SHA256.json: reconstrucao desde BPQ-04
  em worktree NOVA. As alteracoes herdadas de producao NAO pertencem a R1-FIX;
  usar o incremental para atribuir alteracoes desta etapa.
- reconstruir.py: valida todos os membros do pacote, baseline, ausencia de
  extras/links/reparse; recusa aplicacao sobre arvore divergente ou suja.
- validar_r1fix.py: Windows nativo obrigatorio; seleciona somente o alvo, ou
  os tres apos evidencia isolada PASS. Nao tem opcao para os 39.
- ROTEIRO_WINDOWS.md: reconstruir LF e rodar isolado; depois tres so se PASS.
- CONFERENCIA_ESTATICA.json: AST/sintaxe/escopo/lifecycle da fixture; nao e
  comprovacao de comportamento Windows.
- PRESERVACAO_FINAL.json e ESTADO_GIT.txt: preservacao das candidatas anteriores.
- MANIFESTO_SHA256.json: todos os membros, exceto ele mesmo; SHA do ZIP e externo.

Para obter registro antes das assercoes, o alvo exige --junitxml fora de Git,
fornecido pelo executor. Grava JSON com criacao exclusiva e flush/fsync, alem
 das propriedades JUnit. A comparacao continua sendo dos bytes INTEGRAIS depois
 da liberacao, nunca uma substituicao por exists() ou igualdade de hashes.

Compartilhamento 0x3 e assercoes CreateFileW/32 preservados. Motor, executor,
DACL, producao, politicas financeiras/cadastrais e bloqueios operacionais intactos.
Os demais usos do helper continuam com READ_ATTRIBUTES; so o alvo usa GENERIC_READ.

CRC do ZIP e conferido ao empacotar. Repetir na extracao e conferir SHA-256.
O reconstrutor valida os arquivos extraidos, nao le o ZIP diretamente.
Nao ha dados privados reais, credenciais ou conteudo documental neste pacote;
so codigo, fixtures sinteticas e metadados agregados.

Residual antigo nao acessado. DACL e homologacao Windows NAO_VALIDADO.
Conversoes reais dos quatro novos condominios continuam BLOQUEADAS.
