"""Windows nativo: somente alvo isolado; três casos só com evidência isolada PASS.

Não instala, não altera fontes e não oferece seleção de 39 testes.
"""
import argparse
import contextlib
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import sys

ALVO='tools/exp04_win/test_cleanup_windows.py::test_windows_arquivo_aberto_outro_processo_share3_falha32'
TRES=[ALVO,
 'tools/exp04_win/test_cleanup_windows.py::test_windows_injecao_api_preserva_codigo_e_nega_sucesso[SetFileInformationByHandle-5]',
 'tools/exp04_win/test_cleanup_windows.py::test_windows_pin_share3_impede_rename_e_delete_concorrente']
FILES=('relatorio.json','complementares.xml','r1fix-diagnostico.json','r1fix-comparacao.json')


def conferir_resultado(folder, expected, caminho):
 report=json.loads(caminho(folder/'relatorio.json').read_text(encoding='utf-8'))
 result=report['resultados']['complementares']
 if report['parcial'] or not report['integridade_final'] or report['hashes']!=470:
  raise ValueError()
 if (result['coletados'],result['aprovados'],result['falhas_ou_erros'],result['ignorados'])!=(expected,expected,0,0):
  raise ValueError()
 if not all(t['estado']=='REMOVIDO' for t in report['temporarios']):raise ValueError()
 diagnostic=json.loads(caminho(folder/'r1fix-diagnostico.json').read_text(encoding='utf-8'))
 first=diagnostic['diagnostico']['primeira_falha']
 compare=json.loads(caminho(folder/'r1fix-comparacao.json').read_text(encoding='utf-8'))
 if first['api']!='CreateFileW' or first['win32']!=32:raise ValueError()
 if diagnostic['acesso_auxiliar']!=0x80000000 or diagnostic['share_auxiliar']!=3:raise ValueError()
 if not all(diagnostic[k] for k in ('pronto_recebido','auxiliar_ativo_antes','auxiliar_ativo_apos_tentativa')):raise ValueError()
 if not compare['comparacao_integral'] or not compare['auxiliar_encerrado'] or compare['returncode_auxiliar']!=0:
  raise ValueError()
 if compare['bytes_lidos']!=len(b'SINTETICO'):raise ValueError()
 return {name:sha256(caminho(folder/name).read_bytes()).hexdigest() for name in FILES}


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--pacote',type=Path,required=True)
 parser.add_argument('--candidata',type=Path,required=True)
 parser.add_argument('--evidencias',type=Path,required=True)
 parser.add_argument('--escopo',choices=('isolado','tres'),required=True)
 parser.add_argument('--isolado',type=Path)
 a=parser.parse_args()
 if os.name!='nt':
  print('{"estado":"BLOQUEADO","codigo":"WINDOWS_NATIVO_INDISPONIVEL","testes_executados":0}')
  return 2
 try:
  if not all(p.is_absolute() for p in (a.pacote,a.candidata,a.evidencias)):raise ValueError()
  from reconstruir import executar as conferir, caminho
  conferir(a.pacote,a.candidata,True)
  version=a.pacote/'VERSAO_R1_FIX_SHA256.json'
  version_hash=sha256(version.read_bytes()).hexdigest()
  if a.escopo=='tres':
   if a.isolado is None:raise ValueError()
   receipt_path=caminho(a.isolado)
   receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
   if receipt['escopo']!='isolado' or receipt['resultado']!='PASS' or receipt['manifesto_sha256']!=version_hash:
    raise ValueError()
   if conferir_resultado(receipt_path.parent,1,caminho)!=receipt['evidencias_sha256']:raise ValueError()
 except Exception:
  print('{"estado":"BLOQUEADO","codigo":"PACOTE_CANDIDATA_OU_PASS_ISOLADO_INVALIDOS"}')
  return 2
 sys.path.insert(0,str(a.candidata))
 from tools.exp04_win import executar
 expected=1 if a.escopo=='isolado' else 3
 executar.SCOPES={'complementares':(['-x',ALVO] if expected==1 else ['-x',*TRES],expected)}
 captured=io.StringIO()
 with contextlib.redirect_stdout(captured):
  code=executar.main(['--versao',str(version),'--evidencias',str(a.evidencias),'--escopo','complementares'])
 print(captured.getvalue(),end='')
 if code!=3:return 2
 try:
  meta=json.loads(captured.getvalue())
  folder=caminho(a.evidencias/meta['relatorio']).parent
  evidence_hashes=conferir_resultado(folder,expected,caminho)
  conferir(a.pacote,a.candidata,True)
  receipt={'escopo':a.escopo,'resultado':'PASS','manifesto_sha256':version_hash,
           'evidencias_sha256':evidence_hashes,'sistema':sys.platform,'python':sys.version.split()[0],
           'api':'CreateFileW','win32':32,'comparacao_integral':True,'DACL':'NÃO_VALIDADO',
           'homologacao_windows':False,'conversoes_reais':'BLOQUEADAS'}
  with (folder/'r1fix-validacao.json').open('x',encoding='utf-8') as f:
   json.dump(receipt,f,ensure_ascii=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 except Exception:
  print('{"resultado":"NAO_VALIDADO","codigo":"CRITERIOS_R1FIX_NAO_ATENDIDOS"}')
  return 2
 print(json.dumps(receipt,ensure_ascii=True))
 return 3


if __name__=='__main__':raise SystemExit(main())
