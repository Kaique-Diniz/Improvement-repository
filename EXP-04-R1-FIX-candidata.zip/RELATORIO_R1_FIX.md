# EXP-04 — R1-FIX: correção da fixture e limite da validação

## Estado da entrega

Candidata nova e isolada, derivada da R1 de 470 hashes, baseline
`770d062d29c4361d6932592883df9339bb4089bc`. A candidata anterior permanece intacta.
A nova candidata também tem 470 arquivos; 469 são byte a byte iguais à referência.
Só `tools/exp04_win/test_cleanup_windows.py` mudou, em duas funções: o helper da
fixture e o cenário afetado. Motor, executor, produção, DACL, políticas e todos
os demais testes/fixtures foram preservados.

| Evidência pedida | Resultado desta tarefa |
|---|---|
| Teste isolado Windows | NAO_EXECUTADO — ambiente disponível é Linux |
| Resultado PASS/FAIL nativo | NÃO_VALIDADO; nenhum PASS/FAIL foi emitido |
| API efetivamente observada na nova execução | Não coletada; esperado CreateFileW |
| Win32 real na nova execução | Não coletado; esperado 32, sem atribuí-lo por suposição |
| Preservação/bytes integrais no Windows | NAO_EXECUTADO |
| Três testes posteriores | NAO_EXECUTADO; dependem de PASS isolado nativo |
| Suíte de 39 | NÃO EXECUTADA |
| Integridade da candidata | 470 hashes conferidos, um arquivo diferente da referência |

Nenhum teste foi executado em Linux como substituto. O preflight nativo foi
chamado e recusou a execução com WINDOWS_NATIVO_INDISPONIVEL, retorno 2 e zero
testes executados. Isso é bloqueio de ambiente, não FAIL do teste. Não existem
JUnit Windows novos desta tarefa; gerar conforme ROTEIRO_WINDOWS.md.

## Correção e por que o diff inclui diagnóstico

- `processo_aberto` aceita `acesso` opcional com default READ_ATTRIBUTES (0x80),
  para não alterar o cenário existente de share 0x7. Só o teste afetado passa
  GENERIC_READ (0x80000000). O subprocesso recebe o valor explicitamente e mantém
  share 0x3, OPEN_EXISTING, flags e assinatura nativa anteriores.
- Permanecem PRONTO após handle válido, bloqueio em stdin e CloseHandle ao sair.
  O processo não é liberado antes da tentativa. Se já encerrou antes da tentativa,
  o cenário falha sem pedir exclusão. Exige-se que ele continue ativo depois.
- `liberar(p)` continua no finally externo: falha nas asserções ou no registro
  de diagnóstico não evita sua chamada. Os limites/timeouts anteriores não foram
  alterados; não se promete encerramento forçado de um processo preso em API do SO.
- A expectativa continua sendo primeira_falha.api == CreateFileW e win32 == 32.
  O motor mantém a captura imediata de GetLastError, sem alteração.
- Antes dessas asserções, um finally interno registra propriedades JUnit e JSON
  sanitizado fora do Git, com criação exclusiva, flush e fsync. Essa persistência
  também ocorre se remover falhar de modo inesperado ou não lançar a exceção
  esperada. Não há nomes/caminhos privados, tokens ou conteúdo documental no JSON.
- Após liberar o processo, o teste lê o arquivo INTEIRO e compara exatamente com
  os bytes sintéticos originais. Registra igualdade/tamanho e encerramento em JSON
  antes da asserção de igualdade; não substitui comparação por exists() ou hash.

O diff contém 36 adições/8 remoções no único arquivo: além do parâmetro/acesso,
a observabilidade e a persistência acima foram exigidas explicitamente pelo
pedido. Nenhuma implementação de exclusão, flag dos pins ou política foi tocada.
Se não houver --junitxml, o cenário falha R1FIX_JUNIT_OBRIGATORIO: sem evidência
persistente não haverá PASS. Os demais testes não passaram a exigir esse registro.

## Conferências estáticas realizadas

- Hashes de todos os arquivos comparados com os 470 da R1: só o arquivo indicado difere.
- AST: só as duas funções permitidas mudaram; todos os outros nós do módulo iguais.
- Sintaxe do módulo e do código Python entregue ao auxiliar conferida em memória.
- Default do helper permanece 0x80; somente o alvo pede 0x80000000, share 0x3.
- Sinalização PRONTO e stdin/finally inspecionados; asserções Win32 e de bytes mantidas.
- Patch incremental conferido com git apply --check na candidata anterior, sem aplicar nela.

Essas conferências não comprovam o conflito de compartilhamento no Windows nem
satisfazem os cinco critérios nativos de aprovação. A validação permanece pendente.
O relatório de preservação registra hashes/HEAD/status/refs das candidatas anteriores.
Sem commit, push, PR, merge, publicação ou acesso ao residual antigo.

## Próxima ação limitada

Revisar R1_PARA_R1_FIX.patch. Reconstruir Windows em worktree nova com LF e
manifesto VERSAO_R1_FIX_SHA256.json. Executar somente o alvo. Se PASS com API/código
reais, bytes íntegros, auxiliar encerrado, temporário removido e hashes íntegros,
executar os três originais da R1. O lançador exige os arquivos da evidência isolada
antes de permitir a etapa posterior e usa -x para parar na primeira falha.

Qualquer API/código diferente: preservar evidência e parar para diagnóstico,
sem flexibilizar asserções. Não executar os 39. Homologação Windows e DACL efetiva
permanecem NÃO_VALIDADO; conversões reais dos quatro novos condomínios BLOQUEADAS.
