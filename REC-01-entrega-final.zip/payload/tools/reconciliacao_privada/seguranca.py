"""Contenção estática, leitura por handle e integridade; não certifica DACL."""
from dataclasses import dataclass
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import stat


class Bloqueio(Exception):
    """Somente códigos constantes podem alcançar o terminal."""
    def __init__(self, codigo):
        super().__init__(codigo)
        self.codigo = codigo


def hash_bytes(data):
    return sha256(data).hexdigest()


def json_bytes(data):
    return (json.dumps(data, ensure_ascii=True, sort_keys=True, indent=2,
                       allow_nan=False) + '\n').encode('utf-8')


def caminho_estatico(path, *, arquivo=False):
    """lstat em TODOS os ancestrais, antes de resolver; sem atravessar links."""
    p = Path(os.path.abspath(path))
    for node in (*reversed(p.parents), p):
        try:
            st = node.lstat()
        except OSError:
            raise Bloqueio('CAMINHO_INACESSIVEL') from None
        if (stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400
                or (hasattr(node, 'is_junction') and node.is_junction())):
            raise Bloqueio('LINK_OU_REPARSE_RECUSADO')
        if node != p and not stat.S_ISDIR(st.st_mode):
            raise Bloqueio('PAI_NAO_DIRETORIO')
    if arquivo and not stat.S_ISREG(st.st_mode):
        raise Bloqueio('ARQUIVO_NAO_REGULAR')
    if not arquivo and not stat.S_ISDIR(st.st_mode):
        raise Bloqueio('RAIZ_NAO_DIRETORIO')
    return p


def relativo_seguro(texto):
    if (not isinstance(texto, str) or not texto or '\\' in texto or ':' in texto
            or '\x00' in texto):
        raise Bloqueio('CAMINHO_RELATIVO_INVALIDO')
    p = PurePosixPath(texto)
    if p.is_absolute() or any(x in ('', '.', '..') for x in texto.split('/')):
        raise Bloqueio('CAMINHO_RELATIVO_INVALIDO')
    return p


def fora_git(path):
    """Metadados incompletos também bloqueiam; não depende de stderr do Git."""
    p = caminho_estatico(path)
    for node in (p, *p.parents):
        if os.path.lexists(node / '.git'):
            raise Bloqueio('AREA_PRIVADA_DENTRO_GIT')
        if sum(os.path.lexists(node / n) for n in ('HEAD', 'objects', 'refs', 'config')) >= 2:
            raise Bloqueio('AREA_PRIVADA_DENTRO_GIT')
    return p


def assinatura(st):
    return st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns


@dataclass
class Arquivo:
    caminho: Path
    digest: str
    identidade: tuple
    conteudo: bytes

    @classmethod
    def ler(cls, root, nome, esperado=None, limite=100 * 1024 * 1024):
        root = caminho_estatico(root)
        p = root.joinpath(*relativo_seguro(nome).parts)
        caminho_estatico(p, arquivo=True)
        if not p.is_relative_to(root):
            raise Bloqueio('FONTE_FORA_RAIZ')
        antes = p.lstat()
        # O_NOFOLLOW protege a folha no POSIX; as guardas Windows são estáticas.
        flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
        try:
            fd = os.open(p, flags)
            with os.fdopen(fd, 'rb') as handle:
                st = os.fstat(handle.fileno())
                if not stat.S_ISREG(st.st_mode) or assinatura(st) != assinatura(antes):
                    raise Bloqueio('FONTE_SUBSTITUIDA')
                if st.st_size > limite:
                    raise Bloqueio('LIMITE_ARQUIVO_EXCEDIDO')
                data = handle.read(limite + 1)
                depois = os.fstat(handle.fileno())
            caminho_estatico(p, arquivo=True)
            if (len(data) > limite or assinatura(st) != assinatura(depois)
                    or assinatura(st) != assinatura(p.lstat())):
                raise Bloqueio('FONTE_SUBSTITUIDA')
        except OSError:
            raise Bloqueio('FALHA_LEITURA') from None
        digest = hash_bytes(data)
        if esperado is not None and digest != esperado:
            raise Bloqueio('HASH_DIVERGENTE')
        return cls(p, digest, assinatura(st), data)

    def conferir(self):
        atual = Arquivo.ler(self.caminho.parent, self.caminho.name, self.digest)
        if atual.identidade != self.identidade:
            raise Bloqueio('FONTE_SUBSTITUIDA')


def verificar_candidata(root, manifesto):
    root = caminho_estatico(root)
    expected = manifesto['arquivos']
    if not isinstance(expected, dict) or not expected:
        raise Bloqueio('MANIFESTO_CANDIDATA_INVALIDO')
    for name, digest in sorted(expected.items()):
        Arquivo.ler(root, name, digest, limite=30 * 1024 * 1024)
    # Não admitir fonte Python extra (import shadowing), nem links extras.
    stack = [root]
    while stack:
        folder = stack.pop()
        for p in folder.iterdir():
            if p.name == '.git' and p.parent == root:
                # Worktree legítima pode conter .git arquivo; nunca importado.
                if p.is_symlink():
                    raise Bloqueio('LINK_OU_REPARSE_RECUSADO')
                continue
            st = p.lstat()
            if stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400:
                raise Bloqueio('LINK_OU_REPARSE_RECUSADO')
            if stat.S_ISDIR(st.st_mode):
                if p.name not in ('__pycache__', '.pytest_cache', 'work'):
                    stack.append(p)
            elif stat.S_ISREG(st.st_mode):
                if str(p.relative_to(root)).replace(os.sep, '/') not in expected:
                    raise Bloqueio('ARQUIVO_EXTRA_CANDIDATA')
            else:
                raise Bloqueio('ARQUIVO_NAO_REGULAR')
    return len(expected)


def pasta_saida(parent, nome):
    parent = fora_git(parent)
    relativo_seguro(nome)
    if '/' in nome:
        raise Bloqueio('NOME_SAIDA_INVALIDO')
    target = parent / nome
    try:
        target.mkdir(mode=0o700)  # Sem exist_ok: nunca sobrescrever evidências.
    except OSError:
        raise Bloqueio('SAIDA_EXISTENTE_OU_INACESSIVEL') from None
    return target


def gravar_novo(path, data):
    caminho_estatico(path.parent)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_BINARY', 0)
                 | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
