# H3-D — resumo das decisões para o usuário

24/11/2026. Preparado para auditoria e posterior decisão; nenhuma escolha feita pelo
Codex foi convertida em aprovação. Não enviar XML bruto ou dados pessoais na conversa.

## Escolhas que precisam ser formalizadas

| Grupo | O que decidir | Onde manter a informação sensível |
|---|---|---|
| Custodiante e pessoas | Pessoa real legitimada, responsabilidades, acesso mínimo, registros, revisão de retenção e substituição | Designação nominal em registro privado; não nomes/SIDs/contas no chat |
| Ambiente e destino | Máquina/volume locais legítimos, lugar novo/exclusivo, separação das áreas vedadas, ausência de nuvem/remoto/redirecionamento | Caminho real e identificação da máquina somente privados |
| Proteção existente | Quem pode acessar de fato e qual evidência demonstra proteção suficiente sem mudar ACL/privilégios | Evidência privada examinada em futura etapa autorizada |
| Retenção | Escolher A/B/C, duração/data máxima, marco, revisão, prorrogação, preservação e autoridade de descarte | Política aprovada com referência; nenhuma herança de 90 dias de B |
| Validade da autorização | Início e término/expiração, escopo, revogação, aprovador e registro efetivo | Minuta final privada com decisão real; data do documento não é aprovação |
| Procedimento e cadeia | Etapa posterior de preparação/revisão específica e registro privado de eventos | Não há comando de cópia nem cadeia preenchida nesta H3-D |

O alias CUSTODIANTE_DESIGNADO só representará uma pessoa depois da designação real;
não herdar o operador H2 ou CUSTODIANTE_USUARIO do Portão B. Pessoas/papéis podem
ser apenas os mínimos necessários, mas precisam de decisão concreta, não presunção.

## Como registrar decisões posteriormente

Usar os IDs H3D-D01..D20 da matriz para relacionar escolha, evidência necessária,
responsável, data/hora reais e referência de aprovação. Manter detalhes sensíveis
privados; compartilhar apenas estados, escolhas não sensíveis e referências
sanitizadas expressamente autorizadas. Não é solicitado preenchimento de nomes,
contas, credenciais ou caminho pessoal nesta conversa.

Somente decisão real e identificável pode levar um item a APROVADO_EXPLICITAMENTE.
Se houver reprovação/impedimento, preservar o motivo e estado, sem converter sugestão
em autorização. Aprovar um parâmetro isolado não aprova todos os outros ou H3-C.

## Próxima decisão possível e parada atual

Revisar estes nove documentos e completar as decisões em registro privado. H3-C
continua não pronta para autorização operacional: faltam parâmetros e procedimento
específico. Após aprovação dos parâmetros poderá ser deliberada etapa técnica
separada, ainda sem copiar. Nenhuma custódia, H3-S ou H4 é iniciada pela H3-D.

Não realizar agora leitura Windows adicional, inspeção de permissões, criação de
pasta, cópia, execução ou transferência. Não apresentar uma verificação ainda não
realizada como aprovada; a documentação atual só organiza as decisões pendentes.
