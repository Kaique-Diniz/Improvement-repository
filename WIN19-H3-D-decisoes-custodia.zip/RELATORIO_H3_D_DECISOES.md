# WIN19-H3-D — decisões de custódia para revisão

24/11/2026 — America/Sao_Paulo.
**H3-D = DECISOES_DOCUMENTADAS_AGUARDANDO_APROVACAO.**

## Resultado da preparação

Produzidos os nove documentos autorizados, reutilizando as análises H3-P. A matriz
identifica 20 decisões: 18 PENDENTE e duas PROPOSTO_NAO_APROVADO. Não há parâmetro
novo APROVADO_EXPLICITAMENTE, assinatura, pessoa designada, destino escolhido,
prazo vigente ou autorização de cópia. Os IDs H3D-D01..D20 são decisões documentais,
não controles WIN, testes ou eventos de custódia.

A H3-P foi aceita documentalmente com ressalvas pelo parecer de 24/11. A aceitação
não preencheu os parâmetros concretos, que continuam pendentes. Em especial,
proteção e acesso de um destino real ainda não foram examinados e não se consideram
reprovados por ausência de exame: apenas não demonstrados/aprovados.

## Referência histórica limitada

H2: IDENTIFICADO_COM_LIMITACOES, conforme resumo Windows fornecido pelo usuário.
Alvo: completa-utf8.xml, no caminho nominal histórico relativo a LOCALAPPDATA.
Referência informada: 441505 bytes; SHA-256
`3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`;
modificação UTC `2026-11-17T12:55:35.1745094Z`.
Não houve acesso ou recálculo do hash do XML pelo Codex nesta H3-D. A autenticidade
histórica, comando/código da época e uso do manifesto 448 não foram demonstrados.

## Escolhas e responsabilidade

As alternativas da matriz são admissíveis somente dentro das restrições existentes;
nenhuma aprovação pode dispensar origem nominal, integridade, privacidade,
autorização específica ou proibição de enfraquecimento de segurança. As sugestões
D06 (objeto/finalidade) e D18 (condições de suspensão) não autorizam a operação.

Nomes, pessoas, máquina/volume e caminho real serão preenchidos exclusivamente em
registro privado controlado pelo usuário. O alias CUSTODIANTE_DESIGNADO só poderá
representar uma pessoa após designação real; não herdar o operador H2 ou a função
CUSTODIANTE_USUARIO do Portão B. O responsável por cada decisão é um papel a ser
legitimamente exercido, não uma pessoa presumida pelo Codex.

A retenção exige escolha expressa A/B/C, duração/limite, marco, revisão,
prorrogação/preservação e autoridade de descarte. Nenhuma opção está selecionada.
Validade da autorização de cópia tem início e fim próprios; não é prazo de retenção.
Expirar qualquer prazo não concede eliminação de XML, parciais ou registros.

## Distinção entre pendências e verificações

Bloqueios documentais conhecidos: não há designação, lista de pessoas, destino/
proteção aprovados, retenção aprovada, termo vigente ou procedimento Windows
específico revisado. Esses fatos impedem liberação operacional.

Verificações ainda não realizadas: estado atual/fingerprint da fonte, condições
reais do destino, redirecionamentos, permissões existentes, exclusividade na hora
da operação, integridade e fechamento de uma cópia futura. Nenhuma delas foi
marcada como executada, aprovada ou reprovada nesta etapa.

## Sequência posterior possível, sem autorização implícita

Após auditoria destes documentos, o usuário poderá decidir os parâmetros em registro
privado. Somente depois caberá um escopo separado para detalhar/revisar o procedimento
Windows específico, ainda sem executar a cópia. O termo operacional final deverá
identificar esse procedimento aprovado e a validade, antes de qualquer execução H3-C.
A minuta atual não dá autorização em branco para um método ainda inexistente.

Prontidão atual: documentos preparados para auditoria, H3-C NAO_AUTORIZADA. Não foi
criado procedimento operacional, PowerShell, custódia, XML, script, contrato ou ZIP.
A pasta criada é exclusivamente a pasta documental expressamente autorizada nos
entregáveis, não um destino privado de custódia.

Categoria A CONSOLIDADA_DOCUMENTALMENTE; H3-P aceita documentalmente com ressalvas;
H3-C/H3-S/H4 NAO_AUTORIZADAS; vínculos PROVISORIO_SEM_FONTE; WIN/DACL NÃO_VALIDADO;
runner NÃO_IMPLEMENTADO; C/D/E BLOQUEADOS; conversões reais BLOQUEADAS; prontidão
para ensaios false. Sem modificação de fontes, R1-FIX, Git, ACL, contas, privilégios,
políticas, testes, commit, push, merge ou publicação. Parar para auditoria e decisões.
