# WIN19-H3-D — índice e proveniência

24/11/2026 — America/Sao_Paulo. Pasta exclusiva de documentação:
`/workspace/work/WIN19-H3-D-DECISOES-CUSTODIA-20261124`.
Fora do Git/candidata; não é diretório de custódia nem destino de XML. A pasta é
somente a área documental expressamente autorizada nos entregáveis.

## Nove arquivos entregues

1. [RELATORIO_H3_D_DECISOES.md](RELATORIO_H3_D_DECISOES.md) — objetivo, situação e escopo.
2. [MATRIZ_DECISOES_H3.csv](MATRIZ_DECISOES_H3.csv) — 20 parâmetros, nove colunas,
   alternativas/evidências/responsabilidade/estado/consequências de ausência de aprovação.
3. [MINUTA_AUTORIZACAO_H3_C.md](MINUTA_AUTORIZACAO_H3_C.md) — MINUTA_NAO_APROVADA,
   não assinada, com ficha de pessoas a preencher somente privadamente.
4. [CHECKLIST_DESTINO_E_ACESSO.md](CHECKLIST_DESTINO_E_ACESSO.md) — verificações privadas
   futuras; nenhum item operacional marcado como executado.
5. [PROPOSTA_DECISAO_RETENCAO.md](PROPOSTA_DECISAO_RETENCAO.md) — A/B/C, vantagens,
   limites e requisitos, sem seleção ou prazo presumidos.
6. [CRITERIOS_LIBERACAO_H3_C.md](CRITERIOS_LIBERACAO_H3_C.md) — condições cumulativas,
   bloqueios conhecidos e distinção das condições ainda não verificadas.
7. [DECISOES_PENDENTES_USUARIO.md](DECISOES_PENDENTES_USUARIO.md) — resumo objetivo
   de escolhas, sem solicitar dados pessoais ou XML na conversa.
8. INDICE_ENTREGA_H3_D.md — este registro de fontes e preservação.
9. [MANIFESTO_SHA256_H3_D](MANIFESTO_SHA256_H3_D) — tamanhos/hashes dos oito
   documentos anteriores; exclui apenas a si mesmo, com hash informado na conversa.

## Instrução e parecer obrigatórios

Instrução H3-D, Texto colado.txt, 11.370 bytes, SHA-256
`9deacf79faa0d703a809358ef80cce276b28109fa27cb3f754075df218b1824f`.
Referência principal de autorização exclusivamente documental. Parecer independente
H3-P de 24/11/2026, 7.907 bytes, SHA-256
`06b72d5cf8e73b2ad81caa530d5d4e7357b4c51228c5aa731184b3a3ddf7b9b6`.
Aceita H3-P documentalmente com ressalvas e mantém H3-C não pronta; não concede
execução. Nenhum anexo foi executado ou copiado para esta entrega.

## Documentação H3-P reutilizada, sem refazer análises

| Fonte H3-P lida | Bytes | SHA-256 conferido |
| --- | --- | --- |
| TERMO_AUTORIZACAO_CUSTODIA_PROPOSTO.md | 4234 | 4e5f406d6b4bf2b28a6a31b35acd191a6cdc8964344439f8481a20ebe28f5f4a |
| REQUISITOS_DESTINO_E_ACESSO.md | 3493 | 358e50315e3f84a63532840d124e57a4a71555cf98e45097762d690be77c3792 |
| POLITICA_RETENCAO_PROPOSTA.md | 3186 | f95c94c7b1e68cb95b07fd160c63800d5de34f69c829bfa02c24ed980a3d235f |
| PLANO_COPIA_FIEL.md | 6032 | f4a35e1bbcbc8a579c6912391cb098ac56a9dbed2d496aecb6f9c95c1147211f |
| MATRIZ_IMPEDIMENTOS_H3.md | 3101 | 46d1ecea91af8dd49d65668d17d9fad21704d32f9e4489026b6d2c27061e6ff3 |
| DECISOES_E_PORTOES_H3.md | 2624 | 95a12421ecc21cee20629505013dd33e29abe95c65e6c9acedb7eea870ce1b74 |

Manifesto H3-P autenticado:
`caffd5a530cc13998e8349a4bedea707a3838648a084f0df3bbdea07773a4b41`.
Seus nove documentos foram conferidos por tamanho/hash e permaneceram idênticos
antes/depois da redação. A H3-D organiza decisões e minutas, sem substituir o plano
ou requisitos anteriores por implementação. Os links de origem permanecem em H3-P.

Avaliação H2 documental consultada, 7.360 bytes, SHA-256
`9f9f5d1a872d94c0bd4b7e3363f4f7432b262c0845d519f99a4ddfafc5c320cd`.
É avaliação local do resumo fornecido pelo usuário, não XML nem recálculo de seus
bytes. O fingerprint H2 permanece valor relatado, sem nova leitura nesta etapa.

## Integridade e natureza dos registros novos

A matriz contém estados permitidos PENDENTE, PROPOSTO_NAO_APROVADO,
APROVADO_EXPLICITAMENTE, REPROVADO ou BLOQUEADO. Nesta entrega os valores efetivos
são 18 PENDENTE e dois PROPOSTO_NAO_APROVADO, sem aprovação real presumida.
IDs H3D-D01..D20 identificam parâmetros, não resultados de testes ou custódia.

Somente escrita de Markdown/CSV e metadados de integridade foi realizada com
utilitários locais e Python -I -B/stdlib pathlib/hashlib/escritor CSV. Nenhum bloco
recebido, PowerShell, módulo do produto, parser XML ou procedimento operacional
foi executado. Não há script auxiliar entregue, contrato novo, XML, cópia, depósito,
resultado Windows, assinatura, caminho pessoal, conta, SID ou credencial no material.

## Estados e parada

Categoria A CONSOLIDADA_DOCUMENTALMENTE; H2 IDENTIFICADO_COM_LIMITACOES;
H3-P ACEITA_DOCUMENTALMENTE_COM_RESSALVAS;
H3-D DECISOES_DOCUMENTADAS_AGUARDANDO_APROVACAO; H3-C/H3-S/H4 NAO_AUTORIZADAS;
DESTINO_H3 PENDENTE_DE_APROVACAO; RETENCAO_H3 PENDENTE; custodiante/pessoas pendentes;
vínculos PROVISORIO_SEM_FONTE; WIN/DACL NÃO_VALIDADO; runner NÃO_IMPLEMENTADO;
C/D/E BLOQUEADOS; conversões BLOQUEADAS; prontidão para ensaios false.
T01/T06 ESPECIFICADO, T02 BLOQUEADO, T03/T04/T05/T07 PARCIAL; D01–D10 PARA_APROVAÇÃO.

Nenhuma fonte anterior ou R1-FIX foi modificada. Sem inspeção Windows, ACL/DACL,
privilégio, política, conta, Git, worktree, testes, preflight, cópia, sanitização,
reconciliação, limpeza, commit, push, merge, publicação ou ZIP. Parar para auditoria
e aprovação dos parâmetros; não criar procedimento operacional de cópia agora.
