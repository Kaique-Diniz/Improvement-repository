# H3-D — checklist do destino privado futuro

24/11/2026. Reaproveita REQUISITOS_DESTINO_E_ACESSO.md da H3-P.
**DESTINO_H3=PENDENTE_DE_APROVACAO.** Nenhum destino foi escolhido ou examinado.

Todos os itens abaixo estão **NÃO VERIFICADOS NESTA ETAPA**. O preenchimento real
é privado; a referência compartilhável pode conter apenas alias/estado/evidência
sanitizada autorizados, não nomes, SIDs, contas ou caminhos completos.

| Critério | Evidência/decisão privada necessária | Consequência se não demonstrado |
|---|---|---|
| Máquina e volume sob controle legítimo | Identificação real e autoridade de controle | Não aprovar ambiente/destino |
| Local novo e exclusivo | Caminho aprovado para criação futura, sem materialização agora | Não presumir exclusividade pelo nome |
| Ausência de sincronização automática | Confirmação de configuração já existente pertinente ao local | Não copiar enquanto houver dúvida |
| Ausência de compartilhamento remoto | Confirmação de exposição e pessoas efetivamente autorizadas | Não aprovar exposição não demonstrada |
| Fora de Git/worktrees/raízes ambíguas | Identificação de separação por procedimento futuro autorizado | Dúvida impede aprovação, sem limpar/reconfigurar Git |
| Fora de R1-FIX e outras candidatas | Referência privada da separação | Não usar área auditada como depósito |
| Fora de contratos C5–C8 | Separação do material declarativo | Não consolidar custódia junto dos contratos |
| Fora de Portão B e custódias anteriores | Destino próprio, sem herdar autorização/acesso | Não reabrir custódia anterior |
| Sem reparse/redirecionamento inesperado ou alias ambíguo | Identidade suficientemente demonstrada por revisão futura | Não seguir outra fonte/destino |
| Proteção existente suficiente | Evidência legítima de acesso/proteção do XML, parciais e registros | Manter destino pendente; não enfraquecer segurança |
| Pessoas efetivamente autorizadas | Relação nominal privada mínima com responsabilidades | Não presumir acesso por pertencimento a grupo |
| Ausência de alvo sobrescrevível | Regra de criação exclusiva e resposta a colisões | Não sobrescrever, limpar ou escolher outro destino automaticamente |
| Criação exclusiva sem privilégios adicionais | Método futuro revisado e acesso já legítimo | Não elevar privilégio ou alterar política |

Não executar comandos, preflight, inspeção de permissões, testes entre contas ou
leituras Windows para preencher o checklist nesta H3-D. Não criar pasta para
verificar se depois poderá ser aprovada. Não modificar ACL/DACL, owner, grupos,
usuários, privilégios ou políticas. Ler uma ACL isoladamente não demonstra todos
os acessos efetivos; a aprovação do aplicativo/DACL não é substituto do depósito.

A ausência de prova de proteção mantém PENDENTE_DE_APROVACAO, não uma aprovação
por declaração genérica. Também não equivale a um teste de permissões reprovado,
porque nenhum destino real foi examinado. Não há caminho sugerido/preaprovado.

Depois dos parâmetros aprovados, uma etapa própria poderá preparar a verificação
privada e o procedimento técnico. Essa decisão não é concedida por este checklist.
