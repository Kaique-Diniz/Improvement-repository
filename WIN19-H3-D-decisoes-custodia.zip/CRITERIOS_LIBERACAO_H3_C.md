# H3-D — critérios para futura liberação operacional H3-C

24/11/2026. Consolidam condições do PLANO_COPIA_FIEL.md e MATRIZ_IMPEDIMENTOS_H3.md
existentes. **Nenhuma verificação abaixo foi executada nesta H3-D.** Não é novo
procedimento de cópia; APIs, flags, comandos e implementação permanecem por definir.

## Condições cumulativas

1. Fonte nominal autenticada no nível observável necessário e sem ambiguidade;
   referência H2 é fingerprint relatado, não prova de autenticidade histórica.
2. Tamanho/SHA-256 atuais iguais a 441505 bytes e
   `3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`.
3. Custodiante e pessoas/acesso legitimamente aprovados em registro privado.
4. Ambiente/destino novo, exclusivo e protegido aprovados, sem áreas vedadas,
   sincronização automática, redirecionamento ou permissões insuficientes.
5. Retenção própria aprovada, com marco, revisão e regra de decisão de descarte.
6. Termo operacional nominal vigente, escopo/validade/aprovador identificáveis.
7. Procedimento Windows específico identificado e tecnicamente revisado/aprovado,
   somente em etapa posterior à decisão dos parâmetros necessários.
8. Garantia de criação exclusiva do arquivo futuro, sem sobrescrita ou link como
   substituto de cópia independente; técnica ainda não especificada nesta etapa.
9. Preservação dos bytes e da origem, sem parsing, normalização ou edição.
10. Conferência de integridade após cópia/conclusão/fechamento e estabilidade da fonte.
11. Cadeia privada adequada registrando apenas eventos efetivamente realizados.
12. Tratamento explícito de falhas, parciais, identidade e alterações concorrentes.

Essas condições são requisitos futuros, não resultados de medições presentes.
A H3-D não reexecutou H2 e não calculou o hash do XML. Data de modificação H2:
2026-11-17T12:55:35.1745094Z, como referência relatada. O tratamento de eventual
variação de timestamp com hash igual precisa de decisão conforme H3-P; não
restaurar timestamps ou deixar indefinição ser interpretada como aceite.

## Bloqueios documentais conhecidos hoje

Não há designação de custodiante/pessoas, destino/proteção aprovados, retenção
aprovada, validade/termo operacional vigente ou procedimento específico aprovado.
Assim, H3-C permanece NAO_AUTORIZADA. Minutas completas não removem esses bloqueios.

## Condições físicas ainda não verificadas

Estado atual/regularidade do XML, fingerprint atualizado, volume/caminho de destino,
proteção real, ausência de reparse/alias, possibilidade de criação exclusiva,
estabilidade durante operação e integridade da cópia futura não foram examinados.
Não registrar esses itens como falhas observadas nem como verificações concluídas.

## Impedimentos que bloqueiam a operação se ocorrerem

Custodiante não designado; pessoas indefinidas; destino não aprovado ou proteção
insuficiente; retenção pendente; validade indefinida; método não aprovado;
autorização ausente/expirada; fingerprint H2 divergente; fonte/destino ambíguos;
tentativa de sobrescrita; exigência de elevação ou alteração de ACL. Sem métodos
alternativos automáticos para contornar impedimentos, novas buscas, cópia alternativa,
limpeza de parciais, publicação de logs privados ou reexecução de testes.

## Ordem de decisões, sem autorização em branco

Primeiro revisar e aprovar os parâmetros concretos. Depois, mediante escopo próprio,
detalhar/revisar o procedimento Windows específico sem executá-lo. Só após o método
estar identificado e aprovado poderá ser deliberado o termo operacional final com
validade e escopo. Não escrever, implementar, executar ou testar PowerShell de cópia
nesta H3-D. Um termo que aponta para procedimento indefinido não libera operação.

A cópia futura poderá demonstrar correspondência criptográfica observada, não
história do run, comando, código, manifesto 448, persistência forense ou DACL.
Nenhuma condição desta lista inicia H3-C, H3-S ou H4 automaticamente.
