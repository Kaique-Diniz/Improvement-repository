# H3-D — ficha de decisão de retenção

24/11/2026. Reutiliza POLITICA_RETENCAO_PROPOSTA.md da H3-P.
**RETENCAO_H3=PENDENTE. Nenhuma alternativa selecionada ou prazo aprovado.**

| Alternativa | Vantagens para decisão | Limitações | Requisitos obrigatórios |
|---|---|---|---|
| A — Prazo fixo | Limite temporal e revisão objetivos | Duração precisa ser justificada; finalidade pode mudar | Duração/data-limite expressa, marco inicial, responsável, revisão e regra de descarte autorizado |
| B — Vinculada à finalidade | Relação explícita com marco documental definido | Finalidade aberta pode perpetuar retenção se não houver limite | Marco inequívoco, data máxima, revisão obrigatória, responsável e regra de encerramento |
| C — Preservação excepcional | Atende obrigação legítima quando efetivamente aplicável | Não cabe por mera conveniência ou presunção de obrigação | Fundamento documentado, autoridade competente, alcance, condições e reavaliação específicas |

Nenhuma é opção padrão. O Codex não escolheu quantidade de dias, data-limite ou
prazo indefinido. Os 90 dias do Portão B não se transferem para H3.

## Campos separados para futura aprovação

| Campo de decisão | Estado atual |
|---|---|
| Alternativa e finalidade específica | PENDENTE |
| Prazo/duração ou data-limite/data máxima | PENDENTE |
| Marco inicial da contagem | PENDENTE |
| Revisão periódica ou data de revisão | PENDENTE |
| Responsável pela custódia e revisão | PENDENTE de designação real privada |
| Condições de prorrogação e nova revisão | PENDENTE |
| Obrigações de preservação e seu fundamento | PENDENTE de avaliação legítima |
| Exceções e registro rastreável | PENDENTE |
| Responsável pela decisão de descarte | PENDENTE |
| Autorização específica para qualquer eliminação | NÃO CONCEDIDA; deve ser decisão própria |
| Referência/data/hora de aprovação da política | PENDENTE; nenhum valor fictício |

O início da retenção deve ser escolhido expressamente. A modificação do XML em
17/11 e a data desta preparação não são marcos automáticos. A validade temporal
do termo de cópia é decisão independente, preenchida em sua própria minuta.

Expiração do prazo, conclusão de etapa, revogação, cópia parcial ou hash divergente
não autorizam excluir XML, parciais ou registros. A revisão futura deve avaliar
finalidade/obrigações, identificar peças e obter autorização específica de eliminação.
Prorrogação exige justificativa e decisão rastreável, sem renovação automática.

Sem política completa aprovada, H3-C não pode ser autorizada operacionalmente.
Não há automação, agenda, comando de exclusão ou procedimento executável de descarte.
