# H3-D — minuta de autorização H3-C

24/11/2026 é data da preparação documental, não de aprovação.
**MINUTA_NAO_APROVADA — NÃO ASSINADA — H3-C NAO_AUTORIZADA.**

## Objeto de referência, ainda sem autorização de cópia

completa-utf8.xml, caminho histórico nominal relativo a LOCALAPPDATA referido na H2.
Fingerprint relatado pelo usuário: 441505 bytes, SHA-256
`3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`,
modificação UTC `2026-11-17T12:55:35.1745094Z`. É referência para confronto futuro,
sem recálculo atual ou prova de autenticidade histórica. Finalidade proposta:
preservação privada de cópia fiel para decisões posteriores de exame histórico.

## Campos do futuro termo operacional

Todos os campos de decisão permanecem PENDENTE. Identidades pessoais e locais
concretos devem ser preenchidos somente no registro privado do usuário.

| Campo | Preenchimento exigido futuramente | Referência |
|---|---|---|
| Identificador e versão da autorização | ID inequívoco, limites e documentos aprovados | D14 |
| Arquivo/finalidade | Confirmação nominal do alvo e finalidade limitada | D06 |
| Custodiante real | Designação privada, responsabilidade e substituição formal | D01 |
| Pessoas e papéis | Relação privada mínima, responsabilidades por acesso/registros/retenção | D02 |
| Ambiente | Máquina/volume legitimamente controlados, referência privada | D03 |
| Destino/proteção | Local novo/exclusivo e evidência de proteção existente suficiente | D04/D05 |
| Operações autorizadas | Decisão expressa de leitura de integridade, criação exclusiva de cópia fiel e registros necessários | D06/D18 |
| Procedimento técnico | Identificação e versão do procedimento Windows específico, revisto separadamente após parâmetros | D17 |
| Início da validade | Data/hora/fuso ou condição objetiva aprovada, sem retroatividade presumida | D15 |
| Término/expiração | Data/hora ou condição objetiva delimitada, sem prazo indefinido | D16 |
| Política de retenção | Alternativa, prazo/marco, revisão, preservação, prorrogação e descarte | D07–D13 |
| Interrupção | Impedimentos, divergência, fonte mutável, colisão, acesso insuficiente e falhas | D18 |
| Revogação | Autoridade, registro e efeito sobre novas operações; preservação das peças já existentes | D18/D20 |
| Cadeia privada | Proteção dos registros e responsabilidade por eventos efetivos | D19 |
| Aprovador legítimo | Identidade privada e fundamento de legitimidade | D20 |
| Data/hora da aprovação | Registro real quando houver decisão expressa; hoje não preenchido | D20 |
| Assinatura/aceite rastreável | Registro efetivo da aprovação do escopo, sem preenchimento fictício | D20 |

## Ficha privada de designação — somente campos vazios de decisão

Custodiante real; autoridade legítima; responsabilidades; pessoas autorizadas e
papéis; mínimo de acesso; responsável pelos registros; responsável pela revisão
da retenção; substituto/regra de substituição; aprovador; data/hora real da decisão:
**PENDENTES DE PREENCHIMENTO PRIVADO E APROVAÇÃO**.

Não inserir esses dados na conversa. Nenhuma identidade é herdada de H2, do Portão B,
de conta Windows ou repositório. CUSTODIANTE_DESIGNADO só será alias de função após
existir designação real privada; não constitui a designação por si só.

## Limites que o termo não pode ampliar silenciosamente

Ficam fora do escopo: buscar substitutos, sobrescrever, criar hardlink como cópia,
transferir/publicar XML, parsear, extrair, sanitizar, reconciliar, executar testes,
runner, Categoria B, mudar ACL/owner/usuários/privilégios/políticas ou modificar R1-FIX.
H3-S e H4 exigem autorizações próprias. Campos preenchidos, silêncio ou recebimento
de auditoria não equivalem a aprovação operacional.

A validade da autorização rege quando a operação pode ocorrer. A retenção rege
conservação e revisão das peças; expiração/revogação de uma não autoriza descarte
da outra. Não há assinatura, prazo vigente ou aprovação real neste documento.
O termo permanece MINUTA_NAO_APROVADA até uma decisão explícita e identificável.
