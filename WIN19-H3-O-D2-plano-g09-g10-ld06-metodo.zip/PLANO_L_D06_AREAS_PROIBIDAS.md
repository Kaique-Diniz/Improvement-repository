# H3-O-D2 — instrumento documental L-D06, sem decisão preenchida

27/11/2026. L-D06=PENDENTE. G05=DEPENDENTE_DE_DECISAO já foi aprovado; não reabrir
sua classificação. A proibição de utilizar áreas históricas vedadas não é opcional.

## O que a futura decisão precisa delimitar

Classes/cobertura, referências privadas legítimas, sua proveniência e autoridade,
nível/tipo de evidência, método pertinente, portão de demonstração, validade temporal,
tratamento de lacunas/contradições, privacidade dos caminhos e registro de inconclusão.
A matriz lista explicitamente Git, worktrees, R1-FIX, C5–C8, custódias anteriores,
Portão B e outras áreas legitimamente vedadas. São classes, não diretórios supostos.

## Opções documentais fundamentadas, nenhuma escolhida

- Definir cobertura de referências privadas legítimas e submeter método delimitado
  de confronto a revisão. Só evidência suficiente e vigente pode demonstrar separação
  no escopo; opção não declara referências já existentes nem prova sua materialidade.
- Solicitar complementação privada legítima de fontes/cobertura quando houver lacunas,
  mantendo inconclusão e bloqueio pertinentes. Não executar varredura nem inspecionar
  custódia/área vedada para produzir os dados que faltam.
- Adiar a decisão se escopo/proveniência/método não forem suficientes. Registrar
  dependências sem presumir ausência de sobreposição ou ampliar autorização.

Nenhuma opção dispensa separação. Campos futuros de cobertura, nível de evidência,
portão, validade, referências e decisão permanecem vazios no modelo privado L-D06.
Custodiante e autoridades legítimas definem as escolhas; este plano não as preenche.

## Método conceitual proposto, sem comando ou execução

1. Formalizar privadamente as classes pertinentes, quem pode atestar suas referências
   e o limite do inventário. Identificar versões, data de validade a decidir, lacunas,
   contradições e obrigações, sem expor caminhos no documento compartilhável.
2. Conferir legitimidade/proveniência/cobertura das referências por responsável
   competente. Um hash de conteúdo ou nome de candidata não autentica sua localização.
3. Revisar o método de confronto apenas das referências e do escopo autorizados.
   Comparação nominal pode não bastar frente a alias/identidade física/concorrência;
   se tais garantias forem indispensáveis, exigir revisão de projeto específica.
4. Se faltar evidência pertinente, manter INCONCLUSIVO. Sobreposição demonstrada
   implica impedimento; referência contraditória não se harmoniza silenciosamente.
5. Somente em portão próprio, com método/regras/validade e autorização expressos,
   poderá ser discutida comprovação material. Não usar H3-F-R1 para obter a evidência
   necessária a autorizar sua própria execução. Nenhuma etapa é iniciada agora.
6. Registrar apenas resultado efetivamente obtido em futuro escopo legítimo: cobertura,
   limites, vínculo privado e inconclusão. Não revelar caminho, conta ou inventário.

## V04 e V05 não se substituem

V04 no R1 (B232–251) usa .git e combinação de marcadores nos ancestrais. Nomes
genéricos podem produzir falso positivo conservador; ausência de marcador, metadado
arbitrariamente removido/externo ou aliases podem gerar falso negativo de separação.
Não se executa Git/hooks, não se lê configuração nem se faz varredura. Ausência de
sinais permanece inconclusiva, não prova de separação integral.

V05 (B316–318) apenas registra referências privadas não fornecidas; o método atual
não as recebe ou confronta suficientemente. Deliberação G05 não muda esse código.
Referência legítima é necessária, mas sozinha não prova relação física do objeto
observado. Eventual extensão do método/entrada exige projeto próprio, sem valores
privados inseridos no código atual ou neste plano.

## Momento e validade

Se a separação é necessária para a segurança da própria observação, sua comprovação
pertinente é ANTERIOR a ela. Não adiar condição indispensável para o portão de destino
ou H3-C. Prova material adicional exigida para custódia continua em portões próprios.
A validade temporal e revalidações necessárias são decisões futuras; nenhum prazo
ou política de supervisão é inventado aqui. Condição mutável sem prova vigente
mantém inconclusão/bloqueio. Não criar destino para comprovar separação.
