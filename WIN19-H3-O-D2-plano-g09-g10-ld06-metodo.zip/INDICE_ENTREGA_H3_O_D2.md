# H3-O-D2 — índice, proveniência e inventário

27/11/2026 — America/Sao_Paulo.
Nova pasta externa ao Git: /workspace/work/WIN19-H3-O-D2-PLANO-G09-G10-LD06-METODO-20261127/.
Separada de custódias/fontes; não é destino privado Windows ou registro institucional.
Quatorze arquivos: doze abaixo, este índice e MANIFESTO_SHA256_H3_O_D2.
Manifesto: treze linhas com nome/tamanho/hash, exclui a si próprio; hash próprio
informado na entrega em chat. Sem autorreferência, script, log ou arquivo extra.

## Doze documentos anteriores ao índice

| Documento | Bytes | SHA-256 |
|---|---:|---|
| [DECISAO_DOCUMENTAL_PROPOSTA_H3_O_D2.md](DECISAO_DOCUMENTAL_PROPOSTA_H3_O_D2.md) | 4692 | `674569cb2cc467fa51adc7c55ec49c9001f2a2f75c613704ea9a4c67d45cc065` |
| [ESTADOS_E_CRITERIOS_DE_PARADA.md](ESTADOS_E_CRITERIOS_DE_PARADA.md) | 5570 | `a7914648c7d1854b0631e9dc7817e91312d38339c8c22b2b4d008c90305657a9` |
| [MATRIZ_CONFRONTO_L_D06.csv](MATRIZ_CONFRONTO_L_D06.csv) | 10292 | `0c672b8da37e1ea95dae463f07e2965a1ffa788db6e71e0112fd58f4310e5da5` |
| [MATRIZ_CONTRATO_G10_MC01_MC14.csv](MATRIZ_CONTRATO_G10_MC01_MC14.csv) | 20785 | `7ebc4cf73ca612203bd1065c083e728f31ed57525fa5d6005dd107840fca6017` |
| [MATRIZ_DEPENDENCIAS_N02_N04.csv](MATRIZ_DEPENDENCIAS_N02_N04.csv) | 21147 | `6589fa132f5ff986b1c0a0e8b4b7f94c2f35cd37113525126363deb41dc62bc2` |
| [MATRIZ_PORTOES_E_PRECONDICOES.csv](MATRIZ_PORTOES_E_PRECONDICOES.csv) | 5204 | `4552ea60c533e9c4a0e7b92879b0e59d921239b7507f6227cb2d0ce09c3f2946` |
| [MATRIZ_REQUISITOS_G09.csv](MATRIZ_REQUISITOS_G09.csv) | 10811 | `0cd381f4e57e579a95190a8b237d2003d46fa74cd307aee08e14b763ffe0c623` |
| [MATRIZ_RISCOS_E_TRATAMENTOS.csv](MATRIZ_RISCOS_E_TRATAMENTOS.csv) | 21722 | `ff1354ff0cf750c53f9511bba7bd22e8cf48978154871ee4bcf7f135ca663804` |
| [MODELOS_DECISOES_PRIVADAS_NAO_PREENCHIDOS.md](MODELOS_DECISOES_PRIVADAS_NAO_PREENCHIDOS.md) | 11819 | `4c8607574367a78f9b467e924d0f117f6edbcb85092a79ef28f07cd3ea309c1d` |
| [PLANO_L_D06_AREAS_PROIBIDAS.md](PLANO_L_D06_AREAS_PROIBIDAS.md) | 4493 | `725f9cf38df36628dddc272d9cae0bd03a2be6ff79f3900bc247f80b33a91d32` |
| [RELATORIO_H3_O_D2.md](RELATORIO_H3_O_D2.md) | 6459 | `97d3f05ff0948ec22ed5befae521f735f43e7ad7af89c834a52651e7faea238a` |
| [REVISAO_PROJETO_H3_F_R1.md](REVISAO_PROJETO_H3_F_R1.md) | 5170 | `850503e82e8c309655dd0ce51d4d1fbe9eb2b8ba1b3da8bd4187cad01232f00f` |

Seis CSVs: G09 12 requisitos; G10 14 M-C; L-D06 7 classes; riscos 9; runtime 15;
portões 12 requisitos em quatro momentos conceituais. UTF-8 sem BOM/LF, delimitador
ponto e vírgula e quoting pertinente, cabeçalhos/colunas/IDs conferidos como dados.
Originais contratuais, riscos e runtime preservados literalmente como colunas
históricas; planos novos não são comprovações, escolhas ou execuções.

## Entradas diretas autenticadas

| Fonte | Bytes | SHA-256 recalculado |
|---|---:|---|
| Texto colado.txt | 23848 | `ed3b64c4344b966e1a65076c98588a997c80c669f466533be6a78deabbdd7f59` |
| PARECER_INDEPENDENTE_WIN19_H3_O_D1_2026-11-27.md | 13075 | `d9f3feec5e29f0c11849e0706f01b8a6d00a2114bb2e8d5fccb831c3fa41767d` |

Instrução autoriza somente análise/plano documental. Parecer D1 corresponde ao
hash exigido, aceita a consolidação com ressalvas e relata novo confronto no
ambiente do auditor. Os arquivos de entrada não são copiados como anexos extras.
Hash local de Texto colado.txt não é atestado independente de mensagem primária,
assinatura institucional ou conteúdo que não integrou o pacote anterior.

## Raízes dos manifestos conferidas

| Fonte / manifesto | Bytes | SHA-256 | Arquivos cobertos |
|---|---:|---|---:|
| H3-O-D1 / MANIFESTO_SHA256_H3_O_D1 | 1181 | `e7afd1fca563813334c2b365819535d7058d9cde8ac305db734649104980704a` | 11 |
| H3-O / MANIFESTO_SHA256_H3_O | 934 | `e4a1aa2b7062825616a4ef724251e854ab4bb8ed1801d8310a2fb185265ec7a6` | 9 |
| H3-N / MANIFESTO_SHA256_H3_N | 818 | `b0b293a4dd75f3639406a1987668b1217c98b25e0930fcf9cf3b385dc7d6f7c6` | 8 |
| H3-M / MANIFESTO_SHA256_H3_M | 1130 | `0d190653da615d68939568b1751bcbd052cc6fd77fd7cf17c7015ec72bca37f3` | 11 |
| H3-L / MANIFESTO_SHA256_H3_L | 994 | `47a7a71a1f442eeb0f8e61031e37620963b782d488728af476aacea6b757e76d` | 10 |
| H3-K / MANIFESTO_SHA256_H3_K | 923 | `3e1b2f74d2de06fbcdfe9c46a0a3b3ce98df796a7febeff6b60dcfb06ab11f86` | 9 |
| H3-E / MANIFESTO_SHA256_H3_E | 722 | `71fba7f8808106efb50215a8287a4b24e38de9c75fb31c4afab63c5094d866d1` | 7 |
| H3-G / MANIFESTO_SHA256_H3_G | 898 | `baa58c4986e16b57ab9d83197b856033ab9ce7598e8003351f93dea964ad9598` | 9 |
| H3-F-R1 / MANIFESTO_SHA256_H3_F_R1 | 633 | `5b517e9b7572c5505b6bd35ecefb19ad127e0d4e7842bc0447f61b15b311f99d` | 6 |
| H3-I / MANIFESTO_SHA256_H3_I | 812 | `9cba6b86efebe8cec0774fe61083a1ae61bbdf766d91c732452013451f7e2d8d` | 8 |
| H3-J / MANIFESTO_SHA256_H3_J | 718 | `7dca06a6632ad00b9f14697720aefbe2bc789e9bf1b320bdab9e9dcd04aaa6dd` | 7 |

Raízes correspondem aos hashes obrigatórios/previamente autenticados e índices
históricos. Todos os arquivos cobertos foram conferidos em tamanho/hash antes
do uso. Nenhuma fonte essencial ao plano permaneceu ausente ou divergente.
Autenticação identifica cópias documentais, não materialidade Windows ou assinatura.

## Referências específicas usadas

| Documento | Bytes | SHA-256 |
|---|---:|---|
| H3-O-D1 / RELATORIO_H3_O_D1.md | 5495 | `64f25e22f6a08b7f6450875f4dace00f019b4c80242bb29f1fe5a864d396734c` |
| H3-O-D1 / MATRIZ_CONSOLIDADA_L_D02_G01_G11.csv | 11540 | `4312a3c9ef938964d909584e03da724f67ebb2f37ab7d1dc56a018672faa4f50` |
| H3-O-D1 / MATRIZ_CLASSIFICACAO_EVIDENCIA_AUTORIZACAO.csv | 4967 | `866ca95ea08c88c4b045c7b246f67a4492e459ffb81968cc8f68b8fcf59ccbf8` |
| H3-O-D1 / PENDENCIAS_G05_L_D06_E_GARANTIAS.md | 3420 | `5f975eec0d814a0a4effc1729c6af5f4417e2094c8dc07304ed6c2227c2fa793` |
| H3-O-D1 / DEPENDENCIAS_G09_G10_E_METODO.md | 6323 | `27bdf8c453b2628210fc16fda677fa9fb27bdcfe965180205fa192900f1e0329` |
| H3-O-D1 / ESTADOS_BLOQUEIOS_E_PROXIMOS_PORTOES.md | 5835 | `aba84661851b1d36e79e5d629e3f802270e75d1620c60df858b4812270c284bf` |
| H3-L / AVALIACAO_METODO_H3_F_R1.md | 7603 | `f6ad04099cb875ec70f575827cdbb4051c27051a7c8f0f657c281ee5c166209b` |
| H3-L / CONTRATO_EXTERNO_RESULTADOS.md | 9946 | `fa61ffd2f3b71168b9af5b5764835ea3fe1882c63d2074e0710665ad2be7bf9b` |
| H3-L / MATRIZ_RUNTIME_N02_N04.csv | 6919 | `21548eace5babad14d47f1fd6d146cd775dd400d7ae6e0994842fe348eb4b9f9` |
| H3-L / REVISAO_R03_R07.md | 4718 | `2f4d3a8293b4214d9562c9366f01ac6237415ba21292e17548c1e9bf88a7d7f3` |
| H3-L / MATRIZ_DECISOES_CUSTODIANTE.csv | 6836 | `b38bb7fd25c78e50591fbb2605b163c5df7545ef585a9e122b9b281a4ebad67e` |
| H3-K / MATRIZ_RISCOS_R01_R09.csv | 15069 | `5a5064fbd20ab09b46c547491b82e8141ab896daad08ae57d0ad2b5c029fc780` |
| H3-K / MATRIZ_COBERTURA_V01_V10.csv | 11100 | `b4e23548af2cf0fe31eae735422fe8d3a9846138fbda1cb574055b7d1f269d49` |
| H3-K / CHECKLIST_PRECONDICOES_INSPECAO.md | 8027 | `9aa2bb55d54033e3a0fcf579843620f843b9d5ed02ffbee087df085307bce756` |
| H3-K / ANALISE_IMPEDIMENTOS_E_INCONCLUSOES.md | 5797 | `f4c6b836866a09ce252e635d36e941d42c7d8c639fe0dbb48ae9e881f0f915a9` |
| H3-F-R1 / COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md | 22438 | `d927512fb7a00ed5614d8920717670b0675865518a865f8fdbed569f685a9145` |
| H3-F-R1 / RISCOS_PENDENTES_E_PORTOES.md | 12028 | `74bc0dd84073b06ebbce245600e47a342f2ce0c7925518fd19436f82a2482d8a` |
| H3-F-R1 / DIFF_H3_F_H3_F_R1.patch | 3209 | `1cd6735875e46a11ad5cbcd291e6a5e0030e321a48472c27a01a048c4cbad07a` |
| H3-M / MATRIZ_ADOCAO_CONTRATO_EXTERNO.csv | 7309 | `fdb0d87b03bbdff01bb82f2634377ba390bce608de29e2a0e3b85fe701635f2d` |
| H3-M / MATRIZ_DECISOES_L_D01_L_D12.csv | 14001 | `e4d4f3995696207a7b0b09452875391413197ca8d4e08edd3888ea51d6f32a06` |
| H3-E / POLITICA_CUSTODIA_LOCAL.md | 3466 | `b3991e85e4f7eb49b88cd86f40103a8ac3f28b97ef51326b46bbcf5924138107` |
| H3-E / PENDENCIAS_PARA_H3_C.md | 3512 | `66c707b5680a8c2b637bf00ef583357f8b200a2a88169cbc8e1fa38d4e412d66` |
| H3-I / DECISOES_PENDENTES_H3_I.md | 4011 | `2d854f54a2b725b1fad3daee3355f80d79a8b2148c12f04a56d09553ccc9316d` |
| H3-J / DECISAO_DOCUMENTAL_H3_J.md | 3182 | `84cb799ed03d98287c7b8e45a0e2bd82d02e4b6d9419b3870a0d676af826b716` |

Bloco R1 lido só como bytes/texto: 20.362 bytes, 383 LF, UTF-8 sem BOM, SHA-256
`af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5`.
Extração exclui cercas/marcadores, inclui LF final; não invoca parser, função ou
chamada final B383. Nenhuma aplicação/inversão de patch, teste ou mock foi realizada.

## Confronto posterior das quatro manifestações — adendo de contexto

A D1 original registrou que o executor não dispunha das quatro fontes. O parecer
D1 agora recebido/autenticado informa leitura e recálculo direto pelo auditor,
sem divergência impeditiva. Metadados relatados naquele parecer:

| Manifestação | Bytes informados pelo auditor | SHA-256 informado como recalculado pelo auditor |
|---|---:|---|
| 1 — G09/G10 | 3969 | `8033dafa90bf39997a19829a9a31e15ea1ab15e68e22e55b3f53f9d9ce62ef49` |
| 2 — G01–G04 | 7314 | `a974e82f8305461aeeca5f1701b3240b58bd12c5d48ad935756c5b3df90de109` |
| 3 — G06/G07 | 7962 | `d45f4d07d0cd2f0059c1e6fb4826738965b1bb89fdcd5a578cec793193437924` |
| 4 — G05 | 8565 | `9445240274f6118e2b494ffbcc07b762d73dff08c58e1445a0d1afb94f8d0be4` |

Esses quatro recálculos NÃO foram feitos pelo executor nesta D2; não se afirma
recebimento/cópia dos quatro arquivos nem se reconstrói seu corpo. O confronto
foi concluído no contexto da auditoria segundo fonte autenticada, sem reescrever
os doze arquivos D1 ou converter hash em prova de autoria/assinatura/horário nativo.
Isso resolve a lacuna naquele contexto e preserva as ressalvas de proveniência
primária e formalização privada. As onze classificações não são reabertas.

## Preservação, privacidade e parada

Comparados 109 arquivos de fontes/manifestos/entradas/pacote, byte a
byte antes/depois; todos idênticos. Alcance documental localizado, não prova forense
global. ZIP D1 preservado: 27.566 bytes, SHA-256
8ffd8aa1378c1ae777116e2bc0a0dccefb36ee2d8bdd2fae953fc8171882eb98.
Nenhum histórico, manifesto, código, termo ou pacote anterior foi atualizado.

Preservados 11 enquadramentos aprovados, 12 decisões históricas sem novas decisões
materiais, 14 questões sem adoção/implementação, 15 runtime não verificados, 9 riscos
abertos, V01–V10 não executados e 30 itens 8/10/11/1. N01 só sintaxe R1 conforme
relato; modelos de nove decisões privados permanecem vazios, sem valores publicados.

Python -I -B/biblioteca padrão apenas para documentos, CSV, hashes/comparação e
escrita dos treze documentos mais manifesto. Sem PowerShell, novo parsing nativo/
runtime, APIs/WMI/testes/ACL/DACL, diretório privado/JUnit/XML, custódia/destino,
código/patch/script/runner, conta/permissão/privilégio/política, instalação/remoto,
Git, commit/push/merge, ZIP ou publicação. Só a pasta documental D2 foi criada.

Textos novos não contêm caminho privado completo, conta/SID, identificador pessoal
ou de máquina, credencial, cliente/JUnit, coadministrador nominal, ACL individual
ou inventário sensível. Pastas do executor no índice não são destinos do usuário.
Governança H3-I/H3-J, proveniência primária e vínculos PROVISORIO_SEM_FONTE preservados.
Parar para auditoria; nenhum encaminhamento A/B/C libera execução/inspeção/custódia.
