# H3-O-D2 — modelos privados NÃO PREENCHIDOS

27/11/2026 é data dos modelos, não de decisões/assinaturas operacionais.
Os nove modelos indicam campos necessários, sem dados reais e sem solicitar envio
de seus valores ao Codex. Identidade/conta/SID/host/caminho/inventário/ACL/pessoa
não são preenchidos. Nunca inserir credencial bruta no registro, nem no público.
Nenhuma política existente se torna indecidida por haver modelo de implementação.
L-D01 e L-D02 já foram declaradas/deliberadas; não são reabertas. L-D05 permanece
preservada: coadministradores só mediante autorização específica, sem novo modelo
ou participação presumida nesta tarefa.

## L-D03 — Legitimidade do ambiente

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: A02,A05,A06,A07,A08; A02=PENDENTE_DE_EVIDENCIA; A05=PENDENTE_DE_EVIDENCIA; A06=PENDENTE_DE_EVIDENCIA; A07=PENDENTE_DE_EVIDENCIA; A08=NAO_APLICAVEL_COM_JUSTIFICATIVA.
Matéria a formalizar em ambiente privado: Formalizar ambiente local legítimo, host e versão, ausência de elevação/remoto, dependências e proveniência de evidência
Papel responsável, sem identificação nominal: Responsável legítimo pelo ambiente e custodiante.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D04 — Identidade/responsabilidades e política de retenção

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: C01,C02,C05,R01,R02,R03,R04; C01=DOCUMENTADA; C02=PENDENTE_DE_EVIDENCIA; C05=PENDENTE_DE_DECISAO; R01=DOCUMENTADA; R02=DOCUMENTADA; R03=DOCUMENTADA; R04=PENDENTE_DE_DECISAO.
Matéria a formalizar em ambiente privado: Formalizar nominalmente legitimidade/deveres/substituição e responsáveis por registros e revisões; preservar política já documentada, sem redecidi-la silenciosamente
Papel responsável, sem identificação nominal: Custodiante e autoridade legítima aplicável.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D06 — Áreas proibidas

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: D04; D04=PENDENTE_DE_EVIDENCIA.
Matéria a formalizar em ambiente privado: Estabelecer inventário privado legítimo, cobertura e método de confronto sem varredura ou nomes por semelhança
Papel responsável, sem identificação nominal: Custodiante com responsável legítimo pelas referências.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D07 — Destino proposto

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: D01,D02,D03,O05; D01=DOCUMENTADA; D02=PENDENTE_DE_DECISAO; D03=PENDENTE_DE_EVIDENCIA; O05=PENDENTE_DE_DECISAO.
Matéria a formalizar em ambiente privado: Propor privadamente diretório novo/exclusivo/local e evidência de volume; aprovação de destino é decisão distinta e posterior
Papel responsável, sem identificação nominal: Custodiante.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D08 — Exposição/confidencialidade

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: D05,O03; D05=PENDENTE_DE_EVIDENCIA; O03=PENDENTE_DE_EVIDENCIA.
Matéria a formalizar em ambiente privado: Definir política de compartilhamento/sincronização, destinatários e sigilo, preservando administrativos e tratamento de captura
Papel responsável, sem identificação nominal: Custodiante e responsável legítimo pelo ambiente.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D09 — Obrigações institucionais

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: C04; C04=PENDENTE_DE_DECISAO.
Matéria a formalizar em ambiente privado: Avaliar deveres legítimos de preservação, confidencialidade e compatibilidade da política; não presumir inexistência
Papel responsável, sem identificação nominal: Autoridade legítima aplicável e custodiante.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D10 — Falhas e evidências

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: A03,A04,O02; A03=DOCUMENTADA; A04=DOCUMENTADA; O02=PENDENTE_DE_DECISAO.
Matéria a formalizar em ambiente privado: Adotar/revisar contrato externo de identidade, recepção, duração, interrupção e recursos incertos; conferir futuramente cópia usada, sem confundir sintaxe com runtime
Papel responsável, sem identificação nominal: Custodiante e responsável técnico.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D11 — Validade da autorização

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: O04,O06; O04=PENDENTE_DE_DECISAO; O06=PENDENTE_DE_DECISAO.
Matéria a formalizar em ambiente privado: Definir referência legítima, operador, escopo, início/fim/expiração e eventos que invalidam; prazo de retenção não é validade
Papel responsável, sem identificação nominal: Custodiante/autoridade competente.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |

## L-D12 — Separação de portões

Estado do modelo: NAO_PREENCHIDO. Não é decisão/autorização real.
Base histórica: O04,O05,O06; O04=PENDENTE_DE_DECISAO; O05=PENDENTE_DE_DECISAO; O06=PENDENTE_DE_DECISAO.
Matéria a formalizar em ambiente privado: Formalizar que observação, aprovação de destino e termo H3-C são decisões distintas, com métodos, evidências e validade próprios
Papel responsável, sem identificação nominal: Custodiante e responsáveis legítimos de cada decisão.

| Campo futuro privado | Valor |
|---|---|
| Referência legítima da decisão e versão | |
| Identidade/competência do responsável, somente privadamente | |
| Objeto/finalidade e limites | |
| Alternativas e motivação | |
| Evidências legítimas e proveniência | |
| Cobertura/referências privadas pertinentes, sem publicar valores | |
| Nível de evidência/portão, quando aplicável | |
| Decisão efetiva, se emitida futuramente | |
| Responsabilidades/validade/condições de interrupção | |
| Limitações e pendências remanescentes | |
| Manifestação legítima/data/fuso efetivos, sem inventar assinatura | |
| Referência de formalização privada e acesso legítimo | |


## Limites comuns

Modelos não comprovam legitimidade, direitos, privacidade ou preenchimento de
L-D03–L-D12. Não concedem coleta/ensaio, Git, Windows, inspeção, alteração de segurança,
remoto, custódia ou implementação para obter evidências faltantes. Um identificador
local de registro futuro não se apresenta como ID nativo ou assinatura inexistente.
Manter REGISTRO_PRIVADO_LEGITIMO_PENDENTE até formalização própria, quando exigida.
