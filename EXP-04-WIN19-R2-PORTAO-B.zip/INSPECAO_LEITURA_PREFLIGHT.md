# Inspeção estática da sonda — sem execução

A análise abaixo descreve as operações solicitadas pelo código, não evidência
nativa Windows. Python foi apenas analisado por AST/compilado em memória.
PowerShell foi revisado por leitura; nenhuma execução ou validação nativa5.1.

| Componente | Consultas/limites | Mutações solicitadas |
|---|---|---|
| regular_path / hashes | lstat, listagem e read_bytes; compara 470 hashes/extras e rejeita symlink/reparse | Nenhuma escrita, mkdir, unlink, replace, temporário ou JUnit |
| fora_git_preparacao | lexists .git, marcadores HEAD/objects/refs, ancestrais e sobreposição | Não inicializa/repara Git nem cria área |
| Git | rev-parse HEAD, status --porcelain com --no-optional-locks, timeout20s, stdout/stderr em memória | Sem add/checkout/reset/clean; fsmonitor e untrackedCache desativados só na chamada; nenhuma configuração persistente |
| SHGetKnownFolderPath | GUID LocalAppData, flags0, consulta caminho existente; CoTaskMemFree libera memória | Sem KF_FLAG_CREATE; não cria LocalAppData ou área WIN19 |
| OpenProcessToken | somente TOKEN_QUERY=0x8; GetTokenInformation classes20/3 | Não AdjustTokenPrivileges, LogonUser, impersonação ou criação de conta |
| LookupPrivilegeValueW | consulta LUID de SeCreateSymbolicLinkPrivilege e compara atributos em memória | Não habilita privilégio; consulta não prova criação de symlink |
| GetVolumePathNameW / GetVolumeInformationW | ponto de montagem real, tipo/capacidades; serial não é emitido | Sem formatar, alterar8.3, ACL ou volume |
| GetShortPathNameW | arquivo já existente tools/exp04_win/casos_historicos.json; buffer limitado; erro imediato | Não cria alias/arquivo; alias ausente não é PASS; erro de API bloqueia |
| winreg | OpenKey KEY_READ e QueryValueEx de Developer Mode | Não SetValue/DeleteKey; chave ausente=False; erro inesperado bloqueia |
| PowerShell da sonda | -I -S -B -X utf8; env somente do processo com restauração finally | Não instala dependências, não muda ExecutionPolicy/registro/permissões |
| Comando futuro | Get-Item/Get-FileHash, captura textual e SHA em memória | Não salva arquivos nem cria área; flag não equivale a autorização |

APIs de erro capturam GetLastError imediatamente após a consulta que falhou.
SHGetKnownFolderPath usa HRESULT retornado; consulta de tamanho do token espera
ERROR_INSUFFICIENT_BUFFER(122). Erros não são imprimidos com str(OSError), evitando
caminhos/SIDs/SDDL. CloseHandle é verificado; nenhuma negação por DACL é exercitada.
A sonda não chama CreateFileW/SetFileInformationByHandle ou o helper de remoção.

Somente leitura significa ausência de mutações solicitadas pelo programa; não
constitui prova forense de ausência de cache/atime mantidos pelo sistema operacional.
As verificações de caminho não fixam todos os objetos por handles durante leitura;
não são prova de resistência a substituição concorrente nem homologação de DACL.
Qualquer alteração/instabilidade de integridade impede aceite do inventário.

A preparação externa acrescenta campos de HEAD, flags de runtime, área e hashes
antes/depois para tornar os critérios observáveis. A conferência final ocorre em
finally após integridade inicial válida; se falhar, o resultado público é BLOQUEADO
com INTEGRIDADE_FINAL_NAO_COMPROVADA, preservando eventual código anterior seguro.
Capacidades ausentes permanecem impedimentos; saída0 nunca autoriza C/D/E.
