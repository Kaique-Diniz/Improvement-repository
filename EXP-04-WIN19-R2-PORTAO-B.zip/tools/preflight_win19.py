"""Somente leitura: não cria área, link, alias, conta ou ACL; não executa testes.

Saída só agregada: sem caminhos, nomes de conta, SIDs, SDDL ou hostname.
Capacidade observada não significa autorização ou controle aprovado.
"""
import argparse
import ctypes
from ctypes import wintypes
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import uuid

BASE='770d062d29c4361d6932592883df9339bb4089bc'
MANIFEST='a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c'


def impedimentos(report):
    """Inventário nunca concede autorização ou aprova controle de segurança."""
    items = ['ROTEIRO_R2_AGUARDA_REVISAO', 'TESTES_SEM_AUTORIZACAO_FUTURA',
             'JUNIT_EXP04_ORIGINAL_NAO_CUSTODIADO', 'VINCULOS_19_PROVISORIOS',
             'POLITICA_DACL_PARA_APROVACAO', 'TOKENS_DISTINTOS_NAO_VERIFICADOS',
             'DACL_EFETIVA_NAO_VALIDADA', 'CONVERSOES_REAIS_BLOQUEADAS']
    if report.get('sistema_arquivos') != 'NTFS':
        items.append('NTFS_NAO_CONFIRMADO_NA_AREA_PREVISTA')
    if not report.get('persistent_acls_suportadas'):
        items.append('SUPORTE_ACL_PERSISTENTE_NAO_CONFIRMADO')
    if not report.get('symlink_privilegio_habilitado'):
        items.append('SYMLINK_PRIVILEGIO_NAO_HABILITADO; CAPACIDADE_REAL_NAO_TESTADA')
    if report.get('developer_mode_somente_leitura'):
        items.append('DEVELOPER_MODE_OBSERVADO_NAO_COMPROVA_CRIACAO_SYMLINK')
    if not report.get('alias_existente_observado'):
        items.append('ALIAS_8_3_REAL_NAO_OBSERVADO')
    if report.get('codigo'):
        items.append(report['codigo'])
    return items


class Bloqueio(Exception):pass


def regular_path(p, directory=False):
    p=Path(p)
    if not p.is_absolute() or '..' in p.parts:raise Bloqueio('CAMINHO_INVALIDO')
    for n in (*reversed(p.parents),p):
        s=n.lstat()
        if stat.S_ISLNK(s.st_mode) or getattr(s,'st_file_attributes',0)&0x400:
            raise Bloqueio('LINK_REPARSE_RECUSADO')
        if n!=p and not stat.S_ISDIR(s.st_mode):raise Bloqueio('ANCESTRAL_INVALIDO')
    if not (stat.S_ISDIR(s.st_mode) if directory else stat.S_ISREG(s.st_mode)):
        raise Bloqueio('TIPO_INVALIDO')
    return p


def hashes(root):
    root=regular_path(root,True);found={};stack=[root]
    while stack:
        folder=stack.pop()
        for p in folder.iterdir():
            if p.parent==root and p.name=='.git':
                s=p.lstat()
                if stat.S_ISLNK(s.st_mode) or getattr(s,'st_file_attributes',0)&0x400:
                    raise Bloqueio('METADADO_GIT_INVALIDO')
                continue
            s=p.lstat()
            if stat.S_ISLNK(s.st_mode) or getattr(s,'st_file_attributes',0)&0x400:
                raise Bloqueio('CONTEUDO_CONTEM_LINK_REPARSE')
            if stat.S_ISDIR(s.st_mode):stack.append(p)
            elif stat.S_ISREG(s.st_mode):found[p.relative_to(root).as_posix()]=sha256(p.read_bytes()).hexdigest()
            else:raise Bloqueio('TIPO_EXTRA_INVALIDO')
    return found


def pasta_local_registrada():
    class GUID(ctypes.Structure):
        _fields_=[('a',ctypes.c_uint32),('b',ctypes.c_uint16),('c',ctypes.c_uint16),('d',ctypes.c_ubyte*8)]
    shell=ctypes.WinDLL('shell32',use_last_error=True);ole=ctypes.WinDLL('ole32',use_last_error=True)
    shell.SHGetKnownFolderPath.argtypes=[ctypes.POINTER(GUID),wintypes.DWORD,wintypes.HANDLE,ctypes.POINTER(ctypes.c_void_p)]
    shell.SHGetKnownFolderPath.restype=ctypes.c_long
    ole.CoTaskMemFree.argtypes=[ctypes.c_void_p];ole.CoTaskMemFree.restype=None
    key=GUID.from_buffer_copy(uuid.UUID('f1b32785-6fba-4fcf-9d55-7b8e7f157091').bytes_le)
    ptr=ctypes.c_void_p()
    try:
        result=shell.SHGetKnownFolderPath(ctypes.byref(key),0,None,ctypes.byref(ptr))
        if result!=0 or not ptr.value:raise Bloqueio('PASTA_REGISTRADA_INDISPONIVEL')
        return regular_path(Path(ctypes.wstring_at(ptr)),True)
    finally:
        if ptr.value:ole.CoTaskMemFree(ptr)


def contexto_token():
    k=ctypes.WinDLL('kernel32',use_last_error=True);a=ctypes.WinDLL('advapi32',use_last_error=True)
    k.GetCurrentProcess.restype=wintypes.HANDLE
    k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
    a.OpenProcessToken.argtypes=[wintypes.HANDLE,wintypes.DWORD,ctypes.POINTER(wintypes.HANDLE)];a.OpenProcessToken.restype=wintypes.BOOL
    a.GetTokenInformation.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD)]
    a.GetTokenInformation.restype=wintypes.BOOL
    token=wintypes.HANDLE()
    if not a.OpenProcessToken(k.GetCurrentProcess(),0x8,ctypes.byref(token)):
        error=ctypes.get_last_error();raise Bloqueio('TOKEN_QUERY_FALHOU_'+str(error))
    try:
        elevated=wintypes.DWORD();size=wintypes.DWORD()
        if not a.GetTokenInformation(token,20,ctypes.byref(elevated),ctypes.sizeof(elevated),ctypes.byref(size)):
            error=ctypes.get_last_error();raise Bloqueio('TOKEN_ELEVATION_QUERY_FALHOU_'+str(error))
        # TOKEN_QUERY apenas; nenhuma chamada AdjustTokenPrivileges.
        a.GetTokenInformation(token,3,None,0,ctypes.byref(size))
        error=ctypes.get_last_error()
        if error!=122 or not 4<=size.value<=65536:raise Bloqueio('TOKEN_PRIVILEGES_TAMANHO_INVALIDO')
        raw=ctypes.create_string_buffer(size.value)
        if not a.GetTokenInformation(token,3,raw,size.value,ctypes.byref(size)):
            error=ctypes.get_last_error();raise Bloqueio('TOKEN_PRIVILEGES_QUERY_FALHOU_'+str(error))
        class LUID(ctypes.Structure):_fields_=[('low',ctypes.c_uint32),('high',ctypes.c_int32)]
        class Entry(ctypes.Structure):_fields_=[('luid',LUID),('attributes',ctypes.c_uint32)]
        luid=LUID();a.LookupPrivilegeValueW.argtypes=[wintypes.LPCWSTR,wintypes.LPCWSTR,ctypes.POINTER(LUID)]
        a.LookupPrivilegeValueW.restype=wintypes.BOOL
        if not a.LookupPrivilegeValueW(None,'SeCreateSymbolicLinkPrivilege',ctypes.byref(luid)):
            error=ctypes.get_last_error();raise Bloqueio('LOOKUP_PRIVILEGE_FALHOU_'+str(error))
        count=ctypes.c_uint32.from_buffer(raw).value
        if 4+count*ctypes.sizeof(Entry)>size.value:raise Bloqueio('TOKEN_PRIVILEGES_INVALIDO')
        present=enabled=False
        for i in range(count):
            item=Entry.from_buffer(raw,4+i*ctypes.sizeof(Entry))
            if (item.luid.low,item.luid.high)==(luid.low,luid.high):
                present=True;enabled=bool(item.attributes&2)
        return dict(token_elevado=bool(elevated.value),symlink_privilegio_presente=present,
                    symlink_privilegio_habilitado=enabled,symlink_criacao_testada=False)
    finally:
        if not k.CloseHandle(token):
            error=ctypes.get_last_error();raise Bloqueio('TOKEN_CLOSE_FALHOU_'+str(error))


def volume_info(root):
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    # O ponto de montagem pode não ser a raiz da letra de unidade.
    pathfn=k.GetVolumePathNameW
    pathfn.argtypes=[wintypes.LPCWSTR,wintypes.LPWSTR,wintypes.DWORD]
    pathfn.restype=wintypes.BOOL
    mount=ctypes.create_unicode_buffer(32768)
    if not pathfn(str(root),mount,len(mount)):
        error=ctypes.get_last_error();raise Bloqueio('VOLUME_PATH_QUERY_FALHOU_'+str(error))
    fn=k.GetVolumeInformationW
    fn.argtypes=[wintypes.LPCWSTR,wintypes.LPWSTR,wintypes.DWORD,ctypes.POINTER(wintypes.DWORD),ctypes.POINTER(wintypes.DWORD),ctypes.POINTER(wintypes.DWORD),wintypes.LPWSTR,wintypes.DWORD]
    fn.restype=wintypes.BOOL
    flags=wintypes.DWORD();serial=wintypes.DWORD();maxlen=wintypes.DWORD();fs=ctypes.create_unicode_buffer(64)
    if not fn(mount.value,None,0,ctypes.byref(serial),ctypes.byref(maxlen),ctypes.byref(flags),fs,len(fs)):
        error=ctypes.get_last_error();raise Bloqueio('VOLUME_QUERY_FALHOU_'+str(error))
    return dict(sistema_arquivos=fs.value,persistent_acls_suportadas=bool(flags.value&8),
                reparse_suportado=bool(flags.value&0x80),hardlinks_suportados=bool(flags.value&0x400000))


def tem_metadados_git(folder):
    return (os.path.lexists(folder/'.git') or
        (os.path.lexists(folder/'objects') and any(os.path.lexists(folder/n) for n in ('refs','HEAD','config'))))


def fora_git_preparacao(folder):
    regular_path(folder,True)
    for p in (folder,*folder.parents):
        # Até .git danificado ou link quebrado impede considerar a área externa.
        if tem_metadados_git(p):
            raise Bloqueio('PREPARACAO_DENTRO_OU_COM_METADADOS_GIT')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidata',type=Path,required=True);p.add_argument('--manifesto',type=Path,required=True)
    p.add_argument('--area-prevista',type=Path,required=True);a=p.parse_args()
    report=dict(etapa='PREFLIGHT_SOMENTE_LEITURA',testes_executados=0,area_criada=False,
        ACL_alterada=False,prontidao_para_executar=False,DACL_efetiva='NÃO_VALIDADO',
        politica_DACL='PARA_APROVACAO',autorizacao_testes='PENDENTE',conta_identificada_no_relatorio=False,
        significado_saida_0='SOMENTE_COLETA_CONCLUIDA_MESMO_COM_IMPEDIMENTOS',
        portao_C='BLOQUEADO',portao_D='BLOQUEADO',portao_E='BLOQUEADO',
        versao_preparacao='WIN19-R2-PORTAO-B',baseline_esperado=BASE,
        hashes_antes_conferidos=0,hashes_depois_conferidos=0,
        integridade_antes=False,integridade_depois=False)
    root=None;expected=None;before_valid=False
    try:
        if sys.version_info[:2]!=(3,12):raise Bloqueio('PYTHON_312_OBRIGATORIO')
        if not sys.flags.utf8_mode:raise Bloqueio('UTF8_OBRIGATORIO_NO_PROCESSO')
        if not sys.dont_write_bytecode:raise Bloqueio('BYTECODE_DEVE_ESTAR_DESABILITADO')
        if not sys.flags.isolated or not sys.flags.no_site:raise Bloqueio('PYTHON_ISOLADO_SEM_SITE_OBRIGATORIO')
        script=regular_path(Path(__file__).absolute())
        fora_git_preparacao(script.parent)
        mf=regular_path(a.manifesto);data=mf.read_bytes()
        fora_git_preparacao(mf.parent)
        if sha256(data).hexdigest()!=MANIFEST:raise Bloqueio('MANIFESTO_REFERENCIA_DIVERGENTE')
        v=json.loads(data);root=regular_path(a.candidata,True)
        if script.is_relative_to(root) or mf.is_relative_to(root):raise Bloqueio('PREPARACAO_SOBREPOE_CANDIDATA')
        if v['baseline']!=BASE or len(v['arquivos'])!=470:raise Bloqueio('REFERENCIA_INVALIDA')
        for name in v['arquivos']:
            pp=PurePosixPath(name)
            if pp.is_absolute() or '..'in pp.parts:raise Bloqueio('MANIFESTO_CAMINHO_INVALIDO')
        expected=v['arquivos']
        if hashes(root)!=expected:raise Bloqueio('HASHES_OU_EXTRAS_DIVERGENTES')
        before_valid=True
        report.update(hashes_antes_conferidos=470,integridade_antes=True,
            preflight_python_sha256=sha256(script.read_bytes()).hexdigest(),
            preparacao_externa_ao_git=True,utf8_ativo=True,bytecode_desabilitado=True,
            python_isolado=True,site_desabilitado=True)
        if any(os.environ.get(k) for k in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_COMMON_DIR',
                                          'GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES')):
            raise Bloqueio('GIT_AMBIENTE_REDIRECIONADO')
        git_command=['git','--no-optional-locks','-c','core.fsmonitor=false','-c','core.untrackedCache=false','-C',str(root)]
        git=subprocess.run(git_command+['rev-parse','HEAD'],capture_output=True,timeout=20)
        if git.returncode or git.stdout.decode('ascii').strip()!=BASE:raise Bloqueio('HEAD_DIVERGENTE')
        report.update(git_head=BASE,head_confere=True)
        top=subprocess.run(git_command+['rev-parse','--show-toplevel'],capture_output=True,timeout=20)
        if top.returncode or Path(top.stdout.decode('utf-8').strip())!=root:raise Bloqueio('RAIZ_GIT_DIFERENTE_DA_CANDIDATA')
        report['git_raiz_confere']=True
        state=subprocess.run(git_command+['status','--porcelain=v1','--untracked-files=all'],capture_output=True,timeout=20)
        if state.returncode:raise Bloqueio('STATUS_GIT_INDISPONIVEL')
        report.update(status_git_sha256=sha256(state.stdout).hexdigest(),status_git_registros=len(state.stdout.splitlines()))
        report.update(hashes_conferidos=470,manifesto_sha256=MANIFEST,python=sys.version.split()[0],sistema=sys.platform)
        if os.name!='nt':raise Bloqueio('WINDOWS_NATIVO_INDISPONIVEL')
        win=sys.getwindowsversion()
        report['windows_build']=dict(major=win.major,minor=win.minor,build=win.build)
        local=pasta_local_registrada();area=a.area_prevista
        if not area.is_absolute() or '..' in area.parts or area.parent!=local or not area.name.startswith('WIN19-'):
            raise Bloqueio('AREA_DEVE_SER_NOVA_FILHA_WIN19_NO_LOCALAPPDATA')
        for n in (local,*local.parents):
            if tem_metadados_git(n):raise Bloqueio('AREA_DENTRO_GIT')
        if area==root or area.is_relative_to(root) or root.is_relative_to(area):raise Bloqueio('AREA_SOBREPOE_CANDIDATA')
        if os.path.lexists(area):raise Bloqueio('AREA_PREVISTA_JA_EXISTE_PRESERVAR')
        report.update(area_prevista_nova=True,area_direta_localappdata=True,
                      area_fora_git=True,sem_sobreposicao_candidata=True)
        report.update(contexto_token())
        if report['token_elevado']:raise Bloqueio('CONTA_ELEVADA_NAO_AUTORIZADA')
        report.update(volume_info(local))
        report['volume_candidata']=volume_info(root)
        if report['sistema_arquivos']!='NTFS':raise Bloqueio('VOLUME_AREA_NAO_NTFS')
        if not report['persistent_acls_suportadas']:raise Bloqueio('VOLUME_AREA_SEM_ACL_PERSISTENTE')
        # Consulta de capacidade de nome curto em um arquivo EXISTENTE, sem criar alias.
        target=root/'tools/exp04_win/casos_historicos.json';k=ctypes.WinDLL('kernel32',use_last_error=True)
        fn=k.GetShortPathNameW;fn.argtypes=[wintypes.LPCWSTR,wintypes.LPWSTR,wintypes.DWORD];fn.restype=wintypes.DWORD
        buf=ctypes.create_unicode_buffer(32768);n=fn(str(target),buf,len(buf));error=ctypes.get_last_error() if not n else None
        if not n:raise Bloqueio('GET_SHORT_PATH_QUERY_FALHOU_'+str(error))
        if n>=len(buf):raise Bloqueio('GET_SHORT_PATH_TAMANHO_INVALIDO')
        report.update(alias_existente_observado=bool(0<n<len(buf) and buf.value.lower()!=str(target).lower()),
                      codigo_sonda_alias=error,alias_sintetico_ainda_nao_testado=True)
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock',0,winreg.KEY_READ) as key:
                report['developer_mode_somente_leitura']=bool(winreg.QueryValueEx(key,'AllowDevelopmentWithoutDevLicense')[0])
        except FileNotFoundError:report['developer_mode_somente_leitura']=False
        except OSError as error:
            raise Bloqueio('DEVELOPER_MODE_QUERY_FALHOU_'+str(getattr(error,'winerror',None))) from None
        report['estado']='OBSERVACOES_COLETADAS_SEM_AUTORIZACAO_DE_TESTES'
    except Bloqueio as e:report.update(estado='BLOQUEADO',codigo=str(e))
    except Exception:report.update(estado='BLOQUEADO',codigo='PREFLIGHT_ERRO_OPERACIONAL')
    finally:
        if before_valid:
            try:
                if hashes(root)!=expected:raise Bloqueio('HASHES_ALTERADOS_DURANTE_PREFLIGHT')
                report.update(hashes_depois_conferidos=470,integridade_depois=True,
                              hashes_antes_depois_da_coleta=470)
            except Exception:
                if report.get('codigo'):report['codigo_antes_integridade_final']=report['codigo']
                report.update(estado='BLOQUEADO',codigo='INTEGRIDADE_FINAL_NAO_COMPROVADA')
    report['impedimentos']=impedimentos(report)
    report['coleta_concluida']=report['estado']!='BLOQUEADO'
    print(json.dumps(report,ensure_ascii=True))
    return 2 if report['estado']=='BLOQUEADO' else 0


if __name__=='__main__':raise SystemExit(main())
