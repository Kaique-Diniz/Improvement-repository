param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Candidata,
    [Parameter(Mandatory=$true)][string]$Manifesto,
    [Parameter(Mandatory=$true)][string]$AreaPrevista
)
$ErrorActionPreference = 'Stop'
$CodigoPreflight = 2
# Somente o ambiente deste processo; restaurado ao sair. Não altera registro/políticas.
$Utf8Anterior = [Environment]::GetEnvironmentVariable('PYTHONUTF8', 'Process')
$BytecodeAnterior = [Environment]::GetEnvironmentVariable('PYTHONDONTWRITEBYTECODE', 'Process')
try {
    $env:PYTHONUTF8 = '1'
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $Sonda = Join-Path $PSScriptRoot 'preflight_win19.py'
    # -I/-S evitam sitecustomize, user site e imports de PYTHONPATH na inicialização.
    & $Python -I -S -B -X utf8 $Sonda --candidata $Candidata --manifesto $Manifesto --area-prevista $AreaPrevista
    $CodigoPreflight = $LASTEXITCODE
}
finally {
    [Environment]::SetEnvironmentVariable('PYTHONUTF8', $Utf8Anterior, 'Process')
    [Environment]::SetEnvironmentVariable('PYTHONDONTWRITEBYTECODE', $BytecodeAnterior, 'Process')
}
if ($CodigoPreflight -ne 0) { throw 'WIN19_PREFLIGHT_BLOQUEADO_VER_JSON_SANITIZADO' }
Write-Host 'COLETA_CONCLUIDA. Saida 0 nao autoriza testes. Examine impedimentos no JSON.'
Write-Host 'PRONTIDAO_PARA_EXECUTAR=False; DACL=NAO_VALIDADO; conversoes reais BLOQUEADAS.'
