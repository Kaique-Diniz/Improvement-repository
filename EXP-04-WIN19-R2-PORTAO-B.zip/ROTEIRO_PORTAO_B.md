# WIN19-R2 — roteiro final do Portão B, ainda NÃO EXECUTADO

18/11/2026. Portão B é elegível para autorização específica; esta entrega não
concede essa autorização. Não executar agora os blocos ou scripts abaixo.
Não executar pytest, coleta, testes nativos/DACL nem criar área/link/conta.

## 1. Identidades e caminhos para revisão

Pacote R2 de origem: EXP-04-WIN19-R2-preparacao.zip, 219.760 bytes, 33 entradas,
SHA-256 535fa9e0fae92ec358edd74a385808170d38570ce0ead3fd715e230715be585b.
CRC e os 32 hashes internos foram reconferidos nesta tarefa por leitura local.

Candidata Windows EXISTENTE informada pelo usuário:
`%LOCALAPPDATA%\E4-R1-FIX\candidata-lf-v2`.
O usuário confirmou o caminho absoluto correspondente no perfil atual. A notação
acima evita reproduzir nome pessoal no material compartilhável. Não criar outra
worktree nem reconstruir, converter LF ou corrigir a candidata existente.

Referência: `REFERENCIA_R1_FIX_470_SHA256.json`, SHA-256
`a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`,
baseline `770d062d29c4361d6932592883df9339bb4089bc` e 470 entradas.
HEAD isolado não prova correspondência; comparação inclui todos os arquivos,
extras e tipos inesperados, exceto o metadado .git da raiz.

Pasta Windows proposta de preparação externa:
`%LOCALAPPDATA%\WIN19-R2-Portao-B\preparacao`.
Nela, preservar os caminhos `tools\preflight_win19.py/.ps1` e o manifesto.
Não substituir a extração R2 anterior: esta é uma cópia de revisão separada.
A escolha/extração desta pasta é uma etapa manual futura, fora do preflight.
Não copiar a candidata ou documentos privados para a pasta de preparação.

Python proposto a partir do roteiro anterior:
`%LOCALAPPDATA%\WIN01D-Auditoria\venv\Scripts\python.exe`.
A existência/versão desse executável e dos caminhos Windows não foi verificada
nesta etapa. O comando exige Python3.12; se não existir, parar e informar o
executável3.12 já disponível. Sem instalação, elevação ou alteração de políticas.

Área apenas PREVISTA: `%LOCALAPPDATA%\WIN19-B-<GUID>`; filha direta do LocalAppData
registrado, nova e inexistente. Não usar pasta de evidências existente, Git,
documentos, outra candidata ou o contêiner residual. A GUID só é criada em memória;
a área não é criada pelo comando, pela sonda ou pelo script PowerShell.

## 2. Conferência da preparação antes de autorizar B

Conferir o manifesto desta entrega e o SHA externo independentemente. Os três
hashes usados na chamada constam de HASHES_PREFLIGHT_PORTAO_B.json. O comando
pinado recusa reparse em seus arquivos e divergência de hash. A sonda também
recusa scripts/manifesto dentro de Git (incluindo .git danificado ou Git bare),
ancestrais reparse, sobreposição e redirecionamento de ambiente Git.

A matriz e a proposta DACL são cópias byte a byte da R2; nenhuma decisão D01–D10
foi alterada/aprovada. Aprovação do procedimento B não autoriza C, D ou E.
O comando e os scripts desta entrega não foram executados em PowerShell5.1.

## 3. Comando para execução FUTURA, somente após autorização específica

Abrir PowerShell comum, não administrativo. Não alterar ExecutionPolicy, usar
Bypass, ativar Developer Mode ou conceder privilégio de symlink.

```powershell
# NAO EXECUTADO. Revisar caminhos e obter autorizacao especifica ANTES de usar.
$ErrorActionPreference = 'Stop'
$LocalWIN19 = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::LocalApplicationData)
$PreparacaoB = Join-Path $LocalWIN19 'WIN19-R2-Portao-B\preparacao'
$Candidata = Join-Path $LocalWIN19 'E4-R1-FIX\candidata-lf-v2'
$Python = Join-Path $LocalWIN19 'WIN01D-Auditoria\venv\Scripts\python.exe'
$AreaPrevista = Join-Path $LocalWIN19 ('WIN19-B-' + [guid]::NewGuid().ToString('N'))
$ComandoB = Join-Path $PreparacaoB 'COMANDO_PORTAO_B_NAO_EXECUTADO.ps1'
# A flag abaixo e uma trava; NAO e uma autorizacao por si mesma.
& $ComandoB -Python $Python -Candidata $Candidata -AreaPrevista $AreaPrevista -PortaoBAutorizado
```

O comando confere hashes e chama somente tools/preflight_win19.ps1. Este chama
Python com `-I -S -B -X utf8`: sem PYTHONPATH/sitecustomize/user site, sem bytecode,
UTF-8 explícito. Nenhum módulo da aplicação, helper de remoção ou teste é importado.
Não executar esse comando diretamente para obter uma suposta aprovação WIN19.

## 4. Saídas, interrupções e custódia

A sonda produz uma linha JSON ASCII sanitizada. Saída0: coleta concluída mesmo
com impedimentos. Saída2/estado BLOQUEADO, JSON ausente ou inválido: parar e
preservar o registro disponível; não repetir em loop nem tentar corrigir o SO.
O wrapper PowerShell pode emitir exceção controlada após a linha JSON.
O comando proposto captura essa linha em uma lista em memória antes do throw,
sem imprimir o texto de exceção inesperada. Em ausência de JSON não há evidência
de integridade/conclusão: registrar NÃO_VALIDADO e revisar o erro em privado.

Também calcula SHA-256 da representação JSON normalizada para UTF-8 sem BOM,
LF e newline final. Esse SHA não é o hash de stdout bruto byte a byte; PowerShell
remove delimitadores de linha ao capturar texto. Não confundir as representações.
O comando não grava logs, JSON, temporários, área nem JUnit. Exibição/hash em
memória não é custódia durável e não substitui um runner de evidências.

A autorização futura deve designar custodiante e método de retenção. Guardar
originais stdout/stderr (quando houver captura original confiável) em custódia
privada separada, com tamanho/SHA, horário/fuso, versão dos scripts e caminho da
candidata. Se só houver cópia da linha normalizada, declarar stdout bruto
NÃO_DISPONIVEL e registrar explicitamente a transformação. Retenção manual em
pasta local de evidências fora do Git é separada da sonda e requer procedimento
aprovado; nada é salvo automaticamente por esta entrega. Não compartilhar stderr
inesperado sem revisão: pode conter caminhos privados. Hashes de cópias brutas e
sanitizadas são distintos; não inventar hashes ou registros que não existam.

Revisar CRITERIOS_ACEITACAO_PORTAO_B.csv. Para reconhecer COLETA CONCLUÍDA,
precisam existir 470 hashes e integridade true antes/depois, HEAD correto, Git
consultado, Python3.12/UTF-8/isolamento, token não elevado, área válida e NTFS
na área prevista, sem erro de consulta. O status Git pode ser sujo pela reconstrução
esperada: comparar com manifesto, não exigir clean nem fazer reset/clean.

Mesmo nesse caso permanecem prontidao_para_executar=false, impedimentos explícitos,
C/D/E BLOQUEADOS, 19 PROVISORIO_SEM_FONTE e DACL NÃO_VALIDADO. Ausência de alias
ou privilégio symlink não autoriza alteração do ambiente nem aprova rejeição de
links. Erro de API, reparse, área inválida, elevação, hash/HEAD divergente ou
NTFS incompatível bloqueiam. Integridade final é tentada no finally se a inicial
foi válida, inclusive após falha de consulta; falta de prova final impede aceite.

## 5. Parada

Entregar JSON/custódia para revisão humana após eventual B autorizado. Nenhum
pytest, --collect-only, symlink, junction, teste de helper ou acesso DACL decorre
de saída0. Não rodar os 21 casos diretamente. C depende de runner resiliente,
revisão dos helpers/factories e outra autorização. D depende da política/tokens;
E/homologação/conversões reais/publicação permanecem bloqueados.
