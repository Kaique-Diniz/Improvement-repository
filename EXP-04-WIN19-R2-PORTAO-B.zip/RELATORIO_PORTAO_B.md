# WIN19-R2 — preparação do Portão B entregue para revisão

18/11/2026. Escopo principal: INSTRUCOES_CODEX_WIN19_R2_PORTAO_B.md;
fundamentação: PARECER_TECNICO_WIN19_R2_2026-11-18.md, copiados literalmente.

Entregues roteiro final/comando PowerShell não executado,22 critérios de aceite,
modelo de evidência, inspeção de leitura, revisão das ressalvas C/D e proposta
não aplicada para ampliar sentinelas da autoridade WIN14. A sonda foi ajustada
somente em cópia externa: HEAD/hashes/runtime/área explícitos, integridade final
em finally, recusa de preparação em Git e de ambiente Git redirecionado, consultas
falhas fechadas e Python -I -S -B -X utf8. Não foi criado executor dos casos C.

Caminho da candidata fornecido pelo usuário corresponde a
%LOCALAPPDATA%\E4-R1-FIX\candidata-lf-v2; nenhum caminho Windows foi acessado
nesta tarefa. O roteiro separa confirmação textual, hashes locais e futura
verificação nativa. A pasta de preparação/área WIN19 e o executável Python são
propostos, não declarados existentes/conferidos no computador Windows.

Conferências desta entrega: leitura dos anexos/código, AST/compilação em memória,
parsing JSON/CSV, hashes/CRC do ZIP R2 e leitura Git de preservação. Zero execução
de preflight (inclusive Linux), pytest, coleta, helper, symlink, experimento API
ou DACL. PowerShell5.1 não foi executado nem testado. Nenhuma dependência instalada.

Matriz19, referência470 e proposta DACL são idênticas às R2. Política não mudou;
19 vínculos PROVISORIO_SEM_FONTE, funcional/nativo/DACL NÃO_VALIDADO. Fonte primária
EXP04 e os sete motivos históricos continuam ausentes; checklist preservado.
Os470 hashes locais,27worktrees, refsGit e16pacotes anteriores são reconferidos
no registro de preservação. Isso não é conferência de hashes na máquina Windows.

DIFF_PREPARACAO_PORTAO_B.patch mostra diferenças aplicadas só à preparação externa;
PROPOSTA_WIN14_AUTORIDADE_NAO_APLICADA.patch é sugestão separada para revisão,
sem aplicação aos testes. Manifesto final cobre todos os arquivos exceto ele
próprio. Diff exclui a si próprio e o manifesto para evitar autorreferência.

O comando B conserva JSON sanitizado em memória mesmo após erro controlado,
mas captura textual normalizada não é stdout bruto e não oferece custódia durável.
Não usar esse comando como runner de evidências C. Ver pendências e protocolo de
retenção manual futura, separado da sonda que não cria arquivos.

PARE: B aguarda autorização específica, C/D/E BLOQUEADOS, DACL PARA_APROVAÇÃO,
homologação e conversões reais BLOQUEADAS. Sem commit/push/PR/merge/publicação.
A vedação específica desta entrega prevalece sobre a autorização geral anterior
para publicar ZIPs. Se houver pacote ZIP local, ele não será publicado nesta etapa.
