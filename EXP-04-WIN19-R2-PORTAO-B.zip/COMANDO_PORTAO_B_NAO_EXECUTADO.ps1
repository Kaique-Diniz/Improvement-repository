# PREPARADO, NAO EXECUTADO. A flag nao substitui autorizacao posterior do usuario.
param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Candidata,
    [Parameter(Mandatory=$true)][string]$AreaPrevista,
    [switch]$PortaoBAutorizado
)
$ErrorActionPreference = 'Stop'
if (-not $PortaoBAutorizado) { throw 'PORTAO_B_AGUARDA_AUTORIZACAO_POSTERIOR' }

function Conferir-CaminhoSemReparse([string]$Caminho) {
    if (-not [IO.Path]::IsPathRooted($Caminho)) { throw 'CAMINHO_DEVE_SER_ABSOLUTO' }
    $Atual = [IO.Path]::GetFullPath($Caminho)
    while ($Atual) {
        $Item = Get-Item -LiteralPath $Atual -Force
        if (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw 'CAMINHO_CONTEM_REPARSE_PRESERVAR'
        }
        $Pai = [IO.Path]::GetDirectoryName($Atual)
        if ($Pai -eq $Atual) { break }
        $Atual = $Pai
    }
}

$Local = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::LocalApplicationData)
if (-not $Local) { throw 'LOCALAPPDATA_REGISTRADO_INDISPONIVEL' }
$CandidataEsperada = Join-Path $Local 'E4-R1-FIX\candidata-lf-v2'
if (-not [string]::Equals([IO.Path]::GetFullPath($Candidata), $CandidataEsperada,
        [StringComparison]::OrdinalIgnoreCase)) { throw 'CAMINHO_CANDIDATA_DIFERENTE_DO_REVISADO' }
$Manifesto = Join-Path $PSScriptRoot 'REFERENCIA_R1_FIX_470_SHA256.json'
$Sonda = Join-Path $PSScriptRoot 'tools\preflight_win19.ps1'
$Hashes = @{
    'tools\preflight_win19.py' = 'a4791c242baeb8aaf4f54a6a7a7e9e5a382f586e4abd8577fc856a529eb0a73f'
    'tools\preflight_win19.ps1' = '0b25e04a23aea0c8ee0bb470278864688c4c1eb656787ba6bd5089252147979a'
    'REFERENCIA_R1_FIX_470_SHA256.json' = 'a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c'
}
Conferir-CaminhoSemReparse $Python
Conferir-CaminhoSemReparse $Candidata
foreach ($Nome in $Hashes.Keys) {
    $Arquivo = Join-Path $PSScriptRoot $Nome
    Conferir-CaminhoSemReparse $Arquivo
    if ((Get-FileHash -LiteralPath $Arquivo -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Hashes[$Nome]) {
        throw 'HASH_PREPARACAO_DIVERGENTE_PRESERVAR'
    }
}

# Preserva em memoria a linha JSON emitida ANTES de eventual throw da sonda.
# Nao imprime $_ do catch: mensagens inesperadas podem conter caminhos privados.
# Esta captura textual normaliza LF; nao e stdout bruto byte a byte.
$LinhasPortaoB = New-Object 'System.Collections.Generic.List[string]'
$FalhaPortaoB = $false
try {
    & $Sonda -Python $Python -Candidata $Candidata -Manifesto $Manifesto -AreaPrevista $AreaPrevista |
        ForEach-Object { [void]$LinhasPortaoB.Add([string]$_) }
}
catch { $FalhaPortaoB = $true }
$JsonNormalizadoPortaoB = [string]::Join("`n", $LinhasPortaoB.ToArray()) + "`n"
try { $RelatorioPortaoB = ConvertFrom-Json -InputObject $JsonNormalizadoPortaoB }
catch { throw 'SAIDA_JSON_AUSENTE_OU_INVALIDA_NAO_COMPARTILHAR_CAPTURA_BRUTA' }
if ($null -eq $RelatorioPortaoB.estado) { throw 'JSON_SEM_ESTADO_PRESERVAR' }

# JSON da sonda e SHA da representacao normalizada; nenhuma escrita em arquivo.
Write-Output $JsonNormalizadoPortaoB
$Sha = [Security.Cryptography.SHA256]::Create()
try {
    $Digest = $Sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($JsonNormalizadoPortaoB))
    $HashJson = [BitConverter]::ToString($Digest).Replace('-', '').ToLowerInvariant()
}
finally { $Sha.Dispose() }
Write-Host ('SHA256_JSON_NORMALIZADO_LF_UTF8_SEM_BOM=' + $HashJson)
if ($FalhaPortaoB -or -not $RelatorioPortaoB.coleta_concluida -or
        $RelatorioPortaoB.estado -eq 'BLOQUEADO') {
    throw 'PORTAO_B_BLOQUEADO_JSON_PRESERVADO_EM_MEMORIA_NAO_REEXECUTAR'
}
Write-Host 'COLETA_CONCLUIDA; NAO E APROVACAO. C/D/E BLOQUEADOS; DACL NAO_VALIDADO.'
