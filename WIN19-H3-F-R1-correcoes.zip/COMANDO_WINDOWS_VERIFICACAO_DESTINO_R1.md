# WIN19-H3-F-R1 — bloco completo materializado para auditoria

24/11/2026 — America/Sao_Paulo.
**MATERIALIZADO_AGUARDANDO_AUDITORIA — NÃO VALIDADO POR PARSER — NÃO EXECUTADO.**

Nova versão documental derivada exclusivamente do bloco H3-F autenticado e dos
quatro hunks H3-G. D01: revalidação V09; D02: parada após falha de descarte WMI;
D03: erro da guarda classificado V03; D04: Path ausente em share de disco.
Nenhuma mudança adicional. O original H3-F e a proposta H3-G estão preservados.

Não executar, importar, dot-source ou colar este bloco para “carregar funções”.
A chamada final original permanece presente e invocaria a função se o texto
fosse executado. Uma eventual análise sintática futura, sob nova autorização,
deverá receber os bytes como texto, sem executar o bloco ou suas funções.
Não há arquivo .ps1 ou autorização de teste/consulta nesta entrega.

A identidade H3-F-R1 é documental e criptográfica. O campo interno versao_proposta
permanece exatamente como na fonte, pois alterá-lo seria uma quinta mudança
não autorizada. Nenhuma parte da fonte foi reconstruída de parecer ou de memória.

<!-- INICIO_BLOCO_POWERSHELL_H3_F_R1 -->
```powershell
function Invoke-H3FProposta {
    # PROPOSTA NAO EXECUTADA. Requer revisao e autorizacao futuras.
    $ErrorActionPreference = 'Stop'
    $states = [ordered]@{}
    foreach ($n in 1..10) {
        $id = 'V{0:00}' -f $n
        $states[$id] = [ordered]@{ estado = 'NAO_EXECUTADO'; codigos = @() }
    }
    $flow = [pscustomobject]@{
        Atual = 'V01'; ParadaControlada = $false; RecursosFechados = $true
    }
    $identity = $null
    $proposed = $null
    $chain = New-Object 'System.Collections.Generic.List[object]'
    $missing = @()
    $versao = $PSVersionTable.PSVersion.ToString()

    function Set-H3State([string]$Id, [string]$Estado, [string[]]$Codigos) {
        $states[$Id].estado = $Estado
        $states[$Id].codigos = @($Codigos)
    }
    function Stop-H3([string]$Id, [string]$Estado, [string]$Codigo) {
        Set-H3State $Id $Estado @($Codigo)
        $flow.ParadaControlada = $true
        throw [System.OperationCanceledException]::new('H3F_PARADA_CONTROLADA')
    }
    function Get-H3Attributes([string]$PrivatePath) {
        try {
            return [pscustomobject]@{
                Ausente = $false; Atributos = [IO.File]::GetAttributes($PrivatePath)
            }
        } catch {
            $cause = $_.Exception.GetBaseException()
            if (($cause -is [IO.FileNotFoundException]) -and
                (($cause.HResult -band 65535) -eq 2)) {
                return [pscustomobject]@{ Ausente = $true; Atributos = $null }
            }
            # Acesso negado, erro 3 e demais falhas nao viram inexistencia segura.
            throw [InvalidOperationException]::new('H3F_METADADO_INDISPONIVEL')
        }
    }
    function Assert-H3Chain {
        # Releitura ordenada, sem resolver links; nao equivale a pin por handle.
        foreach ($entry in $chain) {
            try {
                $a = Get-H3Attributes $entry.Caminho
            } catch {
                Stop-H3 'V03' 'INCONCLUSIVO' 'H3F_RELEITURA_ANCESTRAL_INDISPONIVEL'
            }
            if ($a.Ausente -or
                (($a.Atributos -band [IO.FileAttributes]::ReparsePoint) -ne 0) -or
                (($a.Atributos -band [IO.FileAttributes]::Directory) -eq 0) -or
                ($a.Atributos -ne $entry.Atributos)) {
                Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_ALTERACAO_OU_REDIRECIONAMENTO'
            }
        }
    }
    function Test-H3Within([string]$Child, [string]$Parent) {
        # Comparacao nominal privada, sem consulta ao destino indicado em Parent.
        $a = $Child.TrimEnd([char]92)
        $b = $Parent.TrimEnd([char]92)
        return ($a.Equals($b, [StringComparison]::OrdinalIgnoreCase) -or
            $a.StartsWith($b + '\', [StringComparison]::OrdinalIgnoreCase))
    }
    function Get-H3LocalRows([string]$Namespace, [string]$Query, [string[]]$Fields) {
        if ($Namespace -notin @('root\cimv2', 'root\Microsoft\Windows\Storage')) {
            throw [InvalidOperationException]::new('H3F_NAMESPACE_NAO_PERMITIDO')
        }
        $searcher = $null; $collection = $null; $iterator = $null
        $rows = New-Object 'System.Collections.Generic.List[object]'
        try {
            $options = [System.Management.ConnectionOptions]::new()
            $options.EnablePrivileges = $false
            $options.Timeout = [TimeSpan]::FromSeconds(10)
            $scope = [System.Management.ManagementScope]::new(('\\.\' + $Namespace), $options)
            $enumOptions = [System.Management.EnumerationOptions]::new()
            $enumOptions.Timeout = [TimeSpan]::FromSeconds(10)
            $enumOptions.Rewindable = $false
            $searcher = [System.Management.ManagementObjectSearcher]::new(
                $scope, [System.Management.ObjectQuery]::new($Query), $enumOptions)
            $collection = $searcher.Get()
            $iterator = $collection.GetEnumerator()
            while ($iterator.MoveNext()) {
                $item = $iterator.Current
                try {
                    if ($rows.Count -ge 256) {
                        throw [InvalidOperationException]::new('H3F_CONSULTA_LIMITE')
                    }
                    $record = @{}
                    foreach ($field in $Fields) { $record[$field] = $item.Properties[$field].Value }
                    [void]$rows.Add([pscustomobject]$record)
                } finally {
                    try { $item.Dispose() } catch {
                        $flow.RecursosFechados = $false
                        throw [InvalidOperationException]::new('H3F_DESCARTE_ITEM_FALHOU')
                    }
                }
            }
        } finally {
            foreach ($resource in @($iterator, $collection, $searcher)) {
                if ($null -ne $resource) {
                    try { $resource.Dispose() } catch { $flow.RecursosFechados = $false }
                }
            }
            if (-not $flow.RecursosFechados) {
                throw [InvalidOperationException]::new('H3F_RECURSO_NAO_ENCERRADO')
            }
        }
        return $rows.ToArray()
    }

    try {
        $flow.Atual = 'V01'
        if (($PSVersionTable.PSVersion.Major -ne 5) -or
            ($PSVersionTable.PSVersion.Minor -ne 1) -or
            ($PSVersionTable.PSEdition -ne 'Desktop') -or
            ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT)) {
            Stop-H3 'V01' 'IMPEDIMENTO' 'H3F_AMBIENTE_INCOMPATIVEL'
        }
        $sender = Microsoft.PowerShell.Utility\Get-Variable -Name PSSenderInfo -ErrorAction SilentlyContinue
        $session = [Environment]::GetEnvironmentVariable('SESSIONNAME', 'Process')
        if (($null -ne $sender -and $null -ne $sender.Value) -or
            ($Host.Name -eq 'ServerRemoteHost') -or ($session -match '^(RDP|ICA)')) {
            Stop-H3 'V01' 'IMPEDIMENTO' 'H3F_SESSAO_REMOTA_DETECTADA'
        }
        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $machinePrivate = [Environment]::MachineName
        if (($null -eq $identity.User) -or [string]::IsNullOrWhiteSpace($machinePrivate)) {
            Stop-H3 'V01' 'INCONCLUSIVO' 'H3F_CONTEXTO_LOCAL_INDISPONIVEL'
        }
        $principal = [Security.Principal.WindowsPrincipal]::new($identity)
        $elevated = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if ($elevated) { Stop-H3 'V01' 'IMPEDIMENTO' 'H3F_SESSAO_ELEVADA_FORA_DO_ESCOPO' }
        Set-H3State 'V01' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_CONTEXTO_LOCAL_OBSERVADO_LEGITIMIDADE_NAO_CERTIFICADA')

        $flow.Atual = 'V03'
        # Entrada unica local, sem valor padrao e sem publicacao do caminho.
        $proposed = Microsoft.PowerShell.Utility\Read-Host -Prompt 'Caminho privado proposto (absoluto; nao sera criado)'
        if ([string]::IsNullOrWhiteSpace($proposed) -or
            ($proposed -ne $proposed.Trim()) -or ($proposed.Length -gt 240) -or
            ($proposed -notmatch '^[A-Za-z]:\\') -or ($proposed.Contains('/')) -or
            ($proposed.Length -le 3) -or $proposed.EndsWith('\')) {
            Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_CAMINHO_INVALIDO_OU_AMBIGUO'
        }
        $parts = @($proposed.Substring(3).Split([char]92))
        foreach ($part in $parts) {
            if ([string]::IsNullOrWhiteSpace($part) -or ($part -ne $part.Trim()) -or
                $part.EndsWith('.') -or ($part -in @('.', '..')) -or $part.Contains('~') -or
                ($part.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) -or
                ($part -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]|CONIN\$|CONOUT\$)(\..*)?$')) {
                Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_COMPONENTE_AMBIGUO'
            }
        }
        $full = [IO.Path]::GetFullPath($proposed)
        if (-not $full.Equals($proposed, [StringComparison]::OrdinalIgnoreCase)) {
            Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_NORMALIZACAO_NAO_IDENTICA'
        }
        $root = $proposed.Substring(0, 3)
        $flow.Atual = 'V02'
        $drive = [IO.DriveInfo]::new($root)
        if ($drive.DriveType -eq [IO.DriveType]::Network) {
            Stop-H3 'V02' 'IMPEDIMENTO' 'H3F_VOLUME_REMOTO'
        }
        if ($drive.DriveType -in @([IO.DriveType]::Removable, [IO.DriveType]::CDRom)) {
            Stop-H3 'V02' 'IMPEDIMENTO' 'H3F_VOLUME_REMOVIVEL'
        }
        if (($drive.DriveType -ne [IO.DriveType]::Fixed) -or (-not $drive.IsReady)) {
            Stop-H3 'V02' 'INCONCLUSIVO' 'H3F_VOLUME_NAO_IDENTIFICADO'
        }
        # Fixed permite apenas as proximas consultas locais; nao prova disco interno.
        $letter = $proposed.Substring(0, 1).ToUpperInvariant()
        $q = "ASSOCIATORS OF {Win32_LogicalDisk.DeviceID='$($letter):'} WHERE AssocClass=Win32_LogicalDiskToPartition"
        $partitions = @(Get-H3LocalRows 'root\cimv2' $q @('DiskIndex'))
        if ($partitions.Count -ne 1 -or $null -eq $partitions[0].DiskIndex) {
            Stop-H3 'V02' 'INCONCLUSIVO' 'H3F_MAPEAMENTO_FISICO_AMBIGUO'
        }
        $diskIndex = [uint32]$partitions[0].DiskIndex
        $physical = @(Get-H3LocalRows 'root\cimv2' ("SELECT Index, InterfaceType, MediaType FROM Win32_DiskDrive WHERE Index=$diskIndex") @('Index','InterfaceType','MediaType'))
        $disks = @(Get-H3LocalRows 'root\Microsoft\Windows\Storage' ("SELECT Number, BusType, IsOffline FROM MSFT_Disk WHERE Number=$diskIndex") @('Number','BusType','IsOffline'))
        if ($physical.Count -ne 1 -or $disks.Count -ne 1 -or
            $null -eq $physical[0].Index -or $null -eq $disks[0].Number -or
            [uint32]$physical[0].Index -ne $diskIndex -or
            [uint32]$disks[0].Number -ne $diskIndex -or
            $null -eq $disks[0].BusType -or $null -eq $disks[0].IsOffline -or
            $disks[0].IsOffline) {
            Stop-H3 'V02' 'INCONCLUSIVO' 'H3F_DISCO_FISICO_NAO_IDENTIFICADO'
        }
        $bus = [int]$disks[0].BusType
        if ($bus -in @(4, 7, 9, 12, 13)) {
            Stop-H3 'V02' 'IMPEDIMENTO' 'H3F_BARRAMENTO_INCOMPATIVEL'
        }
        if ($bus -notin @(3, 10, 11, 17, 18, 19)) {
            Stop-H3 'V02' 'INCONCLUSIVO' 'H3F_NATUREZA_FISICA_NAO_DEMONSTRADA'
        }
        Set-H3State 'V02' 'INCONCLUSIVO' @('H3F_DISCO_LOCAL_OBSERVADO_INTERNO_NAO_CERTIFICADO')

        $flow.Atual = 'V03'
        $rootAttr = Get-H3Attributes $root
        if ($rootAttr.Ausente -or
            (($rootAttr.Atributos -band [IO.FileAttributes]::Directory) -eq 0) -or
            (($rootAttr.Atributos -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
            Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_RAIZ_INACESSIVEL_OU_REDIRECIONADA'
        }
        [void]$chain.Add([pscustomobject]@{ Caminho = $root; Atributos = $rootAttr.Atributos })
        $cursor = $root
        for ($i = 0; $i -lt $parts.Count; $i++) {
            Assert-H3Chain
            $cursor = [IO.Path]::Combine($cursor, $parts[$i])
            $a = Get-H3Attributes $cursor
            Assert-H3Chain
            if ($a.Ausente) {
                $missing = @($parts[$i..($parts.Count - 1)])
                break
            }
            if (($a.Atributos -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
                Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_REPARSE_DETECTADO'
            }
            if ($i -eq $parts.Count - 1) {
                Stop-H3 'V09' 'IMPEDIMENTO' 'H3F_DESTINO_JA_EXISTENTE'
            }
            if (($a.Atributos -band [IO.FileAttributes]::Directory) -eq 0) {
                Stop-H3 'V03' 'IMPEDIMENTO' 'H3F_ANCESTRAL_NAO_DIRETORIO'
            }
            [void]$chain.Add([pscustomobject]@{ Caminho = $cursor; Atributos = $a.Atributos })
        }
        if ($missing.Count -eq 0) { Stop-H3 'V09' 'INCONCLUSIVO' 'H3F_ANCESTRAL_NAO_DETERMINADO' }
        $ancestorPrivate = $chain[$chain.Count - 1].Caminho
        $firstMissingPrivate = $cursor
        Set-H3State 'V03' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_COMPONENTES_EXISTENTES_SEM_REPARSE_OBSERVADO')
        Set-H3State 'V09' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_PRIMEIRA_AUSENCIA_OBSERVADA_SEM_GARANTIA_FUTURA')

        $flow.Atual = 'V04'
        foreach ($part in $parts) {
            if ($part.Equals('.git', [StringComparison]::OrdinalIgnoreCase)) {
                Stop-H3 'V04' 'IMPEDIMENTO' 'H3F_COMPONENTE_GIT'
            }
        }
        foreach ($entry in $chain) {
            Assert-H3Chain
            $marker = Get-H3Attributes ([IO.Path]::Combine($entry.Caminho, '.git'))
            if (-not $marker.Ausente) { Stop-H3 'V04' 'IMPEDIMENTO' 'H3F_GIT_OU_WORKTREE_DETECTADO' }
            $signals = 0
            foreach ($name in @('HEAD', 'config', 'objects', 'refs', 'commondir')) {
                Assert-H3Chain
                $marker = Get-H3Attributes ([IO.Path]::Combine($entry.Caminho, $name))
                if (-not $marker.Ausente) { $signals++ }
            }
            if ($signals -ge 2) { Stop-H3 'V04' 'IMPEDIMENTO' 'H3F_METADADOS_GIT_AMBIGUOS' }
        }
        Assert-H3Chain
        Set-H3State 'V04' 'INCONCLUSIVO' @('H3F_SEM_MARCADOR_COMUM_SEPARACAO_GIT_NAO_CERTIFICADA')

        $flow.Atual = 'V06'
        foreach ($key in @('OneDrive', 'OneDriveCommercial', 'OneDriveConsumer')) {
            $cloud = [Environment]::GetEnvironmentVariable($key, 'Process')
            if (-not [string]::IsNullOrWhiteSpace($cloud)) {
                if ($cloud -notmatch '^[A-Za-z]:\\') {
                    Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_INDICADOR_SINCRONIZACAO_AMBIGUO'
                }
                if (Test-H3Within $proposed ([IO.Path]::GetFullPath($cloud))) {
                    Stop-H3 'V06' 'IMPEDIMENTO' 'H3F_INDICADOR_SINCRONIZACAO_INCIDENTE'
                }
            }
        }
        $shares = @(Get-H3LocalRows 'root\cimv2' 'SELECT Path, Type FROM Win32_Share' @('Path','Type'))
        foreach ($share in $shares) {
            if ($null -eq $share.Type) { Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_SHARE_METADADO_INCOMPLETO' }
            if (([uint32]$share.Type -band 255) -eq 0) {
                if ([string]::IsNullOrWhiteSpace([string]$share.Path)) {
                    Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_SHARE_CAMINHO_INDISPONIVEL'
                }
                $sharePrivate = [string]$share.Path
                if ($sharePrivate -notmatch '^[A-Za-z]:\\') {
                    Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_SHARE_CAMINHO_AMBIGUO'
                }
                if (Test-H3Within $proposed ([IO.Path]::GetFullPath($sharePrivate))) {
                    Stop-H3 'V06' 'IMPEDIMENTO' 'H3F_COMPARTILHAMENTO_INCIDENTE'
                }
            }
        }
        Set-H3State 'V06' 'INCONCLUSIVO' @('H3F_AUSENCIA_INDICADORES_NAO_PROVA_AUSENCIA_EXPOSICAO')

        $flow.Atual = 'V07'
        Assert-H3Chain
        $sections = [Security.AccessControl.AccessControlSections]::Access -bor
            [Security.AccessControl.AccessControlSections]::Owner -bor
            [Security.AccessControl.AccessControlSections]::Group
        $aclPrivate = [IO.Directory]::GetAccessControl($ancestorPrivate, $sections)
        Assert-H3Chain
        $ownerPrivate = $aclPrivate.GetOwner([Security.Principal.SecurityIdentifier])
        $groupPrivate = $aclPrivate.GetGroup([Security.Principal.SecurityIdentifier])
        $groupsPrivate = @($identity.Groups)
        $rulesPrivate = $aclPrivate.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])
        $binaryPrivate = $aclPrivate.GetSecurityDescriptorBinaryForm()
        $rawPrivate = [Security.AccessControl.RawSecurityDescriptor]::new($binaryPrivate, 0)
        $nullDacl = ($null -eq $rawPrivate.DiscretionaryAcl)
        $broadAllow = 0; $denials = 0; $inherited = 0
        $broadTypes = @([Security.Principal.WellKnownSidType]::WorldSid,
            [Security.Principal.WellKnownSidType]::AuthenticatedUserSid,
            [Security.Principal.WellKnownSidType]::BuiltinUsersSid,
            [Security.Principal.WellKnownSidType]::BuiltinGuestsSid,
            [Security.Principal.WellKnownSidType]::AnonymousSid,
            [Security.Principal.WellKnownSidType]::NetworkSid)
        foreach ($rule in $rulesPrivate) {
            if ($rule.IsInherited) { $inherited++ }
            if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Deny) { $denials++ }
            if ($rule.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow) {
                foreach ($kind in $broadTypes) {
                    if ($rule.IdentityReference.IsWellKnown($kind)) { $broadAllow++; break }
                }
            }
        }
        # Identidades, regras, heranca e contadores nao sao publicados.
        Set-H3State 'V07' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_SEGURANCA_ANCESTRAL_LIDA_SEM_VALIDAR_EFETIVIDADE')

        $flow.Atual = 'V05'
        Set-H3State 'V05' 'INCONCLUSIVO' @('H3F_REFERENCIAS_PRIVADAS_AREAS_VEDADAS_NAO_FORNECIDAS')
        # Nao pedir caminhos extras, inventar referencias ou procurar candidatas.
        $flow.Atual = 'V09'
        Set-H3State 'V09' 'INCONCLUSIVO' @('H3F_REVALIDACAO_DESTINO_PENDENTE')
        Assert-H3Chain
        $again = Get-H3Attributes $firstMissingPrivate
        Assert-H3Chain
        if (-not $again.Ausente) { Stop-H3 'V09' 'IMPEDIMENTO' 'H3F_COLISAO_OU_ALTERACAO_OBSERVADA' }
        Set-H3State 'V09' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_PRIMEIRA_AUSENCIA_OBSERVADA_SEM_GARANTIA_FUTURA')
        $flow.Atual = 'V08'
        if ($nullDacl) { Stop-H3 'V08' 'IMPEDIMENTO' 'H3F_DACL_NULA_ANCESTRAL' }
        if ($broadAllow -gt 0) {
            Stop-H3 'V08' 'INCONCLUSIVO' 'H3F_CONCESSAO_AMPLA_REQUER_REVISAO_PRIVADA'
        }
        Stop-H3 'V08' 'INCONCLUSIVO' 'H3F_PROTECAO_FUTURA_E_PAPEIS_NAO_DEMONSTRADOS'
    } catch {
        if (-not $flow.ParadaControlada) {
            Set-H3State $flow.Atual 'INCONCLUSIVO' @('H3F_CONSULTA_LOCAL_FALHOU_SEM_DETALHES_PUBLICOS')
        }
    } finally {
        if ($null -ne $identity) {
            try { $identity.Dispose() } catch { $flow.RecursosFechados = $false }
        }
        # Remover referencias nao assegura apagamento forense de memoria/host.
        $identity = $null; $principal = $null; $proposed = $null
        $aclPrivate = $null; $rulesPrivate = $null; $binaryPrivate = $null
        $ownerPrivate = $null; $groupPrivate = $null; $groupsPrivate = $null
        $rawPrivate = $null; $machinePrivate = $null
    }
    $hasBlock = $false; $incomplete = (-not $flow.RecursosFechados); $executed = 0
    foreach ($id in @('V01','V02','V03','V04','V05','V06','V07','V08','V09')) {
        $state = $states[$id].estado
        if ($state -eq 'IMPEDIMENTO') { $hasBlock = $true }
        if ($state -in @('INCONCLUSIVO', 'NAO_EXECUTADO')) { $incomplete = $true }
        if ($state -ne 'NAO_EXECUTADO') { $executed++ }
    }
    if ($hasBlock) {
        $result = 'IMPEDIMENTO_IDENTIFICADO'
        Set-H3State 'V10' 'IMPEDIMENTO' @('H3F_CONSOLIDACAO_COM_IMPEDIMENTO')
    } elseif ($executed -eq 0) {
        $result = 'PROCEDIMENTO_NAO_EXECUTADO'
        Set-H3State 'V10' 'NAO_EXECUTADO' @('H3F_SEM_OBSERVACOES')
    } elseif ($incomplete) {
        $result = 'AVALIACAO_INCOMPLETA'
        Set-H3State 'V10' 'INCONCLUSIVO' @('H3F_CONSOLIDACAO_INCOMPLETA')
    } else {
        $result = 'SEM_IMPEDIMENTO_IDENTIFICADO_NAS_VERIFICACOES_REALIZADAS'
        Set-H3State 'V10' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_CONSOLIDACAO_LIMITADA_A_OBSERVACOES')
    }
    if (-not $flow.RecursosFechados) {
        $states['V10'].codigos += 'H3F_RECURSO_CONSULTA_NAO_ENCERRADO'
    }
    return [ordered]@{
        verificacao = 'WIN19-H3-F'; versao_proposta = '20261124-r1'
        powershell_versao = $versao; resultado_consolidado = $result
        verificacoes = $states; recursos_consulta_fechados = $flow.RecursosFechados
        copia_realizada = $false; alteracao_seguranca_autorizada = $false
        destino_aprovado = $false; h3_c_autorizada = $false
        legitimidade_institucional = 'PENDENTE_DE_DECISAO_PRIVADA'
        limitacoes = @('IDENTIDADE_FISICA_NAO_AUTENTICADA',
            'CORRIDAS_NAO_ELIMINADAS', 'PERMISSOES_DESTINO_INEXISTENTE_NAO_PROVADAS',
            'SINCRONIZACAO_E_EXPOSICAO_NAO_EXCLUIDAS', 'DACL_PRODUTO_NAO_VALIDADA',
            'HISTORIA_JUNIT_NAO_AUTENTICADA', 'REFERENCIAS_PRIVADAS_PENDENTES')
    }
}
# Somente uma saida publica agregada; sem arquivos, transcricao ou transcript.
Invoke-H3FProposta | Microsoft.PowerShell.Utility\ConvertTo-Json -Depth 8
```
<!-- FIM_BLOCO_POWERSHELL_H3_F_R1 -->

## Extração precisa e identidade

Usar somente o conteúdo entre a cerca powershell e sua cerca de fechamento,
delimitadas pelos marcadores INICIO_BLOCO_POWERSHELL_H3_F_R1 e
FIM_BLOCO_POWERSHELL_H3_F_R1. Excluir cercas, marcadores e qualquer texto externo;
incluir o LF final imediatamente anterior à cerca de fechamento. Não indentar,
normalizar, converter para CRLF, inserir BOM ou remover espaços do código.

Bloco: 20.362 bytes, 383 linhas, UTF-8 sem BOM, LF, incluindo LF final.
SHA-256 calculado, idêntico ao esperado:
`af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5`.

Esse hash comprova identidade dos bytes, não sintaxe, compatibilidade PS5.1,
funcionamento das APIs, proteção do destino ou segurança operacional.
Nenhuma consulta WMI, ACL, Windows ou leitura do JUnit foi realizada.
