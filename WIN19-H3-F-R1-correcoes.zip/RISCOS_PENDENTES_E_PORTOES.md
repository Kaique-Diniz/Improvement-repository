# H3-F-R1 — riscos pendentes e portões

24/11/2026. As quatro mudanças estão apenas materializadas como bytes para auditoria.
Não atribuir resolução de risco ou aprovação de runtime por correspondência de hash.

## Inventário H3-G preservado integralmente

Abaixo estão os nove registros R01–R09 e os quatro N01–N04, com todos os campos
substantivos da matriz H3-G preservados. IDs, classificações, severidades, causas,
limites e pendências não foram promovidos. Referências de linhas continuam sendo
as da fonte H3-F original; não são linhas renumeradas de H3-F-R1.

## H3G-R01 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** Inicializacao/saida
- **Localização na fonte H3-F original:** 3–16; 334–371
- **Evidência ou causa:** Inicializacao e serializacao final ficam fora do try principal.
- **Impacto:** Falha nesses limites pode impedir JSON sanitizado unico; nao foi demonstrado vazamento nem ocorrencia.
- **Tratamento proposto:** Exigir revisao do host e considerar envelope externo em escopo futuro; nao executar ou mudar ambiente agora.
- **Efeito e limites:** Nenhuma alteracao incluida no diff minimo; nao prometer captura absoluta de cancelamento/host.
- **Validação nativa pendente:** Comportamento real do host/erros permanece NAO_VERIFICADO.

## H3G-R02 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** WMI
- **Localização na fonte H3-F original:** 61–103
- **Evidência ou causa:** Timeout nao limita Connect nem garante tempo global; providers/auditoria podem gerar efeitos internos.
- **Impacto:** Duracao e ausencia absoluta de efeitos nao comprovadas pela leitura.
- **Tratamento proposto:** Documentar limites e interromper em falha observavel; sem processo invasivo ou repeticao automatica.
- **Efeito e limites:** Limitacao conhecida preservada; nao aumentar escopo.
- **Validação nativa pendente:** Disponibilidade, duracao e encerramento reais dependem de validacao propria.

## H3G-R03 — RISCO_POTENCIAL

- **Severidade:** ALTA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** V03/V09
- **Localização na fonte H3-F original:** 27–59; 190–223; 310–313
- **Evidência ou causa:** Caminhos/atributos e releituras nao fixam identidade fisica; aliases/SUBST e substituicao com mesmos atributos nao sao excluidos.
- **Impacto:** Possivel observacao de objeto diferente entre consultas; nao e prova de contorno ocorrido.
- **Tratamento proposto:** Manter limitacao e bloqueio de custodia; qualquer metodo com handles requer projeto/revisao propria.
- **Efeito e limites:** Sem pin, flags novas ou relaxamento de reparse nesta proposta.
- **Validação nativa pendente:** Corridas e aliases nao exercitados; nao declarados eliminados.

## H3G-R04 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** V02
- **Localização na fonte H3-F original:** 151–188
- **Evidência ou causa:** Juncao por indices entre provedores, provider Storage e classificacao de barramento dependem do ambiente; Fixed nao prova interno.
- **Impacto:** Metadados podem ser incompletos, virtuais ou ambiguos; codigo ja deixa resultado inconclusivo.
- **Tratamento proposto:** Conservar paradas e inconclusao; revisar evidencias fisicas em escopo posterior sem inferencia automatica.
- **Efeito e limites:** Sem trocar a regra para aprovar discos por barramento.
- **Validação nativa pendente:** Correspondencia de providers no alvo nao observada.

## H3G-R05 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** V04/V05
- **Localização na fonte H3-F original:** 225–244; 307–309
- **Evidência ou causa:** Heuristica de marcadores pode ter falsos positivos e nao descobre Git arbitrariamente danificado/externo; referencias historicas ausentes.
- **Impacto:** Separacao nao certificada; ausencia de marcadores nao aprova area.
- **Tratamento proposto:** Preservar INCONCLUSIVO e confronto privado posterior; nao executar Git ou varredura.
- **Efeito e limites:** Sem remover marcadores ou preencher V05 por presuncao.
- **Validação nativa pendente:** Nenhuma area real inspecionada.

## H3G-R06 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** V06
- **Localização na fonte H3-F original:** 246–272
- **Evidência ou causa:** OneDrive de processo e shares locais sao indicadores parciais; share administrativo incidente tambem impede.
- **Impacto:** Pode haver parada normal em maquinas com share administrativo e exposicao nao detectada por outros mecanismos.
- **Tratamento proposto:** Explicitar abrangencia e revisar politica privadamente; nao excluir shares administrativos do teste por conveniencia.
- **Efeito e limites:** Diff D04 so corrige metadado nulo; preserva politica de bloqueio.
- **Validação nativa pendente:** Sincronizacao e exposicao reais nao medidas.

## H3G-R07 — RISCO_POTENCIAL

- **Severidade:** ALTA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** V01/V07/V08
- **Localização na fonte H3-F original:** 119–127; 274–319
- **Evidência ou causa:** DACL/grupos do ancestral nao provam acesso efetivo, privilegios completos do token ou protecao do objeto futuro.
- **Impacto:** Nao permite homologar deposito, XML/parciais/registros ou DACL do produto.
- **Tratamento proposto:** Conservar V08 INCONCLUSIVO e DACL nula como impedimento; decisao e evidencia privadas posteriores.
- **Efeito e limites:** Sem testes entre contas, alteracao de token/ACL ou calculo de acesso efetivo improvisado.
- **Validação nativa pendente:** Efetividade e protecao continuam NAO_VERIFICADAS.

## H3G-R08 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** Privacidade/host
- **Localização na fonte H3-F original:** 131; catches; 324–332; 357–371
- **Evidência ou causa:** Read-Host pode exibir caminho; objetos, erros capturados e buffers podem permanecer em memoria ou captura externa.
- **Impacto:** JSON normal construido e sanitizado; nao garante privacidade do host ou apagamento forense.
- **Tratamento proposto:** Exigir sessao privada e revisao antes de compartilhar; nao limpar memoria/logs ou desabilitar auditoria para contornar.
- **Efeito e limites:** Sem persistencia automatica de detalhes nesta proposta.
- **Validação nativa pendente:** Nenhuma exposicao real foi provocada ou observada.

## H3G-R09 — RISCO_POTENCIAL

- **Severidade:** MEDIA
- **Evidência H3-G:** CONFERIDO_ESTATICAMENTE
- **Critérios:** Resolucao de comandos/host
- **Localização na fonte H3-F original:** 14; 66; 113; 131; 371
- **Evidência ou causa:** New-Object nao qualificado depende da sessao; nomes qualificados ainda podem causar carregamento automatico de modulo.
- **Impacto:** Ausencia de Import-Module nao garante ausencia de codigo de carregamento/efeitos no host.
- **Tratamento proposto:** Validar origem de host/modulos em etapa propria; nao instalar, reconfigurar ou executar nesta revisao.
- **Efeito e limites:** Sem alteracao persistente de autoload ou PSModulePath; nenhum carregamento feito pelo bloco nesta tarefa.
- **Validação nativa pendente:** Origem dos modulos do Windows do usuario nao inspecionada.

## H3G-N01 — NAO_VERIFICADO

- **Severidade:** ALTA
- **Evidência H3-G:** NAO_VERIFICADO
- **Critérios:** Sintaxe global
- **Localização na fonte H3-F original:** 1–371
- **Evidência ou causa:** Ambiente disponivel e Linux; nao ha evidencia autorizada de parser Windows PowerShell 5.1 isolado.
- **Impacto:** Nao se declara gramatica nativa valida nem ausencia de erros de parser.
- **Tratamento proposto:** Registrar PARSING_NATIVO_PS51=NAO_EXECUTADO; eventual parser nativo exige ambiente/escopo apropriados.
- **Efeito e limites:** Nao substituir por PowerShell 7 nem instalar ferramentas.
- **Validação nativa pendente:** VALIDADO_POR_PARSER: nenhum item nesta entrega.

## H3G-N02 — NAO_VERIFICADO

- **Severidade:** ALTA
- **Evidência H3-G:** NAO_VERIFICADO
- **Critérios:** Tipos/sobrecargas .NET
- **Localização na fonte H3-F original:** 27–76; 119–153; 276–286
- **Evidência ou causa:** Assinaturas possuem correspondencia documental; resolucao/carregamento/binding reais nao foram executados.
- **Impacto:** Presenca na documentacao nao prova funcionamento no alvo.
- **Tratamento proposto:** Revisao nativa separada do Framework/tipos/binder, sem invocar procedimento nesta etapa.
- **Efeito e limites:** Sem Add-Type ou importacao de dependencias.
- **Validação nativa pendente:** Nao ha incompatibilidade categorica PS51 comprovada nesta revisao.

## H3G-N03 — NAO_VERIFICADO

- **Severidade:** ALTA
- **Evidência H3-G:** NAO_VERIFICADO
- **Critérios:** Providers e propriedades WMI
- **Localização na fonte H3-F original:** 165–188; 258
- **Evidência ou causa:** Root\Microsoft\Windows\Storage e MSFT_Disk dependem da versao/provedor/acesso; MSFT_Disk documenta Windows 8/Server 2012 como minimo.
- **Impacto:** PS51 isoladamente nao garante disponibilidade e acesso das consultas.
- **Tratamento proposto:** Manter erro/nulo/ambiguidade como inconclusao; nao elevar ou instalar provider.
- **Efeito e limites:** Sem testes no computador do usuario.
- **Validação nativa pendente:** Nenhuma consulta WMI executada.

## H3G-N04 — NAO_VERIFICADO

- **Severidade:** MEDIA
- **Evidência H3-G:** NAO_VERIFICADO
- **Critérios:** Arrays, escopo e JSON em runtime
- **Localização na fonte H3-F original:** 4–24; 61–103; 357–371
- **Evidência ou causa:** Referencia mutavel e arrays possuem estrutura coerente no texto; binding, enumeracao e JSON nao foram interpretados em PS51.
- **Impacto:** Nao se certifica resultado real a partir da leitura.
- **Tratamento proposto:** Conferir primeiro parser sob escopo proprio e depois decidir validacao adequada sem execucao operacional implicita.
- **Efeito e limites:** Nao simular arrays, callbacks ou falhas de APIs nesta tarefa.
- **Validação nativa pendente:** Sem teste funcional ou simulacao.

## Estados e decisões preservados

H3-F-R1=MATERIALIZADO_AGUARDANDO_AUDITORIA;
H3-F original=PRESERVADO;
H3-G=ACEITA_REVISAO_ESTATICA_COM_RESSALVAS;
PARSING_NATIVO_PS51=NAO_EXECUTADO;
execução do procedimento Windows=NAO_AUTORIZADA;
verificação real do destino=NAO_EXECUTADA;
proteção efetiva=NAO_VERIFICADA;
H3-C/H3-S/H4=NAO_AUTORIZADAS;
assistência remota=ADIADA_NAO_AUTORIZADA;
vínculos históricos=PROVISORIO_SEM_FONTE;
WIN-01..WIN-19=NÃO_VALIDADO; DACL=NÃO_VALIDADO;
runner C=NÃO_IMPLEMENTADO; Portões C/D/E=BLOQUEADOS;
conversões reais=BLOQUEADAS; prontidao_para_executar=false.

Políticas locais de custódia, coadministração específica e retenção H4 com máximo
inicial 180 dias após cópia aceita, revisões 60/120/180/antecipada, prorrogação
expressa e nenhuma exclusão automática permanecem. Retenção não autoriza a operação
nem define validade do termo de cópia. Caminho, proteção e acessos reais não foram
inspecionados; nenhum dado privado foi solicitado nesta conversa.

Não declarar que as quatro correções resolvem sintaxe/compatibilidade PS5.1,
providers, efeitos do host, identidade física, corridas, proteção do objeto futuro,
acesso de coadministradores, exposição/sincronização ou segurança operacional.
V05/V08 continuam inconclusivos por desenho e não podem ser preenchidos por suposição.

Próximo passo possível: auditoria dos bytes H3-F-R1. Depois, somente com autorização
separada, análise sintática nativa sobre o texto autenticado, sem executar a função
principal. Não dot-source ou colar para carregar funções: a chamada final foi
preservada. Nenhuma criação de custódia, cópia do XML ou H3-C decorre desta entrega.
Parar para revisão; sem testes Windows, alteração de segurança, Git, publicação,
commit, push, merge ou ZIP.
