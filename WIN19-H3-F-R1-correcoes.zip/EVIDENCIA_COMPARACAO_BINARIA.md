# H3-F-R1 — evidência de comparação textual e binária offline

24/11/2026. Evidência de identidade e transformação de bytes, não ensaio do
programa. Nenhum código PowerShell foi interpretado ou executado.

## Identidades conferidas

| Objeto | Bytes | Linhas LF quando aplicável | SHA-256 |
|---|---:|---:|---|
| Markdown H3-F original | 21778 | documento, não bloco | 286894f9c5fbdb37e512407cd830c8c20bf08bc49b7b8e1cb07d61d8b3f340c1 |
| Bloco original extraído | 19771 | 371 | 8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4 |
| Markdown H3-G da proposta | 6430 | documento, não diff | bf6eeeba225628cc5607c608c018ced9c9531526c8c59ddfed3594ff3883249a |
| Diff autenticado e .patch novo | 3209 | 62 | 1cd6735875e46a11ad5cbcd291e6a5e0030e321a48472c27a01a048c4cbad07a |
| Bloco revisado efetivamente materializado | 20362 | 383 | af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5 |
| Reversão textual do revisado | 19771 | 371 | 8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4 |

Codificação do código e diff: UTF-8 estrito sem BOM; nenhum CR; LF final preservado.
O conteúdo do bloco é diferente do documento Markdown inteiro; não comparar os
hashes desses objetos como se fossem a mesma entrada. Hashes/tamanhos dos seis
arquivos finais estão no manifesto, sem autorreferência.

## Hunks e contextos

| Cabeçalho exato | Correção | Conferência |
|---|---|---|
| @@ -41,9 +41,13 @@ | D03 — guarda do ancestral | Contexto e remoções coincidem literalmente |
| @@ -85,9 +89,12 @@ | D02 — descarte WMI | Contexto e remoções coincidem literalmente |
| @@ -257,10 +264,12 @@ | D04 — share de disco | Contexto e remoções coincidem literalmente |
| @@ -306,12 +315,15 @@ | D01 — revalidação V09 | Contexto e remoções coincidem literalmente |

Exatamente quatro hunks; 16 linhas adicionadas, 4 removidas, saldo +12 linhas.
Tamanho revisado − original: 20.362 − 19.771 = 591 bytes.
Nenhuma linha foi alterada fora dos quatro hunks. Preservados comentários,
espaços, quebras, funções, chamadas, constantes e a chamada final fora desse escopo.

## Método reprodutível de conferência, sem programa PowerShell

1. Autenticar documento H3-F e extrair bytes entre seus marcadores/cercas, excluindo
   delimitadores e incluindo LF final; validar tamanho, linhas, UTF-8 e hash.
2. Autenticar documento H3-G e extrair bytes entre cercas diff; validar identidade.
3. Ler somente o formato unified diff: quatro cabeçalhos, coordenadas e prefixos
   de contexto/remoção/adição. Conferir cada linha de contexto e remoção em sua
   posição literal, sem adaptação, busca aproximada ou offsets alternativos.
4. Construir novo texto em memória com os trechos inalterados e as quatro mudanças.
   Conferir também as coordenadas e contagens do lado resultante.
5. Exigir tamanho 20.362, linhas 383, UTF-8 sem BOM/LF e hash esperado idêntico.
6. Regenerar diff textual com quatro linhas de contexto e os mesmos rótulos
   virtuais. O resultado foi exatamente igual aos 3.209 bytes autenticados.
7. Inverter adições/remoções e coordenadas dos mesmos quatro hunks sobre o revisado.
   O resultado foi comparado byte a byte com a fonte, com igualdade integral.
8. Após gravar apenas o Markdown novo, extrair novamente seu bloco pelos marcadores
   R1 e conferir igualdade integral com os bytes construídos em memória.

Ferramentas: Python -I -B, biblioteca padrão pathlib/hashlib/re/csv/difflib e
comparação de bytes, sem pacote instalado. Ler a gramática de diff não é parsing
PowerShell nem validação de sintaxe. Nenhum patch foi aplicado ao arquivo original
ou a script preexistente; o .patch é documental.

## Resultados e limites

Fonte autenticada; diff autenticado; quatro contextos/remoções correspondentes;
resultado idêntico ao esperado; diff regenerado idêntico; reversão igual ao original;
bloco reextraído do Markdown igual; chamada final preservada.
Esses resultados não demonstram que o código seja sintaticamente válido, que o
throw funcione em Windows, que WMI encerre recursos ou que DACL/proteção seja eficaz.
PARSING_NATIVO_PS51=NAO_EXECUTADO. Nenhum teste funcional ou simulação operacional.
