# WIN19-H3-F-R1 — índice, inventário e proveniência

24/11/2026 — America/Sao_Paulo.
Pasta nova documental: /workspace/work/WIN19-H3-F-R1-CORRECOES-20261124.
Externa ao Git, às entregas anteriores, a R1-FIX e às custódias. Não é diretório
Windows ou depósito do JUnit.

## Sete arquivos exclusivos

1. [COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md](COMANDO_WINDOWS_VERIFICACAO_DESTINO_R1.md)
   — único bloco completo revisado, 20.362 bytes/383 linhas; não validado/executado.
2. [DIFF_H3_F_H3_F_R1.patch](DIFF_H3_F_H3_F_R1.patch) — cópia exata dos 3.209 bytes
   de diff autenticados H3-G, finalidade documental, sem aplicação em fonte anterior.
3. [RELATORIO_H3_F_R1_MATERIALIZACAO.md](RELATORIO_H3_F_R1_MATERIALIZACAO.md)
   — autorização, fontes, quatro mudanças e resultado materializado.
4. [EVIDENCIA_COMPARACAO_BINARIA.md](EVIDENCIA_COMPARACAO_BINARIA.md)
   — contextos, identidades, igualdade textual/binária e reversibilidade.
5. [RISCOS_PENDENTES_E_PORTOES.md](RISCOS_PENDENTES_E_PORTOES.md)
   — todos os campos dos nove riscos/quatro itens não verificados, sem promoção.
6. INDICE_ENTREGA_H3_F_R1.md — este inventário e proveniência.
7. [MANIFESTO_SHA256_H3_F_R1](MANIFESTO_SHA256_H3_F_R1) — tamanho/hash dos seis
   anteriores; não se autorreferencia; hash informado na conversa.

## Instrução e parecer obrigatórios

Texto colado.txt: instrução específica H3-F-R1 de 24/11/2026, 10.550 bytes,
SHA-256 5dfad987e01bc8f7bef5ed83675a28b6ad0fd09b0584000cb98d37319c4eba47.
PARECER_INDEPENDENTE_WIN19_H3_G_2026-11-24.md: 8.377 bytes,
SHA-256 3f1cb237aff44e25f9119bccd25ae491e14a6078eaebab3bcfc2e235858a85a1.
Lidos como documentos; não executados nem copiados para esta pasta. O parecer
aceita H3-G como revisão estática com ressalvas; a instrução posterior autoriza
somente esta materialização, não parsing, funcionamento ou custódia.

## Origem exclusiva dos bytes

Documento H3-F COMANDO_WINDOWS_VERIFICACAO_DESTINO.md: 21.778 bytes, SHA-256
286894f9c5fbdb37e512407cd830c8c20bf08bc49b7b8e1cb07d61d8b3f340c1.
Bloco original extraído entre marcadores/cercas, com LF final e sem delimitadores:
19.771 bytes/371 linhas; SHA-256
8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4.
Documento H3-G PROPOSTAS_CORRECAO_MINIMA.md: 6.430 bytes, SHA-256
bf6eeeba225628cc5607c608c018ced9c9531526c8c59ddfed3594ff3883249a.
Diff entre cercas diff, incluindo LF final: 3.209 bytes, SHA-256
1cd6735875e46a11ad5cbcd291e6a5e0030e321a48472c27a01a048c4cbad07a.
Nenhum código foi reconstruído de mensagens/parecer ou adaptado para obter um hash.

| Outras fontes H3-G obrigatórias conferidas | Bytes | SHA-256 |
|---|---:|---|
| MATRIZ_DEFEITOS_E_RISCOS.csv | 9022 | fe98a1a26954f18a118b5c5a0d62f907b80f831d6af84800f61213fb25af9c0a |
| DECISAO_E_PROXIMOS_PORTOES.md | 2920 | b42387eedf1e38a7256b1232649038b388c219bc6fdd1fc45f0c969a3904d11d |

## Identidade materializada

Bloco H3-F-R1: 20.362 bytes, 383 linhas, UTF-8 sem BOM, somente LF e LF final.
SHA-256 calculado igual ao esperado:
af798e95c821499d5cf0f6b8d4f08537ed4709b32ddccdfc928f463caaec26b5.
A extração precisa pelos novos marcadores está no Markdown do comando. Comparação
direta dos bytes reextraídos confirmou igualdade ao resultado construído.
Quatro hunks e respectivos contextos conferidos; diff regenerado idêntico ao
patch de origem; inversão devolve a fonte integralmente. Chamada final preservada.

## Preservação e ferramentas

Manifesto H3-F preservado, SHA-256
52edc8442c7ee86824e45895353511f390eade151a3e76cd038af1b2246a9873.
Manifesto H3-G preservado, SHA-256
baa58c4986e16b57ab9d83197b856033ab9ce7598e8003351f93dea964ad9598.
Todos os documentos cobertos e os próprios manifestos foram conferidos antes/depois.
Pacote H3-F: 25.645 bytes, SHA-256
d1c8379c32e9b32667a37714e596b633944b025c7624dd771a4ab24f3f769fbd.
Pacote H3-G: 25.418 bytes, SHA-256
b1ab5f1d86057a97a03b82555cd8e24b35d1614a6f73d828e409a74cf1cef3d6.
Ambos preservados, sem substituição ou publicação nova.

Python -I -B e biblioteca padrão foram usados para leitura/comparação de bytes,
extração documental, coordenadas/contextos de unified diff, difflib e hashes.
Isso não constitui parsing da linguagem PowerShell, interpretação ou simulação
do programa. Sem ferramentas/dependências instaladas, .ps1, ZIP, executável,
runner, XML, cópia de candidata, Windows, WMI, ACL, privilégio, política, Git,
commit/push/merge/publicação. Só os sete arquivos pedidos foram produzidos.

H3-F-R1 MATERIALIZADO_AGUARDANDO_AUDITORIA; parsing nativo NAO_EXECUTADO;
execução NAO_AUTORIZADA e demais bloqueios conforme RISCOS_PENDENTES_E_PORTOES.md.
Parar para auditoria independente, sem iniciar a análise sintática ou H3-C.
