# H3-M — alternativas de finalidade A e B, sem escolha

26/11/2026. FINALIDADE_FUTURA=NAO_DECIDIDA. As alternativas abaixo são propostas
para decisão privada legítima; não representam autorização ou aceite de risco.
Permanece METODO_REQUER_REVISAO_ADICIONAL_ANTES_DE_OBSERVACAO.

## Comparação de projeto

| Dimensão | Alternativa A — observação local limitada | Alternativa B — garantias reforçadas antes de observar |
|---|---|---|
| Finalidade | Obter indicadores/metadados nominais úteis à avaliação posterior | Exigir garantias definidas de identidade, concorrência, exclusividade, acesso, separação e recepção antes da observação |
| Benefício | Evidenciar indícios, impedimentos, falhas e lacunas sem apresentá-los como certificação | Reduzir incertezas relevantes quando as garantias forem indispensáveis à finalidade escolhida |
| Informação possível | Volume declarado, atributos/reparse observados, sinais Git/nuvem/share, segurança ancestral, presença/ausência pontual e inconclusões | Evidências pertinentes às garantias exigidas, somente após revisão/método/validação próprios; hoje não demonstradas |
| Garantia demonstrável hoje | Apenas identidade e consistência documental das fontes e relato sintático R1, não observação real de ambiente | Nenhuma garantia material reforçada foi comprovada nesta preparação |
| Limitações | Consultas não atômicas, sem identidade imutável/reserva futura; dependências N02–N04 e host pendentes | Viabilidade e método dependem de objeto/identidade/operação; pode exigir desenvolvimento e evidência nativa próprios |
| Não certifica | Identidade estável, exclusividade futura, ausência de corrida, separação completa, ausência absoluta de exposição, acesso efetivo, proteção futura ou aptidão de custódia | Escolher a finalidade não demonstra as garantias nem cria autorização de custódia; proteção de alvo futuro não pode ser inventada |
| Dependências | Finalidade/garantias, legitimidade, escopo privado, método revisado, contrato de resultados, evidências e autorização específica | As mesmas dependências e possível revisão de projeto, componentes adicionais e validação nativa especificamente autorizados |
| Riscos | R01–R09 permanecem; A não aceita automaticamente R03/R07 | R01–R09 permanecem até evidência/decisão próprias; desenho novo não é prova de solução |
| Decisões | L-D01/L-D02 e demais decisões pertinentes, sem preencher valores | Mesmos 12 temas, com motivação de garantias indispensáveis e viabilidade |
| Próximos portões | Revisão adicional de método/contrato e evidências; só depois discutir autorização | Revisão de projeto/viabilidade; eventual desenvolvimento separado só se autorizado; auditoria e validação próprias posteriormente |

## Nomenclatura e limites que evitam confusão

A/B são alternativas futuras da H3-M. Não confundir B desta etapa com o Nível B
da H3-L (certificação do destino para custódia). A alternativa B pode impor
precondições reforçadas à observação, mas não concede certificação ou termo H3-C.
A alternativa A também não altera a política de áreas proibidas, legitimidade,
proteção e privacidade: limitar a afirmação não torna segura uma leitura indevida.

Uma futura evidência A só poderia relatar o que APIs retornaram para nomes numa
janela observada, sem assegurar os mesmos objetos ao longo das consultas. Não é
snapshot atômico nem reserva. Podem persistir V02/V04/V05/V06/V08 inconclusivos.
Não preencher lacunas com parsing, cleanup, outras suítes ou hashes de documentos.

## Consequências para R03 e R07

- R03: atributos pontuais são indicadores. Identidade física vinculada e controle
  de substituição/exclusividade são garantias distintas. Se indispensáveis antes
  da observação, exigem revisão de método; handles/pinning/APIs não são implementados.
- R07: metadados da DACL ancestral são indicadores. Acesso efetivo por identidade/
  operação e proteção do diretório futuro são questões distintas. Ausência de
  concessão ampla não prova proteção; não criar objeto ou testar outra conta agora.

Não pressupor B indispensável para todo diagnóstico. Tampouco usar A para afastar
uma garantia que o custodiante/autoridade legítima considere indispensável ou para
ignorar obrigação institucional. Exigência inviável antes de observar implica
revisão/adiamento, não autorização para criação ou mudança de segurança.

## Estado e parada

Nenhuma alternativa escolhida. As classificações da matriz são hipóteses propostas
sob cada finalidade, não decisões aprovadas. Decidir apenas quando houver manifestação
expressa em registro privado legítimo; não solicitar seus valores no chat.
