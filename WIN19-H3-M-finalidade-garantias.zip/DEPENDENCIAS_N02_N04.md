# H3-M — dependências técnicas preservadas

26/11/2026. H3G-N02=NAO_VERIFICADO; H3G-N03=NAO_VERIFICADO;
H3G-N04=NAO_VERIFICADO. N02/N03 ALTA; N04 MEDIA.

Fonte: MATRIZ_RUNTIME_N02_N04.csv H3-L, 6.919 bytes, SHA-256
`21548eace5babad14d47f1fd6d146cd775dd400d7ae6e0994842fe348eb4b9f9`.
Abaixo, os 15 IDs e todos os 13 campos de cada registro são preservados literalmente
como conteúdo documental (6 N02, 4 N03, 5 N04); análise por grupo não reclassifica itens.
Não são casos de teste autorizados, runner, exemplos, mocks ou simulações.

N01 continua apenas sintaxe R1 conforme evidência textual do usuário. Não comprova
presença de APIs, providers, token, fluxo de falhas, descarte ou JSON real. D01–D04
permanecem mudanças textuais sem aprovação funcional. Inventários/documentos já
legítimos podem ser examinados sem executar H3-F-R1; novas observações nativas,
mesmo sem o bloco, precisam revisão e autorização separadas.

## H3G-N02 — Tipos, métodos e APIs .NET

Documentação: assinaturas/tipos/contratos no texto, sem binder real. As finalidades A e B dependem das leituras que usam essas APIs; garantias G01–G10 pertinentes seriam afetadas por tipo/sobrecarga/resolução incompatíveis. Revisão de projeto se houver incompatibilidade ou componente adicional; não constatada como defeito nativo aqui. Validação nativa separada pode ser necessária, sob autorização específica de ambiente/objeto/limites, sem executar H3-F-R1 por consequência.

### N02-01 — registro H3-L preservado

- **id:** N02-01
- **pendencia:** H3G-N02
- **severidade_historica:** ALTA
- **linhas_r1:** B072–080
- **dependencias:** System.Management: ConnectionOptions/ManagementScope/EnumerationOptions/ObjectQuery/ManagementObjectSearcher
- **questao_aberta:** Presença, construtores e resolução de assemblies/tipos
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Inventário/documentação legítimos podem ser examinados sem H3-F-R1
- **evidencia_dependente_de_autorizacao_propria:** Binding real exige escopo nativo próprio autorizado; não executado
- **execucao_atual:** NAO_EXECUTADA

### N02-02 — registro H3-L preservado

- **id:** N02-02
- **pendencia:** H3G-N02
- **severidade_historica:** ALTA
- **linhas_r1:** B027–039;B145–160
- **dependencias:** File.GetAttributes, Path.GetFullPath/Combine, DriveInfo
- **questao_aberta:** Exceções/HResult, sobrecargas e comportamento no ambiente
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Contratos públicos e registros legítimos sem chamar o bloco
- **evidencia_dependente_de_autorizacao_propria:** Comportamento do filesystem exige validação nativa separada
- **execucao_atual:** NAO_EXECUTADA

### N02-03 — registro H3-L preservado

- **id:** N02-03
- **pendencia:** H3G-N02
- **severidade_historica:** ALTA
- **linhas_r1:** B058–064;B145–156
- **dependencias:** TrimEnd/Split com char; Equals/StartsWith OrdinalIgnoreCase; casts uint32/int
- **questao_aberta:** Binding char[]/string e conversões/nulos
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Análise de assinaturas sem execução
- **evidencia_dependente_de_autorizacao_propria:** Binder/casts reais precisam autorização nativa específica
- **execucao_atual:** NAO_EXECUTADA

### N02-04 — registro H3-L preservado

- **id:** N02-04
- **pendencia:** H3G-N02
- **severidade_historica:** ALTA
- **linhas_r1:** B126–134
- **dependencias:** WindowsIdentity/WindowsPrincipal/GetCurrent/IsInRole/Dispose
- **questao_aberta:** Resolução .NET Framework e contexto/token observável
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Documentação e legitimidade do ambiente em registro privado
- **evidencia_dependente_de_autorizacao_propria:** Observação real do contexto/fechamento só em escopo autorizado
- **execucao_atual:** NAO_EXECUTADA

### N02-05 — registro H3-L preservado

- **id:** N02-05
- **pendencia:** H3G-N02
- **severidade_historica:** ALTA
- **linhas_r1:** B285–309
- **dependencias:** Directory.GetAccessControl, GetOwner/GetGroup/GetAccessRules, descritor binário, RawSecurityDescriptor
- **questao_aberta:** Sobrecargas Access|Owner|Group, enumerações e propriedades
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Confronto documental sem ler ACL real
- **evidencia_dependente_de_autorizacao_propria:** Leitura nativa e qualquer efetividade requerem autorizações distintas; não teste entre contas automático
- **execucao_atual:** NAO_EXECUTADA

### N02-06 — registro H3-L preservado

- **id:** N02-06
- **pendencia:** H3G-N02
- **severidade_historica:** ALTA
- **linhas_r1:** B081–109;B336–338
- **dependencias:** Get/MoveNext/Current/Dispose e WindowsIdentity.Dispose
- **questao_aberta:** Existência/dispatch e falhas de encerramento
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Análise dos contratos e do fluxo textual
- **evidencia_dependente_de_autorizacao_propria:** Fechamento/falhas requerem evidência nativa própria, sem invocar H3-F-R1 por consequência
- **execucao_atual:** NAO_EXECUTADA

## H3G-N03 — Providers WMI

Documentação: namespaces/classes/propriedades e tratamento de falhas previstos. A depende de indicadores de volume/share e B de evidência apropriada ainda mais forte (G01/G06/G09/G10). Disponibilidade, permissão, resposta, duração e descarte continuam não verificados. Revisar projeto se o método não puder satisfazer garantias ou encerramento; não instalar provider/elevar. Consulta ou ensaio exige autorização própria com efeitos/tempo/falhas, não concedida por esta matriz.

### N03-01 — registro H3-L preservado

- **id:** N03-01
- **pendencia:** H3G-N03
- **severidade_historica:** ALTA
- **linhas_r1:** B172–177
- **dependencias:** root\cimv2; Win32_LogicalDiskToPartition; DiskIndex
- **questao_aberta:** Disponibilidade/associação, zero/um/vários/nulo e permissões
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Informação legítima de versão/provider pode existir sem execução do bloco
- **evidencia_dependente_de_autorizacao_propria:** Consultar associação é operação nativa própria e não autorizada aqui
- **execucao_atual:** NAO_EXECUTADA

### N03-02 — registro H3-L preservado

- **id:** N03-02
- **pendencia:** H3G-N03
- **severidade_historica:** ALTA
- **linhas_r1:** B178–195
- **dependencias:** root\cimv2 Win32_DiskDrive Index/InterfaceType/MediaType; root\Microsoft\Windows\Storage MSFT_Disk Number/BusType/IsOffline
- **questao_aberta:** Mínimo documental Windows 8/Server 2012 não prova provider/acesso; nulos/offline/índices/bus
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Documentação e inventário legítimo sem consulta
- **evidencia_dependente_de_autorizacao_propria:** Correspondência real e natureza física exigem evidência separada; Fixed não basta
- **execucao_atual:** NAO_EXECUTADA

### N03-03 — registro H3-L preservado

- **id:** N03-03
- **pendencia:** H3G-N03
- **severidade_historica:** ALTA
- **linhas_r1:** B265–281
- **dependencias:** root\cimv2; Win32_Share; Path/Type inclusive administrativos
- **questao_aberta:** Metadados parciais/nulos, permissão, exposição; D04 não executada
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Política/inventário privado já legítimos sem consulta
- **evidencia_dependente_de_autorizacao_propria:** WMI real requer autorização própria; sem remover/isentar share para obter aprovação
- **execucao_atual:** NAO_EXECUTADA

### N03-04 — registro H3-L preservado

- **id:** N03-04
- **pendencia:** H3G-N03
- **severidade_historica:** ALTA
- **linhas_r1:** B065–110
- **dependencias:** Escopos locais e opções Timeout/EnablePrivileges/Rewindable, limite de registros
- **questao_aberta:** Conexão implícita/provider/COM/RPC/MoveNext/Dispose; prazo global não garantido
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Revisão de contrato e requisitos de duração sem executar
- **evidencia_dependente_de_autorizacao_propria:** Duração/efeitos/fechamento nativos exigem método próprio; não elevar ou instalar
- **execucao_atual:** NAO_EXECUTADA

## H3G-N04 — Escopo, coleções, exceções e serialização

Documentação: fluxo, estados e objeto normal definidos; comportamento real não foi simulado. Ambas finalidades dependem de recepção coerente/vinculável (G10) e demais conclusões. Escopo/unrolling/catch/finally/serialização seguem pendentes. Contrato e eventual mecanismo adicional exigem revisão de projeto, adoção expressa e autorização de implementação/validação próprias; nenhuma sequência automática de testes foi preparada.

### N04-01 — registro H3-L preservado

- **id:** N04-01
- **pendencia:** H3G-N04
- **severidade_historica:** MEDIA
- **linhas_r1:** B004–025
- **dependencias:** Estados ordenados e objeto flow compartilhados; helpers aninhados
- **questao_aberta:** Escopo e propagação das mutações
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Inspeção textual de variáveis sem mocks ou exemplos executados
- **evidencia_dependente_de_autorizacao_propria:** Semântica real exige validação nativa própria, ainda não autorizada
- **execucao_atual:** NAO_EXECUTADA

### N04-02 — registro H3-L preservado

- **id:** N04-02
- **pendencia:** H3G-N04
- **severidade_historica:** MEDIA
- **linhas_r1:** B070–110;B173–180
- **dependencias:** List[object], ToArray e @(), enumeração
- **questao_aberta:** Cardinalidade, unrolling, limite e dados em memória
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Conferência textual da intenção
- **evidencia_dependente_de_autorizacao_propria:** Zero/um/vários e comportamento de binder não foram simulados; autorização própria futura
- **execucao_atual:** NAO_EXECUTADA

### N04-03 — registro H3-L preservado

- **id:** N04-03
- **pendencia:** H3G-N04
- **severidade_historica:** MEDIA
- **linhas_r1:** B022–025;B093–107;B332–345
- **dependencias:** Stop-H3, throw/catch/finally e encerramento
- **questao_aberta:** Parada controlada, exceção sobreposta e atribuição V03/V09
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Presença textual D01–D04 conhecida sem execução
- **evidencia_dependente_de_autorizacao_propria:** Eficácia de falhas/fechamento precisa validação separada; sem convertê-la em teste autorizado agora
- **execucao_atual:** NAO_EXECUTADA

### N04-04 — registro H3-L preservado

- **id:** N04-04
- **pendencia:** H3G-N04
- **severidade_historica:** MEDIA
- **linhas_r1:** B319–368
- **dependencias:** Revalidação e consolidação acumulada de V01–V10
- **questao_aberta:** Coerência real de estados/códigos e incompletude
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Grafo nominal/estático sem simular execuções
- **evidencia_dependente_de_autorizacao_propria:** Confronto em execução precisa escopo próprio e contrato externo
- **execucao_atual:** NAO_EXECUTADA

### N04-05 — registro H3-L preservado

- **id:** N04-05
- **pendencia:** H3G-N04
- **severidade_historica:** MEDIA
- **linhas_r1:** B369–383
- **dependencias:** Objeto de 12 propriedades e ConvertTo-Json Depth 8
- **questao_aberta:** Saída única/completa, tipos, codificação de captura e falhas fora do try
- **conferencia_documental:** CONFERIDO_ESTATICAMENTE
- **sintaxe_do_bloco:** SINTAXE_VALIDADA_PS51_CONFORME_EVIDENCIA_APENAS_R1
- **comportamento:** COMPORTAMENTO_NATIVO_NAO_VERIFICADO
- **estado_pendencia:** NAO_VERIFICADO
- **evidencia_possivel_sem_executar_h3_f_r1:** Contrato textual pode ser revisado sem H3-F-R1
- **evidencia_dependente_de_autorizacao_propria:** Serialização/contexto real e vínculo com rodada precisam evidência operacional específica
- **execucao_atual:** NAO_EXECUTADA

