# H3-M — confronto do checklist H3-K, sem reclassificação

26/11/2026. Fonte CHECKLIST_PRECONDICOES_INSPECAO.md, 8.027 bytes, SHA-256
`9aa2bb55d54033e3a0fcf579843620f843b9d5ed02ffbee087df085307bce756`.

As seis colunas históricas de cada um dos 30 IDs são reproduzidas abaixo sem
alterar os textos; a última coluna apenas relaciona as decisões H3-L existentes.
Os vínculos correspondem exatamente à MATRIZ_DECISOES_CUSTODIANTE.csv H3-L,
6.836 bytes, SHA-256 b38bb7fd25c78e50591fbb2605b163c5df7545ef585a9e122b9b281a4ebad67e.

| ID histórico | Grupo | Condição | Situação documental | Base/necessidade | Limite e decisão | Decisões relacionadas |
|---|---|---|---|---|---|---|
| A01 | Ambiente | Escopo Windows local legítimo definido | DOCUMENTADA | Política H3-E e instrução H3-K | Define a exigência, não comprova legitimidade da máquina; não libera inspeção | L-D01 |
| A02 | Ambiente | Legitimidade e autorização do ambiente específico | PENDENTE_DE_EVIDENCIA | Registro privado legítimo necessário | Não presumir a partir do operador H2, do nome do perfil ou do sucesso de parsing | L-D03 |
| A03 | Ambiente | Identidade exata do bloco R1 e fontes | DOCUMENTADA | 20.362 bytes/383 LF e SHA-256 conferidos | Válido para cópia documental local; futura cópia usada exige conferência própria | L-D10 |
| A04 | Ambiente | Evidência de sintaxe PS5.1 | DOCUMENTADA | Segunda tentativa informada pelo usuário, zero erros; ED-01 sanada | Não comprova runtime, host atual ou mesmos bytes do auxiliar | L-D10 |
| A05 | Ambiente | Sessão real PS5.1 Desktop, local e sem elevação | PENDENTE_DE_EVIDENCIA | Contexto real futuro não inspecionado | V01 observa indicadores parciais; não alterar privilégios para satisfazer | L-D03 |
| A06 | Ambiente | Origem do host, módulos, .NET e resolução de comandos | PENDENTE_DE_EVIDENCIA | R09/N02; nenhuma inspeção do host | Não instalar nem mudar perfis/PSModulePath/políticas | L-D03 |
| A07 | Ambiente | Providers WMI, acesso, duração e encerramento | PENDENTE_DE_EVIDENCIA | R02/N03; nenhuma consulta | Evidência separada, limitada e autorizada; não extrapolar PS5.1 | L-D03 |
| A08 | Ambiente | Assistência remota ou compartilhamento supervisionado | NAO_APLICAVEL_COM_JUSTIFICATIVA | ADIADA_NAO_AUTORIZADA na política vigente | Não participa da eventual inspeção prevista; ausência real de remoto ainda deve ser comprovada no ambiente | L-D03 |
| D01 | Destino | Requisito de diretório novo/exclusivo e fora de áreas proibidas | DOCUMENTADA | Política H3-E | É regra de escolha, não local escolhido/existente/aprovado | L-D07 |
| D02 | Destino | Proposta privada do caminho e aprovação pertinente | PENDENTE_DE_DECISAO | Custodiante; nenhum caminho solicitado no chat | Sem criação prévia presumida; caminho permanece privado | L-D07 |
| D03 | Destino | Volume físico interno local | PENDENTE_DE_EVIDENCIA | R04/V02; Fixed não basta | Não inferir natureza por letra, barramento ou nome | L-D07 |
| D04 | Destino | Referências de Git/worktrees, R1-FIX, C5–C8, custódias e Portão B | PENDENTE_DE_EVIDENCIA | Inventário privado legítimo não fornecido | V04/V05 continuam limitados; sem varredura ou nomes por semelhança | L-D06 |
| D05 | Destino | Separação de sincronização e compartilhamentos | PENDENTE_DE_EVIDENCIA | R06/V06 | Sem isentar shares administrativos ou alterar serviços; ausência de indicador não basta | L-D08 |
| D06 | Destino | Identidade física e concorrência/exclusividade | PENDENTE_DE_DECISAO | R03/V03/V09; método sem pin | Decidir finalidade/garantia exigida e necessidade de revisão de projeto, sem aceitar risco por silêncio | L-D02 |
| D07 | Destino | Proteção efetiva e acesso por papel/operação | PENDENTE_DE_EVIDENCIA | R07/V07/V08 | Objeto futuro não existe; não criar para fechar checklist; bloqueante da custódia, sem tratar leitura de ancestral como aprovação | L-D02 |
| C01 | Custódia | Usuário como custodiante principal em política | DOCUMENTADA | H3-E | Papel definido; não autentica nominalmente identidade ou legitimidade | L-D04 |
| C02 | Custódia | Identidade, legitimidade, deveres e substituição | PENDENTE_DE_EVIDENCIA | Registro privado legítimo | Sem nome/SID/conta em documentos compartilháveis | L-D04 |
| C03 | Custódia | Coadministradores específicos e limites | PENDENTE_DE_DECISAO | Autorização específica e registro privado | Sem acesso/participação/movimentação/exclusão presumidos | L-D05 |
| C04 | Custódia | Compatibilidade institucional e confidencialidade | PENDENTE_DE_DECISAO | Responsável legítimo conforme obrigações aplicáveis | Não presumir inexistência de obrigação; governança H3-I/H3-J permanece separada | L-D09 |
| C05 | Custódia | Responsáveis por evidências, revisão e eventual descarte | PENDENTE_DE_DECISAO | Designação privada | Não criar agenda automática ou preencher eventos futuros | L-D04 |
| R01 | Retenção | Limite inicial até 180 dias vinculado à H4 | DOCUMENTADA | Política H3-E | Contagem só após futura cópia fiel aceita e verificada; não começa agora | L-D04 |
| R02 | Retenção | Revisões 60/120/180 e antecipada se H4 terminar | DOCUMENTADA | Política H3-E | Nenhuma data concreta/agenda/revisão executada; não autoriza H4 | L-D04 |
| R03 | Retenção | Prorrogação expressa e nenhuma exclusão automática | DOCUMENTADA | Política H3-E | Descarte/movimentação exige aprovação específica; preservar origem | L-D04 |
| R04 | Retenção | Marco real, responsáveis e registros privados | PENDENTE_DE_DECISAO | Futuro evento de cópia aceita ainda inexistente | Sem inventar data; não confundir prazo de retenção com validade da autorização | L-D04 |
| O01 | Operação | Método técnico, finalidade e garantias revisados | PENDENTE_DE_DECISAO | R01/R03/R07 e N02–N04 | Decisão prévia sobre inspeção limitada versus certificação; nenhum script/runner novo | L-D01, L-D02 |
| O02 | Operação | Recepção de evidência, prazo e tratamento de falhas | PENDENTE_DE_DECISAO | R01/R02/R08/N04 | Saída ausente ou encerramento incerto bloqueiam; sem repetição automática/limpeza forense | L-D10 |
| O03 | Operação | Privacidade do host e destinatários legítimos | PENDENTE_DE_EVIDENCIA | R08/R09 | Sem capturas/transcrições não autorizadas e sem desabilitar auditoria | L-D08 |
| O04 | Operação | Autorização futura limitada de inspeção | PENDENTE_DE_DECISAO | Só depois da auditoria/revisão e precondições pertinentes | Escopo, finalidade, identidade do método, operador legítimo, início/fim/expiração e interrupção expressos | L-D01, L-D11, L-D12 |
| O05 | Operação | Aprovação específica futura do destino | PENDENTE_DE_DECISAO | Não é objeto desta H3-K | Não se deduz do parsing, ausência de impedimento ou leitura de ACL | L-D07, L-D12 |
| O06 | Operação | Termo H3-C sobre origem/destino/proteção/método/responsáveis/validade | PENDENTE_DE_DECISAO | H3-C não autorizada | Nenhuma transferência do XML antes deste portão; retenção 180 dias não concede operação | L-D11, L-D12 |

## Contagem por identificador único

| Estado histórico | Quantidade |
|---|---:|
| DOCUMENTADA | 8 |
| PENDENTE_DE_EVIDENCIA | 10 |
| PENDENTE_DE_DECISAO | 11 |
| NAO_APLICAVEL_COM_JUSTIFICATIVA | 1 |
| Total de IDs únicos | 30 |

Há 12 decisões L-D01–L-D12, todas sem valor preenchido. Um ID pode estar associado
a mais de uma decisão; não somar ocorrências de vínculos como novos requisitos.
DOCUMENTADA é política/evidência textual, não condição material satisfeita.
O item remoto não aplicável tem sua justificativa histórica e não prova ausência
real de assistência no ambiente. Nenhum requisito foi encerrado ou presumido atendido.

A formalização futura continua privada e legítima; não publicar referências reais,
identidades, caminhos, inventário interno ou JUnit. O checklist original permanece
íntegro e não foi atualizado para refletir propostas desta H3-M.
