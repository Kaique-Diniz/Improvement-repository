# H3-M — finalidade, garantias e decisões preparadas

26/11/2026 — America/Sao_Paulo. Preparação exclusivamente documental.
H3-M=DECISOES_PREPARADAS_AGUARDANDO_AUDITORIA.

## Escopo e conclusão

Alternativas A (observação limitada) e B (garantias reforçadas antes de observar)
foram comparadas sem escolher em nome do custodiante. Permanece a conclusão
METODO_REQUER_REVISAO_ADICIONAL_ANTES_DE_OBSERVACAO. A preparação contém decisões,
critérios e modelo, não implementação, teste, aceitação de risco ou autorização.

Todas as fontes essenciais H3-L/K/E e o parecer H3-L estavam disponíveis e foram
conferidas com identidades autenticadas. Não houve divergência que impedisse uma
conclusão documental; essa conferência não comprova Windows, contexto privado ou
história do JUnit. Índice discrimina fontes, limites de proveniência e hashes.

## Respostas objetivas

1. Preparadas duas finalidades: A busca indícios/metadados nominais e lacunas;
   B exige garantias definidas mais fortes antes da observação. Adiamento por
   decisão insuficiente é encaminhamento C, não uma terceira finalidade executável.
2. Características declaradas de volume, atributos/ausência pontuais, marcadores
   Git, indicadores de exposição e DACL ancestral podem ser informações diagnósticas.
   Não certificam identidade estável, separação completa, acesso efetivo ou proteção.
   As propostas por G01–G11 são condicionais, não escolhas aprovadas.
3. Se indispensáveis, identidade física, controle de substituição/exclusividade,
   acesso efetivo/proteção e recepção vinculável exigem avaliar revisão de projeto.
   Handles/pinning, entradas, consumidor/supervisor ou outra API não são implementados.
   Nem toda observação diagnóstica exige automaticamente o mesmo reforço.
4. Doze IDs L-D01–L-D12 preservados com todos os campos H3-L e contexto/alternativas/
   consequências/dependências acrescentados; valores continuam NAO_PREENCHIDO.
   Políticas existentes se distinguem de decisões operacionais pendentes.
5. Todos os 30 IDs do checklist e seis colunas históricas preservados, distribuição
   8 DOCUMENTADA / 10 PENDENTE_DE_EVIDENCIA / 11 PENDENTE_DE_DECISAO /
   1 NAO_APLICAVEL_COM_JUSTIFICATIVA. Vínculo múltiplo não duplica contagem.
6. Todos os 15 registros runtime preservados integralmente: 6 N02, 4 N03, 5 N04.
   Grupos seguem NAO_VERIFICADO; N01 apenas sintaxe R1 conforme evidência do usuário.
7. Quatorze questões do contrato requerem decisão de adoção/revisão/adiamento,
   incluindo origem, vínculo com autorização, ambiente/operador, início, JSON,
   falhas/tempo/encerramento, privacidade e veto a aprovação automática. Nenhum
   prazo, mecanismo ou adoção é escolhido. CONTRATO_EXTERNO=PROPOSTO_NAO_IMPLEMENTADO.
8. Custodiante/autoridade legítima decidem finalidade, garantias, legitimidade,
   responsabilidades, coadministradores, referências/local, exposição/obrigações,
   falhas/evidências, validade e separação de portões. Modelo apenas descreve campos;
   não solicita envio de valores privados ao Codex.
9. Próximo portão imediato é auditoria H3-M. Depois de decisões expressas, A exige
   revisão adicional de método/contrato/evidências; B revisão de projeto/viabilidade;
   C preserva adiamento. Nenhuma execução, desenvolvimento ou custódia é automática.

## Riscos e políticas que não foram reclassificados

| Item | Severidade histórica | Estado preservado |
|---|---|---|
| H3G-R01 | MEDIA | RISCO_POTENCIAL |
| H3G-R02 | MEDIA | RISCO_POTENCIAL |
| H3G-R03 | ALTA | RISCO_POTENCIAL |
| H3G-R04 | MEDIA | RISCO_POTENCIAL |
| H3G-R05 | MEDIA | RISCO_POTENCIAL |
| H3G-R06 | MEDIA | RISCO_POTENCIAL |
| H3G-R07 | ALTA | RISCO_POTENCIAL |
| H3G-R08 | MEDIA | RISCO_POTENCIAL |
| H3G-R09 | MEDIA | RISCO_POTENCIAL |

N02/N03 ALTA e N04 MEDIA continuam não verificados. V01–V10 não executados;
D01–D04 sem prova funcional. Nenhum dos 11 temas G constitui novo controle WIN.
A H3-F-R1 não resolve sozinha R03/R07 ou garantias de custódia.

Política H3-E: usuário custodiante principal como papel, coadministradores somente
especificamente autorizados, mudanças de acesso/movimentação/exclusão com autorização
prévia específica, remoto adiado/não autorizado, custódia inicial local e diretório
exclusivo/protegido/separado. Identidades/legitimidade, responsáveis, obrigações,
referências privadas, local, direitos/método/proteção, marco e validade seguem pendentes.
Retenção inicial máxima até 180 dias só após futura cópia fiel aceita/verificada,
revisões 60/120/180 e antecipada se H4 terminar, prorrogação expressa justificada e
nenhuma exclusão automática. Sem relógio/agenda iniciados.

## Método e preservação

Somente leitura documental, CSV como dados, hashes e comparação integral em Linux
com biblioteca padrão Python; escrita exclusiva na nova pasta H3-M externa ao Git
e separada de custódia. Nenhum parsing adicional PowerShell/runtime/JSON, WMI,
Windows/DACL, mock/simulação, código/runner, dado privado/JUnit, instalação/remoto,
ACL/privilégio/política, Git, ZIP ou publicação. Fontes/manifests e pacotes anteriores
conferidos antes/depois permaneceram idênticos, no alcance listado no índice.
Entregar doze arquivos e parar para auditoria independente.
