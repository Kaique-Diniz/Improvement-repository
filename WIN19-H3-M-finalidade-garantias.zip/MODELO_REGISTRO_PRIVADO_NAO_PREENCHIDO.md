# H3-M — modelo de registro privado, NÃO PREENCHIDO

26/11/2026 é a data do modelo, não de uma decisão operacional ou de assinatura.
Não é autorização, termo assinado ou registro privado real. Não há dados pessoais.
Os campos de valor abaixo estão vazios. Não enviar seus valores ao Codex.
O preenchimento futuro depende de manifestação expressa e ambiente privado legítimo.

## Identificação de uma decisão

Aplicável separadamente a L-D01, L-D02, L-D03, L-D04, L-D05, L-D06, L-D07,
L-D08, L-D09, L-D10, L-D11 e L-D12. Repetir registros apenas quando legitimamente
necessário, sem transformar as doze pendências em decisões presumidas.

| Campo a formalizar privadamente | Requisito do campo | Valor |
|---|---|---|
| ID da decisão e referência documental | Vincular ao tema histórico, sem inventar ID nativo/assinatura | |
| Versão do registro | Identificar versão real futura e referência anterior quando houver | |
| Papel responsável e identidade legítima | Identidade nominal/autoridade ficam privadas; comprovação pertinente | |
| Fundamento/competência para decidir | Referência legítima, sem presumir poderes pelo nome da conta | |
| Finalidade exata e alternativa considerada | A, B ou adiamento somente se expressamente decididos | |
| Objeto e garantias indispensáveis | Indicar identidade/operação/limites e motivação da decisão | |
| Alternativas analisadas e justificativa | Não omitir consequências de ausência de prova | |
| Políticas preexistentes aplicáveis | Referenciar H3-E sem reabrir por silêncio ou confundir com autorização | |
| Evidências legítimas e sua proveniência | Referências privadas; registrar identidade documental e limitações | |
| Dependências e decisões anteriores | Vincular apenas decisões efetivamente formalizadas | |
| Ambiente/operador autorizado | Nominal e legitimidade privadas; não preencher por alias herdado | |
| Coadministradores e limites | Pessoas específicas e operações autorizadas, se houver decisão | |
| Referências privadas de áreas proibidas | Inventário legítimo delimitado, sem publicar valores | |
| Referência privada de destino proposto | Não implica criação/aprovação; local real somente privadamente | |
| Regras de exposição/confidencialidade | Destinatários/canais/obrigações aplicáveis, sem credenciais | |
| Método/código e identidade esperados | Referência e identidade da cópia efetivamente proposta, sem atestado runtime fictício | |
| Adoção/revisão do contrato externo | Cláusulas expressamente decididas e dependências de implementação | |
| Duração total/acompanhamento/interrupção | Somente valores/método futuramente aprovados; não inferir de timeout de API | |
| Recepção/recursos incertos | Critérios e responsável sem mecanismo de encerramento improvisado | |
| Escopo e referência da autorização | Decisão de finalidade não substitui autorização operacional | |
| Início/fim/expiração da validade | Eventos reais futuros, com fuso e limites de confiança, sem datas inventadas | |
| Resultado efetivo da decisão | Permanecer vazio até manifestação expressa; não confundir modelo com aceite | |
| Riscos e limitações residuais | Registro próprio; finalidade A não equivale a aceitar R03/R07 | |
| Necessidade de revisão/implementação | Não conceder desenvolvimento por inferência | |
| Separação de inspeção/destino/H3-C | Registros independentes, nenhuma abertura automática | |
| Responsáveis por retenção/revisões | Conservar 180 dias máximo inicial e revisões 60/120/180/antecipada | |
| Marco futuro de cópia fiel aceita | Só após evento real; campo não inicia contagem de retenção | |
| Obrigações institucionais | Avaliação legítima de compatibilidade, não presumir ausência | |
| Registro de manifestação/validação legítima | Só se realmente existente; não inventar assinatura/carimbo/hora | |
| Destinatários e proteção do registro privado | Não configurar acesso, criar custódia ou enviar dados neste modelo | |

## Limites de utilização do modelo

Modelo compartilhável descreve campos; não contém caminho privado completo,
conta/SID, ID de computador, identidade de coadministrador, inventário interno,
credencial, detalhe de ACL individual, dado de cliente ou conteúdo do JUnit.
Não solicitar esses dados na conversa. Não incluir credenciais no registro mesmo
quando legitimamente preenchido; usar referências adequadas, nunca segredo bruto.

Mudanças de acesso, movimentações e exclusões dependem de autorização prévia
específica do custodiante. Nenhuma implementação, execução, remoto, share,
sincronização ou coleta é autorizada para preencher o modelo. Decisão de política,
aceite de risco, autorização de inspeção e termo H3-C não são intercambiáveis.
