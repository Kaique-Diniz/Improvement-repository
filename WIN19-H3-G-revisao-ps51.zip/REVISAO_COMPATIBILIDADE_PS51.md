# H3-G — compatibilidade PowerShell 5.1 e contratos .NET

24/11/2026. Estado geral CONFERIDO_ESTATICAMENTE, não validado por parser.
Linhas Bnnn referem-se ao bloco autenticado, sem cercas Markdown, início em B001.
Ambiente atual Linux; nenhum interpretador PowerShell foi invocado.

## Linguagem, binding, escopo e saída

| Elemento | Linhas | Conclusão documental / limite |
|---|---|---|
| Funções aninhadas e parâmetros tipados | B001–103 | Construções anteriores ao PS7; nenhum uso de sintaxe exclusivamente PS7 identificado. Não é validação da gramática inteira. |
| [ordered], [pscustomobject], arrays, -in/-notin, try/catch/finally | B004–25 e demais | Representação textual compatível com recursos documentados do PS5.1; eventuais erros de binding/execução não foram medidos. |
| ::new() e tipos .NET | B025, B068–76, B124, B153, B286 | Forma de instanciação documentada no PS5.1. A disponibilidade da classe e a escolha da sobrecarga são verificações distintas. [about_Classes](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_classes?view=powershell-5.1). |
| Quebras após operadores e expressões entre parênteses | B107–10, B132–43, B173–78, B276–78 | Leitura não encontrou erro específico; sem substituir parser por contagem de delimitadores. [about_Parsing](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_parsing?view=powershell-5.1). |
| Conversões enum/integer e short-circuit | B154–88, B261, B276–301 | Conversões inteiras, bits e acesso indexado têm intenção coerente; exceções de cast/nulos devem permanecer inconclusivas. Números de barramento não autenticam posição interna. |
| Strings e caminhos | B054–59, B134–49 | Strings simples PS não usam barra invertida como escape; OrdinalIgnoreCase é comparação nominal. TrimEnd/Split com char exigem binding para sobrecarga char[]; isso não foi exercitado. Não trocar por comparação cultural. |
| Escopo mutável | B004–24, B061–103 | Helpers leem variáveis do escopo pai e modificam membros de objetos compartilhados. Não dependem de atribuir uma nova variável pai por nome. Resolução real no host permanece não verificada. [about_Scopes](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_scopes?view=powershell-5.1). |
| Arrays e coleções | B014, B066–102, B166–78 | List[object], ToArray e captura @() tornam intenção de zero/um/vários resultados explícita. Unrolling e descarte não foram simulados. Não usar PowerShell 7 como prova para 5.1. |
| JSON | B357–71 | Objeto normal contém primitivas/coleções de códigos, sem objeto de identidade/ACL. Depth 8 é maior que a profundidade aparente desse modelo; serialização real não executada. [ConvertTo-Json 5.1](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/convertto-json?view=powershell-5.1). |

## APIs e sobrecargas examinadas

| Classe/operação | Assinatura/intenção observada | Disponibilidade e ressalva |
|---|---|---|
| ManagementScope | String de escopo local + ConnectionOptions | Contrato documentado; resolução System.Management no Windows-alvo não inspecionada. [Construtores](https://learn.microsoft.com/en-us/dotnet/api/system.management.managementscope.-ctor?view=netframework-4.8.1). |
| ManagementObjectSearcher | ManagementScope, ObjectQuery, EnumerationOptions | Sobrecarga documentada; não foi construída nesta revisão. [Construtores](https://learn.microsoft.com/en-us/dotnet/api/system.management.managementobjectsearcher.-ctor?view=netframework-4.8.1). |
| ConnectionOptions | Construtor vazio, EnablePrivileges=false, Timeout | Não solicita habilitar privilégios. Timeout não é prazo global de conexão; não prova que o token atual não possua privilégios. |
| EnumerationOptions | Construtor vazio, Timeout e Rewindable=false | Enumeração direta coerente com percurso único. A função não deve continuar após falha de descarte: D02. [Timeout](https://learn.microsoft.com/en-us/dotnet/api/system.management.managementoptions.timeout?view=netframework-4.8.1). |
| ManagementObject/coleção/enumerador | Get, MoveNext, Current e Dispose | Recursos de consulta têm descarte previsto; falha deve ser refletida e parar. [Contrato do enumerador](https://learn.microsoft.com/en-us/dotnet/api/system.management.managementobjectcollection.managementobjectenumerator). |
| DriveInfo | String da raiz, DriveType e IsReady | Leitura de tipo/prontidão não prova disco físico interno ou identidade física. |
| File | GetAttributes(String) | Metadados, não leitura de conteúdo. Só FileNotFoundException/HResult 2 vira ausência; demais falhas não são sucesso. [GetAttributes](https://learn.microsoft.com/en-us/dotnet/api/system.io.file.getattributes?view=netframework-4.8.1). |
| Directory | GetAccessControl(String, AccessControlSections) | Sobrecarga do .NET Framework, não presumir API equivalente em runtime diferente. [GetAccessControl](https://learn.microsoft.com/en-us/dotnet/api/system.io.directory.getaccesscontrol?view=netframework-4.8.1). |
| WindowsIdentity/WindowsPrincipal | GetCurrent(), construtor com identidade, IsInRole | Apenas contexto do usuário atual, sem logon novo; Dispose em finally. Não autentica legitimidade institucional. [GetCurrent](https://learn.microsoft.com/en-us/dotnet/api/system.security.principal.windowsidentity.getcurrent?view=netframework-4.8.1). |
| RawSecurityDescriptor | Byte[] e Int32 offset zero | Sobrecarga documentada, recebendo descritor privado. Não equivale a AccessCheck nem teste entre contas. [Construtores](https://learn.microsoft.com/en-us/dotnet/api/system.security.accesscontrol.rawsecuritydescriptor.-ctor?view=netframework-4.8.1). |

As páginas de API podem reunir diversas versões e mostrar avisos de versões
recentes. Foram usadas para comparar contratos, não para certificar assemblies
instalados ou afirmar que um pacote .NET moderno seja dependência autorizada.
Não houve Add-Type, Import-Module, carregamento experimental ou instalação.

## Consultas WMI previstas

| Consulta | Namespace, propriedades e tratamento |
|---|---|
| ASSOCIATORS OF Win32_LogicalDisk via Win32_LogicalDiskToPartition | Root\CIMV2; associação documentada entre lógico/partição; resultado esperado Win32_DiskPartition com DiskIndex. Zero/múltiplos/nulo param. [Associação](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-logicaldisktopartition), [partição](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-diskpartition). |
| Win32_DiskDrive WHERE Index | Root\CIMV2; Index, InterfaceType, MediaType. O contrato de Index descreve número físico e valor sentinela de não mapeamento. Não é prova de correspondência em todo provider. [Win32_DiskDrive](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-diskdrive). |
| MSFT_Disk WHERE Number | Root\Microsoft\Windows\Storage; Number, BusType, IsOffline. Dependência documentada de Windows 8/Server 2012 ou posterior; PS5.1 isolado não a garante. Falhas param inconclusivas. [MSFT_Disk](https://learn.microsoft.com/en-us/windows-hardware/drivers/storage/msft-disk). |
| Win32_Share | Root\CIMV2; Path e Type, inclusive bit administrativo. Propriedades podem ser nulas por permissão: corrigir Path nulo de share de disco, D04. [Win32_Share](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-share). |

Os barramentos numéricos não substituem prova de disco interno. Versões de SDK e
provider podem diferir; o enum de storage é referência descritiva, não medição:
[STORAGE_BUS_TYPE](https://learn.microsoft.com/en-us/windows/win32/api/winioctl/ne-winioctl-storage_bus_type).

Conclusão: não há incompatibilidade categórica PS5.1 comprovada ou erro sintático
específico demonstrado nesta inspeção, mas sintaxe global e binding nativo
permanecem NAO_VERIFICADO. PARSING_NATIVO_PS51=NAO_EXECUTADO.
