# H3-G — limites de validação e evidências realmente obtidas

24/11/2026. Ambiente de execução disponível: Linux.
PARSING_NATIVO_PS51=NAO_EXECUTADO.

| Rótulo | Uso nesta entrega |
|---|---|
| CONFERIDO_ESTATICAMENTE | Leitura autenticada, comparação com contratos públicos e análise do fluxo textual; não execução. |
| VALIDADO_POR_PARSER | Nenhum item. Não foi invocado parser Windows PS5.1 ou outro interpretador. |
| NAO_VERIFICADO | Sintaxe global, binding .NET, providers, host, recursos e resultados reais. |
| DEFEITO_CONFIRMADO | Quatro inconsistências demonstradas no texto; não ocorrência reproduzida em Windows. |
| RISCO_POTENCIAL | Nove condições/limites possíveis, sem prova de materialização ou exploração. |

## O que foi feito

Autenticação do único bloco H3-F e manifesto; leitura dos seis documentos
obrigatórios H3-F/parecer; exame de documentação oficial Microsoft por pesquisa/
consulta web; criação de nove documentos externos e manifesto, diff puramente
textual em memória e conferência de hashes/tamanhos/CSV.

Ferramentas locais: Python com -I -B e biblioteca padrão pathlib/hashlib/csv/io/
textwrap/difflib/platform, somente para metadados e documentos; terminal Linux.
Essas ferramentas não interpretaram PowerShell ou APIs Windows. A extração por
marcadores/cercas é delimitação documental para hash, não parsing da linguagem.

## O que não foi feito

Nenhum parsing, lint, teste sintático ou funcional em PowerShell 5.1/7, .NET ou
conversor. Nenhuma simulação de callbacks, exceções de API ou cenários de destino.
Não foi executada Invoke-H3FProposta nem função extraída, consulta WMI, ACL,
filesystem Windows, preflight, pytest, teste entre contas ou código de anexo.
Não houve instalação, chamada ao Windows do usuário, caminho privado solicitado,
leitura/cópia do JUnit, criação de custódia ou alteração de segurança.

## Identificação de parser

Nome/versão/origem de parser utilizado: NÃO_APLICAVEL, pois nenhum foi utilizado.
Não preencher esses campos com Python, ferramenta de busca, PowerShell 7 ou nome
suposto de Windows PowerShell 5.1. Não há tokens/AST/errors reais de parser nesta
entrega, portanto não existe relatório de parsing nativo aprovado.

Documentação de ::new(), métodos e classes demonstra contratos publicados, não
que as bibliotecas estejam presentes ou que o programa inteiro seja gramaticalmente
válido. A ausência de erro sintático identificado não deve ser convertida em
“zero erros do parser”. Mesmo um parser futuro não executa nem valida semântica
WMI, permissionamento, identidade física, corrida, estabilidade ou DACL efetiva.

## Próximas evidências possíveis, sem autorização atual

Somente após decisão de revisão, considerar H3-F-R1 documental isolada e, em
ambiente apropriado expressamente autorizado, parser Windows PowerShell 5.1
confiável sobre texto autenticado, registrando origem/versão/hash da ferramenta e
entrada. Não invocar o bloco nem suas funções. Testes de funcionamento, consultas
e avaliação real continuam sendo escopos separados e não estão liberados.

Originais H3-F e pacotes foram preservados por bytes/hashes. Essa conferência
local não prova ausência de toda operação em outros ambientes nem autentica o
histórico JUnit. Nada desta revisão homologa WIN/DACL ou conversões.
