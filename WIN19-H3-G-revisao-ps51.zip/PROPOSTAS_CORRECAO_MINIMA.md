# H3-G — propostas documentais de correção mínima

24/11/2026. **DIFF PROPOSTO, NÃO APLICADO, NÃO PARSEADO, NÃO EXECUTADO.**
Não existe candidata H3-F-R1 materializada nesta entrega. Os nomes de arquivo do
diff são rótulos virtuais de texto, não caminhos reais nem arquivos .ps1.

## Escopo de eventual autorização futura H3-F-R1

Fonte exclusiva: bloco H3-F de 19.771 bytes, SHA-256
8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4.
Original preservado; alterações não autorizadas para aplicação nesta tarefa.

| Achado | Menor mudança proposta | Mudança de comportamento e garantia mantida |
|---|---|---|
| D01 | Definir V09 corrente/pendente antes da última releitura e reconfirmar só após ausência observada | Falha não reutiliza confirmação antiga nem apaga o motivo de V05. Sem leitura adicional ou criação. |
| D02 | Marcar falha e lançar exceção sanitizada ao falhar Dispose do item | Não pedir novo item após erro de encerramento. finally externo continua tentando encerrar enumerador/coleção/searcher; resultado não vira sucesso. |
| D03 | Capturar falha de Get-H3Attributes dentro de Assert-H3Chain e parar V03 INCONCLUSIVO | Erro da guarda é diagnosticado como tal, sem mensagem privada, retry ou resolução de reparse. |
| D04 | Exigir Path não vazio para qualquer share do tipo disco | Informação parcial vira inconclusão/parada própria; IPC e não disco continuam fora dessa exigência. Bloqueio de share administrativo permanece. |

Nenhuma proposta muda flags de segurança, ACL, privilégio, política de custódia,
retenção, fonte XML, regras Git, limites físicos, referências privadas, V05/V08,
modo de criação/exclusão ou aprovações operacionais. Não ajustar asserções para
obter resultado favorável. Os efeitos acima são intenção estática, não resultado
validado de um código revisado.

## Diff integral proposto sobre o bloco autenticado

Gerado por comparação de texto em memória, sem executar script, analisar gramática,
aplicar patch ou gravar versão revisada do código. Os quatro ajustes estão completos
no diff abaixo; contexto/hunks referem-se à fonte H3-F. Revisão independente poderá
rejeitar ou refinar a proposta antes de qualquer autorização de H3-F-R1.

```diff
--- H3-F/bloco-original-autenticado.txt
+++ PROPOSTA-NAO-APLICADA/bloco-H3-F-R1.txt
@@ -41,9 +41,13 @@
     }
     function Assert-H3Chain {
         # Releitura ordenada, sem resolver links; nao equivale a pin por handle.
         foreach ($entry in $chain) {
-            $a = Get-H3Attributes $entry.Caminho
+            try {
+                $a = Get-H3Attributes $entry.Caminho
+            } catch {
+                Stop-H3 'V03' 'INCONCLUSIVO' 'H3F_RELEITURA_ANCESTRAL_INDISPONIVEL'
+            }
             if ($a.Ausente -or
                 (($a.Atributos -band [IO.FileAttributes]::ReparsePoint) -ne 0) -or
                 (($a.Atributos -band [IO.FileAttributes]::Directory) -eq 0) -or
                 ($a.Atributos -ne $entry.Atributos)) {
@@ -85,9 +89,12 @@
                     $record = @{}
                     foreach ($field in $Fields) { $record[$field] = $item.Properties[$field].Value }
                     [void]$rows.Add([pscustomobject]$record)
                 } finally {
-                    try { $item.Dispose() } catch { $flow.RecursosFechados = $false }
+                    try { $item.Dispose() } catch {
+                        $flow.RecursosFechados = $false
+                        throw [InvalidOperationException]::new('H3F_DESCARTE_ITEM_FALHOU')
+                    }
                 }
             }
         } finally {
             foreach ($resource in @($iterator, $collection, $searcher)) {
@@ -257,10 +264,12 @@
         }
         $shares = @(Get-H3LocalRows 'root\cimv2' 'SELECT Path, Type FROM Win32_Share' @('Path','Type'))
         foreach ($share in $shares) {
             if ($null -eq $share.Type) { Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_SHARE_METADADO_INCOMPLETO' }
-            if (([uint32]$share.Type -band 255) -eq 0 -and
-                -not [string]::IsNullOrWhiteSpace([string]$share.Path)) {
+            if (([uint32]$share.Type -band 255) -eq 0) {
+                if ([string]::IsNullOrWhiteSpace([string]$share.Path)) {
+                    Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_SHARE_CAMINHO_INDISPONIVEL'
+                }
                 $sharePrivate = [string]$share.Path
                 if ($sharePrivate -notmatch '^[A-Za-z]:\\') {
                     Stop-H3 'V06' 'INCONCLUSIVO' 'H3F_SHARE_CAMINHO_AMBIGUO'
                 }
@@ -306,12 +315,15 @@
 
         $flow.Atual = 'V05'
         Set-H3State 'V05' 'INCONCLUSIVO' @('H3F_REFERENCIAS_PRIVADAS_AREAS_VEDADAS_NAO_FORNECIDAS')
         # Nao pedir caminhos extras, inventar referencias ou procurar candidatas.
+        $flow.Atual = 'V09'
+        Set-H3State 'V09' 'INCONCLUSIVO' @('H3F_REVALIDACAO_DESTINO_PENDENTE')
         Assert-H3Chain
         $again = Get-H3Attributes $firstMissingPrivate
         Assert-H3Chain
         if (-not $again.Ausente) { Stop-H3 'V09' 'IMPEDIMENTO' 'H3F_COLISAO_OU_ALTERACAO_OBSERVADA' }
+        Set-H3State 'V09' 'CONFIRMADO_COM_EVIDENCIA' @('H3F_PRIMEIRA_AUSENCIA_OBSERVADA_SEM_GARANTIA_FUTURA')
         $flow.Atual = 'V08'
         if ($nullDacl) { Stop-H3 'V08' 'IMPEDIMENTO' 'H3F_DACL_NULA_ANCESTRAL' }
         if ($broadAllow -gt 0) {
             Stop-H3 'V08' 'INCONCLUSIVO' 'H3F_CONCESSAO_AMPLA_REQUER_REVISAO_PRIVADA'
```

SHA-256 dos bytes do diff entre cercas, UTF-8 sem BOM, LF incluindo LF final:
`1cd6735875e46a11ad5cbcd291e6a5e0030e321a48472c27a01a048c4cbad07a`.
Esse hash identifica somente a proposta documental, não candidata operacional.

## Riscos sem patch nesta etapa

R01–R09 continuam documentados. Não se cria envelope operacional novo, timeout
externo invasivo, mecanismo de pin, mudança em autoload/módulos ou cálculo de acesso
efetivo. Esses itens exigem decisões de escopo e evidência próprias. Parser pode
examinar sintaxe, mas não provar guardas, providers, Dispose ou segurança.

Antes de aplicar qualquer alteração, obter autorização específica e preservar
esta fonte/proposta. Depois, futura versão isolada e novamente revisada; eventual
parser Windows PS5.1 confiável somente no ambiente/escopo apropriados, sem invocar
funções ou consultas. Execução do destino, H3-C, H3-S e H4 não decorrem disso.
