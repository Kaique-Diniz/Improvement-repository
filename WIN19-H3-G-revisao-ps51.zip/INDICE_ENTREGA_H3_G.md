# WIN19-H3-G — índice e proveniência da revisão

24/11/2026 — America/Sao_Paulo. Diretório documental novo externo ao Git:
/workspace/work/WIN19-H3-G-REVISAO-PS51-20261124. Não é destino de custódia.

## Dez entregáveis exclusivos

1. [RELATORIO_H3_G.md](RELATORIO_H3_G.md) — respostas objetivas e conclusão.
2. [REVISAO_COMPATIBILIDADE_PS51.md](REVISAO_COMPATIBILIDADE_PS51.md) — linguagem,
   classes/sobrecargas e consultas, com fontes Microsoft e limites nativos.
3. [REVISAO_SEGURANCA_E_EFEITOS.md](REVISAO_SEGURANCA_E_EFEITOS.md) — leitura,
   privacidade, host/providers e efeitos indiretos.
4. [REVISAO_LOGICA_V01_V10.md](REVISAO_LOGICA_V01_V10.md) — cobertura individual,
   ordem real de chamadas, paradas e consolidação.
5. [MATRIZ_DEFEITOS_E_RISCOS.csv](MATRIZ_DEFEITOS_E_RISCOS.csv) — 17 IDs de revisão:
   quatro defeitos confirmados estaticamente, nove riscos potenciais, quatro
   itens não verificados. Não são casos Windows ou vínculos históricos.
6. [PROPOSTAS_CORRECAO_MINIMA.md](PROPOSTAS_CORRECAO_MINIMA.md) — diff integral
   proposto em texto, não aplicado, sem candidata/script revisado materializado.
7. [LIMITES_DE_VALIDACAO_H3_G.md](LIMITES_DE_VALIDACAO_H3_G.md) — ferramentas,
   distinção de evidência e parsing nativo não executado.
8. [DECISAO_E_PROXIMOS_PORTOES.md](DECISAO_E_PROXIMOS_PORTOES.md) — recomendação,
   autorização futura específica e bloqueios preservados.
9. INDICE_ENTREGA_H3_G.md — este registro.
10. [MANIFESTO_SHA256_H3_G](MANIFESTO_SHA256_H3_G) — tamanho/hash dos nove documentos
    anteriores; não se autorreferencia. Hash informado na conversa.

## Instrução principal e parecer de fundamento

Texto colado.txt, instrução EXP-04 / WIN19 — H3-G, 9.709 bytes, SHA-256
280605264144411becc6dd1cfa8ee12ef75163cf08a14e1a867a8fb09ce79291.
Autoriza revisão e proposição documental; parser só se PS5.1 confiável estiver
em ambiente apropriado. Como o ambiente é Linux, não houve parsing nativo.

PARECER_INDEPENDENTE_WIN19_H3_F_2026-11-24.md, 7.099 bytes, SHA-256
208acb1070a12ba645e8ad5ce9c07810cf1ba47c5c513e1993b00d740a7603f8.
Lido integralmente; aceita H3-F documentalmente com ressalvas e sem execução.
Não contém aprovação operacional. Ambos os anexos foram usados como documentos,
não executados nem copiados para a pasta nova.

## Fonte H3-F obrigatória, autenticada e preservada

| Documento | Bytes | SHA-256 |
|---|---:|---|
| COMANDO_WINDOWS_VERIFICACAO_DESTINO.md | 21778 | 286894f9c5fbdb37e512407cd830c8c20bf08bc49b7b8e1cb07d61d8b3f340c1 |
| REVISAO_ESTATICA_COMANDO.md | 7000 | 1cebfe4c6273d9e027aca410e62ba06bb08aff2a4df84124f11793bcd9c1e0f4 |
| MATRIZ_V01_V10_H3_F.csv | 4252 | f87e4d875e60c8aa7ce3023971bcfaeb5de76365a8f11740535aebc36a09ff4f |
| MATRIZ_IMPEDIMENTOS_H3_F.md | 5623 | 94208fa4b21c97080b480401268e26cdf3b2da1e20acd75b395deae20b4d9c87 |
| LIMITACOES_E_DECISOES_H3_F.md | 5111 | 887fe2ba3dce75fa4ae8150f0e77a143935cea95db35dfede23996e4c04fa246 |

Manifesto H3-F: SHA-256
52edc8442c7ee86824e45895353511f390eade151a3e76cd038af1b2246a9873.
Todos os oito documentos e manifesto foram conferidos e preservados.
ZIP H3-F anterior: 25.645 bytes, SHA-256
d1c8379c32e9b32667a37714e596b633944b025c7624dd771a4ab24f3f769fbd,
sem mudança. A preservação local é conferência de bytes, não prova de ausência de
toda operação em ambiente remoto.

## Extração e endereçamento

Bloco único delimitado por marcadores INICIO_BLOCO_POWERSHELL_H3_F /
FIM_BLOCO_POWERSHELL_H3_F e cerca powershell no Markdown. Excluir cercas e
marcadores, incluir LF final do código; UTF-8 sem BOM, sem CR. 19.771 bytes,
SHA-256 8cb34850fc182feb06c46620336cc076d1401f2797151dca6abad536bc2527e4.
Numeração B001–B371 é a posição das linhas desse texto LF, não linhas do Markdown.
Extração e comparação são documentais, não parsing da linguagem.

Diff em PROPOSTAS_CORRECAO_MINIMA.md: texto UTF-8/LF incluindo LF final;
SHA-256 1cd6735875e46a11ad5cbcd291e6a5e0030e321a48472c27a01a048c4cbad07a. Somente proposta, nunca aplicada.

## Fontes públicas de apoio e ferramentas

Documentação oficial Microsoft consultada em 24/11/2026 por ferramenta de busca/
leitura web. URLs diretas e suas aplicações constam em REVISAO_COMPATIBILIDADE_PS51.md
e REVISAO_SEGURANCA_E_EFEITOS.md. Nenhum exemplo dessas páginas foi executado,
instalado ou copiado como dependência. Apenas contratos foram confrontados; páginas
que agregam versões não atestam o Framework instalado no alvo.

Uma abertura direta da página Dispose do enumerador com filtro Framework não
retornou conteúdo pela ferramenta; foi consultada a página pública da classe do
enumerador, que documenta IDisposable/Dispose. Isso não é consulta de API em runtime.
Não é apresentada evidência operacional para suprir essa limitação.

Python -I -B/stdlib para bytes/hashes, documentos, CSV e difflib apenas. Nenhum
interpretador/parser PS, teste/simulação, WMI/ACL/filesystem Windows, produto,
XML, Git, criação de custódia, segurança, commit/push/merge/publicação ou ZIP.
Nove documentos novos e manifesto; sem cópia de contrato/código executável.
Parar para auditoria, mantendo os estados em DECISAO_E_PROXIMOS_PORTOES.md.
