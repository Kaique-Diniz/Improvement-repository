# H3-G — correspondência lógica dos dez critérios

24/11/2026. Todos os resultados Windows reais continuam NAO_EXECUTADO.
A coluna de análise descreve o código, não uma verificação realizada no destino.

| Critério | Localização Bnnn | Cobertura e limite | Achados |
|---|---|---|---|
| V01 Ambiente | B105–127 | PS5.1 Desktop/Win32NT, indicadores de sessão, contexto e elevação. Confirma só observação; legitimidade institucional permanece privada. Não identifica toda ferramenta remota nem privilégio do token. | R07/R08/R09; N01/N02 |
| V02 Disco | B151–188 | Fixed local permite consultas, não prova interno. Associação lógica/partição → DiskIndex → Index/Number, nulos/contagem/offline/bus tratados. Mesmo bus compatível fica INCONCLUSIVO. | R04; N03; sem regra substitutiva de aprovação |
| V03 Caminho | B129–150; B190–223; helper B042–53 | Input explícito, nomes/raiz, componentes e reparse; distingue ancestral e primeira ausência do sufixo não consultado. Releituras não fixam identidade. Erro da guarda pode ser atribuído ao chamador. | D03; R03; N02 |
| V04 Git | B225–244 | .git arquivo/diretório, componente .git e combinação de marcadores bare/danificados. Sem Git/hooks/conteúdo/recursão. Limite final INCONCLUSIVO. Não identifica qualquer remoção arbitrária de metadata; heurística pode sobrebloquear. | R05; D03 em releitura da guarda |
| V05 Áreas proibidas | B307–309 | Referências privadas não fornecidas; INCONCLUSIVO. Nenhuma varredura, caminho presumido ou preenchimento por nome parecido. | Limitação intencional preservada; D01 pode sobrescrever o código original de V05 |
| V06 Nuvem/share | B246–272 | Indicadores parciais OneDrive e shares locais; incidente impede, inclusive administrativo. Ausência não prova inexistência. Path de share de disco nulo é omitido pela condição atual. | D04; R06; N03 |
| V07 ACL ancestral | B274–305 | Leitura de owner/grupo/DACL/herança/regras/grupos; detalhes só em memória. Nenhuma alteração/SACL ou prova de efetividade futura. Confirmação é limitada à leitura. | R07; D03; N02 |
| V08 Proteção | B314–319 | DACL nula impede; allow amplo exige revisão; demais casos permanecem INCONCLUSIVO. Sem objeto futuro e papéis comprovados não há proteção certificada. | Limitação intencional, não relaxar; R07 |
| V09 Exclusividade | B211–223; B310–313 | Existência impede; primeira ausência observada é releita, sem criação/reserva. Falha de revalidação pode deixar confirmação antiga por corrente V05. | D01; R03 |
| V10 Resultado | B320–371 | Impedimento prevalece; caso incompleto não confirma; flags destino_aprovado/h3_c_autorizada false. Falha de fechamento sinalizada. Inicialização e serialização fora do envelope exigem cuidado. | R01; N04; nenhum VALIDADO_POR_PARSER |

## Ordem real e condições de parada

A execução proposta não percorre ordem numérica estrita: V01, validação inicial
V03, V02, percurso V03/V09, V04, V06, V07, registro V05, revalidação V09, V08 e
consolidação V10. Essa ordem deve ser auditada como está, não renumerada no relatório.
Antes da primeira ausência observa-se só metadata; não são lidos conteúdos ou XML.

Impedimentos/erros terminam o corpo e levam a finally/consolidação. Uma falha de
Dispose do item é exceção: a flag é marcada, mas o loop pode continuar, D02.
Nulos de Type são tratados; Path de share de disco vazio/nulo pode ser ignorado,
D04. Ausência segura só é inferida na exceção específica documentada em Get-H3Attributes,
não em qualquer erro; nenhuma alteração desse filtro é proposta.

A guarda registra divergência de atributos/reparse em V03, mas erro operacional
na própria consulta escapa à identificação V03, D03. Durante a última releitura
de ausência o critério corrente é V05 e V09 já está confirmada, D01. A proposta
retira essas ambiguidades sem acrescentar leitura, repetir ou normalizar caminhos.

## Consolidação e impossibilidade de aprovação

Pela rota atual, V02/V04/V05/V06/V08 nunca ficam todas confirmadas. A saída normal
é incompleta ou impedida; a alternativa genérica de ausência de impedimento não
é alcançada na configuração atual. PROCEDIMENTO_NAO_EXECUTADO é ramo do formato,
não prova independente de que o bloco não rodou e não gera JSON se nada for invocado.

A confirmação de V01/V07/V09 é uma observação limitada, não aprovação do requisito
material integral. Os quatro defeitos podem distorcer detalhe ou ordem de parada,
mas o estado agregado nominal continua conservador. Isso não é prova de segurança
global do host nem fundamento para dispensar correções.

V05/V08 não podem ser preenchidas por suposição, CPF, nomes, resultados cleanup,
outras suítes, leitura ACL isolada ou política documental. H3-C e WIN/DACL ficam
bloqueados até suas evidências e autorizações próprias; nada foi executado aqui.
