# H3-G — segurança, privacidade e efeitos indiretos

24/11/2026. CONFERIDO_ESTATICAMENTE sobre o bloco H3-F autenticado, não ensaio.

| Requisito | Evidência textual | Conclusão limitada |
|---|---|---|
| Somente leitura explícita | Consultas .NET/WMI e processamento em memória | Não há chamada explícita de persistência/cópia/mutação no fluxo. Isso não é garantia absoluta sobre o host/provider. |
| Sem execução de arquivos externos | Não há chamada de script, executável, Invoke-Expression ou Add-Type | Origem dos comandos/assemblies e carregamento automático são precondições do host, não comprovadas pela ausência de chamada explícita. |
| Sem XML histórico | Input é caminho proposto para diretório; não há leitura do JUnit ou conteúdo de arquivos | Identificações históricas nos documentos não são acessadas pelo código. |
| Sem arquivo/diretório/log | Não há escrita, temporário, transcript ou teste por criação | A pasta documental Linux desta entrega não é diretório de custódia. |
| Sem ACL/owner/herança alterados | GetAccessControl e inspeção do descritor; ausência de mutadores | V07 confirma no máximo a leitura; V08 não atesta proteção futura. |
| Sem privilégio/política alterados | EnablePrivileges=false; rejeição de administrador observável; sem configuração persistente | Não habilita privilégio, mas não inventaria completamente os já existentes. |
| Sem conexão remota solicitada | Escopo WMI ponto local fixo; sem host recebido por parâmetro ou rede externa | WMI local usa mecanismos internos de comunicação e pode ativar providers. Não afirma ausência de toda conexão interna do Windows. |
| Sem instalação de módulos | Nenhum instalador/importação explícita | Autoload de comandos qualificados e resolução de New-Object dependem da sessão confiável. |
| Sem Git/hooks | Só nomes de marcadores e GetAttributes, sem Git/configuração/conteúdo | Ausência de marcador não certifica separação; nenhum reparo é proposto. |
| Sem dados privados no objeto JSON normal | Return contém apenas versão/códigos/estados/flags/limitações | Caminho é digitado no console; objetos e ErrorRecord podem ficar em memória/captura privada. Não prova ausência de vazamento fora desse modelo. |

## Efeitos e precondições não certificados

Consultas System.Management podem ativar providers, COM/RPC locais, auditoria e
logs do sistema. Timeout de ManagementOptions não afeta Connect e não garante
prazo total. Isso impede prometer ausência absoluta de efeitos ou bloqueio global
limitado. Não se propõe desligar auditoria, serviço, nuvem ou política para permitir
consulta. [Contrato de Timeout](https://learn.microsoft.com/en-us/dotnet/api/system.management.managementoptions.timeout?view=netframework-4.8.1).

A resolução de comandos depende do host e de módulos: qualificação pode causar
autoload, e New-Object não qualificado pode ser sombreado. Tratar como risco de
ambiente, não como execução maliciosa observada. Nenhum módulo foi carregado por
este bloco durante a revisão. Não alterar PSModulePath/preferências para encobrir
incertezas. [Documentação de módulos 5.1](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_modules?view=powershell-5.1).

Read-Host é entrada local visível; não recebe caminho no chat e não tem padrão.
Uma sessão privada, confiável e sem captura não autorizada é precondição futura.
JSON normal sanitizado não é garantia sobre mensagens do host, cancelamento,
erros fora do try, histórico de erros ou memória. Limpar referências não é
apagamento forense; não apagar logs/memória para alegar proteção.

## Identidade e alcance

GetAttributes com releituras não fixa identidade física e não elimina corridas.
Guardas interrompem reparse conhecido, mas substituição intermediária não
observada permanece possível. Não foi demonstrado contorno de isolamento; a
limitação impede usar a inspeção como certificação do depósito.

DACL nula impede; concessão ampla produz revisão privada, não conclusão de acesso
efetivo ignorando deny/grupos. Privilégios, coadministradores e herança de objeto
inexistente não são autenticados. Nenhum novo teste entre contas, DACL ou atribuição
de acesso foi executado ou autorizado. DACL do produto permanece NÃO_VALIDADO.

Os defeitos D01/D03 afetam atribuição de diagnóstico; D02 afeta ordem de parada;
D04 afeta tratamento de metadado parcial. O fluxo nominal continua sem aprovar
local/cópia, mas precisão diagnóstica e parada conservadora exigem revisão mínima.
Não se alteram políticas nem se removem bloqueios para obter saída favorável.
