# Reconstrução reproduzível e identificação da versão auditada

Extrair o ZIP em diretório NOVO com Python 3.12 disponível. Não executar testes Windows durante esta auditoria. O repositório existente deve conter o commit-base, sem que seja necessário trocar sua branch. O pacote não instala dependências nem busca commits automaticamente.

No PowerShell, a partir da pasta `reconstrucao` do pacote extraído:

```powershell
$RepoExistenteWin01 = 'PREENCHER_CAMINHO_DO_CHECKOUT_EXISTENTE'
$DestinoWin01 = Join-Path $env:LOCALAPPDATA 'ConversorWIN01-Auditoria-Isolada'
$ResultadosWin01 = Join-Path $env:LOCALAPPDATA 'ConversorWIN01D-Resultados'
# $DestinoWin01 pode existir como diretório pai, mas WIN-01-A e WIN-01-C devem estar ausentes.
py -3.12 .\reconstruir.py --repo "$RepoExistenteWin01" --destino "$DestinoWin01"
py -3.12 .\reconstruir.py --verificar (Join-Path $DestinoWin01 'WIN-01-A') --versao A
py -3.12 .\reconstruir.py --verificar (Join-Path $DestinoWin01 'WIN-01-C') --versao C
```

O script valida todos os payloads antes de criar worktrees, recusa ambos os destinos se qualquer um já existir, cria HEAD destacado na base e desativa conversão automática CRLF somente para o checkout. Substitui arquivos do baseline apenas quando seus bytes correspondem ao hash esperado; arquivos novos usam abertura exclusiva. Não toca A/C originais, não altera configuração persistente e não cria commits. Uma falha deixa o novo diretório para inspeção; não há remoção automática. Não repetir sobre o mesmo destino ou apagar trabalho existente para obter sucesso: usar um novo destino após diagnosticar.

Ao finalizar, cada versão é conferida contra TODOS os arquivos de seu manifesto, e arquivos inesperados são recusados (exceto metadados .git e caches __pycache__/.pytest_cache). A verificação pode ser repetida antes e depois de cada rodada futura. Mudanças CRLF ou arquivos de código extras são divergências, não normalizados silenciosamente. Não colocar venv, evidências ou documentos privados dentro dessas worktrees.

A revisada: 469 arquivos, incluindo os artefatos e logs históricos da preparação; C candidata: 441 arquivos, com os 28 deltas auditados. São versões separadas sobre o mesmo baseline. Sobrepor os testes de A à C alteraria a seleção testada e não reproduziria os 2679 casos da candidata. Para usar o roteiro A com C, consultar a pasta A sem copiar seus testes para C. Os manifests trazem hashes de todos os arquivos e o payload de cada versão; HEAD igual não basta.

Após revisão/autorização da execução Windows, seguir `reconstrucao/payload/C/docs/win_01_c/WIN_01_D.md`. O runner C existente valida HEAD, mas não verifica estes manifests: executar explicitamente `reconstruir.py --verificar ... --versao C` antes e depois, registrando saídas no diretório externo de resultados. Guardar também o SHA-256 deste ZIP recebido, seu manifesto e o comando real de teste. Os metadados da venv e pip freeze são necessários; hashes de fonte não autenticam binários/dependências do computador Windows.

## Sonda CP1252 Linux — comando reproduzível, sem alegar Windows

Com a venv preparada explicitamente pelo auditor e a worktree C reconstruída, executar na raiz C (substituir o caminho do interpretador). Não instalar automaticamente pelo runner. O plugin calibra Path.read_text com encoding=locale; não simula NTFS, API Win32, permissões ou privilégios.

```bash
PYTHONUTF8=0 PYTHONPATH="$PWD/src:$PWD/tools/win01c" /caminho/venv/bin/python -m pytest -q -p cp1252_probe -p no:cacheprovider --tb=short tests/test_acl_evidence.py tests/test_private_permissions_regression.py tests/test_windows_compatibility.py
```

Para os 38 nodeids, o JSON preserva parametrizações. Exemplo de invocação sem expansão de shell:

```python
import json, os, pathlib, subprocess, sys
root = pathlib.Path.cwd()
env = os.environ.copy()
env['PYTHONUTF8'] = '0'
env['PYTHONPATH'] = os.pathsep.join([str(root/'src'), str(root/'tools/win01c')])
nodes = list(json.loads((root/'docs/win_01_c/historicos.json').read_text(encoding='utf-8')).values())
subprocess.run([sys.executable, '-m', 'pytest', '-q', '-p', 'cp1252_probe', '-p', 'no:cacheprovider', '--tb=short', *nodes], env=env, check=True)
```

Usar diretório externo para novos JUnit/logs. Os logs Linux ANTES/DEPOIS incluídos são históricos preservados, não serão regenerados sobre os mesmos arquivos. A tentativa inicial de sonda não calibrada foi documentada como ineficaz; não a usar como prova. Para repetir o experimento ANTES, criar outra worktree NOVA apenas na base e usar o plugin auditado por PYTHONPATH externo, sem alterar as worktrees A/C. As falhas esperadas são resultado de diagnóstico, não motivo para relaxar asserts.

## Ensaios desta tarefa

Duas worktrees Linux novas foram reconstruídas e tiveram os 469/441 hashes conferidos. Repetir sobre os mesmos destinos foi recusado antes de alteração. Foram testadas a rejeição de arquivo corrompido e de arquivo extra em um diretório sintético isolado. Nenhuma execução Windows/PowerShell ou suite WIN-01-D foi iniciada.
