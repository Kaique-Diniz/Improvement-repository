# WIN-01-C — auditoria da candidata preservada

Esta inspeção não modifica os 28 arquivos candidatos nem reexecuta WIN-01-D. Os hashes do manifesto anterior foram conferidos antes/depois. A suíte Linux anterior de 2679 aprovações continua sendo o resultado da candidata; os ensaios adicionais desta tarefa verificam apenas reconstrução e integridade.

## Produção: alterações exatas e relação causal

1. `src/conversor/adapters/windows_acl_evidence.py`, funções `_compare_string_ordinal_ignore_case` (linha 90) e `_mesmo_path_normalizado` (122): troca oleaut32 por WinDLL Kernel32; remove LCID/flags indevidos, define os cinco argumentos e restype, conta unidades UTF-16, rejeita NUL/retornos inválidos e captura OSError como não coincidência. O restante do módulo não muda. Ligação direta com os cinco históricos ACL: evidencia_sempre_hardcoded_false, normalizacao_8_3_expande_nome_curto, comparacao_de_caminho_e_case_insensitive_ordinal, hardlink_e_rejeitado_na_comparacao_de_caminho e evidencia_com_baseline_registra_artefato_mas_nao_autoriza. Traceback Windows comum foi relatado pelo usuário; regressões adicionais são sintéticas no Linux. Não integra enforcement de DACL ou autorização ao MVP.

2. `src/conversor/web/app.py`, linhas 78 e 149: exclusivamente encoding=utf-8 em RegistroPrivado.listar e leitura de key_file. O registro teve mojibake reproduzido por teste novo sob CP1252. A chave gerada é ASCII; sua alteração é consistência explícita e não correção de falha histórica demonstrada. Não há demonstração de que essas duas linhas causaram algum dos 38 históricos. Os 19 casos de encoding foram reproduzidos em leituras/escritas implícitas dos próprios testes e fixtures; a correspondência está em CLASSIFICACAO_38.md. Não atribuir automaticamente esses 19 ao arquivo Web.

## Asserções, fixtures, skips e marcadores

Foram comparadas as ASTs antes/depois por função e os multiconjuntos de asserções, removendo apenas argumentos encoding das chamadas read_text/write_text para comparar a lógica. Resultado: 451 asserções anteriores presentes, 466 na candidata, nenhuma removida/substituída/relaxada logicamente. A contagem é estática e inclui asserts de helpers/fixtures, não equivale a casos pytest. Não houve remoção de pytest.raises existente. inventario_testes.json registra as contagens/decoradores por arquivo; o diff integral permite revisão literal.

Isso NÃO significa cobertura nativa igual: duas condições de plataforma e nove cenários de links podem impedir que as mesmas asserções sejam alcançadas. Não foi adicionada marca xfail, não foi alterada parametrização preexistente e não houve remoção de testes. Foram adicionados fixture api_ordinal_sintetica e novos testes parametrizados ACL.

- `test_isolamento_git_links_e_permissoes[permissao_fonte]`: novo skip antes do corpo quando os.name != posix. O pytest.raises(ErroAplicacao) anterior continua no código, mas não executa em Windows. Justificativa: produção só aplica bits mode em POSIX. Resultado Windows é ausência de evidência DACL, não aprovação.
- `test_isolamento_git_links_e_permissoes[permissao_raiz]`: mesma condição e mesma limitação; chmod não comprova ACL NTFS.
- Os nove casos de links abaixo passaram a usar criar_symlink. Somente os.name == nt e winerror == 1314 produzem skip. Essa condição significa capacidade ausente e suprime as asserções posteriores daquele caso; qualquer outro erro propaga. Quando a criação funciona, pytest.raises e asserts originais continuam exigidos. Causa nativa histórica individual ainda não foi comprovada.
- `test_raiz_link_ancestral_e_git_recusados` agrupa vários controles: se houver skip na criação inicial, também deixam de executar as verificações posteriores de diretório privado e Git. Isso é uma ressalva de cobertura residual, não um controle aprovado; uma futura separação dos cenários pode melhorar esse teste, mas não foi feita nesta preservação.
- `test_normalizacao_8_3_expande_nome_curto`: assert original preservado, porém foi removida a chamada condicional real a GetLongPathNameW para um alias PASTA_~1 fictício. A fixture agora deixa sua expansão ao mock, em ambas as plataformas. Justificativa: nome curto real não é garantido por esse literal. Reduz cobertura nativa que não deve ser alegada pelo teste sintético; requer sonda 8.3 real na WIN-01-D.
- Ajuste incidental: o novo import no início de tests/bbz/test_persistent_links.py precede a string descritiva anterior; ela deixa de ser __doc__ do módulo. Não muda asserts nem negócio, mas é uma diferença de metadado de teste a revisar. Não foi corrigida silenciosamente.

## Quatorze casos sem resolução nativa comprovada

Grupo solicitado: nove links, dois de aplicabilidade POSIX e três de causa não demonstrada. Os dois POSIX têm diferença de aplicabilidade identificada por código, não prova de segurança NTFS. Além destes 14, os 19 casos reproduzidos na sonda CP1252 continuam sem confirmação individual da causalidade histórica por traceback Windows. Apenas os cinco ACL têm causa nativa comum relatada explicitamente; nenhuma correção foi revalidada em Windows nesta tarefa.

| Identificador histórico | Categoria e pendência |
|---|---|
| `tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.bbz.test_persistent_links::test_raiz_link_ancestral_e_git_recusados` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.bbz.test_persistent_links::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.phase3.test_private_validation::test_canonicos_so_por_opcao_explicita_na_area_privada` | CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.phase3.test_private_validation::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida` | CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.phase3.test_protected_sources::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[symlink]` | LINKS_CAMINHOS_CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |
| `tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_fonte]` | POSIX_NTFS; DIFERENCA_DE_APLICABILIDADE; DACL_PENDENTE |
| `tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_raiz]` | POSIX_NTFS; DIFERENCA_DE_APLICABILIDADE; DACL_PENDENTE |
| `tests.test_documents::test_auditoria_documental_persiste_em_json_protegido` | CAUSA_NAO_DEMONSTRADA; PENDENTE_WINDOWS |

## Segurança sem evidência suficiente

DACL efetiva de diretórios/arquivos, negação de acesso a outro usuário, isolamento entre processos hostis, disponibilidade de symlinks, rejeição real de junctions/reparse points/hardlinks, normalização 8.3, falhas nativas de IO, atomicidade/locks no NTFS e recuperação após crash continuam pendentes. Não foram modificados private_permissions, billing_authority, protected_sources ou os repositórios privados. Igualdade de ACEs sintéticos, chmod, skips e HTTP local não certificam enforcement Windows. Não há autorização operacional.

## Inventário dos 28 arquivos

| Arquivo | Alteração/justificativa |
|---|---|
| `docs/win_01_c/CLASSIFICACAO_38.md` | Documentar classificacao individual, evidencias, limites ou procedimento de revalidacao. |
| `docs/win_01_c/RELATORIO.md` | Documentar classificacao individual, evidencias, limites ou procedimento de revalidacao. |
| `docs/win_01_c/WIN_01_D.md` | Documentar classificacao individual, evidencias, limites ou procedimento de revalidacao. |
| `docs/win_01_c/classificacao_38.csv` | Documentar classificacao individual, evidencias, limites ou procedimento de revalidacao. |
| `docs/win_01_c/classificacao_38.json` | Documentar classificacao individual, evidencias, limites ou procedimento de revalidacao. |
| `docs/win_01_c/historicos.json` | Documentar classificacao individual, evidencias, limites ou procedimento de revalidacao. |
| `src/conversor/adapters/windows_acl_evidence.py` | Diff diagnostico de 84ab546: ABI Kernel32, UTF16, NUL e erro fail-closed; sem autorizar acesso. |
| `src/conversor/web/app.py` | UTF8 explicito no registro JSON legado e chave local textual; regressao de mojibake reproduzida. |
| `tests/bbz/test_edificio_win.py` | UTF8 explicito em 4 chamadas textuais; assercoes preservadas. |
| `tests/bbz/test_persistent_links.py` | UTF8 explicito em 12 chamadas textuais; assercoes preservadas. Fixture de link usa helper de capacidade sem alterar rejeicao exigida. |
| `tests/evaluation/test_simulation_schema.py` | UTF8 explicito em 3 chamadas textuais; assercoes preservadas. |
| `tests/integrated_processing/test_storage.py` | UTF8 explicito em 8 chamadas textuais; assercoes preservadas. |
| `tests/phase3/test_private_validation.py` | UTF8 explicito em 14 chamadas textuais; assercoes preservadas. |
| `tests/phase3/test_protected_sources.py` | UTF8 explicito em 0 chamadas textuais; assercoes preservadas. Fixture de link usa helper de capacidade sem alterar rejeicao exigida. |
| `tests/private_simulation/test_private_storage.py` | UTF8 explicito em 12 chamadas textuais; assercoes preservadas. Fixture de link usa helper de capacidade sem alterar rejeicao exigida. Dois casos de bits POSIX sao explicitamente inaplicaveis fora POSIX; DACL nao validada. |
| `tests/recognition/test_homologation_harness.py` | UTF8 explicito em 8 chamadas textuais; assercoes preservadas. |
| `tests/rules/test_authority.py` | UTF8 explicito em 15 chamadas textuais; assercoes preservadas. |
| `tests/test_acl_evidence.py` | Regressoes recuperadas do mesmo commit para assinatura Win32, Unicode, NUL e erros; nao prova execucao nativa. |
| `tests/test_cli_and_schemas.py` | UTF8 explicito em 2 chamadas textuais; assercoes preservadas. |
| `tests/test_documents.py` | UTF8 explicito em 1 chamadas textuais; assercoes preservadas. |
| `tests/test_export.py` | UTF8 explicito em 1 chamadas textuais; assercoes preservadas. |
| `tests/test_windows_compatibility.py` | Regressoes sinteticas de JSON CP1252 e comportamento do helper de symlinks. |
| `tests/web/test_habita_diagnostic_closing.py` | UTF8 explicito em 2 chamadas textuais; assercoes preservadas. |
| `tests/web/test_template_identifiers.py` | UTF8 explicito em 3 chamadas textuais; assercoes preservadas. |
| `tests/windows_support.py` | Disponibilidade de symlink: skip somente winerror 1314 Windows; outros erros nao sao ocultados. |
| `tools/win01c/ambiente.py` | Preparar revalidacao Windows sem instalar dependencias ou mudar politicas; evidencia externa ao Git. |
| `tools/win01c/cp1252_probe.py` | Sonda calibrada de codificacao para isolar a hipotese CP1252 em Linux. |
| `tools/win01c/validar.ps1` | Preparar revalidacao Windows sem instalar dependencias ou mudar politicas; evidencia externa ao Git. |

## Diferenças Linux/Windows e resultados

Linux usa caminho POSIX e locale UTF-8 mesmo com PYTHONUTF8=0. A sonda altera apenas io.open/Path e não substitui DLLs, NTFS ou segurança. Kernel32 é real apenas na futura execução Windows; no Linux os testes de ABI usam fake. Symlink 1314 e ignores POSIX surgem somente quando aplicáveis no Windows. Nenhum skip ocorreu na suíte Linux de 2679 casos. Os 749 casos dos seis perfis e 43 focados se sobrepõem à suíte; não somá-los.

## Identidade da versão e preservação

A candidata possui 441 arquivos esperados (baseline completo mais os 28 deltas); A revisada possui 469 (baseline mais 39 artefatos revisados). versao_A.json e versao_C.json listam SHA-256 de todos os arquivos, não só HEAD. O pacote fornece payloads dos deltas e reconstruir.py. Foram reconstruídas e verificadas duas worktrees Linux novas com todos os hashes. Isso valida o procedimento em Linux, não a execução PowerShell/Windows. Não se sobrepõem A e C, para preservar a seleção de 2679 testes da candidata. O runner C existente confere HEAD, mas NÃO verifica sozinho esses manifestos: executar o verificador externo antes e depois de cada rodada Windows e guardar os resultados fora do Git.
