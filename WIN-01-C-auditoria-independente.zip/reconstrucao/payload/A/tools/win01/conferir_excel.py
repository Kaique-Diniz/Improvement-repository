"""Confere XLSX A/B; separa finanças, endereço e procedência sem expor dados privados."""
from collections import Counter
from datetime import date
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sys
from zipfile import BadZipFile

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
from conversor.domain.template import COLUNAS

PERFIS = ('passaredo', 'forest_hill', 'parque_santa_monica', 'vero_encanto', 'itajuba', 'terraco_beach_parque')
ADDR_INDEX = (4, 5, 7, 8, 9, 10)
ADDR_FIELDS = ('logradouro', 'numero', 'cep', 'bairro', 'cidade', 'uf')


class ErroConferencia(ValueError):
    """Somente códigos constantes definidos neste módulo, nunca conteúdo da entrada."""


def motivo_seguro(exc):
    if isinstance(exc, ErroConferencia):
        return exc.args[0]
    if isinstance(exc, FileExistsError):
        return 'ARQUIVO_SAIDA_JA_EXISTE'
    if isinstance(exc, FileNotFoundError):
        return 'ARQUIVO_NAO_ENCONTRADO'
    if isinstance(exc, PermissionError):
        return 'ACESSO_NEGADO'
    if isinstance(exc, (json.JSONDecodeError, UnicodeError)):
        return 'JSON_OU_CODIFICACAO_INVALIDA'
    if isinstance(exc, (BadZipFile, InvalidFileException)):
        return 'XLSX_INVALIDO'
    if isinstance(exc, OSError):
        return 'FALHA_IO'
    return 'ERRO_DE_CONFERENCIA'


def outside_git(path):
    path = Path(path).resolve()
    return not any((parent / '.git').exists() for parent in (path, *path.parents))


def read_sheet(path):
    if not outside_git(path):
        raise ErroConferencia('ENTRADA_DENTRO_DO_GIT')
    workbook = load_workbook(path, read_only=True, data_only=False, keep_links=False)
    try:
        if 'Dados' not in workbook.sheetnames:
            raise ErroConferencia('ABA_DADOS_AUSENTE')
        sheet = workbook['Dados']
        if sheet.max_column != 30:
            raise ErroConferencia('COLUNAS_INVALIDAS')
        cells = list(sheet.iter_rows())
        if not cells or tuple(c.value for c in cells[0]) != COLUNAS:
            raise ErroConferencia('CABECALHO_INVALIDO')
        if any(c.data_type == 'f' for row in cells for c in row):
            raise ErroConferencia('FORMULA_NAO_PERMITIDA')
        rows = [tuple(c.value for c in row) for row in cells[1:] if any(c.value is not None for c in row)]
        if any(r[2] is not None and not isinstance(r[2], str) for r in rows):
            raise ErroConferencia('DOCUMENTO_NAO_TEXTUAL')
        return rows
    finally:
        workbook.close()


def consolidar_estados(statuses):
    # Reprovação comprovada não pode ser ocultada por outro eixo pendente.
    if 'REPROVADO' in statuses:
        return 'REPROVADO'
    if any(s != 'APROVADO' for s in statuses):
        return 'BLOQUEADO'
    return 'APROVADO'


def check_pair(a_path, b_path, expected, address=None):
    if not isinstance(expected, dict) or any(type(expected.get(k)) is not int or expected[k] < 0
                                            for k in ('elegiveis_a', 'linhas_b', 'adicionais_b')):
        raise ErroConferencia('EXPECTATIVAS_INVALIDAS')
    if address is not None and (not isinstance(address, dict) or any(k not in address for k in ADDR_FIELDS)):
        raise ErroConferencia('ENDERECO_ESPERADO_INCOMPLETO')
    a, b = read_sheet(a_path), read_sheet(b_path)
    financial_a = [r for r in a if r[29] is not None]
    financial_b = [r for r in b if r[29] is not None]
    try:
        values = [Decimal(str(r[29])) for r in financial_a + financial_b]
        if any(not v.is_finite() for v in values):
            raise InvalidOperation
        total = sum(values[:len(financial_a)], Decimal(0))
        expected_total = Decimal(str(expected['total_original'])) if 'total_original' in expected else None
        if expected_total is not None and not expected_total.is_finite():
            raise InvalidOperation
    except InvalidOperation:
        raise ErroConferencia('VALOR_FINANCEIRO_INVALIDO') from None
    checks = {
        '30_colunas_e_cabecalhos': True,
        'financeiro_ab_identico': Counter(financial_a) == Counter(financial_b),
        'a_sem_linhas_cadastrais': len(a) == len(financial_a),
        'elegiveis_a': len(financial_a) == expected['elegiveis_a'],
        'linhas_b': len(b) == expected['linhas_b'],
        'adicionais_b': len(b) - len(financial_b) == expected['adicionais_b'],
    }
    financial_status = 'APROVADO' if all(checks.values()) else 'REPROVADO'
    total_status = 'NAO_EXECUTADO'
    if expected_total is not None:
        checks['total_original'] = total == expected_total
        total_status = 'APROVADO' if checks['total_original'] else 'REPROVADO'
    address_status = 'NAO_EXECUTADO'
    if address is not None:
        target = tuple(address[n] for n in ADDR_FIELDS)
        checks['endereco_todas_linhas_ab'] = bool(a and b) and all(tuple(row[i] for i in ADDR_INDEX) == target for row in a + b)
        address_status = 'APROVADO' if checks['endereco_todas_linhas_ab'] else 'REPROVADO'
    axes = {'financeiro_ab': financial_status, 'total_original_esperado': total_status,
            'endereco': address_status, 'procedencia_independente': 'NAO_COMPROVADA'}
    reasons = []
    if financial_status == 'REPROVADO':
        reasons.append('DIVERGENCIA_FINANCEIRA_OU_CONTRATUAL')
    if total_status == 'NAO_EXECUTADO':
        reasons.append('TOTAL_ORIGINAL_SEM_REFERENCIA')
    elif total_status == 'REPROVADO':
        reasons.append('TOTAL_ORIGINAL_DIVERGENTE')
    if address_status == 'NAO_EXECUTADO':
        reasons.append('ENDERECO_NAO_VERIFICADO')
    elif address_status == 'REPROVADO':
        reasons.append('ENDERECO_DIVERGENTE')
    reasons.append('PROCEDENCIA_SEM_COMPROVACAO_INDEPENDENTE')
    return {'status': consolidar_estados(list(axes.values())), 'financeiro': 'REPROVADO' if total_status == 'REPROVADO' else financial_status,
            'financeiro_completo': consolidar_estados([financial_status, total_status]),
            'verificacao_completa': False, 'eixos': axes, 'motivos': reasons, 'checks': checks,
            'elegiveis_a': len(financial_a), 'linhas_b': len(b), 'adicionais_b': len(b) - len(financial_b),
            'total_original': str(total), 'endereco': address_status,
            'sha256_a': hashlib.sha256(a_path.read_bytes()).hexdigest(),
            'sha256_b': hashlib.sha256(b_path.read_bytes()).hexdigest()}


def placeholder(value):
    if not isinstance(value, str) or not value.strip():
        return True
    return bool(re.search(r'PREENCHER|PLACEHOLDER|SUBSTITUIR|TODO|EXEMPLO|<[^>]*>', value, re.IGNORECASE))


def validar_proveniencia_declarada(manifest, item):
    head, evidence = manifest.get('head_execucao'), item.get('evidencia_execucao')
    if placeholder(head) or placeholder(evidence):
        raise ErroConferencia('PROVENIENCIA_AUSENTE_OU_PLACEHOLDER')
    if not re.fullmatch(r'[0-9a-fA-F]{40}', head) or len(set(head.lower())) == 1:
        raise ErroConferencia('HEAD_DECLARADO_INVALIDO')
    try:
        ref = item.get('data_ref')
        if not isinstance(ref, str) or date.fromisoformat(ref).isoformat() != ref:
            raise ValueError
    except ValueError:
        raise ErroConferencia('DATA_REFERENCIA_INVALIDA') from None
    if any(placeholder(item.get(key)) for key in ('a', 'b')):
        raise ErroConferencia('CAMINHO_ENTRADA_AUSENTE_OU_PLACEHOLDER')
    # Validade formal não autentica autoria, data ou origem do XLSX.
    # Mesmo um campo "comprovada": true autodeclarado não é prova independente.


def conferir_manifesto(manifest_path):
    if not outside_git(manifest_path):
        raise ErroConferencia('MANIFESTO_DENTRO_DO_GIT')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    if not isinstance(manifest, dict) or not isinstance(manifest.get('perfis'), dict):
        raise ErroConferencia('ESTRUTURA_MANIFESTO_INVALIDA')
    result = {'origem': 'conferencia de arquivos fornecidos nesta rodada', 'homologacao': False,
              'verificacao_completa': False, 'procedencia_independente': 'NAO_COMPROVADA', 'perfis': {}}
    for profile in PERFIS:
        item = manifest['perfis'].get(profile)
        if not isinstance(item, dict):
            result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': 'PAR_A_B_AUSENTE'}
            continue
        try:
            validar_proveniencia_declarada(manifest, item)
            paths = [Path(item[key]).resolve() for key in ('a', 'b')]
            result['perfis'][profile] = check_pair(*paths, item.get('esperado'), item.get('endereco'))
            result['perfis'][profile]['data_ref'] = item['data_ref']
            result['perfis'][profile]['proveniencia_declarada'] = 'VALIDADA_FORMALMENTE'
        except Exception as exc:
            result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': motivo_seguro(exc),
                                        'verificacao_completa': False}
    result['status'] = consolidar_estados([r['status'] for r in result['perfis'].values()])
    return result


def main():
    try:
        manifest_path, output = map(Path, sys.argv[1:])
        if not outside_git(output):
            raise ErroConferencia('RELATORIO_DENTRO_DO_GIT')
        try:
            result = conferir_manifesto(manifest_path)
        except Exception as exc:
            result = {'status': 'BLOQUEADO', 'motivo': motivo_seguro(exc),
                      'verificacao_completa': False, 'homologacao': False}
        with output.open('x', encoding='utf-8') as stream:
            json.dump(result, stream, indent=2, ensure_ascii=True)
            stream.write('\n')
    except Exception as exc:
        print(json.dumps({'status': 'BLOQUEADO', 'motivo': motivo_seguro(exc)}))
        return 2
    print(result['status'])
    return {'APROVADO': 0, 'REPROVADO': 1, 'BLOQUEADO': 2}[result['status']]


if __name__ == '__main__':
    raise SystemExit(main())
