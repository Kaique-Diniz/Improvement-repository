"""Inventário estático: não executa testes; saída nova, sem sobrescrita."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    scopes = json.loads((root / 'docs/win_01_a/escopos.json').read_text(encoding='utf-8'))
    records = []
    for path in sorted((root / 'tests').rglob('test_*.py')):
        rel = path.relative_to(root).as_posix()
        raw = path.read_bytes()
        tree = ast.parse(raw, filename=rel)
        records.append({
            'path': rel, 'sha256': hashlib.sha256(raw).hexdigest(),
            'integrada': any(rel == p or rel.startswith(p + '/') for p in scopes['integrada']),
            'definitions': [{'name': node.name, 'line': node.lineno}
                            for node in ast.walk(tree)
                            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                            and node.name.startswith('test_')],
        })
    payload = {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'kind': 'inventario estatico; parametrizacoes exigem pytest --collect-only',
        'files': records,
    }
    with args.output.open('x', encoding='utf-8') as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
