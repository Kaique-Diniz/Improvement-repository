"""Sonda nativa 8.3; não modifica configuração do volume ou o aplicativo."""
import ctypes
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
p = root / 'Arquivo_Sintetico_Com_Nome_Longo.txt'
p.write_text('WIN01A-SINTETICO', encoding='utf-8')
result = {'8_3': 'NAO_EXECUTADO', 'normalizacao': 'NAO_EXECUTADO', 'politica_aplicativo': 'NAO_EXECUTADO'}
try:
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    short = kernel.GetShortPathNameW
    short.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint]
    short.restype = ctypes.c_uint
    long = kernel.GetLongPathNameW
    long.argtypes = short.argtypes
    long.restype = ctypes.c_uint
    buffer = ctypes.create_unicode_buffer(32768)
    n = short(str(p), buffer, len(buffer))
    if not n or n >= len(buffer):
        result['8_3'] = 'BLOQUEADO'
    elif buffer.value == str(p):
        result['8_3'] = 'BLOQUEADO'
        result['motivo'] = 'NOME_CURTO_NAO_DISPONIVEL'
    else:
        result['8_3'] = 'APROVADO'
        expanded = ctypes.create_unicode_buffer(32768)
        n = long(buffer.value, expanded, len(expanded))
        result['normalizacao'] = 'APROVADO' if n and n < len(expanded) and expanded.value.casefold() == str(p).casefold() else 'REPROVADO'
except (OSError, AttributeError):
    result['8_3'] = 'BLOQUEADO'
print(json.dumps(result))
