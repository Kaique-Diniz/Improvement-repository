"""Compila em memória, sem gravar pyc ou alterar o checkout."""
from pathlib import Path

root = Path(__file__).resolve().parents[2]
count = 0
for folder in ('src', 'tests', 'tools/win01'):
    for path in (root / folder).rglob('*.py'):
        compile(path.read_bytes(), str(path), 'exec')
        count += 1
print('APROVADO:', count, 'arquivos Python compilados em memoria')
