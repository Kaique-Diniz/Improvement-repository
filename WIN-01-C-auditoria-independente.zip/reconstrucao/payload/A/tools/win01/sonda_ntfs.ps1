[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ProbeRoot)
$ErrorActionPreference = 'Stop'
# Diretório novo criado pelo runner. Somente conteúdo sintético e nenhuma mudança de ACL.
$Root = (Resolve-Path -LiteralPath $ProbeRoot).Path
$Result = [ordered]@{politica_acl_efetiva='NAO_EXECUTADO'; isolamento_outro_usuario='NAO_EXECUTADO'; seguranca_integrada='NAO_EXECUTADO'}
try {
    $Drive = New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($Root))
    $Result.sistema_arquivos = $Drive.DriveFormat
    $Result.ntfs = if ($Drive.DriveFormat -eq 'NTFS') {'APROVADO'} else {'BLOQUEADO'}
} catch { $Result.ntfs = 'BLOQUEADO' }
try {
    $Acl = Get-Acl -LiteralPath $Root
    $Result.leitura_acl = 'APROVADO'
    $Result.dacl_protegida = $Acl.AreAccessRulesProtected
    $Result.ace_count = @($Acl.Access).Count
    # Não exportar nomes de contas nem SIDs; leitura não comprova política efetiva.
} catch { $Result.leitura_acl = 'BLOQUEADO' }
$Source = Join-Path $Root 'origem.txt'
[IO.File]::WriteAllText($Source, 'WIN01A-SINTETICO')
foreach ($Type in @('HardLink','SymbolicLink','Junction')) {
    try {
        $Target = $Source
        if ($Type -eq 'Junction') {
            $Target = Join-Path $Root 'alvo-junction'
            New-Item -ItemType Directory -Path $Target | Out-Null
        }
        $Link = Join-Path $Root $Type
        New-Item -ItemType $Type -Path $Link -Target $Target -ErrorAction Stop | Out-Null
        $Item = Get-Item -LiteralPath $Link -Force
        $Result[$Type] = @{status='APROVADO'; reparse_point=[bool]($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)}
    } catch { $Result[$Type] = @{status='BLOQUEADO'; motivo='CRIACAO_INDISPONIVEL_SEM_ELEVACAO'} }
}
$Result.observacao = 'Sonda em diretorio proprio; nao altera politica, nao autoriza aplicativo, nao testa outro usuario. Artefatos sinteticos preservados nesta rodada.'
$Result | ConvertTo-Json -Depth 5
