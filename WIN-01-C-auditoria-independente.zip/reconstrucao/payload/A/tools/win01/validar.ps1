[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$EvidenceRoot,
    [ValidateSet('rapida','nativa','completa','excel')][string]$Etapa = 'rapida',
    [string]$ManifestoExcel
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Executar somente em Windows nativo.' }
$Python = (Get-Command $Python -ErrorAction Stop).Source
$Params = @((Join-Path $PSScriptRoot 'executar.py'), '--evidence-root', $EvidenceRoot, '--etapa', $Etapa)
if ($ManifestoExcel) { $Params += @('--manifesto-excel', $ManifestoExcel) }
& $Python @Params
exit $LASTEXITCODE
