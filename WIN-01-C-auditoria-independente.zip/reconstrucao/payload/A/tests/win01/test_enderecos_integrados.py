"""WIN-01-A: endereços efêmeros A/B dos seis perfis; somente dados sintéticos."""
from io import BytesIO

import pytest
from fastapi.testclient import TestClient
from openpyxl import load_workbook

from conversor.domain.template import COLUNAS
from conversor.web.ephemeral import criar_app_efemero
from tests.int02.fixtures import PERFIS, caso, homologar
from tests.web.test_classic_local import ADDRESS, ORIGIN, boot


@pytest.mark.parametrize('perfil', PERFIS)
def test_endereco_seis_perfis_modos_ab_sem_mudar_financeiro(tmp_path, monkeypatch, perfil):
    c = caso(perfil)
    homologar(monkeypatch, [c])
    app = criar_app_efemero(area_temporaria=tmp_path)
    with TestClient(app, base_url=ORIGIN) as client:
        boot(client)
        found = client.post('/api/identificar', files={'inadimplencia': ('falso.' + c.ext, c.financeiro)})
        assert found.status_code == 200
        context = found.json()['contexto']
        url = '/api/contextos/' + context + '/configuracao'
        observed = {}
        for configured in (False, True):
            if configured:
                payload = {'revisao_esperada': 0, 'endereco': ADDRESS, 'mapeamentos': []}
                assert client.put(url, json=payload).status_code == 200
                # Recarregar configuração pela API usada pelo botão; contexto permanece.
                assert client.get(url).json()['endereco']['logradouro'] == ADDRESS['logradouro']
                assert client.put(url, json=payload | {'condominio_id': 'outro'}).status_code == 422
            for mode in ('A', 'B'):
                result = client.post('/api/conversoes', data={
                    'data_ref': str(c.ref), 'modo': mode, 'condominio': perfil, 'contexto': context,
                }, files={'inadimplencia': ('falso.' + c.ext, c.financeiro),
                          'cadastro': ('falso.' + c.ext_cad, c.cadastro)})
                assert result.status_code == 200
                raw = client.get('/api/conversoes/' + result.json()['id'] + '/excel')
                assert raw.status_code == 200
                workbook = load_workbook(BytesIO(raw.content))
                try:
                    rows = list(workbook['Dados'].values)
                finally:
                    workbook.close()
                assert rows[0] == COLUNAS
                assert len(rows) == 2 + int(mode == 'B')
                financial = [row for row in rows[1:] if row[29] is not None]
                # Endereço altera só seis campos administrativos; demais células iguais.
                invariant = [tuple(v for i, v in enumerate(row) if i not in (4, 5, 7, 8, 9, 10)) for row in financial]
                observed[configured, mode] = invariant
                if configured:
                    expected = tuple(ADDRESS[n] for n in ('logradouro', 'numero', 'cep', 'bairro', 'cidade', 'uf'))
                    assert all(tuple(row[i] for i in (4, 5, 7, 8, 9, 10)) == expected for row in rows[1:])
        assert observed[False, 'A'] == observed[False, 'B'] == observed[True, 'A'] == observed[True, 'B']
        # Sessão nova não consulta o contexto antigo nem herda seu endereço.
        assert client.delete('/api/sessao').status_code in (200, 204)
        boot(client)
        assert client.get(url).status_code == 404
        again = client.post('/api/identificar', files={'inadimplencia': ('falso.' + c.ext, c.financeiro)})
        new_url = '/api/contextos/' + again.json()['contexto'] + '/configuracao'
        assert not client.get(new_url).json()['endereco']
    assert not any(path.is_file() for path in tmp_path.rglob('*'))
