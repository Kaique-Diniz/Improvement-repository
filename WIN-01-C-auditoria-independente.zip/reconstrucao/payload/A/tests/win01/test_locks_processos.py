"""Lock real entre processos sob o mesmo usuário; não certifica DACL ou usuário hostil."""
import subprocess
import sys

from filelock import FileLock


def test_lock_real_impede_segundo_processo_ate_liberacao(tmp_path):
    lock = tmp_path / 'somente_sintetico.lock'
    code = '''
import sys
from filelock import FileLock, Timeout
try:
    with FileLock(sys.argv[1], timeout=0.2):
        print('ADQUIRIDO')
except Timeout:
    print('BLOQUEADO_POR_LOCK')
'''
    with FileLock(lock, timeout=2):
        blocked = subprocess.run([sys.executable, '-c', code, str(lock)], capture_output=True, text=True, timeout=10)
        assert blocked.returncode == 0
        assert blocked.stdout.strip() == 'BLOQUEADO_POR_LOCK'
    released = subprocess.run([sys.executable, '-c', code, str(lock)], capture_output=True, text=True, timeout=10)
    assert released.returncode == 0
    assert released.stdout.strip() == 'ADQUIRIDO'
