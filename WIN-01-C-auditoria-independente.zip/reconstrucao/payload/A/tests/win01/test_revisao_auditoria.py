"""Regressões da auditoria WIN-01-A: estados parciais, procedência e motivos seguros."""
import json
from pathlib import Path
import subprocess
import sys

import pytest

from tools.win01.conferir_excel import (PERFIS, check_pair, conferir_manifesto,
    consolidar_estados, motivo_seguro)
from tools.win01.executar import classificar_passo, motivo_execucao
from tests.win01.test_conferencia_excel import sheet

ROOT = Path(__file__).resolve().parents[2]


def inputs(tmp_path):
    a, b = tmp_path / 'a.xlsx', tmp_path / 'b.xlsx'
    row = [None] * 30
    row[3], row[29] = 'Pessoa Inteiramente Ficticia', 100
    fields = {'logradouro': 'Rua Ficticia', 'numero': '1', 'cep': '00000001',
              'bairro': 'Bairro Ficticio', 'cidade': 'Cidade Ficticia', 'uf': 'SP'}
    for i, value in zip((4, 5, 7, 8, 9, 10), fields.values()):
        row[i] = value
    sheet(a, [row]); sheet(b, [row])
    expected = {'elegiveis_a': 1, 'linhas_b': 1, 'adicionais_b': 0, 'total_original': '100'}
    return a, b, expected, fields


def manifest_file(tmp_path):
    a, b, expected, fields = inputs(tmp_path)
    item = {'a': str(a), 'b': str(b), 'data_ref': '2026-11-09', 'evidencia_execucao': 'rodada-20261110-123609',
            'esperado': expected, 'endereco': fields}
    data = {'head_execucao': '770d062d29c4361d6932592883df9339bb4089bc',
            'perfis': {profile: dict(item) for profile in PERFIS}}
    path = tmp_path / 'manifesto.json'
    return path, data


def test_eixos_financeiros_aprovados_nao_aprovam_procedencia(tmp_path):
    a, b, expected, fields = inputs(tmp_path)
    result = check_pair(a, b, expected, fields)
    assert result['financeiro'] == result['endereco'] == 'APROVADO'
    assert result['eixos']['total_original_esperado'] == 'APROVADO'
    assert result['eixos']['procedencia_independente'] == 'NAO_COMPROVADA'
    assert result['status'] == 'BLOQUEADO' and not result['verificacao_completa']


def test_total_ausente_e_endereco_ausente_permanecem_pendentes(tmp_path):
    a, b, expected, _ = inputs(tmp_path)
    expected.pop('total_original')
    result = check_pair(a, b, expected)
    assert result['financeiro'] == 'APROVADO'
    assert result['eixos']['total_original_esperado'] == 'NAO_EXECUTADO'
    assert result['endereco'] == 'NAO_EXECUTADO'
    assert {'TOTAL_ORIGINAL_SEM_REFERENCIA', 'ENDERECO_NAO_VERIFICADO'} <= set(result['motivos'])


@pytest.mark.parametrize('field,value,code', [
    ('head_execucao', 'PREENCHER_COM_HEAD_REAL_DA_RODADA', 'PROVENIENCIA_AUSENTE_OU_PLACEHOLDER'),
    ('head_execucao', '0' * 40, 'HEAD_DECLARADO_INVALIDO'),
    ('evidencia_execucao', 'PREENCHER_ID_DA_RODADA', 'PROVENIENCIA_AUSENTE_OU_PLACEHOLDER'),
    ('data_ref', '09/11/2026', 'DATA_REFERENCIA_INVALIDA'),
    ('a', 'PREENCHER_CAMINHO_ABSOLUTO_XLSX_A', 'CAMINHO_ENTRADA_AUSENTE_OU_PLACEHOLDER'),
])
def test_placeholders_e_proveniencia_invalida_recusados(tmp_path, field, value, code):
    path, data = manifest_file(tmp_path)
    if field == 'head_execucao':
        data[field] = value
    else:
        data['perfis']['passaredo'][field] = value
    path.write_text(json.dumps(data))
    result = conferir_manifesto(path)
    assert result['perfis']['passaredo']['motivo'] == code
    assert result['status'] == 'BLOQUEADO'


def test_autodeclaracao_nao_e_comprovacao_independente(tmp_path):
    path, data = manifest_file(tmp_path)
    for item in data['perfis'].values():
        item['procedencia_comprovada'] = True
    path.write_text(json.dumps(data))
    result = conferir_manifesto(path)
    assert result['procedencia_independente'] == 'NAO_COMPROVADA'
    assert result['status'] == 'BLOQUEADO'
    assert all(r['proveniencia_declarada'] == 'VALIDADA_FORMALMENTE' for r in result['perfis'].values())


def test_motivos_sem_caminhos_ou_conteudo_privado(tmp_path):
    path, data = manifest_file(tmp_path)
    data['perfis']['passaredo']['a'] = str(tmp_path / 'SEGREDO_PESSOAL_NAO_EXIBIR.xlsx')
    path.write_text(json.dumps(data))
    result = conferir_manifesto(path)
    assert result['perfis']['passaredo']['motivo'] == 'ARQUIVO_NAO_ENCONTRADO'
    assert 'SEGREDO_PESSOAL' not in json.dumps(result)
    assert motivo_seguro(PermissionError('/caminho/privado')) == 'ACESSO_NEGADO'
    assert motivo_seguro(ValueError('documento pessoal')) == 'ERRO_DE_CONFERENCIA'
    assert motivo_execucao(FileNotFoundError('/caminho/privado')) == 'EXECUTAVEL_OU_ARQUIVO_AUSENTE'
    assert motivo_execucao(subprocess.TimeoutExpired('comando privado', 1)) == 'TEMPO_LIMITE_EXCEDIDO'


def test_cli_bloqueado_retorna_json_sem_traceback(tmp_path):
    path = tmp_path / 'manifesto.json'; path.write_text('{invalido')
    output = tmp_path / 'relatorio.json'
    result = subprocess.run([sys.executable, str(ROOT / 'tools/win01/conferir_excel.py'), str(path), str(output)],
                            capture_output=True, text=True, timeout=20)
    assert result.returncode == 2 and not result.stderr
    assert json.loads(output.read_text())['motivo'] == 'JSON_OU_CODIFICACAO_INVALIDA'


def test_reprovacao_nao_e_ocultada_por_eixo_pendente():
    assert consolidar_estados(['REPROVADO', 'NAO_EXECUTADO']) == 'REPROVADO'
    assert classificar_passo('excel', 2) == ('BLOQUEADO', 'CONFERENCIA_EXCEL_INCOMPLETA')
    assert classificar_passo('pytest', 1) == ('REPROVADO', 'TESTES_REPROVADOS')
    assert classificar_passo('coleta', 5) == ('BLOQUEADO', 'COLETA_NAO_CONCLUIDA')


def test_escopo_rapido_nao_mascara_acl_nativo():
    scopes = json.loads((ROOT / 'docs/win_01_a/escopos.json').read_text())
    assert 'tests/test_acl_evidence.py' not in scopes['integrada']
    assert 'tests/test_acl_evidence.py' in scopes['nativa']
    assert 'tests/test_acl_evidence.py' in scopes['acl']
    assert scopes['completa'] == ['tests']


def test_cli_nao_sobrescreve_relatorio_existente(tmp_path):
    path, data = manifest_file(tmp_path); path.write_text(json.dumps(data))
    output = tmp_path / 'relatorio.json'; output.write_text('EVIDENCIA_ANTERIOR')
    result = subprocess.run([sys.executable, str(ROOT / 'tools/win01/conferir_excel.py'), str(path), str(output)],
                            capture_output=True, text=True, timeout=20)
    assert result.returncode == 2 and not result.stderr
    assert json.loads(result.stdout)['motivo'] == 'ARQUIVO_SAIDA_JA_EXISTE'
    assert output.read_text() == 'EVIDENCIA_ANTERIOR'


def test_modelo_distribuido_e_recusado_antes_de_abrir_fontes(tmp_path):
    path = tmp_path / 'manifesto.json'
    path.write_bytes((ROOT / 'docs/win_01_a/manifesto_excel.exemplo.json').read_bytes())
    result = conferir_manifesto(path)
    assert result['status'] == 'BLOQUEADO'
    assert all(p['motivo'] == 'PROVENIENCIA_AUSENTE_OU_PLACEHOLDER' for p in result['perfis'].values())


def test_total_original_divergente_reprova_financas(tmp_path):
    a, b, expected, fields = inputs(tmp_path)
    expected['total_original'] = '101'
    result = check_pair(a, b, expected, fields)
    assert result['eixos']['financeiro_ab'] == 'APROVADO'
    assert result['financeiro'] == result['financeiro_completo'] == result['status'] == 'REPROVADO'
    assert result['endereco'] == 'APROVADO'
    assert not result['verificacao_completa']
