# WIN-01-A — roteiro reproduzível em Windows

Somente diagnóstico; não autoriza operação, CRM, cobrança ou publicação. Não importar Excel no sistema final. Os scripts não instalam dependências nem alteram políticas de segurança. Usar PowerShell sem elevação; não mudar ExecutionPolicy para rodá-los. Se a política local impedir execução, registrar BLOQUEADO e submeter o script à revisão local.

## 1. Worktree e dependências

Em um checkout já existente do repositório, preparar uma worktree isolada (o destino precisa ser novo):

```powershell
# Diretório do próprio usuário; não requer escrita na raiz de C:\.
$RaizWin01 = Join-Path $env:LOCALAPPDATA 'ConversorWIN01'
$CheckoutWin01 = Join-Path $RaizWin01 'checkout'
$VenvWin01 = Join-Path $RaizWin01 'venv'
$EvidenceWin01 = Join-Path $RaizWin01 'Resultados'
$PrivadoWin01 = Join-Path $RaizWin01 'Privado'
New-Item -ItemType Directory -Force -Path $RaizWin01, $EvidenceWin01, $PrivadoWin01 | Out-Null
# Executar a partir de um checkout existente; $CheckoutWin01 precisa ser novo.
git cat-file -t 770d062d29c4361d6932592883df9339bb4089bc
git worktree add --detach "$CheckoutWin01" 770d062d29c4361d6932592883df9339bb4089bc
Set-Location "$CheckoutWin01"
py -3.12 -m venv "$VenvWin01"
$PythonWin01 = Join-Path $VenvWin01 'Scripts\python.exe'
& $PythonWin01 -m pip install -e ".[test,web]"
& $PythonWin01 -m pip check
```

Se o objeto estiver ausente, obter somente o SHA com `git fetch --no-tags origin 770d062d29c4361d6932592883df9339bb4089bc` e repetir a criação. Não fazer checkout sobre BPQ-04 nem aplicar o commit completo 84ab546. Instalação é ação explícita do usuário; o script não a automatiza.

Copiar o conteúdo do pacote de preparação (docs, tools, tests/win01) para o checkout **sem sobrescrever arquivos preexistentes**. Antes, conferir status e listar as colisões de nomes. Se já houver WIN-01-A local, preservar e comparar primeiro. Não copiar a venv Linux ou documentos reais. Conferir HEAD e `git status --short`.

## 2. Etapas PowerShell

```powershell
# Reutilizar $PythonWin01 e $EvidenceWin01 definidos acima.
& .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa rapida
& .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa nativa
& .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa completa
```

Cada chamada cria uma rodada única fora de qualquer checkout Git. Recusa HEAD diferente e Python diferente de Windows/3.12. Não usa administrador, não instala pacotes, não aplica correções, não remove evidências anteriores. O HEAD continua na base com o defeito ACL conhecido. A aprovação rápida não remove esse bloqueador de homologação.

- **Rápida:** versões, Git, dependências, sintaxe em memória, inventário SHA-256, coleta e escopo integrado dos seis perfis, excluindo `tests/test_acl_evidence.py`; inclui autoteste de geração/conferência XLSX.
- **Nativa:** sonda de filesystem/NTFS, leitura ACL sem contas/SIDs no resumo, criação de hardlink/symlink/junction, caminho 8.3 e testes ACL/permissões/armazenamento disponíveis, incluindo todo `tests/test_acl_evidence.py` com as cinco falhas históricas conhecidas. A pasta da sonda é nova e preserva somente arquivos sintéticos. Registrar controles ausentes. Sonda de leitura não comprova segurança efetiva.
- **Completa:** coleta e suíte pytest integral, JUnit e totais estruturados, códigos de saída, Git inicial/final. `passed = tests - failures - errors - skipped`; warning completo fica no log pytest.

Todas as etapas usam `-X utf8` explicitamente. Não equivalem à execução histórica sem UTF-8. O comando histórico exato com `-X utf8`, que obteve 106 aprovações, está preservado em `docs/win_01_a/EVIDENCIAS_USUARIO.md`. Eventual comparação sem UTF-8 deve ficar em outra rodada explicitamente identificada; não foi executada nesta revisão. Não confundir essa seleção histórica com o novo escopo rápido.

`relatorio.json` distingue APROVADO, REPROVADO e BLOQUEADO; código 0/1/2 respectivamente. Aprovação se refere somente à execução da etapa. Skips exigem revisão, e controles sem evidência não ficam aprovados na matriz. Logs pytest e diffs são privados e podem incluir contexto de falha; não anexá-los ao Git. Os resumos Excel não imprimem pessoas, documentos ou contatos.

## 3. Conferência Excel privada

Copiar `docs/win_01_a/manifesto_excel.exemplo.json` para fora do Git. Preencher caminhos absolutos dos XLSX A e B de cada perfil, HEAD realmente executado, identificador da rodada, data_ref, expectativas e, se disponível, os seis campos de endereço configurados. O exemplo contém **referências fornecidas pelo usuário para 09/11/2026**, não resultados produzidos pelo script. Não usá-las para fixtures ou data diferente.

```powershell
& .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa excel -ManifestoExcel (Join-Path $PrivadoWin01 'manifesto.json')
```

A ferramenta abre arquivos em modo leitura, exige 30 colunas e cabeçalhos literais, rejeita fórmulas/documento numérico, compara financeiramente A/B preservando multiplicidades e verifica contagens/totais/endereço quando fornecidos. Não grava cópias de arquivos ou linhas privadas. Referências de total original dos outros cinco perfis devem ser fornecidas com prova; ausência fica explicitada, não se inventa total esperado. O Excel não comprova sozinho qual data/HEAD gerou seu conteúdo; a proveniência do manifesto exige evidência da execução. Revisar individualmente qualquer diferença.

## 4. Navegador nativo

```powershell
& $PythonWin01 -X utf8 -m conversor.web --port 8000
```

Abrir `http://127.0.0.1:8000`. Registrar Windows, browser/versão, data UTC e data_ref. Não usar `--legado-persistente` nem bind público.

Para **cada um dos seis perfis** da matriz, usar fontes sintéticas conformes ao respectivo leitor ou executar privadamente com as fontes autorizadas já sob guarda do usuário, sem copiá-las ao repositório:

1. Identificar inadimplência e cadastrar fonte complementar compatível. Arquivo novo pode exigir seleção explícita; nome de arquivo não comprova identidade. Cadastro sem identidade suficiente deve permanecer bloqueado. Não editar o catálogo de produção para fazer uma fixture ser reconhecida.
2. Conferir administradora/condomínio e modos A/B com data_ref fixa; preservar valores, vencimentos, responsáveis e elegibilidade. Repetir com mesmos bytes/data e comparar; datas diferentes são rodadas distintas.
3. Configurar endereço de seis campos somente no contexto correto. Clicar **Recarregar configuração**, confirmar valor vigente e nova conversão; conferir aplicação nas linhas financeiras e cadastrais B sem mudar finanças. Outro condomínio/sessão não deve herdar configuração. Registrar perda de endereço após descarte/encerramento como contrato efêmero, sem implementar ADDR-01.
4. Baixar XLSX diagnóstico e executar conferência. Confirmar segundo download recusado, isolamento de sessão e recusa de exportação operacional.
5. Alternar seis perfis, tentar cadastro e contexto cruzados, observar mensagens controladas sem dados privados. Conferir limites de entrada e erro sem sucesso falso.
6. Descartar resultados, observar TTL e encerrar normalmente; registrar limpeza. Não apagar resíduos desconhecidos nem declarar prova de limpeza após crash. Testar acesso externo só em procedimento específico autorizado e com evidência nativa; HTTP local não o substitui.

Fixtures de `tests/int02/fixtures.py` e testes especializados documentam os layouts sintéticos. Alguns fluxos positivos automatizados usam hashes sintéticos sob monkeypatch, exclusivamente em memória dos testes; isso não é homologação de fontes ou uma mudança autorizada de catálogo para o teste manual. Clique real e origem de arquivos devem constar da evidência nativa separada.

## 5. Revisão e transição

Revisar a matriz, cada falha/skip e o estado Git final. Preservar logs antigos e novos, usar os 38 identificadores JUnit e o comando direcionado agora fornecidos pelo usuário em `docs/win_01_a/EVIDENCIAS_USUARIO.md`, sem inferir causas pelos nomes. O patch ACL recuperado foi apenas validado com `git apply --check` nesta tarefa. A WIN-01-C deverá tratar correções em branch própria após revisão/conclusão desta preparação; não aplicá-lo nesta etapa. Não declarar homologação enquanto controles nativos ou financeiros necessários permanecerem sem evidência.


## Revisão após auditoria independente — estados parciais e privacidade

Usar uma pasta local gravável do próprio usuário, fora de qualquer checkout Git, para Resultados e Privado. Se LOCALAPPDATA estiver redirecionado para área sem acesso, escolher outra pasta privada gravável sob o perfil do usuário e ajustar as variáveis; não elevar privilégios nem alterar ExecutionPolicy/ACL. Caminho sob LOCALAPPDATA não prova, sozinho, DACL efetiva. Os scripts continuam recusando evidências dentro do Git.

O modelo de manifesto contém placeholders intencionais: deve ser recusado enquanto houver `PREENCHER_*`, SHA de HEAD inválido, data inválida ou evidência ausente. Preencher HEAD/data/rodada apenas torna a declaração formalmente válida; não comprova que esses metadados produziram os XLSX. Mesmo um campo autodeclarado de aprovação não autentica a origem.

A conferência retorna os eixos `financeiro_ab`, `total_original_esperado`, `endereco` e `procedencia_independente`. Finanças A/B podem estar APROVADO enquanto endereço/total estão NAO_EXECUTADO. Endereço ausente não é NAO_APLICAVEL. A procedência permanece NAO_COMPROVADA pelo script e exige auditoria independente de arquivos, hashes e registros da rodada. O script não possui autenticação de autoria/origem e não converte essa revisão humana em aprovação automática. `verificacao_completa=false` e o estado global é BLOQUEADO se faltarem eixos; divergência comprovada tem prioridade e retorna REPROVADO. A matriz só pode ser atualizada por revisão explícita das evidências correspondentes.

A etapa Excel propaga BLOQUEADO (código 2) quando a conferência está incompleta; REPROVADO (código 1) indica divergência comprovada. Motivos agregados usam códigos constantes, como ARQUIVO_NAO_ENCONTRADO, ACESSO_NEGADO, CABECALHO_INVALIDO, PROVENIENCIA_AUSENTE_OU_PLACEHOLDER, PROCEDENCIA_SEM_COMPROVACAO_INDEPENDENTE, ENDERECO_NAO_VERIFICADO e COLETA_NAO_CONCLUIDA. Não contêm células privadas, caminhos ou mensagens brutas de exceção. Comandos no resumo usam aliases para Python, checkout, evidências e manifesto privado. Logs brutos de subprocessos permanecem locais e privados, sujeitos à revisão antes de divulgação.

O ZIP original publicado, SHA-256 `57a9ffff5c143765ba9b216447f44ec1130c458dae06e4afb933de0668abec00`, e seus resultados históricos permanecem imutáveis. Esta revisão altera somente a preparação local; nenhuma versão substituta foi empacotada ou publicada.
