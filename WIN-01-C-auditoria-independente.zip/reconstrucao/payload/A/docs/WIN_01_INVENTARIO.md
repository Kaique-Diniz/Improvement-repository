# WIN-01-A — inventário de recuperação

Inventário observado em 12/11/2026, antes da criação dos novos artefatos.

- Checkout: `/workspace/Improvement-repository`; origin: `https://github.com/Kaique-Diniz/Improvement-repository.git`.
- Branch `work`, HEAD `04f29ff5fc9124b988bd611d3d1b8d7224ae874f`, igual ao `origin/main` local. Única worktree inicial; índice e arquivos rastreados limpos; nenhum arquivo não rastreado. Nenhum commit local exclusivo em relação ao origin/main local. Isso não prova ausência de trabalho em outro executor.
- Refs locais iniciais: somente `work` e `origin/main`. Nenhuma branch BPQ-04 local foi alterada.
- Não encontrados no checkout inicial: inventário WIN-01-A, matriz WIN-01-A, roteiro Windows WIN-01-A, scripts PowerShell ou instruções originais da tarefa. A busca em `/workspace` e na árvore do commit-base não recuperou esses artefatos. Não se presume acesso ao disco da conversa antiga.
- Existem módulo ACL diagnóstico, testes ACL e documentação de outras fases. `docs/BBZ_EDIFICIO_WIN.md` trata do condomínio Edifício Win, não da WIN-01-A.
- Base e correção não existiam localmente. Ambos foram obtidos por SHA exato via `git fetch --no-tags origin <base> <correcao>`, sem merge ou alteração de branch. Fetch atualiza objetos/FETCH_HEAD.
- A ref remota BPQ-04 aponta para `770d062d29c4361d6932592883df9339bb4089bc`, conforme `git ls-remote --heads origin`.
- Worktree nova: `/workspace/work/win-01-a`, detached HEAD no commit-base obrigatório. Não é continuação material do antigo diretório.
- No commit-base foram recuperados os leitores, fixtures sintéticas, testes dos seis perfis, testes `tests/int02`, documentação dos seis condomínios, INT_02 e BPQ_01 a BPQ_04. São implementação funcional anterior, não artefatos recuperados da preparação WIN-01-A. Hashes dos arquivos efetivamente inventariados estão em `inventario_testes.json`.
- Correção recuperada: `84ab546cd32c2601345d659e6d7fff2d10b4a10d`, dois arquivos ACL. Sua integridade foi conferida pelo objeto Git e o patch por `git apply --check` sobre a base. Não é descendente da base: restaurar sua árvore inteira removeria funcionalidades posteriores. `correcao_acl_recuperada.patch` contém somente o diff desse commit; NÃO aplicado nesta preparação. Regressões dele também permanecem no patch.

## Limites da reconstrução

As instruções originais foram inicialmente solicitadas e posteriormente fornecidas pelo usuário nesta conversa. O pacote foi consolidado conforme elas e as restrições desta recuperação. Não reproduz resultados antigos, não implementa ADDR-01 e não inicia WIN-01-C. Nenhuma regra financeira/cadastral ou arquivo de produção foi modificado. Nenhum commit/push/PR/merge foi feito.

## Consolidação após recebimento das instruções originais

O usuário forneceu as instruções originais durante a recuperação. A lacuna de especificação inicial foi resolvida. Os artefatos novos gerados nesta tarefa foram consolidados nos nomes `docs/WIN_01_*` e `tools/win01/`, sem manter cópias concorrentes dos documentos preliminares. O inventário inicial acima descreve o momento anterior ao recebimento.

Uma inspeção adicional de objetos não alcançáveis (`git fsck --no-reflogs --unreachable`) após o fetch identificou a ancestralidade de 84ab546: 1dc68ae (infraestrutura XLSX), e823f06 (CI), 4336e55 (UTF-8 perfis), 50ca9b6 (UTF-8 fixtures). São commits recuperados pelo fetch da correção, não prova de arquivos locais perdidos. Suas árvores não contêm artefatos nomeados WIN-01-A ou scripts PowerShell. Nenhum deles foi aplicado. O checkout original também não tinha arquivos ignorados a recuperar, conforme `git status --short --ignored`.

## Testes e mecanismos existentes na base

`docs/win_01_a/inventario_testes.json` registra caminhos, SHA-256 e nomes/linhas das funções de testes. É inventário estático: parametrização e skips só se estabelecem por coleta/execução. A coleta da base anterior aos complementos retornou 2.654 casos. `escopos.json` define seleções reproduzíveis; a seleção integrada histórica de 106 aprovações não foi adivinhada.

| Cobertura | Testes recuperados | Lacuna / complemento |
|---|---|---|
| Passaredo e Forest Hill | tests/passaredo, tests/web/test_integrated_auto_gestao.py | Compartilhamento de administradora não basta; casos comprovados por hash e arquivos novos com confirmação estão separados nos testes existentes. Sem identidade interna suficiente não afirmar rejeição inequívoca de todo documento novo. |
| Santa Mônica | tests/oma, tests/int02 | Exige confirmação nativa com XLSX/PDF. |
| Vero Encanto | tests/vero, tests/int02 | Papel titular/pagador e retenções cobertos sinteticamente; fonte real não reutilizada. |
| Itajubá | tests/itajuba, tests/int02 | Cadastro sintético novo sem hash conhecido continua bloqueado; seleção manual não comprova identidade. |
| Beach Parque | tests/beach_parque, tests/int02 | BPQ-04 já possui casos sintéticos de sobrenome com E e CPF do pagador; reutilizados sem duplicar implementação. Totais privados não reproduzidos em fixtures. |
| Endereços efêmeros | tests/web/test_classic_local.py | Complemento tests/win01/test_enderecos_integrados.py: seis perfis, todas as linhas A/B, invariância financeira e recarga via API; clique real depende do navegador. |
| Conferência externa de XLSX | Não havia ferramenta desta preparação | tools/win01/conferir_excel.py e testes de perda de duplicatas, alteração de valor, endereço cadastral ausente, cabeçalho, documento numérico e fórmula. |
| Sessões e descarte | tests/web/test_ephemeral.py, test_classic_local.py; tests/int02/test_integracao.py | Proteção funcional não prova proteção NTFS ou isolamento entre usuários. |

## Inventário de controles Windows/NTFS

| Mecanismo inspecionado | Presença efetiva / limite | Evidência nativa pendente |
|---|---|---|
| windows_acl_evidence.py | Presente e exclusivamente diagnóstico; autoriza_acesso=False / aplicada_ao_leitor=False. Chamada incorreta de CompareStringOrdinal na base. | Reproduzir falha nativa e classificar; correção não aplicada nesta fase. |
| private_permissions.py | Comparador exato de listas de ACEs incluindo herança; não é prova de captura da DACL efetiva pelo fluxo Web. | Integração/negação real de acesso no aplicativo. |
| windows_acl_verifier.py e windows_directory_handles.py | Ausentes da árvore-base. | Não integrar automaticamente nem alegar proteção por eles. |
| Temporários do MVP | TemporaryDirectory, limpeza normal, buffers/cache e sessões; intermediários transitórios. | DACL efetiva, negação de leitura por outro usuário, resíduos após crash. |
| NTFS e ACL | Dependem do volume do usuário; não estabelecidos por Linux. | Sonda cria só pasta/arquivo sintético, consulta filesystem e Get-Acl, sem alterar DACL. Leitura é diferente de política efetiva. |
| Hardlinks, symlinks, junctions/reparse | Testes ACL sintéticos e sonda de criação; privilégios/Developer Mode podem bloquear symlink. | Criação bem-sucedida não prova rejeição segura no app; registrar bloqueios sem elevar privilégios. |
| Nomes 8.3 | GetLongPathNameW no diagnóstico; disponibilidade depende do volume. | Sonda GetShortPathNameW/GetLongPathNameW; nome curto indisponível = BLOQUEADO, sem reconfigurar volume. |
| Escrita/atomicidade/locks | os.replace em private_json/json_repository; FileLock em repositórios legados. | Não generalizar para todo fluxo efêmero; falhas de IO, locks reais entre processos e recuperação por componente ainda exigem execução nativa. |
| Isolamento e falhas | Sessões/contextos e concorrência HTTP cobertos; parte dos testes de armazenamento é legada. | Outro usuário hostil, processo externo, falha de permissão e encerramento forçado continuam NAO_EXECUTADO. |

Regras financeiras existentes permanecem: Passaredo >60; Forest Hill >30 provisório; Santa Mônica >60 provisório; Vero, Itajubá e Beach Parque >30 provisório, com exclusões documentais próprias dos perfis. Os testes recuperados exercitam limites e valores originais. Nenhuma hipótese provisória foi promovida a autorização operacional.


## Atualização desta revisão, sem alterar os inventários históricos

A lista integral dos 38 identificadores JUnit e o comando exato da rodada UTF-8 foram recebidos do usuário após auditoria e estão preservados em `docs/win_01_a/EVIDENCIAS_USUARIO.md`. Os 38 identificadores únicos foram conferidos contra a coleta local histórica, sem repetir Windows. Os inventários JSON anteriores e seus hashes registram as versões anteriores dos testes e não foram sobrescritos por esta revisão.

A seleção integrada usada pela etapa rápida deixa de incluir `tests/test_acl_evidence.py`; o arquivo inteiro permanece no escopo nativo, no escopo ACL e na suíte completa. Os demais testes permanecem. Testes adicionais desta revisão estão em `tests/win01/test_revisao_auditoria.py`; isso altera a seleção atual, sem reescrever as contagens históricas.
