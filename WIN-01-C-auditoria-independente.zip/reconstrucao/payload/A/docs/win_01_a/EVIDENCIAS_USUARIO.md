# Evidências fornecidas pelo usuário

Fonte: mensagem de recuperação WIN-01-A nesta conversa, recebida em 12/11/2026. São relatos de execução anterior em Windows real/Python 3.12, não testes executados nesta tarefa. Logs nativos, nodeids, hashes de entrada, datas exatas das rodadas e identificação completa do checkout executado não foram fornecidos nesta mensagem.

| ID | Evidência relatada | Limite |
|---|---|---|
| U-01 | Suíte completa: 2.613 passed, 38 failed, 3 skipped, 1 warning | Suíte com falhas; não homologada. As 38 falhas não foram classificadas individualmente nesta tarefa. |
| U-02 | Direcionado com `-X utf8`: 106 passed, 2 skipped, zero failed | Seleção/comando integral não informado; não presumir que seja o escopo integrado reconstruído. Não comprova aprovação da suíte completa. |
| U-03 | Falha nativa confirmada em CompareStringOrdinal de windows_acl_evidence.py | Correção informada em 84ab546cd32c2601345d659e6d7fff2d10b4a10d; objeto recuperado separadamente e patch preservado, ainda não aplicado. |
| U-04 | Passaredo: +164 lançamentos | Reconciliação histórica atribuída à mudança das datas de referência. |
| U-05 | Forest Hill: +6 lançamentos | Mesma atribuição; não recalculada nesta tarefa. |
| U-06 | Santa Mônica: +99 lançamentos | Mesma atribuição; não recalculada nesta tarefa. |

Soma aritmética: 164 + 6 + 99 = 269 lançamentos adicionais. Compatibilidade com a mudança das datas é evidência relatada pelo usuário; não constitui autorização para alterar regras nem prova independente de nova execução. Não copiar documentos reais para o Git para completar essas evidências.

## Complemento recebido com as instruções originais

Também fornecidos pelo usuário, sem reexecução nativa nesta tarefa:

- Etapa rápida histórica: aprovada (sem comando/log integral disponível).
- Etapa nativa histórica: 49 aprovados, 5 falhas, 1 ignorado. Não atribuir automaticamente as cinco falhas ao mesmo defeito sem seus nodeids.
- Passaredo: comparação de 07/10/2026 para 09/11/2026, +164 dívidas.
- Forest Hill: comparação de 07/10/2026 para 09/11/2026, +6 dívidas.
- Santa Mônica: comparação de 13/10/2026 para 09/11/2026, +99 dívidas.
- Total reconciliado relatado: 269 lançamentos adicionais e R$ 130.997,71 de valor original agregado. Segundo o usuário, a comparação dos XLSX mostrou compatibilidade com a mudança de datas e ausência de divergência financeira nos lançamentos históricos correspondentes. Não foi repetida nesta tarefa.

### Referências privadas de 09/11/2026

| Perfil | Elegíveis A | Linhas B | Adicionais B |
|---|---:|---:|---:|
| Passaredo | 2.318 | 2.479 | 161 |
| Forest Hill | 1.631 | 1.631 | 0 |
| Parque Santa Mônica | 2.437 | 2.638 | 201 |
| Vero Encanto | 445 | 604 | 159 |
| Itajubá | 3.784 | 3.784 | 0 |
| Terraço Beach Parque | 850 | 1.009 | 159 |

Beach Parque: R$ 603.477,71 de valor original agregado e contrato de 30 colunas, conforme referência fornecida. Estes números não são asserts sobre fixtures sintéticas nem resultado da suíte Linux. Usá-los apenas para conferência de saídas privadas com proveniência e data idênticas.

## Complemento histórico fornecido pelo usuário após a auditoria independente

**Origem:** mensagem do usuário nesta revisão, não execução pelo Codex. Windows real/NTFS, Python 3.12, repositório Kaique-Diniz/Improvement-repository, branch `fix/bpq04-identidade-cadastral-beach-int02`, commit `770d062d29c4361d6932592883df9339bb4089bc`. O XML original não foi copiado para esta worktree; os identificadores abaixo foram extraídos pelo usuário de `pytest_completo.xml`, em `%LOCALAPPDATA%\ConversorWIN01\Resultados\20261110_123609_186ac2`.

Suíte completa relatada: **2613 passed, 38 failed, 3 skipped, 1 warning em 491,49 s**.

### Os 38 identificadores JUnit reprovados, preservados conforme recebidos

Formato `classname::name` do XML. Para uso no pytest, converter somente o módulo anterior a `::` para caminho com `/` e extensão `.py`, preservando nome e parâmetros. Esta lista não é seleção de testes executada nesta revisão.

```text
tests.bbz.test_edificio_win::test_sem_cadastro_e_estado_explicito_sem_copiar_historico
tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]
tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]
tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]
tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]
tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]
tests.bbz.test_persistent_links::test_raiz_link_ancestral_e_git_recusados
tests.bbz.test_persistent_links::test_mudanca_de_perfil_evidencia_nova_guardada_para_revisao
tests.bbz.test_persistent_links::test_referencia_atual_invalida_nao_libera_registro
tests.bbz.test_persistent_links::test_historico_10_ainda_tem_restricao_original
tests.bbz.test_persistent_links::test_schemas_novos_correspondem_aos_contratos
tests.bbz.test_persistent_links::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada
tests.evaluation.test_simulation_schema::test_schema_reproduzivel_e_protecao_somente_simulacao
tests.integrated_processing.test_storage::test_schemas_aditivos_publicados_e_reproduziveis
tests.phase3.test_private_validation::test_canonicos_so_por_opcao_explicita_na_area_privada
tests.phase3.test_private_validation::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida
tests.phase3.test_protected_sources::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]
tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[symlink]
tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_fonte]
tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_raiz]
tests.recognition.test_homologation_harness::test_comparador_preparado_para_boleto_continuado_sem_implementar_extrator
tests.recognition.test_homologation_harness::test_gabarito_detecta_erros_de_campos_continuidade_e_valores[campo-1]
tests.rules.test_authority::test_estado_nao_pode_divergir_de_eventos_mesmo_em_snapshot_assinado
tests.rules.test_authority::test_recibo_sem_permissao_na_politica_historica_e_rejeitado
tests.rules.test_authority::test_mesmo_recibo_assinado_precisa_corresponder_ao_plano_e_cadeia[hash_conteudo-1111111111111111111111111111111111111111111111111111111111111111-EVENTO_NAO_CORRESPONDE_A_VERSAO]
tests.rules.test_authority::test_mesmo_recibo_assinado_precisa_corresponder_ao_plano_e_cadeia[versao-9.0.0-EVENTO_NAO_CORRESPONDE_A_VERSAO]
tests.rules.test_authority::test_mesmo_recibo_assinado_precisa_corresponder_ao_plano_e_cadeia[hash_anterior-1111111111111111111111111111111111111111111111111111111111111111-CADEIA_DE_EVENTOS_INVALIDA]
tests.test_acl_evidence::test_evidencia_sempre_hardcoded_false
tests.test_acl_evidence::test_normalizacao_8_3_expande_nome_curto
tests.test_acl_evidence::test_comparacao_de_caminho_e_case_insensitive_ordinal
tests.test_acl_evidence::test_hardlink_e_rejeitado_na_comparacao_de_caminho
tests.test_acl_evidence::test_evidencia_com_baseline_registra_artefato_mas_nao_autoriza
tests.test_cli_and_schemas::test_schemas_versionados_correspondem_aos_contratos
tests.test_documents::test_auditoria_documental_persiste_em_json_protegido
tests.test_export::test_30_colunas_conferidas_contra_documento_normativo
tests.web.test_habita_diagnostic_closing::test_fechamento_reconciliado_disponibiliza_so_diagnostico_preservando_evidencia[A-3-0]
tests.web.test_habita_diagnostic_closing::test_fechamento_reconciliado_disponibiliza_so_diagnostico_preservando_evidencia[B-3-2]
tests.web.test_template_identifiers::test_torre_nova_conserva_identidade_provisoria_sem_alterar_financeiro
```

| Distribuição informada pelo usuário | Falhas |
|---|---:|
| test_persistent_links | 11 |
| test_authority | 5 |
| test_acl_evidence | 5 |
| test_private_storage | 3 |
| test_homologation_harness | 2 |
| test_habita_diagnostic_closing | 2 |
| test_private_validation | 2 |
| Outros oito módulos | 8 |
| Total | 38 |

A contagem e a correspondência dos identificadores com a coleta local podem ser conferidas sem repetir as execuções Windows. Não inferir a causa das 38 falhas pelos nomes.

### Comando exato UTF-8 informado pelo usuário

```powershell
cd "$HOME\Conversor-MVP-BPQ04"

.\.venv\Scripts\python.exe -X utf8 -m pytest -q `
  tests/rules/test_authority.py `
  tests/test_cli_and_schemas.py `
  tests/test_export.py `
  tests/web/test_habita_diagnostic_closing.py `
  tests/web/test_template_identifiers.py `
  --tb=short
```

Resultado histórico relatado: **106 passed, 2 skipped, 1 warning in 14.49s**.

```text
SKIPPED [1] tests\rules\test_authority.py:128: Permissões POSIX
SKIPPED [1] tests\rules\test_authority.py:168: Permissões POSIX
```

O warning é o DeprecationWarning em `starlette/testclient.py` por `anyio.abc.BlockingPortal`. Os skips POSIX não aprovam políticas NTFS. Esta seleção com UTF-8 não inclui ACL e não demonstra execução da suíte integral com UTF-8 nem correção das 38 falhas.

### Rodada nativa ACL relatada

**49 passed, 5 failed, 1 skipped in 18.39s**. Segundo o usuário, as cinco falhas de `tests/test_acl_evidence.py` compartilharam `AttributeError: function 'CompareStringOrdinal' not found`; traceback e inspeção confirmaram `ctypes.windll.oleaut32.CompareStringOrdinal`, função pertencente à Kernel32. A causa está comprovada para essas cinco falhas, não automaticamente para as demais 33.

Correção recuperada: `84ab546cd32c2601345d659e6d7fff2d10b4a10d`. Não aplicada à base nesta revisão. As cinco falhas continuam bloqueadores da homologação Windows, ainda que a etapa rápida passe após sua separação de escopo. O teste rápido não oculta nem dispensa a etapa nativa ou a suíte completa.
