# Diff integral por arquivo — WIN-01-A

O conteúdo dentro dos 11 blocos, concatenado na ordem, reproduz ajustes.patch.

## 1/11 — docs/WIN_01_INVENTARIO.md

````diff
diff --git a/docs/WIN_01_INVENTARIO.md b/docs/WIN_01_INVENTARIO.md
--- a/docs/WIN_01_INVENTARIO.md
+++ b/docs/WIN_01_INVENTARIO.md
@@ -53,3 +53,10 @@
 | Isolamento e falhas | Sessões/contextos e concorrência HTTP cobertos; parte dos testes de armazenamento é legada. | Outro usuário hostil, processo externo, falha de permissão e encerramento forçado continuam NAO_EXECUTADO. |
 
 Regras financeiras existentes permanecem: Passaredo >60; Forest Hill >30 provisório; Santa Mônica >60 provisório; Vero, Itajubá e Beach Parque >30 provisório, com exclusões documentais próprias dos perfis. Os testes recuperados exercitam limites e valores originais. Nenhuma hipótese provisória foi promovida a autorização operacional.
+
+
+## Atualização desta revisão, sem alterar os inventários históricos
+
+A lista integral dos 38 identificadores JUnit e o comando exato da rodada UTF-8 foram recebidos do usuário após auditoria e estão preservados em `docs/win_01_a/EVIDENCIAS_USUARIO.md`. Os 38 identificadores únicos foram conferidos contra a coleta local histórica, sem repetir Windows. Os inventários JSON anteriores e seus hashes registram as versões anteriores dos testes e não foram sobrescritos por esta revisão.
+
+A seleção integrada usada pela etapa rápida deixa de incluir `tests/test_acl_evidence.py`; o arquivo inteiro permanece no escopo nativo, no escopo ACL e na suíte completa. Os demais testes permanecem. Testes adicionais desta revisão estão em `tests/win01/test_revisao_auditoria.py`; isso altera a seleção atual, sem reescrever as contagens históricas.
````

## 2/11 — docs/WIN_01_MATRIZ_EVIDENCIAS.md

````diff
diff --git a/docs/WIN_01_MATRIZ_EVIDENCIAS.md b/docs/WIN_01_MATRIZ_EVIDENCIAS.md
--- a/docs/WIN_01_MATRIZ_EVIDENCIAS.md
+++ b/docs/WIN_01_MATRIZ_EVIDENCIAS.md
@@ -25,9 +25,16 @@
 | Descarte/temporários | Testes de erro, TTL, logout, encerramento e limpeza normal | NAO_EXECUTADO nativamente; recuperação após crash BLOQUEADO por ausência de implementação/evidência suficiente |
 | NTFS/ACL | Sonda em diretório sintético, Get-Acl, links e 8.3; comparador de ACEs existente | NAO_EXECUTADO; leitura ACL não prova política efetiva; outro usuário/processo continua pendente |
 | ACL conhecida na base | U-03: falha nativa CompareStringOrdinal relatada; chamada incorreta conferida por inspeção; patch recuperado | REPROVADO segundo relato do usuário; correção não aplicada nem revalidada nesta fase |
-| Suíte histórica completa | U-01: 2613 passed, 38 failed, 3 skipped, 1 warning | REPROVADO segundo relato; obter nodeids/logs e classificar causas |
-| Direcionado UTF-8 histórico | U-02: 106 passed, 2 skipped, zero failed | APROVADO somente como relato dessa seleção; comando/log e justificativa dos skips pendentes |
-| Etapa nativa histórica | 49 aprovados, 5 falhas, 1 ignorado, segundo usuário | REPROVADO segundo relato; não atribuir todas as falhas ao ACL sem nodeids |
+| Suíte histórica completa | U-01: 2613 passed, 38 failed, 3 skipped, 1 warning | REPROVADO segundo relato; 38 identificadores e distribuição agora recebidos em EVIDENCIAS_USUARIO.md; causas individuais ainda exigem evidência |
+| Direcionado UTF-8 histórico | U-02: 106 passed, 2 skipped, zero failed | APROVADO somente como relato dessa seleção; comando exato, 106/2/1 e skips POSIX recebidos em EVIDENCIAS_USUARIO.md; não aprova ACL/NTFS |
+| Etapa nativa histórica | 49 aprovados, 5 falhas, 1 ignorado, segundo usuário | REPROVADO segundo relato; as cinco falhas ACL e o erro de DLL foram identificados pelo usuário; sem aplicação da correção |
 | Reconciliação temporal | +164/+6/+99 = 269; R$ 130.997,71, datas e correspondências relatadas | Não reexecutada; não implica regressão ou mudança de regra |
 
 Para promover uma linha: anexar rodada com HEAD/diff, hashes, Windows/Python/browser, comando, dependências, data_ref, modalidade, contagens e justificativa de cada falha/skip. Não basta inspeção de código, leitura de ACL ou êxito em Linux. Evidências privadas ficam fora do Git. A matriz não declara o MVP homologado.
+
+
+## Revisão local após auditoria
+
+Escopo rápido separado do ACL; testes ACL conhecidos permanecem na etapa nativa e na completa, sem correção e como bloqueadores de homologação. Aprovação rápida não altera o estado dessas linhas.
+
+A ferramenta Excel agora mantém estados independentes: comparação financeira A/B, referência do total original, endereço e procedência. Endereço ou total sem evidência = NAO_EXECUTADO, procedência sem comprovação independente = NAO_COMPROVADA; o resumo global fica BLOQUEADO enquanto houver eixos pendentes, salvo REPROVADO por divergência comprovada. Manifesto com placeholders é BLOQUEADO antes da abertura dos XLSX. Declaração formal e hashes não autenticam sozinhos a origem. Nenhum estado Windows desta matriz foi promovido por testes Linux da revisão.
````

## 3/11 — docs/WIN_01_PREPARACAO.md

````diff
diff --git a/docs/WIN_01_PREPARACAO.md b/docs/WIN_01_PREPARACAO.md
--- a/docs/WIN_01_PREPARACAO.md
+++ b/docs/WIN_01_PREPARACAO.md
@@ -70,3 +70,24 @@
 Após revisão da preparação, abrir tarefa/branch própria para classificar e corrigir UTF-8, CompareStringOrdinal e demais falhas Windows, usando os nodeids/logs originais e esta base identificada. O patch recuperado pode orientar uma correção controlada nessa fase; não trazer a árvore inteira do commit de outra linha de histórico. Reexecutar os testes nativos e atualizar a matriz só com evidências correspondentes. Nenhuma correção WIN-01-C foi iniciada nesta tarefa.
 
 A preparação é entregue para revisão. O MVP **não está declarado homologado nem autorizado para operação**.
+
+
+## Revisão local após auditoria independente — alterações pendentes de aprovação
+
+Esta seção descreve exclusivamente a revisão local, posterior ao pacote publicado. Os resultados anteriores acima, os inventários JSON históricos, os logs anteriores e o ZIP original continuam preservados. Não houve nova versão do ZIP, commit, push, PR, merge ou aplicação do patch ACL.
+
+Alterações da preparação:
+
+1. A etapa rápida não seleciona mais `tests/test_acl_evidence.py`. O arquivo inteiro continua nos escopos nativo/ACL/completo e `ACL_COMPARESTRINGORDINAL_REPROVADO_NA_BASE` aparece explicitamente entre os bloqueadores de homologação no relatório do runner. Aprovação rápida não certifica ACL.
+2. A conferência Excel separa finanças A/B, referência do total, endereço e procedência. Total divergente reprova finanças; total/endereço sem referência permanecem NAO_EXECUTADO. `financeiro_completo` depende dos eixos financeiros; `verificacao_completa` permanece falsa diante de eixos pendentes. O script não autentica origem e mantém `procedencia_independente=NAO_COMPROVADA`, mesmo com declaração formal válida. A revisão independente da origem é externa à ferramenta.
+3. Placeholders de HEAD, rodada e caminhos são recusados, assim como HEAD/data inválidos. O manifesto distribuído permanece um exemplo não executável como evidência.
+4. O roteiro usa LOCALAPPDATA/ConversorWIN01, sem escrita na raiz de C:, sem privilégios administrativos e com Resultados/Privado fora do Git. Os comandos preservam caminhos com espaços. O caminho escolhido não implica certificação da DACL.
+5. A lista dos 38 identificadores, distribuição, metadados da execução original, comando exato UTF-8, 106/2/1 em 14,49 s, motivos dos skips POSIX e rodada ACL 49/5/1 em 18,39 s foram recebidos e incorporados em EVIDENCIAS_USUARIO.md. Os 38 identificadores únicos foram conferidos contra a coleta histórica local. São evidências relatadas pelo usuário, não reexecuções Windows desta revisão.
+6. Motivos agregados usam códigos constantes; não exportam mensagens brutas de exceção, células ou caminhos privados. O runner diferencia BLOQUEADO de REPROVADO e prioriza divergências comprovadas. Resumos de comando usam aliases; logs brutos de subprocessos continuam privados. Relatórios existentes não são sobrescritos.
+
+Testes focados finais da revisão em Linux/Python 3.12.14: **20 passed em 1,62 s**, sem falhas/skips, em `work/revisao_auditoria/ferramentas_conclusao.log` e `.xml`. Comando: `python -X utf8 -m pytest -q tests/win01/test_conferencia_excel.py tests/win01/test_revisao_auditoria.py --tb=short -p no:cacheprovider --junitxml=work/revisao_auditoria/ferramentas_conclusao.xml`. As rodadas intermediárias de 17 e 19 testes são sobrepostas e não devem ser somadas. PowerShell/Windows não foram executados nesta revisão. A suíte completa histórica não foi reexecutada.
+
+O diff de revisão é calculado contra os arquivos efetivamente contidos no ZIP aprovado, incluindo arquivos não rastreados, e ficará em `work/revisao_auditoria/ajustes.patch`. Não depende de `git diff` isolado. Esta revisão permanece na worktree WIN-01-A e não substitui o pacote aprovado/publicado.
+
+
+Execução do escopo rápido revisado nesta rodada Linux: **773 passed, 1 warning em 109,58 s**, sem falhas/skips, em `work/revisao_auditoria/rapida_linux.log` e `.xml`. Durante a revisão, três regressões adicionais foram acrescentadas depois dessa coleta; elas passaram na rodada focada final de 20 testes. Por isso a coleta rápida final contém **776 casos**, não uma execução única de 776 casos. Não somar 773+20: as seleções se sobrepõem. A coleta final rápida confirmou ausência de todo o módulo ACL, e a coleta nativa confirmou sua preservação. O warning é a depreciação Starlette/AnyIO já conhecida. Sintaxe final: 275 arquivos Python compilados em memória, sem erro.
````

## 4/11 — docs/WIN_01_ROTEIRO_WINDOWS.md

````diff
diff --git a/docs/WIN_01_ROTEIRO_WINDOWS.md b/docs/WIN_01_ROTEIRO_WINDOWS.md
--- a/docs/WIN_01_ROTEIRO_WINDOWS.md
+++ b/docs/WIN_01_ROTEIRO_WINDOWS.md
@@ -7,12 +7,21 @@
 Em um checkout já existente do repositório, preparar uma worktree isolada (o destino precisa ser novo):
 
 ```powershell
+# Diretório do próprio usuário; não requer escrita na raiz de C:\.
+$RaizWin01 = Join-Path $env:LOCALAPPDATA 'ConversorWIN01'
+$CheckoutWin01 = Join-Path $RaizWin01 'checkout'
+$VenvWin01 = Join-Path $RaizWin01 'venv'
+$EvidenceWin01 = Join-Path $RaizWin01 'Resultados'
+$PrivadoWin01 = Join-Path $RaizWin01 'Privado'
+New-Item -ItemType Directory -Force -Path $RaizWin01, $EvidenceWin01, $PrivadoWin01 | Out-Null
+# Executar a partir de um checkout existente; $CheckoutWin01 precisa ser novo.
 git cat-file -t 770d062d29c4361d6932592883df9339bb4089bc
-git worktree add --detach C:\WIN01A\checkout 770d062d29c4361d6932592883df9339bb4089bc
-Set-Location C:\WIN01A\checkout
-py -3.12 -m venv C:\WIN01A\venv
-C:\WIN01A\venv\Scripts\python.exe -m pip install -e ".[test,web]"
-C:\WIN01A\venv\Scripts\python.exe -m pip check
+git worktree add --detach "$CheckoutWin01" 770d062d29c4361d6932592883df9339bb4089bc
+Set-Location "$CheckoutWin01"
+py -3.12 -m venv "$VenvWin01"
+$PythonWin01 = Join-Path $VenvWin01 'Scripts\python.exe'
+& $PythonWin01 -m pip install -e ".[test,web]"
+& $PythonWin01 -m pip check
 ```
 
 Se o objeto estiver ausente, obter somente o SHA com `git fetch --no-tags origin 770d062d29c4361d6932592883df9339bb4089bc` e repetir a criação. Não fazer checkout sobre BPQ-04 nem aplicar o commit completo 84ab546. Instalação é ação explícita do usuário; o script não a automatiza.
@@ -22,20 +31,19 @@
 ## 2. Etapas PowerShell
 
 ```powershell
-$PythonWin01 = 'C:\WIN01A\venv\Scripts\python.exe'
-$EvidenceWin01 = 'C:\WIN01A\evidencias'
+# Reutilizar $PythonWin01 e $EvidenceWin01 definidos acima.
 & .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa rapida
 & .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa nativa
 & .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa completa
 ```
 
-Cada chamada cria uma rodada única fora de qualquer checkout Git. Recusa HEAD diferente e Python diferente de Windows/3.12. Não usa administrador, não instala pacotes, não aplica correções, não remove evidências anteriores. O HEAD continua na base com o defeito ACL conhecido.
+Cada chamada cria uma rodada única fora de qualquer checkout Git. Recusa HEAD diferente e Python diferente de Windows/3.12. Não usa administrador, não instala pacotes, não aplica correções, não remove evidências anteriores. O HEAD continua na base com o defeito ACL conhecido. A aprovação rápida não remove esse bloqueador de homologação.
 
-- **Rápida:** versões, Git, dependências, sintaxe em memória, inventário SHA-256, coleta e escopo integrado dos seis perfis; inclui autoteste de geração/conferência XLSX.
-- **Nativa:** sonda de filesystem/NTFS, leitura ACL sem contas/SIDs no resumo, criação de hardlink/symlink/junction, caminho 8.3 e testes ACL/permissões/armazenamento disponíveis. A pasta da sonda é nova e preserva somente arquivos sintéticos. Registrar controles ausentes. Sonda de leitura não comprova segurança efetiva.
+- **Rápida:** versões, Git, dependências, sintaxe em memória, inventário SHA-256, coleta e escopo integrado dos seis perfis, excluindo `tests/test_acl_evidence.py`; inclui autoteste de geração/conferência XLSX.
+- **Nativa:** sonda de filesystem/NTFS, leitura ACL sem contas/SIDs no resumo, criação de hardlink/symlink/junction, caminho 8.3 e testes ACL/permissões/armazenamento disponíveis, incluindo todo `tests/test_acl_evidence.py` com as cinco falhas históricas conhecidas. A pasta da sonda é nova e preserva somente arquivos sintéticos. Registrar controles ausentes. Sonda de leitura não comprova segurança efetiva.
 - **Completa:** coleta e suíte pytest integral, JUnit e totais estruturados, códigos de saída, Git inicial/final. `passed = tests - failures - errors - skipped`; warning completo fica no log pytest.
 
-Todas as etapas usam `-X utf8` explicitamente. Não equivalem à execução histórica sem UTF-8. Para investigar encoding, preservar uma rodada separada com o comando histórico completo sem `-X utf8`, depois de obtê-lo; não misturar seleções nem presumir os 106 casos antigos.
+Todas as etapas usam `-X utf8` explicitamente. Não equivalem à execução histórica sem UTF-8. O comando histórico exato com `-X utf8`, que obteve 106 aprovações, está preservado em `docs/win_01_a/EVIDENCIAS_USUARIO.md`. Eventual comparação sem UTF-8 deve ficar em outra rodada explicitamente identificada; não foi executada nesta revisão. Não confundir essa seleção histórica com o novo escopo rápido.
 
 `relatorio.json` distingue APROVADO, REPROVADO e BLOQUEADO; código 0/1/2 respectivamente. Aprovação se refere somente à execução da etapa. Skips exigem revisão, e controles sem evidência não ficam aprovados na matriz. Logs pytest e diffs são privados e podem incluir contexto de falha; não anexá-los ao Git. Os resumos Excel não imprimem pessoas, documentos ou contatos.
 
@@ -44,7 +52,7 @@
 Copiar `docs/win_01_a/manifesto_excel.exemplo.json` para fora do Git. Preencher caminhos absolutos dos XLSX A e B de cada perfil, HEAD realmente executado, identificador da rodada, data_ref, expectativas e, se disponível, os seis campos de endereço configurados. O exemplo contém **referências fornecidas pelo usuário para 09/11/2026**, não resultados produzidos pelo script. Não usá-las para fixtures ou data diferente.
 
 ```powershell
-& .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa excel -ManifestoExcel C:\WIN01A\privado\manifesto.json
+& .\tools\win01\validar.ps1 -Python $PythonWin01 -EvidenceRoot $EvidenceWin01 -Etapa excel -ManifestoExcel (Join-Path $PrivadoWin01 'manifesto.json')
 ```
 
 A ferramenta abre arquivos em modo leitura, exige 30 colunas e cabeçalhos literais, rejeita fórmulas/documento numérico, compara financeiramente A/B preservando multiplicidades e verifica contagens/totais/endereço quando fornecidos. Não grava cópias de arquivos ou linhas privadas. Referências de total original dos outros cinco perfis devem ser fornecidas com prova; ausência fica explicitada, não se inventa total esperado. O Excel não comprova sozinho qual data/HEAD gerou seu conteúdo; a proveniência do manifesto exige evidência da execução. Revisar individualmente qualquer diferença.
@@ -70,4 +78,17 @@
 
 ## 5. Revisão e transição
 
-Revisar a matriz, cada falha/skip e o estado Git final. Preservar logs antigos e novos, classificar os 38 failures históricos por nodeid e obter o comando antigo direcionado. O patch ACL recuperado foi apenas validado com `git apply --check` nesta tarefa. A WIN-01-C deverá tratar correções em branch própria após revisão/conclusão desta preparação; não aplicá-lo nesta etapa. Não declarar homologação enquanto controles nativos ou financeiros necessários permanecerem sem evidência.
+Revisar a matriz, cada falha/skip e o estado Git final. Preservar logs antigos e novos, usar os 38 identificadores JUnit e o comando direcionado agora fornecidos pelo usuário em `docs/win_01_a/EVIDENCIAS_USUARIO.md`, sem inferir causas pelos nomes. O patch ACL recuperado foi apenas validado com `git apply --check` nesta tarefa. A WIN-01-C deverá tratar correções em branch própria após revisão/conclusão desta preparação; não aplicá-lo nesta etapa. Não declarar homologação enquanto controles nativos ou financeiros necessários permanecerem sem evidência.
+
+
+## Revisão após auditoria independente — estados parciais e privacidade
+
+Usar uma pasta local gravável do próprio usuário, fora de qualquer checkout Git, para Resultados e Privado. Se LOCALAPPDATA estiver redirecionado para área sem acesso, escolher outra pasta privada gravável sob o perfil do usuário e ajustar as variáveis; não elevar privilégios nem alterar ExecutionPolicy/ACL. Caminho sob LOCALAPPDATA não prova, sozinho, DACL efetiva. Os scripts continuam recusando evidências dentro do Git.
+
+O modelo de manifesto contém placeholders intencionais: deve ser recusado enquanto houver `PREENCHER_*`, SHA de HEAD inválido, data inválida ou evidência ausente. Preencher HEAD/data/rodada apenas torna a declaração formalmente válida; não comprova que esses metadados produziram os XLSX. Mesmo um campo autodeclarado de aprovação não autentica a origem.
+
+A conferência retorna os eixos `financeiro_ab`, `total_original_esperado`, `endereco` e `procedencia_independente`. Finanças A/B podem estar APROVADO enquanto endereço/total estão NAO_EXECUTADO. Endereço ausente não é NAO_APLICAVEL. A procedência permanece NAO_COMPROVADA pelo script e exige auditoria independente de arquivos, hashes e registros da rodada. O script não possui autenticação de autoria/origem e não converte essa revisão humana em aprovação automática. `verificacao_completa=false` e o estado global é BLOQUEADO se faltarem eixos; divergência comprovada tem prioridade e retorna REPROVADO. A matriz só pode ser atualizada por revisão explícita das evidências correspondentes.
+
+A etapa Excel propaga BLOQUEADO (código 2) quando a conferência está incompleta; REPROVADO (código 1) indica divergência comprovada. Motivos agregados usam códigos constantes, como ARQUIVO_NAO_ENCONTRADO, ACESSO_NEGADO, CABECALHO_INVALIDO, PROVENIENCIA_AUSENTE_OU_PLACEHOLDER, PROCEDENCIA_SEM_COMPROVACAO_INDEPENDENTE, ENDERECO_NAO_VERIFICADO e COLETA_NAO_CONCLUIDA. Não contêm células privadas, caminhos ou mensagens brutas de exceção. Comandos no resumo usam aliases para Python, checkout, evidências e manifesto privado. Logs brutos de subprocessos permanecem locais e privados, sujeitos à revisão antes de divulgação.
+
+O ZIP original publicado, SHA-256 `57a9ffff5c143765ba9b216447f44ec1130c458dae06e4afb933de0668abec00`, e seus resultados históricos permanecem imutáveis. Esta revisão altera somente a preparação local; nenhuma versão substituta foi empacotada ou publicada.
````

## 5/11 — docs/win_01_a/EVIDENCIAS_USUARIO.md

````diff
diff --git a/docs/win_01_a/EVIDENCIAS_USUARIO.md b/docs/win_01_a/EVIDENCIAS_USUARIO.md
--- a/docs/win_01_a/EVIDENCIAS_USUARIO.md
+++ b/docs/win_01_a/EVIDENCIAS_USUARIO.md
@@ -36,3 +36,97 @@
 | Terraço Beach Parque | 850 | 1.009 | 159 |
 
 Beach Parque: R$ 603.477,71 de valor original agregado e contrato de 30 colunas, conforme referência fornecida. Estes números não são asserts sobre fixtures sintéticas nem resultado da suíte Linux. Usá-los apenas para conferência de saídas privadas com proveniência e data idênticas.
+
+## Complemento histórico fornecido pelo usuário após a auditoria independente
+
+**Origem:** mensagem do usuário nesta revisão, não execução pelo Codex. Windows real/NTFS, Python 3.12, repositório Kaique-Diniz/Improvement-repository, branch `fix/bpq04-identidade-cadastral-beach-int02`, commit `770d062d29c4361d6932592883df9339bb4089bc`. O XML original não foi copiado para esta worktree; os identificadores abaixo foram extraídos pelo usuário de `pytest_completo.xml`, em `%LOCALAPPDATA%\ConversorWIN01\Resultados\20261110_123609_186ac2`.
+
+Suíte completa relatada: **2613 passed, 38 failed, 3 skipped, 1 warning em 491,49 s**.
+
+### Os 38 identificadores JUnit reprovados, preservados conforme recebidos
+
+Formato `classname::name` do XML. Para uso no pytest, converter somente o módulo anterior a `::` para caminho com `/` e extensão `.py`, preservando nome e parâmetros. Esta lista não é seleção de testes executada nesta revisão.
+
+```text
+tests.bbz.test_edificio_win::test_sem_cadastro_e_estado_explicito_sem_copiar_historico
+tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]
+tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]
+tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]
+tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]
+tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]
+tests.bbz.test_persistent_links::test_raiz_link_ancestral_e_git_recusados
+tests.bbz.test_persistent_links::test_mudanca_de_perfil_evidencia_nova_guardada_para_revisao
+tests.bbz.test_persistent_links::test_referencia_atual_invalida_nao_libera_registro
+tests.bbz.test_persistent_links::test_historico_10_ainda_tem_restricao_original
+tests.bbz.test_persistent_links::test_schemas_novos_correspondem_aos_contratos
+tests.bbz.test_persistent_links::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada
+tests.evaluation.test_simulation_schema::test_schema_reproduzivel_e_protecao_somente_simulacao
+tests.integrated_processing.test_storage::test_schemas_aditivos_publicados_e_reproduziveis
+tests.phase3.test_private_validation::test_canonicos_so_por_opcao_explicita_na_area_privada
+tests.phase3.test_private_validation::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida
+tests.phase3.test_protected_sources::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]
+tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[symlink]
+tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_fonte]
+tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_raiz]
+tests.recognition.test_homologation_harness::test_comparador_preparado_para_boleto_continuado_sem_implementar_extrator
+tests.recognition.test_homologation_harness::test_gabarito_detecta_erros_de_campos_continuidade_e_valores[campo-1]
+tests.rules.test_authority::test_estado_nao_pode_divergir_de_eventos_mesmo_em_snapshot_assinado
+tests.rules.test_authority::test_recibo_sem_permissao_na_politica_historica_e_rejeitado
+tests.rules.test_authority::test_mesmo_recibo_assinado_precisa_corresponder_ao_plano_e_cadeia[hash_conteudo-1111111111111111111111111111111111111111111111111111111111111111-EVENTO_NAO_CORRESPONDE_A_VERSAO]
+tests.rules.test_authority::test_mesmo_recibo_assinado_precisa_corresponder_ao_plano_e_cadeia[versao-9.0.0-EVENTO_NAO_CORRESPONDE_A_VERSAO]
+tests.rules.test_authority::test_mesmo_recibo_assinado_precisa_corresponder_ao_plano_e_cadeia[hash_anterior-1111111111111111111111111111111111111111111111111111111111111111-CADEIA_DE_EVENTOS_INVALIDA]
+tests.test_acl_evidence::test_evidencia_sempre_hardcoded_false
+tests.test_acl_evidence::test_normalizacao_8_3_expande_nome_curto
+tests.test_acl_evidence::test_comparacao_de_caminho_e_case_insensitive_ordinal
+tests.test_acl_evidence::test_hardlink_e_rejeitado_na_comparacao_de_caminho
+tests.test_acl_evidence::test_evidencia_com_baseline_registra_artefato_mas_nao_autoriza
+tests.test_cli_and_schemas::test_schemas_versionados_correspondem_aos_contratos
+tests.test_documents::test_auditoria_documental_persiste_em_json_protegido
+tests.test_export::test_30_colunas_conferidas_contra_documento_normativo
+tests.web.test_habita_diagnostic_closing::test_fechamento_reconciliado_disponibiliza_so_diagnostico_preservando_evidencia[A-3-0]
+tests.web.test_habita_diagnostic_closing::test_fechamento_reconciliado_disponibiliza_so_diagnostico_preservando_evidencia[B-3-2]
+tests.web.test_template_identifiers::test_torre_nova_conserva_identidade_provisoria_sem_alterar_financeiro
+```
+
+| Distribuição informada pelo usuário | Falhas |
+|---|---:|
+| test_persistent_links | 11 |
+| test_authority | 5 |
+| test_acl_evidence | 5 |
+| test_private_storage | 3 |
+| test_homologation_harness | 2 |
+| test_habita_diagnostic_closing | 2 |
+| test_private_validation | 2 |
+| Outros oito módulos | 8 |
+| Total | 38 |
+
+A contagem e a correspondência dos identificadores com a coleta local podem ser conferidas sem repetir as execuções Windows. Não inferir a causa das 38 falhas pelos nomes.
+
+### Comando exato UTF-8 informado pelo usuário
+
+```powershell
+cd "$HOME\Conversor-MVP-BPQ04"
+
+.\.venv\Scripts\python.exe -X utf8 -m pytest -q `
+  tests/rules/test_authority.py `
+  tests/test_cli_and_schemas.py `
+  tests/test_export.py `
+  tests/web/test_habita_diagnostic_closing.py `
+  tests/web/test_template_identifiers.py `
+  --tb=short
+```
+
+Resultado histórico relatado: **106 passed, 2 skipped, 1 warning in 14.49s**.
+
+```text
+SKIPPED [1] tests\rules\test_authority.py:128: Permissões POSIX
+SKIPPED [1] tests\rules\test_authority.py:168: Permissões POSIX
+```
+
+O warning é o DeprecationWarning em `starlette/testclient.py` por `anyio.abc.BlockingPortal`. Os skips POSIX não aprovam políticas NTFS. Esta seleção com UTF-8 não inclui ACL e não demonstra execução da suíte integral com UTF-8 nem correção das 38 falhas.
+
+### Rodada nativa ACL relatada
+
+**49 passed, 5 failed, 1 skipped in 18.39s**. Segundo o usuário, as cinco falhas de `tests/test_acl_evidence.py` compartilharam `AttributeError: function 'CompareStringOrdinal' not found`; traceback e inspeção confirmaram `ctypes.windll.oleaut32.CompareStringOrdinal`, função pertencente à Kernel32. A causa está comprovada para essas cinco falhas, não automaticamente para as demais 33.
+
+Correção recuperada: `84ab546cd32c2601345d659e6d7fff2d10b4a10d`. Não aplicada à base nesta revisão. As cinco falhas continuam bloqueadores da homologação Windows, ainda que a etapa rápida passe após sua separação de escopo. O teste rápido não oculta nem dispensa a etapa nativa ou a suíte completa.
````

## 6/11 — docs/win_01_a/escopos.json

````diff
diff --git a/docs/win_01_a/escopos.json b/docs/win_01_a/escopos.json
--- a/docs/win_01_a/escopos.json
+++ b/docs/win_01_a/escopos.json
@@ -10,7 +10,6 @@
     "tests/web/test_classic_local.py",
     "tests/web/test_ephemeral.py",
     "tests/web/test_cadastral_policy_metadata.py",
-    "tests/test_acl_evidence.py",
     "tests/win01"
   ],
   "completa": [
````

## 7/11 — docs/win_01_a/manifesto_excel.exemplo.json

````diff
diff --git a/docs/win_01_a/manifesto_excel.exemplo.json b/docs/win_01_a/manifesto_excel.exemplo.json
--- a/docs/win_01_a/manifesto_excel.exemplo.json
+++ b/docs/win_01_a/manifesto_excel.exemplo.json
@@ -3,8 +3,8 @@
   "origem_referencias": "usuario; diagnosticos privados de 09/11/2026, nao executados nesta recuperacao",
   "perfis": {
     "passaredo": {
-      "a": "C:/WIN01A/privado/passaredo_A.xlsx",
-      "b": "C:/WIN01A/privado/passaredo_B.xlsx",
+      "a": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_A",
+      "b": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_B",
       "data_ref": "2026-11-09",
       "evidencia_execucao": "PREENCHER_ID_DA_RODADA",
       "esperado": {
@@ -14,8 +14,8 @@
       }
     },
     "forest_hill": {
-      "a": "C:/WIN01A/privado/forest_hill_A.xlsx",
-      "b": "C:/WIN01A/privado/forest_hill_B.xlsx",
+      "a": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_A",
+      "b": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_B",
       "data_ref": "2026-11-09",
       "evidencia_execucao": "PREENCHER_ID_DA_RODADA",
       "esperado": {
@@ -25,8 +25,8 @@
       }
     },
     "parque_santa_monica": {
-      "a": "C:/WIN01A/privado/parque_santa_monica_A.xlsx",
-      "b": "C:/WIN01A/privado/parque_santa_monica_B.xlsx",
+      "a": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_A",
+      "b": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_B",
       "data_ref": "2026-11-09",
       "evidencia_execucao": "PREENCHER_ID_DA_RODADA",
       "esperado": {
@@ -36,8 +36,8 @@
       }
     },
     "vero_encanto": {
-      "a": "C:/WIN01A/privado/vero_encanto_A.xlsx",
-      "b": "C:/WIN01A/privado/vero_encanto_B.xlsx",
+      "a": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_A",
+      "b": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_B",
       "data_ref": "2026-11-09",
       "evidencia_execucao": "PREENCHER_ID_DA_RODADA",
       "esperado": {
@@ -47,8 +47,8 @@
       }
     },
     "itajuba": {
-      "a": "C:/WIN01A/privado/itajuba_A.xlsx",
-      "b": "C:/WIN01A/privado/itajuba_B.xlsx",
+      "a": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_A",
+      "b": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_B",
       "data_ref": "2026-11-09",
       "evidencia_execucao": "PREENCHER_ID_DA_RODADA",
       "esperado": {
@@ -58,8 +58,8 @@
       }
     },
     "terraco_beach_parque": {
-      "a": "C:/WIN01A/privado/terraco_beach_parque_A.xlsx",
-      "b": "C:/WIN01A/privado/terraco_beach_parque_B.xlsx",
+      "a": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_A",
+      "b": "PREENCHER_CAMINHO_ABSOLUTO_XLSX_B",
       "data_ref": "2026-11-09",
       "evidencia_execucao": "PREENCHER_ID_DA_RODADA",
       "esperado": {
@@ -69,5 +69,6 @@
         "total_original": "603477.71"
       }
     }
-  }
+  },
+  "aviso_procedencia": "Modelo nao executavel como evidencia: substituir placeholders. Declaracoes formais nao comprovam independentemente a procedencia dos XLSX."
 }
````

## 8/11 — tests/win01/test_conferencia_excel.py

````diff
diff --git a/tests/win01/test_conferencia_excel.py b/tests/win01/test_conferencia_excel.py
--- a/tests/win01/test_conferencia_excel.py
+++ b/tests/win01/test_conferencia_excel.py
@@ -27,7 +27,11 @@
     expected = {'elegiveis_a': 2, 'linhas_b': 3, 'adicionais_b': 1, 'total_original': '200.20'}
     sheet(a, [row, row])
     sheet(b, [row, row, extra])
-    assert check_pair(a, b, expected)['status'] == 'APROVADO'
+    result = check_pair(a, b, expected)
+    assert result['financeiro'] == 'APROVADO'
+    assert result['status'] == 'BLOQUEADO'
+    assert result['endereco'] == 'NAO_EXECUTADO'
+    assert result['verificacao_completa'] is False
     sheet(b, [row, extra])
     assert check_pair(a, b, expected)['checks']['financeiro_ab_identico'] is False
     changed = row.copy()
````

## 9/11 — tests/win01/test_revisao_auditoria.py

````diff
diff --git a/tests/win01/test_revisao_auditoria.py b/tests/win01/test_revisao_auditoria.py
new file mode 100644
--- /dev/null
+++ b/tests/win01/test_revisao_auditoria.py
@@ -0,0 +1,151 @@
+"""Regressões da auditoria WIN-01-A: estados parciais, procedência e motivos seguros."""
+import json
+from pathlib import Path
+import subprocess
+import sys
+
+import pytest
+
+from tools.win01.conferir_excel import (PERFIS, check_pair, conferir_manifesto,
+    consolidar_estados, motivo_seguro)
+from tools.win01.executar import classificar_passo, motivo_execucao
+from tests.win01.test_conferencia_excel import sheet
+
+ROOT = Path(__file__).resolve().parents[2]
+
+
+def inputs(tmp_path):
+    a, b = tmp_path / 'a.xlsx', tmp_path / 'b.xlsx'
+    row = [None] * 30
+    row[3], row[29] = 'Pessoa Inteiramente Ficticia', 100
+    fields = {'logradouro': 'Rua Ficticia', 'numero': '1', 'cep': '00000001',
+              'bairro': 'Bairro Ficticio', 'cidade': 'Cidade Ficticia', 'uf': 'SP'}
+    for i, value in zip((4, 5, 7, 8, 9, 10), fields.values()):
+        row[i] = value
+    sheet(a, [row]); sheet(b, [row])
+    expected = {'elegiveis_a': 1, 'linhas_b': 1, 'adicionais_b': 0, 'total_original': '100'}
+    return a, b, expected, fields
+
+
+def manifest_file(tmp_path):
+    a, b, expected, fields = inputs(tmp_path)
+    item = {'a': str(a), 'b': str(b), 'data_ref': '2026-11-09', 'evidencia_execucao': 'rodada-20261110-123609',
+            'esperado': expected, 'endereco': fields}
+    data = {'head_execucao': '770d062d29c4361d6932592883df9339bb4089bc',
+            'perfis': {profile: dict(item) for profile in PERFIS}}
+    path = tmp_path / 'manifesto.json'
+    return path, data
+
+
+def test_eixos_financeiros_aprovados_nao_aprovam_procedencia(tmp_path):
+    a, b, expected, fields = inputs(tmp_path)
+    result = check_pair(a, b, expected, fields)
+    assert result['financeiro'] == result['endereco'] == 'APROVADO'
+    assert result['eixos']['total_original_esperado'] == 'APROVADO'
+    assert result['eixos']['procedencia_independente'] == 'NAO_COMPROVADA'
+    assert result['status'] == 'BLOQUEADO' and not result['verificacao_completa']
+
+
+def test_total_ausente_e_endereco_ausente_permanecem_pendentes(tmp_path):
+    a, b, expected, _ = inputs(tmp_path)
+    expected.pop('total_original')
+    result = check_pair(a, b, expected)
+    assert result['financeiro'] == 'APROVADO'
+    assert result['eixos']['total_original_esperado'] == 'NAO_EXECUTADO'
+    assert result['endereco'] == 'NAO_EXECUTADO'
+    assert {'TOTAL_ORIGINAL_SEM_REFERENCIA', 'ENDERECO_NAO_VERIFICADO'} <= set(result['motivos'])
+
+
+@pytest.mark.parametrize('field,value,code', [
+    ('head_execucao', 'PREENCHER_COM_HEAD_REAL_DA_RODADA', 'PROVENIENCIA_AUSENTE_OU_PLACEHOLDER'),
+    ('head_execucao', '0' * 40, 'HEAD_DECLARADO_INVALIDO'),
+    ('evidencia_execucao', 'PREENCHER_ID_DA_RODADA', 'PROVENIENCIA_AUSENTE_OU_PLACEHOLDER'),
+    ('data_ref', '09/11/2026', 'DATA_REFERENCIA_INVALIDA'),
+    ('a', 'PREENCHER_CAMINHO_ABSOLUTO_XLSX_A', 'CAMINHO_ENTRADA_AUSENTE_OU_PLACEHOLDER'),
+])
+def test_placeholders_e_proveniencia_invalida_recusados(tmp_path, field, value, code):
+    path, data = manifest_file(tmp_path)
+    if field == 'head_execucao':
+        data[field] = value
+    else:
+        data['perfis']['passaredo'][field] = value
+    path.write_text(json.dumps(data))
+    result = conferir_manifesto(path)
+    assert result['perfis']['passaredo']['motivo'] == code
+    assert result['status'] == 'BLOQUEADO'
+
+
+def test_autodeclaracao_nao_e_comprovacao_independente(tmp_path):
+    path, data = manifest_file(tmp_path)
+    for item in data['perfis'].values():
+        item['procedencia_comprovada'] = True
+    path.write_text(json.dumps(data))
+    result = conferir_manifesto(path)
+    assert result['procedencia_independente'] == 'NAO_COMPROVADA'
+    assert result['status'] == 'BLOQUEADO'
+    assert all(r['proveniencia_declarada'] == 'VALIDADA_FORMALMENTE' for r in result['perfis'].values())
+
+
+def test_motivos_sem_caminhos_ou_conteudo_privado(tmp_path):
+    path, data = manifest_file(tmp_path)
+    data['perfis']['passaredo']['a'] = str(tmp_path / 'SEGREDO_PESSOAL_NAO_EXIBIR.xlsx')
+    path.write_text(json.dumps(data))
+    result = conferir_manifesto(path)
+    assert result['perfis']['passaredo']['motivo'] == 'ARQUIVO_NAO_ENCONTRADO'
+    assert 'SEGREDO_PESSOAL' not in json.dumps(result)
+    assert motivo_seguro(PermissionError('/caminho/privado')) == 'ACESSO_NEGADO'
+    assert motivo_seguro(ValueError('documento pessoal')) == 'ERRO_DE_CONFERENCIA'
+    assert motivo_execucao(FileNotFoundError('/caminho/privado')) == 'EXECUTAVEL_OU_ARQUIVO_AUSENTE'
+    assert motivo_execucao(subprocess.TimeoutExpired('comando privado', 1)) == 'TEMPO_LIMITE_EXCEDIDO'
+
+
+def test_cli_bloqueado_retorna_json_sem_traceback(tmp_path):
+    path = tmp_path / 'manifesto.json'; path.write_text('{invalido')
+    output = tmp_path / 'relatorio.json'
+    result = subprocess.run([sys.executable, str(ROOT / 'tools/win01/conferir_excel.py'), str(path), str(output)],
+                            capture_output=True, text=True, timeout=20)
+    assert result.returncode == 2 and not result.stderr
+    assert json.loads(output.read_text())['motivo'] == 'JSON_OU_CODIFICACAO_INVALIDA'
+
+
+def test_reprovacao_nao_e_ocultada_por_eixo_pendente():
+    assert consolidar_estados(['REPROVADO', 'NAO_EXECUTADO']) == 'REPROVADO'
+    assert classificar_passo('excel', 2) == ('BLOQUEADO', 'CONFERENCIA_EXCEL_INCOMPLETA')
+    assert classificar_passo('pytest', 1) == ('REPROVADO', 'TESTES_REPROVADOS')
+    assert classificar_passo('coleta', 5) == ('BLOQUEADO', 'COLETA_NAO_CONCLUIDA')
+
+
+def test_escopo_rapido_nao_mascara_acl_nativo():
+    scopes = json.loads((ROOT / 'docs/win_01_a/escopos.json').read_text())
+    assert 'tests/test_acl_evidence.py' not in scopes['integrada']
+    assert 'tests/test_acl_evidence.py' in scopes['nativa']
+    assert 'tests/test_acl_evidence.py' in scopes['acl']
+    assert scopes['completa'] == ['tests']
+
+
+def test_cli_nao_sobrescreve_relatorio_existente(tmp_path):
+    path, data = manifest_file(tmp_path); path.write_text(json.dumps(data))
+    output = tmp_path / 'relatorio.json'; output.write_text('EVIDENCIA_ANTERIOR')
+    result = subprocess.run([sys.executable, str(ROOT / 'tools/win01/conferir_excel.py'), str(path), str(output)],
+                            capture_output=True, text=True, timeout=20)
+    assert result.returncode == 2 and not result.stderr
+    assert json.loads(result.stdout)['motivo'] == 'ARQUIVO_SAIDA_JA_EXISTE'
+    assert output.read_text() == 'EVIDENCIA_ANTERIOR'
+
+
+def test_modelo_distribuido_e_recusado_antes_de_abrir_fontes(tmp_path):
+    path = tmp_path / 'manifesto.json'
+    path.write_bytes((ROOT / 'docs/win_01_a/manifesto_excel.exemplo.json').read_bytes())
+    result = conferir_manifesto(path)
+    assert result['status'] == 'BLOQUEADO'
+    assert all(p['motivo'] == 'PROVENIENCIA_AUSENTE_OU_PLACEHOLDER' for p in result['perfis'].values())
+
+
+def test_total_original_divergente_reprova_financas(tmp_path):
+    a, b, expected, fields = inputs(tmp_path)
+    expected['total_original'] = '101'
+    result = check_pair(a, b, expected, fields)
+    assert result['eixos']['financeiro_ab'] == 'APROVADO'
+    assert result['financeiro'] == result['financeiro_completo'] == result['status'] == 'REPROVADO'
+    assert result['endereco'] == 'APROVADO'
+    assert not result['verificacao_completa']
````

## 10/11 — tools/win01/conferir_excel.py

````diff
diff --git a/tools/win01/conferir_excel.py b/tools/win01/conferir_excel.py
--- a/tools/win01/conferir_excel.py
+++ b/tools/win01/conferir_excel.py
@@ -1,12 +1,16 @@
-"""Confere XLSX A/B privados sem copiar entradas nem exportar dados pessoais."""
+"""Confere XLSX A/B; separa finanças, endereço e procedência sem expor dados privados."""
 from collections import Counter
-from decimal import Decimal
+from datetime import date
+from decimal import Decimal, InvalidOperation
 import hashlib
 import json
 from pathlib import Path
+import re
 import sys
+from zipfile import BadZipFile
 
 from openpyxl import load_workbook
+from openpyxl.utils.exceptions import InvalidFileException
 from conversor.domain.template import COLUNAS
 
 PERFIS = ('passaredo', 'forest_hill', 'parque_santa_monica', 'vero_encanto', 'itajuba', 'terraco_beach_parque')
@@ -14,85 +18,193 @@
 ADDR_FIELDS = ('logradouro', 'numero', 'cep', 'bairro', 'cidade', 'uf')
 
 
+class ErroConferencia(ValueError):
+    """Somente códigos constantes definidos neste módulo, nunca conteúdo da entrada."""
+
+
+def motivo_seguro(exc):
+    if isinstance(exc, ErroConferencia):
+        return exc.args[0]
+    if isinstance(exc, FileExistsError):
+        return 'ARQUIVO_SAIDA_JA_EXISTE'
+    if isinstance(exc, FileNotFoundError):
+        return 'ARQUIVO_NAO_ENCONTRADO'
+    if isinstance(exc, PermissionError):
+        return 'ACESSO_NEGADO'
+    if isinstance(exc, (json.JSONDecodeError, UnicodeError)):
+        return 'JSON_OU_CODIFICACAO_INVALIDA'
+    if isinstance(exc, (BadZipFile, InvalidFileException)):
+        return 'XLSX_INVALIDO'
+    if isinstance(exc, OSError):
+        return 'FALHA_IO'
+    return 'ERRO_DE_CONFERENCIA'
+
+
 def outside_git(path):
+    path = Path(path).resolve()
     return not any((parent / '.git').exists() for parent in (path, *path.parents))
 
 
 def read_sheet(path):
     if not outside_git(path):
-        raise ValueError('ENTRADA_DENTRO_DO_GIT')
+        raise ErroConferencia('ENTRADA_DENTRO_DO_GIT')
     workbook = load_workbook(path, read_only=True, data_only=False, keep_links=False)
     try:
+        if 'Dados' not in workbook.sheetnames:
+            raise ErroConferencia('ABA_DADOS_AUSENTE')
         sheet = workbook['Dados']
         if sheet.max_column != 30:
-            raise ValueError('COLUNAS')
+            raise ErroConferencia('COLUNAS_INVALIDAS')
         cells = list(sheet.iter_rows())
         if not cells or tuple(c.value for c in cells[0]) != COLUNAS:
-            raise ValueError('CABECALHO')
+            raise ErroConferencia('CABECALHO_INVALIDO')
         if any(c.data_type == 'f' for row in cells for c in row):
-            raise ValueError('FORMULAS')
+            raise ErroConferencia('FORMULA_NAO_PERMITIDA')
         rows = [tuple(c.value for c in row) for row in cells[1:] if any(c.value is not None for c in row)]
         if any(r[2] is not None and not isinstance(r[2], str) for r in rows):
-            raise ValueError('DOCUMENTO_NAO_TEXTUAL')
+            raise ErroConferencia('DOCUMENTO_NAO_TEXTUAL')
         return rows
     finally:
         workbook.close()
 
 
+def consolidar_estados(statuses):
+    # Reprovação comprovada não pode ser ocultada por outro eixo pendente.
+    if 'REPROVADO' in statuses:
+        return 'REPROVADO'
+    if any(s != 'APROVADO' for s in statuses):
+        return 'BLOQUEADO'
+    return 'APROVADO'
+
+
 def check_pair(a_path, b_path, expected, address=None):
+    if not isinstance(expected, dict) or any(type(expected.get(k)) is not int or expected[k] < 0
+                                            for k in ('elegiveis_a', 'linhas_b', 'adicionais_b')):
+        raise ErroConferencia('EXPECTATIVAS_INVALIDAS')
+    if address is not None and (not isinstance(address, dict) or any(k not in address for k in ADDR_FIELDS)):
+        raise ErroConferencia('ENDERECO_ESPERADO_INCOMPLETO')
     a, b = read_sheet(a_path), read_sheet(b_path)
     financial_a = [r for r in a if r[29] is not None]
     financial_b = [r for r in b if r[29] is not None]
-    # Counter preserva multiplicidade; conjuntos ocultariam perdas de linhas repetidas.
-    equal = Counter(financial_a) == Counter(financial_b)
-    total = sum((Decimal(str(r[29])) for r in financial_a), Decimal(0))
+    try:
+        values = [Decimal(str(r[29])) for r in financial_a + financial_b]
+        if any(not v.is_finite() for v in values):
+            raise InvalidOperation
+        total = sum(values[:len(financial_a)], Decimal(0))
+        expected_total = Decimal(str(expected['total_original'])) if 'total_original' in expected else None
+        if expected_total is not None and not expected_total.is_finite():
+            raise InvalidOperation
+    except InvalidOperation:
+        raise ErroConferencia('VALOR_FINANCEIRO_INVALIDO') from None
     checks = {
         '30_colunas_e_cabecalhos': True,
-        'financeiro_ab_identico': equal,
+        'financeiro_ab_identico': Counter(financial_a) == Counter(financial_b),
         'a_sem_linhas_cadastrais': len(a) == len(financial_a),
         'elegiveis_a': len(financial_a) == expected['elegiveis_a'],
         'linhas_b': len(b) == expected['linhas_b'],
         'adicionais_b': len(b) - len(financial_b) == expected['adicionais_b'],
     }
-    if 'total_original' in expected:
-        checks['total_original'] = total == Decimal(expected['total_original'])
+    financial_status = 'APROVADO' if all(checks.values()) else 'REPROVADO'
+    total_status = 'NAO_EXECUTADO'
+    if expected_total is not None:
+        checks['total_original'] = total == expected_total
+        total_status = 'APROVADO' if checks['total_original'] else 'REPROVADO'
+    address_status = 'NAO_EXECUTADO'
     if address is not None:
         target = tuple(address[n] for n in ADDR_FIELDS)
-        checks['endereco_todas_linhas_ab'] = all(tuple(row[i] for i in ADDR_INDEX) == target for row in a + b)
-    return {'status': 'APROVADO' if all(checks.values()) else 'REPROVADO', 'checks': checks,
+        checks['endereco_todas_linhas_ab'] = bool(a and b) and all(tuple(row[i] for i in ADDR_INDEX) == target for row in a + b)
+        address_status = 'APROVADO' if checks['endereco_todas_linhas_ab'] else 'REPROVADO'
+    axes = {'financeiro_ab': financial_status, 'total_original_esperado': total_status,
+            'endereco': address_status, 'procedencia_independente': 'NAO_COMPROVADA'}
+    reasons = []
+    if financial_status == 'REPROVADO':
+        reasons.append('DIVERGENCIA_FINANCEIRA_OU_CONTRATUAL')
+    if total_status == 'NAO_EXECUTADO':
+        reasons.append('TOTAL_ORIGINAL_SEM_REFERENCIA')
+    elif total_status == 'REPROVADO':
+        reasons.append('TOTAL_ORIGINAL_DIVERGENTE')
+    if address_status == 'NAO_EXECUTADO':
+        reasons.append('ENDERECO_NAO_VERIFICADO')
+    elif address_status == 'REPROVADO':
+        reasons.append('ENDERECO_DIVERGENTE')
+    reasons.append('PROCEDENCIA_SEM_COMPROVACAO_INDEPENDENTE')
+    return {'status': consolidar_estados(list(axes.values())), 'financeiro': 'REPROVADO' if total_status == 'REPROVADO' else financial_status,
+            'financeiro_completo': consolidar_estados([financial_status, total_status]),
+            'verificacao_completa': False, 'eixos': axes, 'motivos': reasons, 'checks': checks,
             'elegiveis_a': len(financial_a), 'linhas_b': len(b), 'adicionais_b': len(b) - len(financial_b),
-            'total_original': str(total), 'endereco': 'NAO_EXECUTADO' if address is None else ('APROVADO' if checks['endereco_todas_linhas_ab'] else 'REPROVADO'),
+            'total_original': str(total), 'endereco': address_status,
             'sha256_a': hashlib.sha256(a_path.read_bytes()).hexdigest(),
             'sha256_b': hashlib.sha256(b_path.read_bytes()).hexdigest()}
 
 
-def main():
-    manifest_path, output = map(Path, sys.argv[1:])
-    if not outside_git(manifest_path.resolve()):
-        raise ValueError('MANIFESTO_DEVE_FICAR_FORA_DO_GIT')
+def placeholder(value):
+    if not isinstance(value, str) or not value.strip():
+        return True
+    return bool(re.search(r'PREENCHER|PLACEHOLDER|SUBSTITUIR|TODO|EXEMPLO|<[^>]*>', value, re.IGNORECASE))
+
+
+def validar_proveniencia_declarada(manifest, item):
+    head, evidence = manifest.get('head_execucao'), item.get('evidencia_execucao')
+    if placeholder(head) or placeholder(evidence):
+        raise ErroConferencia('PROVENIENCIA_AUSENTE_OU_PLACEHOLDER')
+    if not re.fullmatch(r'[0-9a-fA-F]{40}', head) or len(set(head.lower())) == 1:
+        raise ErroConferencia('HEAD_DECLARADO_INVALIDO')
+    try:
+        ref = item.get('data_ref')
+        if not isinstance(ref, str) or date.fromisoformat(ref).isoformat() != ref:
+            raise ValueError
+    except ValueError:
+        raise ErroConferencia('DATA_REFERENCIA_INVALIDA') from None
+    if any(placeholder(item.get(key)) for key in ('a', 'b')):
+        raise ErroConferencia('CAMINHO_ENTRADA_AUSENTE_OU_PLACEHOLDER')
+    # Validade formal não autentica autoria, data ou origem do XLSX.
+    # Mesmo um campo "comprovada": true autodeclarado não é prova independente.
+
+
+def conferir_manifesto(manifest_path):
+    if not outside_git(manifest_path):
+        raise ErroConferencia('MANIFESTO_DENTRO_DO_GIT')
     manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
-    result = {'origem': 'conferencia de arquivos fornecidos nesta rodada', 'homologacao': False, 'perfis': {}}
+    if not isinstance(manifest, dict) or not isinstance(manifest.get('perfis'), dict):
+        raise ErroConferencia('ESTRUTURA_MANIFESTO_INVALIDA')
+    result = {'origem': 'conferencia de arquivos fornecidos nesta rodada', 'homologacao': False,
+              'verificacao_completa': False, 'procedencia_independente': 'NAO_COMPROVADA', 'perfis': {}}
     for profile in PERFIS:
-        item = manifest.get('perfis', {}).get(profile)
-        if not item:
+        item = manifest['perfis'].get(profile)
+        if not isinstance(item, dict):
             result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': 'PAR_A_B_AUSENTE'}
             continue
         try:
-            if not item.get('data_ref') or not manifest.get('head_execucao') or not item.get('evidencia_execucao'):
-                raise ValueError('PROVENIENCIA_AUSENTE')
+            validar_proveniencia_declarada(manifest, item)
             paths = [Path(item[key]).resolve() for key in ('a', 'b')]
-            result['perfis'][profile] = check_pair(*paths, item['esperado'], item.get('endereco'))
+            result['perfis'][profile] = check_pair(*paths, item.get('esperado'), item.get('endereco'))
             result['perfis'][profile]['data_ref'] = item['data_ref']
+            result['perfis'][profile]['proveniencia_declarada'] = 'VALIDADA_FORMALMENTE'
         except Exception as exc:
-            # Não registrar exceção com valor/caminho/célula privada.
-            result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': type(exc).__name__}
-    statuses = [r['status'] for r in result['perfis'].values()]
-    result['status'] = 'BLOQUEADO' if 'BLOQUEADO' in statuses else 'REPROVADO' if 'REPROVADO' in statuses else 'APROVADO'
-    with output.open('x', encoding='utf-8') as stream:
-        json.dump(result, stream, indent=2, ensure_ascii=True)
-        stream.write('\n')
+            result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': motivo_seguro(exc),
+                                        'verificacao_completa': False}
+    result['status'] = consolidar_estados([r['status'] for r in result['perfis'].values()])
+    return result
+
+
+def main():
+    try:
+        manifest_path, output = map(Path, sys.argv[1:])
+        if not outside_git(output):
+            raise ErroConferencia('RELATORIO_DENTRO_DO_GIT')
+        try:
+            result = conferir_manifesto(manifest_path)
+        except Exception as exc:
+            result = {'status': 'BLOQUEADO', 'motivo': motivo_seguro(exc),
+                      'verificacao_completa': False, 'homologacao': False}
+        with output.open('x', encoding='utf-8') as stream:
+            json.dump(result, stream, indent=2, ensure_ascii=True)
+            stream.write('\n')
+    except Exception as exc:
+        print(json.dumps({'status': 'BLOQUEADO', 'motivo': motivo_seguro(exc)}))
+        return 2
     print(result['status'])
-    return 2 if result['status'] == 'BLOQUEADO' else 1 if result['status'] == 'REPROVADO' else 0
+    return {'APROVADO': 0, 'REPROVADO': 1, 'BLOQUEADO': 2}[result['status']]
 
 
 if __name__ == '__main__':
````

## 11/11 — tools/win01/executar.py

````diff
diff --git a/tools/win01/executar.py b/tools/win01/executar.py
--- a/tools/win01/executar.py
+++ b/tools/win01/executar.py
@@ -13,6 +13,36 @@
 
 BASE = '770d062d29c4361d6932592883df9339bb4089bc'
 ROOT = Path(__file__).resolve().parents[2]
+
+
+def motivo_execucao(exc):
+    if isinstance(exc, subprocess.TimeoutExpired):
+        return 'TEMPO_LIMITE_EXCEDIDO'
+    if isinstance(exc, FileExistsError):
+        return 'ARTEFATO_JA_EXISTE'
+    if isinstance(exc, FileNotFoundError):
+        return 'EXECUTAVEL_OU_ARQUIVO_AUSENTE'
+    if isinstance(exc, PermissionError):
+        return 'ACESSO_NEGADO'
+    if isinstance(exc, (json.JSONDecodeError, UnicodeError, ET.ParseError)):
+        return 'RELATORIO_INVALIDO'
+    if isinstance(exc, OSError):
+        return 'FALHA_IO'
+    return 'FALHA_DE_PREPARACAO'
+
+
+def classificar_passo(name, code):
+    if code == 0:
+        return 'APROVADO', None
+    if name == 'excel':
+        return ('REPROVADO', 'CONFERENCIA_EXCEL_REPROVADA') if code == 1 else ('BLOQUEADO', 'CONFERENCIA_EXCEL_INCOMPLETA')
+    if name == 'pytest':
+        return ('REPROVADO', 'TESTES_REPROVADOS') if code == 1 else ('BLOQUEADO', 'PYTEST_NAO_CONCLUIDO')
+    if name == 'coleta':
+        return 'BLOQUEADO', 'COLETA_NAO_CONCLUIDA'
+    if name == 'pip-check':
+        return 'BLOQUEADO', 'DEPENDENCIAS_INCONSISTENTES'
+    return 'BLOQUEADO', 'COMANDO_NAO_CONCLUIDO'
 
 
 def main():
@@ -39,21 +69,35 @@
     run.mkdir(parents=True, exist_ok=False)
     report = {'etapa': args.etapa, 'head': BASE, 'origem': 'execucao Windows desta rodada',
               'python': sys.version, 'windows': platform.platform(), 'homologacao': False,
-              'utc': datetime.now(timezone.utc).isoformat(), 'steps': []}
+              'utc': datetime.now(timezone.utc).isoformat(), 'steps': [],
+              'bloqueadores_homologacao': ['ACL_COMPARESTRINGORDINAL_REPROVADO_NA_BASE'],
+              'aprovacao_da_etapa_nao_remove_bloqueadores': True}
     failed = blocked = False
     paths = []
     report['artefatos_sha256'] = {}
     def step(name, cmd):
         nonlocal failed, blocked
-        record = {'name': name, 'command': list(map(str, cmd))}
+        replacements = [(str(sys.executable), '<PYTHON>'), (str(ROOT), '<CHECKOUT>'), (str(run), '<EVIDENCIAS>')]
+        if args.manifesto_excel:
+            replacements.insert(0, (str(args.manifesto_excel.resolve()), '<MANIFESTO_PRIVADO>'))
+        safe_command = []
+        for argument in map(str, cmd):
+            for source, replacement in replacements:
+                argument = argument.replace(source, replacement)
+            safe_command.append(argument)
+        record = {'name': name, 'command': safe_command}
         try:
             result = subprocess.run(cmd, cwd=ROOT, capture_output=True, timeout=1800)
             (run / (name + '.log')).write_bytes(result.stdout + b'\n' + result.stderr)
             code = result.returncode
-            record.update(exit_code=code, status='APROVADO' if code == 0 else 'REPROVADO')
-            failed |= code != 0
+            status, reason = classificar_passo(name, code)
+            record.update(exit_code=code, status=status)
+            if reason:
+                record['motivo'] = reason
+            failed |= status == 'REPROVADO'
+            blocked |= status == 'BLOQUEADO'
         except (OSError, subprocess.TimeoutExpired) as exc:
-            record.update(status='BLOQUEADO', motivo=type(exc).__name__)
+            record.update(status='BLOQUEADO', motivo=motivo_execucao(exc))
             blocked = True
             code = None
         report['steps'].append(record)
@@ -78,6 +122,12 @@
             else:
                 manifest = args.manifesto_excel.resolve()
                 step('excel', [sys.executable, '-X', 'utf8', str(ROOT / 'tools/win01/conferir_excel.py'), str(manifest), str(run / 'excel.json')])
+                if (run / 'excel.json').exists():
+                    excel = json.loads((run / 'excel.json').read_text(encoding='utf-8'))
+                    report['conferencia_excel'] = excel
+                    blocked |= not excel.get('verificacao_completa', False)
+                    if not excel.get('verificacao_completa', False):
+                        report.setdefault('motivos_pendentes', []).append('EIXOS_EXCEL_PENDENTES')
         else:
             if args.etapa == 'rapida':
                 step('sintaxe', [sys.executable, '-X', 'utf8', str(ROOT / 'tools/win01/verificar_sintaxe.py')])
@@ -92,12 +142,20 @@
                         # Windows PowerShell normalmente emite OEM; relatório é ASCII.
                         native = json.loads((run / 'ntfs.log').read_bytes().decode('ascii'))
                     report['sonda'] = native
-                    blocked |= native.get('ntfs') != 'APROVADO' or native.get('leitura_acl') != 'APROVADO'
-                    blocked |= any(native.get(key, {}).get('status') != 'APROVADO' for key in ('HardLink', 'SymbolicLink', 'Junction'))
+                    for key, reason in [('ntfs', 'VOLUME_NTFS_NAO_CONFIRMADO'), ('leitura_acl', 'LEITURA_ACL_NAO_CONFIRMADA')]:
+                        if native.get(key) != 'APROVADO':
+                            blocked = True
+                            report.setdefault('motivos_pendentes', []).append(reason)
+                    for key in ('HardLink', 'SymbolicLink', 'Junction'):
+                        if native.get(key, {}).get('status') != 'APROVADO':
+                            blocked = True
+                            report.setdefault('motivos_pendentes', []).append(key.upper() + '_NAO_CONFIRMADO')
                 if step('caminhos-8-3', [sys.executable, str(ROOT / 'tools/win01/sonda_caminhos.py'), str(probe)]) == 0:
                     short_paths = json.loads((run / 'caminhos-8-3.log').read_text(encoding='utf-8'))
                     report['caminhos'] = short_paths
                     blocked |= short_paths['8_3'] != 'APROVADO'
+                    if short_paths['8_3'] != 'APROVADO':
+                        report.setdefault('motivos_pendentes', []).append('NOME_8_3_NAO_CONFIRMADO')
                     failed |= short_paths['normalizacao'] == 'REPROVADO'
                 report['controles_pendentes'] = ['politica ACL efetiva no app', 'outro usuario/processo hostil', 'recuperacao apos crash', 'restricao real de leitura/escrita', '8.3 se desabilitado no volume']
             scope = scopes[{'rapida': 'integrada', 'nativa': 'nativa', 'completa': 'completa'}[args.etapa]]
@@ -113,9 +171,11 @@
                     counts = report['pytest_totais']
                     counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
                     report['skips_requerem_revisao'] = counts['skipped'] > 0
+                    if counts['skipped']:
+                        report.setdefault('motivos_pendentes', []).append('SKIPS_EXIGEM_REVISAO')
     except Exception as exc:
         blocked = True
-        report['bloqueio'] = type(exc).__name__  # sem paths/conteúdo de documentos
+        report['bloqueio'] = motivo_execucao(exc)  # sem paths/conteúdo de documentos
     finally:
         final_status = git('status', '--porcelain=v1', '--untracked-files=all')
         (run / 'git-final.txt').write_text(final_status, encoding='utf-8')
@@ -124,12 +184,17 @@
         report['git_status_preservado'] &= subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=ROOT) == (run / 'index-diff.patch').read_bytes()
         report['git_status_preservado'] &= all(p.exists() and hashlib.sha256(p.read_bytes()).hexdigest() == report['artefatos_sha256'][p.relative_to(ROOT).as_posix()] for p in paths)
         failed |= not report['git_status_preservado']
-        report['status'] = 'BLOQUEADO' if blocked else 'REPROVADO' if failed else 'APROVADO'
+        report['status'] = 'REPROVADO' if failed else 'BLOQUEADO' if blocked else 'APROVADO'
         (run / 'relatorio.json').write_text(json.dumps(report, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
     print('Etapa:', args.etapa, 'Status:', report['status'], 'Evidencias:', run)
     print('Resultado da etapa nao constitui homologacao; revisar skips e controles ausentes.')
-    return 2 if blocked else 1 if failed else 0
+    return 1 if failed else 2 if blocked else 0
 
 
 if __name__ == '__main__':
-    raise SystemExit(main())
+    try:
+        exit_code = main()
+    except Exception as exc:
+        print(json.dumps({'status': 'BLOQUEADO', 'motivo': motivo_execucao(exc)}))
+        exit_code = 2
+    raise SystemExit(exit_code)
````

