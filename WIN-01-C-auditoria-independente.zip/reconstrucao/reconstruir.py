"""Reconstrói A/C em destinos novos ou confere bytes; biblioteca padrão, sem instalação."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
BASE = '770d062d29c4361d6932592883df9339bb4089bc'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(root, version):
    spec = json.loads((HERE / ('versao_' + version + '.json')).read_text(encoding='utf-8'))
    head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    if head != BASE:
        raise RuntimeError('BASE_DIFERENTE')
    for name, expected in spec['arquivos'].items():
        p = root / name
        if not p.is_file() or p.is_symlink() or digest(p) != expected:
            raise RuntimeError('HASH_DIVERGENTE: ' + name)
    extras = []
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if any(part in ('.git', '__pycache__', '.pytest_cache') for part in rel.parts):
            continue
        if p.is_file() and rel.as_posix() not in spec['arquivos']:
            extras.append(rel.as_posix())
    if extras:
        raise RuntimeError('ARQUIVOS_EXTRAS: ' + ', '.join(sorted(extras)))
    return {'versao': version, 'base': head, 'arquivos_verificados': len(spec['arquivos']), 'hashes': 'OK'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--destino', type=Path)
    parser.add_argument('--verificar', type=Path)
    parser.add_argument('--versao', choices=('A', 'C'))
    args = parser.parse_args()
    if args.verificar:
        if not args.versao:
            parser.error('--verificar requer --versao A ou C')
        print(json.dumps(check(args.verificar.resolve(), args.versao)))
        return
    if not args.repo or not args.destino:
        parser.error('requer --repo e --destino')
    repo = args.repo.resolve(); dest = args.destino.resolve()
    plans = []
    for version in ('A', 'C'):
        target = dest / ('WIN-01-' + version)
        if target.exists() or target.is_symlink():
            raise RuntimeError('DESTINO_PREEXISTENTE: ' + target.name)
        spec = json.loads((HERE / ('versao_' + version + '.json')).read_text(encoding='utf-8'))
        for name, after in spec['payload'].items():
            rel = Path(name)
            if rel.is_absolute() or '..' in rel.parts or ':' in name or '\\' in name:
                raise RuntimeError('CAMINHO_INVALIDO')
            if digest(HERE / 'payload' / version / rel) != after:
                raise RuntimeError('PAYLOAD_CORROMPIDO: ' + name)
        plans.append((version, target, spec))
    subprocess.run(['git', '-C', str(repo), 'cat-file', '-e', BASE + '^{commit}'], check=True)
    dest.mkdir(parents=True, exist_ok=True)
    results = []
    for version, target, spec in plans:
        # -c evita conversão CRLF durante o checkout, sem mudar configuração do repositório.
        subprocess.run(['git', '-C', str(repo), '-c', 'core.autocrlf=false', 'worktree', 'add', '--detach', str(target), BASE], check=True)
        # Preflight integral antes de substituir qualquer arquivo de baseline conhecido.
        for name in spec['payload']:
            p = target / name
            expected = spec['antes'].get(name)
            if expected is None:
                if p.exists() or p.is_symlink():
                    raise RuntimeError('COLISAO_NAO_PREVISTA: ' + name)
            elif not p.is_file() or p.is_symlink() or digest(p) != expected:
                raise RuntimeError('BASE_COM_BYTES_DIFERENTES: ' + name)
        for name in sorted(spec['payload']):
            p = target / name; data = (HERE / 'payload' / version / name).read_bytes()
            p.parent.mkdir(parents=True, exist_ok=True)
            if spec['antes'].get(name) is None:
                with p.open('xb') as stream:
                    stream.write(data)
            else:
                if digest(p) != spec['antes'][name]:
                    raise RuntimeError('ALTERACAO_CONCORRENTE: ' + name)
                with tempfile.NamedTemporaryFile(dir=p.parent, delete=False) as stream:
                    temp = Path(stream.name); stream.write(data)
                try:
                    os.replace(temp, p)
                finally:
                    temp.unlink(missing_ok=True)
        results.append(check(target, version))
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
