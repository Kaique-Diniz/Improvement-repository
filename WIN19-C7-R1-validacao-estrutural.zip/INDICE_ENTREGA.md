# WIN19-C7-R1 — índice da entrega

23/11/2026 — America/Sao_Paulo. Pasta nova externa ao Git:
`/workspace/work/WIN19-C7-R1-VALIDACAO-20261123`.

## Arquivos entregues

1. [RELATORIO_C7_R1_VALIDACAO.md](RELATORIO_C7_R1_VALIDACAO.md) — classificação,
   resultados, base sintética completa e deltas exatos dos modelos adicionais.
2. [DIAGNOSTICO_PARSING_E_METASCHEMA.md](DIAGNOSTICO_PARSING_E_METASCHEMA.md) —
   parsing, metaschema, refs, versões/origem e transcrição da ferramenta.
3. [MATRIZ_SONDAS_E_RESULTADOS_C7_R1.csv](MATRIZ_SONDAS_E_RESULTADOS_C7_R1.csv) —
   81 entradas/esperados/observados/ferramentas/erros/classificações individualizados.
4. [CONFERENCIA_INTEGRIDADE_C6_R1.md](CONFERENCIA_INTEGRIDADE_C6_R1.md) —
   origem, manifesto, três arquivos cobertos, cópia e hashes antes/depois.
5. [PENDENCIAS_E_DECISAO_C7_R1.md](PENDENCIAS_E_DECISAO_C7_R1.md) — limites S/P,
   pendências, estados preservados e ponto de parada.
6. INDICE_ENTREGA.md — este índice.
7. [MANIFESTO_SHA256_C7_R1](MANIFESTO_SHA256_C7_R1) — bytes/SHA-256 dos seis
   documentos anteriores; exclui apenas a si mesmo, com hash informado na conversa.

Somente estes sete documentos são entregues. Não há schema corrigido adicional,
componente ativo, fixture executável ou script .py na pasta de entrega. Blocos
Python/JSON nos relatórios são evidência textual inerte de procedimento e entradas
sintéticas, não runner C, dados reais ou autorização para executar outro portão.

## Resultado

Único schema avaliado: C6-R1/contratos_c/relatorio.schema.json, 20.837 bytes, SHA-256
`079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e`.
Classificação: APROVADO_ESTRUTURALMENTE no escopo C7-R1. Parsing válido, metaschema
Draft 2020-12 válido, 108 refs locais/36 definições sem ciclos. Oito negativas do
parser rejeitadas; 81 sondas com 66 rejeições e 15 aceitações previstas, incluindo
cinco limites semânticos explícitos. Sem nova desconformidade ou correção aplicada.

A área temporária independente é `/workspace/work/win19-c7-r1-trabalho-OyDjzy`.
Ela contém a cópia autenticada e registros intermediários, sem acesso à candidata
ou custódia privada. Origens e cópia mantiveram os hashes antes e depois.

Referência obrigatória: PARECER_INDEPENDENTE_WIN19_C6_R1_2026-11-23.md, SHA-256
`3bd9230d1ae47c5586f4841568faf4b88587e776b5d0a3f4754512b641ee41ad`.
A mensagem do usuário autoriza especificamente C7-R1; nenhuma aprovação de outro
estágio foi usada para conceder execução WIN ou autenticidade de evidências.

## Parada e preservação

C6, C6-R1, C7, R1-FIX e demais áreas anteriores não foram alteradas. Não houve
Pytest do produto, controles WIN, APIs Windows/DACL, mudanças de privilégios/ACL,
configuração, instalação, runner C, Categoria B, coleta de JUnit ou conversão.
Não houve Git, commit, push, merge, publicação ou ZIP nesta entrega.

prontidao_para_executar=false; WIN/DACL NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE;
runner NÃO_IMPLEMENTADO; C/D/E e conversões reais BLOQUEADOS. Entregar para revisão
independente e não iniciar outras etapas.
