# WIN19-C7-R1 — validação estrutural do relatório corrigido

23/11/2026 — America/Sao_Paulo.

**Classificação do schema corrigido: APROVADO_ESTRUTURALMENTE no recorte C7-R1.**
A inserção de um fechamento resolveu a falha sintática anteriormente reproduzida.
A cópia autenticada foi interpretada com parser estrito e aceita pelo metaschema
Draft 2020-12 offline. As sondas não revelaram nova desconformidade estrutural.
A conclusão não aprova fatos declarados, produto, Windows, DACL ou operação.

## Objeto e integridade

Único contrato avaliado: relatorio.schema.json da C6-R1, 20.837 bytes, SHA-256
`079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e`.
Manifesto C6-R1 autenticado:
`8cdcdc309d934def4b779b13cf0694cc07c534ee46ec4b519aa4ec6ef32d82f3`.
Três registros e o próprio manifesto conferidos; origem e cópia continuam idênticas.
A validação utilizou somente a cópia em área nova, externa ao Git. Nenhum byte do
schema foi corrigido, normalizado ou reserializado sobre a origem/cópia.

## Resultados separados por dimensão

| Verificação | Resultado observado | Alcance |
|---|---|---|
| Integridade da origem e manifesto | CONFERIDA | Três arquivos cobertos; tamanhos/hashes exatos |
| UTF-8/JSON estrito | VALIDO | Sem BOM, duplicatas, constantes não JSON ou conteúdo adicional |
| Metaschema Draft 2020-12 | VALIDO | Classe explicitamente selecionada; sem descoberta de dialeto |
| Referências locais | CONFERIDAS | 108 ocorrências em 36 definições; destinos existentes e sem ciclos |
| Sondas estruturais | 81 resultados previstos | 66 rejeições e 15 aceitações, sem discordância |
| Negativas do parser | 8 rejeitadas | Verificações independentes do mecanismo de leitura |
| Segurança Windows/DACL | NÃO_VALIDADO | Nenhuma execução autorizada ou realizada |
| Fatos/autoridade/custódia/persistência | NÃO_VALIDADO | Fora da comprovação estrutural |

Os 81 resultados são de uma única invocação final da ferramenta de sondas, não
soma de rodadas anteriores. Houve uma etapa inicial de integridade/parsing/metaschema,
seguida da invocação final que repetiu essas precondições e avaliou as 81 entradas.
As oito negativas do parser são registradas separadamente. Não houve pytest.

## Instâncias e restrições examinadas

A base contém exatamente 21 subcasos, 19 identificadores WIN e 26 afirmações,
conforme o planejamento C5. WIN-11/13 têm A/B; o ramo de erro WIN-03 e os protocolos
WIN-18/19 permanecem bloqueados. Trata-se de um relatório modelo completo de estado
não executado, sem evidência real. A versão continua 0.1.0-proposta-c5.

As dez aceitações positivas incluem estado não executado, resultado funcional
ilustrativo sem promover nativo/DACL, SKIP sintético, conclusão de cleanup e resíduo,
timeout, crash, preparação bloqueada e observações false/zero. Os campos pertencem
apenas a modelos; não foi criado processo, arquivo-sentinela ou controle Windows.

As 66 rejeições incluem todos os 19 campos obrigatórios da raiz, propriedades
extras, enums/tipos indevidos, cardinalidades 20/22 de casos e 18 de vínculos,
eixos favoráveis em afirmação não executada/SKIP, ausência com valor ou sem motivo,
cleanup contraditório, custódia/hash incoerentes, escopos de autorização errados,
condicionais por natureza, omissão dos ramos WIN-03 e promoção dos protocolos DACL.

Cada entrada, mutação, esperado, observado, ferramenta, caminho do erro e
classificação consta da matriz CSV. Os modelos base/adicionais estão definidos
adiante; nenhuma entrada foi obtida de documento privado ou de execução nativa.

## Cinco limites semânticos demonstrados

| ID | Aceitação estrutural observada | Consequência |
| --- | --- | --- |
| L01 | 21 objetos com subcaso repetido não provam conjunto exato | Não interpretar como consistência factual ou aprovação do controle |
| L02 | Enum individual não confere o par WIN/subcaso | Não interpretar como consistência factual ou aprovação do controle |
| L03 | Afirmação não obrigatória por contains pode faltar | Não interpretar como consistência factual ou aprovação do controle |
| L04 | IDs declarados não demonstram existência de evidência/autorização | Não interpretar como consistência factual ou aprovação do controle |
| L05 | 19 objetos históricos não asseguram WIN únicos | Não interpretar como consistência factual ou aprovação do controle |

Essas aceitações são limites E/S/P explicitados na C5/C7, não rejeições que foram
relaxadas para obter resultado favorável. A forma do relatório não compara chaves,
resolve a veracidade de referências ou autentica autorização. Especialmente L04
é um **modelo contrafeito e rotulado como tal**, com evidências ausentes e IDs
fabricados; sua aceitação estrutural não permite considerar o conteúdo legítimo.
Não foi detectada desconformidade nova frente às restrições estruturais examinadas.

## Reprodutibilidade das entradas

Todos os modelos e sondas têm natureza externa SINTETICO_NAO_EXECUTADO. Quando o
campo natureza interno recebe REGISTRO_DECLARADO nas entradas N44–N47 e L04, ele é
um valor sob teste para exercitar a condicional, nunca apresentação de um registro
real. Aliases AUTH_FICTICIA_MODELO/REV_FICTICIA_MODELO e referências são fabricados.

A coluna entrada_sintetica da matriz identifica o modelo e as mutações declarativas
aplicadas a uma cópia em memória. Não são comandos, seletores pytest ou alterações
no schema. Campos omitidos na lista de mutações mantêm os valores explícitos da
base abaixo. Os modelos adicionais são deltas exatos e sua reconstrução foi
comparada aos objetos efetivamente avaliados. Não há preenchimento implícito do
schema nem completamento de projeções C7 para fingir instância completa.

### Base completa — MODELO SEM EVIDÊNCIA REAL

```json
{
  "versao_contrato": "0.1.0-proposta-c5",
  "natureza": "SINTETICO_NAO_EXECUTADO",
  "relatorio_id": "RELATORIO_MODELO_C7_R1",
  "execucao_id": "RUN_MODELO_C7_R1",
  "versoes_referencia": [
    {
      "referencia_id": "CONTRATO_MODELO_C5",
      "classe": "CONTRATO_DECLARATIVO",
      "versao_rotulo": null,
      "integridade": {
        "estado": "NAO_DISPONIVEL",
        "sha256": null,
        "fonte_ref": null,
        "revisao_ref": null
      }
    }
  ],
  "autorizacoes": {
    "A": {
      "estado": "PENDENTE",
      "registro_ref": null,
      "escopo": "A",
      "versao_alvo": "0.1.0-proposta-c5"
    },
    "B": {
      "estado": "PENDENTE",
      "registro_ref": null,
      "escopo": "B",
      "versao_alvo": "0.1.0-proposta-c5"
    },
    "C": {
      "estado": "PENDENTE",
      "registro_ref": null,
      "escopo": "C",
      "versao_alvo": "0.1.0-proposta-c5"
    },
    "D": {
      "estado": "PENDENTE",
      "registro_ref": null,
      "escopo": "D",
      "versao_alvo": "0.1.0-proposta-c5"
    },
    "E": {
      "estado": "PENDENTE",
      "registro_ref": null,
      "escopo": "E",
      "versao_alvo": "0.1.0-proposta-c5"
    }
  },
  "execucao": {
    "estado": "NAO_INICIADA",
    "precondicoes": [],
    "interrupcoes": [],
    "primeira_falha": null,
    "falhas_adicionais": [],
    "encerramento_comprovado": null
  },
  "casos": [
    {
      "controle_win": "WIN-01",
      "subcaso_id": "WIN-01",
      "afirmacoes": [
        {
          "afirmacao_id": "FLAGS_DIAGNOSTICAS",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-02",
      "subcaso_id": "WIN-02",
      "afirmacoes": [
        {
          "afirmacao_id": "ALIAS_REAL",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        },
        {
          "afirmacao_id": "NOMES_DISTINTOS",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-03",
      "subcaso_id": "WIN-03",
      "afirmacoes": [
        {
          "afirmacao_id": "UNICODE_ORDINAL",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        },
        {
          "afirmacao_id": "ERRO_API_NATIVA",
          "resultado_ensaio": "BLOQUEADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "T02_ERRO_API_NATIVA_BLOQUEADO"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-04",
      "subcaso_id": "WIN-04",
      "afirmacoes": [
        {
          "afirmacao_id": "POSITIVOS_IDENTIDADE",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        },
        {
          "afirmacao_id": "HARDLINK_NOME_DISTINTO",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-05",
      "subcaso_id": "WIN-05",
      "afirmacoes": [
        {
          "afirmacao_id": "BASELINE_SEM_AUTORIZACAO",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-06",
      "subcaso_id": "WIN-06",
      "afirmacoes": [
        {
          "afirmacao_id": "LINK_REGISTRO",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-07",
      "subcaso_id": "WIN-07",
      "afirmacoes": [
        {
          "afirmacao_id": "LINK_CHAVE",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-08",
      "subcaso_id": "WIN-08",
      "afirmacoes": [
        {
          "afirmacao_id": "LINK_LOCK",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-09",
      "subcaso_id": "WIN-09",
      "afirmacoes": [
        {
          "afirmacao_id": "LINK_EVIDENCIAS",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-10",
      "subcaso_id": "WIN-10",
      "afirmacoes": [
        {
          "afirmacao_id": "LINK_CABECAS",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-11",
      "subcaso_id": "WIN-11-A",
      "afirmacoes": [
        {
          "afirmacao_id": "RAIZ_GIT",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-11",
      "subcaso_id": "WIN-11-B",
      "afirmacoes": [
        {
          "afirmacao_id": "ANCESTRAL_REPOSITORIO",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        },
        {
          "afirmacao_id": "ANCESTRAL_APP",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-12",
      "subcaso_id": "WIN-12",
      "afirmacoes": [
        {
          "afirmacao_id": "FONTE_LINK_MESMOS_BYTES",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-13",
      "subcaso_id": "WIN-13-A",
      "afirmacoes": [
        {
          "afirmacao_id": "FONTE_LINK_INTERNA",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-13",
      "subcaso_id": "WIN-13-B",
      "afirmacoes": [
        {
          "afirmacao_id": "FONTE_LINK_EXTERNA",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-14",
      "subcaso_id": "WIN-14",
      "afirmacoes": [
        {
          "afirmacao_id": "AUTORIDADE_CORPO_RECIBO",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-15",
      "subcaso_id": "WIN-15",
      "afirmacoes": [
        {
          "afirmacao_id": "OPCAO_CANONICOS",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-16",
      "subcaso_id": "WIN-16",
      "afirmacoes": [
        {
          "afirmacao_id": "CLI_DOCUMENTOS",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        },
        {
          "afirmacao_id": "DTO_ISOLADO",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-17",
      "subcaso_id": "WIN-17",
      "afirmacoes": [
        {
          "afirmacao_id": "AUDITORIA_ROUNDTRIP",
          "resultado_ensaio": "NAO_EXECUTADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "MODELO_SEM_EVIDENCIA_REAL"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-18",
      "subcaso_id": "WIN-18",
      "afirmacoes": [
        {
          "afirmacao_id": "PROTOCOLO_DACL_FONTE",
          "resultado_ensaio": "BLOQUEADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "PORTAO_D"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    },
    {
      "controle_win": "WIN-19",
      "subcaso_id": "WIN-19",
      "afirmacoes": [
        {
          "afirmacao_id": "PROTOCOLO_DACL_RAIZ",
          "resultado_ensaio": "BLOQUEADO",
          "funcional": "NÃO_VALIDADO",
          "nativo": "NÃO_VALIDADO",
          "DACL": "NÃO_VALIDADO",
          "observado": {
            "estado": "NAO_OBSERVADO",
            "tipo": "AUSENTE",
            "valor": null,
            "motivo": "MODELO_NAO_OBSERVADO",
            "origem": "NAO_DISPONIVEL",
            "evidencia_refs": []
          },
          "esperado": {
            "estado": "NAO_DEFINIDO",
            "tipo": "AUSENTE",
            "valor": null,
            "fonte_ref": null
          },
          "fundamento": {
            "classe": "NENHUM",
            "autorizacao_ref": null,
            "revisao_ref": null,
            "criterio_ref": null
          },
          "evidencia_refs": [],
          "eventos_refs": [],
          "bloqueios": [
            "PORTAO_D"
          ],
          "revisao_ref": null
        }
      ],
      "capacidade": {
        "estado": "NAO_OBSERVADA",
        "observado": {
          "estado": "NAO_OBSERVADO",
          "tipo": "AUSENTE",
          "valor": null,
          "motivo": "MODELO_NAO_OBSERVADO",
          "origem": "NAO_DISPONIVEL",
          "evidencia_refs": []
        },
        "evidencia_refs": []
      },
      "sentinelas": {
        "estado": "NAO_OBSERVADAS",
        "bytes_integrais_comparados": null,
        "identidade_conferida": null,
        "evidencia_refs": []
      },
      "lacunas": [
        "MODELO_SEM_EVIDENCIA_REAL"
      ]
    }
  ],
  "evidencias": [],
  "eventos_refs": [],
  "mensagens_refs": [],
  "historico": {
    "vinculos": [
      {
        "controle_win": "WIN-01",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-02",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-03",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-04",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-05",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-06",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-07",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-08",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-09",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-10",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-11",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-12",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-13",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-14",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-15",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-16",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-17",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-18",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      },
      {
        "controle_win": "WIN-19",
        "vinculo_historico": "PROVISORIO_SEM_FONTE",
        "revisor": "PENDENTE",
        "fonte_primaria": "SEM_FONTE"
      }
    ],
    "fontes_secundarias_refs": [],
    "skips_quantidade_relatada": 7,
    "skips_individualizacao": "PENDENTE_FONTE_PRIMARIA"
  },
  "cleanup": {
    "estado": "NAO_INICIADO",
    "remocao_comprovada": null,
    "residuo_preservado": null,
    "evidencia_refs": [],
    "falhas": []
  },
  "custodia": {
    "estado": "NAO_DEFINIDA",
    "registro_ref": null,
    "integridade": {
      "estado": "NAO_DISPONIVEL",
      "sha256": null,
      "fonte_ref": null,
      "revisao_ref": null
    }
  },
  "lacunas": [
    "MODELO_SEM_EVIDENCIA_REAL"
  ],
  "situacao_cobertura": "NAO_EXECUTADA",
  "efeito_autorizador": "NENHUM",
  "homologacao": "NAO_CONCEDIDA_PELO_CONTRATO",
  "conversoes_reais": "BLOQUEADAS"
}
```

### Modelos adicionais — mutações exatas sobre a base

```json
{
  "FUNCIONAL_SINTETICO": [
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/estado",
      "value": "DEFINIDO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/fonte_ref",
      "value": "CRIT_MODELO_01"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/tipo",
      "value": "BOOLEANO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/valor",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/funcional",
      "value": "APROVADO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/fundamento/classe",
      "value": "MODELO_SINTETICO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/fundamento/criterio_ref",
      "value": "CRIT_MODELO_01"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/estado",
      "value": "OBSERVADO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/motivo",
      "value": null
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/origem",
      "value": "HELPER"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/tipo",
      "value": "BOOLEANO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/valor",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/resultado_ensaio",
      "value": "PASS"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/estado",
      "value": "DISPONIVEL_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/estado",
      "value": "OBSERVADO"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/motivo",
      "value": null
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/origem",
      "value": "HELPER"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/tipo",
      "value": "BOOLEANO"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/valor",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/bytes_integrais_comparados",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/estado",
      "value": "PRESERVACAO_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/identidade_conferida",
      "value": true
    },
    {
      "op": "replace",
      "path": "/evidencias",
      "value": [
        {
          "evidencia_id": "EVI_MODELO_01",
          "classe": "MODELO_SINTETICO",
          "origem_rotulo": "MODELO_DOCUMENTAL",
          "execucao_ref": "RUN_MODELO_C7_R1",
          "integridade": {
            "estado": "NAO_DISPONIVEL",
            "sha256": null,
            "fonte_ref": null,
            "revisao_ref": null
          },
          "custodia": {
            "estado": "NAO_DEFINIDA",
            "registro_ref": null,
            "integridade": {
              "estado": "NAO_DISPONIVEL",
              "sha256": null,
              "fonte_ref": null,
              "revisao_ref": null
            }
          },
          "revisao_ref": null
        }
      ]
    },
    {
      "op": "replace",
      "path": "/execucao/encerramento_comprovado",
      "value": true
    },
    {
      "op": "replace",
      "path": "/execucao/estado",
      "value": "ENCERRADA_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/situacao_cobertura",
      "value": "PARCIAL"
    }
  ],
  "SKIP_SINTETICO": [
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/observado/estado",
      "value": "OBSERVADO"
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/observado/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/observado/motivo",
      "value": null
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/observado/origem",
      "value": "HELPER"
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/observado/tipo",
      "value": "CODIGO_WIN32"
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/observado/valor",
      "value": 1314
    },
    {
      "op": "replace",
      "path": "/casos/5/afirmacoes/0/resultado_ensaio",
      "value": "SKIP"
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/estado",
      "value": "INDISPONIVEL_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/observado/estado",
      "value": "OBSERVADO"
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/observado/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/observado/motivo",
      "value": null
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/observado/origem",
      "value": "HELPER"
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/observado/tipo",
      "value": "CODIGO_WIN32"
    },
    {
      "op": "replace",
      "path": "/casos/5/capacidade/observado/valor",
      "value": 1314
    },
    {
      "op": "replace",
      "path": "/evidencias",
      "value": [
        {
          "evidencia_id": "EVI_MODELO_01",
          "classe": "MODELO_SINTETICO",
          "origem_rotulo": "MODELO_DOCUMENTAL",
          "execucao_ref": "RUN_MODELO_C7_R1",
          "integridade": {
            "estado": "NAO_DISPONIVEL",
            "sha256": null,
            "fonte_ref": null,
            "revisao_ref": null
          },
          "custodia": {
            "estado": "NAO_DEFINIDA",
            "registro_ref": null,
            "integridade": {
              "estado": "NAO_DISPONIVEL",
              "sha256": null,
              "fonte_ref": null,
              "revisao_ref": null
            }
          },
          "revisao_ref": null
        }
      ]
    }
  ],
  "ROTULO_REAL_CONTRAFEITO_SINTETICO": [
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/estado",
      "value": "DEFINIDO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/fonte_ref",
      "value": "CRIT_MODELO_01"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/tipo",
      "value": "BOOLEANO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/esperado/valor",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/funcional",
      "value": "APROVADO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/fundamento/autorizacao_ref",
      "value": "AUTH_FICTICIA_MODELO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/fundamento/classe",
      "value": "EVIDENCIA_EXECUCAO_REVISADA"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/fundamento/criterio_ref",
      "value": "CRIT_MODELO_01"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/fundamento/revisao_ref",
      "value": "REV_FICTICIA_MODELO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/estado",
      "value": "OBSERVADO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/motivo",
      "value": null
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/origem",
      "value": "HELPER"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/tipo",
      "value": "BOOLEANO"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/observado/valor",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/resultado_ensaio",
      "value": "PASS"
    },
    {
      "op": "replace",
      "path": "/casos/0/afirmacoes/0/revisao_ref",
      "value": "REV_FICTICIA_MODELO"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/estado",
      "value": "DISPONIVEL_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/estado",
      "value": "OBSERVADO"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/motivo",
      "value": null
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/origem",
      "value": "HELPER"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/tipo",
      "value": "BOOLEANO"
    },
    {
      "op": "replace",
      "path": "/casos/0/capacidade/observado/valor",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/bytes_integrais_comparados",
      "value": true
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/estado",
      "value": "PRESERVACAO_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/evidencia_refs",
      "value": [
        "EVI_MODELO_01"
      ]
    },
    {
      "op": "replace",
      "path": "/casos/0/sentinelas/identidade_conferida",
      "value": true
    },
    {
      "op": "replace",
      "path": "/execucao/encerramento_comprovado",
      "value": true
    },
    {
      "op": "replace",
      "path": "/execucao/estado",
      "value": "ENCERRADA_DECLARADA"
    },
    {
      "op": "replace",
      "path": "/natureza",
      "value": "REGISTRO_DECLARADO"
    },
    {
      "op": "replace",
      "path": "/situacao_cobertura",
      "value": "PARCIAL"
    }
  ]
}
```

## Encerramento

Entregar para auditoria independente. Não houve correção adicional, import do
conversor, instalação, APIs nativas, runner C, Categoria B, ensaio DACL, Git,
publicação ou conversão real. C6 original permanece reprovada como coleção histórica;
a conclusão presente refere-se apenas ao schema de relatório C6-R1 autenticado.
