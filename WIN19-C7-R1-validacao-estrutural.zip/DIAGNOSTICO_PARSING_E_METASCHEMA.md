# C7-R1 — parsing, metaschema, referências e ferramenta

23/11/2026. Resultado: sintaxe VALIDO e metaschema VALIDO para a cópia C6-R1.
O erro L39/C5 da C6 original não ocorreu no arquivo corrigido. Não foi necessário
nem autorizado alterar o schema para concluir as verificações.

## Parser estrito

UTF-8 errors=strict, recusa de BOM, object_pairs_hook para recusar chaves repetidas,
parse_constant para recusar NaN/Infinity e json.loads para recusar conteúdo extra.
parse_float adicionalmente recusa representação float não finita. Esse limite de
representação não é nova regra do contrato: um número como 1e999 pode ser lexicalmente
JSON, mas não seria representável como float finito por este procedimento. O arquivo
recebido não contém esse caso. Não houve normalização dos bytes da entrada.

```json
{
  "parsing": {
    "estado": "VALIDO",
    "UTF8_estrito": true,
    "sem_BOM": true,
    "duplicadas_recusadas": true,
    "constantes_nao_JSON_recusadas": true,
    "conteudo_adicional_recusado": true,
    "sem_CR": true,
    "LF_final": true
  },
  "negativas_parser": [
    {
      "id": "DUPLICADA",
      "rejeitado": true,
      "erro": "PROPRIEDADE_DUPLICADA:a"
    },
    {
      "id": "NAN",
      "rejeitado": true,
      "erro": "CONSTANTE_NAO_JSON:NaN"
    },
    {
      "id": "INFINITY",
      "rejeitado": true,
      "erro": "CONSTANTE_NAO_JSON:Infinity"
    },
    {
      "id": "MENOS_INFINITY",
      "rejeitado": true,
      "erro": "CONSTANTE_NAO_JSON:-Infinity"
    },
    {
      "id": "BOM",
      "rejeitado": true,
      "erro": "BOM_PROIBIDO"
    },
    {
      "id": "UTF8_INVALIDO",
      "rejeitado": true,
      "erro": "'utf-8' codec can't decode byte 0xff in position 6: invalid start byte"
    },
    {
      "id": "CONTEUDO_ADICIONAL",
      "rejeitado": true,
      "erro": "Extra data: line 1 column 4 (char 3)"
    },
    {
      "id": "TRUNCADO",
      "rejeitado": true,
      "erro": "Expecting property name enclosed in double quotes: line 1 column 2 (char 1)"
    }
  ]
}
```

## Metaschema e resolução local

`Draft202012Validator.check_schema` efetivamente executado, usando os metaschemas
preexistentes embarcados na instalação local. Dialeto Draft 2020-12 selecionado
explicitamente; ausência intencional de $schema/$id não foi tratada como erro ou
como permissão para buscar rede. Registry de instâncias recusa retrieval externo.
Audit hook do processo bloqueia sockets, subprocessos, ctypes e imports conversor;
leitura limitada à área de trabalho, origem C6-R1 para integridade e prefixo do
runtime; escrita somente na área de trabalho temporária. Foram observadas zero
solicitações de retrieval no registro de instâncias; não houve acesso remoto.

```json
{
  "metaschema": {
    "estado": "VALIDO",
    "classe": "Draft202012Validator",
    "dialeto": "Draft 2020-12 offline, seleção explícita",
    "operadores_presentes": [
      "additionalProperties",
      "allOf",
      "anyOf",
      "const",
      "contains",
      "else",
      "enum",
      "if",
      "maxItems",
      "minItems",
      "not",
      "oneOf",
      "required",
      "then",
      "type"
    ],
    "refs_ocorrencias": 108,
    "defs": 36,
    "ciclos": false,
    "erros": []
  },
  "retrievals_externos": []
}
```

Os operadores allOf, oneOf, anyOf, not e if/then/else foram efetivamente avaliados
nas sondas. Exemplos: N20/N38 eixos não executados; N23 cleanup contraditório;
N21/N22 ausência; N43 boolean diferente de inteiro; N29/N40/N41 natureza sintética;
N44–N47 condicional de registro rotulado; N30–N35/N39 ramos bloqueados; N11–N13
cardinalidades. Erros por instância e schema constam integralmente da matriz.
Não se afirma exploração exaustiva de todas as combinações possíveis.

### Referências encontradas e seus destinos

```json
[
  {
    "path": "/properties/versao_contrato/$ref",
    "destino": "#/$defs/Versao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/natureza/$ref",
    "destino": "#/$defs/NaturezaRegistro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/relatorio_id/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/execucao_id/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/versoes_referencia/items/$ref",
    "destino": "#/$defs/ReferenciaVersao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/autorizacoes/properties/A/allOf/0/$ref",
    "destino": "#/$defs/AutorizacaoRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/autorizacoes/properties/B/allOf/0/$ref",
    "destino": "#/$defs/AutorizacaoRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/autorizacoes/properties/C/allOf/0/$ref",
    "destino": "#/$defs/AutorizacaoRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/autorizacoes/properties/D/allOf/0/$ref",
    "destino": "#/$defs/AutorizacaoRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/autorizacoes/properties/E/allOf/0/$ref",
    "destino": "#/$defs/AutorizacaoRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/execucao/$ref",
    "destino": "#/$defs/EstadoExecucao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/casos/items/$ref",
    "destino": "#/$defs/Caso",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/evidencias/items/$ref",
    "destino": "#/$defs/Evidencia",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/eventos_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/mensagens_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/historico/$ref",
    "destino": "#/$defs/Historico",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/cleanup/$ref",
    "destino": "#/$defs/Cleanup",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/custodia/$ref",
    "destino": "#/$defs/CustodiaRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/properties/lacunas/$ref",
    "destino": "#/$defs/ListaCodigos",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/allOf/1/then/properties/versoes_referencia/items/properties/integridade/$ref",
    "destino": "#/$defs/HashNaoFabricado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/allOf/1/then/properties/custodia/properties/integridade/$ref",
    "destino": "#/$defs/HashNaoFabricado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/allOf/1/then/properties/evidencias/items/properties/integridade/$ref",
    "destino": "#/$defs/HashNaoFabricado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/allOf/1/then/properties/evidencias/items/properties/custodia/properties/integridade/$ref",
    "destino": "#/$defs/HashNaoFabricado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/allOf/1/then/properties/casos/items/properties/afirmacoes/items/allOf/1/then/properties/revisao_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/EstadoExecucao/properties/precondicoes/items/$ref",
    "destino": "#/$defs/Condicao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/EstadoExecucao/properties/interrupcoes/items/$ref",
    "destino": "#/$defs/Interrupcao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/EstadoExecucao/properties/primeira_falha/anyOf/0/$ref",
    "destino": "#/$defs/FalhaSegura",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/EstadoExecucao/properties/falhas_adicionais/items/$ref",
    "destino": "#/$defs/FalhaSegura",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/ReferenciaVersao/properties/referencia_id/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/ReferenciaVersao/properties/versao_rotulo/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/ReferenciaVersao/properties/integridade/$ref",
    "destino": "#/$defs/HashDeclarado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/AutorizacaoRef/properties/registro_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/AutorizacaoRef/properties/versao_alvo/$ref",
    "destino": "#/$defs/Versao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/AutorizacaoRef/then/properties/registro_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Condicao/properties/condicao_id/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Condicao/properties/observado/$ref",
    "destino": "#/$defs/Observacao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Condicao/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Interrupcao/properties/fase/$ref",
    "destino": "#/$defs/Etapa",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Interrupcao/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Interrupcao/properties/detalhe_seguro/$ref",
    "destino": "#/$defs/CodigoSeguro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/properties/evidencia_id/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/properties/origem_rotulo/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/properties/execucao_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/properties/integridade/$ref",
    "destino": "#/$defs/HashDeclarado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/properties/custodia/$ref",
    "destino": "#/$defs/CustodiaRef",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/properties/revisao_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Evidencia/then/properties/execucao_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Caso/properties/controle_win/$ref",
    "destino": "#/$defs/Win",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Caso/properties/subcaso_id/$ref",
    "destino": "#/$defs/Subcaso",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Caso/properties/afirmacoes/items/$ref",
    "destino": "#/$defs/Afirmacao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Caso/properties/capacidade/$ref",
    "destino": "#/$defs/Capacidade",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Caso/properties/sentinelas/$ref",
    "destino": "#/$defs/Sentinelas",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Caso/properties/lacunas/$ref",
    "destino": "#/$defs/ListaCodigos",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Capacidade/properties/observado/$ref",
    "destino": "#/$defs/Observacao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Capacidade/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Sentinelas/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/afirmacao_id/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/resultado_ensaio/$ref",
    "destino": "#/$defs/ResultadoEnsaio",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/funcional/$ref",
    "destino": "#/$defs/ResultadoEixo",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/nativo/$ref",
    "destino": "#/$defs/ResultadoEixo",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/DACL/$ref",
    "destino": "#/$defs/ResultadoEixo",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/observado/$ref",
    "destino": "#/$defs/Observacao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/esperado/$ref",
    "destino": "#/$defs/Esperado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/fundamento/$ref",
    "destino": "#/$defs/Fundamento",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/eventos_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/bloqueios/$ref",
    "destino": "#/$defs/ListaCodigos",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Afirmacao/properties/revisao_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Fundamento/properties/autorizacao_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Fundamento/properties/revisao_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Fundamento/properties/criterio_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Fundamento/allOf/2/then/properties/criterio_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Fundamento/allOf/2/then/properties/autorizacao_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Fundamento/allOf/3/then/properties/revisao_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Cleanup/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Cleanup/properties/falhas/items/$ref",
    "destino": "#/$defs/FalhaSegura",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Historico/properties/vinculos/items/properties/controle_win/$ref",
    "destino": "#/$defs/Win",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Historico/properties/fontes_secundarias_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/ListaRefs/items/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/ListaCodigos/items/$ref",
    "destino": "#/$defs/CodigoSeguro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/ValorPresente/oneOf/4/properties/valor/$ref",
    "destino": "#/$defs/CodigoSeguro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/properties/sha256/anyOf/0/$ref",
    "destino": "#/$defs/SHA",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/properties/fonte_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/properties/revisao_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/1/then/properties/sha256/$ref",
    "destino": "#/$defs/SHA",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/1/then/properties/fonte_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/2/then/properties/sha256/$ref",
    "destino": "#/$defs/SHA",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/2/then/properties/fonte_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/2/then/properties/revisao_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/3/then/properties/fonte_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashDeclarado/allOf/3/then/properties/revisao_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/HashNaoFabricado/allOf/0/$ref",
    "destino": "#/$defs/HashDeclarado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Observacao/properties/tipo/$ref",
    "destino": "#/$defs/TipoValor",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Observacao/properties/motivo/anyOf/0/$ref",
    "destino": "#/$defs/CodigoSeguro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Observacao/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Observacao/then/allOf/0/$ref",
    "destino": "#/$defs/ValorPresente",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Observacao/else/properties/motivo/$ref",
    "destino": "#/$defs/CodigoSeguro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Esperado/properties/tipo/$ref",
    "destino": "#/$defs/TipoValor",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Esperado/properties/fonte_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Esperado/then/allOf/0/$ref",
    "destino": "#/$defs/ValorPresente",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/Esperado/then/properties/fonte_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/FalhaSegura/properties/fase/$ref",
    "destino": "#/$defs/Etapa",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/FalhaSegura/properties/codigo_seguro/$ref",
    "destino": "#/$defs/CodigoSeguro",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/FalhaSegura/properties/codigo_original/$ref",
    "destino": "#/$defs/Observacao",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/FalhaSegura/properties/evidencia_refs/$ref",
    "destino": "#/$defs/ListaRefs",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/CustodiaRef/properties/registro_ref/anyOf/0/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/CustodiaRef/properties/integridade/$ref",
    "destino": "#/$defs/HashDeclarado",
    "estado": "RESOLVIDA_LOCALMENTE"
  },
  {
    "path": "/$defs/CustodiaRef/allOf/1/then/properties/registro_ref/$ref",
    "destino": "#/$defs/ID",
    "estado": "RESOLVIDA_LOCALMENTE"
  }
]
```

## Ferramentas e origem observada

Runtime Linux/Python preexistente; nenhuma instalação, resolução de dependência
pela rede ou execução de módulo do produto. Versões e origem foram observadas na
instalação local, sem alegar assinatura de fornecedor ou reprodutibilidade de wheel.
Os hashes METADATA são do texto reencodificado UTF-8. A ferramenta temporária é
procedimento independente autorizado de validação C7-R1, não componente do runner C.

```json
{
  "ambiente": {
    "python": "3.12.14",
    "executavel": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python",
    "plataforma": "linux",
    "isolated": 1,
    "dont_write_bytecode": true
  },
  "bibliotecas": [
    {
      "nome": "jsonschema",
      "versao": "4.26.0",
      "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
      "texto_METADATA_sha256": "05b189866ca98a96da3934bf6b83687ced3ff85325273b77e16b705f6d8b26d2"
    },
    {
      "nome": "referencing",
      "versao": "0.37.0",
      "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
      "texto_METADATA_sha256": "c93b00e6ab1524fd60848376604c189a114374776475c25a31d57be47b29de6a"
    },
    {
      "nome": "jsonschema-specifications",
      "versao": "2025.9.1",
      "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
      "texto_METADATA_sha256": "35abd41757f32b4ea24756920ded47b70173d77cbc052a5a6d3ab583b2e8d89d"
    },
    {
      "nome": "attrs",
      "versao": "26.1.0",
      "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
      "texto_METADATA_sha256": "4cd40e690f23bf37cbcad34efd6758e062df1df07c86833f7e3ce95bf1fa38cc"
    },
    {
      "nome": "rpds-py",
      "versao": "2026.6.3",
      "raiz": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages",
      "texto_METADATA_sha256": "f8be7b17da3980b2c48596941411a43c70ac41b1e2d530aa531f2c15eab2eb1c"
    }
  ],
  "ferramenta_sha256": "031e72877280c9a32962dade8ce1dfefac23f71b848b10c1ba3286b62ded29cd"
}
```

## Reprodução e limitações

Invocação final efetivamente executada:

```text
python -I -B /workspace/work/win19-c7-r1-trabalho-OyDjzy/validar_c7_r1.py
```

A fonte exata segue transcrita como evidência textual inerte, sem arquivo .py na
entrega documental. Para reproduzir em outra área autorizada é necessário adaptar
W/S aos caminhos externos e autenticar novamente a origem; a adaptação terá outro
hash e deverá ser registrada. Nenhum bloco autoriza execução em Windows ou outro
portão. -I -B, audit hook e Registry são restrições do procedimento, não prova de
sandbox de kernel ou segurança contra scripts arbitrários. Nenhum arquivo recebido
foi importado ou executado, e nenhum módulo do conversor foi carregado.

### Transcrição integral da ferramenta independente

```python
"""Ferramenta temporária independente C7-R1; sem runner C ou módulos do produto."""
import sys, os, pathlib, json, math, hashlib, copy, importlib.metadata, platform
W=pathlib.Path('/workspace/work/win19-c7-r1-trabalho-OyDjzy')
S=pathlib.Path('/workspace/work/WIN19-C6-R1-CORRECAO-20261123')
P=pathlib.Path(sys.prefix).resolve()
def guard(event,args):
    if event.startswith(('socket.','subprocess.','ctypes.')) or event in {'os.system','os.exec','os.posix_spawn'}: raise RuntimeError('FORA_ESCOPO_C7_R1')
    if event=='import' and (args[0]=='conversor' or args[0].startswith('conversor.')): raise RuntimeError('IMPORT_PRODUTO_PROIBIDO')
    if event=='open' and isinstance(args[0],(str,bytes)):
        path=pathlib.Path(args[0]).resolve()
        writing=bool(args[2] & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing and not path.is_relative_to(W): raise RuntimeError('ESCRITA_FORA_AREA_C7_R1')
        if not writing and not any(path.is_relative_to(root) for root in (W,S,P)): raise RuntimeError('LEITURA_FORA_ESCOPO_C7_R1')
sys.addaudithook(guard)
def sha(b): return hashlib.sha256(b).hexdigest()
def snapshot():
    mb=(S/'MANIFESTO_SHA256_C6_R1').read_bytes()
    assert sha(mb)=='8cdcdc309d934def4b779b13cf0694cc07c534ee46ec4b519aa4ec6ef32d82f3','MANIFESTO_DIVERGENTE'
    lines=mb.decode('utf-8',errors='strict').splitlines()
    assert lines[0]=='sha256;bytes;arquivo' and len(lines)==4
    expected={'contratos_c/relatorio.schema.json','INDICE_ENTREGA_C6_R1.md','DIFF_C6_C6_R1.patch'}
    result={'MANIFESTO_SHA256_C6_R1':{'bytes':len(mb),'sha256':sha(mb)}}
    for line in lines[1:]:
        h,size,name=line.split(';'); assert name in expected and name not in result
        b=(S/name).read_bytes(); assert len(b)==int(size) and sha(b)==h,'INTEGRIDADE_DIVERGENTE'
        result[name]={'bytes':len(b),'sha256':sha(b)}
    assert set(result)==expected|{'MANIFESTO_SHA256_C6_R1'}
    assert result['contratos_c/relatorio.schema.json']=={'bytes':20837,'sha256':'079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e'}
    return result
before=snapshot()
target=W/'copias/contratos_c/relatorio.schema.json'; target.parent.mkdir(parents=True,exist_ok=True)
if target.exists():
    assert not target.is_symlink() and target.read_bytes()==(S/'contratos_c/relatorio.schema.json').read_bytes(),'COPIA_PREEXISTENTE_DIVERGENTE'
else:
    with target.open('xb') as f: f.write((S/'contratos_c/relatorio.schema.json').read_bytes())
raw=target.read_bytes(); assert sha(raw)==before['contratos_c/relatorio.schema.json']['sha256']
R={'integridade_antes':before,'schema_copia_antes':{'bytes':len(raw),'sha256':sha(raw)},'ambiente':{'python':platform.python_version(),'executavel':sys.executable,'plataforma':sys.platform,'isolated':sys.flags.isolated,'dont_write_bytecode':sys.dont_write_bytecode},'parsing':{},'metaschema':{},'referencias':[],'sondas':[],'negativas_parser':[]}
class StrictError(ValueError): pass
def pairs(values):
    out={}
    for k,v in values:
        if k in out: raise StrictError('PROPRIEDADE_DUPLICADA:'+k)
        out[k]=v
    return out
def badconstant(v): raise StrictError('CONSTANTE_NAO_JSON:'+v)
def finite(v):
    n=float(v)
    if not math.isfinite(n): raise StrictError('FLOAT_NAO_FINITO_LOCAL')
    return n
def strict(b):
    if b.startswith(b'\xef\xbb\xbf'): raise StrictError('BOM_PROIBIDO')
    return json.loads(b.decode('utf-8',errors='strict'),object_pairs_hook=pairs,parse_constant=badconstant,parse_float=finite)
def save():
    (W/'resultado_c7_r1.json').write_text(json.dumps(R,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
try:
    schema=strict(raw)
    assert isinstance(schema,dict)
    R['parsing']={'estado':'VALIDO','UTF8_estrito':True,'sem_BOM':True,'duplicadas_recusadas':True,'constantes_nao_JSON_recusadas':True,'conteudo_adicional_recusado':True,'sem_CR':b'\r' not in raw,'LF_final':raw.endswith(b'\n')}
except (ValueError,AssertionError) as e:
    R['parsing']={'estado':'INVALIDO','erro':str(e)}; R['metaschema']={'estado':'BLOQUEADO'}; save(); raise SystemExit('PARSING_INVALIDO; SEM_VALIDACAO_FORMAL')
for name,b in [('DUPLICADA',b'{"a":1,"a":2}'),('NAN',b'{"a":NaN}'),('INFINITY',b'{"a":Infinity}'),('MENOS_INFINITY',b'{"a":-Infinity}'),('BOM',b'\xef\xbb\xbf{}'),('UTF8_INVALIDO',b'{"a":"\xff"}'),('CONTEUDO_ADICIONAL',b'{} {}'),('TRUNCADO',b'{')]:
    try: strict(b); R['negativas_parser'].append({'id':name,'rejeitado':False})
    except ValueError as e: R['negativas_parser'].append({'id':name,'rejeitado':True,'erro':str(e)})
try:
    from jsonschema import Draft202012Validator
    from referencing import Registry
except ImportError as e:
    R['metaschema']={'estado':'NÃO_VALIDADO','erro':str(e)}; save(); raise SystemExit('BIBLIOTECA_INDISPONIVEL')
R['bibliotecas']=[]
for name in ('jsonschema','referencing','jsonschema-specifications','attrs','rpds-py'):
    d=importlib.metadata.distribution(name)
    R['bibliotecas'].append({'nome':name,'versao':d.version,'raiz':str(d.locate_file('')),'texto_METADATA_sha256':sha(d.read_text('METADATA').encode('utf-8'))})
requests=[]
def deny(uri):
    requests.append(uri)
    raise RuntimeError('REFERENCIA_EXTERNA_PROIBIDA')
registry=Registry(retrieve=deny)
def pointer(path): return '/'+ '/'.join(str(x).replace('~','~0').replace('/','~1') for x in path)
def walk(obj,path=()):
    if isinstance(obj,dict):
        yield path,obj
        for k,v in obj.items(): yield from walk(v,path+(k,))
    elif isinstance(obj,list):
        for n,v in enumerate(obj): yield from walk(v,path+(n,))
graph={k:set() for k in schema['$defs']}; operators=set()
for path,obj in walk(schema):
    operators.update(k for k in obj if k in ('allOf','oneOf','anyOf','not','if','then','else','required','type','enum','const','additionalProperties','minItems','maxItems','contains'))
    assert not any(k in obj for k in ('$schema','$id','$dynamicRef','$data','default','contentEncoding','contentSchema')),'PERFIL_OFFLINE_DIVERGENTE'
    if '$ref' in obj:
        ref=obj['$ref']; dest=ref.removeprefix('#/$defs/')
        assert ref.startswith('#/$defs/') and '/' not in dest and dest in graph,'REFERENCIA_NAO_LOCAL_OU_INEXISTENTE'
        R['referencias'].append({'path':pointer(path+('$ref',)),'destino':ref,'estado':'RESOLVIDA_LOCALMENTE'})
        if len(path)>=2 and path[0]=='$defs': graph[path[1]].add(dest)
def visit(node,anc):
    assert node not in anc,'CICLO_DE_REFS'
    for child in graph[node]: visit(child,anc|{node})
for node in graph: visit(node,set())
try:
    Draft202012Validator.check_schema(schema)
    R['metaschema']={'estado':'VALIDO','classe':'Draft202012Validator','dialeto':'Draft 2020-12 offline, seleção explícita','operadores_presentes':sorted(operators),'refs_ocorrencias':len(R['referencias']),'defs':len(graph),'ciclos':False,'erros':[]}
except Exception as e:
    R['metaschema']={'estado':'INVALIDO','erro':str(e)}; save(); raise SystemExit('METASCHEMA_INVALIDO; NAO_CORRIGIR')
validator=Draft202012Validator(schema,registry=registry)
R['rede_retrievals']=requests
save()
print('INTEGRIDADE',len(before),'ARQUIVOS_AUTENTICADOS; COPIA_20837_BYTES')
print('PARSING',R['parsing'])
print('METASCHEMA',R['metaschema'])
# Modelos exclusivamente sintéticos. Nenhum objeto é coletado do produto ou Windows.
VERSION='0.1.0-proposta-c5'; NV='NÃO_VALIDADO'
PLAN=[('WIN-01',['FLAGS_DIAGNOSTICAS']),('WIN-02',['ALIAS_REAL','NOMES_DISTINTOS']),('WIN-03',['UNICODE_ORDINAL','ERRO_API_NATIVA']),('WIN-04',['POSITIVOS_IDENTIDADE','HARDLINK_NOME_DISTINTO']),('WIN-05',['BASELINE_SEM_AUTORIZACAO']),('WIN-06',['LINK_REGISTRO']),('WIN-07',['LINK_CHAVE']),('WIN-08',['LINK_LOCK']),('WIN-09',['LINK_EVIDENCIAS']),('WIN-10',['LINK_CABECAS']),('WIN-11-A',['RAIZ_GIT']),('WIN-11-B',['ANCESTRAL_REPOSITORIO','ANCESTRAL_APP']),('WIN-12',['FONTE_LINK_MESMOS_BYTES']),('WIN-13-A',['FONTE_LINK_INTERNA']),('WIN-13-B',['FONTE_LINK_EXTERNA']),('WIN-14',['AUTORIDADE_CORPO_RECIBO']),('WIN-15',['OPCAO_CANONICOS']),('WIN-16',['CLI_DOCUMENTOS','DTO_ISOLADO']),('WIN-17',['AUDITORIA_ROUNDTRIP']),('WIN-18',['PROTOCOLO_DACL_FONTE']),('WIN-19',['PROTOCOLO_DACL_RAIZ'])]
def unknownhash(): return {'estado':'NAO_DISPONIVEL','sha256':None,'fonte_ref':None,'revisao_ref':None}
def custody(): return {'estado':'NAO_DEFINIDA','registro_ref':None,'integridade':unknownhash()}
def absent(): return {'estado':'NAO_OBSERVADO','tipo':'AUSENTE','valor':None,'motivo':'MODELO_NAO_OBSERVADO','origem':'NAO_DISPONIVEL','evidencia_refs':[]}
def undefined(): return {'estado':'NAO_DEFINIDO','tipo':'AUSENTE','valor':None,'fonte_ref':None}
def nonebasis(): return {'classe':'NENHUM','autorizacao_ref':None,'revisao_ref':None,'criterio_ref':None}
def claim(name,sub):
    blocked=name=='ERRO_API_NATIVA' or sub in ('WIN-18','WIN-19')
    blocks=['T02_ERRO_API_NATIVA_BLOQUEADO'] if name=='ERRO_API_NATIVA' else ['PORTAO_D'] if sub in ('WIN-18','WIN-19') else ['MODELO_SEM_EVIDENCIA_REAL']
    return {'afirmacao_id':name,'resultado_ensaio':'BLOQUEADO' if blocked else 'NAO_EXECUTADO','funcional':NV,'nativo':NV,'DACL':NV,'observado':absent(),'esperado':undefined(),'fundamento':nonebasis(),'evidencia_refs':[],'eventos_refs':[],'bloqueios':blocks,'revisao_ref':None}
base={'versao_contrato':VERSION,'natureza':'SINTETICO_NAO_EXECUTADO','relatorio_id':'RELATORIO_MODELO_C7_R1','execucao_id':'RUN_MODELO_C7_R1',
'versoes_referencia':[{'referencia_id':'CONTRATO_MODELO_C5','classe':'CONTRATO_DECLARATIVO','versao_rotulo':None,'integridade':unknownhash()}],
'autorizacoes':{axis:{'estado':'PENDENTE','registro_ref':None,'escopo':axis,'versao_alvo':VERSION} for axis in 'ABCDE'},
'execucao':{'estado':'NAO_INICIADA','precondicoes':[],'interrupcoes':[],'primeira_falha':None,'falhas_adicionais':[],'encerramento_comprovado':None},
'casos':[{'controle_win':sub[:6],'subcaso_id':sub,'afirmacoes':[claim(name,sub) for name in names],'capacidade':{'estado':'NAO_OBSERVADA','observado':absent(),'evidencia_refs':[]},'sentinelas':{'estado':'NAO_OBSERVADAS','bytes_integrais_comparados':None,'identidade_conferida':None,'evidencia_refs':[]},'lacunas':['MODELO_SEM_EVIDENCIA_REAL']} for sub,names in PLAN],
'evidencias':[],'eventos_refs':[],'mensagens_refs':[],
'historico':{'vinculos':[{'controle_win':f'WIN-{n:02}','vinculo_historico':'PROVISORIO_SEM_FONTE','revisor':'PENDENTE','fonte_primaria':'SEM_FONTE'} for n in range(1,20)],'fontes_secundarias_refs':[],'skips_quantidade_relatada':7,'skips_individualizacao':'PENDENTE_FONTE_PRIMARIA'},
'cleanup':{'estado':'NAO_INICIADO','remocao_comprovada':None,'residuo_preservado':None,'evidencia_refs':[],'falhas':[]},
'custodia':custody(),'lacunas':['MODELO_SEM_EVIDENCIA_REAL'],'situacao_cobertura':'NAO_EXECUTADA','efeito_autorizador':'NENHUM','homologacao':'NAO_CONCEDIDA_PELO_CONTRATO','conversoes_reais':'BLOQUEADAS'}
assert len(base['casos'])==21 and len({c['subcaso_id'] for c in base['casos']})==21 and len({c['controle_win'] for c in base['casos']})==19
assert sum(len(c['afirmacoes']) for c in base['casos'])==26
R['base_sintetica']=base
R['modelos_adicionais']={}
def change(path,value=None,op='replace'): return {'op':op,'path':path,**({} if op=='remove' else {'value':value})}
def apply_ops(document,ops):
    result=copy.deepcopy(document)
    for operation in ops:
        keys=[x.replace('~1','/').replace('~0','~') for x in operation['path'].split('/')[1:]]
        obj=result
        for key in keys[:-1]: obj=obj[int(key)] if isinstance(obj,list) else obj[key]
        key=keys[-1]
        if isinstance(obj,list):
            if key=='-': assert operation['op']=='add'; obj.append(copy.deepcopy(operation['value']))
            elif operation['op']=='remove': del obj[int(key)]
            else: obj[int(key)]=copy.deepcopy(operation['value'])
        elif operation['op']=='remove': del obj[key]
        else: obj[key]=copy.deepcopy(operation['value'])
    return result

def probe(sid,label,expected,ops=(),model='BASE',category='RESTRICAO_ESTRUTURAL'):
    document=apply_ops(base if model=='BASE' else R['modelos_adicionais'][model],ops)
    # Persistir a definição da entrada antes da avaliação e das conclusões.
    row={'id':sid,'descricao':label,'natureza_ensaio':'SINTETICO_NAO_EXECUTADO','modelo':model,'mutacoes':list(ops),'categoria':category,'esperado':'VALIDO' if expected else 'INVALIDO','observado':'NAO_EXECUTADO','ferramenta':'jsonschema 4.26.0 / Draft202012Validator','erros':[]}
    R['sondas'].append(row); save()
    try:
        errors=list(validator.iter_errors(document))
        row['observado']='INVALIDO' if errors else 'VALIDO'
        row['erros']=[{'instancia':pointer(e.absolute_path),'schema':pointer(e.absolute_schema_path),'restricao':e.validator,'mensagem':e.message} for e in errors]
    except Exception as e:
        row.update(observado='BLOQUEADO',erro_operacional=str(e)); save(); raise
    row['coincide']=row['esperado']==row['observado']
    row['classificacao']='LIMITE_SEMANTICO_CONFIRMADO' if category=='LIMITE_SEMANTICO' and row['coincide'] else 'CONFORME_A_EXPECTATIVA_ESTRUTURAL' if row['coincide'] else 'DESCONFORMIDADE_OBSERVADA'
    save()

def evidence(): return {'evidencia_id':'EVI_MODELO_01','classe':'MODELO_SINTETICO','origem_rotulo':'MODELO_DOCUMENTAL','execucao_ref':'RUN_MODELO_C7_R1','integridade':unknownhash(),'custodia':custody(),'revisao_ref':None}
def obs(value=True,kind='BOOLEANO'): return {'estado':'OBSERVADO','tipo':kind,'valor':value,'motivo':None,'origem':'HELPER','evidencia_refs':['EVI_MODELO_01']}
func=copy.deepcopy(base)
func['evidencias']=[evidence()]
func['situacao_cobertura']='PARCIAL'
func['execucao'].update(estado='ENCERRADA_DECLARADA',encerramento_comprovado=True)
af=func['casos'][0]['afirmacoes'][0]
af.update(resultado_ensaio='PASS',funcional='APROVADO',observado=obs(),esperado={'estado':'DEFINIDO','tipo':'BOOLEANO','valor':True,'fonte_ref':'CRIT_MODELO_01'},fundamento={'classe':'MODELO_SINTETICO','autorizacao_ref':None,'revisao_ref':None,'criterio_ref':'CRIT_MODELO_01'},evidencia_refs=['EVI_MODELO_01'])
func['casos'][0]['capacidade'].update(estado='DISPONIVEL_DECLARADA',observado=obs(),evidencia_refs=['EVI_MODELO_01'])
func['casos'][0]['sentinelas'].update(estado='PRESERVACAO_DECLARADA',bytes_integrais_comparados=True,identidade_conferida=True,evidencia_refs=['EVI_MODELO_01'])
R['modelos_adicionais']['FUNCIONAL_SINTETICO']=func
skip=copy.deepcopy(base); skip['evidencias']=[evidence()]
skip['casos'][5]['afirmacoes'][0].update(resultado_ensaio='SKIP',observado=obs(1314,'CODIGO_WIN32'),evidencia_refs=['EVI_MODELO_01'])
skip['casos'][5]['capacidade'].update(estado='INDISPONIVEL_DECLARADA',observado=obs(1314,'CODIGO_WIN32'),evidencia_refs=['EVI_MODELO_01'])
R['modelos_adicionais']['SKIP_SINTETICO']=skip
# Valor REGISTRO_DECLARADO é colocado sob teste em modelo CONTRAFEITO declarado.
# Nunca é evidência de execução real ou aprovação factual.
marked=copy.deepcopy(func); marked['natureza']='REGISTRO_DECLARADO'; marked['evidencias']=[]
marked['casos'][0]['afirmacoes'][0]['fundamento']={'classe':'EVIDENCIA_EXECUCAO_REVISADA','autorizacao_ref':'AUTH_FICTICIA_MODELO','revisao_ref':'REV_FICTICIA_MODELO','criterio_ref':'CRIT_MODELO_01'}
marked['casos'][0]['afirmacoes'][0]['revisao_ref']='REV_FICTICIA_MODELO'
R['modelos_adicionais']['ROTULO_REAL_CONTRAFEITO_SINTETICO']=marked
probe('P01','Relatório sintético completo não executado, com 21 casos/26 afirmações',True)
probe('P02','Modelo funcional favorável sem promover nativo/DACL',True,model='FUNCIONAL_SINTETICO')
probe('P03','SKIP sintético de capacidade, eixos não validados',True,model='SKIP_SINTETICO')
probe('P04','Cleanup conclusão declarada não aprova controles',True,[change('/cleanup',{'estado':'CONCLUSAO_DECLARADA','remocao_comprovada':True,'residuo_preservado':False,'evidencia_refs':[],'falhas':[]})])
probe('P05','Resíduo preservado com remoção desconhecida',True,[change('/cleanup',{'estado':'RESIDUO_PRESERVADO','remocao_comprovada':None,'residuo_preservado':True,'evidencia_refs':[],'falhas':[]})])
for sid,state in [('P06','TIMEOUT'),('P07','CRASH')]:
    probe(sid,state+' sintético não é conclusão comprovada',True,[change('/execucao/estado',state),change('/execucao/interrupcoes',[{'tipo':state,'fase':'OPERACAO','evidencia_refs':[],'detalhe_seguro':state+'_MODELO'}]),change('/situacao_cobertura','EVIDENCIA_INSUFICIENTE')])
probe('P08','Setup bloqueado sem FAIL funcional fabricado',True,[change('/execucao/estado','BLOQUEADA'),change('/execucao/interrupcoes',[{'tipo':'SETUP','fase':'PREPARACAO','evidencia_refs':[],'detalhe_seguro':'SETUP_MODELO'}]),change('/casos/0/afirmacoes/0/resultado_ensaio','BLOQUEADO')])
probe('P09','Boolean false é valor, não ausência ou aprovação',True,[change('/casos/0/afirmacoes/0/observado',obs(False))])
probe('P10','Win32 zero em observação sintética não é PASS',True,[change('/casos/0/afirmacoes/0/observado',obs(0,'CODIGO_WIN32'))])
required=['versao_contrato','natureza','relatorio_id','execucao_id','versoes_referencia','autorizacoes','execucao','casos','evidencias','eventos_refs','mensagens_refs','historico','cleanup','custodia','lacunas','situacao_cobertura','efeito_autorizador','homologacao','conversoes_reais']
for n,key in enumerate(required,1): probe(f'R{n:02}','Ausência do campo raiz obrigatório '+key,False,[change('/'+key,op='remove')])
negative=[
('N01','Campo raiz adicional','/extra','MODELO'),('N02','Versão desconhecida','/versao_contrato','9.9.9'),('N03','Natureza desconhecida','/natureza','NOVO'),('N04','Agregado PASS proibido','/situacao_cobertura','PASS'),('N05','Homologação proibida','/homologacao','APROVADO'),('N06','Efeito autorizador proibido','/efeito_autorizador','AUTORIZADO'),('N07','Conversão desbloqueada proibida','/conversoes_reais','LIBERADAS'),('N08','ID acima do limite de representação','/relatorio_id','A'*65),('N09','ID numérico indevido','/relatorio_id',12),
('N10','Lista de versões vazia','/versoes_referencia',[]),('N11','Somente 20 casos','/casos',base['casos'][:-1]),('N12','22 casos','/casos',base['casos']+[base['casos'][0]]),('N13','Somente 18 vínculos históricos','/historico/vinculos',base['historico']['vinculos'][:-1]),('N14','Histórico promovido indevidamente','/historico/vinculos/0/vinculo_historico','CONFIRMADO'),('N15','Tipo indevido na lista de casos','/casos/0',None),('N16','Lista de afirmações vazia','/casos/0/afirmacoes',[]),
('N17','Campo adicional em caso','/casos/0/extra','MODELO'),('N18','Resultado de eixo fora do enum','/casos/0/afirmacoes/0/nativo','NOVO'),('N19','Estado de ensaio fora do enum','/casos/0/afirmacoes/0/resultado_ensaio','NOVO'),('N20','Não executado com eixo aprovado','/casos/0/afirmacoes/0/funcional','APROVADO'),('N21','Ausência observada com valor preenchido','/casos/0/afirmacoes/0/observado/valor',False),('N22','Ausência sem motivo','/casos/0/afirmacoes/0/observado/motivo',None),
('N23','Cleanup contraditório','/cleanup',{'estado':'CONCLUSAO_DECLARADA','remocao_comprovada':True,'residuo_preservado':True,'evidencia_refs':[],'falhas':[]}),('N24','Conclusão de cleanup sem remoção','/cleanup',{'estado':'CONCLUSAO_DECLARADA','remocao_comprovada':None,'residuo_preservado':False,'evidencia_refs':[],'falhas':[]}),('N25','Custódia declarada sem registro','/custodia/estado','DECLARADA'),('N26','Hash indisponível com digest inventado','/versoes_referencia/0/integridade/sha256','1'*64),('N27','Fundamento NENHUM com critério','/casos/0/afirmacoes/0/fundamento/criterio_ref','CRIT_MODELO_01'),('N28','Mapa de autorização com escopo errado','/autorizacoes/A/escopo','B'),('N29','Modelo com autorização C alegada','/autorizacoes/C',{'estado':'AUTORIZADA_DECLARADA','registro_ref':'AUTH_MODELO','escopo':'C','versao_alvo':VERSION}),
('N30','Unicode omitido do WIN-03','/casos/2/afirmacoes',base['casos'][2]['afirmacoes'][1:]),('N31','Erro API omitido do WIN-03','/casos/2/afirmacoes',base['casos'][2]['afirmacoes'][:1]),('N32','Erro API sem bloqueio obrigatório','/casos/2/afirmacoes/1/bloqueios',[]),('N33','WIN-18 sem PORTAO_D','/casos/19/afirmacoes/0/bloqueios',[]),('N34','WIN-19 com SKIP em vez de bloqueio','/casos/20/afirmacoes/0/resultado_ensaio','SKIP'),('N35','WIN-18 com DACL promovida','/casos/19/afirmacoes/0/DACL','APROVADO')]
for sid,label,path,value in negative: probe(sid,label,False,[change(path,value)])
probe('N36','Campo obrigatório da afirmação ausente',False,[change('/casos/0/afirmacoes/0/esperado',op='remove')])
probe('N37','Campo adicional em afirmação',False,[change('/casos/0/afirmacoes/0/todos_aprovados',True)])
probe('N38','SKIP com eixo favorável é recusado',False,[change('/casos/5/afirmacoes/0/funcional','APROVADO')],model='SKIP_SINTETICO')
probe('N39','Erro API nativo indevidamente favorável',False,[change('/casos/2/afirmacoes/1/resultado_ensaio','PASS'),change('/casos/2/afirmacoes/1/nativo','APROVADO')])
probe('N40','Modelo com fundamento de revisão real é recusado',False,[change('/casos/0/afirmacoes/0/fundamento',{'classe':'EVIDENCIA_EXECUCAO_REVISADA','autorizacao_ref':'AUTH_MODELO','revisao_ref':'REV_MODELO','criterio_ref':'CRIT_MODELO_01'})],model='FUNCIONAL_SINTETICO')
probe('N41','Modelo com evidência primária em vez de modelo',False,[change('/evidencias/0/classe','PRIMARIA_EXECUCAO')],model='FUNCIONAL_SINTETICO')
probe('N42','Esperado definido não aceita null como valor',False,[change('/casos/0/afirmacoes/0/esperado/valor',None)],model='FUNCIONAL_SINTETICO')
probe('N43','Boolean não é inteiro em observação',False,[change('/casos/0/afirmacoes/0/observado/tipo','INTEIRO')],model='FUNCIONAL_SINTETICO')
probe('N44','Rótulo de registro com aprovação sem refs de evidência',False,[change('/casos/0/afirmacoes/0/evidencia_refs',[])],model='ROTULO_REAL_CONTRAFEITO_SINTETICO')
probe('N45','Rótulo de registro com aprovação sem revisão',False,[change('/casos/0/afirmacoes/0/revisao_ref',None)],model='ROTULO_REAL_CONTRAFEITO_SINTETICO')
probe('N46','Rótulo de registro com aprovação sem fundamento revisado',False,[change('/casos/0/afirmacoes/0/fundamento',nonebasis())],model='ROTULO_REAL_CONTRAFEITO_SINTETICO')
probe('N47','Rótulo de registro com hash fabricado',False,[change('/versoes_referencia/0/integridade',{'estado':'FABRICADO_PARA_ILUSTRACAO','sha256':'1'*64,'fonte_ref':'EVI_MODELO_01','revisao_ref':None})],model='ROTULO_REAL_CONTRAFEITO_SINTETICO')
# Aceitação estrutural deliberadamente não equivale a coerência/autenticidade.
probe('L01','21 objetos com subcaso repetido não provam conjunto exato',True,[change('/casos/1',base['casos'][0])],category='LIMITE_SEMANTICO')
probe('L02','Enum individual não confere o par WIN/subcaso',True,[change('/casos/1/subcaso_id','WIN-01')],category='LIMITE_SEMANTICO')
probe('L03','Afirmação não obrigatória por contains pode faltar',True,[change('/casos/1/afirmacoes',base['casos'][1]['afirmacoes'][:1])],category='LIMITE_SEMANTICO')
probe('L04','IDs declarados não demonstram existência de evidência/autorização',True,model='ROTULO_REAL_CONTRAFEITO_SINTETICO',category='LIMITE_SEMANTICO')
probe('L05','19 objetos históricos não asseguram WIN únicos',True,[change('/historico/vinculos/1',base['historico']['vinculos'][0])],category='LIMITE_SEMANTICO')
R['rede_retrievals']=requests
R['integridade_depois']=snapshot()
R['schema_copia_depois']={'bytes':target.stat().st_size,'sha256':sha(target.read_bytes())}
assert R['integridade_antes']==R['integridade_depois']
assert R['schema_copia_antes']==R['schema_copia_depois']
R['ferramenta_sha256']=sha(pathlib.Path(__file__).read_bytes())
R['resumo']={'sondas':len(R['sondas']),'concordantes':sum(s['coincide'] for s in R['sondas']),'rejeicoes_previstas':sum(s['esperado']=='INVALIDO' for s in R['sondas']),'aceitacoes_previstas':sum(s['esperado']=='VALIDO' for s in R['sondas']),'limites_semanticos':sum(s['categoria']=='LIMITE_SEMANTICO' for s in R['sondas']),'desconformidades':[s['id'] for s in R['sondas'] if not s['coincide']]}
save()
print('RESUMO',R['resumo'])
print('SCHEMA_PRESERVADO',R['schema_copia_depois'])
print('RETRIEVALS_EXTERNOS',requests)
```
