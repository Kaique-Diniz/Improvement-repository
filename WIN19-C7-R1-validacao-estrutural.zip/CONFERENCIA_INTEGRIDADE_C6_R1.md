# C7-R1 — integridade e preservação de C6-R1

23/11/2026. Antes de qualquer parsing/metaschema, autenticados o manifesto e os
três arquivos cobertos. O schema foi copiado com criação exclusiva para:
`/workspace/work/win19-c7-r1-trabalho-OyDjzy/copias/contratos_c/relatorio.schema.json`.
A área foi criada nova para esta tarefa, fora do Git e das candidatas. O arquivo
não foi reserializado, corrigido ou substituído. Na invocação seguinte, a cópia
existente da própria tarefa foi apenas conferida por igualdade dos bytes.

## Originais antes/depois

| Arquivo | Bytes antes/depois | SHA-256 antes = depois |
| --- | --- | --- |
| MANIFESTO_SHA256_C6_R1 | 309 | 8cdcdc309d934def4b779b13cf0694cc07c534ee46ec4b519aa4ec6ef32d82f3 |
| contratos_c/relatorio.schema.json | 20837 | 079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e |
| INDICE_ENTREGA_C6_R1.md | 6872 | a0d6aeb2a797e8d0a7dd1afd635487d567dfa2bf01074c40a64814f1c08fa5be |
| DIFF_C6_C6_R1.patch | 224 | 7719bd9b038a5ee0d71a1ef82c7359dd080cf7579bf55cf7f106ea9db0b3f544 |

Os dois snapshots foram comparados e são iguais, inclusive o manifesto. Cópia:

```json
{
  "antes": {
    "bytes": 20837,
    "sha256": "079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e"
  },
  "depois": {
    "bytes": 20837,
    "sha256": "079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e"
  },
  "iguais": true
}
```

Somente a cópia do schema foi usada no parsing e na validação formal. O acesso
à origem C6-R1 limitou-se à autenticação e preservação dos bytes. Não se utilizou
schema de nome semelhante, reconstrução sem proveniência ou arquivo do Windows.
Não houve acesso de execução à candidata R1-FIX, C6 original, C7 ou custódia privada.

A validação não gravou nenhum dos arquivos anteriores. A identidade local é
comprovada pelos snapshots; não constitui medição do host Windows, prova de
custódia privada ou atestação de ausência de efeitos históricos não observados.
Não houve nova conferência operacional dos 470 arquivos ou dos controles nativos.

## Identidade da referência independente

PARECER_INDEPENDENTE_WIN19_C6_R1_2026-11-23.md, 3.651 bytes, SHA-256
`3bd9230d1ae47c5586f4841568faf4b88587e776b5d0a3f4754512b641ee41ad`.
O parecer aceita a equivalência de um byte, sem conceder validação; a autorização
específica C7-R1 foi dada diretamente na mensagem do usuário de 23/11/2026.

Referências documentais C5/C7 lidas, sem execução ou alteração:

- CONTRATO_RELATORIO_PROPOSTO.md: SHA-256
  `982c73c3a59558cb94e6a5feccdad392642e111518a892f1f105aec8a27608ce`.
- CONTRATO_COBERTURA_21_PROPOSTO.md: SHA-256
  `2a0a74c2a5464cbaddede4a09538802c21b5e8b5c2472d403b52e085d704dcb1`.
- CONSISTENCIA_SEMANTICA_C7.md: SHA-256
  `447c7932c26d982870cf0433f343b6808d6f28d2a67ad41be2383ebdc98a3801`.

A referência C5/C7 identifica a intenção documental dos modelos e limites S/P;
nenhuma aprovação histórica da suíte de cleanup ou do produto foi reutilizada.
