"""Regressões sintéticas da ORDEM das funções reais dos testes nativos.

Não usa Win32 e NÃO comprova execução Windows. O guard reproduz a recusa de
leitura relatada pelo usuário enquanto o handle modelado permanece ativo.
Execute com E4_R1_CANDIDATA apontando para a worktree a verificar.
"""
import errno
import os
from pathlib import Path
from types import SimpleNamespace
import sys

import pytest

CANDIDATA = Path(os.environ['E4_R1_CANDIDATA'])
sys.path.insert(0, str(CANDIDATA))
sys.path.insert(0, str(CANDIDATA/'src'))
from tools.exp04_win import test_cleanup_windows as native


def request_sintetico():
    return SimpleNamespace(node=SimpleNamespace(user_properties=[]))


def proteger_leitura(monkeypatch, state):
    original = Path.read_bytes
    def read(path):
        state['eventos'].append('leitura')
        if state['aberto']:
            raise PermissionError(errno.EACCES, 'LEITURA_SINTETICA_COM_HANDLE_ATIVO')
        return original(path)
    monkeypatch.setattr(Path, 'read_bytes', read)


@pytest.mark.parametrize('errado', [False, True])
def test_ordem_processo_auxiliar_e_codigo32(tmp_path, monkeypatch, errado):
    state = {'aberto':False,'eventos':[]}
    proteger_leitura(monkeypatch,state)
    def abrir(*a):
        state['aberto']=True
        return object()
    def remover(root, d):
        state['eventos'].append('exclusao_recusada')
        d.falhar('abertura','CreateFileW','TEMP_HANDLE_INDISPONIVEL',win32=5 if errado else 32)
        raise native.tm.ErroTemporario('TEMP_HANDLE_INDISPONIVEL')
    def liberar(p):
        state['aberto']=False
        state['eventos'].append('liberado')
    monkeypatch.setattr(native,'processo_aberto',abrir)
    monkeypatch.setattr(native,'remover',remover)
    monkeypatch.setattr(native,'liberar',liberar)
    if errado:
        with pytest.raises(AssertionError):
            native.test_windows_arquivo_aberto_outro_processo_share3_falha32(tmp_path,request_sintetico())
        assert state['eventos']==['exclusao_recusada','liberado']
    else:
        native.test_windows_arquivo_aberto_outro_processo_share3_falha32(tmp_path,request_sintetico())
        assert state['eventos']==['exclusao_recusada','liberado','leitura']
    assert not state['aberto']


@pytest.mark.parametrize('errado', [False, True])
def test_ordem_injecao_set5_e_codigo_preservado(tmp_path, monkeypatch, errado):
    state={'aberto':False,'eventos':[],'ultimo_erro':None}
    proteger_leitura(monkeypatch,state)
    def close(handle):return 1
    kernel=SimpleNamespace(CloseHandle=close)
    monkeypatch.setattr(native.ctypes,'WinDLL',lambda *a,**k:kernel,raising=False)
    monkeypatch.setattr(native.ctypes,'set_last_error',lambda value:state.update(ultimo_erro=value),raising=False)
    class Pin:
        def __init__(self,path,*,diagnostico):
            self.diag=diagnostico
            state['aberto']=True
        def apagar(self):
            result=native.ctypes.WinDLL('kernel32').SetFileInformationByHandle(1,4,None,1)
            assert result==0 and state['ultimo_erro']==5
            state['eventos'].append('set_recusado')
            self.diag.falhar('solicitar_exclusao','SetFileInformationByHandle',
                            'TEMP_EXCLUSAO_POR_HANDLE_FALHOU',win32=87 if errado else 5)
            raise native.tm.ErroTemporario('TEMP_EXCLUSAO_POR_HANDLE_FALHOU')
        def fechar(self):
            state['aberto']=False
            state['eventos'].append('fechado')
    monkeypatch.setattr(native.tm,'_PinWin',Pin)
    call=lambda:native.test_windows_injecao_api_preserva_codigo_e_nega_sucesso(
        tmp_path,monkeypatch,'SetFileInformationByHandle',5,request_sintetico())
    if errado:
        with pytest.raises(AssertionError):call()
        assert state['eventos']==['set_recusado','fechado']
    else:
        call()
        assert state['eventos']==['set_recusado','fechado','leitura']
    assert not state['aberto']


def test_adversarios_antes_close_leitura_depois(tmp_path, monkeypatch):
    state={'aberto':False,'eventos':[]}
    proteger_leitura(monkeypatch,state)
    class Pin:
        identidade=(1,b'ID_SINTETICO')
        def __init__(self,path,*,excluir=True,consulta=False):
            self.excluir=excluir
            if excluir:state['aberto']=True
        def fechar(self):
            if self.excluir:
                state['aberto']=False
                state['eventos'].append('fechado')
    def recusar(operation):
        def action(*a,**k):
            assert state['aberto'], 'PIN_FECHADO_ANTES_DO_ADVERSARIO'
            state['eventos'].append(operation)
            e=PermissionError(errno.EACCES,'RECUSA_SINTETICA')
            e.winerror=32
            raise e
        return action
    monkeypatch.setattr(native.tm,'_PinWin',Pin)
    monkeypatch.setattr(Path,'rename',recusar('rename'))
    monkeypatch.setattr(Path,'unlink',recusar('delete'))
    native.test_windows_pin_share3_impede_rename_e_delete_concorrente(tmp_path)
    assert state['eventos']==['rename','delete','fechado','leitura']
