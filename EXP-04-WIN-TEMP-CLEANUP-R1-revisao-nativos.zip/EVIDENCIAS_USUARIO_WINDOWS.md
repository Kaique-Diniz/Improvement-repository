# Evidências Windows fornecidas pelo usuário — candidata anterior de 470 hashes

Origem: transcrição do usuário, nesta revisão, após conferência por ele do JUnit
Windows. O XML original não foi anexado e não foi examinado diretamente pelo
Codex. Não se trata de execução nativa realizada nesta tarefa.

Resultado anterior: 39 coletados, 33 aprovados, três falhas PermissionError
[Errno 13], três skips classificados pelo usuário; contêiner removido, relatório
integral gerado, 470 hashes íntegros. Os nodeids/motivos dos três skips dessa
rodada não foram retranscritos: não os atribuímos individualmente por suposição.

## 1. Processo auxiliar

`tools/exp04_win/test_cleanup_windows.py::test_windows_arquivo_aberto_outro_processo_share3_falha32`

Linha 115 original:

```python
assert path.read_bytes() == b'SINTETICO'
```

Final transcrito: `PermissionError: [Errno 13] Permission denied: '[CAMINHO_PRIVADO_OMITIDO]'`.
A liberação por `liberar(p)` ocorria no finally, linha 119, depois da leitura.

## 2. Injeção de SetFileInformationByHandle

`tools/exp04_win/test_cleanup_windows.py::test_windows_injecao_api_preserva_codigo_e_nega_sucesso[SetFileInformationByHandle-5]`

Linha 257 original:

```python
assert d.dados['primeira_falha']['api'] == api and path.read_bytes() == b'PRESERVAR'
```

Mesmo PermissionError/Errno 13 transcrito. `pin.fechar()` estava no finally,
linhas 258–260, posterior à leitura.

## 3. Pin contra operações concorrentes

`tools/exp04_win/test_cleanup_windows.py::test_windows_pin_share3_impede_rename_e_delete_concorrente`

Linha 300 original:

```python
assert path.read_bytes() == b'PRESERVAR'
```

Mesmo PermissionError/Errno 13 transcrito. `pin.fechar()` estava no finally,
linha 302, posterior à leitura.

O usuário confirmou que os três tracebacks apontam às leituras e autorizou
somente a reordenação desses três testes em candidata derivada. Esta evidência
não demonstra uma falha do motor de limpeza. Não se infere que todo handle
READ_ATTRIBUTES com compartilhamento 0x3 necessariamente recuse ReadData:
o auxiliar usa READ_ATTRIBUTES, enquanto os pins dos outros dois testes usam
DELETE. A localização efetiva da falha de leitura foi informada pelo usuário;
a nova validação Windows determinará o resultado após a mudança de sequência.
