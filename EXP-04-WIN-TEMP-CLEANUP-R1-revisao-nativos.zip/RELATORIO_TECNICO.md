# EXP-04-WIN-TEMP-CLEANUP-R1 — revisão dos três testes nativos

## Alteração aplicada

Derivação isolada da candidata original de 470 hashes, com baseline
`770d062d29c4361d6932592883df9339bb4089bc`. A nova candidata também tem 470
arquivos. Apenas `tools/exp04_win/test_cleanup_windows.py` difere: quatro linhas
adicionadas e três removidas; nenhuma função auxiliar, importação, parametrização
ou marcador foi alterado.

A hipótese foi confirmada por transcrição do usuário dos três pontos do JUnit
Windows. Não tivemos acesso direto ao XML primário. A correção se limita à ordem:

1. Processo auxiliar: conferir API CreateFileW/código 32 enquanto ainda ativo;
   liberar no finally; conferir bytes integrais depois.
2. Injeção SetFileInformationByHandle: manter recusa/erro 5 e API correta dentro
   do try; fechar o pin no finally; ler e comparar os bytes depois. A expressão
   composta foi separada em duas asserções. Os outros dois parâmetros da mesma
   função continuam com os mesmos valores, operações e verificações.
3. Pin de exclusão: preservar query de identidade, rename/delete adversariais e
   códigos Win32 esperados enquanto o pin permanece aberto; fechá-lo no finally;
   ler e comparar o conteúdo depois.

Nenhum fechamento foi antecipado para permitir as operações adversariais. Não
houve substituição por exists(), relaxamento de códigos Win32 ou novo skip.
As asserções atômicas e as chamadas das três funções foram comparadas por AST:
mesmo inventário, só ordem/posição alteradas. Demais nós AST do módulo iguais.
Os outros 469 arquivos são byte a byte iguais, inclusive motor, executor,
produção, testes funcionais/históricos, regras e documentos de preparação.

## Validação realmente realizada: Linux/Python 3.12.14

- Cinco regressões externas de ordenação: cinco aprovadas, zero falhas/skips.
  Invocam as funções reais alteradas com handles sintéticos. Incluem recusa de
  códigos incorretos, liberação garantida e adversários antes do fechamento.
- Controle negativo: as mesmas três verificações positivas, contra a fonte
  original, falham com PermissionError do guard sintético. Resultado esperado
  para demonstrar a sensibilidade da regressão; não são novas falhas Windows.
- Três nativos selecionados diretamente: três skips por Windows indisponível,
  zero executados nativamente; estado NÃO_VALIDADO.
- Escopo de 39 pelo executor original: 26 aprovados, 13 skips nativos, zero
  falhas/erros. Relatório integral gerado, contêiner removido, 470 hashes íntegros
  antes/depois. Não confundir com os três skips da rodada Windows anterior.

Não foi repetida a suíte funcional completa: esta revisão só move asserções de
três testes nativos; todos os arquivos funcionais e motor/executor permaneceram
idênticos. A rodada anterior completa Linux de 2.842 aprovações é histórica da
candidata anterior, não uma nova execução desta R1.

O guard de leitura é uma simulação da restrição relatada, não uma implementação
do compartilhamento Win32. As cinco aprovações não demonstram DACL, exclusão
nativa ou comportamento integral de CreateFileW. A liberação do processo
auxiliar não é substituída por alteração dos flags: share 0x3 permanece intacto.

## Pendências e preservação

Não há executor Windows real disponível nesta tarefa. Reexecutar os três casos
corrigidos e depois os 39 no Windows conforme ROTEIRO_WINDOWS.md. Exigir zero
falhas, skips individualizados, remoção comprovada e hashes íntegros.
Os novos relatórios JUnit Windows ainda não existem: não foram simulados.

Preservadas candidatas/pacotes/evidências anteriores e o ZIP publicado, sem
acessar o residual do usuário. O relatório de preservação contém a conferência
final. Não há commit, push, PR, merge ou publicação desta revisão.

A homologação Windows e a DACL efetiva permanecem NÃO_VALIDADO. As conversões
reais dos quatro novos condomínios permanecem BLOQUEADAS. O escopo não inclui
outra correção de limpeza, atributos, políticas ou produção.
