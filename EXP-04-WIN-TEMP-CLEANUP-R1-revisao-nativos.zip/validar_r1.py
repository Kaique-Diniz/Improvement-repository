"""Executar três nativos ou 39 de limpeza com executor original intacto.

Execução Linux só com opção explícita e nunca conta como validação nativa.
Não instala dependências. Pacote/candidata devem estar integralmente conferidos.
"""
import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import sys

TRES = [
 'tools/exp04_win/test_cleanup_windows.py::test_windows_arquivo_aberto_outro_processo_share3_falha32',
 'tools/exp04_win/test_cleanup_windows.py::test_windows_injecao_api_preserva_codigo_e_nega_sucesso[SetFileInformationByHandle-5]',
 'tools/exp04_win/test_cleanup_windows.py::test_windows_pin_share3_impede_rename_e_delete_concorrente',
]
LIMPEZA = ['tools/exp04_win/test_cleanup_modelo.py',
           'tools/exp04_win/test_cleanup_regressoes.py',
           'tools/exp04_win/test_cleanup_windows.py']


def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--pacote',type=Path,required=True)
 p.add_argument('--candidata',type=Path,required=True)
 p.add_argument('--evidencias',type=Path,required=True)
 p.add_argument('--escopo',choices=('tres','limpeza'),required=True)
 p.add_argument('--permitir-linux',action='store_true')
 a=p.parse_args()
 if os.name!='nt' and not a.permitir_linux:
  print('{"estado":"NAO_VALIDADO","codigo":"WINDOWS_REAL_OBRIGATORIO"}')
  return 2
 try:
  if not all(x.is_absolute() for x in (a.pacote,a.candidata,a.evidencias)):
   raise ValueError()
  from reconstruir import executar as conferir, caminho
  conferir(a.pacote,a.candidata,True)
 except Exception:
  print('{"estado":"BLOQUEADO","codigo":"PACOTE_CANDIDATA_INVALIDOS"}')
  return 2
 sys.path.insert(0,str(a.candidata))
 from tools.exp04_win import executar
 paths,count=(TRES,3) if a.escopo=='tres' else (LIMPEZA,39)
 # Seleção apenas em memória. Usa nome/identificador de escopo já suportado.
 executar.SCOPES={'complementares':(paths,count)}
 captured=io.StringIO()
 with contextlib.redirect_stdout(captured):
  code=executar.main(['--versao',str(a.pacote/'VERSAO_EXP04_WIN_TEMP_CLEANUP_R1_SHA256.json'),
                     '--evidencias',str(a.evidencias),'--escopo','complementares'])
 print(captured.getvalue(),end='')
 if code not in (0,3):return code
 try:
  info=json.loads(captured.getvalue())
  report=caminho(a.evidencias/info['relatorio'])
  j=json.loads(report.read_text(encoding='utf-8'))
  result=j['resultados']['complementares']
  if result['coletados']!=count or result['falhas_ou_erros'] or j['parcial'] or not j['integridade_final']:
   raise ValueError()
  if not all(t['estado']=='REMOVIDO' for t in j['temporarios']):raise ValueError()
  if os.name=='nt':
   if a.escopo=='tres' and (result['aprovados']!=3 or result['ignorados']):
    raise ValueError()
   for case in result['casos']:
    if case['estado']=='NÃO_VALIDADO' and not (case['skip'] or '').startswith(
        ('INJECAO_POSIX;', 'WIN01_SYMLINK_SEM_PRIVILEGIO_1314;')):
     raise ValueError()
  conferir(a.pacote,a.candidata,True)
 except Exception:
  print('{"estado":"NAO_VALIDADO","codigo":"CRITERIOS_REVISAO_NAO_ATENDIDOS"}')
  return 2
 print(json.dumps({'selecao':a.escopo,'coletados':result['coletados'],
                   'aprovados':result['aprovados'],'skips':result['ignorados'],
                   'validacao_nativa':os.name=='nt','DACL':'NÃO_VALIDADO',
                   'homologacao_windows':False,'conversao_real_novos_perfis':'BLOQUEADA'}))
 return code


if __name__=='__main__':raise SystemExit(main())
