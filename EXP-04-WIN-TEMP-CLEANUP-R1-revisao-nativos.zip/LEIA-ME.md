# EXP-04-WIN-TEMP-CLEANUP-R1

Pacote LOCAL, sem publicacao. Revisar antes de nova execucao Windows.

- RELATORIO_TECNICO.md: unica alteracao, justificativas, resultados e limites.
- EXP04_CLEANUP_PARA_R1.patch: diff incremental completo de UM arquivo,
  quatro linhas adicionadas e tres removidas, inclusive a separacao da assercao.
- payload/tools/exp04_win/test_cleanup_windows.py: arquivo revisado integral.
- REVISAO_ASSERCOES.json: equivalencia de assercoes atomicas/chamadas por AST.
- VERSAO_EXP04_WIN_TEMP_CLEANUP_R1_SHA256.json: 470 hashes da nova candidata.
- VERSAO_CLEANUP_470_ORIGINAL_SHA256.json: manifesto original preservado.
- INTEGRIDADE_REVISAO.json: unico hash alterado e prova de reconstrucao.
- EXP04_WIN_TEMP_CLEANUP_R1.patch e BASELINE_SHA256.json: reconstrucao completa
  desde BPQ-04 sem tocar nas candidatas antigas; inclui mudancas herdadas que
  NAO foram feitas nesta revisao. Para atribuir alteracoes, usar o incremental.
- reconstruir.py: exige worktree nova/limpa, recusa extras/links e valida manifesto.
- ROTEIRO_WINDOWS.md e validar_r1.py: tres nativos PRIMEIRO; depois os 39;
  Windows real obrigatorio por padrao. Nao aceita skips nos tres corrigidos.
- evidencias/linux/: JUnit/logs SANITIZADOS, com sistema real explicito.
- EVIDENCIAS_USUARIO_WINDOWS.md: transcricao fornecida pelo usuario sobre a
  candidata ANTERIOR; XML primario nao recebido. Nao atribuir resultados a R1.
- auditoria/test_ordem_leituras.py: guard sintetico externo; nao integra os 470
  arquivos nem os 39. Cinco testes aprovados na R1. O controle negativo de tres
  falhas ESPERADAS roda sobre a fonte anterior e comprova que a regressao detecta
  a ordem antiga. Nao e uma nova falha Windows da candidata revisada.
- PRESERVACAO_FINAL.json e ESTADO_GIT.txt: candidatas e pacotes anteriores intactos.
- MANIFESTO_SHA256.json: todos os membros, exceto ele mesmo; SHA do ZIP e externo.

Reproduzir a auditoria sintetica em Linux com Python 3.12/dependencias ja prontas:

```bash
export PYTHONDONTWRITEBYTECODE=1 PYTHONUTF8=1
export E4_R1_CANDIDATA=/caminho/absoluto/da/nova/candidata
/caminho/do/python -B -m pytest -q -p no:cacheprovider /caminho/do/pacote/auditoria/test_ordem_leituras.py
```

O lancador tambem pode repetir os 39 em Linux APENAS com --permitir-linux, que
rotula a execucao como nao nativa. Isso nao satisfaz a validacao Windows pedida.
Os JUnit Windows da R1 ainda NAO existem. Nenhum resultado nativo foi inventado.

Original publicado e residual do usuario preservados; residual nao acessado.
Somente codigo, fixtures sinteticas e metadados sanitizados, sem documentos reais.
Nenhuma alteracao em temporarios.py/executar.py, producao, regras ou flags 0x3.
DACL e homologacao Windows NAO_VALIDADO. Conversoes reais dos quatro novos
condominios BLOQUEADAS. Sem commit/push/PR/merge/publicacao.
