# R1 — reconstrução LF e reexecução Windows isolada

Revisar o diff antes de executar. Não tocar na candidata anterior de 470 hashes,
nos pacotes publicados nem no contêiner residual antigo. Usar conta comum,
Windows real e Python 3.12 já instalado. Não há instalação automática, alteração
de DACL/privilégios ou configuração Git persistente.

Conferir primeiro o SHA-256 do ZIP contra a entrega. Extrair em pasta NOVA fora
do Git. Ajustar `$Repo`, `$Pacote` e `$Python` aos caminhos disponíveis. Não
substituir documentos/candidatas antigos. Evidências ficam fora do Git.

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'E4-Cleanup-R1'
$Pacote = Join-Path $Root 'pacote'
$C = Join-Path $Root 'candidata'
$Evidencias = Join-Path $Root 'resultados'
$Repo = Join-Path $HOME 'Conversor-MVP-BPQ04'
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe'
$Base = '770d062d29c4361d6932592883df9339bb4089bc'
if (Test-Path -LiteralPath $C) { throw 'CANDIDATA_R1_JA_EXISTE' }
if (-not (Test-Path -LiteralPath $Pacote)) { throw 'PACOTE_AUSENTE' }
if (-not (Test-Path -LiteralPath $Python)) { throw 'PYTHON_AUSENTE' }
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
# LF somente para esta operação; não modifica configuração do repositório.
& git -c core.autocrlf=false -c core.eol=lf -C $Repo worktree add --detach $C $Base
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_NAO_CRIADA' }
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_NAO_CONFERIDA' }
New-Item -ItemType Directory -Path $Evidencias -Force | Out-Null

# Primeiro: exatamente os três casos corrigidos, sem skips aceitáveis.
& $Python -B (Join-Path $Pacote 'validar_r1.py') --pacote $Pacote --candidata $C --evidencias $Evidencias --escopo tres
$StatusTres = $LASTEXITCODE
if ($StatusTres -ne 3) { throw 'TRES_NATIVOS_NAO_APROVADOS_VER_RELATORIO' }

# Depois: 39 testes de limpeza, mantendo skips individualizados.
& $Python -B (Join-Path $Pacote 'validar_r1.py') --pacote $Pacote --candidata $C --evidencias $Evidencias --escopo limpeza
$StatusLimpeza = $LASTEXITCODE
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'HASH_FINAL_DIVERGENTE' }
if ($StatusLimpeza -ne 3) { throw 'LIMPEZA39_NAO_APROVADA_VER_RELATORIO' }
```

O reconstrutor exige baseline correto e árvore limpa; o patch completo evita
uma dependência na candidata antiga. Confere todos os membros do pacote, recusa
extras/links/reparse e verifica os 470 hashes. Não reaplicar sobre tentativa
incompleta. HEAD isoladamente não prova a versão: usar o manifesto integral.

O lançador externo seleciona em memória o escopo existente `complementares`:
três OU 39 casos, conforme `selecao` no stdout. Isso não significa executar os
36 complementares originais. `temporarios.py` e `executar.py` são os mesmos
bytes da candidata anterior. JUnit/logs/relatorio.json e diagnóstico de limpeza
são produzidos pelo executor intacto, com integridade antes/depois.

Critérios: três coletados/aprovados, zero falhas, zero skips na primeira etapa;
39 coletados, zero falhas, skips conhecidos individualizados na segunda;
todos os contêineres novos REMOVIDOS e 470 hashes íntegros antes/depois.
No Windows, o lançador retorna 2 se a primeira etapa tiver qualquer skip; na
segunda, também recusa skips fora dos códigos de permissões POSIX ou symlink
sem privilégio já previstos. Esses controles ignorados continuam NÃO_VALIDADO.
O código 3 preserva a ressalva de segurança do executor, sem homologação.
O lançador recusa Linux por padrão; não usar `--permitir-linux` nesta rodada.

Preservar os relatórios das duas execuções. Cada um contém `resultados` com os
nodeids e motivos dos skips. Não remover nem conceder privilégios para fazer
skips desaparecerem. Uma nova falha deve ser investigada pela operação real do
traceback, sem alterar implementação ou asserções por suposição.

Em erro de limpeza, preservar o novo contêiner e os relatórios parciais; não
limpar manualmente, não atuar no residual anterior. Enviar somente diagnóstico
sanitizado e trechos de traceback sem caminhos privados. DACL efetiva e
homologação Windows permanecem NÃO_VALIDADO. Conversões reais dos quatro novos
condomínios continuam BLOQUEADAS.
