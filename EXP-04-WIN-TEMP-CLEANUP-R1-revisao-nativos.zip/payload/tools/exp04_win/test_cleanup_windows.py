"""Sondas de limpeza em Windows real; somente árvores novas do tmp_path.

Não aceita caminho de contêiner residual. Não lê documentos. Não eleva
privilégios nem altera DACL. Injeções de erros não comprovam falhas nativas.
"""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

import pytest

from tests.windows_support import criar_symlink
from tools.exp04_win import temporarios as tm
from tools.exp04_win.diagnostico_cleanup import Diagnostico

pytestmark = pytest.mark.skipif(os.name != 'nt', reason='WINDOWS_REAL_NAO_DISPONIVEL; LIMPEZA_NATIVA_NAO_VALIDADA')


def remover(root, d=None):
    d = d or Diagnostico()
    d.fase = 'limpeza'
    pin = tm._PinWin(root, diagnostico=d)
    try:
        tm._remover_win(root, pin, diagnostico=d)
        pin.fechar()
        tm._confirmar_ausencia_win(root, pin, d, 0)
    except BaseException as exc:
        if d.dados['primeira_falha'] is None:
            d.capturar(exc, 'TEMP_LIMPEZA_INTERROMPIDA' if isinstance(exc, KeyboardInterrupt) else 'TEMP_PERCURSO_FALHOU')
        raise
    finally:
        pin.fechar()
    return d


def publicar(request, d):
    # Apenas eventos/códigos numéricos e contadores; não inclui nomes ou caminhos.
    request.node.user_properties.append(('diagnostico_cleanup', json.dumps(d.dados, ensure_ascii=True)))
    request.node.user_properties.append(('seguranca_ntfs', 'DACL_WINDOWS_NAO_VALIDADA; EVIDENCIA_INSUFICIENTE'))


def test_windows_1500_irmaos_niveis_arquivos(tmp_path, request):
    root = tmp_path/'a'
    root.mkdir()
    for i in range(1500):
        p = root/str(i)
        p.mkdir()
        (p/'f').write_bytes(b'SINTETICO')
    (root/'n'/'m').mkdir(parents=True)
    (root/'n'/'m'/'f').write_bytes(b'SINTETICO')
    d = remover(root)
    assert not root.exists() and d.dados['contadores']['diretorios'] == 1503
    assert d.dados['contadores']['arquivos'] == 1501
    publicar(request, d)


def processo_aberto(tmp_path, path, share):
    script = tmp_path/'processo-sintetico.py'
    script.write_text('''import ctypes, sys
from ctypes import wintypes
k = ctypes.WinDLL('kernel32', use_last_error=True)
k.CreateFileW.argtypes = [wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
k.CreateFileW.restype = wintypes.HANDLE
k.CloseHandle.argtypes = [wintypes.HANDLE]
k.CloseHandle.restype = wintypes.BOOL
h = k.CreateFileW(sys.argv[1], 0x80, int(sys.argv[2]), None, 3, 0x02200000, None)
assert h not in (None, wintypes.HANDLE(-1).value), 'ABERTURA_SINTETICA_FALHOU'
print('PRONTO', flush=True)
try:
    sys.stdin.readline()
finally:
    assert k.CloseHandle(h), 'FECHAMENTO_SINTETICO_FALHOU'
''', encoding='utf-8', newline='\n')
    p = subprocess.Popen([sys.executable, '-B', str(script), str(path), str(share)],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         text=True, encoding='utf-8')
    # Espera limitada até processo abrir: usa thread só para a leitura do pipe.
    from concurrent.futures import ThreadPoolExecutor
    pool = ThreadPoolExecutor(1)
    future = pool.submit(p.stdout.readline)
    try:
        assert future.result(timeout=10).strip() == 'PRONTO', 'PROCESSO_SINTETICO_NAO_PRONTO'
    except BaseException:
        p.kill()
        p.communicate(timeout=5)
        raise
    finally:
        pool.shutdown(wait=True)
    return p


def liberar(p):
    if p.poll() is None:
        p.stdin.write('\n')
        p.stdin.flush()
    p.communicate(timeout=10)
    assert p.returncode == 0, 'PROCESSO_SINTETICO_FALHOU'


def test_windows_arquivo_aberto_outro_processo_share3_falha32(tmp_path, request):
    root = tmp_path/'a'
    root.mkdir()
    path = root/'f'
    path.write_bytes(b'SINTETICO')
    p = processo_aberto(tmp_path, path, 3)
    d = Diagnostico()
    try:
        with pytest.raises(tm.ErroTemporario):
            remover(root, d)
        assert d.dados['primeira_falha']['api'] == 'CreateFileW'
        assert d.dados['primeira_falha']['win32'] == 32
    finally:
        liberar(p)
    assert path.read_bytes() == b'SINTETICO'
    publicar(request, d)


def test_windows_delete_pendente_share7_confirma_apos_ultimo_close(tmp_path, monkeypatch, request):
    root = tmp_path/'a'
    root.mkdir()
    path = root/'f'
    path.write_bytes(b'SINTETICO')
    p = processo_aberto(tmp_path, path, 7)
    original = tm._confirmar_ausencia_win
    released = False
    def confirmar(file, pin, d, depth):
        nonlocal released
        if file == path:
            # Liberar SOMENTE após Set+Close do executor: prova nativa do pendente.
            assert p.poll() is None
            attributes = pin.api.GetFileAttributesW(str(file))
            error = ctypes.get_last_error() if attributes == 0xFFFFFFFF else None
            assert not (attributes == 0xFFFFFFFF and error in (2, 3)), 'EXCLUSAO_PENDENTE_NAO_OBSERVADA'
            request.node.user_properties.append(('sonda_pendente_win32', str(error)))
            liberar(p)
            released = True
        return original(file, pin, d, depth)
    monkeypatch.setattr(tm, '_confirmar_ausencia_win', confirmar)
    try:
        d = remover(root)
        assert released and not root.exists()
    finally:
        if p.poll() is None:
            liberar(p)
    publicar(request, d)


def test_windows_diretorio_fica_nao_vazio_nao_apaga_nova_entrada(tmp_path, monkeypatch, request):
    root = tmp_path/'a'
    root.mkdir()
    original = tm._PinWin.apagar
    def adicionar(pin):
        (root/'novo').write_bytes(b'PRESERVAR')
        return original(pin)
    monkeypatch.setattr(tm._PinWin, 'apagar', adicionar)
    d = Diagnostico()
    with pytest.raises(tm.ErroTemporario):
        remover(root, d)
    assert d.dados['primeira_falha']['win32'] == 145
    assert (root/'novo').read_bytes() == b'PRESERVAR'
    publicar(request, d)


def test_windows_readonly_falha_sem_alterar_atributos(tmp_path, request):
    root = tmp_path/'a'
    root.mkdir()
    path = root/'f'
    path.write_bytes(b'PRESERVAR')
    path.chmod(stat.S_IREAD)
    d = Diagnostico()
    try:
        with pytest.raises(tm.ErroTemporario):
            remover(root, d)
        assert d.dados['primeira_falha']['win32'] == 5
        assert path.read_bytes() == b'PRESERVAR' and not path.stat().st_mode & stat.S_IWRITE
    finally:
        # Restaurar só o atributo que este teste aplicou ao seu arquivo fabricado.
        path.chmod(stat.S_IWRITE | stat.S_IREAD)
    publicar(request, d)


@pytest.mark.parametrize('kind', ['junction', 'symlink'])
def test_windows_reparse_nunca_percorre_destino(tmp_path, kind, request):
    root, outside = tmp_path/'a', tmp_path/'fora'
    root.mkdir()
    outside.mkdir()
    (outside/'sentinela').write_bytes(b'PRESERVAR')
    link = root/'link'
    if kind == 'symlink':
        criar_symlink(link, outside, target_is_directory=True)
    else:
        env = dict(os.environ, CLEANUP_LINK=str(link), CLEANUP_TARGET=str(outside))
        p = subprocess.run('cmd.exe /d /v:off /c mklink /J "%CLEANUP_LINK%" "%CLEANUP_TARGET%"',
                           env=env, capture_output=True, timeout=20, check=False)
        assert p.returncode == 0, 'JUNCTION_SINTETICA_NAO_CRIADA'
    d = remover(root)
    assert (outside/'sentinela').read_bytes() == b'PRESERVAR'
    assert d.dados['contadores']['reparse'] == 1 and d.dados['contadores']['arquivos'] == 0
    publicar(request, d)


def test_windows_interrupcao_percurso_fecha_pins(tmp_path, monkeypatch, request):
    root = tmp_path/'a'
    root.mkdir()
    (root/'f').write_bytes(b'PRESERVAR')
    def interromper(pin):
        raise KeyboardInterrupt()
    monkeypatch.setattr(tm._PinWin, 'apagar', interromper)
    d = Diagnostico()
    with pytest.raises(KeyboardInterrupt):
        remover(root, d)
    assert (root/'f').read_bytes() == b'PRESERVAR'
    # Sem pins residuais: rename deve funcionar após o finally.
    (root/'f').rename(root/'preservado')
    publicar(request, d)


class Chamada:
    def __init__(self, f):
        self.f = f
    def __call__(self, *a):
        return self.f(*a)


@pytest.mark.parametrize('api,code', [('CreateFileW', 32), ('SetFileInformationByHandle', 5), ('CloseHandle', 6)])
def test_windows_injecao_api_preserva_codigo_e_nega_sucesso(tmp_path, monkeypatch, api, code, request):
    # Falhas INJETADAS sobre API real, não incidentes observados no Windows.
    path = tmp_path/'f'
    path.write_bytes(b'PRESERVAR')
    real_factory = ctypes.WinDLL
    kernel = real_factory('kernel32', use_last_error=True)
    real_close = kernel.CloseHandle
    real_close.argtypes, real_close.restype = [wintypes.HANDLE], wintypes.BOOL
    class Proxy:
        def __getattr__(self, name):
            return getattr(kernel, name)
    proxy = Proxy()
    def falhar(*a):
        if api == 'CloseHandle':
            assert real_close(*a)  # não vazar handle ao simular retorno falso
        ctypes.set_last_error(code)
        return wintypes.HANDLE(-1).value if api == 'CreateFileW' else 0
    setattr(proxy, api, Chamada(falhar))
    monkeypatch.setattr(tm.ctypes, 'WinDLL', lambda *a, **k: proxy)
    d = Diagnostico()
    pin = None
    try:
        with pytest.raises(tm.ErroTemporario):
            pin = tm._PinWin(path, diagnostico=d)
            pin.apagar() if api == 'SetFileInformationByHandle' else pin.fechar()
        assert d.dados['primeira_falha']['win32'] == code
        assert d.dados['primeira_falha']['api'] == api
    finally:
        if pin:
            pin.fechar()
    assert path.read_bytes() == b'PRESERVAR'
    publicar(request, d)


def test_windows_substituicao_entre_snapshot_e_pin_nao_exclui_terceiro(tmp_path, monkeypatch, request):
    root = tmp_path/'a'
    root.mkdir()
    path = root/'f'
    path.write_bytes(b'INICIAL')
    original = tm._snapshot_win
    def substituir(p, *a):
        result = original(p, *a)
        if p == path:
            path.rename(tmp_path/'inicial')
            path.write_bytes(b'TERCEIRO')
        return result
    monkeypatch.setattr(tm, '_snapshot_win', substituir)
    d = Diagnostico()
    with pytest.raises(tm.ErroTemporario, match='ENTRADA_SUBSTITUIDA'):
        remover(root, d)
    assert path.read_bytes() == b'TERCEIRO' and (tmp_path/'inicial').read_bytes() == b'INICIAL'
    publicar(request, d)


def test_windows_pin_share3_impede_rename_e_delete_concorrente(tmp_path):
    path = tmp_path/'f'
    path.write_bytes(b'PRESERVAR')
    pin = tm._PinWin(path)
    try:
        query = tm._PinWin(path, excluir=False, consulta=True)
        try:
            assert query.identidade == pin.identidade
        finally:
            query.fechar()
        with pytest.raises(OSError) as rename:
            path.rename(tmp_path/'outro')
        assert rename.value.winerror in (5, 32)
        with pytest.raises(OSError) as delete:
            path.unlink()
        assert delete.value.winerror in (5, 32)
    finally:
        pin.fechar()
    assert path.read_bytes() == b'PRESERVAR'
