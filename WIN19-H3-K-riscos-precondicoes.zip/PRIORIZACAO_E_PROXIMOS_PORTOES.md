# H3-K — priorização e próximos portões propostos

26/11/2026. Providências são propostas, não atos autorizados ou risco aceito.
Severidades originais intactas. As justificativas item a item estão nas matrizes.

| Item | Severidade histórica | Providências propostas |
|---|---|---|
| H3G-R03 | ALTA | MANTER_BLOQUEIO;EXIGIR_REVISAO_DE_PROJETO;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-R07 | ALTA | MANTER_BLOQUEIO;REQUER_DECISAO_DO_CUSTODIANTE;EXIGIR_REVISAO_DE_PROJETO;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-N02 | ALTA | MANTER_BLOQUEIO;SOLICITAR_EVIDENCIA_FUTURA;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-N03 | ALTA | MANTER_BLOQUEIO;SOLICITAR_EVIDENCIA_FUTURA;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-R01 | MEDIA | MANTER_BLOQUEIO;EXIGIR_REVISAO_DE_PROJETO;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-R02 | MEDIA | MANTER_BLOQUEIO;SOLICITAR_EVIDENCIA_FUTURA;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-R04 | MEDIA | MANTER_BLOQUEIO;SOLICITAR_EVIDENCIA_FUTURA;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-R05 | MEDIA | MANTER_BLOQUEIO;REQUER_DECISAO_DO_CUSTODIANTE;SOLICITAR_EVIDENCIA_FUTURA |
| H3G-R06 | MEDIA | MANTER_BLOQUEIO;REQUER_DECISAO_DO_CUSTODIANTE;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-R08 | MEDIA | MANTER_BLOQUEIO;REQUER_DECISAO_DO_CUSTODIANTE;SOLICITAR_EVIDENCIA_FUTURA |
| H3G-R09 | MEDIA | MANTER_BLOQUEIO;SOLICITAR_EVIDENCIA_FUTURA;REQUER_VALIDACAO_NATIVA_SEPARADA |
| H3G-N04 | MEDIA | MANTER_BLOQUEIO;EXIGIR_REVISAO_DE_PROJETO;REQUER_VALIDACAO_NATIVA_SEPARADA |

## Ordem de revisão recomendada

1. Auditoria independente dos dez documentos H3-K e de sua suficiência documental.
   Nível A pode considerar descrições/causas/tratamentos/limites mapeados sem fechar
   risco. Divergência de fonte interrompe a conclusão correspondente.
2. Delimitar finalidade e garantias: leitura pontual de metadados não certifica
   identidade física, ausência de corrida ou proteção efetiva. R03/R07 exigem
   decisão e possível projeto próprio se essas garantias forem indispensáveis.
3. Revisar contrato externo de host/saída/tempo/privacidade (R01/R02/R08/R09/N04)
   e evidências privadas já legitimamente disponíveis. Sem testes nesta revisão.
4. Custodiante formaliza papéis, referências de áreas, legitimidade, exposição,
   obrigações institucionais, local proposto, responsáveis e limites de divulgação.
   Não pedir dados pessoais/caminhos em documentos compartilháveis.
5. Só após revisão e decisão expressa poderá haver proposta de validação nativa
   separada de N02/N03/N04 e das quatro correções, com método e precondições próprios.
   Isso não está autorizado, não inclui ensaios DACL/entre contas por inferência e
   não autoriza executar H3-F-R1 para descobrir o ambiente.
6. Uma eventual inspeção somente de leitura requer autorização expressa com
   identidade do texto, ambiente, finalidade limitada, operador legítimo, validade,
   duração, critérios de parada e tratamento de evidência. Continua bloqueada agora.
7. Aprovação do destino e termo operacional H3-C sobre origem, proteção, método,
   responsáveis/validade são decisões distintas posteriores. Nada desta sequência
   inicia custódia, cópia XML, H3-S, H4, controles WIN/DACL ou conversões reais.

## Revisões de projeto somente propostas

- R01/N04: revisão de um envelope externo/consumidor conservador e saída parcial,
  sem prometer captura absoluta de falhas fatais; não implementado.
- R03: identidade estável por handles/APIs distintas somente em desenvolvimento
  futuro, com direitos, compartilhamento, ciclo de vida e limites revisados.
- R05: se for necessário incorporar referências privadas ao método, rever contrato
  de entrada e proteção; não acrescentar caminhos ao bloco existente.
- R07: método por objeto/papel/operação para proteção efetiva futura requer portão
  próprio. Ler a DACL do ancestral ou usar chmod não o substitui.

Não se conclui que todos esses desenvolvimentos sejam obrigatórios para qualquer
observação limitada; a necessidade depende das garantias exigidas e da auditoria.
Não há autorização para alterar o código ou aceitar risco em nome do usuário.

Retenção: política vinculada à H4, máximo inicial 180 dias só após cópia fiel
aceita/verificada, revisões 60/120/180 e antecipada se H4 terminar. Sem relógio
iniciado, exclusão automática ou prorrogação por silêncio. Validade operacional
é separada. Remoto permanece adiado/não autorizado.
