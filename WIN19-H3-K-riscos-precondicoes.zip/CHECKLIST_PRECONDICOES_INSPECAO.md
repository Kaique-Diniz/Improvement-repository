# H3-K — checklist documental para decisão futura

26/11/2026. Nenhum item é resultado de inspeção real.
DOCUMENTADA significa regra/evidência documental existente, não condição material
certificada. PENDENTE_DE_EVIDENCIA exige prova legítima própria; PENDENTE_DE_DECISAO
exige decisão expressa; NAO_APLICAVEL_COM_JUSTIFICATIVA tem o limite declarado.

| ID | Grupo | Condição | Situação documental | Base/necessidade | Limite e decisão |
|---|---|---|---|---|---|
| A01 | Ambiente | Escopo Windows local legítimo definido | DOCUMENTADA | Política H3-E e instrução H3-K | Define a exigência, não comprova legitimidade da máquina; não libera inspeção |
| A02 | Ambiente | Legitimidade e autorização do ambiente específico | PENDENTE_DE_EVIDENCIA | Registro privado legítimo necessário | Não presumir a partir do operador H2, do nome do perfil ou do sucesso de parsing |
| A03 | Ambiente | Identidade exata do bloco R1 e fontes | DOCUMENTADA | 20.362 bytes/383 LF e SHA-256 conferidos | Válido para cópia documental local; futura cópia usada exige conferência própria |
| A04 | Ambiente | Evidência de sintaxe PS5.1 | DOCUMENTADA | Segunda tentativa informada pelo usuário, zero erros; ED-01 sanada | Não comprova runtime, host atual ou mesmos bytes do auxiliar |
| A05 | Ambiente | Sessão real PS5.1 Desktop, local e sem elevação | PENDENTE_DE_EVIDENCIA | Contexto real futuro não inspecionado | V01 observa indicadores parciais; não alterar privilégios para satisfazer |
| A06 | Ambiente | Origem do host, módulos, .NET e resolução de comandos | PENDENTE_DE_EVIDENCIA | R09/N02; nenhuma inspeção do host | Não instalar nem mudar perfis/PSModulePath/políticas |
| A07 | Ambiente | Providers WMI, acesso, duração e encerramento | PENDENTE_DE_EVIDENCIA | R02/N03; nenhuma consulta | Evidência separada, limitada e autorizada; não extrapolar PS5.1 |
| A08 | Ambiente | Assistência remota ou compartilhamento supervisionado | NAO_APLICAVEL_COM_JUSTIFICATIVA | ADIADA_NAO_AUTORIZADA na política vigente | Não participa da eventual inspeção prevista; ausência real de remoto ainda deve ser comprovada no ambiente |
| D01 | Destino | Requisito de diretório novo/exclusivo e fora de áreas proibidas | DOCUMENTADA | Política H3-E | É regra de escolha, não local escolhido/existente/aprovado |
| D02 | Destino | Proposta privada do caminho e aprovação pertinente | PENDENTE_DE_DECISAO | Custodiante; nenhum caminho solicitado no chat | Sem criação prévia presumida; caminho permanece privado |
| D03 | Destino | Volume físico interno local | PENDENTE_DE_EVIDENCIA | R04/V02; Fixed não basta | Não inferir natureza por letra, barramento ou nome |
| D04 | Destino | Referências de Git/worktrees, R1-FIX, C5–C8, custódias e Portão B | PENDENTE_DE_EVIDENCIA | Inventário privado legítimo não fornecido | V04/V05 continuam limitados; sem varredura ou nomes por semelhança |
| D05 | Destino | Separação de sincronização e compartilhamentos | PENDENTE_DE_EVIDENCIA | R06/V06 | Sem isentar shares administrativos ou alterar serviços; ausência de indicador não basta |
| D06 | Destino | Identidade física e concorrência/exclusividade | PENDENTE_DE_DECISAO | R03/V03/V09; método sem pin | Decidir finalidade/garantia exigida e necessidade de revisão de projeto, sem aceitar risco por silêncio |
| D07 | Destino | Proteção efetiva e acesso por papel/operação | PENDENTE_DE_EVIDENCIA | R07/V07/V08 | Objeto futuro não existe; não criar para fechar checklist; bloqueante da custódia, sem tratar leitura de ancestral como aprovação |
| C01 | Custódia | Usuário como custodiante principal em política | DOCUMENTADA | H3-E | Papel definido; não autentica nominalmente identidade ou legitimidade |
| C02 | Custódia | Identidade, legitimidade, deveres e substituição | PENDENTE_DE_EVIDENCIA | Registro privado legítimo | Sem nome/SID/conta em documentos compartilháveis |
| C03 | Custódia | Coadministradores específicos e limites | PENDENTE_DE_DECISAO | Autorização específica e registro privado | Sem acesso/participação/movimentação/exclusão presumidos |
| C04 | Custódia | Compatibilidade institucional e confidencialidade | PENDENTE_DE_DECISAO | Responsável legítimo conforme obrigações aplicáveis | Não presumir inexistência de obrigação; governança H3-I/H3-J permanece separada |
| C05 | Custódia | Responsáveis por evidências, revisão e eventual descarte | PENDENTE_DE_DECISAO | Designação privada | Não criar agenda automática ou preencher eventos futuros |
| R01 | Retenção | Limite inicial até 180 dias vinculado à H4 | DOCUMENTADA | Política H3-E | Contagem só após futura cópia fiel aceita e verificada; não começa agora |
| R02 | Retenção | Revisões 60/120/180 e antecipada se H4 terminar | DOCUMENTADA | Política H3-E | Nenhuma data concreta/agenda/revisão executada; não autoriza H4 |
| R03 | Retenção | Prorrogação expressa e nenhuma exclusão automática | DOCUMENTADA | Política H3-E | Descarte/movimentação exige aprovação específica; preservar origem |
| R04 | Retenção | Marco real, responsáveis e registros privados | PENDENTE_DE_DECISAO | Futuro evento de cópia aceita ainda inexistente | Sem inventar data; não confundir prazo de retenção com validade da autorização |
| O01 | Operação | Método técnico, finalidade e garantias revisados | PENDENTE_DE_DECISAO | R01/R03/R07 e N02–N04 | Decisão prévia sobre inspeção limitada versus certificação; nenhum script/runner novo |
| O02 | Operação | Recepção de evidência, prazo e tratamento de falhas | PENDENTE_DE_DECISAO | R01/R02/R08/N04 | Saída ausente ou encerramento incerto bloqueiam; sem repetição automática/limpeza forense |
| O03 | Operação | Privacidade do host e destinatários legítimos | PENDENTE_DE_EVIDENCIA | R08/R09 | Sem capturas/transcrições não autorizadas e sem desabilitar auditoria |
| O04 | Operação | Autorização futura limitada de inspeção | PENDENTE_DE_DECISAO | Só depois da auditoria/revisão e precondições pertinentes | Escopo, finalidade, identidade do método, operador legítimo, início/fim/expiração e interrupção expressos |
| O05 | Operação | Aprovação específica futura do destino | PENDENTE_DE_DECISAO | Não é objeto desta H3-K | Não se deduz do parsing, ausência de impedimento ou leitura de ACL |
| O06 | Operação | Termo H3-C sobre origem/destino/proteção/método/responsáveis/validade | PENDENTE_DE_DECISAO | H3-C não autorizada | Nenhuma transferência do XML antes deste portão; retenção 180 dias não concede operação |

## Ordem das dependências, sem circularidade

Antes de sequer solicitar autorização da H3-F-R1, precisam ser revisados método,
finalidade limitada, legitimidade/papéis, referências privadas pertinentes,
privacidade, evidências de ambiente já legitimamente disponíveis e tratamento de
falhas/tempo. Não obter evidência faltante executando o procedimento sem autorização.
Se uma verificação só puder ser feita nativamente, sua revisão e autorização são
separadas; não é autorização implícita de inspeção, DACL ou custódia.

A proteção do objeto futuro não pode ser demonstrada criando-o nesta etapa.
Sua ausência bloqueia aprovação operacional/custódia. Uma eventual leitura do
ancestral, se futuramente autorizada, só pode produzir observação limitada;
não precisa fingir que o destino já existe nem substituir a proteção por ela.
Autorização para inspeção não é aprovação do destino; aprovação futura do destino
não é termo de cópia H3-C. As três decisões têm escopo e validade próprios.

As referências privadas e nomes/contas não serão pedidos para inclusão pública.
Não iniciar relógio de retenção, agenda, custódia ou descarte. Não mudar ACL,
privilégios, share, políticas ou auditoria para transformar pendência em evidência.
PRECONDICOES_DOCUMENTAIS_MAPEADAS não significa condições atendidas.
