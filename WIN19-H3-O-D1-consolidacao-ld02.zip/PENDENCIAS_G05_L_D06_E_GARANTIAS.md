# H3-O-D1 — G05/L-D06 e pendências de garantias

27/11/2026. Onze classificações aprovadas quanto ao enquadramento, nenhuma garantia
comprovada. Aprovar DEPENDENTE_DE_DECISAO em G05 não resolve a decisão substantiva.

## G05 — áreas proibidas; L-D06=PENDENTE

Permanecem sem definição final: referências privadas legítimas das áreas vedadas,
nível de evidência exigido, portão de demonstração, método e validade da evidência.
A proibição de utilizar áreas históricas vedadas permanece obrigatória. Ausência
de marcador Git não é prova suficiente. Não adiar para depois da observação uma
condição necessária à segurança da leitura. Não coletar ou publicar caminhos,
executar Git/varredura ou acrescentar referências privadas ao código atual.

Classificação aprovada só reconhece a dependência da decisão pertinente; não é
escolha do nível/portão/método/validade e não autoriza área não comprovada. L-D06
e demais L-D03–L-D12 não receberam novas decisões por estas manifestações.

## G01–G04/G06–G07 — indicadores, não certificação

Volume declarado não prova disco interno; atributos nominais não fixam identidade;
ausência pontual não reserva caminho; marcadores não certificam separação; indícios
de exposição não esgotam sincronização/compartilhamento; DACL ancestral não calcula
acesso efetivo. Aprovação do alcance diagnóstico não torna segura a própria leitura.
R03 e R07 seguem abertos. Legitimidade, escopo, privacidade e segurança podem
impedir até a observação A; necessidade de garantia prévia exige revisão ou adiamento.

## G08 — proteção futura classificada para portão posterior

Proteção efetiva permanece obrigatória antes de custódia. Leitura da DACL ancestral
ou ausência de allow amplo não a demonstra. R07 e V08 são preservados: inconclusão
no desenho de V08 se alcançado, sem execução funcional de V01–V10 nesta tarefa.
Se segurança da observação exigir tratamento anterior, não o postergar por esta
classificação. Não criar alvo, alterar ACL ou testar conta para fabricar evidência.

## G11 — cópia e custódia em portões independentes

Observação não autoriza acesso ao JUnit, cópia fiel, sanitização, criação de destino,
movimentação, descarte ou transferência de custódia. H3-C/H3-S/H4 permanecem não
autorizadas. Método específico de identidade, exclusividade, proteção, integridade
e fechamento, responsáveis e validade deverá ter revisão/termo próprios.

## Política existente e formalização privada

Usuário como custodiante principal é papel já estabelecido. Coadministradores só
nos limites especificamente autorizados; alterações de acesso/movimentação/exclusão
exigem aprovação prévia específica. Remoto adiado/não autorizado; custódia inicial
local requer área exclusiva/protegida/separada. Identidades/legitimidade, obrigações
institucionais, papéis concretos, referências/local/direitos/método/proteção e validade
operacionais não foram preenchidos nesta consolidação.

Retenção inicial até 180 dias somente após futura cópia fiel aceita/verificada,
vinculada à H4, revisões 60/120/180 e antecipada se H4 terminar. Prorrogação expressa
justificada; nenhuma exclusão automática. Nenhuma cópia ou início de retenção foi
realizado nesta tarefa; nenhum marco/relógio/agenda é criado ou presumido.
