# H3-P — termo de decisão proposto para eventual H3-C

24/11/2026. **PROPOSTA NÃO ASSINADA/NÃO APROVADA. H3-C = NAO_AUTORIZADA.**
Este documento contém campos de decisão; não é autorização vigente, recibo de cópia
ou designação de pessoa. Alterar/preencher o formulário não inicia uma operação.

## Objeto nominal proposto

Alvo exclusivo: completa-utf8.xml, no caminho histórico relativo a LOCALAPPDATA
indicado na H2. Referência de bytes informada: 441505, SHA-256
`3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`.
Finalidade proposta: preservar uma cópia fiel privada para futura decisão de exame
histórico, sem autorizar desde já conteúdo, sanitização ou reconciliação.
O objeto/finalidade dependem de aprovação explícita no termo operacional futuro.

## Campos a decidir e registrar privadamente quando sensíveis

| Campo | Situação atual | Exigência para eventual decisão |
|---|---|---|
| Identificador/versão do termo | PENDENTE | Registro inequívoco da decisão efetiva e dos documentos aprovados |
| Arquivo e finalidade autorizados | PROPOSTOS, NÃO APROVADOS | Confirmação nominal do alvo H2 e finalidade limitada à cópia fiel |
| Custodiante responsável | PENDENTE_DE_DESIGNACAO | Pessoa real designada em registro privado; alias de função não substitui a decisão |
| Pessoas autorizadas e papéis | PENDENTE | Acesso mínimo necessário, nominal privado; sem SIDs/contas na parte pública |
| Ambiente local autorizado | PENDENTE | Máquina/volume sob controle legítimo, identificados privadamente |
| Destino concreto novo/exclusivo | PENDENTE_DE_APROVACAO | Caminho real somente privado, condições de proteção examinadas |
| Operações permitidas | PROPOSTAS, NÃO CONCEDIDAS | Leitura de integridade, criação exclusiva de uma cópia fiel e registros privados necessários |
| Método/ferramenta e versão | PENDENTE_DE_REVISAO | Procedimento futuro específico e seus limites técnicos aprovados |
| Prazo de validade da autorização | PENDENTE | Início/fim ou condição temporal inequívoca e fuso; sem validade retroativa ou indefinida implícita |
| Retenção, marco e revisão | PENDENTE | Política própria aprovada antes da cópia, distinta da validade da autorização |
| Condições de suspensão | PROPOSTAS | Qualquer impedimento de fonte/destino/acesso/retenção ou perda de consistência |
| Revogação | PENDENTE de regra/responsável | Efeito sobre novas operações e revisão humana da preservação existente; não apagar automaticamente |
| Aprovador e registro da aprovação | PENDENTE | Decisão expressa por autoridade legítima, data/hora e escopo; sem assinatura presumida |

A documentação compartilhável poderá usar CUSTODIANTE_DESIGNADO somente como
identificador de função ligado a designação real privada já efetuada. Nesta
preparação ninguém foi designado; não inferir custodiante pelo repositório, conta
Windows, operador H2, conversas antigas ou custódia do Portão B.

## Limites operacionais propostos para H3-C

Permissão futura seria restrita a conferir a fonte nominal, criar uma cópia fiel
exclusiva no destino aprovado e conferir sua integridade com registro privado.
Não incluir busca geral, cópia alternativa, upload, nuvem, publicação, parsing XML,
extração de testcase, sanitização, reconciliação H4, testes, elevação de privilégios,
mudança de ACL/proprietário/política/conta ou alteração de candidata/produto.
Nenhuma dessas operações está autorizada neste termo proposto.

A autorização futura será suspensa por ausência de qualquer precondição, hash
incompatível com H2, fonte mutável/ambígua, destino já existente ou não protegido,
acesso ilegítimo, falha de integridade ou expiração/revogação. Não migrar para outro
local ou ampliar o escopo para superar o impedimento. Retomar exigirá nova decisão.

A revogação não autoriza destruição do original, da cópia ou dos registros. Obrigações
de preservação e retenção deverão ser revistas pela autoridade competente. Não há
aprovação ou assinatura nesta entrega; solicitar H3-C somente após parâmetros
concretos aprovados e revisão independente da preparação.
