# WIN19-H3-P — índice e proveniência documental

24/11/2026 — America/Sao_Paulo. Pasta exclusiva de documentos:
`/workspace/work/WIN19-H3-PREPARACAO-CUSTODIA-20261124`.
Fora do Git/candidata. Não é destino de XML ou área de custódia privada.

## Dez documentos autorizados

1. [RELATORIO_H3_PREPARACAO.md](RELATORIO_H3_PREPARACAO.md) — contexto H2,
   decisões, limites e recomendação de prontidão.
2. [TERMO_AUTORIZACAO_CUSTODIA_PROPOSTO.md](TERMO_AUTORIZACAO_CUSTODIA_PROPOSTO.md)
   — campos/limites de decisão, sem assinatura ou designação presumidas.
3. [REQUISITOS_DESTINO_E_ACESSO.md](REQUISITOS_DESTINO_E_ACESSO.md) — condições
   do depósito futuro, sem caminho real escolhido ou alteração de permissões.
4. [POLITICA_RETENCAO_PROPOSTA.md](POLITICA_RETENCAO_PROPOSTA.md) — alternativas
   para apreciação, sem prazo aprovado nem herança de retenção B.
5. [PLANO_COPIA_FIEL.md](PLANO_COPIA_FIEL.md) — sequência técnica textual futura,
   referência H2, critérios e fronteiras; nenhuma implementação ou comando.
6. [MODELO_CADEIA_CUSTODIA.md](MODELO_CADEIA_CUSTODIA.md) — campos privados e
   compartilháveis, sem eventos futuros preenchidos.
7. [MATRIZ_IMPEDIMENTOS_H3.md](MATRIZ_IMPEDIMENTOS_H3.md) — condições de parada
   propostas, sem testes/ocorrências/resultados inventados.
8. [DECISOES_E_PORTOES_H3.md](DECISOES_E_PORTOES_H3.md) — autorizações e bloqueios.
9. INDICE_ENTREGA_H3.md — este registro de proveniência.
10. [MANIFESTO_SHA256_H3](MANIFESTO_SHA256_H3) — tamanhos/hashes dos nove documentos
    anteriores, excluindo apenas a si. Seu hash será informado na conversa.

## Fontes obrigatórias efetivamente lidas

| Fonte obrigatória/documental | Bytes | SHA-256 conferido |
| --- | --- | --- |
| INSTRUCAO_H3_P | 12467 | 912e1fbcd858895a30b994ac09f69b4a32161a5d82d1343d7f3779a0b9a54f78 |
| PARECER_INDEPENDENTE_WIN19_H1_2026-11-24.md | 5772 | ea232799a94b7bc247a38699e256f4af24c6cf0f616d6068f2df758cbd26d29e |
| H1/COMPLEMENTO_CUSTODIA_JUNIT.md | 3944 | 65a8842f95e52095e218481f8977c969c86fd9ba126e150c7b2cf2c784aa342e |
| C3/PROTOCOLO_RECUPERACAO_JUNIT_WINDOWS.md | 9819 | 6cff82b749d207db8527c64e8240385a5bf105704391361b016a3b3c34fa5305 |
| H2/AVALIACAO_DOCUMENTAL_H2.md | 7360 | 9f9f5d1a872d94c0bd4b7e3363f4f7432b262c0845d519f99a4ddfafc5c320cd |

INSTRUCAO_H3_P é o Texto colado.txt anexado ao pedido; é a fonte de autorização
somente documental. As demais referências fundamentam o desenho sem conceder
cópia ou execução. O parecer H1 antecede o resumo H2; sua condição de não execução
naquela revisão não elimina a execução posterior relatada pelo usuário em H2.

O documento H2 é avaliação local do Codex baseada na mensagem do usuário; não
é XML recebido nem recálculo independente do hash do XML. Seu SHA-256 documental
é diferente do fingerprint de origem informado. Essa distinção foi preservada.

Foram conferidos os documentos cobertos pelo manifesto H1 e sua identidade:
`4869390e9a81c8e3011be02b3d1c2723313805231b1918b3a0ee38426e7ce096`.
O protocolo C3 foi reutilizado como referência, sem recopiá-lo integralmente ou
alterar seus estados históricos. As fontes lidas mantiveram tamanho/hash antes
e depois da redação. Nenhuma delas é fonte primária de comando/código do run.

## Identidade documental versus cadeia futura

MANIFESTO_SHA256_H3 cobre somente os nove documentos novos efetivamente criados.
Não inclui XML, hash calculado de cópia inexistente, destinatário aprovado ou
registro de evento futuro. O fingerprint H2 citado nos textos é fornecido pelo
usuário: 441505 bytes e SHA-256
`3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`.
Não foi relido ou recalculado nesta H3-P e não autentica a rodada de 17/11.

## Método e preservação

Somente leitura de referências, cálculo SHA-256 de documentos, edição/redação de
Markdown e conferência de seus bytes. Usados utilitários de arquivo/texto e Python
-I -B/stdlib pathlib/hashlib para documentação, sem módulo do produto, PowerShell,
parser XML, testes ou execução de qualquer bloco recebido. Não há executáveis,
XML, scripts, fixtures, matrizes de resultados presumidos ou ZIP na pasta.

A restrição de não criar diretórios/destino refere-se à custódia operacional;
a pasta documental explicitamente autorizada nos entregáveis foi a única criada.
Não houve depósito no Windows, alteração em C3/H1/H2 ou nas áreas C5–C8, candidata
R1-FIX, Git, custódia B, ACL/DACL, owner, privilégio, política ou conta. Nenhuma
fonte ou parcial foi apagado. Não houve nova coleta, cópia, sanitização, reconciliação,
controle nativo, conversão, commit, push, merge ou publicação.

H3-P PREPARACAO_DOCUMENTAL; H3-C/H3-S/H4 NAO_AUTORIZADAS; custodiante/destino/retenção
pendentes. Preservados Categoria A consolidada documentalmente, H2 identificada
com limitações, vínculos provisórios, WIN/DACL não validados, runner não implementado,
C/D/E e conversões bloqueados, prontidão false. Parar para auditoria independente.
