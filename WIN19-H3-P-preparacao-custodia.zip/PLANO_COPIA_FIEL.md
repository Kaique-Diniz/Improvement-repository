# H3-P — plano textual de eventual cópia fiel H3-C

24/11/2026. **NÃO IMPLEMENTADO; NÃO EXECUTADO; H3-C NAO_AUTORIZADA.**
Este plano define sequência e critérios para uma futura ferramenta/procedimento
Windows a revisar. Não contém bloco PowerShell ou instrução executável aprovada.
Nenhuma escolha de API, flag de compartilhamento ou pin nativo é aprovada aqui.

## 1. Antes de qualquer criação ou cópia

1. Conferir decisão nominal H3-C vigente, escopo e limites, custodiante real/pessoas,
   ambiente/destino aprovados, acesso legítimo e retenção própria já aprovada.
2. Confirmar que o destino será novo/exclusivo, fora das áreas vedadas, sem
   sincronização automática e com proteção suficiente já existente. Não criar
   pasta para testar se depois será aprovada; não sobrescrever/limpar colisões.
3. Confirmar no caminho histórico exato a existência/regularidade da fonte e
   ausência de redirecionamento, reparse ou alias inesperado/ambíguo. Falha impede
   continuidade, sem procura alternativa ou alteração de privilégio/permissão.
4. Ler tamanho e SHA-256 atuais da fonte por método legítimo revisado; registrar
   metadados/instante UTC de observação em cadeia privada, não confundir datas.
5. Exigir 441505 bytes e SHA-256 exato
   `3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`.
   Qualquer diferença desses valores frente à H2 interrompe a operação.
6. Registrar a modificação corrente e confrontar com a referência H2
   `2026-11-17T12:55:35.1745094Z`. Uma variação com hash igual requer política
   de aceitação explícita/revisão, não restauração de timestamps ou autenticação
   presumida. Se o tratamento ficar indefinido, não iniciar a cópia.

A referência H2 foi informada pelo usuário, não recalculada pelo Codex. Não afirma
que o arquivo tenha permanecido inalterado desde a rodada. Não usar hash alternativo,
normalizar encoding para fazê-lo coincidir ou repetir leituras indefinidamente.

## 2. Vínculo e fronteiras a demonstrar no método futuro

O método deverá vincular o objeto examinado aos bytes efetivamente copiados e
manter o destino sob a referência aprovada. Usar o mesmo objeto/handle no ciclo
pré-hash/cópia/pós-conferência é um requisito de desenho a avaliar, não garantia
já implementada. Observar tamanho/datas antes e depois não elimina todas as corridas
nem demonstra file ID/volume ou exclusão de aliases. Se a identidade não puder ser
assegurada ao nível necessário, interromper; não compensar com um resultado favorável.

A revisão técnica futura deverá explicitar acesso/compartilhamento, tratamento de
mudança de entrada/ancestral e garantia de criação exclusiva. Não introduzir
rmtree, privilégios, módulos experimentais ACL ou flags nativas sem escopo próprio.

## 3. Durante a eventual cópia autorizada

- Criar o arquivo de destino de forma exclusiva, com recusa de existência/colisão;
  não aceitar hardlink, symlink, junction ou redirecionamento como cópia fiel independente.
- Transferir os bytes integralmente sem interpretação de XML, recodificação,
  normalização de LF/CRLF, edição de conteúdo ou derivado sanitizado.
- Preservar original: sem mover, renomear, abrir para escrita, ajustar atributos,
  timestamps, owner ou permissões. Registrar metadados da cópia como próprios,
  sem forçá-los a simular a antiguidade do original.
- Manter registro privado dos eventos efetivos e dos impedimentos. Não publicar
  caminhos, dados pessoais, XML, conteúdo de exceção ou logs privados.
- Diante de erro, interromper. Um parcial não pode ser aceito nem tratado como
  cópia fiel; não apagar, sobrescrever ou desviar para outro destino automaticamente.

## 4. Depois da eventual cópia

1. Concluir e registrar a gravação/fechamento dos recursos. Falha de fechamento ou
   conclusão não comprovada bloqueia a aceitação, sem esconder resultados parciais.
2. Ler novamente a cópia pelo método autorizado e medir tamanho/SHA-256. Conferir
   a identidade com a fonte observada: ambos 441505 bytes e digest H2 exato.
3. Reavaliar a origem quanto a estabilidade observável, integridade atual e vínculo
   com o objeto copiado. Se houver mudança, divergência ou identidade incerta,
   preservar observações e não aceitar a cópia para prosseguimento.
4. Registrar início/fim/verificações em UTC, ferramenta/versão, custodiante, origem,
   destino, autorização e relação entre as peças. Distinguir o instante da operação
   das datas do filesystem e da data histórica da execução.
5. Registrar correspondência criptográfica e limitações. Uma comparação integral
   adicional poderá ser proposta se autorizada, sem prometer que hashes provam fatos.
6. Submeter o registro à revisão prevista, preservando original, cópia e histórico.

Flush/close ou hash reaberto não demonstram, isoladamente, persistência física
forense ou autenticidade histórica. O nível efetivamente demonstrado precisa ser
registrado, sem inferir prova de disco ou segurança DACL do aplicativo.

## 5. Critérios cumulativos de aceitação futura

Autorização válida, custodiante/destino/acesso/retenção aprovados; fonte nominal e
referência H2 compatíveis; identidade suficientemente assegurada; criação exclusiva;
bytes preservados; conclusão/fechamento comprovados no nível revisado; cópia e fonte
conferidas; estabilidade observável e cadeia privada registradas; nenhum impedimento
pendente. Só após essas verificações realizadas poderá ser proposta a classificação
COPIA_FIEL_VERIFICADA_COM_LIMITACOES, como resultado de H3-C, nunca desta H3-P.

Tamanho/hash iguais indicam correspondência criptográfica dos bytes observados,
não autenticam retroativamente o run, comando, versão, manifesto 448, autoria ou
custódia passada. Leitura pode alterar último acesso pelo filesystem. Não prometer
preservação forense absoluta. H3-S/H4 continuam separadas e não são disparadas pela cópia.
