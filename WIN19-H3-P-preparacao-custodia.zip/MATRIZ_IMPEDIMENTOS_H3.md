# H3-P — matriz documental de impedimentos futuros

24/11/2026. Condições e códigos propostos para futura revisão. **Nenhum cenário
foi executado e nenhum resultado operacional é preenchido por esta matriz.**

| Condição futura | Resultado/código documental proposto | Tratamento exigido |
|---|---|---|
| Fonte ausente no caminho exato | FONTE_AUSENTE | Interromper; não procurar substituto nem recriar XML |
| Acesso negado | ACESSO_NEGADO | Interromper; não elevar privilégio, alterar owner ou ACL |
| Reparse point ou alias ambíguo | IDENTIDADE_OU_REDIRECIONAMENTO_AMBIGUO | Interromper; não seguir outra origem/destino |
| SHA-256 atual diferente da H2 | HASH_FONTE_DIVERGENTE_H2 | Registrar divergência e interromper; não usar outro hash |
| Tamanho incompatível com 441505 | TAMANHO_FONTE_DIVERGENTE_H2 | Interromper; não atribuir medição antiga ao objeto atual |
| Fonte mutável/mudança observável | FONTE_MUTAVEL | Preservar observações e interromper, sem laço até coincidir |
| Destino/arquivo já existente | DESTINO_JA_EXISTENTE | Não sobrescrever, adotar, limpar ou escolher outro local automaticamente |
| Destino sem proteção suficiente/legítima | DESTINO_NAO_APROVADO | Não copiar; interromper preparação operacional |
| Retenção ainda não aprovada | RETENCAO_H3_PENDENTE | Não iniciar custódia |
| Autorização nominal ausente/expirada/revogada | AUTORIZACAO_H3_C_INVALIDA | Não executar ou suspender novas operações; não destruir evidências |
| Custodiante não designado | CUSTODIANTE_PENDENTE | Não executar; não herdar identidade de tarefa anterior |
| Cópia parcial/incompleta | COPIA_INCOMPLETA | Não aceitar como fiel; preservar parcial em acesso aprovado para decisão, sem publicação |
| Hash/tamanho da cópia diferente da fonte | COPIA_DIVERGENTE | Não aceitar; preservar evidências para revisão |
| Falha de gravação/fechamento ou conclusão incerta | CONCLUSAO_COPIA_NAO_COMPROVADA | Não converter em sucesso; manter impedimento e observações |
| Erro operacional imprevisto | ERRO_OPERACIONAL_NAO_CLASSIFICADO | Interromper, registrar código/descrição sanitizada e limites, sem inferir ausência do arquivo |

Esses rótulos não são enums novos do produto ou dos contratos Categoria A e não
foram implementados. O estado atual do destino é PENDENTE_DE_APROVACAO, não resultado
de uma inspeção real. A fonte atual não foi relida nesta H3-P.

Nenhum erro desencadeia busca ampla, cópia alternativa, publicação de logs privados,
eliminação de evidências, alteração de ACL/privilégio/política/conta, testes ou
reexecução do Portão B. Um parcial não ganha nome/estado de cópia íntegra, nem
originais/derivados são apagados para remover o sinal da falha.

Os registros de falha deverão manter primeira causa e falhas posteriores de forma
rastreável, com horários e ferramenta quando efetivamente existentes; conteúdo
privado permanece na cadeia aprovada. Não preencher eventos antecipadamente.
A leitura pode afetar último acesso pelo sistema; não prometer imutabilidade forense.
