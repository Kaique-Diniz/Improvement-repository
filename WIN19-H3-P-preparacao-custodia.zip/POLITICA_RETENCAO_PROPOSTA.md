# H3-P — retenção e revisão de descarte propostas

24/11/2026. **RETENCAO_H3=PENDENTE.** Nenhum prazo ou descarte foi aprovado.
A ausência de política aprovada impede a autorização operacional da custódia.
Os 90 dias do Portão B não se aplicam automaticamente ao JUnit ou aos registros H3.

## Decisões necessárias

| Elemento | Definição a aprovar, ainda pendente |
|---|---|
| Finalidade | Limitar a preservação ao propósito legítimo de cópia fiel e às decisões posteriores autorizadas |
| Prazo | Duração/data-limite explícita, apropriada e aprovada; nenhum número é adotado nesta proposta |
| Marco inicial | Evento inequívoco a escolher, com registro UTC; não tomar a modificação de 17/11 ou a data desta documentação como início automático |
| Custodiante | Pessoa real designada em registro privado e obrigações de controle de acesso |
| Data de revisão | Data/regra objetiva ligada ao prazo e finalidade, sem usar placeholder como decisão efetiva |
| Prorrogação | Aprovação expressa anterior ao término aplicável, justificativa, nova revisão e limite; sem renovação automática |
| Obrigações de preservação | Existência/aplicabilidade a verificar pela autoridade legítima; não presumir obrigação nem ignorar uma que exista |
| Decisão de descarte | Responsável designado, revisão de finalidade/obrigações e autorização própria antes de qualquer ação |
| Exceções | Motivo, escopo, aprovador, duração/revisão e registro rastreável, sem apagar o histórico |

## Alternativas para apreciação, nenhuma selecionada

**A — Prazo fixo:** escolher duração/data-limite, marco inicial e revisão definidos.
Permite decisão objetiva, mas exige justificar a duração antes de iniciar a custódia.

**B — Prazo vinculado à finalidade:** retenção até um marco documental claramente
identificado, com data máxima e revisão definidas. O marco não pode significar
retenção indefinida enquanto uma etapa nunca é concluída.

**C — Preservação excepcional:** caso uma obrigação legítima imponha conservação,
registrar fundamento, autoridade, alcance e reavaliação. Não cria prazo genérico nem
suspensão ilimitada por conveniência; o tratamento concreto exige decisão competente.

Não há recomendação de quantidade de dias sem contexto. Em qualquer alternativa,
validade da autorização para copiar e duração da retenção são campos diferentes.
A expiração de uma não define automaticamente a outra nem autoriza eliminação.

## Revisão antes de eventual descarte

A futura revisão deverá confirmar finalidade remanescente, obrigações/exceções,
peças afetadas, legitimidade do decisor e efeito sobre cadeia/evidências. Descarte
dependerá de autorização específica e registro; não é consequência automática
de prazo, revogação, hash divergente, falha de cópia ou encerramento de conversa.

Não foi criado cronograma, automação, comando de exclusão, procedimento executável
ou depósito. O original fica preservado; esta proposta não concede ação sobre ele,
cópias, parciais ou logs. Manter RETENCAO_H3=PENDENTE até decisão expressa completa.
