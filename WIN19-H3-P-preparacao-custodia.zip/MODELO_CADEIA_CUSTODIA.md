# H3-P — modelo documental de cadeia de custódia

24/11/2026. **MODELO NÃO PREENCHIDO; nenhum evento de cópia foi realizado.**
A tabela é uma especificação de campos para registro privado futuro. Não é cadastro
operacional, schema executável, recibo, assinatura, log criado ou custódia iniciada.

## Campos de registro futuro

| Campo | Registro privado necessário | Parte eventualmente compartilhável, mediante autorização |
|---|---|---|
| Identificador da peça | ID único e relação ao evento efetivo, não simples nome de arquivo | Alias sem dado pessoal |
| Nome original | Nome observado da origem, sem renomear para coincidir com hipótese | Nome quando seguro/autorizado |
| Localização da origem | Caminho completo/máquina/volume reais, custodiados privadamente | Alias ou referência nominal sem conta pessoal |
| Localização da cópia | Caminho novo aprovado e efetivamente utilizado | Alias do destino, não caminho pessoal |
| Custodiante | Identidade real designada e vínculo à decisão | Função CUSTODIANTE_DESIGNADO somente após designação real |
| Evento e data/hora UTC | Operação efetiva, início/fim e observações, com fuso/origem do relógio quando disponível | Metadados mínimos autorizados |
| Tamanho da fonte | Medição atual datada e vinculada ao objeto examinado | Valor autorizado, distinto de mera referência H2 |
| SHA-256 da fonte | Valor efetivamente medido no evento e seu contexto | Valor quando aprovado para compartilhamento |
| Tamanho da cópia | Medição após conclusão/fechamento, vinculada ao destino | Valor autorizado |
| SHA-256 da cópia | Medição da cópia; não atribuir hash H2 por presunção | Valor autorizado |
| Ferramenta e versão | Identificação do procedimento revisado e implementação usada | Nome/versão não sensíveis |
| Resultado de verificação | Critérios realmente executados e seu alcance, sem aprovação automática | Resumo seguro com limitações |
| Impedimentos | Primeira causa e eventos subsequentes, referências privadas necessárias | Códigos seguros, sem caminhos/locals/dados de XML |
| Autorização | ID/versão/escopo, validade e registro de decisão efetiva | Referência/estado quando autorizado |
| Acessos/transferências | Quem, quando, finalidade, autorização e relação entre peças | Resumo estritamente aprovado |
| Datas do filesystem | Criação/modificação e circunstância observada, separadas do instante de cópia/run | Apenas os campos autorizados |
| Retenção/revisão/exceções | Política aprovada, marco, prazo, responsável, revisões e preservações | Referência e pendências sem dados pessoais |

Todos os valores de eventos futuros permanecem NÃO_PREENCHIDOS. A data desta
preparação, os autores de conversas antigas e a conta do repositório não preenchem
custodiante, horário de cópia ou aprovação. Não inferir sucesso de um campo ausente.

## Referência anterior, não evento de custódia

A H2 informou completa-utf8.xml, 441505 bytes, modificação UTC
2026-11-17T12:55:35.1745094Z e SHA-256
`3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`.
É referência de comparação fornecida pelo usuário. Não preencher com ela as
medições futuras da fonte/cópia nem tratá-la como recebimento do XML pelo Codex.

## Regras de proveniência e privacidade

Manter original e medições anteriores; uma retificação futura precisa de motivo,
responsável e vínculo ao registro anterior, sem reescrever o histórico para remover
divergências. Registrar somente eventos efetivos, inclusive acessos/transferências
expressamente autorizados. Nenhum evento é presumido por existir um formulário.

Registros privados, XML, mapa de aliases, nomes de contas, SIDs, senhas, tokens,
dados pessoais e conteúdo sensível não entram na entrega pública. A ausência de
permissão para compartilhar campo mantém limitação explícita, não valor inventado.
Hash de documento novo H3-P é identidade documental, não hash de cópia de XML.

A política de proteção e retenção do registro privado deve ser aprovada juntamente
com a custódia. Esta especificação não cria diretório, banco de dados, logger,
assinatura, mecanismo ACL ou rotina de descarte.
