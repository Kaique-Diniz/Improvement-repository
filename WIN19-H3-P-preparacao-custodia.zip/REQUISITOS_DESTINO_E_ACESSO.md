# H3-P — requisitos do futuro destino e do acesso

24/11/2026. **Destino H3 = PENDENTE_DE_APROVACAO.** Nenhuma pasta real foi escolhida,
inspecionada ou criada no computador do usuário. A pasta dos documentos H3-P não
é depósito de custódia e não está autorizada a receber XML.

## Condições cumulativas a verificar futuramente

1. Destino local novo e exclusivo, nominalmente aprovado por quem legitimamente
   controla o ambiente; criação somente após a autorização H3-C.
2. Fora de qualquer repositório Git, inclusive worktrees, metadados danificados ou
   raiz bare ambígua; uma dúvida de pertencimento impede a aprovação do destino.
3. Fora da R1-FIX, outras candidatas auditadas, pastas de contratos C5–C8 e depósitos
   ou custódias anteriores do Portão B. Não aproveitar um desses locais por conveniência.
4. Sem compartilhamento/sincronização automática em nuvem ou transferência remota.
   Confirmar a condição real; o nome local da pasta não exclui sincronização,
   redirecionamento, backup compartilhado ou acesso por terceiros.
5. Ancestrais, tipo/volume e identidade de origem/destino suficientemente claros
   para a finalidade, sem reparse, alias ou redirecionamento inesperado/ambíguo.
6. Acesso já existente legítimo para o custodiante e pessoas expressamente autorizadas;
   controle de exposição de XML, registros e parciais com a proteção necessária.
7. Nenhum arquivo existente sobrescrevível e nenhuma dependência de limpeza prévia.
   Existência superveniente do depósito/alvo não autoriza adotá-lo silenciosamente.
8. Criação exclusiva e vínculo ao destino aprovado durante a futura operação,
   com prevenção de colisão/substituição de entradas. A técnica exata requer revisão.

Não indicar um caminho sugerido como se fosse existente, acessível, privado ou
aprovado. O caminho completo e a identificação da máquina/volume ficarão em registro
privado após decisão, vinculados a um alias na documentação compartilhável.

## Exame de acesso e proteção, sem alterações

A análise futura das permissões já existentes deverá ser feita legitimamente e
ser suficiente à custódia pretendida. Leitura de ACL não prova, por si só, o acesso
efetivo de todos os papéis. Não realizar testes entre contas ou presumir política
DACL aprovada. Dados de contas, SID/SDDL e detalhes privados não vão à entrega pública.

Não criar/modificar ACL/DACL, owner, grupos, contas, privilégios, Developer Mode,
políticas ou configuração persistente para viabilizar o destino. Se a proteção
existente for insuficiente, não copiar: registrar DESTINO_NAO_APROVADO e interromper
a preparação operacional. Qualquer solução fora dessas condições é decisão separada.
O mecanismo do aplicativo, chmod, sharing violation ou aprovação da Categoria A
não substituem a proteção do depósito privado.

## Rastreabilidade da futura aprovação

Registrar quem examinou legitimamente o destino, qual evidência fundamenta sua
adequação, o alias/local real privado, pessoas/papéis autorizados, restrições de
sincronização e limites conhecidos. Não preencher tais resultados nesta H3-P.

Neste momento só há pendência de aprovação, não resultado de teste ou inspeção de
uma pasta concreta. Sem destino e acesso suficientemente demonstrados, H3-C não
pode ser autorizado operacionalmente. Nenhum preflight ou script de verificação
foi produzido ou executado nesta preparação.
