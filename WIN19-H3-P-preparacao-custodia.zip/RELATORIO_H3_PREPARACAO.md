# WIN19-H3-P — preparação da custódia controlada

24/11/2026 — America/Sao_Paulo. **H3-P = PREPARACAO_DOCUMENTAL.**
Nenhuma autorização de cópia ou custódia operacional é concedida por esta entrega.

## Situação de partida e proveniência

A H2 foi classificada IDENTIFICADO_COM_LIMITACOES com base no resumo Windows
fornecido pelo usuário, posterior à revisão documental H1. O Codex avaliou os
campos do resumo; não executou a leitura Windows nem recebeu os bytes do XML.
O parecer H1 registra a condição de preparação não executada naquela revisão;
a execução posterior relatada em H2 não reescreve esse histórico.

| Referência H2 informada pelo usuário | Valor |
|---|---|
| Nome | completa-utf8.xml |
| Caminho nominal | %LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml |
| Tamanho informado | 441505 bytes |
| Modificação informada UTC | 2026-11-17T12:55:35.1745094Z |
| SHA-256 informado | 3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28 |
| Critérios de identificação H2 | Nove atendidos na avaliação documental da saída |

Este fingerprint é referência para comparação futura; não foi recalculado pelo
Codex nem comprova imutabilidade desde 17/11, identidade física autenticada, comando
Pytest, versão exata do código, uso do manifesto 448 ou integridade contemporânea.
A candidata R1-FIX de 470 arquivos não substitui a origem documental EXP-04 de 448.

## Preparação realizada

Foram lidos o parecer H1, complemento H1, protocolo C3 e avaliação H2; suas
identidades documentais foram conferidas. Foram preparados um termo ainda não
aprovado, requisitos do destino, alternativas de retenção, plano textual de cópia,
modelo de cadeia, matriz de impedimentos e estados de parada. Nenhum bloco
PowerShell, ferramenta de cópia, parser, extrator ou sanitizador foi implementado.

A pasta desta entrega contém somente os dez documentos autorizados. A criação
dessa pasta documental é a exceção expressa prevista nos entregáveis; ela não é
um destino privado, depósito, custódia H3 ou pasta no Windows. Nenhum diretório de
custódia foi escolhido/criado e nenhum XML foi acessado, copiado ou transferido.

## Decisões que exigem aprovação específica

1. Designar custodiante e pessoas autorizadas em registro privado, com aliases
   públicos apenas após existir a designação real. Não herdar nomes de outras tarefas.
2. Aprovar ambiente e destino local concreto, novo/exclusivo, com acesso legítimo
   e proteção existente suficiente, fora de Git, candidatas, C5–C8, Portão B e
   sincronização automática. Nome de pasta não comprova isolamento.
3. Aprovar finalidade, prazo/marco de retenção, revisão, prorrogação, exceções e
   autoridade de descarte; não existe prazo H3 aprovado nem herança de 90 dias de B.
4. Aprovar termo nominal de H3-C: arquivo, finalidade, operações, validade, revisão
   técnica do procedimento futuro e condições de suspensão/revogação.

A validade da autorização operacional e o prazo de retenção são decisões distintas.
Aprovar a preparação documental não preenche nenhuma delas automaticamente.

## Critérios técnicos propostos para uma cópia futura

Conferir autorização/custodiante/destino/acesso/retenção antes de iniciar. Confirmar
regularidade, ausência de redirecionamento inesperado e referência atual da fonte:
441505 bytes e SHA-256 H2 exato. Divergência, mutabilidade ou ambiguidade interrompe,
sem busca alternativa, elevação, mudança de ACL ou escolha da versão conveniente.

O futuro método deverá preservar o vínculo entre objeto examinado e bytes copiados,
criar arquivo de destino exclusivamente, sem sobrescrita, sem hardlink como cópia,
normalização, regravação do original, parsing ou derivado sanitizado. Após fechamento,
conferir cópia e fonte, estabilidade observável e registro privado dos eventos.
A estratégia de handles/compartilhamento, proteção de fronteiras e implementação
precisará de revisão própria; nenhuma API/flag ou garantia de corrida foi aprovada aqui.

## Recomendação de prontidão

**Preparação documental pronta para auditoria; não pronta para solicitar uma
autorização operacional H3-C concreta.** Ainda faltam custodiante, destino/proteção,
retenção, pessoas/ambiente, validade e procedimento específico revisado. Não existe
pasta real aprovada: isso é pendência, não falha de um destino que teria sido testado.
Se não houver alternativa legítima suficientemente protegida, o estado operacional
será DESTINO_NAO_APROVADO e nenhuma cópia poderá ser iniciada.

Depois da auditoria H3-P e do preenchimento/aprovação desses parâmetros, poderá
ser submetido um pedido nominal H3-C. A coleta atual não é solicitada nem autorizada.
H3-S e H4 são decisões separadas. Não iniciar nenhuma das três operações.

## Garantias não demonstráveis antecipadamente

Não se conhece ainda o depósito, seus acessos reais ou uma cópia concluída. Não é
possível antecipar integridade da cópia, proteção suficiente, estabilidade física,
completude de fechamento, persistência durável ou eventos de cadeia ainda inexistentes.
Hash/tamanho iguais indicarão correspondência criptográfica dos bytes observados,
sem autenticar retroativamente execução, autoria ou uso do manifesto. Leitura pode
atualizar último acesso pelo sistema; não se promete preservação forense absoluta.

Categoria A CONSOLIDADA_DOCUMENTALMENTE; H1 aceita documentalmente com ressalvas;
H2 IDENTIFICADO_COM_LIMITACOES; H3-P PREPARACAO_DOCUMENTAL; H3-C/H3-S/H4 NAO_AUTORIZADAS;
custodiante PENDENTE_DE_DESIGNACAO; destino PENDENTE_DE_APROVACAO; retenção PENDENTE;
vínculos PROVISORIO_SEM_FONTE; WIN/DACL NÃO_VALIDADO; runner NÃO_IMPLEMENTADO;
C/D/E BLOQUEADOS; conversões reais BLOQUEADAS; prontidão para ensaios false.

Sem cópia, XML, Windows, testes, preflight B, implementação Categoria B, alteração
de fontes/candidata/Git/ACL/política/privilégio/conta, limpeza, commit, push, merge,
publicação ou ZIP. Parar para auditoria independente dos dez documentos.
