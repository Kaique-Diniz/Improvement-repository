# WIN19-C1/C2 — entrega documental para revisão

18/11/2026. C1 é parcial por ausência das fontes primárias. C2 está especificada
em texto, com lacunas explícitas. Prontidão para executar continua falsa.

## Leitura principal

1. [Relatório C1](RELATORIO_C1_FONTES_E_LACUNAS.md) e
   [matriz dos 19 vínculos](MATRIZ_C1_VINCULOS_PARA_REVISAO.csv).
2. [Relatório C2](RELATORIO_C2_REVISAO_21.md) e
   [matriz revisada dos 21 subcasos](MATRIZ_C2_REVISAO_21.csv).
3. [Especificação textual do futuro executor](ESPECIFICACAO_RUNNER_C_SOMENTE_TEXTO.md).
4. [Decisões, pendências e portões](DECISOES_E_PORTOES_C1_C2.md).
5. [Conferência e preservação](CONFERENCIA_DOCUMENTAL_E_PRESERVACAO.md).

## Evidência observada versus relato

O manifesto local EXP-04 de 448 entradas foi localizado e teve seu SHA calculado.
O JUnit Windows original não está acessível aqui. O usuário forneceu o local e um
índice secundário com 19 falhas e sete skips agrupados. Não recebemos os bytes
brutos ou o derivado cujo hash foi declarado. O registro local em fontes_relato/
é um novo documento, sem pretensão de reproduzir os bytes da biblioteca.

A matriz C1 conserva separados proposta, relato e original SEM_FONTE. Todos os
19 vínculos continuam PROVISORIO_SEM_FONTE, sujeitos ao revisor. A matriz C2 cobre
21 subcasos com estados funcional/nativo/DACL NÃO_VALIDADO. Nenhum PASS foi
transferido de Linux, cleanup, Portão B ou da transcrição para controles nativos.

## Arquivos auxiliares

- INVENTARIO_C1_CABECALHOS_XML.csv: metadados/cabeçalhos de 142 XML locais.
- INVENTARIO_C1_PACOTES.csv: 11 pacotes EXP-04 preexistentes.
- INVENTARIO_C1_XML_EM_PACOTES.csv: 27 entradas XML nesses pacotes.
- INVENTARIO_C1_C2_DOCUMENTOS_FONTES.csv: fontes de contrato e hashes da versão lida.
- SKIPS_RELATADOS_TRANSCRICAO.csv: quatro grupos que somam sete skips relatados.
- DIFF_MATRIZ_C2_DOCUMENTAL.patch: comparação da matriz-semente recebida com a
  revisão. Expande campos e critérios; não altera testes ou código.
- fontes_instrucoes/: seis documentos recebidos, preservados literalmente.
- fontes_relato/: registro sanitizado do índice recebido em mensagem.
- MANIFESTO_SHA256.json: arquivos da entrega e hashes, excetuando os dois manifestos.
- MANIFESTO_SHA256.sha256: hashes de todos os arquivos, inclusive o JSON, exceto
  este manifesto textual. Hash deste último informado na entrega da conversa.

Nenhum runner, nova fixture ou código executável foi criado. A candidata R1-FIX,
a matriz original, a proposta DACL, os acervos anteriores e a custódia B não foram
alterados. Sem teste, preflight, parsing PowerShell ou mudança de permissões.
A abertura inicial do ZIP com Python, antes de conhecer a vedação interna, está
declarada no relatório; não houve execução posterior de Python ou de código do produto.

Sem commit, push, merge ou publicação. Esta etapa entrega documentos locais e
para. Implementar executor, executar C ou ensaiar DACL requer novas revisões e
autorizações independentes. Homologação e conversões reais permanecem bloqueadas.
