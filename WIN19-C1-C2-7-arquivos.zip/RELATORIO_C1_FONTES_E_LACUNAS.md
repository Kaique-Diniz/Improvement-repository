# WIN19-C1 — fontes históricas e lacunas

18/11/2026. Investigação documental externa ao Git. Esta entrega não executa
extrator histórico, parser de testes, pytest, preflight, PowerShell ou ensaio.
Fonte normativa: INSTRUCOES_CODEX_WIN19_C1_C2.md e C1_RECONCILIACAO_HISTORICA.md
recebidos no ZIP de instruções, preservados literalmente em fontes_instrucoes/.

## Conclusão

Foi localizado o manifesto EXP-04 de **448 arquivos**, baseline
770d062d29c4361d6932592883df9339bb4089bc, SHA-256
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb.
A cópia VERSAO_EXP04_ORIGINAL_SHA256.json no pacote posterior tem o mesmo SHA.
Isso observa um artefato documental de versão de 448, não prova que a rodada Windows
original utilizou esses bytes ou que448 arquivos físicos tenham sido verificados
nesta tarefa. Falta o vínculo dessa versão à execução Windows.

O JUnit da rodada Windows original 2842/19 falhas/7 skips **não foi recuperado como
arquivo acessível**. Nenhum dos 19 vínculos foi confirmado ou reclassificado por
semelhança. Todos ficam PROVISORIO_SEM_FONTE, decisão_revisor=PENDENTE.

## Localização adicional fornecida pelo usuário

Após a busca inicial, o usuário informou:
%LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml.
Este é o local relatado para a fonte-alvo, não um XML recebido nesta tarefa.
O nome de perfil pessoal foi omitido. O caminho não está acessível no executor
Linux pelas montagens convencionais verificadas especificamente para esse arquivo.
Não houve acesso remoto, pesquisa no computador do usuário ou transferência.
Nome do diretório não prova horário/fuso da execução; conteúdo/tamanho/SHA são
SEM_FONTE até os bytes originais ou uma cópia autorizada serem disponibilizados.

## Observações efetivas e fontes que não substituem a rodada Windows

| Fonte local sanitizada | Observado nesta tarefa | Limite |
|---|---|---|
| EXP-04-entrega/VERSAO_EXP04_SHA256.json |448 entradas, base770d062..., SHA19f936...|Não vincula a medição Windows|
| EXP-04-WIN-entrega/VERSAO_EXP04_ORIGINAL_SHA256.json |Mesmo448 e SHA do anterior|Cópia documental, não nova execução|
| exp04-evidencias/completa-entrega.xml |Cabeçalho2842, failures 0, errors 0, skipped 0, timestamp 2026-11-16T13:45:06.658459+00:00|OrigemLinux corroborada em RESULTADOS_FINAIS.md; não fonte19 falhas|
| exp04-evidencias/completa-linux.xml |Cabeçalho2841,0 falhas,0erros,0 skips|Rodada anterior, cardinalidade diferente|
| EXP-04-WIN-entrega/evidencias/completa.xml |Cabeçalho2842,0 falhas,0erros,0 skips, timestamp 2026-11-17T14:48:12.646752+00:00|Relatório da mesma entrega declara linux/Python3.12.14/460 arquivos|
| exp04-win-evidencias/diagnostico-junit-recuperado/completa.xml |Cabeçalho2842,0 falhas,0erros,0 skips|Nome recuperado não comprova origem Windows nem19 falhas|
| EXP-04-WIN-entrega/evidencias/relatorio_execucao.json |sistema=linux, hashes=460, manifesto c0e3f0fd..., homologação=false|Versão posterior; não a histórica448|
| Matriz R2, fichas e casos_historicos.json |Propostas de associação/diagnóstico|Não transcrição do JUnit original|
| EncerramentoB e parsing5.1 com0erros |Relatados pelo usuário nos documentos recebidos|Não são nova prova das19 falhas e não foram repetidos|

Os arquivos completos das duas primeiras entregas também foram localizados nas
entradas dos ZIPs EXP-04-preparacao.zip e EXP-04-WIN-candidata-auditoria.zip.
Manifestos e cabeçalhos não mostram a combinação2842/19/0/7 procurada.

## Busca restrita, método e rastreabilidade

1. Enumerados nomes de XML/log/relatório/manifesto no workspace de trabalho já
   autorizado; pesquisa foi então concentrada em exp04-evidencias, EXP-04-entrega,
   exp04-win-evidencias e EXP-04-WIN-entrega. Referências inexistentes no layout
   antigo não foram tratadas como artefatos: o roteiro real está em payload/docs.
2. Inventariados **142 XML preexistentes** fora de venv/site-packages, payload,
   tests/schemas e diretórios temp-*. Foram lidos somente cabeçalhos de suite e
   metadados; não foram lidos/extraídos 19 tracebacks ou executado parser histórico.
3. Inventariados **11 ZIPs EXP-04** e **27 entradas XML** neles, por leitura de
   diretório/stream de arquivo. Sem extração de originais de teste ou reconstrução.
4. Nenhum cabeçalho único examinado declara2842tests/19failures/0errors/7skipped.
   Essa ausência de correspondência no escopo inventariado não é prova de ausência
   global: a localização Windows fornecida não está montada e nada externo foi varrido.
5. Contadores de cabeçalho são declarações do documento, não uma recontagem dos
   testcase originais. Suites múltiplas/ausentes ficam SEM_SOMA e exigem leitura
   específica se a fonte aparecer; nunca somar pai/filho ou cópias da mesma rodada.
6. Inventários CSV registram caminhos relativos sanitizados, tamanho, SHA e mtimeUTC.
   O timestampXML é mantido separado. Mtime de arquivo/cópia não prova a data/hora
   da execução. Fonte Windows inacessível não recebe SHA/contagem inventados.
7. Logs brutos, documentos privados, credenciais e dados de moradores não foram
   incorporados. Não foi inspecionada a custódia privada B nem criado novo acesso.

INVENTARIO_C1_CABECALHOS_XML.csv e INVENTARIO_C1_XML_EM_PACOTES.csv contêm apenas
metadados/cabeçalhos sanitizados; repetições são cópias e **não** contagens de
execuções independentes. INVENTARIO_C1_C2_DOCUMENTOS_FONTES.csv identifica os
artefatos efetivamente usados e os hashes da versão do código lido para C2.

A abertura inicial do ZIP recebido usou Python padrão apenas como leitor de
arquivo, antes de conhecer a vedação expressa interna. Após a leitura da instrução,
a continuidade usou somente utilitários de arquivo/texto/metadados, sem Python,
PowerShell, extrator, código do produto, testes ou validações de runtime. Não foi
criado arquivo executável novo. As fontes de instruções tiveram hashes conferidos.

## Fontes faltantes — solicitação específica e ordenada

1. **completa-utf8.xml original** no diretório Windows informado: permitir verificar
   suites sem dupla contagem,19failure,7skipped e os atributos originais. Preservar
   nome, bytes, tamanho e SHA do original. Se contiver dados privados, manter raw
   com custodiante e compartilhar cópia sanitizada autorizada com cadeia original→cópia.
2. **Log/stdout/stderr da mesma rodada** e resumo/JSON: nomes ainda não informados.
   Necessários para comando completo, retornos, ambiente/plugins e contexto dos
  19 tracebacks/sete motivos, sem transplantar motivos de cleanup ou BPQ38.
3. **Contexto da execução**: Windows/Python/pytest/plugins, comando UTF-8, horário
   com fuso, commit e diff/untracked daquele instante. Nome da pasta não basta.
4. **Manifesto efetivamente usado naquela rodada e seu SHA**. Há manifesto 448
   localizado, mas sua adoção naquela execução continua não demonstrada.
5. **Aceite humano dos vínculos** após confronto com código exato da época.
   Observação de fonte, quando possível, ainda não é confirmação por revisor.

A pendência foi apresentada ao usuário e recebeu o caminho acima, sem receber
os bytes. C2 continua independente dessa obtenção. Não estender automaticamente
os90dias da coletaB para essas novas fontes históricas: custódia/retenção e cópia
precisam de decisão específica. Nenhum original foi recriado para preencher lacuna.

## Estados de saída

MATRIZ_C1_VINCULOS_PARA_REVISAO.csv contém19 linhas com proposta R2 separada de
original/observado, zeros de confirmações e nenhum testcase Windows atribuído.
Linux e cleanup são referências separadas não transferíveis. C/D/E, DACL e
conversões reais continuam bloqueados; a autorizaçãoB única está consumida.

## Complemento recebido durante C1 — índice secundário do usuário

O índice de recuperação em mensagem forneceu19identificadores de falhas e quatro
registros agrupados que totalizam7 skips, além de2816PASS/19FAIL/7SKIP/0ERROR,
aviso1,555,30s e retorno 1. A coincidência literal desses identificadores com a
proposta R2 é registrada em coluna SEPARADA e não promove os vínculos.

A situação mudou de ausência total de motivos para **motivos relatados em fonte
secundária**. Não faltam mais os textos agrupados do índice; continuam ausentes
os testcase/parametrizações e estágio dos sete skips no XML original. Os quatro
casos na linha16 de reconstrução não foram inventados como quatro nodeids.
Os dois POSIX são rules/test_authority, não as falhas de permissão propostas
para WIN-18/19 em private_simulation. O último motivo não declara númeroWin32.

Foram declarados SHAaba965... para Texto colado(6).txt e SHA3b158... para o
arquivo sanitizado transcrito. Nenhum desses bytes foi recebido: não recalcular
nem atribuir esses SHAs ao registro local novo, que tem seu próprio hash.
Ver fontes_relato/INDICE_RECUPERACAO_USUARIO_20261118.md e o CSV de skips.

A rodada anteriorEXP04 2842/38 falhas citada no índice é outra fonte potencial,
não a alvo2842/19/7. Número38 isolado também não identifica a rodadaBPQ04.
O comando é estrutura recordada, não literal autenticado. A própria mensagem
mantém explícita a falta de SHA do manifesto usado e de aceite dos vínculos.
Logo C1 segue documentalmente parcial e os 19 estados permanecem provisórios.
