# WIN19-C1/C2 — decisões e portões pendentes

18/11/2026. Estado da entrega: preparação documental para revisão, sem execução.
Prontidão para executar = falsa. C/D/E, DACL e conversões reais bloqueados.

## C1: reconciliação parcial e fontes ainda necessárias

O manifesto de 448 entradas foi localizado, SHA-256
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb.
Não foi demonstrado seu uso na rodada Windows. O índice secundário do usuário
informa os 19 identificadores e quatro grupos de skips que somam sete. Os hashes
da transcrição bruta e do derivado sanitizado são declarados, não recalculados.
Todos os 19 vínculos permanecem PROVISORIO_SEM_FONTE; aceite do revisor PENDENTE.

| Pendência | Evidência/decisão necessária | Efeito atual |
|---|---|---|
| C1-01 JUnit original | completa-utf8.xml na localização Windows relatada, bytes/tamanho/SHA e custódia | Original não recuperado; sem testcase/traceback primário |
| C1-02 Log da mesma rodada | Log persistido e comando literal autorizado/sanitizado | Comando apenas recordado e resumo secundário |
| C1-03 Versão da execução | Manifesto efetivamente usado, SHA, contexto Windows/Python/pytest/plugins e estado de código naquele instante | Artefato 448 encontrado não autentica uso |
| C1-04 Sete skips | Casos, parâmetros e estágio no original | Só quatro linhas agrupadas; não inventar quatro nodeids de reconstrução |
| C1-05 Vínculos | Comparação humana com versão exata e aceite por ID | Coincidência literal na transcrição não confirma origem |
| C1-06 Custódia | Responsável, autorização de cópia/sanitização, retenção e descarte dessas fontes | Não transferir automaticamente a retenção B |

A obtenção do caminho não transferiu o arquivo Windows ao Linux. As 142 entradas
XML locais e 27 entradas XML em 11 pacotes foram examinadas apenas por metadados/
cabeçalhos; nenhum cabeçalho único correspondeu a 2842/19/0/7. Isso não prova ausência
global. Cópias e suites aninhadas não podem ser somadas como novas execuções.

## C2: decisões de desenho antes de implementar

| Pendência | Decisão e condição de aceite |
|---|---|
| C2-01 Observador | Aprovar persistência pré-asserção, erro imediato e relatório parcial fora do temporário |
| C2-02 WIN-03 | Separar NUL pré-API do ramo de erro nativo ainda não demonstrado; sem memória insegura |
| C2-03 WIN-04 | Acrescentar no desenho positivo de mesmo caminho/identidade antes de julgar recusa de hardlink |
| C2-04 WIN-06..10 | Confirmar layout positivo/revisão zero e causalidade, sem apagar arquivo inesperado |
| C2-05 WIN-11 | Isolar ambiente/configuração Git antes de futura fixture; raiz Git e ancestral simbólico são casos separados |
| C2-06 WIN-12/14 | Aprovar fluxo real de autoridade/recibo e fontes; proposta WIN-14 não aplicada e exige revisão |
| C2-07 WIN-15/16 | Oráculos independentes, bytes integrais e CLI positivo; DTO separado não comprova saída operacional |
| C2-08 WIN-16 | Definir persistência de saída parcial em timeout e distinção revisão humana/bloqueio |
| C2-09 Limpeza | Provar propriedade/identidade e não seguimento de links; falha/resíduo nunca sucesso |
| C2-10 Dependências | Congelar versões, origem dos imports, helpers e manifesto; fonte filelock local não autentica Windows |
| C2-11 WIN-18/19 | Manter protocolos DACL bloqueados; skip placeholder não é ensaio de acesso |

A matriz revisada tem 21 subcasos e 19 IDs, sem resultado novo. As referências de
produção foram lidas estaticamente, sem mudança, importação ou execução. Este
material não aplica a proposta de autoridade nem modifica cenários existentes.

## Política DACL: preservada, não aprovada

D01–D10 continuam PARA_APROVAÇÃO conforme proposta R2, sem grants ou deny implícitos:

| Decisão | Tema pendente |
|---|---|
| D01 | READ_CONTROL por papel/objeto e custódia de metadados |
| D02 | WRITE_DAC e limite de proprietário/mesmo token |
| D03 | WRITE_OWNER, ameaça e exceções de manutenção |
| D04 | Imutabilidade da fonte, fronteira importador/runtime/operador |
| D05 | Herança, raiz/filhos e imposição pelo fluxo real |
| D06 | Exceções Administradores/SYSTEM |
| D07 | Tokens O/U realmente distintos e A limitado à evidência sanitizada |
| D08 | CREATE/REPLACE, proteção inicial e após reabertura |
| D09 | DELETE, DELETE_CHILD, RENAME e contrato por objeto/link |
| D10 | Chaves, registros, locks, retenção e descarte |

Antes de acesso entre contas: aprovar cada papel/objeto/operação, exceção, token,
responsável e ambiente. Mesmo token não é dois papéis de segurança. Não instalar
ACL manualmente e atribuir a proteção ao escritor/leitor. Não tratar sharing
violation, atributo read-only, POSIX ou leitura de DACL como acesso efetivamente negado.
A candidata e a política atuais permanecem intactas; implementação funcional
necessária pertence a tarefa futura específica.

## Portões independentes — nenhum aberto por esta entrega

1. **Revisão C1/C2:** aceitar os documentos e resolver/aceitar as lacunas, sem
   converter aceitação documental em execução ou vínculo histórico confirmado.
2. **Implementação futura C:** autorização específica para runner externo e
   alterações propostas, revisão do diff e hashes, sem alterar a candidata validada.
3. **Execução futura C:** autorização específica de ambiente, casos, capacidade,
   custódia e interrupção. Uma autorização de implementação não autoriza testes.
4. **Portão D:** política D01–D10, integração do fluxo e laboratório/tokens aprovados;
   autorização específica de ensaios nativos. Segurança não é decorrência de PASS C.
5. **Portão E/homologação:** permanece bloqueado até revisão independente dos
   resultados e controles essenciais. Não desbloquear conversões reais.

O Portão B está encerrado, sua custódia privada preservada e sua autorização única
consumida. O relato de parsing PowerShell 5.1 sem erros é documental: não foi
repetido nem prova runtime. Os 90 dias aprovados para B não regem fontes C1 novas.

Não houve implementação, teste, parsing novo, mudança de ACL, privilégio, conta,
política ou candidato. Sem commit, push, merge ou publicação. Entrega somente em
novos documentos externos ao Git, com manifesto de hashes. **Parar para revisão.**
