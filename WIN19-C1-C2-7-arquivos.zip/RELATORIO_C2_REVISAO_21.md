# WIN19-C2 — revisão estática individual dos 21 cenários

18/11/2026. Desenho e revisão documental, não implementação ou execução.
Referências: C2_REVISAO_21_CENARIOS.md, matriz de21recebida e proposta R2 existente.
MATRIZ_C2_REVISAO_21.csv detalha cada requisito por subcaso. Nenhum arquivo de
runner/fixture/código foi criado ou alterado. Não houve coleta de testes.

## Composição e referências de versão

5 casos API/diagnóstico +11 subcasos links/origem +3documentais/modo +2protocolos
DACL =21 subcasos/19 IDs. WIN11A/B e WIN13A/B são os desdobramentos. Contagem por
leitura textual da proposta; não contagem observada de um coletor pytest.

S1: test_win19_independentes.py da preparaçãoR2,
SHA ff45b64d267d2a0d59bb9585a4026c91fecb59dd97d8ae182e435960e562a3f2.
S2: conftest.py, SHA 25c1a11bd83354d1129b01047809b95d43f52d926de711ede487f3e37c035391.
S3: suporte_nativo.py, SHA a6377489dbcf93efc992a905a3f4becb87a8ca40785df2a22a1112531eafdb70.
S4: factories_r2.py, SHA c50f03fe7c4386d957234628edd3b067b4ab11cb81e46f2edb8906005ea6b56d.
W14P: proposta NÃO APLICADA de autoridade completa,
SHA 016fc28fe4ae63c7ac04801856116d93280dbcbd4c078894c36f42a1dcf51da9.
P1–P6: fontes de produção lidas, sem executar, na referência R1-FIX: diagnóstico
ACL, vínculosJSON, FontesLocaisProtegidas, simulaçãoJSON, validaçãoCLI e DTO de
exportação. D1: implementaçãoWindows de filelock instalada para leitura local;
lockfile do projeto fixa3.20.0, sem comprovar instalação efetiva no Windows.
Hashes/tamanhos/mtimeUTC e aliases completos no inventário de documentos-fontes.
Referências P são contrato da candidata470, não autenticação da versão de 448 histórica.

## Regras comuns aplicadas a CADA linha da matriz

**E0 — observação e eixos.** Futuro registro durável fora do basetemp deve preceder
cada asserção relevante e sobreviver a raise, timeout, crash e falha de cleanup:
controle/subcaso, fase, positivo válido, capacidade realmente alcançada, resultado,
API/código efetivamente observado, bytes/ID/snapshot e motivos. Nunca inferir Win32
pela mensagem/nome do teste. API da aplicação pode ser NÃO_OBSERVÁVEL mesmo com
fixtureWindows real; registrar separadamente API do helper e do produto.

**L0 — propriedade e limpeza.** Só entradas criadas pelo ensaio e identificadas,
ancestrais sem redirecionamento e exclusão sem seguir reparse. FileID, volume e
nome são informações diferentes; inode/fileID isolado não é fronteira DACL. Nunca
usar remoção recursiva do alvo, limpar resíduos antigos ou apagar objetos estranhos.
Divergência/erro/ausência não comprovada preserva área e evidência para revisão.
A prova da limpeza e o PASS funcional são eixos separados. SuporteS3 usa handles,
GENERIC_READ nos ancestrais, share0x3, identidade e disposição por handle; nenhuma
segurança/ABI/viabilidade foi validada nesta C2. Não alterar flags para obter verde.

**Ordem comum.** Planejar autorização e hashes → área própria/exclusiva → evento
INÍCIO persistido → positivo válido e snapshot → adversarial comprovado → operação
alvo → persistência do resultado/erro → comparação integral → julgamento por eixo →
checkpoint de evidência → limpeza própria autorizada ou preservação → hashes/recibo.
Se não alcançar a operação por fixture/capacidade, fica NÃO_VALIDADO, nunca PASS.

**PASS/FAIL/BLOQUEADO/SKIP planejados.** PASS somente para a afirmação realmente
exercitada com positivo e sentinelas. Violação de contrato/alteração indevida é
FAIL com evidência. Precondição/versão/identidade/origem/diagnóstico não comprovados
bloqueiam promoção.1314 somente no cenário que depende do symlink, motivo literal
observado e eixoNÃO_VALIDADO. Não transformar falha real, erro genérico ou falta de
instrumentação em skip conveniente. Todos os eixos permanecem NÃO_VALIDADO agora.

## Revisão dos 21 subcasos

### WIN-01 — flags diagnósticas (S1:88–94)

Positivo: arquivo próprio regular, caminho consigo e bytes completos. O coletor
recebe owner/ACEs SINTÉTICOS e deve produzir caminho_coincide=true e duas flagsfalse.
Não lê/impõe uma DACL real por receber essas entradas. Persistência atual vem após
asserções; qualquer falha anterior pode deixar só INÍCIO. PASS futuro limitado
às flags/bytes, nunca negação por outro token. Aplicam-seE0/L0; NativeAPI interna
sem observação própria deve permanecer NÃO_OBSERVÁVEL.

### WIN-02 — alias8.3 real (S1:98–119)

Nome longo, alias realmente distinto e segundo arquivo próprio com mesmo conteúdo.
Comparações esperadas: alias→originaltrue, alias→outrofalse e inexistente→originalfalse.
GetShortPathNameW registra retorno/erro imediato antes da primeira asserção, ponto
positivo da proposta. Faltam os demais resultados antes de asserts. Nome longo e
alias devem indicar o mesmo objeto/bytes; ausência de alias é NV. Nada de fabricar
nome curto ou mockar normalização. Helper de remoção não precisa apagar esses alvos.

### WIN-03 — comparação ordinal (S1:123–134)

Pares Unicode, ordenação, nãoBMP e eszett/ss têm expectativas explícitas. Comparador
na candidataWindows usa Kernel32/assinatura5argumentos e comprimento em WCHAR16.
Resultados são registrados antes de asserts. NUL é rejeitado antes de chamar API;
isto NÃO demonstra retorno nativo de erro. Ramo de erro permanece não demonstrado,
sem ponteiros inválidos/memória insegura/mock promovido a nativo. Julgar comparação
e ramo de erro como subafirmações distintas sem criar um22ºcaso nem homologar tudo.

### WIN-04 — hardlink no comparador diagnóstico (S1:138–156)

Fixture deve demonstrar dois nomes, mesmo volume/fileID não zero, nlink>=2 e bytes
inteiros iguais. Comparador deve recusar nomes diferentes. Falta positivo consigo
no próprio caso: um comparador sempre false poderia satisfazer a negativa isolada.
Isso precisa de revisão textual antes de futura implementação. Preservar original
e remover só entrada adicional identificada. Mesmo fileID não torna nomes iguais;
o resultado não proíbe hardlink universalmente em leitor cujo contrato éID+SHA.

### WIN-05 — baseline sintético (S1:160–166)

Positivo combina arquivo regular e ACEs declaradas como somente herança; resultado
somente_heranca=true e flags de autorização/leitorfalse. É comparação diagnóstica,
não política efetiva. Registrar análise segura antes dos asserts e preservar bytes.
Não imprimir o dicionário completo, que pode carregar caminho/owner. Não converter
essa saída em AccessCheck ou isolamentoWindows.

### WIN-06 — registro.json simbólico (S1:172–211)

Consultar revisão 0 e conferir layout da raiz INTERNA antes de criar link de arquivo
para sentinela externa própria. Registrar a mudança única e recusa sem dados no
erro, comparar árvore/bytes. A versão usa ErroLeitura genérico: erro operacional,
timeout ou contrato inválido não podem ser aceitos como causa de segurança só por
terem a mesma classe. Rejeição diferencial exige positivo realmente válido e fase
alvo demonstrada. ErroWin32 do produto não é exposto; NÃO_OBSERVÁVEL, não inventado.

### WIN-07 — chave.bin simbólica (S1:172–211)

Mesmo fluxo, mas a entrada é chave ausente da revisão 0 e o alvo é amostra fabricada,
não chave real do usuário. Comparar bytes completos em memória e árvore externa.
Não confundir recusa de link com DACL que protege autoridade/credenciais. Nunca
serializar segredo em evento/asserção expandida. Guardas e limitesE0/L0/1314 comuns.

### WIN-08 — escrita.lock simbólico (S1:172–211)

Lock só pode estar ausente ou ser regular/vazio próprio do positivo. Anomalia não
pode ser apagada para forçar fixture. Biblioteca3.20.0 local usa abertura/truncamento
e remove lock no releaseWindows, mas isso é leitura de código, não observação do
ambiente alvo. Demonstrar fase de recusa antes de qualquer truncamento externo.
Um timeout/erro de abertura do lock não é PASS de rejeição. Não alterar FileLock.

### WIN-09 — evidencias como diretório simbólico (S1:172–211)

Exigir ausência de evidencias na revisão 0 desta fixture mínima; se existir objeto
inesperado, preservar/bloquear. Link deve ser de DIRETÓRIO e apontar a árvore própria
com sentinela. Recusa sem percorrer/escrever árvore e snapshot integral igual são
obrigatórios. Não usar link de arquivo nem junction para fingir esse cenário.

### WIN-10 — cabecas como diretório simbólico (S1:172–211)

Mesmas precondições, com cabecas. Não apagar histórico/preexistente para viabilizar
link. A negativa desta revisão 0 não cobre todas as hipóteses de histórico assinado
com múltiplas revisões. Erro da fixture ficaNV. Limpeza só do reparse próprio, nunca
da árvore apontada. Evento antes da asserção de exceção ainda precisa ser resiliente.

### WIN-11-A — raiz sob Git sintético (S1:215–228)

Positivo em repositório regular fora de Git. Preparação adversarial futura cria
Git só em raiz nova/exclusiva, exige recusa de novo filho e preserva testemunha.
Risco concreto: o subprocesso Git da proposta herda ambiente/configuração. Variáveis
de redirecionamento/templates poderiam afetar outro destino. O desenho futuro
precisa de ambiente controlado, destino/posse provados e metadata prevista; não
executar o Git da proposta agora nem usar autorizaçãoB. Este caso não comprova
ancestral simbólico, bare danificado ou todos os tipos de worktree.

### WIN-11-B — ancestral simbólico (S1:232–245)

Link de diretório aponta a destino próprio e envolve construtores do repositório
e da aplicação. Rejeição de um não prova o outro: eventos/positivos e resultados
separados. A proposta não traz positivo de app no próprio caso; precisa ser definido
sem ligar servidor/operar documentos reais. Exigir nenhum novo filho no destino,
bytes/árvore intactos e RuntimeError esperado da app; não é prova de HTTP/sessões.

### WIN-12 — fonte por link com bytes iguais (S1:249–290)

Positivo guarda fontes, cria vínculo/HMAC/evento, consulta revisão 1 e lê a fonte.
Somente então troca entrada própria por symlink com mesmo SHA/conteúdo. Exigir
recusas em ler_fonte E consultar, preservando registro/chave/cabeças/árvore externa.
Bytes de chave são comparados só em memória; não incluir no JUnit/raw compartilhado
nem habilitar exibição de variáveis locais. Contrato/atesto inválido antes do ataque
não comprova segurança. E0 continua necessário inclusive se pytest.raises falhar.

### WIN-13-A — link interno de fonte protegida (S1:295–314)

MesmoID/hash lê arquivo regular interno no positivo. Link interno deve produzir
FONTE_CONTEM_LINK e bytes do alvo intactos. A superfície pública retorna código de
aplicação, não um erroWin32 observado. Esse é o contrato da raiz/ID/SHA, sem DACL
entre contas. Não misturar com a negativa externa ou inferência por nome de arquivo.

### WIN-13-B — link externo de fonte protegida (S1:295–314)

Positivo interno regular com mesmoID/hash; adversarial aponta a alvo próprio fora
da raiz autorizada. Pela ordem da implementação lida, FONTE_FORA_DA_AREA_AUTORIZADA
precede a verificação de symlink. Preservar alvo externo e não mudar a expectativa
para satisfazer observado. Código app não prova o Win32 que não foi capturado.

### WIN-14 — pacote/autoridade/recibo reais de laboratório (S1:318–361,S4:14–54)

Fixture mínima com unidade sem dívida, quatro catálogos, inventário, fontes e atesto
somente dela. Gravar/recarregar positivo, verificar assinatura/hash/ator. Adversarial
com novoID validado antes da troca de uma fonte por link. Exigir código app exato,
sem corpo/recibo novo e preservação do positivo/externo. Não é autorização de regra
financeira ou IAM/NTFS. Lacuna concreta: snapshot completo da autoridade/concessões
está só em W14P, proposta não aplicada. Rever esse complemento antes de implementar
qualquer teste; guardar segredo em memória/custódia privada, só boolean no derivado.

### WIN-15 — opt-in de canônicos (S1:464–520)

Três PDFs sintéticos habita/fl/cadastro, saída nova sem opt-in deve conter zero
canônicos; com opção explícita, três, homologado=false. Gabaritos são derivados do
mesmo leitor apenas para contrato de opção/comparador, NÃO oráculo financeiro.
A proposta preserva inputs por hashes; a especificação exige também bytes completos
e relato pré-assert. Teste da opção não prova extração,30colunasXLSX, endereço ou DACL.

### WIN-16 — conflito documental vindo de PDF/CLI (S1:380–436,S4:62–114)

Positivo com um documento deve retornar0/comparacao_confere; caso de dois documentos
fabricados válidos deve retornar2/revisao_humana e zero diferenças do gabarito
declarativo. Código2 sozinho também pode representar bloqueio: verificar JSON,
a presença real dos dois documentos/ocorrência e preservação de fontes/auditoria.
Não gerar esperado copiando saída do leitor após uma divergência.

Lacunas concretas: coordenadas/linhas/IDs/ressalvas ainda dependem de runtime futuro;
stdout/stderr de subprocess.run são persistidos só ao retornar, portanto timeout
pode perder o diagnóstico; DTO é exercitado com pessoa do gabarito, não o objeto
materializado pelo CLI. Essa barreira DTO é independente e não demonstra trânsito
do objeto real ao exportador. CLI não exporta: ausênciaXLSX não homologa conversão
operacional ou faturamento. Nada é corrigido ou executado nesta C2.

### WIN-17 — auditoriaJSON roundtrip (S1:440–451)

Ocorrência sintética, escrita real, releitura/modelo equivalente e comparação
integral do UTF-8 canônico esperado. Positivo estrutural e eventos de escrita/releitura
antes dos asserts precisam de persistência. Demonstra semântica/bytes, não DACL,
atomicidade concorrente ou proteçãoWindows por modo 0600. Não colocar payload de
ocorrência/chave em saída pública para provar a igualdade.

### WIN-18 — protocolo de permissão da fonte (S1:455–456)

É apenas placeholder que ignora por política/tokens pendentes. Nenhuma função
completa de teste DACL existe. Fonte, ancestrais e ações por papelO/U precisam da
políticaD aprovada e conta comum distinta; preservar sentinelas integrais e observar
API/código real. Nenhum PASS pode vir do skip ou de chmod. Os dois skipsPOSIX no
índiceC1 são rules/test_authority, não a falha private_simulation/permissao_fonte.

### WIN-19 — protocolo de permissão da raiz (S1:460–461)

Também placeholder bloqueado, não testeNTFS. Futura especificaçãoD deve separar
raiz/filhos, LIST de READ por caminho conhecido, DELETE de DELETE_CHILD, herança,
owner/WRITE_DAC/WRITE_OWNER, create/replace e retenção. Positivo do operador e
negativo de outro token são necessários. Não atribuir proteção à ACL instalada
manualmente na fixture, não criar conta nem alterar qualquer permissão agora.

## Lacunas comuns prioritárias e conclusão da revisão

1. RunnerC não existe. AutouseS2 escreve INÍCIO/eventos dentro de tmp_path; a área
   pode ser volátil e não substitui observador/JUnit/raw separados duravelmente.
2. Parte das asserções antecede registrar, e raises/timeout podem impedir os eventos.
   Preservar primeira falha e erros posteriores de fechamento sem trocar causa.
3. S3 é proposto e não validado nativamente. Não converter erro do helper em falha
   do produto nem em sucesso de segurança, nem usar cleanup 39 como oráculo deC.
4. Inputs/saídas usam helpers de escrita comuns, não sempre criação exclusiva. O
   futuro desenho deve impedir reuso/colisão sem apagar material desconhecido.
5. Flags de revisão/gates de pytest não são autorização. ParsingPS5.1 com0erros é
   relato novo do anexo, não aval aos helpersWin32 ou à execução dos 21 casos.
6. Nenhum resultado Linux, cleanup ou da coletaB foi transportado aos 21 subcasos.

C2 entrega revisão textual completa dos21itens, não teste aprovado. Todos21 eixos
funcional/nativo/DACL=NÃO_VALIDADO;19 vínculos=PROVISORIO_SEM_FONTE. Pendências/
autorizações em DECISOES_E_PORTOES_C1_C2.md. Nenhum código foi implementado.
