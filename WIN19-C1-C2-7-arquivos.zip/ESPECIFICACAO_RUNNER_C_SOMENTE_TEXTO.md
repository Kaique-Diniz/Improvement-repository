# WIN19-C — especificação textual do futuro executor

18/11/2026. **NÃO IMPLEMENTADO. NÃO AUTORIZA EXECUÇÃO.** Este documento descreve
um contrato para revisão. Não contém runner, fixture, comando pytest ou procedimento
para alterar privilégios. Prontidão continua falsa; DACL e conversões bloqueadas.

## Escopo e fronteiras

São 21 subcasos para 19 controles, na matriz C2 desta entrega. WIN-11 e WIN-13
possuem dois subcasos cada. Os dois protocolos DACL WIN-18/19 não se tornam testes
efetivos por estarem enumerados: ficam bloqueados até política e laboratório D
aprovados. A implementação futura não poderá atribuir a esses placeholders um PASS.

A candidata R1-FIX de 470 arquivos será somente leitura. Seu HEAD não basta como
identidade: exigir manifesto aprovado, hash desse manifesto, correspondência de
cada arquivo e ausência de extras não autorizados, além da origem dos imports.
A verificação futura de integridade deverá rejeitar acessos por links/reparse nos
ancestrais, sem reconstruir ou corrigir a candidata silenciosamente. Nenhuma dessas
verificações foi executada agora; o hash do manifesto local é referência documental.

Os ensaios não poderão usar documentos reais. Objetos de ataque, positivos e
sentinelas serão sintéticos e inéditos. Não acessar o residual antigo de cleanup,
as candidatas anteriores ou a custódia privada B. Nenhum PASS de cleanup é prova C.

## Entradas congeladas para a revisão de implementação

- Autorização futura específica, responsável, escopo de casos e ponto de parada.
  A autorização B consumida não é reutilizável.
- Manifesto da candidata, fontes dos cenários/helpers e dependências aprovadas,
  todos com tamanho e SHA-256. Alteração exige nova revisão e novo identificador.
- Python 3.12 e UTF-8; origem explícita de importação e lista de dependências e
  plugins. O filelock local lido não comprova a versão instalada no Windows.
- Caminhos curtos, absolutos, novos e exclusivos para laboratório e evidências,
  fora de Git, documentos privados e outras candidatas. Evidências fora do
  basetemp; nenhum diretório existente entregue ao pytest como área descartável.
- Capacidade Windows real e volume identificado. Não ativar Developer Mode,
  elevar token, mudar ExecutionPolicy, herança ou ACL para viabilizar o ensaio.
- Aprovação das lacunas da matriz C2, especialmente WIN-03/04/11/14/16/18/19.

## Estados e ordem obrigatória

| Estado | Evidência necessária para avançar | Se faltar |
|---|---|---|
| PLANEJADO | Revisão e autorização específicas | BLOQUEADO, sem criar laboratório |
| IDENTIDADE_ADMITIDA | Manifestos, versão e origem de imports correspondem | Parar sem reescrever fonte |
| AREA_RESERVADA | Criação exclusiva e identidade de ancestrais e área demonstradas | Preservar recurso desconhecido; bloquear |
| INICIO_PERSISTIDO | Registro durável externo ao temporário, caso/etapa e limites | Não iniciar operação adversarial |
| POSITIVO_VALIDO | Fluxo real aceita entrada válida, com bytes e árvore de referência | NÃO_VALIDADO; não usar a recusa adversarial como PASS |
| ADVERSARIAL_ESTABELECIDO | Capacidade realmente criada e identidade demonstrada | BLOQUEADO ou skip pontual justificado |
| OPERACAO_OBSERVADA | Resultado real e erro imediatamente capturados | NÃO_VALIDADO; sem inferência pelo nome do teste |
| EVIDENCIA_PERSISTIDA | Resultado e observações gravados antes das asserções | Não promover status |
| INTEGRIDADE_COMPARADA | Bytes integrais e sentinelas inalterados, ou violação registrada | FAIL se houve alteração indevida; preservar |
| JULGADO | Critérios do caso aplicados separadamente por eixo | Sem promoção por agregado |
| ENCERRADO | Handles/processos liberados, limpeza própria comprovada ou resíduo registrado | Limpeza FALHOU, sem homologação |
| CUSTODIA_CONCLUIDA | Índice e hashes finais dos registros, recibo do custodiante | Entrega parcial explícita |

Execução futura sequencial; nenhuma concorrência entre casos. Operações adversariais
concorrentes só dentro do cenário que as exige e com sincronização demonstrável.
Em cenário de handle auxiliar, confirmação de abertura precede a operação alvo;
liberação garantida em encerramento; comparação integral de bytes após a liberação.
Nunca encerrar antecipadamente o handle cuja restrição se pretende demonstrar.

## Observador e persistência anterior às asserções

O futuro observador terá área própria separada do laboratório. Registrar INÍCIO,
precondições, positivo, adversarial, operação, comparação e encerramento. O JSON
por caso é evidência primária do ensaio; JUnit não pode ser o único sobrevivente.
Registros devem ser escritos antes das asserções relevantes, inclusive antes de
avaliar a API/código esperado. Uma exceção anterior à asserção também exige registro.

Campos mínimos: identificador único; controle/subcaso; hashes de versão; etapa;
data UTC e fuso do relatório; tipo de objeto; API/operação; origem do dado
(produto/helper); resultado efetivo; código Win32/errno observado; positivo válido;
capacidade estabelecida; integridade de bytes/árvore; estado funcional/nativo/DACL;
primeira falha; falhas secundárias; estado de limpeza e lacunas.

Capturar GetLastError imediatamente após a API que falhou, antes de outra chamada.
Não derivar código a partir de exceção traduzida, nome do teste ou erro esperado.
Quando o componente não expõe a API nativa, marcar NÃO_OBSERVÁVEL e separar a
telemetria do helper. Erros de CloseHandle ou da persistência não substituem a
primeira falha; ficam adicionais. APIs ou códigos diferentes exigem diagnóstico,
sem editar expectativas automaticamente.

Persistência deve ter confirmação de conclusão e proteger contra truncamento.
Definir na revisão de implementação como registrar falta de espaço ou falha de
escrita sem perder os eventos já concluídos. Não prometer sobrevivência a falha de
energia sem evidência de durabilidade. Falha do observador bloqueia aprovação.

## Sentinelas e propriedade dos objetos

Guardar bytes sintéticos completos em memória e compará-los integralmente após
cada recusa; SHA é complementar, não substitui a comparação exigida. Capturar árvore,
tipo, identidade física e volume antes/depois, com atenção a nomes novos, removidos
ou redirecionados. File ID, caminho e hash respondem a perguntas diferentes.

Cada objeto terá registro de criação exclusiva pelo ensaio e identidade esperada.
Sentinela externa é externa à área sob ataque, mas ainda pertence ao laboratório
sintético autorizado. Nunca usar arquivo de terceiro como alvo. Não resolver links
para abrir/remover seus alvos, nem tratar junction como substituta de symlink.
Hardlink deve ser julgado pelo contrato do componente: o comparador diagnóstico e
o leitor ID+SHA não têm necessariamente a mesma regra de identidade física.

## Falhas, interrupções e resíduos

| Evento | Tratamento futuro exigido |
|---|---|
| Sem privilégio de symlink, erro 1314 efetivamente observado | Skip apenas do cenário dependente; controle nativo NÃO_VALIDADO; sem elevação |
| Alias 8.3 indisponível | Capacidade não demonstrada; não fabricar alias para PASS |
| Positivo inválido ou erro genérico não causal | BLOQUEADO/NÃO_VALIDADO, nunca evidência de rejeição segura |
| API inesperada, bytes alterados ou acesso indevido | FAIL com evento persistido; interromper a sequência pertinente para revisão |
| Timeout de filho | Persistir etapa, estado conhecido e buffers já obtidos; encerrar só processo próprio e preservar diagnósticos |
| Crash ou interrupção | Registro externo de início/último checkpoint permanece; sem resultado final é incompleto, não PASS |
| Falha de limpeza/fechamento | Preservar primeira falha e resíduos; marcar limpeza FALHOU e relatório parcial |
| Evidência ausente ou hash divergente | BLOQUEADO; nunca reconstrução silenciosa nem aprovação por HEAD |

A revisão de implementação deve definir como obter saída parcial do CLI mesmo em
timeout: o desenho atual que depende do retorno normal pode perder stdout/stderr.
Não executar continuação automática depois de violação de sentinela ou identidade.
Não atribuir códigos de retorno numéricos a este runner ainda não implementado;
a tabela de retorno futura deverá distinguir teste falho, bloqueio e erro operacional.

## Limpeza e custódia

Limpeza somente de objetos próprios com identidade e ancestrais conferidos,
sem seguir symlink/reparse e sem remoção recursiva indiscriminada. Alteração de
identidade, objeto inesperado ou ausência não comprovada impede declarar limpeza.
Não apagar automaticamente o laboratório inconclusivo. Propor procedimento específico
se houver resíduo; nenhum ensaio pode limpar o residual histórico por conveniência.

Guardar raw privado apenas quando necessário e autorizado. Derivados sanitizados
terão SHA do original e do derivado, regra de remoção, responsável, data/fuso e
identificador da autorização. Relatório compartilhável sem conteúdo de documentos,
SIDs/SDDL, nomes de conta, chaves HMAC, credenciais ou caminhos pessoais. Autoridade
HMAC funcional não comprova isolamento de token ou DACL.

Retenção e descarte das novas evidências exigem decisão própria. Não herdar os
90 dias da coleta B. Recebimento, cópia e localização privada ficam com custodiante;
nenhum resultado deve depender de logs guardados somente em área temporária.

## Julgamento independente

Resultado do caso: PASS, FAIL, BLOQUEADO ou SKIP com motivo. Separadamente,
afirmações funcional, nativa e DACL: APROVADO, FALHOU ou NÃO_VALIDADO. Um PASS de
serialização, comparação ou recusa de link só aprova a afirmação exercitada.
Erro 32, chmod, flags sintéticas e leitura de ACL não demonstram negação DACL.

WIN-03 mantém o ramo de erro nativo não demonstrado. WIN-14 exige versão de proposta
de autoridade completa previamente aprovada. WIN-16 separa CLI, DTO e política de
exportação: prova isolada de DTO não cobre automaticamente o fluxo inteiro.
WIN-18/19 dependem do portão D, política D01–D10 e tokens distintos aprovados.

Nenhum agregado verde, skip ou coleta B promove prontidão, homologação Windows,
DACL ou conversões reais. Implementação, execução C e eventual ensaio D requerem
revisões e autorizações distintas. **Parar nesta especificação documental.**
