# WIN19-C6-R1 — materialização sintática mínima

23/11/2026 — America/Sao_Paulo.

**C6-R1: MATERIALIZADO_AGUARDANDO_VALIDACAO.**
Conferência exclusivamente de integridade e equivalência dos bytes. Não foi
executado parsing JSON, metaschema, validação de instâncias ou sondas estruturais.

## Autorização e fontes

Instrução C6-R1 recebida, Texto colado.txt, 7.547 bytes, SHA-256
`22174b1c4ac83063ade1ff98749ffc1f8962c3ecfbbbe27f1223a8ce88737967`.
Referência obrigatória lida: PARECER_INDEPENDENTE_WIN19_C7_2026-11-23.md,
6.487 bytes, SHA-256
`9a5596971183d899c4d6334a25105668e9b634c120918279e18764ae9877a73f`.
O parecer fundamenta a correção; a instrução autoriza apenas sua materialização.

Fonte exclusiva efetivamente utilizada:
`/workspace/work/WIN19-C6-CONTRATOS-20261123/contratos_c/relatorio.schema.json`.
Tamanho autenticado antes da escrita: **20.836 bytes**. SHA-256:
`ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6`.
Não foi utilizada reconstrução, cópia C7 ou arquivo de nome semelhante como fonte.

ZIP C6 preservado, 19.872 bytes, SHA-256
`ee9cd82da311ef8ea003f3eba249a1c9967d46cd258a10dd813e706848e82f3a`.
Manifesto C6, 727 bytes, SHA-256
`a72a1800441cdb1b4e1a156759a1e45eb7ae1c3f29d674146403f26a179bc796`.

## Entrega exclusiva

Pasta nova: `/workspace/work/WIN19-C6-R1-CORRECAO-20261123`, externa ao Git e às
candidatas. Sua inexistência foi conferida antes da criação, sem sobrescrita.

1. [contratos_c/relatorio.schema.json](contratos_c/relatorio.schema.json) — único
   contrato revisado; **20.837 bytes**, SHA-256 `079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e`.
2. [DIFF_C6_C6_R1.patch](DIFF_C6_C6_R1.patch) — diff exato; **224 bytes**,
   SHA-256 `7719bd9b038a5ee0d71a1ef82c7359dd080cf7579bf55cf7f106ea9db0b3f544`.
3. INDICE_ENTREGA_C6_R1.md — este registro de origem, conferência e limitações.
4. [MANIFESTO_SHA256_C6_R1](MANIFESTO_SHA256_C6_R1) — inventaria os três arquivos
   anteriores, com bytes/SHA-256; exclui apenas a si mesmo.

O hash do manifesto será informado na conversa. Não há autorreferência de hash.
C6-R1 identifica a entrega neste índice e no diff; a versão interna do schema
permaneceu literalmente preservada. Não houve atualização de versão no contrato.

## Localização e alteração única

Linha 38, antes da vírgula que sucede o fechamento da primeira condicional de
allOf. Inserção de **um byte ASCII `0x7D`**, caractere `}`, na coluna 8 (base um).
Deslocamento do byte inserido no arquivo revisado: **3112**, base zero.

```diff
-    }}},
+    }}}},
```

Não foram alterados nomes, enums, valores, ordem, espaços, referências, tipos,
cardinalidades, condicionais ou qualquer outro conteúdo. O diff entregue contém
somente a substituição textual dessa linha, representando a inserção de um byte,
com a linha 39 original como contexto. Não foi executada aplicação de patch sobre
qualquer entrega anterior.

## Demonstração byte a byte efetivamente executada

Seja O a sequência original de 20.836 bytes, R a sequência revisada de 20.837
bytes e p=3112. Comparações binárias executadas sobre os bytes gravados:

```text
R[p] = 0x7D
R[0:p] = O[0:p]                 (3112 bytes idênticos)
R[p+1:] = O[p:]                 (17724 bytes idênticos)
R[0:p] concatenado com R[p+1:] = O
```

A última igualdade foi observada byte a byte, não inferida apenas de hashes.
SHA-256 dos bytes obtidos pela remoção do byte inserido:
`ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6`,
igual ao original autenticado. A origem não foi regravada para essa conferência:
a remoção existiu somente como comparação de sequências em memória.

- Diferença de tamanho: exatamente **+1 byte**.
- Total de linhas antes/depois: **153/153**.
- LF antes/depois: **153/153**; CR: **0/0**.
- BOM UTF-8: ausente em ambos; bytes iniciais preservados; LF final preservado.
- Todas as linhas exceto a 38 permaneceram idênticas.
- Todo byte anterior e posterior à inserção permaneceu idêntico e na mesma ordem;
  a equivalência preserva a codificação existente, sem decodificar/reformatar o JSON.

## Preservação medida antes e depois

Manifestos anteriores e seus arquivos cobertos foram conferidos por tamanho/hash:
C6: sete registros e o próprio manifesto; C7: onze registros e o próprio manifesto.
As oito cópias C7 de C6 também corresponderam à identidade C6 antes e depois.
ZIP C7 preservado: 32.646 bytes, SHA-256
`f984a0406188323540f8f2cf28ded4a44ade800543ab143784dbc15e2aae1569`.
Manifesto C7 preservado:
`ca6195bf72e191599e5013b5e7d22b5f5e5ca6356e17d6a015d62d92e70471a2`.
Essas medições não representam nova validação dos contratos ou testes Windows.
C5, produto, R1-FIX de 470 arquivos, histórico e custódia privada não receberam
escrita, acesso de execução, limpeza ou alteração. Não houve nova medição Windows.

## Ferramentas, limites e pendências

Utilizados leitura binária, SHA-256, comparação de sequências/linhas, escrita
exclusiva no novo destino e redação dos documentos auxiliares. Python foi invocado
com `-I -B`, usando somente pathlib/hashlib para operações de bytes/arquivos,
sem json.loads, parser equivalente, jsonschema, módulos do conversor ou imports
do produto. A leitura dos manifestos foi exclusivamente de seus registros textuais
de integridade, não parsing ou avaliação de contratos JSON.

**Não houve parsing da revisão**, check_schema, Draft202012Validator, avaliação
de operadores JSON Schema, vetores, instâncias, sondas, pytest, API Windows/DACL,
runner C ou Categoria B. Não houve Git, nova worktree/candidata, instalação,
configuração, alteração de permissões, privilégios, contas, commit, push, merge,
publicação ou novo ZIP.

A identidade e a alteração única foram conferidas. A suficiência da correção e
a validade sintática/estrutural da revisão **não foram verificadas**. Podem existir
outros problemas; nenhuma correção adicional foi procurada ou aplicada. Parsing,
metaschema, referências, guardas, cardinalidade, nulidade e modelos de relatório
permanecem pendentes de auditoria e autorização específica da futura C7-R1.

## Estados preservados e parada

- C6 original: REPROVADO_ESTRUTURALMENTE no conjunto.
- C6-R1: MATERIALIZADO_AGUARDANDO_VALIDACAO.
- C7-R1: NAO_AUTORIZADO.
- Runner C: NÃO_IMPLEMENTADO; autorização de ensaios PENDENTE.
- WIN-01–WIN-19: NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE.
- T01/T06 ESPECIFICADO; T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL.
- DACL NÃO_VALIDADO; política D01–D10 PARA_APROVAÇÃO.
- C/D/E BLOQUEADOS; conversões reais BLOQUEADAS; prontidão para ensaios false.

Parar após esta entrega de quatro arquivos para auditoria independente. Não iniciar
C7-R1 nem considerar a alteração de bytes aprovação do schema ou de segurança.
