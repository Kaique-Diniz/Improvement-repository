# EXP-04-WIN-TEMP — validação e integridade

## Entrega

Candidata nova derivada da EXP-04-WIN de 460 hashes, sem modificar a origem,
EXP-04, D2, R1 ou pacotes auditados. Nenhum commit, push, PR, merge ou publicação.
Único arquivo preexistente alterado: `tools/exp04_win/executar.py`. Novos: auxiliar
de temporários, testes do executor e dois documentos. Produção, testes funcionais,
políticas, leitores, A1/B1, 30 colunas e bloqueios são idênticos em bytes à origem.

O incremento tem cinco arquivos; o diff cumulativo tem 45, para reconstrução a
partir do BPQ-04. Não confundir mudanças cumulativas antigas com esta revisão.
O diff incremental passou em `git apply --check` contra a EXP-04-WIN original,
sem aplicá-lo nela. O manifesto cobre toda a candidata de 464 arquivos.

## Mudança

`--basetemp` sai da árvore longa de evidências e passa ao filho t de um contêiner
curto exclusivo. Windows usa LocalAppData obtido do Shell, UUID por execução,
96 bits no nome e letra por escopo. Pastas preexistentes são recusadas. O caminho
Windows é limitado a 100 unidades UTF-16; não se muda configuração de LongPaths.

Identidade de diretório e marcador exclusivo comprovam a propriedade. O marcador
é lido pelo descritor original, sem reabrir um caminho substituível; Windows mantém
handles sem share-delete. Limpeza usa descritores/handles sem seguir links/reparse,
apenas dentro da árvore criada. O marcador é removido por último. Criação parcial
não permite recursão em cwd ou descritor ausente. Falhas de limpeza/fechamento
são registradas, bloqueiam o resultado e não autorizam excluir arquivos de terceiros.

Logs, XML, relatório e matriz ficam no diretório original de evidências. Também
foi impedida a escrita de erro.json numa pasta de evidências preexistente em
colisão. UTF-8, Python 3.12, integridade e códigos 0/2/3 são preservados.

Nenhuma rotina ativa privilégio de backup/restore: `FILE_FLAG_BACKUP_SEMANTICS`
serve para abrir diretórios e não concede privilégio ao token. Não há mudança
de DACL/política de execução nem integração dessas rotinas ao conversor.

## Execuções reais desta candidata

Linux/Python 3.12.14; `PYTHONUTF8=1` nos filhos; sem instalação de dependências.

| Escopo | Coletados | Aprovados | Falhas/erros | Ignorados | Estado |
|---|---:|---:|---:|---:|---|
| focados | 188 | 188 | 0 | 0 | APROVADO |
| seis | 649 | 649 | 0 | 0 | APROVADO |
| completa | 2842 | 2842 | 0 | 0 | APROVADO |
| complementares | 36 | 36 | 0 | 0 | APROVADO |
| nativos | 7 | 0 | 0 | 7 | NÃO_VALIDADO |
| adicionais_executor | 32 | 32 | 0 | 0 | APROVADO |

A integral inclui focados e seis: não somar essas contagens. Os 36 complementares
anteriores e os 32 casos novos são seleções separadas. O aviso conhecido é a
depreciação AnyIO/Starlette nas seleções com TestClient.

As duas rodadas finais conferiram 464 hashes antes/depois, com o mesmo SHA-256
de manifesto registrado nos relatórios. Todos os seis contêineres dessas rodadas
reais foram removidos sem erro e sua ausência foi conferida independentemente.
As falhas de limpeza intencionalmente injetadas nos testes produziram código 2,
preservaram evidências e não foram classificadas como sucesso do executor.

Os sete nativos foram ignorados em Linux por falta de Windows real. Isso não
nega os sete aprovados que o usuário informou na candidata anterior: são versões
e execuções distintas. Os novos handles/caminhos Windows permanecem NÃO_VALIDADO
até reexecução real. Planejamento/mocks não são prova nativa de limpeza ou DACL.

## Evidência Windows recebida e critérios seguintes

O usuário confirmou 460 hashes, sete nativos aprovados e DACL efetiva não validada.
Relatou 718 falhas na integral com ocorrências de FileNotFoundError/WinError 206.
Trocando só temporários por caminhos curtos obteve 184 aprovados + quatro skips
nos focados e 649 aprovados nos seis, sem alterar produção/testes. Não foi
fornecida uma integral aprovada após essa troca. Esses números são recebidos,
não execuções Windows deste trabalho, e não comprovam a causa de cada uma das
718 falhas individualmente.

Na próxima rodada Windows: 188 focados (quatro skips conhecidos), 649 regressões,
2.842 integral, 36 complementares e sete nativos; zero falhas como objetivo,
skips individualizados, hashes antes/depois e temporários REMOVIDOS. Os 32 novos
devem ser executados separadamente pelo lançador do pacote. Qualquer falha da
integral impede aprovar a correção. Falha de limpeza também é bloqueio explícito.

**Estado da correção Windows: NÃO_VALIDADO.** Não há execução Windows nesta
máquina Linux; a revisão está preparada para auditoria e próxima execução.
**DACL efetiva NÃO_VALIDADO; sem homologação Windows e sem conversão real dos
quatro novos condomínios.** Sete testes nativos ou integral verde isoladamente
não comprovam os controles essenciais de isolamento.
