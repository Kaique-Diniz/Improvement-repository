# EXP-04-WIN-TEMP — candidata local

Ler `RESULTADOS_FINAIS.md` e `payload/docs/EXP_04_WIN_TEMP_RELATORIO.md`.
Roteiro: `payload/docs/EXP_04_WIN_TEMP_WINDOWS.md`.

- `EXP04_WIN_PARA_TEMP.patch`: somente cinco arquivos desta revisão (executor,
  auxiliar de temporários, novos testes e dois documentos).
- `EXP04_WIN_TEMP.patch`: reconstrução completa BPQ-04 + EXP-04 + WIN + TEMP.
- `payload/`: todos os arquivos do diff completo, inclusive os não rastreados.
- `VERSAO_EXP04_WIN_TEMP_SHA256.json`: 464 hashes da candidata inteira.
- `VERSAO_EXP04_WIN_ORIGINAL_SHA256.json`: 460 hashes da candidata anterior.
- `BASELINE_SHA256.json`: 430 hashes do baseline 770d062d29c4361d6932592883df9339bb4089bc.
- `MANIFESTO_SHA256.json`: hashes de todo o pacote exceto o próprio manifesto.
- `reconstruir.py`: bootstrap derivado do anterior; só nomes de patch/manifesto
  são substituídos, conforme `DERIVACAO_RECONSTRUTOR.json`.
- `testar_executor.py`: rodada adicional dos 32 casos novos. Usa o executor em
  memória com seleção limitada; não altera fonte ou testes. Seu rótulo de saída
  `complementares` é uma rodada adicional, não substitui os 36 anteriores.
- `evidencias/principal/`: 188/649/2842/36/7 com logs/JUnit e relatório.
- `evidencias/adicionais_executor/`: 32 casos novos, com logs/JUnit e relatório.

Não aplicar em worktree existente. Reconstruir uma nova a partir do baseline e
conferir todos os hashes antes/depois, seguindo o roteiro. Não instalar dependências,
alterar DACL/políticas, elevar privilégios nem limpar E4-* com wildcard.

Temporários Windows: LocalAppData registrado/E4-<96 bits>-<escopo>/t. O filho t
é novo; contêiner e marcador pertencem ao executor. Logs permanecem em Evidencias.
Erro de propriedade/criação/limpeza é bloqueio com código 2; 3 em Windows mantém
segurança pendente mesmo sem falha de teste. Nunca forçar remoção para obter verde.

Este pacote é local, sem commit/push/PR/merge/publicação. Não substitui ZIPs
anteriores nem contém documentos privados ou tokens de propriedade reais.
**A correção Windows só pode ser aprovada após integral sem falhas; DACL efetiva
e homologação continuam NÃO_VALIDADO, e as quatro conversões reais BLOQUEADAS.**
