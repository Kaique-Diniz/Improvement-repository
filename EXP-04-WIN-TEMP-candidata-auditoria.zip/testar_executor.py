"""Rodada adicional dos 32 testes de temporários; não são os 36 complementares.

Reutiliza o mesmo executor/limpeza/integridade com seleção limitada em memória.
Nenhum arquivo da candidata é alterado. A candidata deve ter sido reconstruída
e conferida pelo procedimento auditado antes de executar este lançador.
"""
import argparse
import json
from pathlib import Path
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--candidata', type=Path, required=True)
    p.add_argument('--versao', type=Path, required=True)
    p.add_argument('--evidencias', type=Path, required=True)
    a = p.parse_args()
    if not a.candidata.is_absolute():
        print('{"estado":"FALHOU","codigo":"CANDIDATA_RELATIVA_RECUSADA"}')
        return 2
    sys.path.insert(0, str(a.candidata))
    from tools.exp04_win import executar
    executar.SCOPES = {'complementares': (['tools/exp04_win/test_temporarios.py'], 32)}
    print(json.dumps({'selecao': 'ADICIONAIS_EXECUTOR_TEMPORARIOS', 'coleta_esperada': 32,
                      'nao_substitui_complementares_36': True}))
    return executar.main(['--versao', str(a.versao), '--evidencias', str(a.evidencias),
                          '--escopo', 'complementares'])


if __name__ == '__main__':
    raise SystemExit(main())
