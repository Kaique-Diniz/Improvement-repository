# EXP-04-WIN-TEMP — revisão isolada do executor

## Escopo e preservação

Candidata derivada da EXP-04-WIN de 460 hashes, reconstruída em worktree nova no
baseline `770d062d29c4361d6932592883df9339bb4089bc`. A EXP-04, EXP-04-WIN, D2, R1,
pacotes publicados, worktrees e resultados anteriores são preservados. Não há
commit, push, PR, merge ou publicação nesta tarefa.

Somente `tools/exp04_win/executar.py` é alterado entre os arquivos preexistentes.
O novo auxiliar `temporarios.py` implementa criação/identidade/limpeza e
`test_temporarios.py` testa o executor. Nenhum arquivo de `src/`, teste funcional,
regra financeira/cadastral, A1/B1, contrato de 30 colunas ou bloqueio é alterado.
Os complementares originais continuam com 36 casos; os testes novos do executor
são uma seleção separada, fora dos 2.842 e dos 36.

## Evidência Windows fornecida pelo usuário

- EXP-04-WIN reconstruída: 460 hashes íntegros.
- Sete testes nativos aprovados; DACL efetiva continua NÃO_VALIDADO.
- Executor integral anterior: 718 falhas; log com
  `FileNotFoundError: [WinError 206]`.
- Trocando apenas os temporários por caminhos curtos: focados 184 aprovados,
  quatro skips e zero falhas; seis condomínios 649 aprovados, zero falhas;
  460 hashes íntegros, sem modificar produção ou testes.

Esses números são evidências recebidas, não execuções Windows deste executor.
Sem nodeids/tracebacks completos não se atribuem todas as 718 falhas à mesma
causa. A rodada integral Windows após esta revisão continua obrigatória; os
resultados parciais não autorizam declarar a correção aprovada.

## Temporários curtos e exclusivos

Antes: `<evidências>/<execução>/temp-<escopo>`.

Agora, em Windows:
`<LocalAppData>\E4-<24 hex do identificador da execução>-<letra do escopo>\t`.
As letras são `f` (focados), `s` (seis), `c` (completa), `e` (complementares) e
`n` (nativos). O identificador integral da execução é UUID4; 96 bits compõem o
nome curto e `mkdir` exclusivo recusa qualquer colisão. Não se reutilizam pastas
anteriores, mesmo que pareçam conter um marcador de outra execução.

O filho `t` é deliberado: pytest pode excluir/recriar seu `--basetemp`. O
contêiner pai, seu marcador aleatório e sua identidade permanecem sob controle
do executor, fora do alcance dessa recriação inicial. O filho não existe quando
é entregue ao pytest. Logs, XML, relatório e matriz continuam exclusivamente na
pasta original de evidências, com as mesmas convenções de nomes.

O caminho do basetemp Windows é limitado a **100 unidades UTF-16**. Isso deixa
orçamento para os nomes gerados pelo pytest; não é promessa universal para toda
profundidade/nome possível. Se a raiz do perfil for longa demais, o executor
bloqueia antes dos testes; não ativa LongPathsEnabled, não usa política global,
drive de terceiros, privilégios administrativos ou fallback silencioso.

LocalAppData é obtido por `SHGetKnownFolderPath`; variável de ambiente divergente
é recusada. Documents é obtido pela mesma API e não pode sobrepor a raiz escolhida.
Caminhos relativos, UNC/dispositivo no planejamento Windows, `..`, symlinks,
junctions/reparse em ancestrais, Git normal/danificado/bare e layout de candidata
nos ancestrais são recusados. A pasta nova não pode sobrepor candidata/evidências.
Em Linux usa `/tmp`, sem confiar em TMPDIR apontando para documentos privados.
Não há parâmetro público que redirecione os temporários para uma pasta arbitrária.

## Propriedade e limpeza

- Contêiner criado exclusivamente pelo executor, com identidade física
  `(st_dev, st_ino)` não zerada; marcador exclusivo com token aleatório, identidade,
  tamanho, conteúdo e link count conferidos. Ctime de APIs diferentes não é usado
  como identidade (compatível com a lição da REC-01-R1 no Python 3.12 Windows).
- POSIX: descritores de pai/raiz, `dir_fd`, `O_NOFOLLOW`, checagem de identidade
  antes de recursão e recusa de volume diferente. Symlinks e hardlinks são
  removidos apenas como entradas; seus destinos não são percorridos/alterados.
- Windows: handles de diretórios sem compartilhamento de delete, abertura com
  `FILE_FLAG_OPEN_REPARSE_POINT`, classificação nativa de reparse antes de
  enumerar e exclusão por handle com `FileDispositionInfo`. Reparse é excluído
  como entrada, nunca enumerado. Não há integração desse auxiliar à produção.
  O campo `FILE_DISPOSITION_INFO.DeleteFile` usa BOOLEAN de um byte, conforme o
  Windows SDK (`microsoft/win32metadata`, `WinBase.h`).
- Criação parcial: rollback apenas da pasta vazia ou do marcador comprovadamente
  criado por esta instância; nunca recursão com descritor ausente ou cwd implícito.
- Marcador/identidade divergente, acesso negado, handle não fechado, interrupção
  ou resíduo após fechamento bloqueiam a limpeza. Registros indicam falhas de
  criação e limpeza separadamente; erro nunca vira sucesso de testes.
- A limpeza é executada em `finally`, inclusive quando pytest falha, não gera
  JUnit ou não inicia. Pasta de evidências nunca é alvo. Colisão na própria pasta
  de evidências também não autoriza sobrescrever `erro.json` preexistente.
- Não há retry de uma árvore cuja limpeza falhou, nem varredura global de E4-*.
  Restos ficam para inspeção manual, com nome técnico e código no relatório.

O limite de propriedade é o contêiner criado para esta execução e seu conteúdo
temporário. Não se declara proteção contra administrador ou processo malicioso
com as mesmas credenciais que o executor. Ausência de travessia de links e
checagem de identidade não substituem DACL efetiva/isolamento entre contas.

## Status e códigos preservados

UTF-8 nos filhos (`PYTHONUTF8=1`, `PYTHONIOENCODING=utf-8`), Python 3.12,
`PYTHONDONTWRITEBYTECODE=1` e integridade antes/depois são preservados. Nenhuma
configuração financeira/de leitura é alterada para facilitar testes.

- 0: testes sem falhas em Linux; não é homologação Windows.
- 2: falha de teste, coleta, criação/limpeza ou outro bloqueio operacional.
- 3: testes sem falha no Windows, com segurança ainda não comprovada.

`temporarios` no JSON registra escopo, contêiner, estado, `codigo_criacao` e
`codigo_limpeza`, sem token ou caminho do perfil. Os caminhos temporários são
sanitizados também nos logs e nos campos XML decodificados, preservando XML válido.
As distinções APROVADO, FALHOU e NÃO_VALIDADO continuam as mesmas.

## Validação e pendências

Os testes sintéticos cobrem planejamento Windows curto, recusa de raízes longas,
unicidade, colisões, identidade/marcador, redirecionamentos, destinos protegidos,
links sem exclusão externa, criação parcial, falha do pytest, limpeza e fechamento,
evidências preservadas, códigos 0/2/3 e bloqueios de segurança.

Os resultados finais Linux, logs/JUnit e hashes estão no relatório do pacote.
Esta máquina é Linux: os novos caminhos/handles Windows exigem execução real
após auditoria. Não apresentar planejamento/mocks como validação nativa.

**Correção Windows: NÃO_VALIDADO até a suíte integral terminar sem falhas.**
**DACL efetiva, homologação Windows e conversões reais dos quatro perfis
permanecem bloqueadas.** Sete nativos aprovados na candidata anterior não removem
esse bloqueio nem substituem a revalidação desta versão.
