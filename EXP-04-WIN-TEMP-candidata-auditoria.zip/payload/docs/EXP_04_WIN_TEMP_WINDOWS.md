# EXP-04-WIN-TEMP — roteiro Windows após auditoria

Usar uma worktree nova. Não aplicar sobre a EXP-04, EXP-04-WIN de 460 hashes,
D2 ou R1 auditadas. Não exigir administrador, instalar dependências ou alterar
políticas/ACLs. Conferir SHA-256/CRC do pacote local e os hashes internos.

## Reconstrução isolada

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'EXP04-WIN-TEMP'
$Pacote = Join-Path $Root 'pacote'
$C = Join-Path $Root 'candidata'
$Repo = Join-Path $HOME 'Improvement-repository' # ajustar
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe' # ajustar
$Evidencias = Join-Path $Root 'Evidencias'
if (Test-Path -LiteralPath $C) { throw 'DESTINO_JA_EXISTE' }
New-Item -ItemType Directory -Path $Evidencias -Force | Out-Null
& git -c core.autocrlf=false -C $Repo worktree add --detach $C 770d062d29c4361d6932592883df9339bb4089bc
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_NAO_CRIADA' }
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_RECUSADA' }
```

`VERSAO_EXP04_WIN_TEMP_SHA256.json` cobre toda a candidata, incluindo auxiliares
e testes novos. `VERSAO_EXP04_WIN_ORIGINAL_SHA256.json` preserva os 460 hashes de
origem. O reconstrutor compara baseline e conteúdo, recusa extras/links e usa
`git apply --check` antes da aplicação. Uma tentativa parcialmente interrompida
deve ser preservada e substituída por outra worktree nova, sem sobrescrita.

## Rodada principal

```powershell
& $Python -B (Join-Path $C 'tools\exp04_win\executar.py') `
    --versao (Join-Path $Pacote 'VERSAO_EXP04_WIN_TEMP_SHA256.json') `
    --evidencias $Evidencias --escopo todos
$Codigo = $LASTEXITCODE
if ($Codigo -eq 2) { throw 'FALHA_DE_TESTE_OU_EXECUCAO_OU_LIMPEZA' }
if ($Codigo -eq 3) {
    Write-Host 'Testes sem falha; DACL efetiva NAO_VALIDADO; SEM_HOMOLOGACAO'
}
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'INTEGRIDADE_FINAL_DIVERGENTE' }
```

Os cinco escopos permanecem iguais. Esperar:

| Escopo | Coleta | Critério |
|---|---:|---|
| Focados EXP-04 | 188 | 184 aprovações e quatro skips conhecidos, sem falhas |
| Seis condomínios | 649 | Zero falhas |
| Integral | 2.842 | Zero falhas; todos os skips individualizados |
| Complementares anteriores | 36 | Sem alterar testes para obter aprovação |
| Nativos anteriores | 7 | Executar em Windows real; inventário não homologa DACL |

Se a integral ainda falhar, **não aprovar esta correção**. Registrar nodeids,
tracebacks e códigos seguros, incluindo possíveis falhas de criação/limpeza.
Não atribuir automaticamente qualquer falha restante a WinError 206.

Os diretórios usados pelo pytest são filhos `t` de contêineres exclusivos
`%LOCALAPPDATA%\E4-<24 hex>-<f|s|c|e|n>`. Não são criados sob Evidencias.
O filho não existe antes de iniciar pytest; o marcador pertence ao contêiner.
Não criar esses nomes manualmente, apagar por wildcard ou reutilizar sobras.
Root Shell/LOCALAPPDATA divergente, reparse, Git/candidata, sobreposição com
Documents ou orçamento acima de 100 unidades UTF-16 bloqueiam a execução.

O registro `temporarios` deve mostrar `REMOVIDO` em todos os escopos concluídos,
sem `codigo_limpeza`. Resíduo/acesso negado/handle não fechado deve produzir erro
e retorno 2, mantendo evidências. Não elevar privilégios, resetar ACLs ou forçar
remoção para ocultar o problema. A causa deve ser revisada no contexto da conta.

## Testes adicionais do executor

Os testes novos estão em `tools/exp04_win/test_temporarios.py`, separados dos 36
anteriores. Executá-los em diretório novo, curto, fora do Git; nunca apontar
`--basetemp` para uma pasta existente com dados. Eles usam somente sentinelas
fabricadas. O teste de padrão real cria/remove seu próprio E4-*; os demais
injetam raízes controladas para testar erro/colisão sem usar documentos privados.
Casos de links só podem ser ignorados quando sua criação realmente retorna 1314.
Planejamento/mocks de Windows executados em Linux não comprovam handles nativos.

Preferir primeiro revisar os logs Linux entregues; após a rodada principal,
usar o lançador adicional do pacote:

```powershell
& $Python -B (Join-Path $Pacote 'testar_executor.py') `
    --candidata $C --versao (Join-Path $Pacote 'VERSAO_EXP04_WIN_TEMP_SHA256.json') `
    --evidencias $Evidencias
if ($LASTEXITCODE -eq 2) { throw 'TESTES_DE_TEMPORARIOS_REPROVADOS_OU_BLOQUEADOS' }
```

Esse lançador seleciona apenas o novo arquivo de testes em memória, reutilizando
o executor e sua gestão segura de temporários. Não altera arquivos da candidata.
Seu relatório usa o rótulo `complementares`, mas contém somente os casos novos de
`test_temporarios.py`; é uma rodada adicional, **não os 36 complementares
originais** da rodada principal. Nodeids, coleta e distinção são explícitos.
Nenhum resultado muda o contrato funcional ou o estado de DACL.

Não usar `-ExecutionPolicy Bypass` para a sonda nativa. Se a política vigente a
bloquear, registrar o controle como não validado/falha operacional pertinente.
Compartilhar apenas os relatórios agregados e logs sanitizados; não incluir
perfil do usuário, marcador/token, documentos, credenciais ou arquivos privados.

**DACL efetiva permanece NÃO_VALIDADO. Sem homologação Windows ou conversão
real dos quatro condomínios enquanto os bloqueios não forem comprovadamente
resolvidos e aprovados em etapa própria.**
