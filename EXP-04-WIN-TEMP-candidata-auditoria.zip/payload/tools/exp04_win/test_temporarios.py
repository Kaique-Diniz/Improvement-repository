"""Somente fixtures fabricadas do executor; não modifica testes funcionais."""
from hashlib import sha256
import json
import ntpath
import os
from pathlib import Path
from types import SimpleNamespace
import uuid
import xml.etree.ElementTree as ET

import pytest

from tests.windows_support import criar_symlink
from tools.exp04_win import executar as ex
from tools.exp04_win import temporarios as tm

ID = '1234567890abcdef1234567890abcdef'


@pytest.fixture
def local(monkeypatch, tmp_path):
    root = tmp_path/'curtos'
    root.mkdir()
    monkeypatch.setattr(tm, '_raiz_padrao', lambda: (root, (tmp_path/'Documentos',)))
    # Estes testes aninham uma raiz fabricada sob o tmp_path do próprio pytest.
    # O limite real é verificado separadamente por planejamento e execução padrão.
    monkeypatch.setattr(tm, 'MAX_BASE_WINDOWS', 32700)
    return root


def test_planejamento_windows_curto_absoluto_sem_evidencias():
    root = r'C:\Users\PessoaFicticia\AppData\Local'
    base = tm.planejar_windows(root, ID, 'completa')
    assert base == ntpath.join(root, 'E4-'+ID[:24]+'-c', 't')
    assert ntpath.isabs(base) and len(base.encode('utf-16-le'))//2 <= 100
    assert 'execucao-' not in base and 'Evidencias' not in base


@pytest.mark.parametrize('root', ['relativo', 'C:relativo', r'\\servidor\privado',
                                  r'\\?\C:\privado', r'C:\area\..\Documentos'])
def test_planejamento_windows_recusa_caminho_inadequado(root):
    with pytest.raises(tm.ErroTemporario, match='TEMP_RAIZ_INVALIDA'):
        tm.planejar_windows(root, ID, 'focados')


def test_raiz_windows_longa_bloqueia_em_vez_de_aceitar_win206():
    with pytest.raises(tm.ErroTemporario, match='TEMP_CAMINHO_EXCEDE_ORCAMENTO'):
        tm.planejar_windows('C:\\'+'a'*100, ID, 'focados')


def test_padrao_real_do_sistema_cria_e_limpa():
    temp = tm.TemporarioCurto(uuid.uuid4().hex, 'focados', protegidos=(ex.ROOT,))
    try:
        base = temp.criar()
        assert base.is_absolute() and not base.exists()
        assert (base.parent/tm.MARCADOR).is_file()
        if os.name == 'nt':
            assert len(str(base).encode('utf-16-le'))//2 <= 100
        base.mkdir()
        (base/'sintetico.txt').write_bytes(b'SINTETICO')
    finally:
        temp.limpar()
    assert temp.registro['estado'] == 'REMOVIDO' and not temp.raiz.exists()


def test_unicidade_escopos_execucoes_e_filho_pytest_ausente(local):
    objects = [tm.TemporarioCurto(ID, s) for s in tm.ESCOPOS]
    objects.append(tm.TemporarioCurto(uuid.uuid4().hex, 'focados'))
    try:
        bases = [t.criar() for t in objects]
        assert len(set(bases)) == 6 and all(not b.exists() for b in bases)
        for b in bases:
            b.mkdir()
            (b/'arquivo').write_bytes(b'SINTETICO')
    finally:
        for t in objects:
            t.limpar()
    assert not list(local.iterdir())


@pytest.mark.parametrize('tipo', ['diretorio', 'arquivo', 'symlink'])
def test_destino_existente_nunca_e_reutilizado_ou_excluido(local, tmp_path, tipo):
    temp = tm.TemporarioCurto(ID, 'seis')
    target = local/temp.nome
    outside = tmp_path/'terceiro'
    outside.mkdir()
    (outside/'sentinela').write_bytes(b'NAO_EXCLUIR')
    if tipo == 'diretorio':
        target.mkdir()
        (target/'sentinela').write_bytes(b'NAO_EXCLUIR')
    elif tipo == 'arquivo':
        target.write_bytes(b'NAO_EXCLUIR')
    else:
        criar_symlink(target, outside, target_is_directory=True)
    try:
        with pytest.raises(tm.ErroTemporario, match='TEMP_DESTINO_EXISTENTE'):
            temp.criar()
    finally:
        temp.limpar()
    assert os.path.lexists(target) and (outside/'sentinela').read_bytes() == b'NAO_EXCLUIR'
    if tipo == 'diretorio':
        assert (target/'sentinela').read_bytes() == b'NAO_EXCLUIR'


def test_area_protegida_documentos_e_git_recusados(local, tmp_path, monkeypatch):
    for mode in ('candidata', 'documentos', 'git_danificado'):
        temp = tm.TemporarioCurto(ID, 'completa', protegidos=(local,) if mode == 'candidata' else ())
        if mode == 'documentos':
            monkeypatch.setattr(tm, '_raiz_padrao', lambda: (local, (local,)))
        else:
            monkeypatch.setattr(tm, '_raiz_padrao', lambda: (local, (tmp_path/'Documentos',)))
        if mode == 'git_danificado':
            (local/'.git').mkdir()
        try:
            with pytest.raises(tm.ErroTemporario):
                temp.criar()
        finally:
            temp.limpar()
        assert not (local/temp.nome).exists()


def test_pai_simbolico_nao_e_seguido(local, tmp_path, monkeypatch):
    link = tmp_path/'redirecionado'
    criar_symlink(link, local, target_is_directory=True)
    monkeypatch.setattr(tm, '_raiz_padrao', lambda: (link, (tmp_path/'Documentos',)))
    temp = tm.TemporarioCurto(ID, 'focados')
    try:
        with pytest.raises(tm.ErroTemporario):
            temp.criar()
    finally:
        temp.limpar()
    assert not list(local.iterdir())


def test_limpeza_remove_alias_sem_apagar_destino(local, tmp_path):
    outside = tmp_path/'externo'
    outside.mkdir()
    sentinel = outside/'sentinela'
    sentinel.write_bytes(b'NAO_APAGAR')
    t = tm.TemporarioCurto(ID, 'nativos')
    try:
        base = t.criar()
        base.mkdir()
        os.link(sentinel, base/'hardlink')
        criar_symlink(base/'link', outside, target_is_directory=True)
    finally:
        t.limpar()
    assert sentinel.read_bytes() == b'NAO_APAGAR' and not t.raiz.exists()


def test_marcador_alterado_impede_limpeza_recursiva(local):
    t = tm.TemporarioCurto(ID, 'focados')
    base = t.criar()
    base.mkdir()
    sentinel = base/'arquivo'
    sentinel.write_bytes(b'PRESERVAR')
    (t.raiz/tm.MARCADOR).write_bytes(b'ALTERADO')
    with pytest.raises(tm.ErroTemporario, match='TEMP_LIMPEZA_FALHOU'):
        t.limpar()
    assert sentinel.read_bytes() == b'PRESERVAR'
    assert t.registro['codigo_limpeza'] == 'TEMP_LIMPEZA_FALHOU'


def test_raiz_substituida_ou_bloqueada_nao_apaga_terceiros(local, tmp_path):
    t = tm.TemporarioCurto(ID, 'focados')
    t.criar()
    moved = local/'movido'
    if os.name == 'nt':
        try:
            with pytest.raises(OSError):
                t.raiz.rename(moved)
        finally:
            t.limpar()
    else:
        t.raiz.rename(moved)
        outside = tmp_path/'terceiro'
        outside.mkdir()
        (outside/'sentinela').write_bytes(b'PRESERVAR')
        t.raiz.symlink_to(outside, target_is_directory=True)
        with pytest.raises(tm.ErroTemporario):
            t.limpar()
        assert (outside/'sentinela').read_bytes() == b'PRESERVAR' and moved.exists()


def test_limpeza_repetida_nao_remove_novo_diretorio_de_terceiro(local):
    t = tm.TemporarioCurto(ID, 'focados')
    t.criar()
    t.limpar()
    t.raiz.mkdir()
    (t.raiz/'terceiro').write_bytes(b'PRESERVAR')
    t.limpar()
    assert (t.raiz/'terceiro').read_bytes() == b'PRESERVAR'


def test_descritor_ausente_nunca_utiliza_cwd(tmp_path):
    sentinel = tmp_path/'sentinela'
    sentinel.write_bytes(b'PRESERVAR')
    with pytest.raises(tm.ErroTemporario, match='TEMP_IDENTIDADE_INDISPONIVEL'):
        tm._remover_posix(None, 0)
    assert sentinel.read_bytes() == b'PRESERVAR'


@pytest.fixture
def executor(monkeypatch, tmp_path, local):
    cand, evidence = tmp_path/'candidata', tmp_path/'evidencias'
    cand.mkdir()
    evidence.mkdir()
    (cand/'.git').mkdir()
    (cand/'sentinela.txt').write_bytes(b'CANDIDATA_NAO_ALTERAR')
    h = cand/'tools/exp04_win/casos_historicos.json'
    h.parent.mkdir(parents=True)
    h.write_text('{"casos":[]}', encoding='utf-8')
    files = {p.relative_to(cand).as_posix():sha256(p.read_bytes()).hexdigest() for p in (h, cand/'sentinela.txt')}
    version = tmp_path/'versao.json'
    version.write_text(json.dumps({'baseline':ex.BASE, 'arquivos':files}), encoding='utf-8')
    monkeypatch.setattr(ex, 'ROOT', cand)
    monkeypatch.setattr(ex, 'SCOPES', {'focados': (['SINTETICO_NAO_EXECUTAR'], 1)})
    state = {'falha_pytest':False, 'erro_pytest':False, 'bases':[]}
    def run(cmd, **kwargs):
        if cmd[0] == 'git':
            return SimpleNamespace(returncode=0, stdout=(ex.BASE+'\n').encode())
        assert kwargs['env']['PYTHONUTF8'] == '1' and kwargs['env']['PYTHONIOENCODING'] == 'utf-8'
        base = Path(next(x.split('=',1)[1] for x in cmd if x.startswith('--basetemp=')))
        assert base.is_absolute() and not base.exists() and (base.parent/tm.MARCADOR).is_file()
        state['bases'].append(base)
        base.mkdir()
        (base/'temporario').write_bytes(b'SINTETICO')
        if state['erro_pytest']:
            raise OSError('CAMINHO_PRIVADO_NAO_IMPRIMIR')
        xml = Path(next(x.split('=',1)[1] for x in cmd if x.startswith('--junitxml=')))
        root = ET.Element('testsuites')
        suite = ET.SubElement(root,'testsuite')
        case = ET.SubElement(suite,'testcase',classname='sintetico',name='test_ficticio')
        if state['falha_pytest']:
            ET.SubElement(case,'failure',message='FALHA_SINTETICA')
        ET.ElementTree(root).write(xml,encoding='utf-8')
        return SimpleNamespace(returncode=int(state['falha_pytest']),stdout=str(base),stderr='')
    monkeypatch.setattr(ex.subprocess, 'run', run)
    state.update(args=['--versao',str(version),'--evidencias',str(evidence),'--escopo','focados'],
                 cand=cand,evidence=evidence,local=local,files=files)
    return state


def resultado(executor, file):
    return json.loads(next(executor['evidence'].glob('execucao-*/'+file)).read_text())


def test_executor_preserva_evidencia_integridade_e_bloqueios(executor, capsys):
    expected = 3 if os.name == 'nt' else 0
    assert ex.main(executor['args']) == expected
    j = resultado(executor,'relatorio.json')
    assert j['resultados']['focados']['aprovados'] == 1
    assert j['integridade_antes_depois'] is True and j['homologacao_windows_integral'] is False
    assert j['estado_seguranca_windows'] == 'NÃO_VALIDADO' and j['conversao_real_novos_perfis'] == 'BLOQUEADA'
    assert all(not p.parent.exists() for p in executor['bases'])
    assert j['temporarios'][0]['estado'] == 'REMOVIDO'
    assert next(executor['evidence'].glob('execucao-*/focados.xml')).exists()
    assert next(executor['evidence'].glob('execucao-*/focados.log')).exists()
    assert all(sha256((executor['cand']/n).read_bytes()).hexdigest() == h for n,h in executor['files'].items())
    assert str(executor['local']) not in next(executor['evidence'].glob('execucao-*/focados.log')).read_text()


def test_falha_pytest_mantem_evidencias_e_retorno_2(executor):
    executor['falha_pytest'] = True
    assert ex.main(executor['args']) == 2
    j = resultado(executor,'relatorio.json')
    assert j['resultados']['focados']['estado_testes'] == 'FALHOU'
    assert j['temporarios'][0]['estado'] == 'REMOVIDO'
    assert not executor['bases'][0].parent.exists()


def test_erro_pytest_ainda_limpa_e_registra_sem_expor(executor,capsys):
    executor['erro_pytest'] = True
    assert ex.main(executor['args']) == 2
    j = resultado(executor,'erro.json')
    assert j['integridade_final'] and j['temporarios'][0]['estado'] == 'REMOVIDO'
    assert not executor['bases'][0].parent.exists()
    assert 'CAMINHO_PRIVADO' not in capsys.readouterr().out


def test_erro_criacao_bloqueia_e_preserva_evidencias(executor,monkeypatch):
    original = Path.mkdir
    def negar(p,*args,**kwargs):
        if p.name.startswith('E4-'):
            raise PermissionError('NAO_EXIBIR')
        return original(p,*args,**kwargs)
    monkeypatch.setattr(Path,'mkdir',negar)
    assert ex.main(executor['args']) == 2
    j = resultado(executor,'erro.json')
    assert j['codigo'] == 'TEMP_CRIACAO_FALHOU' and j['integridade_final']
    assert not list(executor['local'].iterdir())


def test_erro_limpeza_nao_vira_sucesso(executor,monkeypatch):
    original = tm.TemporarioCurto._validar
    def falhar(t,**kwargs):
        if t._pronto:
            raise OSError('SENTINELA_PRIVADA_NAO_EXIBIR')
        return original(t,**kwargs)
    monkeypatch.setattr(tm.TemporarioCurto,'_validar',falhar)
    assert ex.main(executor['args']) == 2
    j = resultado(executor,'erro.json')
    assert j['codigo'] == 'TEMP_LIMPEZA_FALHOU'
    assert j['temporarios'][0]['codigo_limpeza'] == 'TEMP_LIMPEZA_FALHOU'
    assert executor['bases'][0].parent.exists()
    assert next(executor['evidence'].glob('execucao-*/focados.xml')).exists()


def test_rollback_de_criacao_sem_descritor_nao_remove_cwd(local,monkeypatch):
    original = os.open
    def negar(path,flags,*args,**kwargs):
        if str(path).startswith('E4-') and flags & getattr(os,'O_DIRECTORY',0):
            raise PermissionError('SINTETICO')
        return original(path,flags,*args,**kwargs)
    if os.name == 'nt':
        pytest.skip('CENARIO_DIR_FD_POSIX; nao comprova handles Windows')
    monkeypatch.setattr(tm.os,'open',negar)
    t = tm.TemporarioCurto(ID,'focados')
    with pytest.raises(tm.ErroTemporario):
        t.criar()
    t.limpar()
    assert t.registro['estado'] == 'REMOVIDO' and not t.raiz.exists()


def test_falha_criando_marcador_faz_rollback_so_da_pasta_propria(local,monkeypatch):
    original = os.open
    def negar(path,flags,*args,**kwargs):
        if Path(path).name == tm.MARCADOR:
            raise PermissionError('SINTETICO')
        return original(path,flags,*args,**kwargs)
    monkeypatch.setattr(tm.os,'open',negar)
    t = tm.TemporarioCurto(ID,'focados')
    with pytest.raises(tm.ErroTemporario,match='TEMP_CRIACAO_FALHOU'):
        t.criar()
    t.limpar()
    assert t.registro['estado'] == 'REMOVIDO' and not t.raiz.exists()
    assert t.registro['codigo_criacao'] == 'TEMP_CRIACAO_FALHOU'


def test_marcador_preinserido_nao_autoriza_limpeza_de_terceiro(local,monkeypatch):
    original = Path.mkdir
    def inserir(p,*a,**k):
        result = original(p,*a,**k)
        if p.name.startswith('E4-'):
            (p/tm.MARCADOR).write_bytes(b'ARQUIVO_DE_TERCEIRO')
        return result
    monkeypatch.setattr(Path,'mkdir',inserir)
    t = tm.TemporarioCurto(ID,'focados')
    with pytest.raises(tm.ErroTemporario):
        t.criar()
    with pytest.raises(tm.ErroTemporario,match='TEMP_LIMPEZA_FALHOU'):
        t.limpar()
    assert (t.raiz/tm.MARCADOR).read_bytes() == b'ARQUIVO_DE_TERCEIRO'


def test_colisao_evidencias_nao_sobrescreve_arquivo_preexistente(executor,monkeypatch):
    original = Path.mkdir
    def colidir(p,*a,**k):
        if p.name.startswith('execucao-'):
            original(p,*a,**k)
            (p/'erro.json').write_bytes(b'NAO_SOBRESCREVER')
            raise FileExistsError('COLISAO_SINTETICA')
        return original(p,*a,**k)
    monkeypatch.setattr(Path,'mkdir',colidir)
    assert ex.main(executor['args']) == 2
    assert next(executor['evidence'].glob('execucao-*/erro.json')).read_bytes() == b'NAO_SOBRESCREVER'
    assert not list(executor['local'].iterdir())


def test_codigos_windows_3_e_falha_2_preservados(executor,monkeypatch):
    # Simula somente a escolha do código de retorno; não é evidência Windows.
    monkeypatch.setattr(ex,'os',SimpleNamespace(name='nt',environ=os.environ,path=os.path,pathsep=os.pathsep))
    assert ex.main(executor['args']) == 3
    assert resultado(executor,'relatorio.json')['homologacao_windows_integral'] is False


def test_limpeza_windows_reparse_nao_enumera_destino(monkeypatch,tmp_path):
    class Pin:
        diretorio = True
        reparse = True
        apagado = False
        def apagar(self):
            self.apagado = True
    pin = Pin()
    def nao_enumerar(*a,**k):
        pytest.fail('Reparse nao pode ser percorrido')
    monkeypatch.setattr(tm.os,'scandir',nao_enumerar)
    tm._remover_win(tmp_path/'entrada_sintetica',pin)
    assert pin.apagado


def test_falha_fechando_handles_fica_registrada(local,monkeypatch):
    t = tm.TemporarioCurto(ID,'focados')
    t.criar()
    original = t._fechar
    def falhar():
        original()
        raise OSError('NAO_EXIBIR')
    monkeypatch.setattr(t,'_fechar',falhar)
    with pytest.raises(tm.ErroTemporario,match='TEMP_FECHAMENTO_HANDLE_FALHOU'):
        t.limpar()
    assert t.registro['estado'] == 'FALHOU'
    assert t.registro['codigo_limpeza'] == 'TEMP_FECHAMENTO_HANDLE_FALHOU'


def test_marcador_e_lido_pelo_descritor_original_sem_reabrir_caminho(local,monkeypatch):
    original = Path.read_bytes
    def nao_reabrir(p):
        if p.name == tm.MARCADOR:
            pytest.fail('Marcador nao pode ser reaberto pelo caminho')
        return original(p)
    monkeypatch.setattr(Path,'read_bytes',nao_reabrir)
    t = tm.TemporarioCurto(ID,'focados')
    t.criar()
    assert t._marker_fd is not None
    t.limpar()
    assert t.registro['estado'] == 'REMOVIDO' and t._marker_fd is None
