"""Temporários exclusivos; pytest nunca recebe um diretório preexistente.

Windows: LocalAppData registrado no Shell/E4-<96 bits>-<escopo>/t.
O contêiner guarda propriedade e identidade; pytest só pode recriar o filho t.
Nenhuma rotina segue symlink/junction durante a exclusão. Não certifica DACL.
"""
import ctypes
from ctypes import wintypes
import ntpath
import os
from pathlib import Path
import re
import secrets
import stat
import uuid

from tools.exp04.reconstruir import caminho

MAX_BASE_WINDOWS = 100  # unidades UTF-16; sobra orçamento para nomes dos testes
ESCOPOS = {'focados': 'f', 'seis': 's', 'completa': 'c', 'complementares': 'e', 'nativos': 'n'}
MARCADOR = '.e4-owner'


class ErroTemporario(Exception):
    """Somente códigos constantes; caminhos/tokens nunca chegam ao relatório."""


def _windows():
    return os.name == 'nt'


def _nome(identificador, escopo):
    if not re.fullmatch('[0-9a-f]{32}', identificador) or escopo not in ESCOPOS:
        raise ErroTemporario('TEMP_IDENTIFICADOR_INVALIDO')
    return 'E4-'+identificador[:24]+'-'+ESCOPOS[escopo]


def planejar_windows(raiz, identificador, escopo):
    """Planejamento puro; não cria pastas nem transforma relativo em absoluto."""
    drive, resto = ntpath.splitdrive(raiz)
    if (not re.fullmatch('[A-Za-z]:', drive) or not resto.startswith('\\')
            or any(p in ('.', '..') for p in re.split(r'[/\\]', resto))):
        raise ErroTemporario('TEMP_RAIZ_INVALIDA')
    base = ntpath.join(raiz, _nome(identificador, escopo), 't')
    if len(base.encode('utf-16-le', 'surrogatepass')) // 2 > MAX_BASE_WINDOWS:
        raise ErroTemporario('TEMP_CAMINHO_EXCEDE_ORCAMENTO')
    return base


def _pasta_registrada(identificador):
    class GUID(ctypes.Structure):
        _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD),
                    ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    ole = ctypes.WinDLL('ole32', use_last_error=True)
    shell.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD,
                                         wintypes.HANDLE, ctypes.POINTER(ctypes.c_void_p)]
    shell.SHGetKnownFolderPath.restype = ctypes.c_long
    ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    ole.CoTaskMemFree.restype = None
    guid = GUID.from_buffer_copy(uuid.UUID(identificador).bytes_le)
    ptr = ctypes.c_void_p()
    try:
        if shell.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(ptr)) != 0 or not ptr.value:
            raise ErroTemporario('TEMP_PASTA_REGISTRADA_INDISPONIVEL')
        return ctypes.wstring_at(ptr)
    finally:
        if ptr.value:
            ole.CoTaskMemFree(ptr)


def _raiz_padrao():
    if _windows():
        local = _pasta_registrada('f1b32785-6fba-4fcf-9d55-7b8e7f157091')
        docs = _pasta_registrada('fdd39ad0-238f-46af-adb4-6c85480369c7')
        env = os.environ.get('LOCALAPPDATA')
        if env and ntpath.normcase(ntpath.normpath(env)) != ntpath.normcase(ntpath.normpath(local)):
            raise ErroTemporario('TEMP_LOCALAPPDATA_DIVERGENTE')
        return Path(local), (Path(docs),)
    # Não confiar em TMPDIR que possa apontar para documentos/código privados.
    return Path('/tmp'), (Path.home()/'Documents', Path.home()/'Documentos')


def _fora_git(path):
    p = caminho(path, diretorio=True)
    for node in (p, *p.parents):
        if os.path.lexists(node/'.git') or sum(os.path.lexists(node/n) for n in ('HEAD', 'objects', 'refs', 'config')) >= 2:
            raise ErroTemporario('TEMP_DENTRO_GIT')
        if (node/'pyproject.toml').is_file() and (node/'src/conversor').is_dir():
            raise ErroTemporario('TEMP_DENTRO_CANDIDATA')
    return p


def _id(info):
    if (not isinstance(info.st_ino, int) or info.st_ino <= 0 or info.st_dev < 0
            or (_windows() and info.st_dev == 0)):
        raise ErroTemporario('TEMP_IDENTIDADE_INDISPONIVEL')
    return info.st_dev, info.st_ino


def _sobrepostos(a, b):
    return a.is_relative_to(b) or b.is_relative_to(a)


class _PinWin:
    """Abre a entrada sem seguir reparse, bloqueando rename/delete concorrente.

    Exclusão via handle (FileDispositionInfo), nunca percorrendo um redirecionamento.
    FILE_DISPOSITION_INFO.DeleteFile é BOOLEAN de um byte (Windows SDK WinBase.h).
    """
    def __init__(self, path, *, excluir=True):
        self.api = ctypes.WinDLL('kernel32', use_last_error=True)
        self.api.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        self.api.CreateFileW.restype = wintypes.HANDLE
        self.api.GetFileInformationByHandleEx.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.GetFileInformationByHandleEx.restype = wintypes.BOOL
        self.api.SetFileInformationByHandle.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.SetFileInformationByHandle.restype = wintypes.BOOL
        self.api.CloseHandle.argtypes = [wintypes.HANDLE]
        self.api.CloseHandle.restype = wintypes.BOOL
        self.handle = self.api.CreateFileW(str(path), 0x80 | (0x10000 if excluir else 0),
                                          3, None, 3, 0x02000000 | 0x00200000, None)
        if self.handle == wintypes.HANDLE(-1).value:
            self.handle = None
            raise ErroTemporario('TEMP_HANDLE_INDISPONIVEL')
        try:
            class Tag(ctypes.Structure):
                _fields_ = [('atributos', wintypes.DWORD), ('tag', wintypes.DWORD)]
            tag = Tag()
            if not self.api.GetFileInformationByHandleEx(self.handle, 9, ctypes.byref(tag), ctypes.sizeof(tag)):
                raise ErroTemporario('TEMP_METADADOS_INDISPONIVEIS')
            self.diretorio = bool(tag.atributos & 0x10)
            self.reparse = bool(tag.atributos & 0x400)
        except BaseException:
            self.fechar()
            raise

    def apagar(self):
        class Disposition(ctypes.Structure):
            _fields_ = [('apagar', ctypes.c_ubyte)]
        value = Disposition(1)
        if not self.api.SetFileInformationByHandle(self.handle, 4, ctypes.byref(value), ctypes.sizeof(value)):
            raise ErroTemporario('TEMP_EXCLUSAO_POR_HANDLE_FALHOU')

    def fechar(self):
        if self.handle is not None:
            handle, self.handle = self.handle, None
            if not self.api.CloseHandle(handle):
                raise ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')


def _remover_win(path, pin, *, raiz=False):
    if pin is None:
        raise ErroTemporario('TEMP_HANDLE_INDISPONIVEL')
    if pin.diretorio and not pin.reparse:
        with os.scandir(path) as it:
            names = sorted((e.name for e in it), key=lambda n: raiz and n == MARCADOR)
        for name in names:
            child = _PinWin(path/name)
            try:
                _remover_win(path/name, child)
            finally:
                child.fechar()
    # Reparse points são removidos como entradas, sem enumerar seu destino.
    pin.apagar()


def _remover_posix(fd, device, *, raiz=False):
    if not isinstance(fd, int) or fd < 0:
        raise ErroTemporario('TEMP_IDENTIDADE_INDISPONIVEL')
    with os.scandir(fd) as it:
        names = sorted((e.name for e in it), key=lambda n: raiz and n == MARCADOR)
    for name in names:
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if stat.S_ISDIR(info.st_mode):
            if info.st_dev != device:
                raise ErroTemporario('TEMP_VOLUME_REDIRECIONADO')
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            try:
                if _id(os.fstat(child)) != _id(info):
                    raise ErroTemporario('TEMP_ENTRADA_SUBSTITUIDA')
                _remover_posix(child, device)
            finally:
                os.close(child)
            if _id(os.stat(name, dir_fd=fd, follow_symlinks=False)) != _id(info):
                raise ErroTemporario('TEMP_ENTRADA_SUBSTITUIDA')
            os.rmdir(name, dir_fd=fd)
        else:
            os.unlink(name, dir_fd=fd)  # symlink/hardlink: remove apenas a entrada


class TemporarioCurto:
    def __init__(self, identificador, escopo, *, protegidos=()):
        self.nome = _nome(identificador, escopo)
        self.identificador, self.escopo = identificador, escopo
        self.protegidos = tuple(Path(p).absolute() for p in protegidos)
        self.raiz = self.base = None
        self._root_id = self._pai_id = self._marker_id = None
        self._parent_fd = self._root_fd = self._marker_fd = None
        self._parent_pin = self._root_pin = None
        self._criado = self._pronto = self._removido = False
        self._tentou_limpeza = False
        self._token = secrets.token_hex(32).encode('ascii')
        self.registro = {'escopo': escopo, 'container': self.nome, 'estado': 'NAO_CRIADO',
                         'codigo': None, 'codigo_criacao': None, 'codigo_limpeza': None}

    def criar(self):
        try:
            if self._criado or self._removido:
                raise ErroTemporario('TEMP_ESTADO_INVALIDO')
            root, docs = _raiz_padrao()
            if not root.is_absolute() or '..' in root.parts:
                raise ErroTemporario('TEMP_RAIZ_INVALIDA')
            root = _fora_git(root)
            self.raiz, self.base = root/self.nome, root/self.nome/'t'
            if any(_sobrepostos(self.raiz, p) for p in self.protegidos) or any(_sobrepostos(root, p.absolute()) for p in docs):
                raise ErroTemporario('TEMP_DESTINO_PROTEGIDO')
            if _windows():
                planejar_windows(str(root), self.identificador, self.escopo)
            self._pai_id = _id(root.lstat())
            if _windows():
                self._parent_pin = _PinWin(root, excluir=False)
                if self._parent_pin.reparse or not self._parent_pin.diretorio:
                    raise ErroTemporario('TEMP_RAIZ_REDIRECIONADA')
            else:
                self._parent_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                if _id(os.fstat(self._parent_fd)) != self._pai_id:
                    raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
            try:
                self.raiz.mkdir(mode=0o700)
            except FileExistsError:
                raise ErroTemporario('TEMP_DESTINO_EXISTENTE') from None
            self._criado = True
            self._root_id = _id(self.raiz.lstat())
            caminho(self.raiz, diretorio=True)
            if _windows():
                self._root_pin = _PinWin(self.raiz)
                if self._root_pin.reparse or not self._root_pin.diretorio:
                    raise ErroTemporario('TEMP_RAIZ_REDIRECIONADA')
            else:
                self._root_fd = os.open(self.nome, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=self._parent_fd)
                if _id(os.fstat(self._root_fd)) != self._root_id:
                    raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
            marker = self.raiz/MARCADOR
            fd = os.open(marker, os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            with os.fdopen(fd, 'wb') as f:
                self._marker_id = _id(os.fstat(f.fileno()))
                self._marker_fd = os.dup(f.fileno())
                f.write(self._token)
                f.flush()
                os.fsync(f.fileno())
            self._validar()
            self._pronto = True
            self.registro['estado'] = 'CRIADO'
            return self.base
        except ErroTemporario as exc:
            self.registro.update(estado='FALHOU', codigo=str(exc), codigo_criacao=str(exc))
            raise
        except Exception:
            self.registro.update(estado='FALHOU', codigo='TEMP_CRIACAO_FALHOU', codigo_criacao='TEMP_CRIACAO_FALHOU')
            raise ErroTemporario('TEMP_CRIACAO_FALHOU') from None

    def _validar(self, *, marcador=True):
        _fora_git(self.raiz.parent)
        caminho(self.raiz, diretorio=True)
        if _id(self.raiz.parent.lstat()) != self._pai_id or _id(self.raiz.lstat()) != self._root_id:
            raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
        if marcador:
            marker = caminho(self.raiz/MARCADOR)
            st = marker.lstat()
            if (_id(st) != self._marker_id or st.st_nlink != 1 or st.st_size != len(self._token)
                    or self._marker_fd is None or _id(os.fstat(self._marker_fd)) != self._marker_id):
                raise ErroTemporario('TEMP_PROPRIEDADE_NAO_COMPROVADA')
            # Ler o descritor original; nunca abrir de novo um caminho que outro
            # processo possa ter substituído por link entre lstat e leitura.
            os.lseek(self._marker_fd, 0, os.SEEK_SET)
            if os.read(self._marker_fd, len(self._token)+1) != self._token or _id(marker.lstat()) != self._marker_id:
                raise ErroTemporario('TEMP_PROPRIEDADE_NAO_COMPROVADA')

    def _fechar(self):
        error = None
        for name in ('_root_pin', '_parent_pin'):
            obj = getattr(self, name)
            setattr(self, name, None)
            if obj is not None:
                try:
                    obj.fechar()
                except Exception:
                    error = ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')
        for name in ('_marker_fd', '_root_fd', '_parent_fd'):
            fd = getattr(self, name)
            setattr(self, name, None)
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    error = ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')
        if error:
            raise error

    def limpar(self):
        if self._tentou_limpeza:
            if self._criado and not self._removido:
                raise ErroTemporario('TEMP_LIMPEZA_FALHOU')
            return
        self._tentou_limpeza = True
        error = None
        completed = False
        try:
            if self._removido or not self._criado:
                return
            self._validar(marcador=self._pronto)
            if not self._pronto:
                # Falha de criação: só remover pasta vazia/marker que criamos.
                names = [p.name for p in self.raiz.iterdir()]
                if names:
                    if names != [MARCADOR] or _id((self.raiz/MARCADOR).lstat()) != self._marker_id:
                        raise ErroTemporario('TEMP_PROPRIEDADE_NAO_COMPROVADA')
                elif (self._root_pin if _windows() else self._root_fd) is None:
                    # Sem handle de raiz: rollback somente da pasta vazia,
                    # nunca recursão usando cwd/default/um descritor ausente.
                    self.raiz.rmdir()
                    completed = True
                    return
            if self._marker_fd is not None:
                marker_fd, self._marker_fd = self._marker_fd, None
                os.close(marker_fd)
            if _windows():
                _remover_win(self.raiz, self._root_pin, raiz=True)
            else:
                _remover_posix(self._root_fd, self._root_id[0], raiz=True)
                if _id(os.stat(self.nome, dir_fd=self._parent_fd, follow_symlinks=False)) != self._root_id:
                    raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
                os.rmdir(self.nome, dir_fd=self._parent_fd)
            completed = True
        except KeyboardInterrupt:
            error = ErroTemporario('TEMP_LIMPEZA_INTERROMPIDA')
        except Exception:
            error = ErroTemporario('TEMP_LIMPEZA_FALHOU')
        finally:
            try:
                self._fechar()
            except Exception:
                error = ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')
            if completed and error is None:
                try:
                    self.raiz.lstat()
                except FileNotFoundError:
                    self._removido = True
                except OSError:
                    error = ErroTemporario('TEMP_LIMPEZA_FALHOU')
                else:
                    error = ErroTemporario('TEMP_LIMPEZA_FALHOU')
            if error:
                self.registro.update(estado='FALHOU', codigo=str(error), codigo_limpeza=str(error))
                raise error from None
            if self._removido:
                self.registro.update(estado='REMOVIDO', codigo=None)
