"""Lançador externo auditável: valida pacote/candidata e mantém escopos originais.

Só acrescenta seleções de testes em memória no processo pai. Filhos pytest
importam as constantes originais da candidata. Não instala nem modifica fontes.
"""
import argparse
import json
from pathlib import Path
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pacote', required=True, type=Path)
    p.add_argument('--candidata', required=True, type=Path)
    p.add_argument('--evidencias', required=True, type=Path)
    p.add_argument('--escopo', choices=('todos','focados','seis','completa','complementares','nativos','executor','cleanup'), default='todos')
    a = p.parse_args()
    try:
        if not all(x.is_absolute() for x in (a.pacote, a.candidata, a.evidencias)):
            raise ValueError()
        from reconstruir import executar as conferir
        conferir(a.pacote, a.candidata, True)
    except Exception:
        print('{"estado":"FALHOU","codigo":"PREFLIGHT_PACOTE_CANDIDATA_BLOQUEADO"}')
        return 2
    sys.path.insert(0, str(a.candidata))
    from tools.exp04_win import executar, temporarios
    executar.SCOPES.update({
        'executor': (['tools/exp04_win/test_temporarios.py'], 32),
        'cleanup': (['tools/exp04_win/test_cleanup_modelo.py',
                     'tools/exp04_win/test_cleanup_regressoes.py',
                     'tools/exp04_win/test_cleanup_windows.py'], 39),
    })
    temporarios.ESCOPOS.update({'executor': 'x', 'cleanup': 'l'})
    return executar.main(['--versao', str(a.pacote/'VERSAO_EXP04_WIN_TEMP_CLEANUP_SHA256.json'),
                          '--evidencias', str(a.evidencias), '--escopo', a.escopo])


if __name__ == '__main__':
    raise SystemExit(main())
