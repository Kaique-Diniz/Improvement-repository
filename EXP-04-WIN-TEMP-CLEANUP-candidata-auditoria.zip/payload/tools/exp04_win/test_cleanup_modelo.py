"""Modelo determinístico Win32, NÃO é evidência nativa Windows.

Modela sharing e delete-pending em arquivos fabricados no tmp_path. Não lê
LocalAppData nem contêineres preexistentes. Os erros são injetados explicitamente.
"""
import ctypes
import errno
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.exp04_win import temporarios as tm
from tools.exp04_win.diagnostico_cleanup import Diagnostico


class Funcao:
    def __init__(self, f):
        self.f = f

    def __call__(self, *a):
        return self.f(*a)


class KernelModelo:
    def __init__(self, monkeypatch):
        self.error = 0
        self.clock = 0.0
        self.handles = {}
        self.next_handle = 10
        self.pending = {}
        self.delay = 0.0
        self.never = False
        self.calls = []
        self.create_error = self.info_error = self.set_error = self.close_error = 0
        self.attributes_error = 0
        self.on_create = self.on_set = self.on_closed = None
        self.id_override = {}
        for name, method in (
            ('CreateFileW', self.create), ('GetFileInformationByHandleEx', self.info),
            ('SetFileInformationByHandle', self.set_info), ('CloseHandle', self.close),
            ('GetFileAttributesW', self.attributes),
        ):
            setattr(self, name, Funcao(method))
        monkeypatch.setattr(tm.ctypes, 'WinDLL', lambda *a, **k: self, raising=False)
        monkeypatch.setattr(tm.ctypes, 'get_last_error', lambda: self.error, raising=False)
        monkeypatch.setattr(tm, 'time', SimpleNamespace(monotonic=lambda: self.clock, sleep=self.sleep))

    def sleep(self, duration):
        self.clock += duration
        self.drain()

    def failed(self, error, result=0):
        self.error = error
        return result

    def create(self, path, access, share, security, disposition, flags, template):
        p = Path(path)
        self.calls.append(('CreateFileW', access, share, disposition, flags))
        if self.on_create:
            self.on_create(p, access)
        if self.create_error:
            return self.failed(self.create_error, ctypes.c_void_p(-1).value)
        try:
            info = p.lstat()
        except FileNotFoundError:
            return self.failed(2, ctypes.c_void_p(-1).value)
        # Modelo só precisa do componente DELETE da compatibilidade de sharing.
        for row in self.handles.values():
            if row['path'] == p and ((access & 0x10000 and not row['share'] & 4)
                                     or (row['access'] & 0x10000 and not share & 4)):
                return self.failed(32, ctypes.c_void_p(-1).value)
        h = self.next_handle
        self.next_handle += 1
        self.handles[h] = dict(path=p, access=access, share=share, id=info.st_ino,
                               directory=p.is_dir(), reparse=p.is_symlink())
        return h

    def info(self, handle, kind, ptr, size):
        if self.info_error:
            return self.failed(self.info_error)
        row = self.handles[handle]
        if kind == 9:
            assert size == 8
            value = ctypes.cast(ptr, ctypes.POINTER(tm._TagInfo)).contents
            value.atributos = (0x10 if row['directory'] else 0) | (0x400 if row['reparse'] else 0)
        elif kind == 18:
            assert size == 24
            value = ctypes.cast(ptr, ctypes.POINTER(tm._FileIdInfo)).contents
            value.volume = 1
            ident = self.id_override.get(row['path'], row['id'])
            value.file_id[:] = ident.to_bytes(16, 'little')
        else:
            raise AssertionError('classe fora do contrato')
        return 1

    def set_info(self, handle, kind, ptr, size):
        row = self.handles[handle]
        self.calls.append(('SetFileInformationByHandle', row['path']))
        assert kind == 4 and size == 1 and ctypes.cast(ptr, ctypes.POINTER(ctypes.c_ubyte))[0] == 1
        if self.on_set:
            self.on_set(row)
        if self.set_error:
            return self.failed(self.set_error)
        if row['directory'] and not row['reparse'] and any(row['path'].iterdir()):
            return self.failed(145)
        row['delete'] = True
        return 1

    def close(self, handle):
        row = self.handles.pop(handle)
        self.calls.append(('CloseHandle', handle))
        # Clobber para testar captura de GetLastError ANTES de fechar.
        self.error = 0
        if row.get('delete'):
            self.pending[row['path']] = (self.clock+self.delay, row)
            self.drain()
        if self.on_closed:
            self.on_closed(row)
        if self.close_error:
            return self.failed(self.close_error)
        return 1

    def drain(self):
        for p, (when, row) in list(self.pending.items()):
            if self.never or self.clock < when or any(r['path'] == p for r in self.handles.values()):
                continue
            if row['directory'] and not row['reparse']:
                p.rmdir()
            else:
                p.unlink()
            del self.pending[p]

    def attributes(self, path):
        self.calls.append(('GetFileAttributesW',))
        self.drain()
        if self.attributes_error:
            return self.failed(self.attributes_error, 0xFFFFFFFF)
        p = Path(path)
        if p in self.pending:
            return self.failed(5, 0xFFFFFFFF)
        if not os.path.lexists(p):
            return self.failed(2, 0xFFFFFFFF)
        return (0x10 if p.is_dir() else 0) | (0x400 if p.is_symlink() else 0)


@pytest.fixture
def modelo(monkeypatch):
    return KernelModelo(monkeypatch)


def limpar_arvore(root, diag=None):
    diag = diag or Diagnostico()
    diag.fase = 'limpeza'
    pin = tm._PinWin(root, diagnostico=diag)
    try:
        tm._remover_win(root, pin, raiz=True, diagnostico=diag)
        pin.fechar()
        tm._confirmar_ausencia_win(root, pin, diag, 0)
    finally:
        pin.fechar()
    return diag


def test_modelo_1500_irmaos_delete_pendente(modelo, tmp_path):
    root = tmp_path/'arvore'
    root.mkdir()
    for i in range(1500):
        (root/str(i)).mkdir()
    modelo.delay = 0.001
    # Orçamento total > soma dos atrasos fabricados; limite padrão é testado abaixo.
    # Cada exclusão fecha antes de consultar; o atraso fica dentro de 10s total.
    modelo.delay = 0.0001
    # Não usar sono: o relógio do modelo avança na consulta para liberar o pendente.
    original = modelo.GetFileAttributesW.f
    def tick(path):
        modelo.clock += 0.001
        return original(path)
    modelo.GetFileAttributesW.f = tick
    d = limpar_arvore(root)
    assert not root.exists() and not modelo.handles and not modelo.pending
    assert d.dados['contadores']['diretorios'] == 1501
    assert d.dados['contadores']['ausencias_confirmadas'] == 1501
    assert d.dados['primeira_falha'] is None
    pins = [c for c in modelo.calls if c[0] == 'CreateFileW' and c[1] & 0x10000]
    queries = [c for c in modelo.calls if c[0] == 'CreateFileW' and not c[1] & 0x10000]
    assert pins and all(c[2:] == (3, 3, 0x02200000) for c in pins)
    assert queries and all(c[1:] == (0x80, 7, 3, 0x02200000) for c in queries)


def test_modelo_multiplos_niveis_arquivos_e_delete_pendente(modelo, tmp_path):
    root = tmp_path/'arvore'
    (root/'a'/'b').mkdir(parents=True)
    for p in (root/'f', root/'a'/'f', root/'a'/'b'/'f'):
        p.write_bytes(b'SINTETICO')
    modelo.delay = 0.025
    d = limpar_arvore(root)
    assert not root.exists() and d.dados['contadores']['profundidade_maxima'] == 3
    assert d.dados['contadores']['esperas_pendentes'] > 0


def test_modelo_algoritmo_anterior_falha145_com_delete_pendente(modelo, tmp_path):
    # Reprodução mínima do encadeamento antigo: Set filho, Close, Set pai.
    root = tmp_path/'arvore'
    root.mkdir()
    child = root/'filho'
    child.mkdir()
    modelo.delay = 0.025
    d = Diagnostico()
    parent = tm._PinWin(root, diagnostico=d)
    leaf = tm._PinWin(child, diagnostico=d)
    try:
        leaf.apagar()
        leaf.fechar()
        with pytest.raises(tm.ErroTemporario):
            parent.apagar()
        assert d.dados['primeira_falha']['win32'] == 145
    finally:
        leaf.fechar()
        parent.fechar()
    # Isto prova o modelo; não identifica a causa do residual Windows do usuário.


@pytest.mark.parametrize('operation,error,api', [('create', 32, 'CreateFileW'),
    ('info', 87, 'GetFileInformationByHandleEx:Tag'),
    ('set', 5, 'SetFileInformationByHandle'), ('close', 6, 'CloseHandle')])
def test_modelo_erros_originais_capturados_antes_de_close(modelo, tmp_path, operation, error, api):
    p = tmp_path/'ARQUIVO_PRIVADO_NAO_EXIBIR'
    p.write_bytes(b'SINTETICO')
    d = Diagnostico()
    pin = None
    try:
        if operation in ('create', 'info'):
            setattr(modelo, operation+'_error', error)
            with pytest.raises(tm.ErroTemporario):
                tm._PinWin(p, diagnostico=d)
        else:
            pin = tm._PinWin(p, diagnostico=d)
            setattr(modelo, operation+'_error', error)
            with pytest.raises(tm.ErroTemporario):
                pin.apagar() if operation == 'set' else pin.fechar()
        first = d.dados['primeira_falha']
        assert first['win32'] == error and first['api'] == api
        assert 'ARQUIVO_PRIVADO' not in json.dumps(d.dados) and str(tmp_path) not in json.dumps(d.dados)
    finally:
        modelo.close_error = 0
        if pin:
            pin.fechar()
    assert not modelo.handles


def test_modelo_falha_primaria_nao_perdida_com_close_secundario(modelo, tmp_path):
    p = tmp_path/'f'
    p.write_bytes(b'X')
    d = Diagnostico()
    modelo.info_error = 87
    modelo.close_error = 6
    with pytest.raises(tm.ErroTemporario):
        tm._PinWin(p, diagnostico=d)
    assert d.dados['primeira_falha']['win32'] == 87
    assert d.dados['falhas_secundarias'][0]['win32'] == 6


@pytest.mark.parametrize('error', [5, 32, 303, 123])
def test_modelo_ausencia_nao_comprovada_falha_limitada(modelo, tmp_path, error):
    p = tmp_path/'f'
    p.write_bytes(b'X')
    d = Diagnostico()
    pin = tm._PinWin(p, diagnostico=d)
    pin.apagar()
    pin.fechar()
    modelo.attributes_error = error
    with pytest.raises(tm.ErroTemporario):
        tm._confirmar_ausencia_win(p, pin, d, 0)
    assert d.dados['primeira_falha']['win32'] == error
    assert d.dados['contadores']['sondagens_ausencia'] <= 7
    assert modelo.clock <= 1
    assert len([c for c in modelo.calls if c[0] == 'SetFileInformationByHandle']) == 1


def test_modelo_orcamento_total_limita_esperas(modelo, tmp_path, monkeypatch):
    p = tmp_path/'f'
    p.write_bytes(b'X')
    d = Diagnostico()
    pin = tm._PinWin(p, diagnostico=d)
    pin.apagar()
    pin.fechar()
    modelo.attributes_error = 5
    monkeypatch.setattr(tm, 'ORCAMENTO_ESPERA_TOTAL', 0.015)
    with pytest.raises(tm.ErroTemporario, match='ORCAMENTO_ESPERA'):
        tm._confirmar_ausencia_win(p, pin, d, 0)
    assert modelo.clock <= 0.015001


def test_modelo_arquivo_substituido_entre_snapshot_e_pin_nao_apaga_terceiro(modelo, tmp_path):
    root = tmp_path/'arvore'
    root.mkdir()
    p = root/'entrada'
    p.write_bytes(b'INICIAL')
    kept = tmp_path/'inicial-preservado'
    replaced = False
    def replace(path, access):
        nonlocal replaced
        if path == p and access & 0x10000 and not replaced:
            replaced = True
            p.rename(kept)
            p.write_bytes(b'TERCEIRO')
    modelo.on_create = replace
    d = Diagnostico()
    with pytest.raises(tm.ErroTemporario, match='ENTRADA_SUBSTITUIDA'):
        limpar_arvore(root, d)
    assert p.read_bytes() == b'TERCEIRO' and kept.read_bytes() == b'INICIAL'
    assert not any(c[0] == 'SetFileInformationByHandle' for c in modelo.calls)


def test_modelo_identidade128_nao_truncada(modelo, tmp_path):
    root = tmp_path/'arvore'
    root.mkdir()
    p = root/'f'
    p.write_bytes(b'INICIAL')
    def alterar(path, access):
        if path == p and access & 0x10000:
            modelo.id_override[p] = p.lstat().st_ino+(1 << 100)
    modelo.on_create = alterar
    with pytest.raises(tm.ErroTemporario, match='ENTRADA_SUBSTITUIDA'):
        limpar_arvore(root)
    assert p.read_bytes() == b'INICIAL'


def test_modelo_nao_remove_substituto_criado_apos_close(modelo, tmp_path):
    p = tmp_path/'entrada'
    p.write_bytes(b'INICIAL')
    d = Diagnostico()
    pin = tm._PinWin(p, diagnostico=d)
    modelo.on_closed = lambda row: row['path'].write_bytes(b'TERCEIRO') if row.get('delete') else None
    pin.apagar()
    pin.fechar()
    with pytest.raises(tm.ErroTemporario):
        tm._confirmar_ausencia_win(p, pin, d, 0)
    assert p.read_bytes() == b'TERCEIRO'
    assert len([c for c in modelo.calls if c[0] == 'SetFileInformationByHandle']) == 1


def test_modelo_diretorio_nao_vazio_nao_reescaneia(modelo, tmp_path):
    root = tmp_path/'arvore'
    root.mkdir()
    def adicionar(row):
        if row['path'] == root:
            (root/'novo').write_bytes(b'TERCEIRO')
    modelo.on_set = adicionar
    d = Diagnostico()
    with pytest.raises(tm.ErroTemporario):
        limpar_arvore(root, d)
    assert d.dados['primeira_falha']['win32'] == 145
    assert (root/'novo').read_bytes() == b'TERCEIRO'


def test_modelo_interrupcao_fecha_handles_sem_continuar_remocao(modelo, tmp_path):
    root = tmp_path/'arvore'
    root.mkdir()
    (root/'f').write_bytes(b'X')
    modelo.on_set = lambda row: (_ for _ in ()).throw(KeyboardInterrupt())
    d = Diagnostico()
    with pytest.raises(KeyboardInterrupt):
        limpar_arvore(root, d)
    assert not modelo.handles and (root/'f').read_bytes() == b'X'
    assert d.dados['primeira_falha']['codigo'] == 'TEMP_LIMPEZA_INTERROMPIDA'


def test_modelo_pin_bloqueia_delete_query_nao_remove_protecao(modelo, tmp_path):
    p = tmp_path/'f'
    p.write_bytes(b'X')
    pin = tm._PinWin(p)
    try:
        with pytest.raises(tm.ErroTemporario):
            tm._PinWin(p)
        query = tm._PinWin(p, excluir=False, consulta=True)
        assert query.identidade == pin.identidade
        query.fechar()
        with pytest.raises(tm.ErroTemporario):
            tm._PinWin(p)
    finally:
        pin.fechar()


def test_diagnostico_oserror_nao_copia_mensagem_caminho_ou_token():
    d = Diagnostico()
    d.excecao('solicitar_exclusao', 'os.unlink',
        OSError(errno.EACCES, 'TOKEN_DOCUMENTO_PRIVADO', 'CAMINHO_PRIVADO'))
    assert d.dados['primeira_falha']['errno'] == errno.EACCES
    assert 'PRIVADO' not in json.dumps(d.dados)
    for _ in range(15):
        d.falhar('fechamento', 'CloseHandle', 'TEMP_FECHAMENTO_HANDLE_FALHOU', win32=6)
    assert len(d.dados['falhas_secundarias']) == 8 and d.dados['falhas_secundarias_omitidas'] == 7
