"""Estresse POSIX e checkpoints do executor, exclusivamente dados fabricados."""
import errno
import json
import os
from pathlib import Path
import uuid

import pytest

from tools.exp04_win import executar as ex
from tools.exp04_win import temporarios as tm
from tools.exp04_win.test_temporarios import local, executor, resultado


def test_estresse_real_1500_irmaos_e_multiplos_niveis(local):
    temp = tm.TemporarioCurto(uuid.uuid4().hex, 'completa')
    base = temp.criar()
    base.mkdir()
    for i in range(1500):
        p = base/str(i)
        p.mkdir()
        (p/'f').write_bytes(b'SINTETICO')
    (base/'a'/'b'/'c').mkdir(parents=True)
    (base/'a'/'b'/'c'/'f').write_bytes(b'SINTETICO')
    temp.limpar()
    assert temp.registro['estado'] == 'REMOVIDO' and not temp.raiz.exists()
    d = temp.registro['diagnostico']
    assert d['estado_final'] == 'REMOVIDO'
    assert d['contadores']['diretorios'] == 1505
    assert d['contadores']['arquivos'] == 1502  # inclui marcador exclusivo
    assert d['contadores']['profundidade_maxima'] >= 4


def test_erro_limpeza_preserva_relatorio_parcial_junit_e_diagnostico(executor, monkeypatch, capsys):
    original = tm.TemporarioCurto._validar
    def negar(temp, **kwargs):
        if temp._pronto:
            raise PermissionError(errno.EACCES, 'TOKEN_E_DOCUMENTO_PRIVADO', 'CAMINHO_PRIVADO')
        return original(temp, **kwargs)
    monkeypatch.setattr(tm.TemporarioCurto, '_validar', negar)
    assert ex.main(executor['args']) == 2
    report = resultado(executor, 'relatorio.json')
    assert report['parcial'] and report['codigo'] == 'TEMP_LIMPEZA_FALHOU'
    assert report['estado_execucao'] == 'FALHOU' and report['estado_testes'] == 'APROVADO'
    assert report['resultados']['focados']['aprovados'] == 1 and report['integridade_final']
    assert report['estado_seguranca_windows'] == 'NÃO_VALIDADO'
    assert not report['homologacao_windows_integral'] and report['conversao_real_novos_perfis'] == 'BLOQUEADA'
    diag = report['temporarios'][0]['diagnostico']
    assert diag['estado_final'] == 'FALHOU'
    assert diag['primeira_falha']['errno'] == errno.EACCES
    assert diag['primeira_falha']['etapa'] == 'validacao_propriedade'
    out = next(executor['evidence'].glob('execucao-*'))
    assert (out/'focados.xml').is_file() and (out/'focados.log').is_file()
    assert 'PRIVADO' not in json.dumps(report) and 'PRIVADO' not in capsys.readouterr().out
    assert executor['bases'][0].exists()  # falha não é ocultada pela remoção posterior


def test_checkpoint_existe_antes_de_iniciar_limpeza(executor, monkeypatch):
    original = tm.TemporarioCurto.limpar
    def observar(temp):
        report = resultado(executor, 'relatorio.json')
        assert report['parcial'] and report['estado_execucao'] == 'EM_ANDAMENTO'
        assert report['resultados']['focados']['coletados'] == 1
        assert next(executor['evidence'].glob('execucao-*/focados.xml')).exists()
        return original(temp)
    monkeypatch.setattr(tm.TemporarioCurto, 'limpar', observar)
    assert ex.main(executor['args']) == (3 if os.name == 'nt' else 0)
    assert not resultado(executor, 'relatorio.json')['parcial']


def test_falha_gravacao_final_preserva_checkpoint_e_sinaliza(executor, monkeypatch, capsys):
    original = ex._salvar_relatorio
    calls = 0
    def negar_final(*args):
        nonlocal calls
        calls += 1
        if calls > 1:
            raise OSError('CAMINHO_PRIVADO')
        return original(*args)
    monkeypatch.setattr(ex, '_salvar_relatorio', negar_final)
    assert ex.main(executor['args']) == 2
    assert resultado(executor, 'relatorio.json')['parcial']
    stdout = json.loads(capsys.readouterr().out)
    assert stdout['codigo_relatorio_parcial'] == 'GRAVACAO_RELATORIO_PARCIAL_FALHOU'
    assert 'PRIVADO' not in json.dumps(stdout)


@pytest.mark.skipif(os.name != 'posix', reason='INJECAO_POSIX; controle Windows NAO_VALIDADO')
def test_interrupcao_posix_gera_falha_publica_e_fecha_recursos(local, monkeypatch):
    temp = tm.TemporarioCurto(uuid.uuid4().hex, 'completa')
    temp.criar().mkdir()
    (temp.base/'f').write_bytes(b'PRESERVAR')
    original = tm._remover_posix
    def interromper(*a, **k):
        raise KeyboardInterrupt()
    monkeypatch.setattr(tm, '_remover_posix', interromper)
    with pytest.raises(tm.ErroTemporario, match='TEMP_LIMPEZA_FALHOU'):
        temp.limpar()
    assert temp._parent_fd is None and temp._root_fd is None and temp._marker_fd is None
    assert temp.registro['diagnostico']['primeira_falha']['codigo'] == 'TEMP_LIMPEZA_INTERROMPIDA'
    assert (temp.base/'f').read_bytes() == b'PRESERVAR'
    monkeypatch.setattr(tm, '_remover_posix', original)


@pytest.mark.skipif(os.name != 'posix', reason='INJECAO_POSIX; controle Windows NAO_VALIDADO')
def test_posix_errno_remocao_preservado_antes_fechamentos(local, monkeypatch):
    temp = tm.TemporarioCurto(uuid.uuid4().hex, 'completa')
    temp.criar().mkdir()
    (temp.base/'f').write_bytes(b'PRESERVAR')
    original = tm.os.unlink
    def negar(path, *a, **k):
        if str(path) == 'f':
            raise PermissionError(errno.EACCES, 'CONTEUDO_PRIVADO', 'CAMINHO_PRIVADO')
        return original(path, *a, **k)
    monkeypatch.setattr(tm.os, 'unlink', negar)
    with pytest.raises(tm.ErroTemporario):
        temp.limpar()
    d = temp.registro['diagnostico']['primeira_falha']
    assert d['errno'] == errno.EACCES and d['api'] == 'os.unlink' and d['categoria'] == 'arquivo'
    assert d['profundidade'] == 2 and 'PRIVADO' not in json.dumps(d)
