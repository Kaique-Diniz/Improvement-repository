"""Diagnóstico agregado e sanitizado: nunca nomes, caminhos ou mensagens de SO."""

CATEGORIAS = {'arquivo', 'diretorio', 'reparse', 'desconhecido'}
CONTADORES = ('enumerados', 'visitados', 'arquivos', 'diretorios', 'reparse',
              'aberturas', 'consultas_identidade', 'exclusoes_solicitadas',
              'fechamentos', 'ausencias_confirmadas', 'sondagens_ausencia',
              'esperas_pendentes', 'profundidade_maxima', 'falhas')


def numero(value):
    return value if type(value) is int and 0 <= value <= 0xFFFFFFFF else None


class Diagnostico:
    def __init__(self):
        self.fase = 'criacao'
        self.contexto = {'etapa': 'validacao', 'api': 'validar_propriedade',
                         'categoria': 'diretorio', 'profundidade': 0}
        self.dados = {'estado_final': 'NAO_INICIADO', 'primeira_falha': None,
                      'falhas_secundarias': [], 'falhas_secundarias_omitidas': 0,
                      'contadores': dict.fromkeys(CONTADORES, 0),
                      'share_pins': 0x3, 'share_consultas_somente_leitura': 0x7}

    def situar(self, etapa, api, categoria, profundidade):
        self.contexto = dict(etapa=etapa, api=api, categoria=categoria, profundidade=profundidade)

    def capturar(self, exc, codigo='TEMP_OPERACAO_FALHOU'):
        self.excecao(exc=exc, codigo=codigo, **self.contexto)

    def contar(self, campo, value=1):
        self.dados['contadores'][campo] += value

    def visitar(self, categoria, profundidade):
        self.contar('visitados')
        self.contar({'arquivo': 'arquivos', 'diretorio': 'diretorios', 'reparse': 'reparse'}[categoria])
        self.dados['contadores']['profundidade_maxima'] = max(
            profundidade, self.dados['contadores']['profundidade_maxima'])

    def falhar(self, etapa, api, codigo, *, categoria='desconhecido', profundidade=0,
               win32=None, errno=None):
        # Etapa/API/código só são constantes internas. Não aceitar str(exc).
        self.contar('falhas')
        evento = {'fase': self.fase, 'etapa': etapa, 'api': api, 'codigo': codigo,
                  'win32': numero(win32), 'errno': numero(errno),
                  'categoria': categoria if categoria in CATEGORIAS else 'desconhecido',
                  'profundidade': profundidade,
                  'contadores': dict(self.dados['contadores'])}
        if self.dados['primeira_falha'] is None:
            self.dados['primeira_falha'] = evento
        elif len(self.dados['falhas_secundarias']) < 8:
            self.dados['falhas_secundarias'].append(evento)
        else:
            self.dados['falhas_secundarias_omitidas'] += 1

    def excecao(self, etapa, api, exc, *, categoria='desconhecido', profundidade=0,
                codigo='TEMP_OPERACAO_FALHOU'):
        self.falhar(etapa, api, codigo, categoria=categoria, profundidade=profundidade,
                    win32=getattr(exc, 'winerror', None), errno=getattr(exc, 'errno', None))
