"""Temporários exclusivos; pytest nunca recebe um diretório preexistente.

Windows: LocalAppData registrado no Shell/E4-<96 bits>-<escopo>/t.
O contêiner guarda propriedade e identidade; pytest só pode recriar o filho t.
Nenhuma rotina segue symlink/junction durante a exclusão. Não certifica DACL.
"""
import ctypes
from ctypes import wintypes
import ntpath
import os
from pathlib import Path
import re
import secrets
import stat
import time
import uuid

from tools.exp04.reconstruir import caminho
from tools.exp04_win.diagnostico_cleanup import Diagnostico

MAX_BASE_WINDOWS = 100  # unidades UTF-16; sobra orçamento para nomes dos testes
ESCOPOS = {'focados': 'f', 'seis': 's', 'completa': 'c', 'complementares': 'e', 'nativos': 'n'}
MARCADOR = '.e4-owner'


class ErroTemporario(Exception):
    """Código público constante, com detalhe interno também constante."""
    def __init__(self, codigo, *, detalhe=None):
        self.codigo = codigo
        self.detalhe = detalhe
        super().__init__(codigo if detalhe is None else codigo+'; '+detalhe)


def _windows():
    return os.name == 'nt'


def _nome(identificador, escopo):
    if not re.fullmatch('[0-9a-f]{32}', identificador) or escopo not in ESCOPOS:
        raise ErroTemporario('TEMP_IDENTIFICADOR_INVALIDO')
    return 'E4-'+identificador[:24]+'-'+ESCOPOS[escopo]


def planejar_windows(raiz, identificador, escopo):
    """Planejamento puro; não cria pastas nem transforma relativo em absoluto."""
    drive, resto = ntpath.splitdrive(raiz)
    if (not re.fullmatch('[A-Za-z]:', drive) or not resto.startswith('\\')
            or any(p in ('.', '..') for p in re.split(r'[/\\]', resto))):
        raise ErroTemporario('TEMP_RAIZ_INVALIDA')
    base = ntpath.join(raiz, _nome(identificador, escopo), 't')
    if len(base.encode('utf-16-le', 'surrogatepass')) // 2 > MAX_BASE_WINDOWS:
        raise ErroTemporario('TEMP_CAMINHO_EXCEDE_ORCAMENTO')
    return base


def _pasta_registrada(identificador):
    class GUID(ctypes.Structure):
        _fields_ = [('a', wintypes.DWORD), ('b', wintypes.WORD),
                    ('c', wintypes.WORD), ('d', ctypes.c_ubyte * 8)]
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    ole = ctypes.WinDLL('ole32', use_last_error=True)
    shell.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD,
                                         wintypes.HANDLE, ctypes.POINTER(ctypes.c_void_p)]
    shell.SHGetKnownFolderPath.restype = ctypes.c_long
    ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
    ole.CoTaskMemFree.restype = None
    guid = GUID.from_buffer_copy(uuid.UUID(identificador).bytes_le)
    ptr = ctypes.c_void_p()
    try:
        if shell.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(ptr)) != 0 or not ptr.value:
            raise ErroTemporario('TEMP_PASTA_REGISTRADA_INDISPONIVEL')
        return ctypes.wstring_at(ptr)
    finally:
        if ptr.value:
            ole.CoTaskMemFree(ptr)


def _raiz_padrao():
    if _windows():
        local = _pasta_registrada('f1b32785-6fba-4fcf-9d55-7b8e7f157091')
        docs = _pasta_registrada('fdd39ad0-238f-46af-adb4-6c85480369c7')
        env = os.environ.get('LOCALAPPDATA')
        if env and ntpath.normcase(ntpath.normpath(env)) != ntpath.normcase(ntpath.normpath(local)):
            raise ErroTemporario('TEMP_LOCALAPPDATA_DIVERGENTE')
        return Path(local), (Path(docs),)
    # Não confiar em TMPDIR que possa apontar para documentos/código privados.
    return Path('/tmp'), (Path.home()/'Documents', Path.home()/'Documentos')


def _fora_git(path):
    p = caminho(path, diretorio=True)
    for node in (p, *p.parents):
        if os.path.lexists(node/'.git') or sum(os.path.lexists(node/n) for n in ('HEAD', 'objects', 'refs', 'config')) >= 2:
            raise ErroTemporario('TEMP_DENTRO_GIT')
        if (node/'pyproject.toml').is_file() and (node/'src/conversor').is_dir():
            raise ErroTemporario('TEMP_DENTRO_CANDIDATA')
    return p


def _id(info):
    if (not isinstance(info.st_ino, int) or info.st_ino <= 0 or info.st_dev < 0
            or (_windows() and info.st_dev == 0)):
        raise ErroTemporario('TEMP_IDENTIDADE_INDISPONIVEL')
    return info.st_dev, info.st_ino


def _sobrepostos(a, b):
    return a.is_relative_to(b) or b.is_relative_to(a)


class _TagInfo(ctypes.Structure):
    _fields_ = [('atributos', ctypes.c_uint32), ('tag', ctypes.c_uint32)]


class _FileIdInfo(ctypes.Structure):
    _fields_ = [('volume', ctypes.c_uint64), ('file_id', ctypes.c_ubyte * 16)]


def _categoria(pin):
    return 'reparse' if pin.reparse else 'diretorio' if pin.diretorio else 'arquivo'


class _PinWin:
    """Abre a entrada sem seguir reparse, bloqueando rename/delete concorrente.

    Exclusão via handle (FileDispositionInfo), nunca percorrendo um redirecionamento.
    FILE_DISPOSITION_INFO.DeleteFile é BOOLEAN de um byte (Windows SDK WinBase.h).
    """
    def __init__(self, path, *, excluir=True, consulta=False, diagnostico=None,
                 profundidade=0, categoria='desconhecido'):
        self.diagnostico = diagnostico if diagnostico is not None else Diagnostico()
        self.profundidade, self.categoria = profundidade, categoria
        if consulta and excluir:
            raise ErroTemporario('TEMP_CONSULTA_NAO_PODE_EXCLUIR')
        self.api = ctypes.WinDLL('kernel32', use_last_error=True)
        self.api.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                                        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
        self.api.CreateFileW.restype = wintypes.HANDLE
        self.api.GetFileInformationByHandleEx.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.GetFileInformationByHandleEx.restype = wintypes.BOOL
        self.api.SetFileInformationByHandle.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        self.api.SetFileInformationByHandle.restype = wintypes.BOOL
        self.api.CloseHandle.argtypes = [wintypes.HANDLE]
        self.api.CloseHandle.restype = wintypes.BOOL
        self.api.GetFileAttributesW.argtypes = [wintypes.LPCWSTR]
        self.api.GetFileAttributesW.restype = ctypes.c_uint32
        # 0x3 é mantido nos pins. 0x7 só na consulta READ_ATTRIBUTES, sem DELETE,
        # para poder observar uma entrada que já tenha um pin DELETE aberto.
        self.diagnostico.situar('abertura', 'CreateFileW', categoria, profundidade)
        self.handle = self.api.CreateFileW(str(path), 0x80 | (0x10000 if excluir else 0),
                                          7 if consulta else 3, None, 3,
                                          0x02000000 | 0x00200000, None)
        if self.handle in (None, wintypes.HANDLE(-1).value):
            error = ctypes.get_last_error()  # imediatamente; antes de fechar outro handle
            self.handle = None
            self._erro('abertura', 'CreateFileW', 'TEMP_HANDLE_INDISPONIVEL', error)
        self.diagnostico.contar('aberturas')
        try:
            tag = _TagInfo()
            self.diagnostico.situar('metadados', 'GetFileInformationByHandleEx:Tag', categoria, profundidade)
            if not self.api.GetFileInformationByHandleEx(self.handle, 9, ctypes.byref(tag), ctypes.sizeof(tag)):
                error = ctypes.get_last_error()
                self._erro('metadados', 'GetFileInformationByHandleEx:Tag', 'TEMP_METADADOS_INDISPONIVEIS', error)
            self.diretorio = bool(tag.atributos & 0x10)
            self.reparse = bool(tag.atributos & 0x400)
            self.categoria = _categoria(self)
            fid = _FileIdInfo()
            self.diagnostico.situar('identidade', 'GetFileInformationByHandleEx:FileId', self.categoria, profundidade)
            if not self.api.GetFileInformationByHandleEx(self.handle, 18, ctypes.byref(fid), ctypes.sizeof(fid)):
                error = ctypes.get_last_error()
                self._erro('identidade', 'GetFileInformationByHandleEx:FileId', 'TEMP_IDENTIDADE_INDISPONIVEL', error)
            self.identidade = (int(fid.volume), bytes(fid.file_id))
            self.diagnostico.contar('consultas_identidade')
            if not fid.volume or not any(fid.file_id):
                self._erro('identidade', 'GetFileInformationByHandleEx:FileId', 'TEMP_IDENTIDADE_INDISPONIVEL', None)
        except BaseException:
            try:
                self.fechar()
            except Exception:
                pass  # falha secundária já registrada; preservar o primeiro erro
            raise

    def _erro(self, etapa, api, codigo, error):
        self.diagnostico.falhar(etapa, api, codigo, win32=error,
                               categoria=self.categoria, profundidade=self.profundidade)
        raise ErroTemporario(codigo)

    def apagar(self):
        class Disposition(ctypes.Structure):
            _fields_ = [('apagar', ctypes.c_ubyte)]
        value = Disposition(1)
        self.diagnostico.situar('solicitar_exclusao', 'SetFileInformationByHandle', self.categoria, self.profundidade)
        if not self.api.SetFileInformationByHandle(self.handle, 4, ctypes.byref(value), ctypes.sizeof(value)):
            error = ctypes.get_last_error()
            self._erro('solicitar_exclusao', 'SetFileInformationByHandle', 'TEMP_EXCLUSAO_POR_HANDLE_FALHOU', error)
        self.diagnostico.contar('exclusoes_solicitadas')

    def fechar(self):
        if self.handle is not None:
            handle, self.handle = self.handle, None
            self.diagnostico.situar('fechamento', 'CloseHandle', self.categoria, self.profundidade)
            ok = self.api.CloseHandle(handle)
            error = ctypes.get_last_error() if not ok else None
            if not ok:
                self._erro('fechamento', 'CloseHandle', 'TEMP_FECHAMENTO_HANDLE_FALHOU', error)
            self.diagnostico.contar('fechamentos')


ESPERAS_AUSENCIA = (0, 0.01, 0.02, 0.04, 0.08, 0.16, 0.32)
LIMITE_AUSENCIA = 1.0
ORCAMENTO_ESPERA_TOTAL = 10.0


def _confirmar_ausencia_win(path, pin, diagnostico, profundidade):
    """Só leituras após Set+Close bem-sucedidos; nunca repetir uma exclusão."""
    deadline = time.monotonic()+LIMITE_AUSENCIA
    diagnostico.dados['limites_espera'] = {'sondagens_por_objeto': len(ESPERAS_AUSENCIA),
        'prazo_por_objeto_ms': int(LIMITE_AUSENCIA*1000),
        'orcamento_por_container_ms': int(ORCAMENTO_ESPERA_TOTAL*1000)}
    diagnostico.situar('confirmar_ausencia', 'GetFileAttributesW', pin.categoria, profundidade)
    last_error = None
    for attempt, delay in enumerate(ESPERAS_AUSENCIA):
        if attempt and time.monotonic() >= deadline:
            break
        if delay:
            used = getattr(diagnostico, '_espera_consumida', 0.0)
            remaining = ORCAMENTO_ESPERA_TOTAL-used
            if remaining <= 0:
                diagnostico.falhar('confirmar_ausencia', 'orcamento_espera', 'TEMP_ORCAMENTO_ESPERA_ESGOTADO',
                                   categoria=pin.categoria, profundidade=profundidade)
                raise ErroTemporario('TEMP_ORCAMENTO_ESPERA_ESGOTADO')
            duration = min(delay, remaining, max(0, deadline-time.monotonic()))
            start = time.monotonic()
            time.sleep(duration)
            diagnostico._espera_consumida = used+max(duration, time.monotonic()-start)
            diagnostico.dados['espera_consumida_ms'] = int(diagnostico._espera_consumida*1000)
            diagnostico.contar('esperas_pendentes')
        value = pin.api.GetFileAttributesW(str(path))
        error = ctypes.get_last_error() if value == 0xFFFFFFFF else None
        diagnostico.contar('sondagens_ausencia')
        if value == 0xFFFFFFFF and error in (2, 3):
            diagnostico.contar('ausencias_confirmadas')
            return
        last_error = error
        if value == 0xFFFFFFFF and error not in (5, 32, 303):
            diagnostico.falhar('confirmar_ausencia', 'GetFileAttributesW', 'TEMP_CONSULTA_AUSENCIA_FALHOU',
                               win32=error, categoria=pin.categoria, profundidade=profundidade)
            raise ErroTemporario('TEMP_CONSULTA_AUSENCIA_FALHOU')
    diagnostico.falhar('confirmar_ausencia', 'GetFileAttributesW', 'TEMP_EXCLUSAO_NAO_CONFIRMADA',
                       win32=last_error, categoria=pin.categoria, profundidade=profundidade)
    raise ErroTemporario('TEMP_EXCLUSAO_NAO_CONFIRMADA')


def _snapshot_win(path, diagnostico, profundidade):
    # OPEN_REPARSE_POINT também na consulta: identidade da entrada, não destino.
    pin = _PinWin(path, excluir=False, consulta=True, diagnostico=diagnostico, profundidade=profundidade)
    try:
        return pin.identidade, pin.categoria
    finally:
        pin.fechar()


def _remover_win(path, pin, *, raiz=False, diagnostico=None, profundidade=0):
    diag = diagnostico if diagnostico is not None else Diagnostico()
    if pin is None:
        raise ErroTemporario('TEMP_HANDLE_INDISPONIVEL')
    diag.visitar(_categoria(pin), profundidade)
    if pin.diretorio and not pin.reparse:
        diag.situar('enumeracao', 'os.scandir', 'diretorio', profundidade)
        try:
            with os.scandir(path) as it:
                names = sorted((e.name for e in it), key=lambda n: raiz and n == MARCADOR)
        except OSError as exc:
            diag.excecao('enumeracao', 'os.scandir', exc, categoria='diretorio', profundidade=profundidade)
            raise
        diag.contar('enumerados', len(names))
        entries = [(name, _snapshot_win(path/name, diag, profundidade+1)) for name in names]
        for name, (expected, category) in entries:
            child = _PinWin(path/name, diagnostico=diag, profundidade=profundidade+1, categoria=category)
            try:
                if child.identidade != expected:
                    diag.falhar('validacao_identidade', 'comparar_FileIdInfo', 'TEMP_ENTRADA_SUBSTITUIDA',
                                 categoria=category, profundidade=profundidade+1)
                    raise ErroTemporario('TEMP_ENTRADA_SUBSTITUIDA')
                _remover_win(path/name, child, diagnostico=diag, profundidade=profundidade+1)
            except BaseException as exc:
                if diag.dados['primeira_falha'] is None:
                    diag.capturar(exc, 'TEMP_LIMPEZA_INTERROMPIDA' if isinstance(exc, KeyboardInterrupt) else 'TEMP_PERCURSO_FALHOU')
                try:
                    child.fechar()
                except Exception:
                    pass  # preservar falha primária; CloseHandle já registrou a secundária
                raise
            else:
                child.fechar()
                _confirmar_ausencia_win(path/name, child, diag, profundidade+1)
    # Reparse points são removidos como entradas, sem enumerar seu destino.
    pin.apagar()


def _remover_posix(fd, device, *, raiz=False, diagnostico=None, profundidade=0):
    diag = diagnostico if diagnostico is not None else Diagnostico()
    try:
        return _remover_posix_impl(fd, device, raiz=raiz, diagnostico=diag, profundidade=profundidade)
    except BaseException as exc:
        if diag.dados['primeira_falha'] is None:
            diag.capturar(exc, 'TEMP_LIMPEZA_INTERROMPIDA' if isinstance(exc, KeyboardInterrupt) else 'TEMP_OPERACAO_FALHOU')
        raise


def _remover_posix_impl(fd, device, *, raiz=False, diagnostico=None, profundidade=0):
    diag = diagnostico if diagnostico is not None else Diagnostico()
    if not isinstance(fd, int) or fd < 0:
        raise ErroTemporario('TEMP_IDENTIDADE_INDISPONIVEL')
    diag.visitar('diretorio', profundidade)
    diag.situar('enumeracao', 'os.scandir', 'diretorio', profundidade)
    with os.scandir(fd) as it:
        names = sorted((e.name for e in it), key=lambda n: raiz and n == MARCADOR)
    diag.contar('enumerados', len(names))
    for name in names:
        diag.situar('metadados', 'os.stat', 'desconhecido', profundidade+1)
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if stat.S_ISDIR(info.st_mode):
            if info.st_dev != device:
                raise ErroTemporario('TEMP_VOLUME_REDIRECIONADO')
            diag.situar('abertura', 'os.open', 'diretorio', profundidade+1)
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            diag.contar('aberturas')
            try:
                diag.situar('validacao_identidade', 'os.fstat', 'diretorio', profundidade+1)
                if _id(os.fstat(child)) != _id(info):
                    raise ErroTemporario('TEMP_ENTRADA_SUBSTITUIDA')
                _remover_posix(child, device, diagnostico=diag, profundidade=profundidade+1)
            except BaseException as exc:
                if diag.dados['primeira_falha'] is None:
                    diag.capturar(exc, 'TEMP_LIMPEZA_INTERROMPIDA' if isinstance(exc, KeyboardInterrupt) else 'TEMP_OPERACAO_FALHOU')
                raise
            finally:
                diag.situar('fechamento', 'os.close', 'diretorio', profundidade+1)
                try:
                    os.close(child)
                except OSError as exc:
                    diag.capturar(exc, 'TEMP_FECHAMENTO_HANDLE_FALHOU')
                    raise
                diag.contar('fechamentos')
            diag.situar('validacao_identidade', 'os.stat', 'diretorio', profundidade+1)
            if _id(os.stat(name, dir_fd=fd, follow_symlinks=False)) != _id(info):
                raise ErroTemporario('TEMP_ENTRADA_SUBSTITUIDA')
            diag.situar('solicitar_exclusao', 'os.rmdir', 'diretorio', profundidade+1)
            os.rmdir(name, dir_fd=fd)
            diag.contar('exclusoes_solicitadas')
        else:
            cat = 'reparse' if stat.S_ISLNK(info.st_mode) else 'arquivo'
            diag.visitar(cat, profundidade+1)
            diag.situar('solicitar_exclusao', 'os.unlink', cat, profundidade+1)
            os.unlink(name, dir_fd=fd)  # symlink/hardlink: remove apenas a entrada
            diag.contar('exclusoes_solicitadas')


class TemporarioCurto:
    def __init__(self, identificador, escopo, *, protegidos=()):
        self.nome = _nome(identificador, escopo)
        self.identificador, self.escopo = identificador, escopo
        self.protegidos = tuple(Path(p).absolute() for p in protegidos)
        self.raiz = self.base = None
        self._root_id = self._pai_id = self._marker_id = None
        self._parent_fd = self._root_fd = self._marker_fd = None
        self._parent_pin = self._root_pin = None
        self._criado = self._pronto = self._removido = False
        self._tentou_limpeza = False
        self._diagnostico = Diagnostico()
        self._token = secrets.token_hex(32).encode('ascii')
        self.registro = {'escopo': escopo, 'container': self.nome, 'estado': 'NAO_CRIADO',
                         'codigo': None, 'codigo_criacao': None, 'codigo_limpeza': None,
                         'diagnostico': self._diagnostico.dados}

    def criar(self):
        try:
            if self._criado or self._removido:
                raise ErroTemporario('TEMP_ESTADO_INVALIDO')
            root, docs = _raiz_padrao()
            if not root.is_absolute() or '..' in root.parts:
                raise ErroTemporario('TEMP_RAIZ_INVALIDA')
            root = _fora_git(root)
            self.raiz, self.base = root/self.nome, root/self.nome/'t'
            if any(_sobrepostos(self.raiz, p) for p in self.protegidos) or any(_sobrepostos(root, p.absolute()) for p in docs):
                raise ErroTemporario('TEMP_DESTINO_PROTEGIDO')
            if _windows():
                planejar_windows(str(root), self.identificador, self.escopo)
            self._pai_id = _id(root.lstat())
            if _windows():
                self._parent_pin = _PinWin(root, excluir=False, diagnostico=self._diagnostico, categoria='diretorio')
                if self._parent_pin.reparse or not self._parent_pin.diretorio:
                    raise ErroTemporario('TEMP_RAIZ_REDIRECIONADA')
            else:
                self._parent_fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                if _id(os.fstat(self._parent_fd)) != self._pai_id:
                    raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
            try:
                self.raiz.mkdir(mode=0o700)
            except FileExistsError:
                raise ErroTemporario('TEMP_DESTINO_EXISTENTE') from None
            self._criado = True
            self._root_id = _id(self.raiz.lstat())
            caminho(self.raiz, diretorio=True)
            if _windows():
                self._root_pin = _PinWin(self.raiz, diagnostico=self._diagnostico, categoria='diretorio')
                if self._root_pin.reparse or not self._root_pin.diretorio:
                    raise ErroTemporario('TEMP_RAIZ_REDIRECIONADA')
            else:
                self._root_fd = os.open(self.nome, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=self._parent_fd)
                if _id(os.fstat(self._root_fd)) != self._root_id:
                    raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
            marker = self.raiz/MARCADOR
            fd = os.open(marker, os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            with os.fdopen(fd, 'wb') as f:
                self._marker_id = _id(os.fstat(f.fileno()))
                self._marker_fd = os.dup(f.fileno())
                f.write(self._token)
                f.flush()
                os.fsync(f.fileno())
            self._validar()
            self._pronto = True
            self.registro['estado'] = 'CRIADO'
            return self.base
        except ErroTemporario as exc:
            if self._diagnostico.dados['primeira_falha'] is None:
                self._diagnostico.capturar(exc, exc.codigo)
            self.registro.update(estado='FALHOU', codigo=str(exc), codigo_criacao=str(exc))
            raise
        except Exception as exc:
            if self._diagnostico.dados['primeira_falha'] is None:
                self._diagnostico.capturar(exc, 'TEMP_CRIACAO_FALHOU')
            self.registro.update(estado='FALHOU', codigo='TEMP_CRIACAO_FALHOU', codigo_criacao='TEMP_CRIACAO_FALHOU')
            raise ErroTemporario('TEMP_CRIACAO_FALHOU') from None

    def _validar(self, *, marcador=True):
        _fora_git(self.raiz.parent)
        caminho(self.raiz, diretorio=True)
        if _id(self.raiz.parent.lstat()) != self._pai_id or _id(self.raiz.lstat()) != self._root_id:
            raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
        if marcador:
            marker = caminho(self.raiz/MARCADOR)
            st = marker.lstat()
            if (_id(st) != self._marker_id or st.st_nlink != 1 or st.st_size != len(self._token)
                    or self._marker_fd is None or _id(os.fstat(self._marker_fd)) != self._marker_id):
                raise ErroTemporario('TEMP_PROPRIEDADE_NAO_COMPROVADA')
            # Ler o descritor original; nunca abrir de novo um caminho que outro
            # processo possa ter substituído por link entre lstat e leitura.
            os.lseek(self._marker_fd, 0, os.SEEK_SET)
            if os.read(self._marker_fd, len(self._token)+1) != self._token or _id(marker.lstat()) != self._marker_id:
                raise ErroTemporario('TEMP_PROPRIEDADE_NAO_COMPROVADA')

    def _fechar(self):
        error = None
        for name in ('_root_pin', '_parent_pin'):
            obj = getattr(self, name)
            setattr(self, name, None)
            if obj is not None:
                try:
                    obj.fechar()
                except Exception as exc:
                    if self._diagnostico.dados['primeira_falha'] is None:
                        self._diagnostico.excecao('fechamento', 'CloseHandle', exc,
                                                 categoria='diretorio', codigo='TEMP_FECHAMENTO_HANDLE_FALHOU')
                    error = ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')
        for name in ('_marker_fd', '_root_fd', '_parent_fd'):
            fd = getattr(self, name)
            setattr(self, name, None)
            if fd is not None:
                try:
                    os.close(fd)
                except OSError as exc:
                    self._diagnostico.excecao('fechamento', 'os.close', exc,
                        categoria='arquivo' if name == '_marker_fd' else 'diretorio',
                        codigo='TEMP_FECHAMENTO_HANDLE_FALHOU')
                    error = ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')
        if error:
            raise error

    def limpar(self):
        if self._tentou_limpeza:
            if self._criado and not self._removido:
                raise ErroTemporario('TEMP_LIMPEZA_FALHOU')
            return
        self._tentou_limpeza = True
        self._diagnostico.fase = 'limpeza'
        self._diagnostico.dados['estado_final'] = 'EM_ANDAMENTO'
        error = None
        completed = False
        try:
            if self._removido or not self._criado:
                return
            self._diagnostico.situar('validacao_propriedade', 'validar_propriedade', 'diretorio', 0)
            self._validar(marcador=self._pronto)
            if not self._pronto:
                # Falha de criação: só remover pasta vazia/marker que criamos.
                names = [p.name for p in self.raiz.iterdir()]
                if names:
                    if names != [MARCADOR] or _id((self.raiz/MARCADOR).lstat()) != self._marker_id:
                        raise ErroTemporario('TEMP_PROPRIEDADE_NAO_COMPROVADA')
                elif (self._root_pin if _windows() else self._root_fd) is None:
                    # Sem handle de raiz: rollback somente da pasta vazia,
                    # nunca recursão usando cwd/default/um descritor ausente.
                    self.raiz.rmdir()
                    completed = True
                    return
            if self._marker_fd is not None:
                marker_fd, self._marker_fd = self._marker_fd, None
                self._diagnostico.situar('fechamento', 'os.close', 'arquivo', 0)
                os.close(marker_fd)
            if _windows():
                _remover_win(self.raiz, self._root_pin, raiz=True, diagnostico=self._diagnostico)
                pin = self._root_pin
                pin.fechar()
                self._root_pin = None
                # O pin do pai permanece aberto durante a prova de ausência.
                _confirmar_ausencia_win(self.raiz, pin, self._diagnostico, 0)
            else:
                _remover_posix(self._root_fd, self._root_id[0], raiz=True, diagnostico=self._diagnostico)
                if _id(os.stat(self.nome, dir_fd=self._parent_fd, follow_symlinks=False)) != self._root_id:
                    raise ErroTemporario('TEMP_RAIZ_SUBSTITUIDA')
                self._diagnostico.situar('solicitar_exclusao', 'os.rmdir', 'diretorio', 0)
                os.rmdir(self.nome, dir_fd=self._parent_fd)
                self._diagnostico.contar('exclusoes_solicitadas')
            completed = True
        except KeyboardInterrupt:
            if self._diagnostico.dados['primeira_falha'] is None:
                self._diagnostico.capturar(KeyboardInterrupt(), 'TEMP_LIMPEZA_INTERROMPIDA')
            error = ErroTemporario('TEMP_LIMPEZA_INTERROMPIDA')
        except Exception as exc:
            if self._diagnostico.dados['primeira_falha'] is None:
                self._diagnostico.capturar(exc, exc.codigo if isinstance(exc, ErroTemporario) else 'TEMP_LIMPEZA_FALHOU')
            error = ErroTemporario('TEMP_LIMPEZA_FALHOU')
        finally:
            try:
                self._fechar()
            except Exception as exc:
                if self._diagnostico.dados['primeira_falha'] is None:
                    self._diagnostico.excecao('fechamento', 'fechar_recursos', exc,
                                             categoria='diretorio', codigo='TEMP_FECHAMENTO_HANDLE_FALHOU')
                if error is None:
                    error = ErroTemporario('TEMP_FECHAMENTO_HANDLE_FALHOU')
            if completed and error is None:
                try:
                    self.raiz.lstat()
                except FileNotFoundError:
                    self._removido = True
                except OSError as exc:
                    self._diagnostico.excecao('confirmar_ausencia', 'os.lstat', exc, categoria='diretorio')
                    error = ErroTemporario('TEMP_LIMPEZA_FALHOU')
                else:
                    self._diagnostico.falhar('confirmar_ausencia', 'os.lstat', 'TEMP_EXCLUSAO_NAO_CONFIRMADA', categoria='diretorio')
                    error = ErroTemporario('TEMP_LIMPEZA_FALHOU')
            if error:
                self._diagnostico.dados['estado_final'] = 'FALHOU'
                self.registro.update(estado='FALHOU', codigo='TEMP_LIMPEZA_FALHOU', codigo_limpeza=error.codigo)
                raise ErroTemporario('TEMP_LIMPEZA_FALHOU', detalhe=error.codigo if error.codigo != 'TEMP_LIMPEZA_FALHOU' else None) from None
            if self._removido:
                self._diagnostico.dados['estado_final'] = 'REMOVIDO'
                self.registro.update(estado='REMOVIDO', codigo=None)
            elif not self._criado:
                self._diagnostico.dados['estado_final'] = 'NAO_CRIADO'
