# EXP-04-WIN-TEMP-CLEANUP — reconstrução LF e validação Windows

Executar só após revisão. Windows real, Python 3.12, conta comum, sem alterar
políticas, privilégios ou DACL. Não usar nem limpar o residual da execução
anterior. Esta revisão não fornece recuperação do residual.

## Reconstrução em worktree NOVA

Baixar o pacote local que foi auditado e comparar seu SHA-256 com a entrega.
Extrair em pasta nova fora do Git. Substituir SOMENTE o caminho de `$Repo` por
um checkout já existente do repositório; `$Python` pode ser o executável 3.12
do venv já disponível. Não instalar dependências automaticamente.

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'E4-Cleanup'
$Pacote = Join-Path $Root 'pacote'
$C = Join-Path $Root 'candidata'
$Evidencias = Join-Path $Root 'resultados'
$Repo = Join-Path $HOME 'Conversor-MVP-BPQ04'
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe'
$Base = '770d062d29c4361d6932592883df9339bb4089bc'
if (Test-Path -LiteralPath $C) { throw 'DESTINO_CANDIDATA_JA_EXISTE' }
if (-not (Test-Path -LiteralPath $Pacote)) { throw 'PACOTE_AUSENTE' }
if (-not (Test-Path -LiteralPath $Python)) { throw 'PYTHON_AUSENTE' }
# O -c vale para esta operação, sem alterar configurações persistentes.
& git -c core.autocrlf=false -c core.eol=lf -C $Repo worktree add --detach $C $Base
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_NAO_CRIADA' }
$env:PYTHONUTF8 = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_BLOQUEADA' }
```

O reconstrutor verifica CRC/hashes indiretamente pelo manifesto de todos os
arquivos extraídos, recusa extras/links/reparse points, exige baseline/árvore
limpa e aplica patch completo. Conferir CRC do ZIP separadamente com ferramenta
de extração e usar o SHA-256 publicado para identificar o arquivo exato.
Nenhum arquivo preexistente divergente é sobrescrito silenciosamente. Não
repetir reconstrução após falha; preservar a tentativa para diagnóstico.
O manifesto da versão comprova bytes LF de TODOS os arquivos, não só HEAD.

## Executor e estresse novo

Criar `$Evidencias` fora de qualquer repositório/candidata/área de documentos
privados. O executor continua usando LocalAppData registrado no Shell para os
contêineres E4 novos, curtos e exclusivos. Não informar diretório temporário
manual, residual, documentos ou worktree como basetemp.

```powershell
New-Item -ItemType Directory -Path $Evidencias -Force | Out-Null
# Este lançador externo usa o executor auditado e apenas acrescenta escopos de
# testes sintéticos; não modifica a candidata nem os escopos funcionais originais.
& $Python -B (Join-Path $Pacote 'validar_cleanup.py') --pacote $Pacote --candidata $C --evidencias $Evidencias --escopo cleanup
$StatusCleanup = $LASTEXITCODE
if ($StatusCleanup -eq 2) { throw 'CLEANUP_FALHOU_VER_RELATORIO' }
if ($StatusCleanup -ne 3) { throw 'RETORNO_WINDOWS_INESPERADO' }
& $Python -B (Join-Path $Pacote 'validar_cleanup.py') --pacote $Pacote --candidata $C --evidencias $Evidencias --escopo todos
$StatusTodos = $LASTEXITCODE
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'HASH_FINAL_DIVERGENTE' }
if ($StatusTodos -eq 2) { throw 'EXECUCAO_FALHOU_VER_RELATORIO' }
if ($StatusTodos -ne 3) { throw 'RETORNO_WINDOWS_INESPERADO' }
```

`validar_cleanup.py --escopo cleanup` reúne 20 casos de modelo, seis regressões
e 13 nativos novos (39 coletados). Os dois casos POSIX novos ignorados no
Windows não comprovam DACL. `todos` também preserva os cinco escopos anteriores
e acrescenta `executor` (32 casos anteriores) e `cleanup` (39). A candidata
não contém estes lançadores externos nem seu próprio manifesto.

Retornos preservados: 0 execução de testes sem falhas em Linux; 2 falha,
coleta divergente, integridade ou limpeza não comprovada; 3 testes sem falhas
em Windows, SEM homologação de segurança. Um skip é NÃO_VALIDADO. Não interpretar
3 como autorização operacional. Não somar escopos sobrepostos como testes únicos.

## Conferência de evidências e contingência

Para cada execução nova, guardar relatorio.json, XML e logs, fora do Git.
Confirmar as quantidades originais: 188 focados, 649 seis, 2.842 completa,
36 complementares, sete nativos; executor antigo 32 e cleanup novo 39.
Comparar com a evidência anterior sem assumir que todos os skips se repetirão.
Examinar os motivos individuais; nunca marcar skip de symlink/POSIX como controle
nativo aprovado. DACL efetiva NÃO_VALIDADO, quatro perfis reais BLOQUEADOS.

Para contêineres novos com falha, NÃO apagar/reativar/renomear manualmente.
Preservar erro.json, relatorio.json parcial e JUnit. Enviar apenas o bloco
sanitizado temporarios[].diagnostico: primeira falha com fase/etapa/API,
Win32/errno, categoria, profundidade, contadores, limites de espera e estado.
O código público é TEMP_LIMPEZA_FALHOU e retorno 2 mesmo se pytest passou.
Caso a escrita de relatório falhe, o stdout contém código específico; o último
checkpoint já salvo permanece disponível, sujeito à disponibilidade do disco.
Amostras só sintéticas; não enviar nomes de arquivos, caminhos privados ou dados.

Os testes nativos de falha injetada aprovam o tratamento da falha, não a exclusão.
Os testes de árvore bem-sucedida devem comprovar ausência. A conta disponível
não comprova acesso efetivo de outro usuário. Uma execução favorável não remove
os bloqueios de segurança nem autoriza as conversões reais.
