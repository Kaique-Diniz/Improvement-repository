# EXP-04-WIN-TEMP-CLEANUP — diagnóstico e limites da candidata

## Escopo e preservação

Derivada integralmente da EXP-04-WIN-TEMP de 464 hashes, em worktree separada
e detached no baseline `770d062d29c4361d6932592883df9339bb4089bc`.
Só dois arquivos preexistentes foram alterados: `tools/exp04_win/temporarios.py`
e `tools/exp04_win/executar.py`. Os acréscimos são diagnóstico, testes sintéticos
e documentação. Nenhum arquivo de produção, teste funcional/histórico, dependência,
configuração, regra financeira ou cadastral foi alterado em relação à TEMP.
Não há commit, push, PR, merge ou publicação desta revisão.

As candidatas/pacotes anteriores e o ZIP histórico permanecem preservados.
O contêiner residual do usuário NÃO foi acessado. Esta entrega não contém um
procedimento de recuperação dele e não autoriza limpá-lo. Os testes só criam
árvores novas e fabricadas. Nunca usar o nome do residual como argumento.

## Evidências Windows recebidas do usuário, não executadas aqui

Na TEMP anterior: focados 184 aprovados/4 skips; seis perfis 649 aprovados;
completa 2.842 coletados, 2.824 aprovados/18 skips, zero falhas e erros;
464 hashes antes/depois; sete controles nativos anteriores aprovados;
executor adicional 28 aprovados/4 skips. Os 18 skips foram classificados pelo
usuário em 14 dependentes de symlinks e quatro de permissões POSIX.
Após os testes ocorreu `TEMP_LIMPEZA_FALHOU`; ficaram 1.434 diretórios diretamente
sob `t` no contêiner residual. Isso não identifica qual API falhou nem seu código.
DACL efetiva continua NÃO_VALIDADO. As conversões reais dos quatro novos
condomínios continuam BLOQUEADAS.

## Diagnóstico: o que está demonstrado

1. O código anterior descartava GetLastError e o contexto da primeira falha.
   Logo não é possível atribuir retroativamente a causa do residual a erro 145,
   sharing, atributos ou outra causa específica.
2. `SetFileInformationByHandle(FileDispositionInfo)` seguido de `CloseHandle`
   solicita exclusão; outro handle que compartilhe DELETE pode manter o objeto
   pendente até o último fechamento. O algoritmo anterior solicitava logo a
   exclusão do pai, sem confirmar a ausência do filho.
3. Um modelo determinístico de sharing/delete-pending reproduz erro 145 nesse
   encadeamento antigo. A rotina nova passa no mesmo modelo, com sondas de leitura
   limitadas. Isso demonstra o defeito do encadeamento no modelo, NÃO a causa-raiz
   do incidente Windows nem uma aprovação nativa da correção.
4. Antes, uma falha na limpeza após pytest podia deixar JUnit/log, mas impedir a
   geração de `relatorio.json`. Agora há checkpoint atômico ANTES da limpeza e
   relatório parcial atualizado na saída de falha, preservando os testes concluídos.

Hipóteses ainda pendentes no Windows real: exclusão pendente (145 no pai),
compartilhamento incompatível (32), readonly/acesso negado (5), objeto recém-criado,
falha de fechamento (6), software externo e latência do sistema de arquivos.
Não é feita classificação por suposição ou pela quantidade de diretórios restantes.

## Parâmetros Windows e fronteiras preservadas

Pins mantêm CreateFileW com `OPEN_EXISTING=3`,
`FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT = 0x02200000`,
READ_ATTRIBUTES e DELETE para objetos de exclusão; o pin do pai só tem
READ_ATTRIBUTES. O compartilhamento dos pins permanece **0x3**:
FILE_SHARE_READ | FILE_SHARE_WRITE, SEM FILE_SHARE_DELETE. Assim tentativas
concorrentes de rename/delete devem ser recusadas enquanto o pin está aberto.
A evidência nativa correspondente está preparada, ainda não executada aqui.

Novas consultas transitórias de identidade usam READ_ATTRIBUTES, SEM DELETE,
share **0x7**. Isso permite consultar uma entrada que tenha pin DELETE aberto;
a consulta não remove a restrição imposta pelo pin 0x3. São consultas sem seguir
reparse points. Não se ampliou o compartilhamento dos pins de exclusão.

Antes de abrir cada filho para exclusão, guarda-se FileIdInfo completo:
volume de 64 bits + identificador de 128 bits. Após abrir o pin exclusivo,
compara-se a identidade; divergência interrompe sem excluir o substituto.
Metadados indisponíveis/identidade nula falham fechados. Reparse points são
excluídos como entradas, sem enumerar destinos. O pin do pai fica aberto até
confirmar a ausência da raiz. Sem fallback para rmtree ou remoção por caminho.
O marcador de propriedade, sua leitura pelo descritor original e verificações
de identidade/área autorizada permanecem obrigatórios.

A área exclusiva é a fronteira de propriedade. Esta implementação não prova
que outro usuário não consiga criar objetos ali: isso exige evidência de DACL.
A comparação de identidade detecta troca entre snapshot e pin; não atribui
procedência a uma entrada introduzida ANTES do snapshot. Essa limitação não é
tratada como homologação de isolamento. Não há retentativa que persiga entradas
novas nem mudança de atributos/permissões para tornar a exclusão possível.

## Confirmação limitada de ausência

Somente após SetFileInformationByHandle E CloseHandle bem-sucedidos, consultar
GetFileAttributesW. Ausência exige ERROR_FILE_NOT_FOUND (2) ou PATH_NOT_FOUND (3).
ACCESS_DENIED (5), SHARING_VIOLATION (32) e DELETE_PENDING (303) NÃO comprovam
remoção. Outros erros interrompem imediatamente.

Máximo sete sondas por objeto, esperas de 0, 10, 20, 40, 80, 160, 320 ms;
prazo de agendamento de um segundo por objeto; orçamento acumulado de dez
segundos por contêiner. Inclui o tempo medido do sleep e não apenas o pedido.
São limites das esperas e sondas da aplicação, não timeouts compulsórios para
APIs Win32 síncronas ou para uma suspensão externa do processo.
Nunca repetir SetFileInformationByHandle, reabrir para excluir ou reenumerar
novas entradas durante a espera. Um substituto encontrado após Close é apenas
observado; não é apagado. Orçamento esgotado, objeto persistente ou erro bloqueiam
com `TEMP_LIMPEZA_FALHOU`, retorno público 2 e diagnóstico específico.

## Diagnóstico sanitizado e relatórios

`diagnostico_cleanup.py` mantém fase, etapa/API constantes, categoria, profundidade,
contadores agregados, primeira falha e até oito falhas secundárias (demais só
contadas). Captura GetLastError imediatamente após a API retornar falha,
antes de fechar handles. Não usa FormatMessage, str(exc), nomes de entradas,
caminhos completos, marcador secreto, conteúdo, documentos ou credenciais.
Registra limites/consumo de espera e estado final REMOVIDO/FALHOU/NAO_CRIADO.

`executar.py` preserva UTF-8/Python 3.12, manifesto antes/depois, local externo
de evidências, códigos 0/2/3, sete controles nativos e bloqueios de segurança.
O checkpoint usa arquivo exclusivo, flush/fsync e replace atômico no diretório
exclusivo de evidências. Se atualização posterior falhar, mantém checkpoint e
expõe GRAVACAO_RELATORIO_PARCIAL_FALHOU. Não promete gravar em disco indisponível.
Falha de limpeza conserva `resultados`, JUnit e logs sanitizados já escritos;
`estado_testes` pode ser APROVADO e `estado_execucao` FALHOU simultaneamente.
Isso não promove uma execução incompleta a sucesso.

## Cobertura entregue e execução

- Modelo Win32: 1.500 irmãos, níveis/arquivos, sharing, espera pendente,
  orçamento, erros Create/Info/Set/Close, erro primário e secundário, identidade
  completa, substituição antes do pin/depois do Close, não vazio e interrupção.
- Estresse real em Linux: 1.500 irmãos com arquivos e níveis, sem alterar testes
  funcionais; regressões de checkpoint/relatório parcial/erro de gravação e errno.
- Treze casos preparados para Windows real: 1.500 irmãos, arquivo aberto por
  outro processo com sharing 3/7, diretório não vazio, readonly, junction/symlink,
  interrupção, três injeções de API, substituição de entrada e pin contra rename.
  Injeções são identificadas como tal. Symlink sem privilégio só ignora o caso
  dependente; nenhuma concessão de privilégio ou alteração de DACL.

Resultados finais Linux, JUnit, contagens individuais de skips e prova de
reconstrução constam de RESULTADOS_FINAIS.md e dos manifestos externos do pacote.
Skips de testes nativos em Linux são NÃO_VALIDADO, nunca APROVADO. Os resultados
Windows da TEMP original não são atribuídos à candidata nova.

## Referências da API

- https://learn.microsoft.com/windows/win32/api/fileapi/nf-fileapi-createfilew
- https://learn.microsoft.com/windows/win32/api/fileapi/nf-fileapi-deletefilew
- https://learn.microsoft.com/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle
- https://learn.microsoft.com/windows/win32/api/winbase/ns-winbase-file_disposition_info
- https://learn.microsoft.com/windows/win32/api/winbase/ns-winbase-file_id_info

CreateFileW/DeleteFileW também foram conferidos no repositório público
MicrosoftDocs/sdk-api, arquivos sdk-api-src/content/fileapi/nf-fileapi-*.md.
BOOLEAN de FileDispositionInfo permanece um byte, conforme SDK; estruturas de
TagInfo e FileIdInfo têm larguras explícitas (8 e 24 bytes) testadas pelo modelo.

## Decisão de auditoria

Candidata para revisão e NOVA execução Windows em área isolada; não é correção
nativa homologada. Aprovação exige suíte integral concluída, relatorio.json,
remoção comprovada de cada contêiner novo ou falha 2 com diagnóstico específico,
hashes íntegros e nenhuma alteração de terceiros. Pendências de DACL e symlinks
sem privilégio devem continuar individualizadas. Não iniciar conversão real.
