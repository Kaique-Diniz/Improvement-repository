# EXP-04-WIN-TEMP-CLEANUP

Entrega LOCAL para revisao; nao executar Windows antes da auditoria.

- `RESULTADOS_FINAIS.md`: validacao executada e limites.
- `payload/docs/EXP_04_WIN_TEMP_CLEANUP_RELATORIO.md`: diagnostico e API/sharing.
- `payload/docs/EXP_04_WIN_TEMP_CLEANUP_WINDOWS.md`: reconstruir LF e executar em
  worktree Windows nova. Nenhuma alteracao persistente de configuracao Git.
- `EXP04_WIN_TEMP_PARA_CLEANUP.patch`: diff incremental COMPLETO (8 arquivos:
  dois alterados, seis novos), inclusive arquivos nao rastreados.
- `EXP04_WIN_TEMP_CLEANUP.patch`: diff cumulativo desde BPQ-04, para reconstruir
  sem depender dos arquivos de candidatas anteriores. Mudancas herdadas nao sao
  atribuiveis a esta tarefa: consultar INVENTARIO_INCREMENTAL.json.
- `payload/`: versao integral dos oito arquivos do delta incremental.
- `VERSAO_EXP04_WIN_TEMP_CLEANUP_SHA256.json`: 470 hashes da candidata.
- `VERSAO_EXP04_WIN_TEMP_ORIGINAL_SHA256.json`: 464 hashes anteriores preservados.
- `BASELINE_SHA256.json`: arvore limpa para reconstrucao sem sobrescrita silenciosa.
- `MANIFESTO_SHA256.json`: hashes de todos os membros do pacote, exceto ele proprio.
- `RECONSTRUCAO_CONFERIDA.json`, `PRESERVACAO_FINAL.json`, `ESTADO_GIT.txt`: controles.
- `evidencias/`: JUnit/logs sanitizados, relatorio integral Linux e prova parcial.
- `validar_cleanup.py`: lancador externo, acrescenta executor/cleanup em memoria,
  preservando fontes e escopos funcionais. Windows retorna 3 sem falhas, MAS
  seguranca permanece NÃO_VALIDADO. Erro/teste/limpeza bloqueada retorna 2.

Conferir SHA-256 do ZIP contra a entrega. O teste CRC foi realizado ao empacotar;
repetir na extracao. O reconstrutor opera nos arquivos ja extraidos, verificando
seus SHA-256; ele nao abre nem examina o ZIP diretamente. O manifesto nao inclui
seu proprio hash; a identidade do ZIP e fornecida fora dele.

Somente codigo, documentacao, fixtures fabricadas e metadados sanitizados foram
incluidos. Nenhum documento privado foi lido/incorporado. Nao incluir fontes
reais nas candidatas, pacotes, evidencias de pytest ou Git.

O residual anterior do usuario esta preservado e nao foi acessado. Nao executar
limpeza manual dele, nem usar caminhos de terceiros nos testes desta entrega.
Nao ha publicacao, commit, push, PR ou merge. Auditoria antes de executar Windows.
