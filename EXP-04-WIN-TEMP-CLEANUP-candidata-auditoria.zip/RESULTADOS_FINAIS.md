# EXP-04-WIN-TEMP-CLEANUP — entrega para auditoria

Candidata isolada, 470 hashes, baseline `770d062d29c4361d6932592883df9339bb4089bc`.
A suite completa abaixo e UMA execucao de 2.842 casos; as demais selecoes
sobrepoem-se parcialmente. Nao somar linhas como quantidade de testes unicos.
Python 3.12.14, Linux, UTF-8. Nenhum Windows real foi executado nesta tarefa.

| Escopo | Coletados | Aprovados | Falhas/erros | Skips |
|---|---:|---:|---:|---:|
| focados | 188 | 188 | 0 | 0 |
| seis | 649 | 649 | 0 | 0 |
| completa | 2842 | 2842 | 0 | 0 |
| complementares | 36 | 36 | 0 | 0 |
| nativos | 7 | 0 | 0 | 7 |
| executor | 32 | 32 | 0 | 0 |
| cleanup | 39 | 26 | 0 | 13 |

Executor Linux retornou 0. Relatorio final nao parcial, integridade antes/depois
comprovada, sete conteineres REMOVIDOS. Na limpeza da suite completa, os
contadores registram 5.229 diretorios e 13.066 arquivos percorridos em Linux.
O teste de estresse real com 1.500 irmaos/arquivos/niveis passou; o modelo Win32
com 1.500 irmaos tambem passou. Os JUnit identificam individualmente os casos.
Os sete nativos anteriores e os 13 novos foram ignorados por Windows ausente:
NÃO_VALIDADO, nao controles aprovados. Aviso conhecido do Starlette/AnyIO nos
escopos que carregam TestClient, preservado nos logs.

Prova adicional intencional de falha sintetica: uma funcao aprovada,
`evidencias/prova-checkpoint.xml`. O executor fabricado retornou 2 com
`TEMP_LIMPEZA_FALHOU`, erro original errno 13, relatorio parcial, testes concluidos
aprovados e JUnit/logs conservados. Os arquivos efetivamente produzidos estao
em `evidencias/prova-falha-sintetica/`; nao representam incidente Windows real.

Sintaxe em memoria: 295 arquivos Python. `pip check`: nenhuma dependencia
incompativel. Nenhuma instalacao. Hashes de producao, testes funcionais e
historicos identicos a TEMP. Nao foram relaxadas assercoes preexistentes.

Reconstrucao do patch completo em OUTRA worktree detached conferiu os mesmos
470 hashes. `git apply --check` do incremental passou sobre TEMP, somente leitura.
Nenhuma alteracao na candidata apos a suite. Todos os 20 checkouts/worktrees e
11 ZIPs anteriores conferidos, com refs/HEAD/estado Git/bytes preservados.

A causa-raiz do residual do usuario permanece NAO_COMPROVADA. O modelo demonstra
que excluir o pai antes da ausencia do filho pode falhar 145 quando ha exclusao
pendente. A mudanca aguarda somente leituras, com limites, sem repetir exclusao.
Pins continuam com share 0x3; consultas READ_ATTRIBUTES sem DELETE usam 0x7.
Identidade completa e comparada antes de excluir; nenhum reparse e percorrido.
Falhas preservam codigo publico TEMP_LIMPEZA_FALHOU e retorno 2.

Pendente: estresse Windows/PowerShell 5.1, novo ciclo completo no Windows,
confirmacao de remocao de todos os conteineres novos, analise de qualquer codigo
nativo observado, isolamento entre usuarios e DACL efetiva. Nao acessar o residual
antigo: nao ha procedimento de recuperacao autorizado nesta entrega.

DACL efetiva NÃO_VALIDADO. Conversoes reais dos quatro perfis BLOQUEADAS.
Nao ha homologacao Windows/de seguranca. Sem commit/push/PR/merge/publicacao.
