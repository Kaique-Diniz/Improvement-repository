# WIN-01-A — preparação para revisão

## Resultado e estado Git

Preparação reconstruída sobre o commit obrigatório `770d062d29c4361d6932592883df9339bb4089bc`, em `/workspace/work/win-01-a`, com HEAD destacado. O checkout inicial `/workspace/Improvement-repository` permanece limpo na branch `work`, HEAD `04f29ff5fc9124b988bd611d3d1b8d7224ae874f`. A ref BPQ-04 não foi modificada. Não houve commit, push, PR ou merge. Nenhum arquivo rastreado da base foi alterado; os arquivos da preparação são novos e não rastreados.

Artefatos da preparação anterior não foram recuperados do disco disponível. Foram recuperadas a base funcional dos seis perfis e a correção ACL por SHA do remoto; a correção foi preservada em patch, não aplicada. As instruções originais foram fornecidas pelo usuário durante esta tarefa e incorporadas à consolidação.

## Arquivos preparados

- `docs/WIN_01_INVENTARIO.md`: recuperação, cobertura, lacunas e mecanismos existentes na base.
- `docs/WIN_01_MATRIZ_EVIDENCIAS.md`: seis perfis, eixos de validação e estados formais; CSV em `docs/win_01_a/matriz_evidencias.csv` (48 linhas perfil/eixo).
- `docs/WIN_01_ROTEIRO_WINDOWS.md`: setup explícito, execução PowerShell, browser e conferência privada A/B.
- `docs/WIN_01_PREPARACAO.md`: este relatório.
- `docs/win_01_a/EVIDENCIAS_USUARIO.md`: resultados Windows e reconciliações relatados, sem atribuí-los a esta execução.
- `docs/win_01_a/escopos.json`: seleção integrada, nativa, completa e ACL.
- `docs/win_01_a/inventario_testes_base.json` e `inventario_testes.json`: SHA-256 e funções antes/depois dos complementos; não contam parametrizações como se fossem execução.
- `docs/win_01_a/manifesto_excel.exemplo.json`: configuração externa com referências relatadas de 09/11/2026; caminhos fictícios, sem dados pessoais.
- `docs/win_01_a/correcao_acl_recuperada.patch`: diff exato de 84ab546, sem aplicação.
- `tools/win01/validar.ps1` e `executar.py`: etapas rápida, nativa, completa e Excel, sem instalação implícita e com evidências fora do Git.
- `tools/win01/sonda_ntfs.ps1` e `sonda_caminhos.py`: leitura de ACL e sondas sintéticas de filesystem, links e nomes 8.3; não impõem política de segurança.
- `tools/win01/inventariar.py` e `verificar_sintaxe.py`: inventário sem sobrescrita e compilação em memória.
- `tools/win01/conferir_excel.py`: valida A/B, 30 colunas, cabeçalhos, tipos, fórmulas, duplicatas, contagens, totais/endereço quando informados, emitindo apenas agregados/hashes.
- `tests/win01/test_enderecos_integrados.py`: seis perfis com aplicação de endereço em todas as linhas A/B, invariância financeira, recarga por API e nova sessão sem herança de contexto.
- `tests/win01/test_conferencia_excel.py`: cinco casos de integridade da ferramenta (incluindo perda de duplicatas, valor alterado, endereço cadastral ausente, documento numérico, fórmula e cabeçalho divergente).
- `tests/win01/test_locks_processos.py`: exclusão mútua real entre processos do mesmo usuário, sem alegação de isolamento de outro usuário.

## Testes efetivamente executados nesta tarefa

Ambiente: **Linux, Python 3.12.14**, venv isolada `/workspace/work/win01a-venv`; dependências de `.[test,web]` instaladas explicitamente para esta preparação. Não foi instalada ferramenta PowerShell. Dependências transitivas registradas no pacote de evidências; um aviso Starlette/AnyIO de depreciação de BlockingPortal ocorreu nas suítes com TestClient.

| Verificação | Resultado |
|---|---|
| pip check | Nenhuma dependência quebrada |
| Coleta da base antes dos complementos | 2.654 testes coletados |
| Escopo integrado recuperado (seleção explícita em escopos.json, sem tests/win01 naquela rodada) | 761 passed, zero failed/skipped, 1 warning; 89,68 s |
| Complemento de endereços dos seis perfis | 6 passed, zero failed/skipped, 1 warning; 7,11 s |
| Suíte completa com complementos de endereço e conferência Excel | **2.665 passed, zero failed/skipped, 1 warning; 211,57 s** |
| Teste de lock acrescentado após a coleta da suíte completa | **1 passed**, zero failed/skipped; 0,57 s, rodada separada |
| Coleta final, incluindo lock | 2.666 casos; não confundir coleta com execução integral em uma única rodada |
| Sintaxe final | 274 arquivos Python compilados em memória, sem erro |
| Runner no Linux | Recusou execução com código 2 e mensagem exigindo Windows/Python 3.12; não criou diretório da rodada |
| Patch ACL | git apply --check aprovado; correção não aplicada |
| Git | Índice e arquivos rastreados sem diff; checkout inicial limpo; somente novos artefatos da preparação na worktree isolada |

Comando da suíte completa:

```text
/workspace/work/win01a-venv/bin/python -X utf8 -m pytest -q tests --tb=short -p no:cacheprovider --junitxml=/workspace/work/win01a-completa.xml
```

O teste de lock foi executado separadamente com os mesmos argumentos, selecionando `tests/win01/test_locks_processos.py` e outro JUnit. Não somar execuções sobrepostas como testes distintos. A suíte integral não foi repetida após adicionar o lock; ele não altera testes anteriores ou código de produção. Logs, JUnit, dependências e coleta estão no pacote para auditoria. A compilação e a recusa Linux não validam sintaxe ou execução PowerShell nativa.

## Evidências do usuário incorporadas

Aprovação rápida histórica; nativa 49/5/1; completa 2613/38/3 e 1 warning; direcionada UTF-8 106/0/2; bug CompareStringOrdinal e commit corretivo; reconciliação temporal +164/+6/+99 = 269, R$ 130.997,71; seis referências A/B para 09/11/2026 e total Beach Parque. Tudo identificado como fornecido pelo usuário. Não foram importados XLSX/PDF reais nem simuladas execuções anteriores.

## Pendências e riscos impeditivos da homologação

1. Executar/revisar os scripts em PowerShell Windows real. Não executados nesta recuperação; ausência de PowerShell no Linux foi confirmada. Sem confirmação nativa, NTFS, DACL efetiva, symlink/junction/8.3 e comportamento de permissões ficam sem aprovação.
2. A base mantém o bug ACL. Obter logs e nodeids das 38 falhas/3 skips e das cinco falhas nativas históricas; obter o comando direcionado antigo de 106 aprovações. Não presumir que todas as falhas sejam encoding ou a mesma API.
3. Testar/revisar no browser Windows os seis perfis, o clique real de recarga, downloads, descarte e encerramento. TestClient não comprova isolamento do SO ou proteção externa.
4. Conferir privadamente A/B com data e fontes idênticas às referências. O roteiro não inclui fontes reais. Conferência do total original esperado dos outros cinco perfis depende de evidência ainda não fornecida; a ferramenta não inventa esse valor. Manifesto declarado não autentica sozinho a proveniência da execução.
5. Não há prova integrada suficiente de política ACL efetiva, isolamento de outro usuário, recuperação após crash, limite de CPU/RSS do processo ou apagamento forense. Alguns controles de armazenamento testados pertencem a componentes legados, não a toda rota efêmera. Ausência desses controles não deve ser encoberta por sondas aprovadas.
6. Nomes curtos podem estar desabilitados e symlinks podem exigir permissões indisponíveis. Registrar BLOQUEADO sem elevação nem reconfiguração. Locks entre processos do mesmo usuário não provam isolamento contra outro usuário.
7. Endereço é efêmero por contrato; ADDR-01 permanece fora do escopo. Regras provisórias, retenções e valores originais foram preservados; sem autorização operacional.

## Transição proposta, sem iniciar WIN-01-C

Após revisão da preparação, abrir tarefa/branch própria para classificar e corrigir UTF-8, CompareStringOrdinal e demais falhas Windows, usando os nodeids/logs originais e esta base identificada. O patch recuperado pode orientar uma correção controlada nessa fase; não trazer a árvore inteira do commit de outra linha de histórico. Reexecutar os testes nativos e atualizar a matriz só com evidências correspondentes. Nenhuma correção WIN-01-C foi iniciada nesta tarefa.

A preparação é entregue para revisão. O MVP **não está declarado homologado nem autorizado para operação**.
