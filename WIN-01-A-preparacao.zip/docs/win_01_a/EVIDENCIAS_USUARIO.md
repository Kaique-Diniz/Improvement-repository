# Evidências fornecidas pelo usuário

Fonte: mensagem de recuperação WIN-01-A nesta conversa, recebida em 12/11/2026. São relatos de execução anterior em Windows real/Python 3.12, não testes executados nesta tarefa. Logs nativos, nodeids, hashes de entrada, datas exatas das rodadas e identificação completa do checkout executado não foram fornecidos nesta mensagem.

| ID | Evidência relatada | Limite |
|---|---|---|
| U-01 | Suíte completa: 2.613 passed, 38 failed, 3 skipped, 1 warning | Suíte com falhas; não homologada. As 38 falhas não foram classificadas individualmente nesta tarefa. |
| U-02 | Direcionado com `-X utf8`: 106 passed, 2 skipped, zero failed | Seleção/comando integral não informado; não presumir que seja o escopo integrado reconstruído. Não comprova aprovação da suíte completa. |
| U-03 | Falha nativa confirmada em CompareStringOrdinal de windows_acl_evidence.py | Correção informada em 84ab546cd32c2601345d659e6d7fff2d10b4a10d; objeto recuperado separadamente e patch preservado, ainda não aplicado. |
| U-04 | Passaredo: +164 lançamentos | Reconciliação histórica atribuída à mudança das datas de referência. |
| U-05 | Forest Hill: +6 lançamentos | Mesma atribuição; não recalculada nesta tarefa. |
| U-06 | Santa Mônica: +99 lançamentos | Mesma atribuição; não recalculada nesta tarefa. |

Soma aritmética: 164 + 6 + 99 = 269 lançamentos adicionais. Compatibilidade com a mudança das datas é evidência relatada pelo usuário; não constitui autorização para alterar regras nem prova independente de nova execução. Não copiar documentos reais para o Git para completar essas evidências.

## Complemento recebido com as instruções originais

Também fornecidos pelo usuário, sem reexecução nativa nesta tarefa:

- Etapa rápida histórica: aprovada (sem comando/log integral disponível).
- Etapa nativa histórica: 49 aprovados, 5 falhas, 1 ignorado. Não atribuir automaticamente as cinco falhas ao mesmo defeito sem seus nodeids.
- Passaredo: comparação de 07/10/2026 para 09/11/2026, +164 dívidas.
- Forest Hill: comparação de 07/10/2026 para 09/11/2026, +6 dívidas.
- Santa Mônica: comparação de 13/10/2026 para 09/11/2026, +99 dívidas.
- Total reconciliado relatado: 269 lançamentos adicionais e R$ 130.997,71 de valor original agregado. Segundo o usuário, a comparação dos XLSX mostrou compatibilidade com a mudança de datas e ausência de divergência financeira nos lançamentos históricos correspondentes. Não foi repetida nesta tarefa.

### Referências privadas de 09/11/2026

| Perfil | Elegíveis A | Linhas B | Adicionais B |
|---|---:|---:|---:|
| Passaredo | 2.318 | 2.479 | 161 |
| Forest Hill | 1.631 | 1.631 | 0 |
| Parque Santa Mônica | 2.437 | 2.638 | 201 |
| Vero Encanto | 445 | 604 | 159 |
| Itajubá | 3.784 | 3.784 | 0 |
| Terraço Beach Parque | 850 | 1.009 | 159 |

Beach Parque: R$ 603.477,71 de valor original agregado e contrato de 30 colunas, conforme referência fornecida. Estes números não são asserts sobre fixtures sintéticas nem resultado da suíte Linux. Usá-los apenas para conferência de saídas privadas com proveniência e data idênticas.
