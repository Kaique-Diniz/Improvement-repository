# WIN-01-A — matriz de evidências

Estados permitidos: `APROVADO`, `REPROVADO`, `BLOQUEADO`, `NAO_EXECUTADO`, `NAO_APLICAVEL`. O estado por perfil abaixo se refere à nova rodada Windows integrada, ainda não executada. Aprovação Linux não promove nenhum controle Windows. Relatos do usuário são identificados separadamente. A planilha CSV complementar detalha 48 combinações perfil/eixo.

| Condomínio / perfil | Administradora | Financeiro / cadastro | A / B / adicionais de referência | Estado Windows | Cobertura automatizada |
|---|---|---|---|---|---|
| Passaredo / passaredo | AUTO GESTÃO | XLSX / XLSX | 2318 / 2479 / 161 | NAO_EXECUTADO | tests/passaredo; tests/web/test_integrated_auto_gestao.py; tests/int02; tests/win01 |
| Forest Hill / forest_hill | AUTO GESTÃO | XLSX / XLSX | 1631 / 1631 / 0 | NAO_EXECUTADO | tests/passaredo/test_forest_hill.py; tests/web/test_integrated_auto_gestao.py; tests/int02; tests/win01 |
| Parque Santa Mônica / parque_santa_monica | OMA | XLSX / PDF | 2437 / 2638 / 201 | NAO_EXECUTADO | tests/oma; tests/int02; tests/win01 |
| Vero Encanto / vero_encanto | LELLO_2 | XLSX / PDF | 445 / 604 / 159 | NAO_EXECUTADO | tests/vero; tests/int02; tests/win01 |
| Itajubá / itajuba | BN PLANNER | PDF / XLSX | 3784 / 3784 / 0 | NAO_EXECUTADO | tests/itajuba; tests/int02; tests/win01 |
| Terraço Beach Parque / terraco_beach_parque | HABITACIONAL | XLSX / PDF | 850 / 1009 / 159 | NAO_EXECUTADO | tests/beach_parque; tests/int02; tests/win01 |

As contagens são referências privadas relatadas pelo usuário para **09/11/2026**; não são expectativas dos arquivos sintéticos. Beach Parque: R$ 603.477,71 agregado, referência relatada.

| Eixo | Evidência disponível | Estado / pendência nativa |
|---|---|---|
| Reconhecimento/identidade | tests/int02/test_integracao.py e integração AUTO GESTÃO; hashes, confirmação, estrutura, cruzamentos e nomes enganosos | NAO_EXECUTADO em Windows desta rodada; distinguir rejeição comprovada de identidade nova indeterminada |
| Modo A/elegibilidade | Testes dos seis leitores/domínios; limites >60 ou >30 e restrições documentais de cada perfil | NAO_EXECUTADO; não transformar regras provisórias em autorização operacional |
| Modo B/cadastro | tests/int02 e casos próprios, retenções sem excluir dívida; financeiro A/B preservado | NAO_EXECUTADO; conferir titular/pagador/locatário e ausência de documento |
| BPQ-04 | tests/beach_parque/test_identidade_individual.py: sobrenome com E (B02108 equivalente) e CPF na linha do pagador (A00007 equivalente) | NAO_EXECUTADO nativamente; casos sintéticos recuperados, sem copiar dados privados |
| Endereço | tests/win01/test_enderecos_integrados.py: seis perfis A/B, linhas financeiras/cadastrais e API de recarga; testes clássicos de isolamento | NAO_EXECUTADO no browser Windows; clique real, descarte e perda do contexto; ADDR-01 fora do escopo |
| Integridade financeira/XLSX | Contrato 30 colunas; ferramentas com comparação Counter A/B, contagens, originais, hashes e tipos | NAO_EXECUTADO sobre pares privados; totais não fornecidos não são inventados |
| Sessões/segurança funcional | tests/web/test_ephemeral.py e test_classic_local.py; isolamento, origem/Host, download e limites | NAO_EXECUTADO nativamente; HTTP local não prova bloqueio externo ou DACL |
| Descarte/temporários | Testes de erro, TTL, logout, encerramento e limpeza normal | NAO_EXECUTADO nativamente; recuperação após crash BLOQUEADO por ausência de implementação/evidência suficiente |
| NTFS/ACL | Sonda em diretório sintético, Get-Acl, links e 8.3; comparador de ACEs existente | NAO_EXECUTADO; leitura ACL não prova política efetiva; outro usuário/processo continua pendente |
| ACL conhecida na base | U-03: falha nativa CompareStringOrdinal relatada; chamada incorreta conferida por inspeção; patch recuperado | REPROVADO segundo relato do usuário; correção não aplicada nem revalidada nesta fase |
| Suíte histórica completa | U-01: 2613 passed, 38 failed, 3 skipped, 1 warning | REPROVADO segundo relato; obter nodeids/logs e classificar causas |
| Direcionado UTF-8 histórico | U-02: 106 passed, 2 skipped, zero failed | APROVADO somente como relato dessa seleção; comando/log e justificativa dos skips pendentes |
| Etapa nativa histórica | 49 aprovados, 5 falhas, 1 ignorado, segundo usuário | REPROVADO segundo relato; não atribuir todas as falhas ao ACL sem nodeids |
| Reconciliação temporal | +164/+6/+99 = 269; R$ 130.997,71, datas e correspondências relatadas | Não reexecutada; não implica regressão ou mudança de regra |

Para promover uma linha: anexar rodada com HEAD/diff, hashes, Windows/Python/browser, comando, dependências, data_ref, modalidade, contagens e justificativa de cada falha/skip. Não basta inspeção de código, leitura de ACL ou êxito em Linux. Evidências privadas ficam fora do Git. A matriz não declara o MVP homologado.
