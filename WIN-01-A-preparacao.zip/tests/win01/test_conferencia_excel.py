"""A conferência deve detectar perda de duplicatas e alteração financeira/endereço."""
from pathlib import Path

from openpyxl import Workbook
import pytest

from conversor.domain.template import COLUNAS
from tools.win01.conferir_excel import check_pair


def sheet(path, rows, header=COLUNAS):
    workbook = Workbook()
    workbook.active.title = 'Dados'
    workbook.active.append(header)
    for row in rows:
        workbook.active.append(row)
    workbook.save(path)
    workbook.close()


def test_conferencia_preserva_multiplicidade_e_identifica_alteracoes(tmp_path):
    a, b = tmp_path / 'a.xlsx', tmp_path / 'b.xlsx'
    row = [None] * 30
    row[2], row[3], row[29] = '00000000191', 'Pessoa Ficticia', 100.10
    extra = [None] * 30
    extra[3] = 'Cadastro Ficticio'
    expected = {'elegiveis_a': 2, 'linhas_b': 3, 'adicionais_b': 1, 'total_original': '200.20'}
    sheet(a, [row, row])
    sheet(b, [row, row, extra])
    assert check_pair(a, b, expected)['status'] == 'APROVADO'
    sheet(b, [row, extra])
    assert check_pair(a, b, expected)['checks']['financeiro_ab_identico'] is False
    changed = row.copy()
    changed[29] = 100.11
    sheet(b, [row, changed, extra])
    assert check_pair(a, b, expected)['status'] == 'REPROVADO'


def test_conferencia_nao_aprova_endereco_ausente_em_linha_cadastral(tmp_path):
    a, b = tmp_path / 'a.xlsx', tmp_path / 'b.xlsx'
    row = [None] * 30
    row[3], row[29] = 'Pessoa Ficticia', 100
    row[4] = 'Rua Ficticia'
    extra = [None] * 30
    extra[3] = 'Cadastro Ficticio'
    sheet(a, [row])
    sheet(b, [row, extra])
    result = check_pair(a, b, {'elegiveis_a': 1, 'linhas_b': 2, 'adicionais_b': 1},
                        {'logradouro': 'Rua Ficticia', 'numero': None, 'cep': None, 'bairro': None, 'cidade': None, 'uf': None})
    assert result['endereco'] == 'REPROVADO'


@pytest.mark.parametrize('kind', ['header', 'document', 'formula'])
def test_conferencia_recusa_contrato_invalido(tmp_path, kind):
    a, b = tmp_path / 'a.xlsx', tmp_path / 'b.xlsx'
    row = [None] * 30
    row[2], row[29] = '00000000191', 100
    header = COLUNAS
    if kind == 'header':
        header = (*COLUNAS[:26], COLUNAS[26] + ' ', *COLUNAS[27:])
    elif kind == 'document':
        row[2] = 191
    else:
        row[29] = '=1+1'
    sheet(a, [row], header)
    sheet(b, [row], header)
    with pytest.raises(ValueError):
        check_pair(a, b, {'elegiveis_a': 1, 'linhas_b': 1, 'adicionais_b': 0})
