"""Runner Windows da preparação. Não corrige produção nem instala pacotes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

BASE = '770d062d29c4361d6932592883df9339bb4089bc'
ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-root', type=Path, required=True)
    parser.add_argument('--etapa', choices=('rapida', 'nativa', 'completa', 'excel'), required=True)
    parser.add_argument('--manifesto-excel', type=Path)
    args = parser.parse_args()
    if sys.platform != 'win32' or sys.version_info[:2] != (3, 12):
        parser.error('Requer Windows nativo e Python 3.12')
    def git(*cmd):
        return subprocess.check_output(['git', *cmd], cwd=ROOT).decode('utf-8', 'replace').strip()
    if git('rev-parse', 'HEAD') != BASE:
        parser.error('HEAD diferente do commit-base obrigatorio')
    output = args.evidence_root.resolve()
    # Rejeita qualquer worktree Git, não só o checkout atual.
    existing = output
    while not existing.exists():
        existing = existing.parent
    in_git = subprocess.run(['git', '-C', str(existing), 'rev-parse', '--show-toplevel'], capture_output=True)
    if in_git.returncode == 0 or output == ROOT or ROOT in output.parents:
        parser.error('Evidencias precisam ficar fora de qualquer checkout Git')
    run = output / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex)
    run.mkdir(parents=True, exist_ok=False)
    report = {'etapa': args.etapa, 'head': BASE, 'origem': 'execucao Windows desta rodada',
              'python': sys.version, 'windows': platform.platform(), 'homologacao': False,
              'utc': datetime.now(timezone.utc).isoformat(), 'steps': []}
    failed = blocked = False
    paths = []
    report['artefatos_sha256'] = {}
    def step(name, cmd):
        nonlocal failed, blocked
        record = {'name': name, 'command': list(map(str, cmd))}
        try:
            result = subprocess.run(cmd, cwd=ROOT, capture_output=True, timeout=1800)
            (run / (name + '.log')).write_bytes(result.stdout + b'\n' + result.stderr)
            code = result.returncode
            record.update(exit_code=code, status='APROVADO' if code == 0 else 'REPROVADO')
            failed |= code != 0
        except (OSError, subprocess.TimeoutExpired) as exc:
            record.update(status='BLOQUEADO', motivo=type(exc).__name__)
            blocked = True
            code = None
        report['steps'].append(record)
        return code
    try:
        (run / 'git-inicial.txt').write_text(git('status', '--porcelain=v1', '--untracked-files=all'), encoding='utf-8')
        (run / 'working-diff.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))
        (run / 'index-diff.patch').write_bytes(subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=ROOT))
        # Hashes de todos os artefatos da preparação e testes complementares.
        paths = [*ROOT.glob('docs/WIN_01_*.md')]
        for folder in ('docs/win_01_a', 'tools/win01', 'tests/win01'):
            paths.extend(p for p in (ROOT / folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
        report['artefatos_sha256'] = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
        step('dependencias', [sys.executable, '-m', 'pip', 'freeze'])
        step('pip-check', [sys.executable, '-m', 'pip', 'check'])
        step('inventario', [sys.executable, str(ROOT / 'tools/win01/inventariar.py'), str(run / 'inventario.json')])
        scopes = json.loads((ROOT / 'docs/win_01_a/escopos.json').read_text(encoding='utf-8'))
        if args.etapa == 'excel':
            if not args.manifesto_excel:
                report['steps'].append({'name': 'excel', 'status': 'BLOQUEADO', 'motivo': 'MANIFESTO_AUSENTE'})
                blocked = True
            else:
                manifest = args.manifesto_excel.resolve()
                step('excel', [sys.executable, '-X', 'utf8', str(ROOT / 'tools/win01/conferir_excel.py'), str(manifest), str(run / 'excel.json')])
        else:
            if args.etapa == 'rapida':
                step('sintaxe', [sys.executable, '-X', 'utf8', str(ROOT / 'tools/win01/verificar_sintaxe.py')])
            if args.etapa == 'nativa':
                probe = run / 'sonda-sintetica'
                probe.mkdir()
                code = step('ntfs', ['powershell.exe', '-NoProfile', '-File', str(ROOT / 'tools/win01/sonda_ntfs.ps1'), '-ProbeRoot', str(probe)])
                if code == 0:
                    try:
                        native = json.loads((run / 'ntfs.log').read_text(encoding='utf-8-sig'))
                    except (ValueError, UnicodeError):
                        # Windows PowerShell normalmente emite OEM; relatório é ASCII.
                        native = json.loads((run / 'ntfs.log').read_bytes().decode('ascii'))
                    report['sonda'] = native
                    blocked |= native.get('ntfs') != 'APROVADO' or native.get('leitura_acl') != 'APROVADO'
                    blocked |= any(native.get(key, {}).get('status') != 'APROVADO' for key in ('HardLink', 'SymbolicLink', 'Junction'))
                if step('caminhos-8-3', [sys.executable, str(ROOT / 'tools/win01/sonda_caminhos.py'), str(probe)]) == 0:
                    short_paths = json.loads((run / 'caminhos-8-3.log').read_text(encoding='utf-8'))
                    report['caminhos'] = short_paths
                    blocked |= short_paths['8_3'] != 'APROVADO'
                    failed |= short_paths['normalizacao'] == 'REPROVADO'
                report['controles_pendentes'] = ['politica ACL efetiva no app', 'outro usuario/processo hostil', 'recuperacao apos crash', 'restricao real de leitura/escrita', '8.3 se desabilitado no volume']
            scope = scopes[{'rapida': 'integrada', 'nativa': 'nativa', 'completa': 'completa'}[args.etapa]]
            collected = step('coleta', [sys.executable, '-X', 'utf8', '-m', 'pytest', '--collect-only', '-q', *scope])
            if collected == 0:
                step('pytest', [sys.executable, '-X', 'utf8', '-m', 'pytest', '-q', '--tb=short', '-p', 'no:cacheprovider', '--junitxml=' + str(run / 'junit.xml'), *scope])
                if (run / 'junit.xml').exists():
                    suites = ET.parse(run / 'junit.xml').getroot().iter('testsuite')
                    report['pytest_totais'] = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
                    for suite in suites:
                        for key in report['pytest_totais']:
                            report['pytest_totais'][key] += int(suite.get(key, 0))
                    counts = report['pytest_totais']
                    counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
                    report['skips_requerem_revisao'] = counts['skipped'] > 0
    except Exception as exc:
        blocked = True
        report['bloqueio'] = type(exc).__name__  # sem paths/conteúdo de documentos
    finally:
        final_status = git('status', '--porcelain=v1', '--untracked-files=all')
        (run / 'git-final.txt').write_text(final_status, encoding='utf-8')
        report['git_status_preservado'] = final_status == (run / 'git-inicial.txt').read_text(encoding='utf-8')
        report['git_status_preservado'] &= subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT) == (run / 'working-diff.patch').read_bytes()
        report['git_status_preservado'] &= subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=ROOT) == (run / 'index-diff.patch').read_bytes()
        report['git_status_preservado'] &= all(p.exists() and hashlib.sha256(p.read_bytes()).hexdigest() == report['artefatos_sha256'][p.relative_to(ROOT).as_posix()] for p in paths)
        failed |= not report['git_status_preservado']
        report['status'] = 'BLOQUEADO' if blocked else 'REPROVADO' if failed else 'APROVADO'
        (run / 'relatorio.json').write_text(json.dumps(report, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
    print('Etapa:', args.etapa, 'Status:', report['status'], 'Evidencias:', run)
    print('Resultado da etapa nao constitui homologacao; revisar skips e controles ausentes.')
    return 2 if blocked else 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
