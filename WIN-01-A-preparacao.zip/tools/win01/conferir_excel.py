"""Confere XLSX A/B privados sem copiar entradas nem exportar dados pessoais."""
from collections import Counter
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys

from openpyxl import load_workbook
from conversor.domain.template import COLUNAS

PERFIS = ('passaredo', 'forest_hill', 'parque_santa_monica', 'vero_encanto', 'itajuba', 'terraco_beach_parque')
ADDR_INDEX = (4, 5, 7, 8, 9, 10)
ADDR_FIELDS = ('logradouro', 'numero', 'cep', 'bairro', 'cidade', 'uf')


def outside_git(path):
    return not any((parent / '.git').exists() for parent in (path, *path.parents))


def read_sheet(path):
    if not outside_git(path):
        raise ValueError('ENTRADA_DENTRO_DO_GIT')
    workbook = load_workbook(path, read_only=True, data_only=False, keep_links=False)
    try:
        sheet = workbook['Dados']
        if sheet.max_column != 30:
            raise ValueError('COLUNAS')
        cells = list(sheet.iter_rows())
        if not cells or tuple(c.value for c in cells[0]) != COLUNAS:
            raise ValueError('CABECALHO')
        if any(c.data_type == 'f' for row in cells for c in row):
            raise ValueError('FORMULAS')
        rows = [tuple(c.value for c in row) for row in cells[1:] if any(c.value is not None for c in row)]
        if any(r[2] is not None and not isinstance(r[2], str) for r in rows):
            raise ValueError('DOCUMENTO_NAO_TEXTUAL')
        return rows
    finally:
        workbook.close()


def check_pair(a_path, b_path, expected, address=None):
    a, b = read_sheet(a_path), read_sheet(b_path)
    financial_a = [r for r in a if r[29] is not None]
    financial_b = [r for r in b if r[29] is not None]
    # Counter preserva multiplicidade; conjuntos ocultariam perdas de linhas repetidas.
    equal = Counter(financial_a) == Counter(financial_b)
    total = sum((Decimal(str(r[29])) for r in financial_a), Decimal(0))
    checks = {
        '30_colunas_e_cabecalhos': True,
        'financeiro_ab_identico': equal,
        'a_sem_linhas_cadastrais': len(a) == len(financial_a),
        'elegiveis_a': len(financial_a) == expected['elegiveis_a'],
        'linhas_b': len(b) == expected['linhas_b'],
        'adicionais_b': len(b) - len(financial_b) == expected['adicionais_b'],
    }
    if 'total_original' in expected:
        checks['total_original'] = total == Decimal(expected['total_original'])
    if address is not None:
        target = tuple(address[n] for n in ADDR_FIELDS)
        checks['endereco_todas_linhas_ab'] = all(tuple(row[i] for i in ADDR_INDEX) == target for row in a + b)
    return {'status': 'APROVADO' if all(checks.values()) else 'REPROVADO', 'checks': checks,
            'elegiveis_a': len(financial_a), 'linhas_b': len(b), 'adicionais_b': len(b) - len(financial_b),
            'total_original': str(total), 'endereco': 'NAO_EXECUTADO' if address is None else ('APROVADO' if checks['endereco_todas_linhas_ab'] else 'REPROVADO'),
            'sha256_a': hashlib.sha256(a_path.read_bytes()).hexdigest(),
            'sha256_b': hashlib.sha256(b_path.read_bytes()).hexdigest()}


def main():
    manifest_path, output = map(Path, sys.argv[1:])
    if not outside_git(manifest_path.resolve()):
        raise ValueError('MANIFESTO_DEVE_FICAR_FORA_DO_GIT')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
    result = {'origem': 'conferencia de arquivos fornecidos nesta rodada', 'homologacao': False, 'perfis': {}}
    for profile in PERFIS:
        item = manifest.get('perfis', {}).get(profile)
        if not item:
            result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': 'PAR_A_B_AUSENTE'}
            continue
        try:
            if not item.get('data_ref') or not manifest.get('head_execucao') or not item.get('evidencia_execucao'):
                raise ValueError('PROVENIENCIA_AUSENTE')
            paths = [Path(item[key]).resolve() for key in ('a', 'b')]
            result['perfis'][profile] = check_pair(*paths, item['esperado'], item.get('endereco'))
            result['perfis'][profile]['data_ref'] = item['data_ref']
        except Exception as exc:
            # Não registrar exceção com valor/caminho/célula privada.
            result['perfis'][profile] = {'status': 'BLOQUEADO', 'motivo': type(exc).__name__}
    statuses = [r['status'] for r in result['perfis'].values()]
    result['status'] = 'BLOQUEADO' if 'BLOQUEADO' in statuses else 'REPROVADO' if 'REPROVADO' in statuses else 'APROVADO'
    with output.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, ensure_ascii=True)
        stream.write('\n')
    print(result['status'])
    return 2 if result['status'] == 'BLOQUEADO' else 1 if result['status'] == 'REPROVADO' else 0


if __name__ == '__main__':
    raise SystemExit(main())
