# WIN19-C1 — complementação documental

18/11/2026, referência civil America/Sao_Paulo. Revisão estática externa ao Git.
Os documentos anteriores e a candidata permanecem intactos. Não houve Python,
pytest, preflight, parser PowerShell, extrator histórico ou ensaio nesta etapa.

## Conclusão e limites

**C1 permanece parcial: 19 vínculos PROVISORIO_SEM_FONTE, zero confirmados,
decisões PENDENTE.** Não foi recebido o JUnit original da rodada EXP-04 Windows
UTF-8 de 2.842 casos, 2.816 PASS, 19 FAIL, sete SKIP, zero ERROR. O local relatado
é %LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml;
pertence ao Windows do usuário e não foi tratado como arquivo local acessível.

O manifesto local de 448 entradas foi novamente observado, baseline
770d062d29c4361d6932592883df9339bb4089bc, 50.698 bytes, SHA-256
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb.
Uma cópia literal é entregue em fontes_observadas/VERSAO_EXP04_SHA256.json.
Isso permite auditar seus bytes, mas **não prova seu uso na execução Windows**,
a correspondência física dos 448 arquivos naquela máquina ou a origem de um teste.

## Proveniência: três perguntas diferentes

| Artefato | Observação nesta etapa | Classe e limite |
|---|---|---|
| Instrução colada, parecer e matriz anexados | Bytes recebidos e hashes calculados; cópias em fontes_recebidas/ | Fontes desta revisão documental; não fontes primárias da execução Windows |
| Matriz reconstruída do diff | 19.210 bytes, SHA a1fb7a7d52e74e42cb7890ba6d39925fea3a3629deb85b3f33564eec01600459, igual à matriz anterior local | Derivado documental; igualdade não cria origem independente |
| ZIP auditado de sete arquivos | 30.656 bytes, SHA e8b4e77799dcbddd6e2f70b44e796077e344e27f4f6bd76bf62145b6aba86afe | Publicação anterior preservada; não contém JUnit original |
| Manifesto anterior | SHA 5594fab96c477572d74527180f8f5e70b1780b332ba71c4772d019778ca6917c; enumera 22 outros arquivos | Fonte da conferência de integridade documental, não prova de execução |
| 16 auxiliares ausentes do ZIP | Todos acessíveis; hashes originais conferem; cópias literais em auxiliares_anteriores/ | Material agora entregue para revisão, sem promoção de status |
| Índice secundário do usuário | Registro local anterior preservado; 19 nomes e quatro grupos de skips | Testemunho transcrito, não testcase/traceback original |
| Texto colado(6).txt e derivado sanitizado da biblioteca | Bytes não recebidos; SHAs apenas declarados | Não recalculados nem atribuídos ao nosso registro Markdown |
| Manifesto 448 | Bytes observados, hash e cardinalidade documental conferidos | Referência de versão encontrada; adoção na rodada não demonstrada |
| JUnit/logs Linux ou de candidatas posteriores | Referências nos inventários anteriores | Não substituem o XML-alvo, mesmo com 2.842 casos |
| Encerramento cleanup e Portão B | Referências contextuais | Não transferem PASS de segurança nem nova autorização |

Os SHAs relatados da biblioteca continuam: raw
aba965b2eb20f1e75a7fae46aaf3e172ee2ef62173f8adaf5d94cd724a6cfc9c e derivado
3b158c6ecabb1b1d69999d6690f2c44eb363d08794dafbfbfd5c2d0be66f6d65.
Esses valores permanecem declarações sem bytes originais para conferência.

## Reexame restrito realizado

Foram relidos o relatório C1, as matrizes, os inventários e o registro secundário
anteriores, além do parecer atual. A integridade de cada auxiliar foi comparada
com o manifesto preexistente e as cópias foram comparadas byte a byte. A matriz
anexada foi comparada diretamente à local, sem reconstruí-la ou executar código.

Foi feita busca apenas de nomes completa-utf8.xml e referências específicas da
rodada nos quatro diretórios de entregas/evidências EXP-04 já autorizados. Nenhum
arquivo-alvo apareceu ali. Não houve busca em arquivos pessoais, no computador
Windows, em credenciais ou no depósito privado B. A ausência no escopo acessível
não demonstra ausência global. Não foram novamente varridos os 142 XML nem
recontados testcase: esses inventários são artefatos da etapa anterior, preservados.

As cardinalidades anteriores — 142 XML, 11 pacotes e 27 entradas XML — continuam
atribuídas ao método estático daquela entrega. SHA íntegro do inventário não
valida sua metodologia nem transforma cópias em execuções independentes.

## Sete skips: informação disponível e lacunas

O índice secundário relata quatro casos agrupados em test_reconstrucao.py:16,
com motivo EXP04_SYMLINK_SEM_PRIVILEGIO_1314; controle nativo NAO_VALIDADO; dois
casos em rules/test_authority.py:128 e :168 com motivo Permissões POSIX; um caso
em test_acl_evidence.py:140 com motivo symlink indisponível nesta plataforma.

Não há sete nodeids individualizados, estágio ou traceback primário. Não atribuir
WinError 1314 ao último caso por suposição. Os dois skips POSIX de authority não
são as falhas private_simulation/permissao_fonte e permissao_raiz de WIN-18/19.
O CSV agrupado anterior é entregue literalmente, preservando o motivo informado.

## Recuperação necessária no Windows — sem comandos de coleta nesta entrega

| Peça exata ou identificação ainda necessária | Campos a preservar | Finalidade |
|---|---|---|
| completa-utf8.xml no diretório relatado | Bytes, nome, tamanho, SHA, origem e custodiante | 19 failure e sete skipped, classe/nome/parâmetro/estágio e traceback sanitizado |
| Log persistido stdout/stderr da mesma rodada, se existente; nome SEM_FONTE | Nome original, bytes/SHA e vínculo ao mesmo run | Resumo, comando e erros; não recriar log a partir do console |
| Relatório/contexto do mesmo run, se existente; nome SEM_FONTE | SO, Python, pytest/plugins, variáveis relevantes sem valores secretos, data/fuso, retorno | Distinguir execução histórica das posteriores |
| Comando literal no log/histórico autorizado; origem SEM_FONTE | Texto exato, parâmetros e identificação da origem | A estrutura lembrada não é transcrição autenticada |
| Manifesto efetivamente usado, nome original e SHA | Bytes, 448 entradas e vínculo explícito ao run | Conferir se é o artefato 19f936... localizado, sem presumir |
| Estado de código da execução, se preservado | Commit, alterações/untracked e manifesto efetivo da candidata | HEAD sozinho não prova os bytes executados |
| Registro do custodiante/revisor | Autorização de cópia e sanitização, cadeia raw→derivado, data/fuso e aceite por ID | Tornar a proposta de vínculo revisável sem expor dados privados |

Não inventar nomes para peças ainda desconhecidas. Se um original não existir,
registrar sua ausência; a transcrição continua secundária. Raw privado deve
permanecer com custodiante. Retenção própria de C1 ainda precisa de decisão;
não herdar automaticamente os 90 dias da coleta B.

## Matriz atualizada e ponto de parada

MATRIZ_C1_ATUALIZADA.csv preserva as 19 propostas, colunas de relato e campos
primários SEM_FONTE. Acrescenta fonte desta revisão e o limite do manifesto.
Nenhum caso foi confirmado por coincidência literal. Revisão documental favorável
não é assinatura de vínculo histórico. Ver INTEGRIDADE_16_AUXILIARES.csv para
nomes, bytes e hashes dos 16 ausentes. Nenhuma evidência primária foi reconstruída.

prontidao_para_executar=false; autorizacao_testes=PENDENTE; WIN01–WIN19 e DACL
NÃO_VALIDADO; C/D/E e CONVERSOES_REAIS BLOQUEADOS. Parar para revisão independente.
