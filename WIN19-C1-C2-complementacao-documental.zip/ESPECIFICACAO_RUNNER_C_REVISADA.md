# WIN19-C — especificação revisada, exclusivamente textual

18/11/2026. **NÃO IMPLEMENTADA. NÃO EXECUTAR.** Complementação do contrato anterior
à luz do parecer independente. Nenhuma propriedade descrita foi validada por esta
revisão. Não há script, fixture, comando de teste ou instrução para mudar a máquina.

## 1. Escopo e autorizações distintas

A especificação cobre 21 subcasos/19 IDs da matriz atualizada. WIN-11 e WIN-13 têm
dois subcasos cada; WIN-18/19 continuam protocolos bloqueados, não testes DACL.
Resultados não confirmam os vínculos históricos. A candidata R1-FIX 470 é referência
somente leitura. Nenhuma coleta B, aprovação de cleanup ou parsing PowerShell é
reutilizada como autorização ou prova dos controles C.

São quatro decisões distintas: aceitar esta especificação; autorizar implementar
um runner externo; revisar o diff/hashes e autorizar executar C em ambiente definido;
aprovar política/laboratório e autorizar ensaios DACL em outro portão. Nenhuma está
implícita na anterior. C/D/E e conversões reais permanecem bloqueados.

## 2. Congelamento de versão e origem

A futura revisão de implementação deverá fixar: manifesto 470 aprovado e seu SHA;
manifesto dos cenários/helpers/runner externos; versões/hashes de dependências e
binários; origem dos imports; autorização e custodiante. HEAD não autentica bytes
com alterações/untracked. Divergência ou link/reparse em caminho de referência
bloqueia, sem reconstrução ou correção silenciosa.

Python 3.12/UTF-8 e importação explícita da candidata aprovada serão requisitos do
processo futuro. Usar ambiente de dependências previamente aprovado, sem instalar
pacotes automaticamente. Não herdar PYTHONPATH/PYTHONHOME, user site ou plugins
indefinidos; definir busca controlada e verificar origem real dos módulos. Não
tratar PYTHONPATH apenas declarado como prova. Não produzir bytecode/cache nem usar
plugins/parallelismo extras. Como demonstrar essas condições ainda precisa de
revisão de implementação; nenhuma importação foi feita nesta tarefa.

Git no futuro WIN-11-A usa binário absoluto conhecido e hash aprovado. Seu ambiente
será construído por allowlist, sem variáveis GIT_* herdadas, redirecionamentos de
worktree/objeto/índice/configuração/templates/exec path ou PATH não controlado.
Somente controles de processo explicitamente aprovados serão repostos: desabilitar
configuração de sistema; config global vazia própria; config local nova sem
includes; hooks/template vazios próprios. Não mudar HOME nem configurações
persistentes. As variáveis mínimas necessárias ao Windows serão revisadas, sem
copiar o ambiente inteiro. A inicialização é só em laboratório novo, sem rede.
Se qualquer metadado Git inesperado aparecer, bloquear em vez de aceitar como
área externa segura. O caso não prova automaticamente todas as formas de Git bare,
worktree ou metadata danificada do produto.

## 3. Áreas separadas, titularidade e limites

Futura área de trabalho curta, absoluta, nova, reservada por criação exclusiva,
fora de qualquer Git, documentos privados, outras candidatas e resíduos anteriores.
Futura área de evidências separada do laboratório/basetemp, também exclusiva e
com custodiante definido. Nenhum diretório preexistente será entregue ao pytest
para descarte. Não procurar documentos de clientes nem usar arquivo de terceiro
como alvo/sentinela. Não tocar contêiner residual histórico.

Titularidade nesta especificação significa prova de criação exclusiva pelo ensaio
e identidade do objeto, não apenas owner de filesystem nem controle DACL. Registrar
raiz/ancestrais e recusar symlink/reparse/redirecionamento inesperado antes de
atravessar. Como preservar isso contra substituição concorrente exige revisão
técnica futura; checagem textual não é garantia implementada de ausência de race.

## 4. Máquina de estados futura

| Etapa | Condição para avançar | Falta/erro |
|---|---|---|
| Autorização | Escopo e ambiente aprovados por escrito | Não reservar recursos |
| Referências | Hashes, versão e origem de imports correspondentes | BLOQUEADO sem reescrever |
| Área própria | Criação exclusiva e identidades/ancestrais demonstrados | Preservar desconhecido |
| Início durável | Evento externo confirmado antes da primeira asserção | Não iniciar positivo/ataque |
| Positivo | Fluxo regular válido de cada componente | NÃO_VALIDADO se precondição falhar |
| Snapshot prévio | Bytes integrais, nomes, tipos, IDs e diretórios congelados | BLOQUEADO se incompleto |
| Adversarial | Capacidade realmente estabelecida e sincronizada | Skip pontual só se motivo observado |
| Operação | Resultado/erro real imediatamente capturado | API não observável não é inventada |
| Persistência | Evento confirmado antes de avaliar expectativa | Falha de observador bloqueia |
| Comparação | Sentinelas/árvore e fronteiras comparadas integralmente | FAIL por violação, preservar |
| Julgamento | Resultado por afirmação e eixo | Sem promoção por soma verde |
| Encerramento | Filhos/handles próprios liberados e limpeza comprovada | Falha operacional/resíduo explícitos |
| Custódia | Índice, hashes, derivação e recibo de entrega | Parcial se incompleto |

Ordem sequencial entre casos. Concorrência só dentro do caso aprovado que a exige,
com handshake comprovado. Não encerrar um handle antes da operação cujo bloqueio
se quer observar; comparar bytes depois de liberá-lo quando a leitura exigir.
Um resultado falso de comparador não serve sem positivo que exija true.

## 5. Observador antes de todas as asserções

O futuro observador deve persistir início e cada evento relevante FORA da árvore
temporária. Também deve registrar exceção anterior à asserção, snapshot falho,
JSON ausente, falha de fixture, timeout e encerramento parcial. Não depender de
pytest.raises, fixture finalizer, relatório final ou retorno normal do subprocesso
como único ponto de gravação. JUnit é complementar, não única evidência sobrevivente.

Campos do evento: run/caso/subcaso; versão e hashes; fase; horário UTC e referência
de fuso; objeto por rótulo seguro; positivo/capacidade; operação; camada de origem
(produto/helper/CLI); retorno efetivo; erro observado ou NÃO_OBSERVÁVEL; integridade;
eixos funcional/nativo/DACL; primeira falha e falhas secundárias; limpeza/custódia.
Rótulos nunca contêm caminhos pessoais, nomes de conta, SID/SDDL ou segredos.

Capturar o código Win32 imediatamente após a API que falhou, antes de outra chamada.
Não inferir GetLastError a partir do erro esperado no nome de teste ou de mensagem
traduzida. Não confundir código de aplicação, wrapper e API nativa. Preserve a
primeira falha; falha posterior de CloseHandle, persistência ou limpeza é adicional.
Se a superfície do produto não expõe o erro nativo, deixar NÃO_OBSERVÁVEL. Mudar
produção ou instrumentá-la demandaria escopo separado, não autorizado por este texto.

A revisão futura deve definir confirmação de escrita, ordenação, atomicidade dos
índices e resposta a falta de espaço. Fsync/rename ou arquivo presente não são por
si prova de durabilidade após energia perdida; não afirmar resistência não ensaiada.
Falha do observador impede PASS, mesmo que a asserção funcional passasse.

## 6. Snapshots, bytes e WIN-14

Registrar para cada entrada própria: existência, nome relativo, tipo, identidade de
arquivo/volume, categoria de link/reparse e diretórios inclusive vazios. Guardar
bytes completos em memória e comparar após operação; hash é verificação adicional.
Ler conteúdo somente quando a entrada e seus ancestrais forem regulares/autorizados.
Arquivo diferente de mesmos bytes não é identidade igual. Mapa de arquivos→bytes
sozinho não atesta ausência de novas pastas ou substituição física.
Comparação pré/pós também não prova ausência de leitura ou mutação transitória
revertida. Tais alegações exigiriam observação própria aprovada, ainda não definida;
não promovê-las a PASS pela igualdade final.

WIN-14 congela referências após a gravação/releitura positiva, quando já existe
política de autorização histórica legítima. Observar separadamente fontes, corpos,
recibos/locks, chave, concessões e toda a raiz de autoridade, incluindo policies e
outros objetos efetivamente presentes. Não inventar ponteiros que não existem na
versão. Cada fronteira produz resultado independente, sem curto-circuito impedir
observação das demais. Snapshot incompleto gera bloqueio com evento seguro.

W14P permanece NÃO APLICADA. Seu acréscimo de comparação de authority.raiz não
resolve sozinho a identidade, diretórios vazios, observação pré-assert ou DACL.
Segredos/credencial e conteúdo de chave ficam somente em memória ou custódia
privada aprovada, nunca serializados em resultado compartilhado, repr ou locals.
Não publicar hashes de credencial como substituto de segredo. Usar booleans por
fronteira no derivado. Autoridade de aplicação não é identidade Windows distinta.

## 7. CLI, timeout, crash e WIN-16

O desenho futuro salva stdout/stderr continuamente em arquivos exclusivos externos
ao basetemp e confirma eventos/checkpoints; a única cópia não fica retida até o
retorno de subprocess.run. Não imprimir saída bruta ou documento no log público.
Conservar bytes parciais em crash/timeout, identificar estágio alcançado e marcar
resultado incompleto. Definir, na revisão de implementação, quais descendentes são
comprovadamente próprios antes de encerrá-los; não matar processos por nome genérico.

WIN-16 separa CLI, JSON documental, DTO e exportação. Oráculo declarativo é congelado
antes da leitura. Positivo real precede conflito; retorno dois sozinho é ambíguo.
Assim que JSON/auditoria forem lidos, observar status, contagens, duas evidências e
retenção antes de assert; erro de leitura também deve persistir. DTO do gabarito é
prova isolada. O CLI sem exportação não comprova conversão operacional. Não gerar
XLSX fictício para promover homologação. Raw sintético com documentos fabricados
continua restrito; o relatório compartilhável só usa agregados e integridade.

## 8. Resultado, interrupção e limpeza

| Condição futura | Resultado e tratamento |
|---|---|
| Contrato exercitado, positivo/adversarial válidos e bytes intactos | PASS somente da afirmação alcançada |
| Contrato violado, sentinela alterada ou acesso indevido | FAIL, persistir e interromper a sequência pertinente |
| Ausência de fonte, versão, positivo ou telemetria necessária | BLOQUEADO/NÃO_VALIDADO |
| Symlink 1314 realmente observado ou alias real indisponível | Skip apenas da capacidade dependente; nativo NÃO_VALIDADO |
| Timeout/crash/interrupção | Evidência parcial, sem PASS pela ausência de saída |
| API/código diferente do esperado | Registrar e diagnosticar; nunca mudar asserção para obter verde |
| Falha de limpeza/handle ou identidade incerta | Resíduo preservado e encerramento FALHOU, sem sucesso silencioso |

Nenhuma tentativa infinita ou limpeza de fallback irrestrita. Só remover objetos
com prova de criação e identidade, sem seguir link/reparse. Nenhum objeto externo
ou antigo é apagado. Falha não autoriza reset da área. A remoção incompleta exige
procedimento posterior específico e autorizado; evidências/JUnit permanecem fora
do laboratório. Numeração de exit codes e viabilidade concreta serão revisadas
na futura implementação, sem alterar executores existentes nesta tarefa.

## 9. Custódia e eixos

Evidência privada/raw e derivado sanitizado terão responsáveis, cadeia original→
derivado, nomes/bytes/SHA, regra de remoção, data/fuso e autorização de transferência.
Retenção própria para C1/C, sem aplicar automaticamente 90 dias de B. Não anexar
logs privados, credenciais ou documentos de clientes; não depender de diretório
que o cleanup possa remover. Custodiante confirma recebimento sem expor localização.

Resultado de ensaio e de segurança são dimensões diferentes. Por afirmação,
funcional/nativo/DACL usam APROVADO, FALHOU ou NÃO_VALIDADO. PASS de flags, JSON,
sharing violation ou link recusado não aprova DACL. NUL pré-API não aprova erro
nativo de CompareStringOrdinal. Hardlink é julgado pelo contrato específico.
WIN-18/19 exigem política D01–D10 e tokens distintos em portão separado; chmod,
mesmo token e ACL aplicada manualmente não provam integração do aplicativo.

## 10. Situação de saída desta revisão

Todos os 21 cenários e 19 controles NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE;
prontidao_para_executar=false; autorizacao_testes=PENDENTE; C/D/E, DACL e
conversões reais bloqueados. Nenhuma área de ensaio foi criada, nenhum cenário
executado e nenhuma propriedade acima está implementada por este documento.
Parar para revisão independente, sem solicitar execução automática.
