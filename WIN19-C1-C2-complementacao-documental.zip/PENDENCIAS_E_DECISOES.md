# WIN19-C1/C2 — pendências, decisões textuais e portões

18/11/2026. Preparação documental externa ao Git, sem execução ou publicação.

## Situação consolidada

| Eixo | Situação |
|---|---|
| Integridade dos 16 auxiliares ausentes no ZIP | Acessíveis, hashes originais conferidos, cópias documentais entregues |
| Matriz C2 reconstruída anexada | Igual à matriz local por bytes/SHA; continua derivado |
| Manifesto histórico 448 | Artefato observado e copiado; uso na rodada Windows não demonstrado |
| JUnit/log original Windows | Não recebido/acessível no escopo autorizado |
| Vínculos históricos | 19 PROVISORIO_SEM_FONTE, zero confirmados, revisor PENDENTE |
| Revisão prospectiva C2 | 21 cenários com decisões e lacunas documentadas, não implementados |
| Desvio processual inicial | Declarado, com efeitos não demonstrados; comando exato SEM_FONTE |
| Prontidão/autorizações | prontidao_para_executar=false; autorizacao_testes=PENDENTE |
| Controles/homologação | WIN01–WIN19 e DACL NÃO_VALIDADO; C/D/E BLOQUEADOS |
| Operação | CONVERSOES_REAIS=BLOQUEADAS |

## Ressalvas tratadas nesta preparação

- Os 16 documentos auxiliares faltantes foram relacionados individualmente com
  nome original, SHA esperado/observado, tamanho e cópia entregue. Isso fecha a
  lacuna de disponibilidade documental local, não o aceite independente desses
  documentos nem a comprovação da execução Windows.
- WIN-03 distingue retorno de wrapper e Kernel32. O erro nativo segue sem estratégia
  segura demonstrada; NUL/mock/ponteiro inseguro não são aceitos como comprovação.
- WIN-04 define positivo consigo e equivalente real, além do negativo de hardlink,
  para impedir falso PASS do comparador sempre false. Nenhum teste foi alterado.
- WIN-11-A especifica isolamento do processo Git e configuração própria sem herança;
  WIN-11-B exige positivos e negativas independentes de repositório e aplicação.
- WIN-14 tem W14P integralmente lida, mas não aplicada. Além da autoridade, o desenho
  passa a exigir nomes, diretórios vazios e identidades, não só arquivos/bytes.
  O snapshot atual não atende sozinho essa definição. Não há prova de DACL.
- WIN-16 separa CLI, JSON, DTO e exportação. Prevê stdout/stderr contínuos externos
  e evidência pré-assert, inclusive incompleta. Viabilidade permanece pendente.
- A nota do desvio distingue admissão, finalidade relatada e efeitos não demonstrados.
  Nenhuma ferramenta foi reexecutada para reconstruir a prova ausente.

## Impedimentos que permanecem

| ID | Fonte ou decisão necessária | Por que impede avanço automático |
|---|---|---|
| F01 | completa-utf8.xml original e cadeia de custódia | Sem testemunho primário dos testcase/19 falhas/sete skips |
| F02 | Log persistido, comando literal e contexto do mesmo run | Estrutura recordada não autentica ambiente/retorno/origem |
| F03 | Manifesto efetivamente usado e versão física/alterações do instante | SHA do artefato encontrado não demonstra adoção |
| F04 | Aceite humano por vínculo após confronto com código exato | Semelhança literal de nome não confirma história |
| F05 | Retenção, custodiante e autorização de cópia/sanitização das novas fontes | Não herdar automaticamente os 90 dias de B |
| F06 | Registro bruto do comando Python inicial, se existir e for autorizado | Não há prova integral de efeitos; não repetir o procedimento |
| T01 | Revisão de viabilidade do observador externo durável | Pré-asserção, crash/timeout e falha de escrita só estão especificados |
| T02 | Estratégia segura ou aceite explícito de lacuna do ramo de erro WIN-03 | Comparações normais não demonstram falha nativa |
| T03 | Positivos/identidades e capacidade de alias/hardlink/symlink | Capacidade ausente não vira PASS nem autorização de privilégio |
| T04 | Allowlist Git/Python e origem de imports/binários/dependências | Isolamento descrito ainda não implementado/validado |
| T05 | Revisão de W14P e substituição futura do snapshot insuficiente | Diretórios/identidade/telemetria faltantes, sem mutação nesta etapa |
| T06 | Oráculo independente, observação CLI/JSON e limite DTO | Ausência de XLSX não é fluxo operacional aprovado |
| T07 | Limpeza própria com identidade e preservação de evidências | Não aceitar resíduo ou tentativa infinita como sucesso |
| D00 | Política D01–D10, laboratório/tokens e integração real do fluxo | DACL não demonstrada por chmod, flags ou mesmo token |

## D01–D10 preservadas PARA_APROVAÇÃO

D01 READ_CONTROL; D02 WRITE_DAC/proprietário; D03 WRITE_OWNER/exceções;
D04 imutabilidade/fronteira da fonte; D05 herança/imposição no fluxo;
D06 Administradores/SYSTEM; D07 tokens O/U distintos e A limitado;
D08 CREATE/REPLACE; D09 DELETE/DELETE_CHILD/RENAME; D10 chaves/registros/retenção.
Nenhuma célula pendente virou grant ou deny aprovado. A proposta original permanece
inalterada. Não criar conta, coletar senha, impersonar, elevar ou instalar ACL.
Nenhum ensaio com ACL manual pode ser atribuído à segurança integrada do produto.

## Autorizações futuras separadas

1. Aceitar esta documentação não aprova implementação ou execução.
2. Implementação C exigirá tarefa/autorização específica, com escopo externo,
   diff e hashes para revisão, preservando candidata e evidências anteriores.
3. Execução C exigirá autorização própria dos casos, ambiente, capacidades,
   interrupção, custódia e limpeza. Não resulta da autorização para implementar.
4. Ensaios DACL D exigirão política aprovada, integração materializada pelo fluxo,
   tokens distintos e laboratório aprovado, com autorização independente.
5. Portão E/homologação e conversões continuarão bloqueados até decisão própria
   apoiada em evidências suficientes, não por suíte verde ou skip.

O Portão B está encerrado; sua coleta única e custódia privada foram preservadas.
Sua autorização não pode ser reutilizada. O relato de parsing 5.1 sem erros não foi
repetido e não abre C. As publicações anteriores pertencem às autorizações de
transferência então dadas; esta tarefa atual **não autoriza nova publicação**.

## Ponto de parada

Nenhum runner, fixture, candidata ou alteração de produção foi criado. Não houve
Python, pytest, preflight, PowerShell, ensaio de Windows/DACL ou mudança de segurança
nesta complementação. Foram usados apenas utilitários de arquivo/texto/hash e
edição de novos documentos. Não houve commit, push, merge ou publicação.
Entregar para revisão independente e parar, sem solicitar desbloqueio automático.
