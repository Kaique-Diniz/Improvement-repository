# Conferência documental e preservação — 18/11/2026

Escopo: somente documentos novos externos ao Git e leitura estática de fontes.
Esta conferência usa utilitários de arquivo/texto/hash; não é preflight, parsing
PowerShell, coleta pytest, execução de produto ou validação nativa.

- C1: 19 linhas, 19 IDs únicos, todos PROVISORIO_SEM_FONTE e revisão PENDENTE.
- Os 19 identificadores do registro local do índice do usuário coincidem
  literalmente com a coluna secundária da matriz. Isso não autentica JUnit,
  causa, versão ou vínculo histórico. Campos primários continuam SEM_FONTE.
- C2: 21 linhas, 21 subcasos únicos, 19 IDs. WIN-11 e WIN-13 desdobrados em dois.
  Nenhum eixo funcional/nativo/DACL aprovado. Nenhum caso executado.
- Skips relatados: quatro linhas agrupadas, total sete. Não há sete nodeids
  originais disponíveis. Os dois casos POSIX referem-se a rules/test_authority,
  não às falhas private_simulation/permissao_fonte e permissao_raiz.
- As cinco entradas cobertas pelo manifesto interno do ZIP de instruções foram
  conferidas contra as cópias literais. O manifesto interno não cobre a si próprio.
- Os 27 documentos/códigos locais inventariados foram novamente comparados com
  seus hashes registrados: sem divergência. As seis fontes P1–P6 correspondem às
  entradas respectivas do manifesto R1-FIX 470 de referência.
- Isso não reexecuta a verificação dos 470 arquivos nem comprova a candidata no
  computador Windows. Nenhum arquivo da candidata foi editado nesta tarefa.
- Inventário histórico: 142 XML locais, 11 pacotes, 27 entradas XML em pacotes.
  Cabeçalhos e cópias não são execuções independentes. Nenhum header único alvo
  2842/19/0/7 apareceu no escopo acessível.
- As fontes de biblioteca relatadas têm hashes DECLARADOS, não recalculados.
  O registro Markdown novo possui hash próprio. O caminho privado foi reduzido
  a %LOCALAPPDATA%; não foram incorporados raw da custódia B ou dados de clientes.
- Não foram criados arquivos executáveis. O diff compara apenas matrizes
  documentais, não contém correção ou implementação de código.

O relatório C1 registra a exceção de procedimento: a primeira abertura do ZIP de
instruções usou Python padrão antes da leitura de sua vedação interna. Não houve
uso posterior de Python nem execução de teste/produto. Nenhum parsing PowerShell
ou preflight foi realizado. O relato anterior de parsing 5.1 permanece testemunho.

O manifesto desta entrega cobre os documentos novos e cópias documentais, com
arquivos relativos e bytes. O manifesto SHA-256 textual também cobre o manifesto
JSON; exclui apenas a si próprio. Não há ZIP novo ou publicação nesta etapa.
Portão B e seu acervo privado permanecem preservados; C/D/E e conversões bloqueados.
