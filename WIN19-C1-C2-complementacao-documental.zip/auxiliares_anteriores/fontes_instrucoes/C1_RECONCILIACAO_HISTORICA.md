# WIN19-C1 — Reconciliação da fonte histórica EXP-04

**Natureza:** instrução de investigação documental, não autorização de testes.

## Evidência-alvo e risco de confusão

A fonte histórica procurada é **a execução Windows EXP-04 original**, cuja contagem foi declarada como **2.842 casos / 19 falhas / 7 skips**, associada a versão/manifesto **448**. Contagens declaradas não atestam origem sem o JUnit original.

Não substituir a origem por:

- JUnit Linux EXP-04 (2.842, mas sem as 19 falhas Windows);
- JUnit BPQ-04 relacionado a 38 falhas;
- JUnit R1-FIX (1+3 PASS) ou da suíte cleanup (36 PASS/3 SKIP);
- matriz D2 ou nodeids sugeridos pelo nome.

## C1-A — Inventário de fontes (somente leitura)

Procurar prioritariamente no escopo local já autorizado e nos pacotes que o projeto designa como EXP-04: XML original, stdout/stderr/log, relatório resumo/JSON, comando da execução, arquivos de contexto da época, ambiente (Windows/Python/pytest/plugins), manifesto de 448 arquivos, commit e diff/untracked. Registrar **onde cada peça foi observada** em caminhos sanitizados, tamanho, data/hora/fuso e SHA-256. Não copiar nem expor dados sensíveis ao relatório compartilhável. Não recriar ou reconstruir os artefatos faltantes.

Se o JUnit original não estiver disponível, fazer inventário de **fontes ausentes** e solicitar ao usuário especificamente o JUnit/log/manifesto originais. Não marcar confirmado qualquer dos 19.

## C1-B — Reconciliação apenas com origem primária

1. Confirmar identidade da rodada: arquivo, executor/comando, versão, contadores XML e relatório. JUnit pode conter `testsuites` com suites hierárquicas; evitar somar o mesmo caso duas vezes.
2. Localizar os **19 `testcase` com `failure`**, capturando `classname`, `name`, parametrização e traceback, sem derivar `nodeid` real só por parecido com o código. Verificar IDs contra a versão exata de teste daquele baseline.
3. Localizar os **sete `skipped`** com motivo literal e estágio; não presumir que correspondam a POSIX ou symlinks.
4. Confrontar os 19 casos originais com WIN-01..19 e os nodeids propostos na matriz R2. Para cada ID: `OBSERVADO_COM_FONTE`, `PROVISORIO_SEM_FONTE`, `DIVERGENTE` ou `AMBIGUO`, com justificativa e referência exata. **Confirmação** exige assinatura/aceite do revisor; o Codex apenas propõe classificação.
5. Registrar duplicatas, casos extra, parametrização desigual, ausência de correspondência e diferença no código da época. Um ID histórico pode não corresponder 1:1 ao cenário prospectivo.
6. Manter os resultados Linux e cleanup em colunas separadas sem transferir PASS ou status DACL.

## C1-C — Custódia e confidencialidade

- Evidência bruta fica privada sob responsabilidade do custodiante; relatório compartilhável só lista metadados sanitizados.
- Derivados precisam registrar regra de remoção de campos, SHA do original e do derivado, responsável, data/fuso e autorização específica para extração/cópia, se necessária. Sem inventar uma cópia histórica que não foi coletada.
- A retenção de 90 dias aprovada pertence à **coleta B**; não aplicar automaticamente essa política a novas fontes históricas sem decisão sobre custódia.
- Não usar dados de clientes nem credenciais como insumo de testes prospectivos.

## Modelo mínimo de tabela para C1

`id,grupo,nodeid_proposto_R2,teste_original_exato,classe_original,parametro_original,arquivo_versao,xml_fonte_sha256,traceback_ref_sanitizada,estado_proposto,decisao_revisor,motivo,prova_ausente`

Iniciar 19 linhas como `PROVISORIO_SEM_FONTE`, `decisao_revisor=PENDENTE`, até evidência.

## Ponto de parada

Entregar inventário, matriz e lista ordenada de fontes faltantes. **Não executar** `extrair_junit_historico.py`, pytest, qualquer teste, script ou preflight nesta tarefa. O próximo avanço depende da apresentação/autorização das fontes e do aceite humano dos vínculos.
