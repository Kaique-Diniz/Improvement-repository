# EXP-04 / WIN19 — Preparação documental C1 + C2

**Data:** 18/11/2026  
**Natureza:** instruções para o Codex, sem execução e sem autorização de testes.  
**Fonte de planejamento:** documentos de encerramento do Portão B fornecidos na conversa, matriz e plano da preparação WIN19-R2, e registros da coleta B já revisados.

## Conteúdo

- `INSTRUCOES_CODEX_WIN19_C1_C2.md`: ordem consolidada ao Codex e limites.
- `C1_RECONCILIACAO_HISTORICA.md`: procedimento de localização, custódia e conciliação das fontes EXP-04, *sem inventar vínculo*.
- `C2_REVISAO_21_CENARIOS.md`: especificação de revisão dos cenários futuros, sem runner, fixture ou pytest novos.
- `MATRIZ_C2_PLANEJAMENTO_21.csv`: 21 subcasos planejados referidos aos 19 identificadores históricos; **não é resultado de teste**.
- `MANIFESTO_SHA256.json`: tamanhos e SHA-256 dos demais arquivos desta entrega.

## Estado preservado

R1-FIX: 470 arquivos segundo os relatórios Windows anteriores; manifesto referência SHA-256 `a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c`. Portão B encerrado documentalmente, com `prontidao_para_executar=false`. WIN-01 a WIN-19: `PROVISORIO_SEM_FONTE` e eixos funcional/nativo/DACL `NÃO_VALIDADO` até evidência independente. C/D/E e conversões reais bloqueados.

A instrução de preparação **não constitui autorização** para execução C/D/E, implementação do runner, publicação, alteração de ACL, elevação ou novos acessos ao Windows.
