# EXP-04 / WIN19 — Instrução consolidada ao Codex: C1 e C2

**Escopo autorizado por esta mensagem:** apenas **pesquisa documental, inspeção estática e preparação de especificações** em novos artefatos externos ao Git. Não executar código, testar, importar módulos com efeitos, coletar pytest, executar preflight ou criar nova candidata.

## Contexto que não pode ser promovido a homologação

1. R1-FIX validada em Windows no escopo controlado; suíte complementar: **36 PASS / 3 SKIP / 0 FAIL**. Dois skips POSIX e um symlink `WinError 1314` que deixou a rejeição do link **não validada**.
2. Portão B: coleta única de leitura encerrada e auditada; `prontidao_para_executar=false`; 470 hashes registrados antes/depois; 19 vínculos `PROVISORIO_SEM_FONTE`; DACL `NÃO_VALIDADO`. A autorização histórica `CHAT_20261118_PORTAO_B_UNICA` **foi consumida** e não pode ser reutilizada.
3. Histórico EXP-04 ainda não reconciliado: valores **declarados**, e não revalidados nesta etapa: 2.842 casos, 19 falhas, sete skips e versão/manifesto de 448 arquivos. JUnit original e motivos exatos dos skips não foram recuperados nas entregas anteriores.
4. Parsing Windows PowerShell 5.1 já realizado conforme registro nesta conversa: ENTRADA/WRAPPER/VERIFICADOR com **0 erros de parsing** e hashes conferidos. Esse resultado não demonstra execução nem DACL. Não repetir parsing nesta tarefa.

## Frente C1 — localização de fontes e reconciliação histórica

Seguir `C1_RECONCILIACAO_HISTORICA.md`.

- Fazer inventário **somente leitura** nas fontes locais de trabalho do projeto já autorizadas. Não vasculhar arquivos pessoais, credenciais, dados de clientes ou depósitos externos sem nova autorização.
- Identificar a execução EXP-04 exata, não o JUnit Linux sem falhas, não BPQ-04 de 38 falhas e não os JUnit dos 39 testes de cleanup.
- Requisitar fontes faltantes ao usuário como bloqueio explícito, indicando **nomes e finalidade**, sem inferir os 19 nodeids nem os motivos de sete skips.
- Se a fonte primária aparecer, registrar proveniência, SHA-256/tamanho, versão, data/fuso e cadeia de custódia; não alterar o original. Somente após conferência por revisor, atualizar *em documentação nova* estados dos vínculos por controle. Não escrever de volta na matriz original.
- Preservar simultaneamente testemunho histórico (o que foi relatado), evidência efetivamente observada (o que foi lido) e inferência (o que se propõe).

## Frente C2 — revisão dos 21 cenários independentes propostos

Seguir `C2_REVISAO_21_CENARIOS.md` e a matriz `MATRIZ_C2_PLANEJAMENTO_21.csv`.

- Revisar **21 subcasos propostos para 19 IDs**; os pares WIN-11 e WIN-13 geram dois subcasos cada.
- Para cada um, detalhar precondições, positivo, adversarial, sentinela, bytes completos, identidade de arquivos, retorno observável, falha/skip, evidência pré-asserção, custódia e eixo (funcional, nativo, DACL).
- Indicar precisamente lacunas WIN-03 (falha API nativa), WIN-14 (`gravar_pacote`, autoridade/recibo), WIN-16 (CLI/PDF/oráculo independente), WIN-18/19 (DACL somente como protocolo).
- Desenhar runner resiliente **em texto** (não criar `*.py`, `*.ps1`, fixtures executáveis ou comandos pytest) e o modelo de tratamento de crash/timeout/resíduo, sem limpeza destrutiva.
- Manter DACL D01–D10 `PARA_APROVAÇÃO`; não propor instalação ou mutação ACL nesta tarefa. Papel/objeto/operação e tokens distintos ficam em especificação futura separada.

## Restrições invioláveis

- Não modificar a candidata R1-FIX, seus 470 arquivos, suas worktrees, a sonda B, os pacotes e evidências anteriores.
- Não executar Python/pytest/PowerShell, parser/extrator histórico, preflight, testes nativos, acesso entre tokens, DACL, criação de symlink/hardlink/junction ou comandos de Git que escrevam; admitir apenas leitura estática dos documentos e metadados existentes no escopo autorizado.
- Não habilitar Developer Mode, privilégios de symlink, execução elevada, contas, políticas ou permissões; não mexer em `ExecutionPolicy`.
- Não produzir datasets privados nem anexar logs raw, segredos, caminhos pessoais, SID, SDDL, chaves, credenciais ou documentos de clientes.
- Sem commit, push, merge, publicação, alteração de produção ou desbloqueio de conversões reais.
- Se um dado não estiver na fonte, declarar `SEM_FONTE`/`NÃO_VALIDADO` e indicar a evidência necessária. `PASS` de cleanup não é homologação.

## Entregáveis e ponto de parada

1. `RELATORIO_C1_FONTES_E_LACUNAS.md` — fontes encontradas/ausentes, buscas restritas realizadas, provenance e diferenças frente às contagens históricas declaradas.
2. `MATRIZ_C1_VINCULOS_PARA_REVISAO.csv` — 19 IDs e campos originais/presumidos/observados separados; estados provisórios até validação do revisor.
3. `RELATORIO_C2_REVISAO_21.md` — revisão individual dos 21 casos, dependências, precondições, limitações e riscos.
4. `ESPECIFICACAO_RUNNER_C_SOMENTE_TEXTO.md` — contrato futuro de auditoria e custódia, sem código executável.
5. `DECISOES_E_PORTOES_C1_C2.md` — lacunas bloqueadoras e futuras autorizações independentes para implementar runner, executar C e testar DACL D; matriz D01–D10 permanece proposta.
6. Manifesto SHA-256 dos **documentos novos**; diff documental se comparar versões, sem diff de código de execução.

Entregar os artefatos e **parar**, sem executar o próximo portão. Nenhum desses entregáveis por si só altera `prontidao_para_executar=false`.
