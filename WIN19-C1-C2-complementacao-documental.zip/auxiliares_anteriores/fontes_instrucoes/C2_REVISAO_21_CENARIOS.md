# WIN19-C2 — Revisão estática dos 21 cenários propostos

**Natureza:** desenho e revisão textual, não implementação/execução. A R2 é uma proposta, não uma suíte homologada.

## Composição

- WIN-01..05: **5** controles de API/diagnóstico.
- WIN-06..14: **11** subcasos de links e origem (WIN-11 e WIN-13 em dois subcasos).
- WIN-15..17: **3** casos documentais e modo de operação.
- WIN-18..19: **2** protocolos de permissões herdados de testes POSIX/chmod; não são testes DACL efetivos.
- **Total estrutural: 21 subcasos, 19 IDs.**

## Campos obrigatórios de revisão de cada caso

`id/subcaso; contrato do componente (e limites); entrada positiva válida; precondição nativa e forma de demonstrá-la; adversarial; objeto/identidade; sentinelas e comparação integral de bytes; ordem de operações; API/erro real observável ou NÃO_OBSERVÁVEL; evidência persistida antes da asserção; retorno esperado; critérios PASS/FAIL/BLOQUEADO/SKIP; limpeza sem seguir links; risco de regressão; estado funcional/nativo/DACL separados; fontes e hash da versão.`

Regra universal: teste que não alcança a operação pretendida por falta de permissão, fixture inválida ou ausência de alias é **NÃO_VALIDADO**, não PASS. Nunca editar a expectativa para coincidir com resultado observado.

## Riscos concretos a revisar

### API — WIN-01..05

- WIN-01/05: flags sintéticas de diagnóstico ACL não comprovam acesso negado por DACL efetiva.
- WIN-02: usar alias 8.3 **real** do volume, preservar nome longo e bytes. Alias fabricado/normalizador mockado não prova Windows.
- WIN-03: distinguir comparação Unicode/ordinal real de falha de API; NUL é recusa pré-API. **Ramo de erro nativo permanece não demonstrado** sem instrumentação segura. Não usar ponteiros inválidos, mock de erro ou memória insegura para forçar PASS.
- WIN-04: hardlink com nome diferente e identidade de arquivo observada; escopo é comparador diagnóstico, não proibição universal no leitor de arquivos cujo contrato é ID+SHA.

### Links e origem — WIN-06..14

- WIN-06..10: verificar layout real de `RepositorioVinculosJSON` após controle positivo e revisão zero. Nenhum arquivo preexistente inesperado pode ser apagado para forçar a fixture. Lock residual, se previsto, deve ser regular e vazio; preservar qualquer estado anômalo.
- WIN-11: separar raiz sob Git e ancestral simbólico; um sucesso não demonstra o outro.
- WIN-12: preparar acervo/atesto/HMAC/fontes com fluxo real; trocar somente fonte sintética por link para conteúdo de bytes iguais; comparar árvore e sentinela externa.
- WIN-13: caso link interno e caso externo, considerar ordem de recusas (`FONTE_CONTEM_LINK` / `FONTE_FORA_DA_AREA_AUTORIZADA`) sem misturar DACL.
- WIN-14: controle positivo real `gravar_pacote`, releitura, autoridade HMAC e recibo, depois ataque sintético com novo ID. Preservar segredo apenas em custódia privada e provar que corpo/recibo antigos e sentinela externa não mudaram; não atribuir isolamento de tokens/DACL ao fluxo funcional.
- Symlink: limitação 1314 demonstrada no ambiente anterior; não ligar Developer Mode, elevar ou mudar privilégios. Junction não é substituta de symlink; planejar laboratório autorizado para a capacidade ausente.

### Documento/modo — WIN-15..17

- WIN-15: três PDFs sintéticos e opção explícita; gabarito extraído do leitor só comprova contrato de saída, não regra financeira independente.
- WIN-16: PDF sintético com documentos válidos e coordenadas definidas, CLI real em desenho futuro, controle positivo válido, conflito com retorno/recusa esperados. Gabarito declarativo independente do leitor; preservar auditoria CPF/CNPJ e insumos, impedir canônico/XLSX operacional indevido. Não homologar faturamento pelo CLI de validação.
- WIN-17: roundtrip JSON/bytes e semântica da auditoria; não é prova de DACL real.

### DACL — WIN-18/19

- O legado `chmod` não demonstra NTFS. Esses IDs ficam `NÃO_VALIDADO` até protocolo D por papéis/tokens distintos e política **D01–D10 PARA_APROVAÇÃO**. Não implementar contas, impersonação, alteração ACL ou comandos executáveis neste planejamento.
- A futura política exige modelo de ameaça, papéis O/U/A, objeto/operação (`READ_DATA`, `LIST`, `WRITE`, `CREATE`, `RENAME`, `DELETE`, `DELETE_CHILD`, `READ_CONTROL`, `WRITE_DAC`, `WRITE_OWNER`), herança, proprietário, root/filho, exceções, retenção e imposição real no fluxo do produto.

## Desenho textual do runner C (sem implementação)

1. Condições de início: autorização C futura específica, candidata e 470 hashes, hashes dos testes/dependências, Python 3.12 e import path explícito, área curta, inédita, fora de Git e de documentos privados.
2. Operação isolada e sequencial; nenhum pytest plugin extra, bytecode/cache/xdist. `basetemp` deve ser **inexistente** e não reutilizado, porque pytest pode apagar diretório existente.
3. Observador e JSON/JUnit em área separada do laboratório; registrar INÍCIO e capacidade real, snapshots e erros nativos antes de asserções, inclusive falha/timeout/crash. `GetLastError`/código Win32 só quando efetivamente observado e imediatamente capturado.
4. Sentinelas de bytes completos, file ID e snapshots da árvore; exclusão apenas das entradas criadas após prova de identidade e sem seguir reparse. Recursos não comprovados ou resíduos preservados para revisão, nunca `rmtree` indiscriminado.
5. Criação de derivações sanitizadas com cadeia SHA raw→derivado e metadados sem dados pessoais. Avaliar encerramento/limpeza separadamente do PASS do teste.
6. Fail-closed: hash divergente, import de origem errada, API inesperada, erro de sentinela, DACL não observada, limpeza incompleta ou capacidade ausente bloqueiam a promoção de status. Nenhum skip vira PASS.
7. Portão D separado: impor DACL dentro do fluxo do produto não pode ser substituído por ACL aplicada manualmente na fixture.

## Critério de aceite da **revisão C2**, não dos testes

- 21 subcasos inventariados, com 19 IDs e riscos/limites explícitos.
- WIN-03/14/16/18/19 com condição de aceite específica e lacunas formalizadas.
- Runner especificado apenas em texto; nenhum artefato executável criado.
- Pendente de origens C1 continua marcado, eixos funcional/nativo/DACL ficam `NÃO_VALIDADO`.
- Entrega preparada para revisão humana e futura decisão de portão. **Parar sem executar.**
