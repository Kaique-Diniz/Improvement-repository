# Registro do índice de recuperação informado pelo usuário em 18/11/2026

Este documento novo registra o conteúdo técnico fornecido em mensagem durante
C1/C2. Não são os bytes de Texto colado(6).txt nem do derivado sanitizado citado.
O SHA deste registro local é próprio e não pode ser substituído pelos SHAs relatados.

Fonte de biblioteca relatada: Texto colado(6).txt, transcrição de console,
SHA-256 declarado aba965b2eb20f1e75a7fae46aaf3e172ee2ef62173f8adaf5d94cd724a6cfc9c.
Bytes brutos permanecem na biblioteca do usuário e não foram recebidos aqui.
Derivado citado: EXP04_WINDOWS_UTF8_2842_LOG_TRANSCRITO_SANITIZADO.txt,
SHA-256 declarado 3b158c6ecabb1b1d69999d6690f2c44eb363d08794dafbfbfd5c2d0be66f6d65.
Os bytes desse arquivo também não foram anexados nesta mensagem.

Rodada relatada: EXP-04: SUITE COMPLETA UTF8,2842testes,2816PASS,19FAIL,7SKIP,
0ERROR,1aviso,555,30segundos, códigopytest1. Console afirma448hashes, mas não
apresenta SHA do manifesto efetivamente usado. Isso não identifica por si só a
versão física exata. O usuário distingue uma rodada anteriorEXP04 de2842/38falhas.
Não confundir essa rodada com o alvo2842/19/7 nem com BPQ04 de38falhas.

Local Windows referido: %LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619\completa-utf8.xml.
Arquivo original não recuperado nesta entrega. Estrutura de comando lembrada:
Python3.12, modoUTF8, bytecode/cache desabilitados, PYTHONPATH da candidata/src,
pytest quiet, traceback curto e JUnit. Comando literal/ambiente/pastas/versão ainda
precisam de log ou histórico autenticado, não de reconstrução por memória.

## Registros agrupados de skips, conforme mensagem

- SKIPPED [4] tests\exp04\test_reconstrucao.py:16: EXP04_SYMLINK_SEM_PRIVILEGIO_1314; controle nativo NAO_VALIDADO
- SKIPPED [1] tests\rules\test_authority.py:128: Permissões POSIX
- SKIPPED [1] tests\rules\test_authority.py:168: Permissões POSIX
- SKIPPED [1] tests\test_acl_evidence.py:140: symlink indisponível nesta plataforma

## Identificadores de falhas transcritos na mensagem (não JUnit observado)

- tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]
- tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]
- tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]
- tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]
- tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]
- tests/bbz/test_persistent_links.py::test_raiz_link_ancestral_e_git_recusados
- tests/bbz/test_persistent_links.py::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada
- tests/phase3/test_private_validation.py::test_canonicos_so_por_opcao_explicita_na_area_privada
- tests/phase3/test_private_validation.py::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida
- tests/phase3/test_protected_sources.py::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]
- tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[symlink]
- tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[permissao_fonte]
- tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[permissao_raiz]
- tests/test_acl_evidence.py::test_evidencia_sempre_hardcoded_false
- tests/test_acl_evidence.py::test_normalizacao_8_3_expande_nome_curto
- tests/test_acl_evidence.py::test_comparacao_de_caminho_e_case_insensitive_ordinal
- tests/test_acl_evidence.py::test_hardlink_e_rejeitado_na_comparacao_de_caminho
- tests/test_acl_evidence.py::test_evidencia_com_baseline_registra_artefato_mas_nao_autoriza
- tests/test_documents.py::test_auditoria_documental_persiste_em_json_protegido

## Limites preservados

Mensagem observada e registrada, não fonte primária validada. Falta XML original,
log persistido, comando literal, contexto, versão física/manifesto448 e seu SHA.
Não publicar brutos nem aplicar automaticamente retençãoB às novas fontes.
Não transferir resultados aos controles:19PROVISORIO_SEM_FONTE e eixosNÃO_VALIDADO.
Nenhum teste ou alteração de candidata/permissão/ACL foi autorizado pelo índice.
