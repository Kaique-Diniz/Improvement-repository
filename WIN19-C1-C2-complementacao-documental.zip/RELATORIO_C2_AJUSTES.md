# WIN19-C2 — ajustes documentais dos 21 cenários

18/11/2026. **Especificação revisada, não implementada nem executada.**
Base: matriz anexada reconstruída do diff, idêntica à matriz local por SHA-256;
parecer independente e instrução de complementação. Não é JUnit ou fonte histórica.
Continuam cinco casos API, 11 LINK, três MODO e dois CHMOD: 21 subcasos, 19 IDs.
CHMOD é o rótulo histórico preservado; não é uma estratégia de validação Windows.

Os cenários e auxiliares S1–S4 continuam os arquivos de proposta anteriores,
inalterados. P1–P6 são fontes de contrato R1-FIX lidas estaticamente; P7 é
billing_authority.py, agora também examinado. W14P é proposta não aplicada.
Versões, hashes e aliases estão no inventário de fontes desta complementação.
Os números de linha na matriz identificam o código anterior, não uma alteração nova.

## Critérios comuns, aplicáveis individualmente aos 21 registros

**R0 — evidência anterior ao julgamento.** Antes de qualquer asserção do ensaio,
persistir o evento externo correspondente: início, capacidade, positivo, estado
prévio, adversarial, operação, retorno/erro, comparação e encerramento. Se uma
operação levantar exceção ou o snapshot falhar, persistir o estado incompleto e
primeira falha, sem depender de uma asserção posterior. Não armazenar a única
cópia em tmp_path/basetemp. Observabilidade permanece propriedade A IMPLEMENTAR.

**I0 — identidade e sentinelas.** Guardar em memória bytes integrais e mapa da
árvore própria: nomes relativos, tipo, file ID/volume, links/reparse e existência
de diretórios, inclusive vazios. Conferir raiz e ancestrais, sem atravessar links.
Hash de arquivo não substitui identidade nem comparação integral. Qualquer objeto
inesperado fica preservado e bloqueia. Dados secretos não entram em eventos públicos.
Igualdade pré/pós demonstra apenas o estado observado: não comprova ausência de
leitura ou de escrita transitória revertida. Se essa ausência integrar o contrato,
a forma segura de observá-la precisará de revisão própria; permanece não demonstrada.

**L0 — encerramento.** Somente objetos criados exclusivamente pelo ensaio e com
identidade comprovada podem ser removidos. Não seguir link, apagar alvo, reutilizar
área, fazer limpeza recursiva irrestrita ou tocar residual histórico. Erro de
limpeza é separado do resultado funcional e não é sucesso de encerramento.

**J0 — classificação.** PASS futuro limitado à afirmação exercitada com positivo
válido, adversarial demonstrado e sentinelas intactas; FAIL para violação de contrato;
BLOQUEADO para fonte/fixture/observação insuficiente; SKIP apenas para capacidade
pontual efetivamente indisponível. WinError 1314 deve ser observado, não deduzido.
Erro genérico de fixture/timeout não comprova recusa. Cada subafirmação mantém eixo
funcional/nativo/DACL próprio. Todos estão NÃO_VALIDADO nesta entrega.

## WIN-01 — flags diagnósticas

Positivo: arquivo regular próprio, identidade real e comparação consigo; informar
ACEs rotuladas como sintéticas. Registrar coleta e duas flags de não autorização
antes do julgamento, sem serializar owner/caminho. Exigir bytes integrais intactos.
Adversarial é atribuir autoridade a um diagnóstico: as flags devem permanecer false.
Contraprova: resultado vazio/erro ou caminho não coincidente não satisfaz positivo.
Decisão textual: limitar PASS ao contrato do diagnóstico. Não é leitura/negação
DACL nem segurança entre contas. R0/I0/L0/J0 exigidos; execução pendente.

## WIN-02 — alias 8.3 real

Positivo: nome longo regular próprio, identidade e bytes conhecidos. Obter alias
real distinto naquele volume e demonstrar que alcança o mesmo objeto; registrar
GetShortPathNameW e erro imediato quando houver falha. Não fabricar alias.
Comparar alias com original, com outro arquivo de bytes iguais e com caminho
ausente: respectivamente equivalente, distinto e recusado. Registrar cada resultado
antes do julgamento. Contraprova: bytes iguais não tornam o segundo arquivo igual.
Alias inexistente ou indisponível deixa a subafirmação NÃO_VALIDADO. L0 preserva
ambos os alvos próprios. Não prova DACL nem todos os casos de normalização.

## WIN-03 — Unicode funcional e falha Win32 separados

Subafirmação funcional: os pares conhecidos da proposta são ação.TXT/AÇÃO.txt
(igual), a/b (menor), b/a (maior), duas strings com o mesmo emoji não BMP e sufixos
x/y (diferentes), par não BMP idêntico (igual) e ß/ss (diferentes). Não usar ordenação
linguística no lugar da comparação ordinal case-insensitive nativa.

Distinguir a API dos retornos do wrapper: CompareStringOrdinal retorna 1/2/3 para
menor/igual/maior, enquanto o wrapper normaliza para -1/0/+1. Zero DA API é falha,
não igualdade. Registrar a camada efetivamente observada; sem telemetria interna,
o resultado do wrapper não deve ser rotulado como retorno bruto de Kernel32.

Subafirmação de erro: exigiria falha REAL com assinatura de cinco argumentos,
buffers válidos, retorno nativo zero e GetLastError capturado imediatamente, com
origem comprovada. Não há estratégia segura demonstrada neste acervo para forçar
esse ramo. **Decisão: ramo de erro nativo NÃO_VALIDADO**, sem indução por ponteiro
inválido, mock, alteração de produção ou NUL recusado antes da API. NUL verifica
somente recusa pré-API. Não ajustar expectativa ao resultado. O caso continua um
subcaso com subafirmações separadas, sem inventar um 22º cenário.

## WIN-04 — identidade, equivalência e hardlink

Definidos três positivos/negativos dentro do mesmo subcaso:

1. Comparar o arquivo regular consigo: deve ser true, com file ID/volume e bytes
   conhecidos. Isso impede PASS por comparador que sempre retorna false.
2. Comparar caminho equivalente REAL demonstrado com o mesmo objeto: deve ser
   true. Se usar alias 8.3, exigir a capacidade de WIN-02; não inventar equivalência
   por conteúdo ou converter ausência dessa capacidade em PASS.
3. Criar segundo nome hardlink próprio: mesmo volume/file ID não zero, nlink
   compatível e bytes integrais iguais, mas nome normalizado distinto. O comparador
   diagnóstico deve retornar false. Outro arquivo de bytes iguais também é distinto.

Persistir identidade e comparação antes de avaliar. Se hardlink não se estabelecer,
ficará NÃO_VALIDADO, não falso PASS de recusa. Após eventual retirada SOMENTE da
entrada adicional própria, reler os bytes completos do original. I0/L0 obrigatórios.
Este contrato é do comparador diagnóstico; não impõe veto universal de hardlink
no leitor ID+SHA nem comprova origem documental ou DACL.

## WIN-05 — baseline declarado

Arquivo regular próprio e baseline de ACEs sintéticas são o positivo. Registrar
somente flags agregadas, com somente_heranca=true e autorização/leitor=false como
expectativa da proposta. Contraprova: baseline ausente/erro não prova a análise.
Comparar bytes integrais, sem imprimir estrutura ACL completa. Decisão: escopo é
comparação de dados declarados, sem AccessCheck ou política DACL efetiva. Persistência
prévia R0 e encerramento L0 continuam requisitos futuros, não resultados obtidos.

## WIN-06 — registro.json simbólico

Positivo: consulta real em raiz interna exclusiva retorna revisão zero. Documentar
layout antes do ataque; registro deve estar ausente, sem apagar objeto inesperado.
Criar link de arquivo para sentinela externa própria, provar identidade e alvo.
Registrar consulta recusada e erro seguro antes do julgamento; comparar toda árvore
e bytes do alvo. Contraprova: consulta inválida antes do link ou timeout não serve.
O ErroLeitura genérico só sustenta causalidade diferencial com positivo e operação
alvo alcançados. API Win32 interna NÃO_OBSERVÁVEL sem prova específica. Limpar só
entrada própria; 1314 pontual mantém controle nativo NÃO_VALIDADO.

## WIN-07 — chave.bin simbólica

Mesmo positivo de revisão zero, com chave ausente. Alvo é sentinela fabricada, não
credencial de usuário. Só a entrada chave.bin é modificada na preparação futura;
consulta deve recusar com árvore/alvo intactos. Registrar existência/identidade e
booleans, nunca bytes de chave, hash de credencial ou conteúdo de autoridade.
Contraprova: falha de contrato/lock não prova rejeição do link. Mesmas condições
R0/I0/L0/J0 de WIN-06; nenhuma conclusão de proteção HMAC por DACL.

## WIN-08 — escrita.lock simbólico

Após positivo revisão zero, admitir lock ausente ou regular/vazio próprio conforme
backend efetivamente usado; qualquer anomalia bloqueia. Se a troca exigir remoção,
só lock comprovadamente próprio, fechado e do estado previsto. Symlink aponta a
sentinela própria. Demonstrar recusa antes de abertura/truncamento indevido, bytes
integrais e árvore intactos. A versão de filelock precisa estar congelada: o backend
Windows lido pode truncar/remover lock no fluxo válido. Timeout não é prova de
rejeição causal, nem se altera o backend para obter PASS. Persistir resultado antes
da asserção de exceção. Link indisponível fica NÃO_VALIDADO; L0 não segue o destino.

## WIN-09 — diretório evidencias simbólico

Positivo revisão zero com evidencias ausente. Alvo externo próprio contém árvore
com arquivo e diretório vazio para detectar mudanças além de conteúdo. Criar link
de DIRETÓRIO, demonstrar categoria e recusa; snapshot I0 deve incluir diretórios,
não somente arquivos. Não apagar evidencias inesperado para fabricar a precondição.
Contraprova: link de arquivo, junction ou falha prévia de fixture não cobrem o caso.
Persistência R0, bytes integrais e remoção apenas do link próprio. Sem capacidade,
controle nativo NÃO_VALIDADO, sem mudar privilégios.

## WIN-10 — diretório cabecas simbólico

Positivo revisão zero com cabecas ausente, sem mexer em histórico já existente.
Adversarial é link de diretório para árvore própria; exigir recusa e nenhuma nova
entrada/modificação no alvo, inclusive diretórios vazios e metadados de identidade
I0. Não confundir a negativa mínima com validação de todo histórico assinado.
Erro genérico não causal, objeto inesperado ou link não criado bloqueiam. Registrar
antes do julgamento e preservar área inconclusiva, sem seguir/apagar o alvo.

## WIN-11-A — raiz sob Git sintético

Positivo de RepositorioVinculosJSON em área regular externa ao Git, revisão zero.
O desenho futuro cria um Git sintético separado; só após configuração e raiz
comprovadas, tenta construtor no filho e exige recusa sem criá-lo.

**Ambiente Git proposto:** caminho absoluto do binário e hash aprovados; ambiente
filho por allowlist mínima, sem herdar variáveis GIT_* nem redirecionamentos como
GIT_DIR, GIT_WORK_TREE, GIT_COMMON_DIR, GIT_INDEX_FILE, GIT_OBJECT_DIRECTORY,
GIT_ALTERNATE_OBJECT_DIRECTORIES, GIT_CONFIG_COUNT/PARAMETERS, GIT_TEMPLATE_DIR,
GIT_EXEC_PATH ou mecanismos equivalentes. Os únicos ajustes de Git serão exclusivos
desse processo futuro: config de sistema desabilitada, config global apontando a
arquivo vazio próprio e config local nova; template e hooks vazios próprios,
sem includes ou rede. Não mudar HOME, configuração global ou máquina. Aprovar
allowlist Windows necessária, diretório de trabalho e caminho dos temporários.

O futuro observador registra início/configuração sanitizada, retorno, identidade
metadata prevista e recusa causal antes das asserções. Comparar sentinela e árvore
externa própria, confirmar nenhum filho criado. Objeto Git inesperado/danificado
bloqueia o laboratório, sem classificá-lo como externo seguro. Não generalizar
este cenário init para todos os bare/worktrees danificados do produto. Nenhum Git
foi inicializado ou executado por esta revisão documental.

## WIN-11-B — ancestral simbólico

Prever DOIS positivos independentes, em raízes regulares próprias: repositório
consulta revisão zero; aplicação é construída com configuração sintética válida
sem iniciar servidor/rede e encerra seu contexto próprio. Evidência de sucesso,
área criada prevista e identidade de cada um; falha no positivo bloqueia esse eixo.

Depois criar ancestral simbólico para destino próprio e tentar ambos construtores
em filhos separados. Esperar recusa do repositório e AREA_PRIVADA_NAO_PODE_SER_LINK
da aplicação; registrar resultados individualmente e ausência de novos filhos.
Comparar sentinelas/árvore do alvo. Não permitir que uma recusa curta-circuite a
observação da outra. Sem symlink, ambos controles dependentes permanecem
NÃO_VALIDADO. Não prova HTTP, sessão, DACL ou a condição Git de WIN-11-A.

## WIN-12 — link de bytes idênticos em acervo válido

Positivo real: fontes próprias, vínculo/atesto/HMAC válidos, gravação e leitura
regular, revisão um. Registrar contrato e snapshots antes da troca única da fonte
por link para alvo próprio de bytes integrais iguais. Exigir recusa tanto de ler
fonte quanto de consultar/reabrir o acervo, com registro/chave/cabeças e alvo sem
alteração. Ambos resultados persistidos mesmo se o primeiro falhar. Não publicar
chave ou campos pessoais. Hash igual não substitui comprovação do link ou causalidade;
falha de schema/credencial/lock não é PASS. R0/I0/L0 e capacidade real obrigatórios.

## WIN-13-A — link interno da fonte protegida

Positivo: ID autorizado e mesmo hash leem arquivo regular interno. Adversarial:
mapa desse ID aponta a link interno real, de alvo próprio. Esperar FONTE_CONTEM_LINK,
sem abrir caminho alternativo que contorne a validação. Persistir código de
aplicação, estado alcançado e bytes integrais antes do julgamento. Não rotular
esse código como erro Win32 observado. Conteúdo igual não autoriza contornar a
regra. Limpeza só do link; sem capacidade, NÃO_VALIDADO.

## WIN-13-B — link externo da fonte protegida

Positivo interno equivalente ao anterior; ataque aponta por link a sentinela
própria fora da raiz autorizada. A ordem estática do leitor prevê
FONTE_FORA_DA_AREA_AUTORIZADA antes da recusa específica de link. Não trocar código
para coincidir com observado. Comparar alvo e controle interno integralmente;
registrar código e nenhuma alteração externa. Não usar junction substituta se
symlink faltar. A recusa da fronteira não demonstra política DACL.

## WIN-14 — revisão integral de W14P e autoridade

W14P tem dois blocos: cria before_authority após o positivo e compara authority.raiz
após a recusa; soma authority_unchanged ao boolean agregado e o registra. Isso
amplia a cobertura planejada além de repo.raiz e repo.ancoras. **Não foi aplicado.**

A leitura de P7 mostra autoridade com chave.bin, operadores.json/concessões e
policies de autorização histórica. P4 coloca recibos/locks em simulacoes-<id>
dentro da raiz da autoridade. A raiz dos corpos é separada. O positivo cria pacote
mínimo real, autoriza, grava corpo e recibo, verifica assinatura, hash, ator e relê.
Somente DEPOIS desse positivo se congela a referência; a política histórica criada
legitimamente pelo positivo deve integrar o snapshot. O ataque usa novo ID válido,
com contrato conferido antes de trocar apenas a fonte por link.

| Fronteira | Prova futura de preservação após recusa |
|---|---|
| Fontes e sentinela externa próprias | Bytes integrais, identidade e árvore sem escrita/leitura indevida observável |
| Corpo positivo em repo.raiz | Mesmo conteúdo/identidade e nenhum corpo do ID adversarial ou temporário novo |
| Recibos/locks em repo.ancoras | Recibo positivo/assinatura/associação preservados; nenhum recibo adversarial |
| Chave e concessões da autoridade | Bytes comparados somente em memória, sem serialização ou hash de credencial público |
| Policies e demais entradas da autoridade | Mesmos nomes, tipos, diretórios inclusive vazios, bytes e identidades; nenhuma concessão/política/ponta criada ou alterada |
| Credencial da fixture | Conservada em memória e usada só no fluxo autorizado; não é identidade Windows distinta |

Limites concretos de W14P: o helper snapshot atual guarda APENAS mapa de arquivos
regulares→bytes; ignora existência de diretórios vazios e não registra file ID,
volume, identidade da raiz/ancestrais ou metadados de política. Também executa
asserts internos e lê antes de garantir persistência do diagnóstico. Um diretório
vazio novo ou substituição por arquivo de bytes iguais pode escapar dessa igualdade.
O snapshot não é prova de ausência de leitura, proteção DACL ou estado em memória.

**Decisão:** aceitar somente a intenção de expansão; complementar I0/R0 no desenho
antes de revisar implementação futura. Exigir congelamento de todas as fronteiras,
observações independentes sem curto-circuito e diagnóstico de snapshot incompleto.
Na ordem estática de gravar_pacote, conferir_fontes precede _guardar/autorização;
logo recusa do link nessa fase não deveria emitir corpo/recibo ou nova política.
Isso é expectativa de contrato, não resultado nativo. Exigir código app
CAMINHO_COM_LINK_NAO_PERMITIDO e ausência desses efeitos com positivo válido.

Booleans seguros por fronteira entram no derivado. Segredos ficam somente em
memória/custódia privada autorizada; nem dicionário completo, hashes de segredo,
repr de credencial ou traceback com locals nas evidências compartilháveis.
Autoridade HMAC de aplicação não equivale a IAM, DACL ou negação entre tokens.

## WIN-15 — opção explícita de canônicos

Positivo: três PDFs sintéticos estruturalmente válidos, identificados e com bytes
guardados. Duas saídas novas: sem opção deve haver zero canônicos; com opção
explícita, três; ambas sem homologação. Registrar contagens e preservação antes
das asserções, não só hash final. O gabarito derivado do leitor pode servir ao
contrato da opção, mas não é oráculo financeiro independente. Erro do positivo
ou comparação vazia bloqueia. Não comprova 30 colunas, faturamento ou DACL. L0 e
custódia externa ao basetemp preservam diagnósticos.

## WIN-16 — quatro planos distintos e observação durável

1. **CLI:** positivo de PDF posicionado com um titular/documento sintético válido
   deve retornar zero/comparacao_confere. Ataque com dois documentos sintéticos
   válidos e conflitantes deve retornar dois/revisao_humana. Dois isolado pode ser
   bloqueio: não é prova do conflito.
2. **JSON/documentos:** oráculo declarativo produzido antes da leitura, a partir
   da tabela de coordenadas, valores fabricados e regras publicadas de IDs. Não
   copiar resultado do leitor para obter igualdade. Conferir contagens um/um/zero,
   zero divergências, os dois tipos de documento na mesma ocorrência, retenção e
   homologado_producao=false; comparar integralmente insumos e gabarito.
3. **DTO:** a proposta usa a pessoa do gabarito, não objeto retornado pelo CLI.
   Sua recusa REVISAO_HUMANA é uma subprova isolada e deve ser rotulada assim.
   Uma futura prova com objeto materializado pelo leitor exigiria desenho próprio,
   origem de objeto demonstrada e revisão; não está implementada por este texto.
4. **Exportação operacional:** o CLI de validação não exporta. Ausência de XLSX
   ou canônico inesperado é guarda desse fluxo, não homologação de conversão nem
   integração ponta a ponta. Conversões reais seguem bloqueadas.

Antes de iniciar o filho, persistir evento. O desenho futuro direciona stdout/stderr
continuamente a arquivos exclusivos de custódia fora do basetemp, com checkpoints;
não aguarda subprocess.run terminar para salvar a única cópia. Em timeout/crash,
preservar bytes já produzidos e último estado, encerrar apenas o filho próprio,
marcar relatório incompleto, sem interpretar ausência de JSON como recusa segura.

Ao receber JSON/auditoria, persistir primeiro observações agregadas do status,
contagens, ocorrência e integridade, inclusive chave ausente/JSON ilegível, depois
avaliar asserções. Raw sintético documental fica privado; derivados não revelam
valores de documentos ou caminhos pessoais. Saída sem esses dados também é condição
de aceite. Falha de persistência bloqueia. Nenhum timeout/crash foi ensaiado agora.

## WIN-17 — auditoria JSON

Positivo com ocorrência sintética válida, escrita e releitura pelo contrato real.
Congelar bytes UTF-8 canônicos esperados e modelo antes de escrever. Registrar
escrita/releitura/erro antes de comparar os bytes completos e semântica. Falha de
schema ou arquivo vazio não prova segurança. Preservar JSON próprio e evento durável;
limpeza só após custódia. Sem prova de DACL, atomicidade concorrente ou proteção
NTFS derivada de modo 0600.

## WIN-18 — protocolo DACL da fonte

Sem implementação/execução. Política D01–D10, objeto fonte e ancestrais, direitos
por papel O/U/A, tokens comuns distintos e fluxo que impõe a política precisam
ser aprovados. Positivo O e negativo U seriam provas diferentes, com handles
fechados e sentinelas integrais. chmod, mesmo token, sharing violation ou skip
não são negação DACL. Sem política/laboratório, BLOQUEADO, DACL NÃO_VALIDADO.
Não transformar os skips de rules/authority em aprovação deste controle.

## WIN-19 — protocolo DACL da raiz

Mesmo bloqueio independente, com raiz e filhos, criação/replace, herança,
proprietário, listar/ler/escrever/criar, RENAME, DELETE e DELETE_CHILD. Direito
negado no pai não implica direito negado por caminho conhecido ao filho. Política
manual na fixture não prova integração do aplicativo. Nenhuma conta, ACL ou token
foi criado/usado nesta revisão. Placeholder não permite PASS e continua CHMOD
apenas como grupo histórico. D01–D10 permanecem PARA_APROVAÇÃO.

## Conclusão documental

As cinco prioridades receberam decisões textuais: WIN-03 mantém ramo de erro
nativo pendente; WIN-04 define positivo para evitar always-false; WIN-11 define
isolamento e positivos separados; WIN-14 amplia desenho de snapshots, sem aplicar
W14P; WIN-16 separa quatro planos e preservação futura de saída parcial. Viabilidade,
implementação e resultados de todas essas propriedades permanecem pendentes.
Os 21 cenários ficam funcional=nativo=DACL=NÃO_VALIDADO; 19 vínculos provisórios;
prontidao_para_executar=false. Parar para revisão, sem implementar nem executar.
