# WIN19-C1/C2 — complementação para revisão independente

18/11/2026, America/Sao_Paulo. Revisão DOCUMENTAL, não autorização operacional.
Entrega nova externa ao Git. As versões anteriores e a candidata estão preservadas.

## Documentos principais

1. [RELATORIO_C1_COMPLEMENTAR.md](RELATORIO_C1_COMPLEMENTAR.md) — classes de fonte,
   reexame local e lista exata/limites das peças a recuperar no Windows.
2. [MATRIZ_C1_ATUALIZADA.csv](MATRIZ_C1_ATUALIZADA.csv) — 19 vínculos provisórios,
   zero confirmados, decisões PENDENTE, campos primários SEM_FONTE.
3. [RELATORIO_C2_AJUSTES.md](RELATORIO_C2_AJUSTES.md) — revisão individual dos
   21 cenários e decisões WIN-03/04/11/14/16.
4. [MATRIZ_C2_ATUALIZADA.csv](MATRIZ_C2_ATUALIZADA.csv) — identidades/grupos
   preservados e critérios complementados, sem transformar planejamento em PASS.
5. [ESPECIFICACAO_RUNNER_C_REVISADA.md](ESPECIFICACAO_RUNNER_C_REVISADA.md) —
   somente texto, incluindo ambiente, eventos duráveis, snapshots e interrupção.
6. [NOTA_DESVIO_PROCESSUAL.md](NOTA_DESVIO_PROCESSUAL.md) — comando exato não
   recuperado; desvio declarado, com efeitos não demonstrados; nenhum replay.
7. [PENDENCIAS_E_DECISOES.md](PENDENCIAS_E_DECISOES.md) — lacunas e autorizações
   independentes para revisão, implementação, C, DACL e homologação.
8. [MANIFESTO_SHA256](MANIFESTO_SHA256) — SHA-256, bytes e nome relativo de cada
   arquivo efetivamente entregue nesta versão, exceto o próprio manifesto.

## Complementos de integridade e rastreabilidade

- [INTEGRIDADE_16_AUXILIARES.csv](INTEGRIDADE_16_AUXILIARES.csv): os 16 ausentes
  do ZIP foram localizados, seus hashes originais conferem e cópias literais são
  entregues em auxiliares_anteriores/, preservando nomes e bytes.
- auxiliares_anteriores/MANIFESTO_SHA256.sha256: cópia literal do manifesto histórico
  da entrega anterior, para rastrear os hashes originais. É documento de referência,
  não o inventário desta versão. Sua lista antiga inclui seis arquivos disponíveis
  no ZIP anterior, que não são duplicados nessa pasta. O manifesto histórico JSON
  e o manifesto de instruções também conservam seus escopos originais.
- [INVENTARIO_FONTES_COMPLEMENTAR.csv](INVENTARIO_FONTES_COMPLEMENTAR.csv): nomes,
  tamanhos, hashes e limites de origem das fontes usadas. Hash de código referenciado
  não significa que ele foi executado ou validado nesta revisão.
- [CRITERIOS_C2_COMPLEMENTARES.csv](CRITERIOS_C2_COMPLEMENTARES.csv): critérios por
  subcaso usados na atualização documental; nenhum código de teste gerado.
- fontes_recebidas/: instrução atual, parecer e matriz reconstruída, cópias literais.
  O texto colado recebe nome descritivo; os bytes e SHA são os mesmos do anexo.
- [Manifesto 448 observado](fontes_observadas/VERSAO_EXP04_SHA256.json): cópia do
  artefato local, permitindo conferir o SHA 19f936...; não prova seu uso no Windows.

## Diferenças da versão

[DIFF_COMPLEMENTACAO_DOCUMENTAL.patch](DIFF_COMPLEMENTACAO_DOCUMENTAL.patch) compara
os dois relatórios, as duas matrizes, a especificação e decisões com a entrega
anterior; também identifica os novos documentos de apoio. Não contém patch de
produção, runner ou fixture. Cópias literais não geram diffs: seus nomes/hashes
são relacionados nos inventários. O manifesto final é produzido depois do diff e
não aparece nele, para evitar dependência circular de hash. Os anexos recebidos
são fontes, não alterações propostas pelo agente.

A matriz reconstruída do diff foi comparada diretamente à matriz anterior local:
bytes idênticos, SHA a1fb7a7d52e74e42cb7890ba6d39925fea3a3629deb85b3f33564eec01600459.
A atualização atual é documento NOVO e terá outro SHA. A comparação de igualdade
não autentica os 19 casos históricos nem vira evidência independente de execução.

## Situação preservada e parada

C1 parcial: JUnit/log/contexto originais e manifesto efetivamente usado ainda não
comprovados. Os sete skips continuam agrupados em fonte secundária. C2 especificada,
com lacunas técnicas e de implementação explícitas; W14P permanece não aplicada.

prontidao_para_executar=false; autorizacao_testes=PENDENTE;
WIN01–WIN19=NÃO_VALIDADO; DACL=NÃO_VALIDADO;
C/D/E=BLOQUEADOS; CONVERSOES_REAIS=BLOQUEADAS.

Nenhum Python, pytest, preflight, parsing PowerShell, runner, ensaio Windows/DACL,
fixture executável ou candidata foi executado/criado nesta complementação. Nenhuma
permissão, conta, política, produção ou candidata anterior foi modificada. Sem
commit, push, merge, ZIP novo ou publicação. Parar para revisão independente.
