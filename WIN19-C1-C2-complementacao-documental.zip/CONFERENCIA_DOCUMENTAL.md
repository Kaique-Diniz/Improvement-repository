# Conferência desta complementação — 18/11/2026

Conferência de arquivos/texto/metadados, não teste de aplicação, parser PowerShell,
preflight ou ensaio de segurança. Nenhuma propriedade do runner foi executada.

| Item documental | Resultado observado |
|---|---|
| Anexo matriz reconstruída versus matriz anterior local | Mesmos bytes e SHA a1fb7a7d52e74e42cb7890ba6d39925fea3a3629deb85b3f33564eec01600459 |
| Auxiliares ausentes da amostra de sete arquivos | 16 de 16 acessíveis e com SHA original correspondente; cópias byte a byte |
| Matriz C1 atualizada | 19 registros/19 IDs, 25 colunas; todos provisórios, decisões PENDENTE, zero confirmações |
| Matriz C2 atualizada | 21 registros/21 subcasos/19 IDs, 31 colunas; API 5, LINK 11, MODO 3, CHMOD 2 |
| Eixos C2 | Todas as 21 linhas funcional/nativo/DACL NÃO_VALIDADO, vínculos provisórios e decisões PENDENTE |
| Relatório C2 | 21 seções individuais, preservando WIN-11-A/B e WIN-13-A/B |
| Manifesto 448 copiado | 448 entradas, baseline 770d062..., 50.698 bytes e SHA 19f936...; uso Windows não comprovado |
| Fontes registradas no inventário complementar | Hashes novamente comparados sem divergência |
| Manifesto completo da entrega anterior | Todos os arquivos ali referenciados continuam conferindo no diretório original |
| Artefatos executáveis novos | Nenhum .py, .ps1, .exe ou .sh na entrega |
| Conteúdo compartilhável | Varredura textual sem padrões de tokens, chaves privadas, CPF/CNPJ formatados ou caminhos de perfil; não é atestado forense |

Esses resultados conferem a consistência e disponibilidade DOCUMENTAL. Não são
execução dos controles, aceite de vínculos, prova de segurança, DACL ou auditoria
forense do processo inicial. Hash idêntico não comprova origem da execução Windows.
Não foram recontados testcase originais ou reexecutados os 470 hashes da candidata.

Nenhum Python, teste, preflight, PowerShell, acesso entre tokens, Git de ensaio,
criação de link ou mudança de privilégio/ACL foi executado nesta etapa. Operações
foram leitura estática, cópia de documentos, comparação, diff e hash em arquivos
novos. Nenhum original foi editado, removido, resetado ou substituído. Sem commit,
push, merge ou publicação. C/D/E e conversões permanecem bloqueados.

O manifesto raiz MANIFESTO_SHA256 lista apenas os arquivos efetivamente presentes
nesta entrega, com bytes e SHA, excluindo somente a si próprio. Manifestos arquivados
em auxiliares_anteriores/ preservam seus escopos antigos e não são o manifesto novo.
O hash do manifesto raiz é informado na conversa, sem dependência circular.
