# Nota — desvio processual declarado, com efeitos não demonstrados

18/11/2026. Natureza estritamente documental. Não houve repetição da operação.

## Ocorrência e classificação

A entrega anterior declarou uso inicial de Python padrão para abrir/ler o ZIP de
instruções, antes de identificar sua vedação expressa. O parecer independente
registrou a ressalva. Classificação mantida: **desvio processual declarado, com
efeitos não demonstrados**. A explicação de desconhecimento inicial da vedação
não elimina a ocorrência. Não descrevê-la como ausência absoluta de execução de
ferramenta, nem presumir dano ou falha funcional de segurança sem evidência.

## Comando e finalidade

**Comando exato: SEM_FONTE nas peças documentais disponíveis nesta revisão.**
Não há nelas argv, heredoc/stdin integral, caminho/versão exatos do executável,
ambiente ou log original da chamada. Não foi reconstruído um comando aproximado,
consultado histórico pessoal ou executado novamente Python para fabricar prova.

A finalidade relatada foi leitura do arquivo de instruções recebido, sem propósito
de testar/importar o produto. O objeto identificado é o ZIP de 11.242 bytes em
attachments/d17cdea2-637b-4c7b-bb73-b0a2e4d1827a/EXP04_WIN19_C1_C2_INSTRUCOES.zip,
SHA-256 e78f64d12f55671db5aa6ca8200000aab41d7df3914cf5de51f958d7ea2e2877.
Seu hash é referência documental registrada, não registro do que o processo fez.
Não copiar o comando de uma operação posterior e atribuí-lo ao processo inicial.

## Arquivos relacionados e o que se pode afirmar

O ZIP contém C1_RECONCILIACAO_HISTORICA.md, C2_REVISAO_21_CENARIOS.md,
INSTRUCOES_CODEX_WIN19_C1_C2.md, LEIA_ME.md, MATRIZ_C2_PLANEJAMENTO_21.csv e
MANIFESTO_SHA256.json. As cópias documentais foram posteriormente preservadas e
hashes conferidos; não há neste material trilha por membro que prove exatamente
quais foram acessados pela chamada Python inicial ou a ordem dessas leituras.
Não foram produzidos arquivos adicionais para reconstituir tal trilha.

| Afirmação | Base disponível | Limite |
|---|---|---|
| Houve Python inicial para leitura do ZIP | Declaração em RELATORIO_C1_FONTES_E_LACUNAS.md e conferência anterior | Admissão documentada; comando bruto ausente |
| Finalidade de leitura, antes da identificação da vedação | Relato do agente, reiterado no parecer | Não equivale a tracing independente de syscalls/efeitos |
| Uso posterior de utilitários de arquivo/texto/hash, sem novos testes | Relato da entrega e documentos gerados | Não reconstitui ambiente do processo inicial |
| Cópias documentais e hashes existentes | Arquivos acessíveis e comparações desta revisão | Provam estado observado, não ausência histórica de toda mutação |
| Candidata não editada intencionalmente naquela tarefa | Declaração e hashes de fontes examinadas | Não é auditoria forense integral do processo Python inicial |

## Efeitos conhecidos e não demonstrados

Conhecido documentalmente: declaração de execução da ferramenta de leitura e
produção posterior de relatórios/cópias documentais. Não há evidência primária
nesta entrega de alteração da candidata, privilégio, ACL, documento privado ou
execução de teste por essa chamada inicial. **Ausência dessa evidência não é prova
forense de ausência de efeitos.** Também não há base para atribuir automaticamente
qualquer alteração posterior ao processo inicial.

Não demonstrados: leituras/escritas completas do processo, imports efetivos,
cache/temporários, chamadas de rede, identidade/ambiente do executável e comparação
integral de filesystem imediatamente antes/depois. Nenhum desses efeitos é afirmado
como ocorrido ou como impossível. A simples existência atual de cópias íntegras
não resolve essa lacuna temporal.

## Ações posteriores e encerramento

Segundo o registro anterior, após conhecer a vedação o uso de Python cessou e a
continuação usou utilitários estáticos, sem pytest/preflight/ensaio Windows/DACL.
Nesta complementação não houve Python, replay, teste, importação de produto ou
busca em históricos pessoais. Não foi tentada a coleta B novamente. Nenhuma
correção no produto ou no ambiente decorre desta nota.

Se houver registro bruto da chamada original, sua recuperação autorizada pode
complementar comando/efeitos em documento novo, mantendo esta nota e a cadeia de
custódia. Sem tal fonte, manter SEM_FONTE e a classificação acima. A ocorrência
não confirma nenhum dos 19 vínculos, não aprova DACL e não abre portão de execução.
