# EXP-04 / WIN19 — Parecer independente da entrega documental C1/C2

**Data:** 18/11/2026  
**Fonte auditada:** `WIN19-C1-C2-7-arquivos.zip`, recebido nesta conversa.  
**Decisão:** ACEITA COMO PREPARAÇÃO DOCUMENTAL, COM RESSALVAS. C1 permanece parcial; C2 é uma especificação revisável, não aprovação de implementação/execução. `prontidao_para_executar=false`. DACL, C/D/E, conversões e publicação BLOQUEADOS.

## 1. Verificações de integridade realizadas

- ZIP: 30.656 bytes, SHA-256 `e8b4e77799dcbddd6e2f70b44e796077e344e27f4f6bd76bf62145b6aba86afe`. Sete entradas; CRC íntegro; todos os membros legíveis. Não foi executado código da entrega.
- `MANIFESTO_SHA256.sha256`: SHA-256 `5594fab96c477572d74527180f8f5e70b1780b332ba71c4772d019778ca6917c`, idêntico ao declarado pelo remetente.
- O manifesto enumera **22 outros arquivos**. **Seis** deles estão presentes no ZIP e conferem por SHA-256; os **16 restantes não foram anexados**. O sétimo membro é o próprio manifesto, cujo hash foi conferido externamente com o valor declarado.
- O diff documental contém 22 linhas adicionais (cabeçalho e 21 casos) e 22 removidas. Foi possível reconstruir exatamente os bytes da `MATRIZ_C2_REVISAO_21.csv` por meio das linhas positivas e LF final: SHA-256 `a1fb7a7d52e74e42cb7890ba6d39925fea3a3629deb85b3f33564eec01600459`, igual ao manifesto. A versão reconstruída é um DERIVADO, não uma nova fonte independente.
- A matriz C2 derivada possui **21 registros, 19 IDs** (WIN-11 e WIN-13 duplicados por subcasos), grupos **API=5, LINK=11, MODO=3, CHMOD=2**. Todas as 21 linhas contêm `funcional=nativo=DACL=NÃO_VALIDADO`, `vinculo_historico=PROVISORIO_SEM_FONTE`, `decisao_revisor=PENDENTE`.

## 2. Resultado por documento

### C1 — `RELATORIO_C1_FONTES_E_LACUNAS.md`

**Aceito como investigação parcial.** O relatório declara localização de manifesto com 448 entradas no baseline `770d062d29c4361d6932592883df9339bb4089bc`, SHA-256 `19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb`. Não foi possível verificar o manifesto de 448 neste ZIP; seu hash e conteúdo são declarações documentais desta entrega. O vínculo do manifesto com a rodada Windows original não está provado.

O JUnit original `completa-utf8.xml` no caminho relatado `%LOCALAPPDATA%\EXP04-Auditoria\Completa-UTF8-20261117-094619` não foi anexado. O índice secundário recebido reporta 2.842 testes, 2.816 PASS, 19 FAIL, sete SKIP e zero ERROR, mas não substitui XML/log/ambiente primários. Os 19 vínculos permanecem corretamente `PROVISORIO_SEM_FONTE`; `decisao_revisor=PENDENTE`. A matriz C1 CSV não está nos sete arquivos, logo as suas colunas/19 linhas não puderam ser inspecionadas diretamente.

O relatório declara inventário de 142 XML e 11 ZIPs com 27 entradas XML; os inventários não vieram nesta amostra e essas cardinalidades não foram independentemente recontadas.

### C2 — `RELATORIO_C2_REVISAO_21.md`, diff e matriz reconstruída

**Aceito como revisão estática prospectiva, com pendências de desenho.** A contagem e a estrutura da matriz foram verificadas diretamente. Nenhum caso foi executado ou homologado. Pontos de atenção preservados:

- WIN-03: a rejeição de NUL antes de API não demonstra ramo de erro nativo; não fabricar falha de Win32.
- WIN-04: falta positivo de identidade/próprio caminho para evitar falso PASS por comparador sempre falso.
- WIN-06–10/12/13: positivos válidos, sentinelas integrais, causalidade de recusa, capacidade de symlink, não seguimento do alvo e limpezas restritas precisam ser observáveis.
- WIN-11: isolamento de ambiente/configuração ao invocar Git; construtores de repo e app devem ter positivos e resultados separados.
- WIN-14: proposta W14P de snapshot integral da autoridade NÃO APLICADA; sua eventual adoção exige revisão própria, sem segredo em resultado compartilhável.
- WIN-16: distinguir CLI/JSON/DTO/exportação operacional e persistir saída parcial de subprocesso em timeout; oráculo independente do leitor.
- WIN-18/19: são protocolos DACL bloqueados, não testes efetivos; `CHMOD` não comprova DACL.

### `ESPECIFICACAO_RUNNER_C_SOMENTE_TEXTO.md`

**Aceita como contrato conceitual, não como autorização de implementação.** Há separação entre evidência externa e temporários, persistência antes das asserções, hashes e imports congelados, captura imediata de erro nativo, execução sequencial, propriedade exclusiva/limpeza fail-closed, tratamento de timeout/crash e classificação separada dos eixos funcional/nativo/DACL. Falta revisar a viabilidade técnica concreta e autorizar um diff futuro; o texto não implementa nem prova essas propriedades.

### `DECISOES_E_PORTOES_C1_C2.md`

**Coerente.** As pendências C1-01..06 e C2-01..11 e D01..D10 permanecem abertas e definem autorizações independentes para revisão, implementação do runner, execução C e ensaios D. A única autorização do Portão B continua consumida.

## 3. Ressalva de procedimento: Python antes da leitura da vedação

O Codex declarou ter usado o Python padrão apenas como leitor de ZIP antes de ler a restrição expressa, e não ter repetido o uso posteriormente. Essa declaração **não é execução de pytest, da sonda, nem prova de mutação da candidata**, mas o uso inicial de Python ocorreu e não deve ser descrito como ausência absoluta de execução de ferramenta. Este pacote não inclui comando exato, trilha de efeitos ou atestado independente de ausência de alterações. Registrar como **desvio processual declarado, de efeito não demonstrado**, sem presumir dano, sem retestar e sem converter em achado de segurança funcional. Solicitar nota complementar estritamente documental se o registro formal exigir detalhe do comando.

## 4. Limites e próximos portões

- **C1 permanece parcial:** recuperar o XML Windows original, log/stdout/stderr, comando/contexto e manifestação comprovada da versão 448; manter 19 vínculos provisórios até validação humana.
- **C2 aceita documentalmente:** o conteúdo é útil para planejar. Antes de autorizar IMPLEMENTAÇÃO do runner, decidir e revisar as lacunas WIN-03/04/11/14/16, a persistência do observador, a identidade e a limpeza dos objetos; congelar hashes.
- **Evidência não recebida:** 16 arquivos auxiliares não foram auditados, inclusive a matriz C1 original e os inventários. A auditoria integral da entrega local requer esses arquivos, ou atestado local controlado de sua integridade, sem expor material privado.
- **Nenhum desbloqueio:** não executar preflight B novamente, testes C, DACL, mudança de privilégio/ACL, conversões reais, commit/push/merge ou publicação. Preservar a candidata de 470 arquivos e a custódia anterior. Retenção de novas fontes C1 exige decisão independente da retenção B.

**Resultado final:** aprovação DOCUMENTAL com ressalvas do material recebido. Prontidão operativa = **false**. Execução de Portões C/D/E e homologação Windows/DACL = **NÃO AUTORIZADA**.
