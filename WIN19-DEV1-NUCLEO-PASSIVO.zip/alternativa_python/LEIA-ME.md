# WIN19 DEV-1 — núcleo passivo sintético

Python 3.12, somente biblioteca padrão. U01–U04 implementadas exclusivamente como
biblioteca passiva nesta área BT01 do Codex. U05/U06/U07 não autorizadas.
Nenhuma integração com conversor, H3-F-R1 ou Windows. Não é sandbox para código
Python adversarial; as entradas admitidas são tipos primitivos/contratos fechados,
e o chamador continua responsável por fornecer apenas material sintético.

## APIs e fronteiras

- origem.conferir(bytes, sha256_esperado=None): SHA-256 de bytes fornecidos, no
  máximo 16.384 bytes. Digest esperado exige 64 hexadecimais minúsculos.
  Coincidir com declaração não autentica origem, carregamento ou autoridade.
- contexto.avaliar(dict | None): exige seis campos fechados. Referências somente
  REF_SINTETICA_A/REF_SINTETICA_B, finalidade OBSERVACAO_LIMITADA e quatro booleanos:
  autorizacao_declarada, operador_declarado, escopo_declarado, vigencia_declarada.
  Declaração completa continua não comprovada; nenhum prazo ou pessoa reais.
- recepcao.receber(bytes | None, sha256_esperado=None, contexto=None): classifica
  JSON em memória no contrato WIN19-DEV1-SINTETICO-1 abaixo. Não recebe caminho,
  lê arquivo ou captura canal. Não é consumidor do contrato operacional H3-F-R1.
- eventos.resumir(list[Evento] | tuple[Evento,...]): reduz eventos fornecidos.
  Início declarado/observado-fornecido, saída, interrupção, término, incerteza e
  fechamento declarado. Nenhuma observação própria ou interferência em processos.
- registro.sanitizar(dict | None): projeção por allowlist; somente enumerações,
  contagens limitadas e duas referências sintéticas. Sem payload, erros livres,
  digest bruto, caminhos, pessoas, contas, SIDs ou credenciais.
- contratos: tipos congelados, enums fechados e propriedades constantes false
  para destino/custódia/operação/autenticidade/autorização/fechamento/prontidão.

Não usar APIs com dados reais ou JUnit. Um marcador sintético não prova a origem
factual dos dados; nesta entrega apenas entradas fabricadas são usadas.

## Contrato de recepção sintético e versionado

Objeto único com exatamente nove campos:
versao (string WIN19-DEV1-SINTETICO-1), sintetico (true), documento_real (false),
resultado (INCONCLUSIVO ou IMPEDIMENTO), verificacoes (lista não vazia),
recursos_encerrados (booleano ou null), destino_aprovado (false),
custodia_autorizada (false) e operacao_autorizada (false).

Cada verificação tem exatamente id S01–S16 único e estado de
NAO_EXECUTADO/INCONCLUSIVO/IMPEDIMENTO/OBSERVADO_SINTETICO.
O resultado IMPEDIMENTO é obrigatório se e somente se houver esse estado na lista.
OBSERVADO_SINTETICO é declaração fictícia para o teste, nunca aprovação material.

Limites delegados: 16 KiB de bytes UTF-8 estritos sem BOM, 256 nós JSON,
profundidade 12 e até 16 verificações. Duplicatas em qualquer nível, NaN/Infinity,
overflow não finito, conteúdo adicional, estrutura/tipos/flags incompatíveis são
recusados. Ausência difere de fragmento; diagnóstico de possível incompletude
sintática não comprova truncamento de transporte. Exceções não ecoam o payload.
A árvore é limitada após decodificação; a entrada em bytes já está limitada antes.
Isso limita volume computacional, não garante um tempo máximo de execução.

EVIDENCIA_RECEBIDA_VALIDAVEL significa apenas estrutura sintética apta à revisão,
não verdade material ou vínculo real autenticado. Hash divergente preserva
valido_estruturalmente mas classifica atribuição incompatível. Nenhuma referência
autorreferente comprova legitimidade. O contexto ausente/inadequado fica explícito.

Sete estados externos: EVIDENCIA_RECEBIDA_VALIDAVEL, EVIDENCIA_INCOMPLETA,
EVIDENCIA_AUSENTE, EVIDENCIA_INCOMPATIVEL, EXECUCAO_INTERROMPIDA,
ENCERRAMENTO_NAO_COMPROVADO, RESULTADO_INCONCLUSIVO.
Eixos podem coexistir; não há DESTINO_APROVADO como estado.
Todas as respostas permanecem inconclusivas para execução/segurança reais.

## Eventos e registro

Máximo de 32 eventos por redução; tipo Evento/TipoEvento exatos. Não há relógio,
sleep, timeout ativo, processo ou supervisor. Duração finita fornecida entre
zero e 1.000.000.000, não decrescente quando presente, é só limite de dado
sintético: não é orçamento ou autorização de execução real.
Início precede saída/interrupção/término. Não há reinício após término.
Primeiro evento/duração/transição inválidos interrompe a redução, preservando
estado anterior e motivo seguro; eventos posteriores não são aplicados.
Fechamento fornecido/declarado não comprova recursos; sua incerteza permanece.
Quantidade recebida é limitada ao máximo quando a entrada excede o limite.

Registro admite estados/motivos, quantidade_verificacoes (0–16),
quantidade_eventos (0–32), referencia fechada, validade_estrutural e flags de
não aprovação. Booleano não é contagem. Até 32 campos de entrada; excesso recusa
o conjunto conservadoramente. Campos descartados são contados (com limite),
nunca copiados. Tentativa de flag true é recusada com APROVACAO_INDEVIDA e false.
Motivo/estado desconhecidos não são ecoados; dados adversos conhecidos permanecem.
F não verifica por si a origem factual do que o chamador declara estruturalmente
válido. Sanitização não apaga memória/logs/host nem comprova privacidade universal.

## Verificação autorizada no Codex

Na raiz DEV-1, comando:
python -B -m unittest discover -s tests -p 'test_*.py' -v

Os cinco arquivos tests usam somente unittest, biblioteca padrão e os seis módulos
novos. Tudo em memória e com dados fictícios. Não há teste do produto, import do
conversor, leitura privada, API Windows ou validação formal P2/P3/P4/P5/P6.
Não adicionar __init__.py: o pacote usa namespace Python, mantendo o inventário
fechado. -B evita caches. Nenhuma instalação necessária/autorizada.

## Estados e preservação

Autorização DEV-1 permite desenvolvimento/autotestes locais, não C, host,
observação, custódia ou publicação. G09/G10 continuam sem comprovação para execução
real, L-D06 pendente, R01–R09 abertos (R03/R07 ALTA), N02–N04 não verificados;
N01 antiga só se aplica aos bytes R1.
H3-F-R1 inalterada e não autorizada; WIN01–WIN19/DACL não validados; H3-C/H3-S/H4
não autorizadas; conversões reais bloqueadas e prontidao_operacional=false.

Auditar código/testes/resultados/manifesto e parar. O ZIP local autorizado contém
somente 14 arquivos; nenhuma publicação/Git é permitida nesta rodada.
