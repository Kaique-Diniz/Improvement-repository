"""B: metadados declarados não são autenticação nem autorização."""
from .contratos import ContextoPassivo, EstadoContexto, Motivo, Referencia

_CAMPOS = frozenset({
    "referencia", "finalidade", "autorizacao_declarada",
    "operador_declarado", "escopo_declarado", "vigencia_declarada",
})
_BOOLEANOS = ("autorizacao_declarada", "operador_declarado",
              "escopo_declarado", "vigencia_declarada")


def avaliar(dados: dict | None) -> ContextoPassivo:
    base = (Motivo.AUTORIZACAO_NAO_COMPROVADA,)
    if dados is None:
        return ContextoPassivo(EstadoContexto.SEM_DECLARACAO, None,
                               base + (Motivo.CONTEXTO_AUSENTE,))
    if (type(dados) is not dict or len(dados) != len(_CAMPOS)
            or any(type(k) is not str for k in dados) or set(dados) != _CAMPOS):
        return ContextoPassivo(EstadoContexto.DECLARACAO_INVALIDA, None,
                               base + (Motivo.CONTEXTO_INVALIDO,))
    if (type(dados["referencia"]) is not str
            or dados["referencia"] not in {r.value for r in Referencia}
            or type(dados["finalidade"]) is not str
            or dados["finalidade"] != "OBSERVACAO_LIMITADA"
            or any(type(dados[k]) is not bool for k in _BOOLEANOS)):
        return ContextoPassivo(EstadoContexto.DECLARACAO_INVALIDA, None,
                               base + (Motivo.CONTEXTO_INVALIDO,))
    ref = Referencia(dados["referencia"])
    if not all(dados[k] for k in _BOOLEANOS):
        return ContextoPassivo(EstadoContexto.DECLARACAO_INSUFICIENTE, ref,
                               base + (Motivo.CONTEXTO_INSUFICIENTE,))
    return ContextoPassivo(EstadoContexto.DECLARACAO_COMPLETA, ref, base)
