# H3-N — critérios de deliberação futura L-D02

26/11/2026. L-D02=CRITERIOS_PREPARADOS_DECISAO_PENDENTE.
Os onze valores efetivos permanecem NAO_PREENCHIDO; não é pedido automático de
ratificação. Após auditoria, eventual manifestação expressa poderá aprovar, rejeitar
ou ajustar cada proposta com motivação e limitações, em registro legítimo privado.
Nenhum formulário de garantias ou modelo privado foi preenchido nesta entrega.

## Critérios para uma decisão fundamentada

1. Finalidade e afirmação: a escolha A delimita diagnóstico nominal/pontual. Para
   cada G, distinguir indício observado, garantia indispensável antes de ler e
   requisito de custódia posterior. Não fundir consultas num snapshot atômico.
2. Legitimidade de operador/ambiente (G09): evidência privada e autoridade pertinentes
   antes de propor execução. PS5.1/não elevação não comprovam legitimidade ou token
   completo. Não pedir conta/SID/máquina no documento compartilhável.
3. Separação de áreas (G04/G05): decidir suficiência das referências legítimas e
   alcance da prova, preservando proibições. DEPENDENTE_DE_DECISAO não significa
   proibição opcional. Marcador ausente não prova separação; não buscar candidatas,
   adicionar caminhos privados ao código ou presumir por nomes.
4. Identidade/concorrência (G02/G03, R03): se a garantia física for indispensável
   antes da observação, exigir objeto/identidade/operação, evidência e revisão de
   método apropriados. Releitura de atributos não elimina corrida nem reserva nome.
   Se não demonstrável, manter revisão/adiamento; não executar para descobrir.
5. Metadados de segurança/proteção (G07/G08, R07): leitura de DACL ancestral não é
   acesso efetivo nem proteção futura. Ausência de allow amplo não cumpre custódia.
   Proteção do futuro alvo em portão próprio; não criar ou testar outra conta agora.
6. Exposição e privacidade (G06/G09): definir escopo legítimo e tratamento de captura/
   saída, sem desabilitar auditoria/logs/serviços ou isentar shares administrativos.
   Informação diagnóstica não dispensa segurança da própria leitura.
7. Recepção/encerramento (G10): decidir origem do código, vínculo com autorização/
   rodada, evidência completa e limites de confiança. Contrato H3-L segue proposto,
   não implementado/não adotado; rótulos de versão e JSON válido não autenticam runtime.
8. Resultados ausentes/inconclusivos: estabelecer tratamento conservador sem completar
   campos a partir de outra rodada, considerar silêncio sucesso ou corrigir saída
   para torná-la compatível. Recursos incertos e interrupção requerem registro de
   limitação, sem repetição automática ou mecanismo de encerramento improvisado.
9. Duração/tempo/validade: não inventar prazo total, supervisor ou procedimento. Os
   timeouts de APIs não definem duração global; retenção de 180 dias não é validade
   de execução. Revisão/decisão técnica próprias continuam necessárias.
10. Dependências técnicas: N02/N03/N04 continuam não verificadas; decidir o que é
    relevante à finalidade e que evidência nativa separada poderá ser necessária,
    sem autorizar ensaios por esta documentação. N01 só comprova sintaxe R1 conforme
    relato do usuário. D01–D04 não são eficácia funcional demonstrada.
11. Revisão do método: conservar METODO_REQUER_REVISAO_ADICIONAL_ANTES_DE_OBSERVACAO.
    Handles/pinning/novas APIs, consumidor, envelope ou supervisor seriam escopos
    futuros de projeto/implementação, não autorizados. Não decidir em nome do custodiante.
12. Portões (G11): escolha da finalidade, deliberação de garantias, inspeção, aprovação
    do destino e termo H3-C são decisões distintas. Nenhuma abre H3-S/H4, WIN/DACL,
    conversões reais ou custódia por inferência.

## Riscos que podem impedir até observação diagnóstica

Todos permanecem potenciais; abaixo não se declara exploração observada.

| ID | Severidade histórica | Estado preservado |
|---|---|---|
| H3G-R01 | MEDIA | RISCO_POTENCIAL |
| H3G-R02 | MEDIA | RISCO_POTENCIAL |
| H3G-R03 | ALTA | RISCO_POTENCIAL |
| H3G-R04 | MEDIA | RISCO_POTENCIAL |
| H3G-R05 | MEDIA | RISCO_POTENCIAL |
| H3G-R06 | MEDIA | RISCO_POTENCIAL |
| H3G-R07 | ALTA | RISCO_POTENCIAL |
| H3G-R08 | MEDIA | RISCO_POTENCIAL |
| H3G-R09 | MEDIA | RISCO_POTENCIAL |

- R01/R02/N04: falha sem JSON, duração não delimitada ou recursos incertos podem
  inviabilizar recepção/encerramento confiáveis; manter bloqueio sem contrato revisado.
- R03: corrida/redirecionamento pode alcançar objeto fora do escopo; limitar a
  afirmação não torna segura a operação. Exigência de identidade estável sem método
  adequado impede progressão até revisão ou adiamento.
- R04/R05/R06: volume/áreas/exposição não demonstrados podem ser incompatíveis com
  a própria leitura. Ausência de indicador não é autorização de escopo.
- R07: falta de legitimidade, limites de acesso ou exposição de metadados de segurança
  pode tornar inadequada a leitura do ancestral; proteção futura continua não provada.
- R08/R09: captura/host/comando de origem não confiável pode comprometer privacidade
  ou executar componente fora do escopo; não operar para conferir sua legitimidade.

A classificação INDICADOR_DIAGNOSTICO se refere ao alcance da informação, não à
dispensa de precondições de segurança. Nenhuma garantia foi ratificada por L-D01.
