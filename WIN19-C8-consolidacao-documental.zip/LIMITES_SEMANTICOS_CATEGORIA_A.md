# C8 — limites semânticos e probatórios da Categoria A

23/11/2026. Consolidação de ressalvas existentes; não impõe nem implementa regras
novas nos contratos. Fonte principal: parecer independente C7-R1 e registros C5/C7.

## Cinco limitações mantidas integralmente

| ID | Limitação confirmada historicamente | Consequência para futura revisão de consumo |
|---|---|---|
| L01 — Cobertura | A existência de 21 objetos não comprova unicidade nem conjunto exato de subcasos | Comparar o conjunto de chaves com a cobertura autorizada, sem promover por contagem |
| L02 — Correspondência | Enumerações de identificadores não comprovam a associação correta entre WIN e subcaso | Examinar pares e contexto; enums isolados não bastam |
| L03 — Afirmações | Algumas condições baseadas em contains não exigem necessariamente a presença de todas as afirmações esperadas | Conferir conjunto completo por subcaso, mantendo explícitos ramos não exercitados |
| L04 — Referências e custódia | Identificadores e hashes declarados não comprovam existência, autenticidade, integridade factual, custódia ou autorização | Exigir fontes e revisão próprias; rótulos e forma do hash não são prova |
| L05 — Histórico | 19 objetos não garantem 19 controles WIN distintos | Conferir identidade/duplicação e fontes primárias, sem inferência por semelhança |

As aceitações L01–L05 foram registradas na C7-R1 e reproduzidas segundo seu parecer
independente. Não foram executadas novamente nesta C8. O modelo L04 usava aliases
contrafeitos explicitamente sintéticos: sua aceitação de forma não legitimou o
conteúdo. Nenhum modelo é promovido a registro real, evidência primária ou autorização.

## Distinções obrigatórias

- ACK declarado descreve recebimento declarado. Não demonstra flush, fsync, disco,
  durabilidade, entrega ordenada, identidade da peça ou legitimidade de autorização.
- Validade estrutural verifica forma admissível; veracidade exige prova externa.
  Hash com formato correto não demonstra cálculo sobre a peça correta ou custódia.
- Resultado funcional não aprova resultado nativo. Resultado nativo não comprova
  DACL efetiva, isolamento entre contas ou política de autorização de acesso.
- SKIP não é PASS. A afirmação não exercitada continua NÃO_VALIDADO. Ausência,
  null, false e zero não são intercambiáveis nem geram aprovação automática.
- Documento SINTETICO_NAO_EXECUTADO não é execução autorizada. Mesmo contendo
  PASS/APROVADO ilustrativo, continua modelo sem prova de fatos.
- Cleanup concluído ou ausência de exceção não demonstra proteção de segurança.
  Resíduo e falha de limpeza não devem desaparecer por resultado agregado favorável.

## Limites de implementação e de perfil

O dialeto proposto é Draft 2020-12 offline, sem $schema/$id, sem refs entre arquivos,
com $ref local ao próprio $defs. A seleção de dialeto precisa ser explícita para
qualquer consumidor futuro; não presumir autodetecção em consumidor genérico.
A repetição literal de tipos não comprova verdade, ordem, unicidade por chave ou
igualdade dinâmica entre peças. Cardinalidade e uniqueItems de objetos não resolvem
L01/L05. Uma regex de ID/código não é sanitização de conteúdo privado.

Limites de representação de campos não são orçamento de bytes totais, fluxo,
buffers, tempo ou retenção. Tais limites operacionais continuam PARA_REVISÃO,
sem valores novos definidos nesta C8. Não existe licença para consumo ilimitado.

T02 permanece bloqueado; T03/T04/T05/T07 parciais. WIN-03 mantém o ramo nativo
bloqueado. WIN-18/19 continuam protocolos condicionados ao Portão D, não prova
NTFS por chmod ou compartilhamento de handles. C5/T01/T06 especificados não são
componentes ativos, autorizações de ensaio ou evidência de execução.

Nenhum mecanismo para resolver L01–L05 ou qualquer dessas ressalvas foi implementado.
A Categoria A não implica consumidor Categoria B nem runner C autorizado.
