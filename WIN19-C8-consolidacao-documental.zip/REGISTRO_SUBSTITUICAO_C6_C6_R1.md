# C8 — seleção documental do relatório C6-R1

23/11/2026. Relação de referência: C6/relatorio.schema.json → C6-R1/relatorio.schema.json.
Esta seta representa seleção documental; não é comando, migração ou troca de arquivos.

## Identidades distintas e preservadas

| Papel | Origem | Bytes | SHA-256 |
|---|---|---|---|
| Histórico excluído da seleção C8 | WIN19-C6-CONTRATOS-20261123/contratos_c/relatorio.schema.json | 20836 | ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6 |
| Referência lógica selecionada | WIN19-C6-R1-CORRECAO-20261123/contratos_c/relatorio.schema.json | 20837 | 079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e |

## Encadeamento documental

1. C6 materializou o relatório original. C7 confirmou JSONDecodeError na linha 39,
   coluna 5, char 3110: Expecting property name enclosed in double quotes.
2. O diagnóstico apontou o fechamento ausente na primeira condicional allOf.
   A versão original continuou inválida; as outras cinco peças foram avaliadas
   independentemente nos escopos aplicáveis.
3. C6-R1 materializou em área distinta a inserção de um único ASCII 0x7D na linha
   38: `    }}},` → `    }}}},`. Offset indicado: 3112, base zero. O restante dos
   bytes foi preservado, sem alterar versão interna, propriedades ou formatação.
4. A auditoria C6-R1 aceitou a equivalência de um byte. Ressaltou que, em uma
   sequência de caracteres idênticos, a comparação não individualiza fisicamente
   qual fechamento foi inserido; isso não altera a equivalência comprovada.
5. C7-R1 validou a cópia corrigida: parsing, metaschema Draft 2020-12, referências
   locais e 81 sondas previstas. O parecer independente C7-R1 relata reprodução
   81/81, com as cinco aceitações semânticas limitadas explicitadas.
6. A C8 seleciona a identidade C6-R1 porque possui correção auditada e validação
   estrutural pertinente. Os outros cinco arquivos mantêm as identidades C6.

A equivalência byte a byte, o parsing e as sondas acima são resultados históricos
atribuídos aos registros e pareceres correspondentes; não foram reexecutados na C8.
Aqui foram conferidos apenas tamanhos/hashes e documentos de origem.

## Evidências de referência

- PARECER_INDEPENDENTE_WIN19_C7_2026-11-23.md: confirma a reprovação do conjunto C6
  e o diagnóstico, examinando os resultados dos outros cinco no recorte declarado.
- PARECER_INDEPENDENTE_WIN19_C6_R1_2026-11-23.md: equivalência de um byte aceita,
  sem comprovação estrutural ainda naquela revisão.
- PARECER_INDEPENDENTE_WIN19_C7_R1_2026-11-23.md: aprovação estrutural com ressalvas
  de semântica/proveniência e reprodução independente relatada de 81 sondas.

Hashes e proveniência dos pareceres e dos relatórios são registrados no índice e
no inventário lógico. Nenhuma aprovação posterior reclassifica os bytes antigos.

## Exclusão e preservação

O relatório original C6 não aparece entre as seis linhas do inventário lógico.
Permanece preservado, assim como seu ZIP, manifesto, diagnóstico e resultado
histórico REPROVADO_ESTRUTURALMENTE. A C6-R1 também permanece no local próprio.
Não foi aplicada nesta C8 substituição, cópia consolidada, alteração de metadados,
novo diff, correção adicional ou atualização da versão 0.1.0-proposta-c5.
