# C8 — requisitos para eventual consumo futuro

23/11/2026. Documento de precondições para decisão posterior; não é especificação
executável, configuração de carregamento, implementação, plano autorizado de ensaio
ou aprovação de um consumidor Categoria B.

## A. Condições demonstradas nos respectivos escopos

| Condição | Evidência e limite |
|---|---|
| Identidade dos bytes | Seis fontes selecionadas novamente conferidas por tamanho/SHA-256 na C8 |
| Integridade documental | Manifestos C5/C6/C6-R1/C7/C7-R1 e documentos cobertos conferidos; identidade não prova fatos externos |
| Sintaxe e estrutura | Evidências históricas C7/C7-R1, com distinção entre metaschema e conferência editorial |
| Cobertura documental | 21 subcasos/19 WIN na tabela existente, sem comprovação de execução |
| Perfil offline | Draft 2020-12 explicitamente escolhido; omissão intencional de $schema/$id; referências locais |
| Proveniência de auditoria | Pareceres identificam quais resultados foram apenas examinados e quais foram reproduzidos |

A C8 não reexecutou parsing, metaschema, verificações de cobertura ou sondas para
produzir esses resultados. Apenas identidade documental foi medida de novo.

## B. Condições ainda não demonstradas

| Condição pendente | Fonte necessária em futura autorização |
|---|---|
| Validação semântica entre registros | Conjunto exato/único, pares WIN/subcaso, afirmações completas e relações explícitas revisadas |
| Autenticidade de evidências | Origem primária, contexto, identidade e revisão documental/factual próprias |
| Persistência durável de ACKs | Prova específica de escrita e custódia; ACK declarado não basta |
| Correspondência hash/objeto externo | Bytes de origem e confronto autorizado, sem supor igualdade por formato/null |
| Reconciliação dos 19 nodeids | JUnit Windows original autenticado, log/contexto/manifesto e revisão humana |
| Execução de runner C | Implementação e autorização específicas, sem derivar de existência dos contratos |
| Isolamento Windows/DACL | Política por papel/objeto/operação aprovada, precondições e evidência nativa própria |
| Segurança de operações nativas | Contrato por operação e provas adequadas, sem substituir por simulação Linux |
| Homologação operacional | Deliberação explícita após cumprimento dos portões aplicáveis |

Não transformar essas necessidades em coleta automática, criação de contas,
instalação, privilégio, DACL, persistência ou execução nesta etapa.

## Condições de uma futura proposta consumidora

1. Definir escopo, artefatos, versões, entradas, saídas e limites de autorização;
   obter decisão explícita de implementação e revisão. A não autoriza B.
2. Selecionar exatamente as seis identidades lógicas da C8, sem carregar o relatório
   C6 reprovado, sem depender apenas de nomes ou HEAD e sem sobrescrever fontes.
3. Definir escolha offline de dialeto, recusa de referência externa, de versão/campo
   desconhecido e de coerção silenciosa. Não descobrir resolvers na rede por padrão.
4. Preservar a representação da ausência e a independência de natureza, autorização,
   execução, resultados funcional/nativo/DACL, custódia, integridade e cleanup.
5. Submeter separadamente os controles semânticos L01–L05 e critérios de evidência
   a desenho/revisão, sem fingir que o metaschema ou um parser os demonstram.
6. Deliberar limites globais de recursos, privacidade, custódia e retenção. Não
   inventar timeout, capacidade ou política a partir de limites de representação.
7. Distinguir falha de preparação, estrutura inválida, falta de prova e falha efetiva
   do alvo. Não promover SKIP, modelo, zero, true ou cleanup a aprovação de segurança.
8. Exigir autorização própria para execução/ensaios e para cada portão pertinente;
   não inferir execução de um campo AUTORIZADA_DECLARADA presente em um documento.
9. Preservar histórico, bloqueios de conversões reais, fontes e versões anteriores.

Essa lista orienta uma decisão futura. Não escolhe tecnologia, cria consumidor,
validador runtime, observador, transporte ou runner, nem inicia outro portão.
