# WIN19-C8 — índice e proveniência

23/11/2026 — America/Sao_Paulo. Pasta nova externa ao Git e à candidata:
`/workspace/work/WIN19-C8-CONSOLIDACAO-DOCUMENTAL-20261123`.

## Oito documentos autorizados

1. [RELATORIO_C8_CONSOLIDACAO.md](RELATORIO_C8_CONSOLIDACAO.md) — síntese e decisão proposta.
2. [INVENTARIO_LOGICO_CATEGORIA_A.csv](INVENTARIO_LOGICO_CATEGORIA_A.csv) — exatamente
   seis registros; também constitui o manifesto lógico das fontes C6/C6-R1.
3. [REGISTRO_SUBSTITUICAO_C6_C6_R1.md](REGISTRO_SUBSTITUICAO_C6_C6_R1.md) — correção
   histórica e seleção documental do relatório, sem operação de substituição.
4. [LIMITES_SEMANTICOS_CATEGORIA_A.md](LIMITES_SEMANTICOS_CATEGORIA_A.md) — L01–L05
   e demais distinções sem implementação de mecanismos.
5. [REQUISITOS_CONSUMO_FUTURO.md](REQUISITOS_CONSUMO_FUTURO.md) — condições já
   demonstradas e pendentes; nenhuma autorização de consumidor Categoria B.
6. [PENDENCIAS_E_PORTOES_C8.md](PENDENCIAS_E_PORTOES_C8.md) — estados preservados.
7. INDICE_ENTREGA_C8.md — este registro de método e proveniência.
8. [MANIFESTO_SHA256_C8](MANIFESTO_SHA256_C8) — bytes/hashes dos sete documentos
   novos; exclui apenas a si, com SHA-256 informado na conversa.

Não existe pasta contratos_c, cópia consolidada de contratos, script, fixture,
validador ou pacote de distribuição nesta entrega. O CSV é referência documental,
sem instrução de carga, alias de filesystem, symlink, hardlink ou redirecionamento.

## Fontes e referência de execução

Instrução C8 recebida, Texto colado.txt, 11.941 bytes, SHA-256
`0f5ad3a8134abcde9563ff4a8f7453ef5380f71a845a3cb0d933159f206b2ef2`.
É a referência principal da autorização. Parecer obrigatório C7-R1 e pareceres
C7/C6-R1 foram lidos como fundamentação, sem executar seus conteúdos:

| Documento recebido/de referência | Bytes | SHA-256 |
| --- | --- | --- |
| PARECER_INDEPENDENTE_WIN19_C7_R1_2026-11-23.md | 6330 | 7826d57dc6c0b64437eb388c73b049ad684382d4b0272a33ab0663681b2b48f7 |
| PARECER_INDEPENDENTE_WIN19_C7_2026-11-23.md | 6487 | 9a5596971183d899c4d6334a25105668e9b634c120918279e18764ae9877a73f |
| PARECER_INDEPENDENTE_WIN19_C6_R1_2026-11-23.md | 3651 | 3bd9230d1ae47c5586f4841568faf4b88587e776b5d0a3f4754512b641ee41ad |

Os relatórios de validação referenciados por linha no inventário possuem hashes
conferidos, distintos dos hashes dos contratos:

- WIN19-C7-VALIDACAO-20261123/RELATORIO_C7_CONSOLIDACAO.md:
  `a3265058bdb1e009e827ad5724e65215beda23279157ae69e2bea5e77c69d4c8`.
- WIN19-C7-R1-VALIDACAO-20261123/RELATORIO_C7_R1_VALIDACAO.md:
  `63aa70f390d85c3eea6bfdfeb86c4b6251316fd414a96c5cfb5eaca16d7c56a8`.

Os seis documentos C5 CONTRATO_*_PROPOSTO.md e a base comum continuam na área C5,
identificados no manifesto C5 abaixo. Seus nomes de origem constam por contrato
no inventário; não foram copiados para C8. Versão interna preservada: 0.1.0-proposta-c5.

## Conferência documental de identidade

| Etapa | Manifesto de origem | Registros cobertos | SHA-256 conferido |
| --- | --- | --- | --- |
| C5 | WIN19-C5-CONTRATOS-DOCUMENTAIS-20261119/MANIFESTO_SHA256 | 17 | b8a3a391097ce220b7764d3f368e2cf85cbd0eeb4b260e98d99a96794e505af5 |
| C6 | WIN19-C6-CONTRATOS-20261123/MANIFESTO_SHA256_C6 | 7 | a72a1800441cdb1b4e1a156759a1e45eb7ae1c3f29d674146403f26a179bc796 |
| C6-R1 | WIN19-C6-R1-CORRECAO-20261123/MANIFESTO_SHA256_C6_R1 | 3 | 8cdcdc309d934def4b779b13cf0694cc07c534ee46ec4b519aa4ec6ef32d82f3 |
| C7 | WIN19-C7-VALIDACAO-20261123/MANIFESTO_SHA256_C7 | 11 | ca6195bf72e191599e5013b5e7d22b5f5e5ca6356e17d6a015d62d92e70471a2 |
| C7-R1 | WIN19-C7-R1-VALIDACAO-20261123/MANIFESTO_SHA256_C7_R1 | 6 | 4547890f5c371f7f7559949e1b16d0e062d8bbe5b254f3d739639a60cb6e8319 |

| Pacote histórico | Bytes | SHA-256 conferido |
| --- | --- | --- |
| WIN19-C6-contratos-declarativos.zip | 19872 | ee9cd82da311ef8ea003f3eba249a1c9967d46cd258a10dd813e706848e82f3a |
| WIN19-C6-R1-correcao-sintatica.zip | 8206 | 2ef92d800448d3d55ca11c999f9dd5839b22efaee6937a5c00f972a39c05d770 |
| WIN19-C7-validacao-estrutural.zip | 32646 | f984a0406188323540f8f2cf28ded4a44ade800543ab143784dbc15e2aae1569 |
| WIN19-C7-R1-validacao-estrutural.zip | 32186 | 00723c6e9b10badfe585ca0ff945166e083cfba87e43f9e31e74312d7f30e307 |

Foram verificados tamanhos/SHA-256 antes da redação e novamente depois, sem alterar
fontes ou pacotes. Os seis contratos selecionados correspondem aos valores da
instrução; o antigo relatório C6 permanece preservado e excluído do inventário lógico.
Não houve parsing JSON/CSV dos contratos, metaschema, sondas, replay de auditoria,
CRC novo, pytest ou preflight. Os manifestos foram lidos apenas como metadados
textuais de integridade. A presença da versão nos contratos foi lida como texto.

A redação usou recursos locais de leitura, cálculo SHA-256 e escrita de documentos,
com Python -I -B/stdlib pathlib, hashlib e escritor CSV. Nenhum arquivo anterior,
bloco de código recebido ou módulo do conversor foi executado/importado. A escrita
se limitou aos oito documentos desta pasta nova. Não há programa auxiliar entregue.

## Separação das classes de hash

1. INVENTARIO_LOGICO_CATEGORIA_A.csv: identidades de fontes já existentes; pasta,
   tamanho/hash e versão de materialização; evidências/pareceres documentais em
   colunas explicitamente separadas. Nenhuma linha significa arquivo copiado à C8.
2. MANIFESTO_SHA256_C8: somente os sete documentos novos e efetivamente presentes.
3. Evidências Windows: nenhum hash novo medido, arquivo recuperado ou resultado
   executado nesta tarefa. Os 19 vínculos permanecem PROVISORIO_SEM_FONTE.

Identidade documental não prova autenticidade de evidência, custódia privada ou
segurança. As afirmações de reprodução independente são atribuídas aos pareceres,
não a nova execução na C8 nem observação do Windows do usuário.

## Parada

C8 CONSOLIDACAO_DOCUMENTAL aguardando revisão. Preservados os estados e bloqueios
do documento de pendências. Não houve novo conjunto físico, consumidor, schema,
Categoria B, runner C, ensaio, coleta, Git, worktree, configuração, ACL, privilégio,
conta, limpeza, commit, push, merge, publicação ou ZIP. Entregar para auditoria.
