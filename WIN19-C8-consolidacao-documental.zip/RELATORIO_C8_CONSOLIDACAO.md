# WIN19-C8 — consolidação documental da Categoria A

23/11/2026 — America/Sao_Paulo. Estado: **CONSOLIDACAO_DOCUMENTAL, aguardando revisão independente**.

## Decisão documental proposta

Adotar como referência lógica exatamente seis identidades: cinco arquivos C6 e
somente o relatório C6-R1. A proposta identifica bytes já existentes e validados
nos respectivos escopos históricos. Não cria distribuição, instalação, consumidor
ou versão nova dos contratos; depende de revisão independente desta documentação.

| Contrato relativo | Origem | Bytes | SHA-256 selecionado |
| --- | --- | --- | --- |
| contratos_c/evento.schema.json | C6 | 10180 | 682edd46b9bd41d70a25f7341ef6844c7adcd005686982cadf5eb81f152f567d |
| contratos_c/mensagem.schema.json | C6 | 10938 | d64e545a02524f6bce02c3541518a7d04c04ad886cdd8198514327bd5be32e98 |
| contratos_c/estados.json | C6 | 13013 | 27c3f56e9e657afb4743f18dadead8de05e234d8d5eb5318cb48ab68dae3ea77 |
| contratos_c/cobertura_21.csv | C6 | 5305 | 5a7e77e6ce8690e6153b512482db859184d3d8533e40a5e11e0bfd8a65ebf599 |
| contratos_c/vetores_de_contrato.json | C6 | 10711 | ed00b1e28d07ca669ccc488bd3d5c403cb64768da554e187bfeba64ceca9a447 |
| contratos_c/relatorio.schema.json | C6-R1 | 20837 | 079d44447f3cfafbdbcfcb565f748d455948835a1618a5214e9875231e2eca7e |

O antigo relatório C6 de 20.836 bytes, SHA-256
`ff47d1545d8e468f9cfcca45c8ef8060c21f6e046800eb4fb8c716b6dc16a4b6`,
**não integra a seleção C8**. Permanece no local original como histórico reprovado.
A seleção do relatório C6-R1 é documental; nenhum arquivo foi substituído no disco.

## Inventário e manifesto lógico

INVENTARIO_LOGICO_CATEGORIA_A.csv tem exatamente seis registros e cumpre duas
funções documentais: inventário de versões e **manifesto lógico das fontes**.
Não foi criado arquivo adicional de manifesto lógico. Pasta de origem e caminho
relativo identificam onde os bytes existentes foram conferidos; não são configuração
ativa, instrução de carregamento, resolução de filesystem ou alias de arquivo.

O manifesto MANIFESTO_SHA256_C8 tem finalidade distinta: cobre os sete documentos
novos desta entrega, excluindo apenas a si. Não inventaria contratos copiados,
pois não existem cópias de contratos dentro da C8. Nenhum desses manifestos contém
hash novo de evidência de execução Windows. Fontes, documentos C8 e fatos nativos
permanecem categorias separadas de proveniência.

## Histórico e alcance das validações citadas

| Etapa | Resultado histórico preservado |
|---|---|
| C5 | Seis contratos especificados documentalmente |
| C6 | Seis materializados; conjunto original reprovado por relatório inválido |
| C7 | Cinco aprovados no recorte aplicável; relatório reprovado por sintaxe |
| C6-R1 | Inserção única de um byte auditada; arquivo distinto preservando a origem |
| C7-R1 | Relatório corrigido aprovado estruturalmente no recorte examinado |
| C8 | Referência lógica 5+1, sem nova validação, aguardando revisão |

C7: evento e mensagem tiveram parsing/metaschema e exemplos completos avaliados;
estados foi conferido no contrato editorial, sem metaschema próprio; CSV teve
conferência 21/19/14; vetores tiveram quatro completos e seis projeções editoriais.
O parecer independente C7 examinou os registros dessas validações, sem reproduzir
as sondas dos cinco arquivos. Essa diferença de proveniência está preservada.

C7-R1: a execução anterior registrou 36 definições, 108 referências locais sem
ciclos e 81 sondas, com 66 rejeições e 15 aceitações. O parecer independente
C7-R1 relata reprodução separada de 81/81 e dos cinco limites L01–L05, sem executar
Python extraído do relatório. As oito negativas auxiliares de parser não integraram
a reprodução independente; continuam evidência da execução anterior do Codex.
Essas são evidências históricas citadas, **não verificações reexecutadas na C8**.

## Conferências efetivamente realizadas nesta C8

Somente leitura documental e tamanhos/SHA-256. As seis identidades selecionadas
correspondem aos valores autorizados. A versão interna 0.1.0-proposta-c5 foi
preservada; sua presença foi lida textualmente, sem interpretação por validador.
Manifestos C5/C6/C6-R1/C7/C7-R1 e arquivos cobertos foram conferidos por tamanho/hash;
ZIPs C6/C6-R1/C7/C7-R1 tiveram identidade conferida por tamanho/hash. Não se executou
novo CRC, parsing dos contratos, metaschema, vetores, sondas ou scripts anteriores.
Nenhuma divergência de integridade foi observada.

Antes e depois da redação, os arquivos fonte cobertos continuaram com as mesmas
identidades. A pasta C8 contém apenas os oito documentos autorizados, sem subpasta
contratos_c, JSON de contrato, symlink, hardlink, redirecionamento ou conjunto físico
unificado. Não foram criadas cópias dos seis contratos, scripts ou fixtures.

## Ressalvas e bloqueios

A forma dos dados não comprova fatos. Preservados L01–L05, distinção de ACK/disco,
funcional/nativo/DACL, SKIP/PASS, modelo/execução autorizada e cleanup/segurança.
Qualquer consumidor futuro exige escopo, implementação, revisão e autorização
específicos. Não há aprovação implícita de Categoria B ou início de runner C.

C6 original REPROVADO_ESTRUTURALMENTE; C6-R1 corrigida e aprovada no escopo C7-R1;
C7-R1 APROVADO_ESTRUTURALMENTE com ressalvas; runner NÃO_IMPLEMENTADO;
WIN01–WIN19 e DACL NÃO_VALIDADO; vínculos PROVISORIO_SEM_FONTE; T01/T06 ESPECIFICADO;
T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL; D01–D10 PARA_APROVAÇÃO;
C/D/E BLOQUEADOS; conversões reais BLOQUEADAS; prontidão para ensaios false.

Sem Git, worktree, instalação, produto/candidata, política, ACL, conta, privilégio,
coleta JUnit, preflight, pytest, Windows, publicação ou ZIP. Parar após a entrega
para auditoria; a C8 não é encerrada documentalmente por esta proposta sozinha.
