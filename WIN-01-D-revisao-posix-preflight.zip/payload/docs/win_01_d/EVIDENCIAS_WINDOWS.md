# Evidências Windows fornecidas pelo usuário — não executadas pelo Codex

Rodada `historicos-direto-20261112-121400`, Windows real, Python 3.12.10, candidata WIN-01-C reconstruída com 441 hashes verificados. Segundo o usuário, A também teve 469 hashes verificados. Os XML originais não foram anexados aqui: os motivos abaixo são transcrições do usuário, sem substituir a evidência primária.

Resultado histórico direto: **24 passed, 3 failed, 11 skipped, 0 errors**. As três falhas ocorreram exclusivamente na exigência de modo POSIX: `AssertionError: assert (33206 & 511) == 384`. 33206 & 511 é 438 (0o666), diferente de 384 (0o600); esse modo Windows não comprova permissões NTFS.

Falhas relatadas:

1. tests.phase3.test_private_validation::test_canonicos_so_por_opcao_explicita_na_area_privada
2. tests.phase3.test_private_validation::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida
3. tests.test_documents::test_auditoria_documental_persiste_em_json_protegido

## Motivos explícitos dos onze skips relatados

Os nove casos abaixo tiveram o motivo literal `WIN01_SYMLINK_SEM_PRIVILEGIO_1314; rejeicao de links NAO_VALIDADA`:

1. tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]
2. tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]
3. tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]
4. tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]
5. tests.bbz.test_persistent_links::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]
6. tests.bbz.test_persistent_links::test_raiz_link_ancestral_e_git_recusados
7. tests.bbz.test_persistent_links::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada
8. tests.phase3.test_protected_sources::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]
9. tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[symlink]

Os dois casos abaixo tiveram o motivo literal `Permissoes POSIX; DACL Windows NAO_VALIDADA`:

10. tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_fonte]
11. tests.private_simulation.test_private_storage::test_isolamento_git_links_e_permissoes[permissao_raiz]

Classificação obrigatória: todos os onze permanecem **SEM_COMPROVACAO_DO_CONTROLE_NATIVO**. Nenhum deles está aprovado, corrigido ou homologado. Não alterar privilégios, DACL ou políticas do Windows para obter testes verdes. O teste agrupado de raiz/Git pode deixar verificações posteriores sem execução quando a criação do link é ignorada; essa limitação continua documentada na auditoria C.

## Defeito do preflight relatado

PowerShell 5.1 com ErrorActionPreference=Stop interrompeu o runner antes do pytest porque o stderr esperado de `git rev-parse --show-toplevel` fora do Git foi convertido em NativeCommandError. A candidata revisada captura o stderr em Python/subprocess, sem reduzir a política Stop. A regressão nativa PS 5.1 está preparada e ainda não foi executada neste ambiente Linux.
