# WIN-01-D — candidata revisada, separada da C publicada

Worktree Linux nova: /workspace/work/win-01-d, HEAD destacado em 770d062d29c4361d6932592883df9339bb4089bc. Foi reconstruída a candidata C publicada pelo payload dos 28 arquivos; depois foram aplicados os cinco arquivos da proposta de preflight e os ajustes mínimos abaixo. A worktree C local, A, a reconstrução Windows de 441 hashes e os pacotes anteriores não foram alterados.

## Três funções: somente a asserção de modo é condicionada

Em tests/phase3/test_private_validation.py (duas ocorrências) e tests/test_documents.py (uma ocorrência), adicionou-se import os e, para cada asserção exata `stat().st_mode & 0o777 == 0o600`, o guard `if os.name == "posix"`. Nenhuma dessas funções chama pytest.skip. Não há aprovação substituta no Windows. Comentários e metadados do runner mantêm explicitamente DACL_WINDOWS_NAO_VALIDADA como pendência independente.

A comparação AST com a C publicada comprovou que, removendo somente os três guards e o import de os, ambos os módulos são idênticos. Foram preservados contagem de canônicos, retenção de conflitos, ausência de canônicos em revisão, CPF/CNPJ nas ocorrências, ausência de exposição em stdout, integridade JSON e reconstrução/correspondência de contratos. Os testes continuam após o guard; não há return ou skip no ramo Windows.

As três funções foram executadas diretamente em Linux. Regressões auxiliares também chamam seus corpos com os.name substituído somente na referência do módulo de teste por posix e nt; não alteram os.name global nem simulam Windows/NTFS em produção. Esses ensaios confirmam os ramos e o fluxo documental, não proteção DACL.

## Preflight e tratamento de erro

validar.ps1 utiliza preflight_git.ps1/preflight_git.py. Somente saída única/status/código coerentes são aceitos. Git externo: código 128 e diagnóstico conhecido em locale C, sem stdout, vira FORA_DO_GIT/0. Diretório .git, worktree principal/vinculada e bare são recusados. Git ausente, configuração inválida, timeout, permissão, retorno vazio de sucesso ou diagnóstico inesperado ficam bloqueados. O stderr do Git é capturado no filho Python; não chega ao pipeline PS 5.1. Nenhuma exceção inesperada é convertida em aprovação. ErrorActionPreference permanece Stop.

Regressões incluem configuração inválida real, Git ausente/negado/timeout simulados e diretórios externos/internos reais. A função PS ainda deve ser executada em PowerShell 5.1 real para comprovar a correção nativa. Esse teste não executa a suíte histórica ou altera a reconstrução auditada.

O resultado.json do runner agora registra também pendencias_seguranca=['DACL_WINDOWS_NAO_VALIDADA']; exit_code, homologacao=false e revisão de skips permanecem preservados. Nenhum leitor, regra financeira, formato A/B ou arquivo src foi alterado em relação à candidata C publicada.

## Evidências e execução

EVIDENCIAS_WINDOWS.md preserva o relato 24/3/11 e os motivos individuais dos onze skips. A nova candidata não foi executada no Windows; não converter a previsão de solução em homologação. Os onze controles continuam sem comprovação nativa.

Primeira tentativa dos testes auxiliares: quatro erros de setup por fixture fontes_sinteticas não importada em tools/win01d. O conftest auxiliar foi ajustado para reutilizar explicitamente esse fixture existente; os logs da tentativa foram preservados. Não houve correção de produção ou alteração de assert para resolver esse setup.

Focados finais em Linux/Python 3.12.14: 24 aprovados, 1 ignorado (PowerShell 5.1 nativo indisponível), zero falhas/erros. Resultado em work/win01d/focados_final.log/xml. Suíte completa executada somente após esses focados; resultado consolidado em work/win01d/resultado.json. As seleções se sobrepõem e não devem ser somadas.

Nenhuma instalação ou teste Windows foi executado. Sem commit, push, PR, merge ou substituição do pacote público C. A versão revisada requer auditoria antes de reconstrução e reexecução nativa novas.


Resultado final da suíte completa Linux: **2697 passed, 1 skipped, 1 warning em 220,09 s**, zero falhas/erros; 2698 casos executados numa única rodada. Seleção: tests/ integral (2679 casos da candidata C com os ajustes mínimos), tools/win01c/test_preflight_git.py e tools/win01d/test_posix_assertions.py. Único skip: integração PowerShell 5.1 nativa, não executável neste Linux. Warning: depreciação Starlette/AnyIO BlockingPortal. Não somar 24 focados à suíte, pois há sobreposição. pip check e compilação em memória de 275 arquivos Python sem erro; git diff --check sem erro.
