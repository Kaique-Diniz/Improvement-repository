# Reconstrução isolada da revisão D — somente após auditoria

Não aplicar sobre a worktree Windows de 441 hashes nem sobre A/C. A nova revisão tem manifesto diferente, pois acrescenta guards POSIX, preflight e regressões. O pacote C publicado permanece uma referência imutável.

O pacote local de revisão fornece VERSAO_D_SHA256.json, payload/, reconstruir.py, diffs contra C publicada e contra BPQ-04. Confirmar primeiro o SHA-256 externo do ZIP recebido. Extrair em diretório novo; não sobrepor extrações anteriores. O manifesto contém todos os arquivos da versão, não apenas deltas ou HEAD. A reconstrução usa o baseline existente e substitui arquivos do baseline somente se o hash anterior confere; qualquer destino preexistente ou colisão inesperada é recusado. Não faz fetch, commit, alteração de branches existentes, instalação ou limpeza automática.

Exemplo, após revisar o pacote:

```powershell
$PacoteWin01D = 'PREENCHER_PASTA_NOVA_DO_PACOTE_EXTRAIDO'
$RepoWin01D = 'PREENCHER_CHECKOUT_GIT_EXISTENTE'
$DestinoWin01D = Join-Path $env:LOCALAPPDATA 'ConversorWIN01D-Candidata-Revisada'
py -3.12 (Join-Path $PacoteWin01D 'reconstruir.py') --pacote "$PacoteWin01D" --repo "$RepoWin01D" --destino "$DestinoWin01D"
py -3.12 (Join-Path $PacoteWin01D 'reconstruir.py') --pacote "$PacoteWin01D" --verificar "$DestinoWin01D"
```

O verificador exige HEAD-base e todos os SHA-256; arquivos extras são recusados, salvo metadados Git e caches pytest/Python. Desativa core.autocrlf somente durante checkout para preservar bytes, sem alterar configurações persistentes. Um erro deixa o novo diretório para diagnóstico; não apaga/recria destinos. Dependências e venv devem ficar fora do checkout, conforme a preparação anterior. Se necessário instalá-las, essa é uma ação explícita separada do usuário, nunca do runner.

Antes de usar validar.ps1 no Windows, executar a regressão test_preflight_ps51.ps1 numa cópia isolada dos auxiliares com Python existente, sem alterar a reconstrução auditada. A integração Windows PowerShell 5.1 foi ignorada nesta validação Linux e continua pendente. O código não reduz ErrorActionPreference nem altera privilégios/ExecutionPolicy. Verificar novamente os hashes antes/depois das rodadas e guardar os logs fora do Git.

DACL_WINDOWS_NAO_VALIDADA permanece no resultado.json. As três funções documentais devem executar integralmente; somente modo POSIX fica condicionado a os.name=='posix'. Não presumir a aprovação futura dos três casos nem converter os onze skips relatados em aprovação nativa. Nesta tarefa foi validada a revisão em Linux; nenhuma nova execução Windows foi iniciada.
