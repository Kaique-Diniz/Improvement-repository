# WIN-01-D — revalidação Windows posterior à auditoria

Não executada nesta tarefa. Usar Windows real/Python 3.12/NTFS com os patches WIN-01-C revisados e HEAD-base 770d062d29c4361d6932592883df9339bb4089bc. A versão corrigida é identificada pelo diff e hashes, pois não há commit novo. Preparar checkout separado, sem substituir A ou BPQ-04. Aplicar o diff completo somente após conferir colisões de arquivos e baseline. Não copiar documentos reais ou logs privados para o Git.

Preparação explícita pelo usuário, sem administrador:

```powershell
$RootWin01C = Join-Path $env:LOCALAPPDATA 'ConversorWIN01C'
$EvidenceWin01C = Join-Path $RootWin01C 'Resultados'
$VenvWin01C = Join-Path $RootWin01C 'venv'
# No checkout corrigido, após revisão do patch:
py -3.12 -m venv "$VenvWin01C"
$PythonWin01C = Join-Path $VenvWin01C 'Scripts\python.exe'
& $PythonWin01C -m pip install -e ".[test,web]"
& .\tools\win01c\validar.ps1 -Python $PythonWin01C -EvidenceRoot $EvidenceWin01C -Suite historicos
& .\tools\win01c\validar.ps1 -Python $PythonWin01C -EvidenceRoot $EvidenceWin01C -Suite acl
& .\tools\win01c\validar.ps1 -Python $PythonWin01C -EvidenceRoot $EvidenceWin01C -Suite perfis
& .\tools\win01c\validar.ps1 -Python $PythonWin01C -EvidenceRoot $EvidenceWin01C -Suite completa
```

O runner não instala dependências, não configura ACL, não muda ExecutionPolicy e não eleva privilégios. Roda sem `-X utf8`, com `PYTHONUTF8=0`, registrando o encoding efetivo do Windows. Se a máquina usa UTF-8 como encoding padrão, isso não é uma rodada CP1252 nativa: registrar essa distinção. A sonda textual Linux não substitui a rodada nativa. Rodar cada suíte até concluir e conservar todos os logs em pastas únicas fora do Git.

Revisar resultados por nodeid, sem somar seleções sobrepostas. Verificar os 38 históricos de `historicos.json`, ABI da Kernel32 (inclusive caracteres não-BMP), links nativos, normalização real 8.3 e falhas da API. O teste sintético de 8.3 não comprova disponibilidade de nomes curtos no volume. As funções de diagnóstico mantêm autoriza_acesso=False e aplicada_ao_leitor=False.

Skips de permissões POSIX não são aprovações NTFS. Skip WIN01_SYMLINK_SEM_PRIVILEGIO_1314 significa que a rejeição de links não foi validada; não habilitar privilégios ou Developer Mode automaticamente. Outros erros de criação de link continuam falhas. Não há implementação nova de verificação DACL efetiva nos componentes privados legados: o isolamento por usuário/processo e a proteção das pastas exigem auditoria nativa própria. Não concluir homologação apenas porque os testes executáveis passaram.

Para os seis condomínios, revalidar navegador, A/B, datas, valores originais, 30 colunas, cadastro, retenções BPQ-04, descarte e sessões conforme a WIN-01-A revisada preservada. Totais privados são referências do usuário, não saídas de fixtures sintéticas. Confirmar historicamente +269/R$ 130.997,71 só com as fontes/datas privadas correspondentes, fora do Git. Não implementar ADDR-01.

Exigir revisão dos três casos cuja causa segue não demonstrada e dos nove casos de links sem traceback nativo original. Obter novos tracebacks sem dados privados antes de atribuir causas. Nenhum resultado desta tarefa constitui homologação Windows, aprovação operacional ou autorização de publicação.
