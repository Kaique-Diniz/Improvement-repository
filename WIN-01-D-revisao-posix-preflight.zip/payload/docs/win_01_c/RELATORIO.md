# WIN-01-C — revisão técnica antes da revalidação Windows

## Preservação e escopo

Base obrigatória 770d062d29c4361d6932592883df9339bb4089bc; branch local fix/win01-compatibilidade-windows; worktree /workspace/work/win-01-c. Sem commits novos, push, PR, merge ou publicação.

A worktree WIN-01-A e seus ajustes foram preservados. Pacote local consolidado novo: /workspace/work/WIN-01-A-revisada-consolidada.zip, 201815 bytes, 41 entradas, manifesto e hashes internos conferidos; SHA-256 c6644d407501887a640dedd9059cccaf8488210561b05a19820d9f041aadc174. O ZIP histórico publicado continua separado e intacto, SHA-256 57a9ffff5c143765ba9b216447f44ec1130c458dae06e4afb933de0668abec00. Nenhum deles foi substituído/publicado nesta fase.

## Classificação individual e limites da prova

CLASSIFICACAO_38.md apresenta cada identificador, categoria, evidência e tratamento; classificacao_38.json/csv incluem os nodeids pytest convertidos. Origem dos 38 casos: relato do usuário extraído do XML Windows histórico, não reprodução nativa desta tarefa.

- 19 casos: falha reproduzida pela sonda CP1252 calibrada em Linux. A sonda altera o padrão de io.open/Path para CP1252, sem simular plataforma, sistema de arquivos ou permissões. Antes: 19 falhas/19 aprovações; depois: 38 aprovações no conjunto histórico. Não prova que o traceback Windows de cada caso teve a mesma causa.
- 5 casos ACL: usuário relatou traceback nativo comum de CompareStringOrdinal em oleaut32; inspeção confirma DLL e assinatura incorretas. Os testes adicionais do patch recuperado expuseram 18 falhas antes de aplicar o código (34 casos: 18 falhas/16 aprovações). São regressões com ABI simulada, não chamadas reais da Kernel32 no Linux.
- 2 casos: teste de permissões POSIX aplicado fora de POSIX; código de produção só examina esses bits em POSIX. Skip explícito fora POSIX registra ausência de validação DACL; não é correção de segurança Windows.
- 9 casos: criação/rejeição de links inspecionada; passam no Linux, mas faltam tracebacks nativos individuais. Helper de fixture só trata winerror 1314 como capacidade ausente; não se afirma que esse foi o erro histórico de todos eles.
- 3 casos: causa ainda não demonstrada — dois de validação privada e um de auditoria documental. Passaram na sonda; não foram declarados corrigidos no Windows.

A primeira tentativa de sonda (work/cp1252_antes.log, 38 aprovações) não interceptava encoding='locale' usado por Path no Python 3.12; não é evidência de compatibilidade CP1252. Foi substituída como experimento pela rodada calibrada, preservando ambos os logs. O plugin final contém uma asserção de calibração com bytes UTF-8 e leitura CP1252. Nenhum resultado foi silenciosamente descartado ou atribuído ao Windows.

## Correções aplicadas e justificativas

Somente dois arquivos de produção mudaram:

1. src/conversor/adapters/windows_acl_evidence.py: reaproveitado exatamente o diff desse arquivo de 84ab546. Kernel32/WinDLL, cinco parâmetros tipados, comprimentos em unidades UTF-16, validação de retorno, recusa de NUL e captura OSError sem aceitar igualdade. Nenhuma integração ao fluxo financeiro/Web efêmero. autoriza_acesso=False e aplicada_ao_leitor=False preservados. private_permissions.mesmas_regras permanece sem alteração e exige igualdade exata de ACEs, inclusive herança.
2. src/conversor/web/app.py: UTF-8 explícito ao ler fontes_autorizadas.json e a chave local textual (esta última é ASCII/UTF-8 por geração). O registro JSON teve mojibake reproduzido antes da correção em um teste sintético de locale CP1252; a leitura da chave foi explicitada por consistência, sem alegar falha histórica própria. Trata-se de componente Web legado, não alteração das regras dos seis perfis.

Os testes nos módulos relacionados aos 38 históricos passaram a declarar UTF-8 nas chamadas Path.read_text/write_text, inclusive ao produzir suas próprias fixtures textuais. Não foi alterada a codificação de documentos financeiros de origem, nem houve recálculo, mudança de responsável, template, elegibilidade, datas ou regra cadastral. As asserções anteriores dos testes fora ACL foram comparadas por AST, removendo apenas os novos argumentos de encoding, e permaneceram iguais.

tests/test_acl_evidence.py reaproveita as regressões do mesmo commit recuperado: assinatura, UTF-16 não-BMP/surrogates, erro nativo, indisponibilidade e NUL. tests/test_windows_compatibility.py cobre JSON legado sob CP1252 e o helper de symlinks. tests/windows_support.py transforma exclusivamente erro 1314 no Windows em skip explícito com rejeição de links NAO_VALIDADA; outros erros continuam falhas. O uso é limitado às fixtures dos casos históricos de links. Os dois casos de chmod são ignorados somente fora POSIX; não foram removidos e continuam exigindo rejeição em Linux.

Não foram trazidas árvores/branches históricas inteiras, verificadores ACL experimentais, alterações de permissões de produção ou regras novas. Não implementado ADDR-01.

## Execuções desta tarefa

Todas em Linux/Python 3.12.14, usando a venv existente com PYTHONPATH apontado explicitamente para src da WIN-01-C; o editable original da venv pertence à A e não foi reinstalado/modificado. Suítes normais usam PYTHONUTF8=0 e não usam -X utf8. Linux com locale UTF-8 ainda não é Windows/CP1252; por isso a sonda separada.

- Registro JSON antes: 1 falha reproduzida com mojibake; depois passa nos testes focados.
- ACL adicional antes do código: 18 falhas e 16 aprovações; após código, regressões e comparador de ACEs passam.
- Sonda CP1252 calibrada, 38 históricos: antes 19 falhas/19 aprovações; após 38 aprovações e 1 warning.
- Focados finais com sonda calibrada: 43 aprovados, zero falhas/skips, 2,02 s; ABI diagnóstica, comparador de ACEs e compatibilidade.
- Seis perfis e integração Web: 749 aprovados, zero falhas/skips, 1 warning; 111,39 s.
- Suíte completa Linux: 2679 aprovados, zero falhas/erros/skips, 1 warning, 252,12 s; todos os 38 identificadores históricos aparecem como aprovados no JUnit Linux. Resultado consolidado em work/resultado_final.json e work/completa_linux.xml/log. Isso não certifica seus caminhos Windows nativos.
- pip check: nenhuma dependência quebrada; freeze em work/dependencias.txt.
- Sintaxe: 270 arquivos Python compilados em memória, sem instalar pacotes ou escrever pyc para a verificação; git diff --check sem erro.
- Busca AST em produção não encontrou chamadas Path.read_text/write_text com encoding omitido. Não se afirma que isso audite todos os decodificadores ou DACLs.

O warning conhecido é depreciação Starlette/AnyIO BlockingPortal. Seleções se sobrepõem: não somar contagens como testes distintos. Arquivos em work são evidências locais desta fase, não documentos privados reais e não material publicado.

## Riscos e pendências para WIN-01-D

Não houve execução Windows real nesta tarefa. Há correções propostas/aplicadas e regressões Linux; não há declaração de que as 38 falhas Windows foram eliminadas. Revisar a matriz individual e executar os quatro escopos de WIN_01_D.md sem -X utf8. Coletar resultados, skips, encoding padrão real e novos tracebacks por nodeid.

DACL efetiva, isolamento contra outros usuários/processos, criação de symlinks sem privilégios extras, junctions/reparse points, hardlinks, nomes curtos 8.3, IO/atomicidade/locks nativos e recuperação após crash permanecem sem certificação. Não tratar chmod(0600), um skip ou leitura de ACL como prova de proteção. Os módulos privados legados não ganharam nesta fase enforcement de DACL. Não expor o MVP na rede nem autorizar operação por causa de resultados sintéticos.

Regras financeiras, valores, associação cadastral, A/B e 30 colunas foram preservados por escopo de diff e regressões; os agregados privados relatados não foram recalculados nem substituídos por fixtures. Revalidação financeira privada e navegador Windows seguem as instruções da WIN-01-A revisada, sem transportar fontes reais para o Git.

O diff completo inclui código, testes e documentação novos, não só git diff de arquivos rastreados. Será conservado em work/WIN_01_C_COMPLETO.patch com manifesto de hashes. Encerrar esta fase para auditoria antes de WIN-01-D; nenhuma publicação está autorizada por esta entrega.

A preservação final conferiu os hashes de todos os 39 arquivos da A incluídos no pacote consolidado e seu estado Git, sem diferenças. O ZIP histórico também manteve seu hash. O runner PowerShell foi preparado para revisão e não foi executado no ambiente Linux; sua execução permanece parte da WIN-01-D.
