"""Regressões sintéticas de texto e disponibilidade de links; não certificam NTFS."""
import json

from conversor.web.app import RegistroPrivado


def test_registro_privado_le_json_utf8_independente_do_locale(tmp_path, monkeypatch):
    import io
    original = io.open
    def cp1252(file, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None):
        if 'b' not in mode and encoding in (None, 'locale'):
            encoding = 'cp1252'
        return original(file, mode, buffering, encoding, errors, newline, closefd, opener)
    monkeypatch.setattr(io, 'open', cp1252)
    path = tmp_path / 'fontes_autorizadas.json'
    expected = [{'id': 'ensaio-ação-sintética'}]
    path.write_bytes(json.dumps({'casos': expected}, ensure_ascii=False).encode('utf-8'))
    assert RegistroPrivado(tmp_path).listar() == expected


def test_symlink_1314_registra_indisponibilidade_sem_aprovar(tmp_path, monkeypatch):
    import pytest
    from pathlib import Path
    from tests import windows_support as support
    monkeypatch.setattr(support, '_windows', lambda: True)
    def negar(*args, **kwargs):
        exc = OSError('MENSAGEM_SINTETICA_NAO_EXPORTAR')
        exc.winerror = 1314
        raise exc
    monkeypatch.setattr(Path, 'symlink_to', negar)
    with pytest.raises(pytest.skip.Exception, match='NAO_VALIDADA'):
        support.criar_symlink(tmp_path / 'link', tmp_path / 'alvo')


def test_outros_erros_de_link_nao_sao_ocultados(tmp_path, monkeypatch):
    import pytest
    from pathlib import Path
    from tests import windows_support as support
    monkeypatch.setattr(support, '_windows', lambda: True)
    def falha(*args, **kwargs):
        raise FileExistsError('SENTINELA_SINTETICA')
    monkeypatch.setattr(Path, 'symlink_to', falha)
    with pytest.raises(FileExistsError):
        support.criar_symlink(tmp_path / 'link', tmp_path / 'alvo')
