"""Capacidade de criar links: indisponibilidade nunca equivale a aprovação de segurança."""
import os
import pytest


def _windows():
    return os.name == 'nt'


def criar_symlink(link, target, *, target_is_directory=False):
    try:
        link.symlink_to(target, target_is_directory=target_is_directory)
    except OSError as exc:
        if _windows() and getattr(exc, 'winerror', None) == 1314:
            pytest.skip('WIN01_SYMLINK_SEM_PRIVILEGIO_1314; rejeicao de links NAO_VALIDADA')
        raise
