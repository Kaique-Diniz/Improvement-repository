function Assert-Win01EvidenceOutsideGit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Python,
        [Parameter(Mandatory=$true)][string]$EvidenceRoot
    )
    # O helper captura stderr do Git no subprocesso. Não reduzir ErrorActionPreference.
    $Status = @(& $Python (Join-Path $PSScriptRoot 'preflight_git.py') $EvidenceRoot)
    $Code = $LASTEXITCODE
    if ($Status.Count -ne 1) { throw 'PREFLIGHT_GIT_ERRO_OPERACIONAL' }
    if ($Code -eq 0 -and $Status[0] -eq 'FORA_DO_GIT') { return }
    if ($Code -eq 10 -and $Status[0] -eq 'EVIDENCIAS_DENTRO_DO_GIT') {
        throw 'EVIDENCIAS_DENTRO_DO_GIT'
    }
    throw 'PREFLIGHT_GIT_ERRO_OPERACIONAL'
}
