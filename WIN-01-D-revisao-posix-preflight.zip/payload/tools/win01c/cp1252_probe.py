"""Sonda de texto CP1252 em Linux. Não simula NTFS, Win32, DACL ou privilégios."""
import io


def pytest_configure(config):
    original = io.open
    def open_cp1252(file, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None):
        if 'b' not in mode and encoding in (None, 'locale'):
            encoding = 'cp1252'
        return original(file, mode, buffering, encoding, errors, newline, closefd, opener)
    io.open = open_cp1252
    config._win01c_original_io_open = original
    # Verificar o efeito real da sonda sobre Path.read_text, inclusive encoding="locale".
    from pathlib import Path
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as temp:
        path = Path(temp) / 'calibracao.txt'
        path.write_bytes('ç'.encode('utf-8'))
        assert path.read_text() == 'Ã§', 'SONDA_CP1252_NAO_CALIBRADA' 


def pytest_unconfigure(config):
    original = getattr(config, '_win01c_original_io_open', None)
    if original is not None:
        io.open = original
