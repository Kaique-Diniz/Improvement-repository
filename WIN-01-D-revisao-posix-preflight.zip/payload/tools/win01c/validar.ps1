[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$EvidenceRoot,
    [ValidateSet('historicos','acl','perfis','completa')][string]$Suite = 'historicos'
)
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'WIN01D_REQUER_WINDOWS_NATIVO' }
$Repo = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$Python = (Get-Command $Python -ErrorAction Stop).Source
$Output = [IO.Path]::GetFullPath($EvidenceRoot)
if ($Output.Equals($Repo, [StringComparison]::OrdinalIgnoreCase) -or $Output.StartsWith($Repo + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'EVIDENCIAS_DENTRO_DO_GIT' }
. (Join-Path $PSScriptRoot 'preflight_git.ps1')
Assert-Win01EvidenceOutsideGit -Python $Python -EvidenceRoot $Output
$PreviousUtf8 = $env:PYTHONUTF8
$PreviousPath = $env:PYTHONPATH
Push-Location $Repo
try {
    $Head = & git rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $Head -ne '770d062d29c4361d6932592883df9339bb4089bc') { throw 'HEAD_INESPERADO' }
    & $Python (Join-Path $PSScriptRoot 'ambiente.py') *> $null
    if ($LASTEXITCODE -ne 0) { throw 'PYTHON_INCOMPATIVEL' }
    $Run = Join-Path $Output ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $Run | Out-Null
    # Testar o encoding padrão Windows, sem -X utf8. Preservar/restaurar o ambiente.
    $env:PYTHONUTF8 = '0'
    $env:PYTHONPATH = Join-Path $Repo 'src'
    & $Python (Join-Path $PSScriptRoot 'ambiente.py') *> (Join-Path $Run 'ambiente.json')
    & $Python -m pip freeze *> (Join-Path $Run 'dependencias.txt')
    & $Python -m pip check *> (Join-Path $Run 'pip-check.txt')
    if ($LASTEXITCODE -ne 0) { throw 'DEPENDENCIAS_INCONSISTENTES' }
    & git status --porcelain=v1 --untracked-files=all | Out-File (Join-Path $Run 'git-inicial.txt') -Encoding utf8
    & git diff --binary | Out-File (Join-Path $Run 'codigo-em-revisao.patch') -Encoding utf8
    & git ls-files --others --exclude-standard | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Hash,Path | ConvertTo-Json | Out-File (Join-Path $Run 'nao-rastreados.json') -Encoding utf8
    $Paths = @()
    if ($Suite -eq 'historicos') {
        $History = Get-Content -LiteralPath 'docs/win_01_c/historicos.json' -Raw -Encoding utf8 | ConvertFrom-Json
        $Paths = @($History.PSObject.Properties | ForEach-Object { $_.Value })
    } elseif ($Suite -eq 'acl') {
        $Paths = @('tests/test_acl_evidence.py','tests/test_private_permissions_regression.py','tests/test_windows_compatibility.py')
    } elseif ($Suite -eq 'perfis') {
        $Paths = @('tests/passaredo','tests/oma','tests/vero','tests/itajuba','tests/beach_parque','tests/int02','tests/web/test_integrated_auto_gestao.py','tests/web/test_classic_local.py','tests/web/test_ephemeral.py','tests/web/test_cadastral_policy_metadata.py')
    } else { $Paths = @('tests') }
    $ArgsTest = @('-m','pytest','-q','--tb=short','-p','no:cacheprovider',('--junitxml=' + (Join-Path $Run 'pytest.xml'))) + $Paths
    @{suite=$Suite;head=$Head;args=$ArgsTest;windows_pendente_revisao=$true} | ConvertTo-Json -Depth 5 | Out-File (Join-Path $Run 'comando.json') -Encoding utf8
    & $Python @ArgsTest *> (Join-Path $Run 'pytest.log')
    $Code = $LASTEXITCODE
    & git status --porcelain=v1 --untracked-files=all | Out-File (Join-Path $Run 'git-final.txt') -Encoding utf8
    @{exit_code=$Code;homologacao=$false;skips_exigem_revisao=$true;pendencias_seguranca=@('DACL_WINDOWS_NAO_VALIDADA')} | ConvertTo-Json | Out-File (Join-Path $Run 'resultado.json') -Encoding utf8
    Write-Host "WIN-01-D: $Suite; exit=$Code. Revisar evidencias privadas e skips em $Run"
} finally {
    $env:PYTHONUTF8 = $PreviousUtf8
    $env:PYTHONPATH = $PreviousPath
    Pop-Location
}
exit $Code
