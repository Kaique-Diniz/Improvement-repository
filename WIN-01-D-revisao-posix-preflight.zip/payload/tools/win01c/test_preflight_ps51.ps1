# Regressão nativa: executar explicitamente em Windows PowerShell 5.1, sem Pester.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Python)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -ne 5 -or $PSVersionTable.PSVersion.Minor -ne 1) {
    throw 'REGRESSAO_REQUER_POWERSHELL_5_1'
}
$Python = (Get-Command $Python -ErrorAction Stop).Source
. (Join-Path $PSScriptRoot 'preflight_git.ps1')
$Root = Join-Path ([IO.Path]::GetTempPath()) ('win01-preflight-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $Root | Out-Null
$Results = @()
function Assert-Rejected([string]$Path, [string]$Expected) {
    try {
        Assert-Win01EvidenceOutsideGit -Python $Python -EvidenceRoot $Path
    } catch {
        if ($_.Exception.Message -eq $Expected) { return }
        throw
    }
    throw 'PREFLIGHT_DEVERIA_RECUSAR'
}
try {
    # Este cenário lançava NativeCommandError na versão anterior sob Stop.
    Assert-Win01EvidenceOutsideGit -Python $Python -EvidenceRoot $Root
    if ($ErrorActionPreference -ne 'Stop') { throw 'PREFERENCIA_ALTERADA' }
    $Results += 'diretorio_externo: APROVADO'
    Assert-Win01EvidenceOutsideGit -Python $Python -EvidenceRoot (Join-Path $Root 'novo\resultados')
    $Results += 'externo_ainda_inexistente: APROVADO'
    $Repo = Join-Path $Root 'repo'
    & git init --quiet --initial-branch=teste $Repo
    if ($LASTEXITCODE -ne 0) { throw 'FIXTURE_GIT_FALHOU' }
    Assert-Rejected (Join-Path $Repo 'resultados\novos') 'EVIDENCIAS_DENTRO_DO_GIT'
    $Results += 'repositorio: RECUSADO'
    # Formato gitdir usado por worktrees vinculadas, sem precisar criar commit.
    $Linked = Join-Path $Root 'worktree-vinculada'
    New-Item -ItemType Directory -Path $Linked | Out-Null
    [IO.File]::WriteAllText((Join-Path $Linked '.git'), ('gitdir: ' + (Join-Path $Repo '.git')))
    Assert-Rejected $Linked 'EVIDENCIAS_DENTRO_DO_GIT'
    $Results += 'gitdir_vinculado: RECUSADO'
    [IO.File]::AppendAllText((Join-Path $Repo '.git\config'), "`n[invalido")
    Assert-Rejected $Repo 'PREFLIGHT_GIT_ERRO_OPERACIONAL'
    $Results += 'git_config_invalida: ERRO_OPERACIONAL'
    $PreviousPath = $env:PATH
    try {
        $env:PATH = ''
        Assert-Rejected $Root 'PREFLIGHT_GIT_ERRO_OPERACIONAL'
    } finally { $env:PATH = $PreviousPath }
    $Results += 'git_ausente: ERRO_OPERACIONAL'
    $Results | ForEach-Object { Write-Output $_ }
} finally {
    # Somente o diretório sintético exclusivo desta regressão; nenhuma worktree auditada.
    Remove-Item -LiteralPath $Root -Recurse -Force
}
