"""Metadados seguros e validação do interpretador para a rodada Windows."""
import json
import locale
import sys

print(json.dumps({'python': sys.version, 'platform': sys.platform,
                  'encoding': locale.getencoding(), 'utf8_mode': sys.flags.utf8_mode}))
raise SystemExit(0 if sys.platform == 'win32' and sys.version_info[:2] == (3, 12) else 2)
