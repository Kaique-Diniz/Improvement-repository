"""As três funções continuam até o fim em ambos os ramos; NT é simulado, não homologado."""
import ast
from pathlib import Path
from types import SimpleNamespace

import pytest
from tests.phase3.test_private_validation import area
from tests.phase3 import test_private_validation as validation
from tests import test_documents as documents


@pytest.mark.parametrize('platform', ['posix', 'nt'])
def test_canonicos_com_documentacao_preservada(area, monkeypatch, platform):
    monkeypatch.setattr(validation, 'os', SimpleNamespace(name=platform))
    validation.test_canonicos_so_por_opcao_explicita_na_area_privada(area)


@pytest.mark.parametrize('platform', ['posix', 'nt'])
def test_conflitos_e_json_continuam_apos_modo(area, monkeypatch, capsys, platform):
    monkeypatch.setattr(validation, 'os', SimpleNamespace(name=platform))
    validation.test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida(area, monkeypatch, capsys)


@pytest.mark.parametrize('platform', ['posix', 'nt'])
def test_roundtrip_da_auditoria_continua_apos_modo(tmp_path, pessoa, monkeypatch, platform):
    monkeypatch.setattr(documents, 'os', SimpleNamespace(name=platform))
    documents.test_auditoria_documental_persiste_em_json_protegido(tmp_path, pessoa)


def test_somente_assercoes_de_modo_sao_condicionadas():
    root = Path(__file__).resolve().parents[2]
    counts = []
    for name in ['tests/phase3/test_private_validation.py', 'tests/test_documents.py']:
        tree = ast.parse((root / name).read_bytes())
        found = []
        for node in ast.walk(tree):
            if isinstance(node, ast.If) and ast.unparse(node.test) == "os.name == 'posix'":
                assert len(node.body) == 1 and not node.orelse
                assert isinstance(node.body[0], ast.Assert)
                expression = ast.unparse(node.body[0].test)
                assert '.stat().st_mode & 511 == 384' in expression
                found.append(node)
        counts.append(len(found))
    assert counts == [2, 1]
