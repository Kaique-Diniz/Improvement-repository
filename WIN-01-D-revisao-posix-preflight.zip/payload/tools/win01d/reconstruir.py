"""Reconstrói a candidata D em destino novo, sem commits, rede ou instalação."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

BASE = '770d062d29c4361d6932592883df9339bb4089bc'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verificar(root, spec):
    head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
    if head != BASE:
        raise RuntimeError('BASE_INESPERADA')
    for name, expected in spec['arquivos'].items():
        p = root / name
        if p.is_symlink() or not p.is_file() or sha(p) != expected:
            raise RuntimeError('HASH_DIVERGENTE: ' + name)
    extras = [p.relative_to(root).as_posix() for p in root.rglob('*')
              if p.is_file() and not any(x in ('.git', '__pycache__', '.pytest_cache') for x in p.relative_to(root).parts)
              and p.relative_to(root).as_posix() not in spec['arquivos']]
    if extras:
        raise RuntimeError('ARQUIVOS_EXTRAS')
    return {'base': head, 'arquivos_verificados': len(spec['arquivos']), 'hashes': 'OK'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pacote', type=Path, required=True)
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--destino', type=Path)
    parser.add_argument('--verificar', type=Path)
    args = parser.parse_args()
    package = args.pacote.resolve()
    spec = json.loads((package / 'VERSAO_D_SHA256.json').read_text(encoding='utf-8'))
    if spec['base'] != BASE:
        raise RuntimeError('MANIFESTO_BASE_INESPERADA')
    if args.verificar:
        print(json.dumps(verificar(args.verificar.resolve(), spec)))
        return
    if not args.repo or not args.destino:
        parser.error('requer --repo e --destino ou --verificar')
    target = args.destino.resolve()
    if target.exists() or target.is_symlink():
        raise RuntimeError('DESTINO_PREEXISTENTE')
    for name, expected in spec['payload'].items():
        if Path(name).is_absolute() or '..' in Path(name).parts or ':' in name or '\\' in name:
            raise RuntimeError('CAMINHO_INVALIDO')
        if sha(package / 'payload' / name) != expected:
            raise RuntimeError('PAYLOAD_CORROMPIDO')
    subprocess.run(['git', '-C', str(args.repo), 'cat-file', '-e', BASE + '^{commit}'], check=True)
    subprocess.run(['git', '-C', str(args.repo), '-c', 'core.autocrlf=false', 'worktree', 'add', '--detach', str(target), BASE], check=True)
    for name in spec['payload']:
        p = target / name; before = spec['antes'].get(name)
        if before is None:
            if p.exists() or p.is_symlink():
                raise RuntimeError('COLISAO_INESPERADA')
        elif not p.is_file() or p.is_symlink() or sha(p) != before:
            raise RuntimeError('BASE_COM_BYTES_DIFERENTES')
    for name in sorted(spec['payload']):
        p = target / name; data = (package / 'payload' / name).read_bytes()
        p.parent.mkdir(parents=True, exist_ok=True)
        if name not in spec['antes']:
            with p.open('xb') as stream:
                stream.write(data)
        else:
            if sha(p) != spec['antes'][name]:
                raise RuntimeError('ALTERACAO_CONCORRENTE')
            with tempfile.NamedTemporaryFile(dir=p.parent, delete=False) as stream:
                temp = Path(stream.name); stream.write(data)
            try:
                os.replace(temp, p)
            finally:
                temp.unlink(missing_ok=True)
    print(json.dumps(verificar(target, spec)))


if __name__ == '__main__':
    main()
