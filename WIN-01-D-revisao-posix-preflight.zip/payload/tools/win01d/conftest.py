from tests.conftest import *  # Fixtures sintéticas já existentes, sem alterar testes históricos.
from tests.phase3.conftest import fontes_sinteticas
