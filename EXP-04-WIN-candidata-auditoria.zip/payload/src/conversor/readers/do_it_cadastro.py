"""Cadastro Do It por participante; não cria boletos ou infere titularidade."""
from hashlib import sha256
from io import BytesIO
import json
import re

from openpyxl import load_workbook
from conversor.adapters.document_probe import SondadorLocal
from conversor.domain.canonical import Contato, LoteCanonico, Origem, Pessoa, RessalvaLeitura, Unidade
from conversor.domain.identity import chave_unidade
from .passaredo_cadastro import normalizar_documento, extrair_telefones, extrair_emails
from .text_support import ErroLeitura, id_estavel

CABECALHO=('Condômino','Telefone','E-mail','Divisão','Unidade','Vaga de garagem','Hobby Box',
           'Ramal','Baixou App','Perfil','Veículos','Nº documento','Data de Nascimento','Gênero','Status')


def texto(v):return str(v).strip()if v is not None else ''


class LeitorCadastroDoIt:
    formato_id='do_it_cadastro_xlsx_v1'

    def ler(self,conteudo,*,contexto):
        sonda=SondadorLocal().sondar(conteudo,arquivo_id='cadastro_doit')
        if sonda.tipo!='xlsx' or sonda.bloqueios or not sonda.completo:raise ErroLeitura('DOIT_CADASTRO_NAO_EXTRAIVEL')
        try:w=load_workbook(BytesIO(conteudo),data_only=False,keep_links=False)
        except Exception:raise ErroLeitura('DOIT_CADASTRO_INVALIDO')from None
        try:
            if len(w.worksheets)!=1:raise ErroLeitura('DOIT_CADASTRO_ABAS_AMBIGUAS')
            s=w.worksheets[0]
            if tuple(texto(c.value)for c in s[1])!=CABECALHO:raise ErroLeitura('DOIT_CADASTRO_CABECALHO_INVALIDO')
            if any(c.data_type=='f'for row in s for c in row):raise ErroLeitura('DOIT_CADASTRO_FORMULA_NAO_PERMITIDA')
            digest=sha256(conteudo).hexdigest();units={};pessoas=[];notas=[]
            def origem(n):return Origem(arquivo_id=contexto.arquivo_id,sha256=digest,
                leitor_versao=self.formato_id+'@1',linha=n,identificador=f'xlsx_aba1_r{n}_A_O')
            for row in s.iter_rows(min_row=2):
                n=row[0].row;v=[c.value for c in row]
                if not any(texto(x)for x in v):continue
                nome,divisao,numero=texto(v[0]),texto(v[3]),texto(v[4])
                if not nome or not divisao or not numero:
                    notas.append(RessalvaLeitura(codigo='DOIT_REGISTRO_SEM_IDENTIDADE_RETIDO',gravidade='alerta',
                        origens=(origem(n),),valores_originais=(json.dumps([texto(x)for x in v],ensure_ascii=False),)))
                    continue
                chave=chave_unidade(divisao,numero)
                uid=id_estavel('uni_doit_cad',contexto.condominio_id,chave)
                if uid in units and (units[uid].bloco_original,units[uid].unidade_original)!=(divisao,numero):
                    raise ErroLeitura('DOIT_CADASTRO_COLISAO_IDENTIDADE')
                units[uid]=Unidade(id=uid,condominio_id=contexto.condominio_id,administradora_id=contexto.administradora_id,
                    bloco_original=divisao,unidade_original=numero,chave_normalizada=chave,
                    normalizador_versao='identidade_real_v1',origem=origem(n))
                doc=normalizar_documento(v[11])
                partes=[p for p in re.split(r'[;,/\r\n]+',texto(v[1]))if p.strip()]
                segmentos=[extrair_telefones(p)for p in partes]
                invalidos=any(not p for p in segmentos)
                telefones=()if invalidos else tuple(dict.fromkeys(t for p in segmentos for t in p))
                try:emails=extrair_emails(v[2]);emails_invalidos=False
                except ErroLeitura as erro:
                    if erro.codigo!='PASSAREDO_EMAIL_INVALIDO':raise
                    emails=();emails_invalidos=True
                pid=id_estavel('pessoa_doit_cad',uid,n)
                pessoas.append(Pessoa(id=pid,unidade_id=uid,nome=nome,documento=doc,
                    documento_origem=origem(n)if doc else None,relacao_unidade=texto(v[9])or'papel_nao_informado',
                    contato=Contato(telefones=telefones[:5],emails=emails[:3],origem=origem(n)),origem=origem(n)))
                if texto(v[11])and not doc:notas.append(RessalvaLeitura(codigo='DOIT_DOCUMENTO_INVALIDO_RETIDO',
                    registro_id=pid,origens=(origem(n),),valores_originais=(texto(v[11]),)))
                if invalidos or emails_invalidos:notas.append(RessalvaLeitura(codigo='DOIT_CONTATO_INVALIDO_RETIDO',registro_id=pid,origens=(origem(n),)))
                notas.append(RessalvaLeitura(codigo='DOIT_PARTICIPANTE_ORIGINAL',gravidade='informativo',registro_id=pid,
                    origens=(origem(n),),valores_originais=(json.dumps({'divisao':divisao,'unidade':numero,'papel':texto(v[9]),
                        'status':texto(v[14]),'linha':n},ensure_ascii=False),)))
            if not pessoas:raise ErroLeitura('DOIT_CADASTRO_SEM_PARTICIPANTES')
            return LoteCanonico(unidades=tuple(units.values()),pessoas=tuple(pessoas),boletos=(),ressalvas=tuple(notas))
        finally:w.close()
