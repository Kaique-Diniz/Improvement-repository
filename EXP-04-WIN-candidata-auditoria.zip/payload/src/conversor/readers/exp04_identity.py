"""Identidade documental EXP-04 separada da administradora e integração aprovadas."""
from hashlib import sha256
from conversor.domain.recognition import normalizar_assinatura
from .bbz_cadastro import codigo_origem
from .bbz_xlsx import LeitorBBZXLSX
from .bbz_cadastro import LeitorCadastroBBZ
from .do_it_xlsx import CODIGO_TECNICO, LeitorDoItXLSX, identificar
from .do_it_cadastro import LeitorCadastroDoIt
from .text_support import ErroLeitura

PERFIS_EXP04=('on_brooklin','citzy_paulista','panorama_diadema_club','do_it_pinheiros')


def reconhecer_documental(conteudo,perfis,*,cadastro=False,escolha=None,identidade=None,doit=False):
    papel='cadastro'if cadastro else'inadimplencia'
    digest=sha256(conteudo).hexdigest()
    if doit:
        perfil=perfis['do_it_pinheiros']
        if cadastro:
            # Este cadastro nao contem identidade interna do condominio.
            if digest!=perfil['fontes_homologacao_sha256']['cadastro']:
                raise ErroLeitura('EXP04_CADASTRO_IDENTIDADE_NAO_COMPROVADA')
            formato=LeitorCadastroDoIt.formato_id
        else:
            identificar(conteudo)
            formato=LeitorDoItXLSX.formato_id
        codigo=CODIGO_TECNICO
    else:
        codigo,nome=identidade
        matches=[perfis[k]for k in PERFIS_EXP04 if k!='do_it_pinheiros'and
            normalizar_assinatura(nome)in{normalizar_assinatura(a)for a in perfis[k]['aliases']}]
        if not matches:return None
        if len(matches)!=1:raise ErroLeitura('EXP04_IDENTIDADE_AMBIGUA')
        perfil=matches[0]
        if codigo_origem(codigo)!=perfil['codigo_origem_documentado']:
            raise ErroLeitura('IDENTIDADE_DOCUMENTAL_CONFLITANTE')
        formato=LeitorCadastroBBZ.formato_id if cadastro else LeitorBBZXLSX.formato_id
    if escolha not in(None,'auto',perfil['id']):raise ErroLeitura('IDENTIDADE_DOCUMENTAL_CONFLITANTE')
    conhecidos=[p['id']for p in perfis.values()if p.get('fontes_homologacao_sha256',{}).get(papel)==digest]
    if conhecidos and conhecidos!=[perfil['id']]:raise ErroLeitura('IDENTIDADE_DOCUMENTAL_CONFLITANTE')
    return dict(perfil,identificacao_diagnostica='fonte_conhecida_por_hash'if conhecidos else'identidade_interna_validada',
        identidade_EXP04={'estado':'DOCUMENTAL_SEM_AUTORIZACAO_OPERACIONAL','codigo_origem':perfil['codigo_origem_documentado'],
            'politica_cobranca_aprovada':False,'vinculo_integracao_aprovado':False}),codigo,formato
