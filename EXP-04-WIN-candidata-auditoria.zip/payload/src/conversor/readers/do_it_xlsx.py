"""Do It: contrato próprio de posição/recibo/subtotais; sem régua ou cadastro."""
from datetime import datetime
from hashlib import sha256
from io import BytesIO
import json
import re

from openpyxl import load_workbook
from conversor.adapters.document_probe import SondadorLocal
from conversor.domain.canonical import Apontamento, Boleto, Composicao, ItemComposicao, LoteCanonico, Origem, Pessoa, RessalvaLeitura, Unidade
from conversor.domain.identity import chave_unidade
from .bbz_xlsx import moeda, data_fonte, somar, ZERO
from .text_support import ErroLeitura, id_estavel

CABECALHO = ('Recibo','Vencimento','Emissão','Conta','Histórico','',
             'Valor Original','Valor Principal','Multa','Atualização Monetária','Juros','Total')
NOME = 'DO IT PINHEIROS'
CODIGO_TECNICO = 'do_it_pinheiros_sem_codigo_interno'
UNIDADE = re.compile(r'^Bloco\s+(\S+)\s+-\s+Unidade\s+(\S+)\s*:\s*(.+)$')


def txt(v):
    return str(v).strip() if v is not None else ''


def falha(codigo, n=None):
    raise ErroLeitura(codigo, linha=n)


def carregar(conteudo):
    sonda = SondadorLocal().sondar(conteudo, arquivo_id='doit_estrutura')
    if sonda.tipo != 'xlsx' or sonda.bloqueios or not sonda.completo:
        falha('DOIT_XLSX_NAO_EXTRAIVEL')
    try:
        w = load_workbook(BytesIO(conteudo), data_only=False, keep_links=False)
    except Exception:
        falha('DOIT_XLSX_INVALIDO')
    try:
        if len(w.worksheets) != 1: falha('DOIT_ABAS_AMBIGUAS')
        s = w.worksheets[0]
        if any(c.data_type == 'f' for row in s for c in row): falha('DOIT_FORMULA_NAO_PERMITIDA')
        if any(txt(c.value) for row in s for c in row[12:]): falha('DOIT_COLUNAS_INESPERADAS')
        pos = re.fullmatch(r'Inadimplência\s+Posição em:\s*(\d{2}/\d{2}/\d{4})', txt(s['B1'].value))
        if not pos or any(txt(c.value) for c in s[1] if c.column != 2): falha('DOIT_POSICAO_INVALIDA')
        try: data_posicao = datetime.strptime(pos[1], '%d/%m/%Y').date()
        except ValueError: falha('DOIT_POSICAO_INVALIDA')
        if txt(s['A2'].value) != 'Condomínio: ' + NOME or any(txt(c.value) for c in s[2][1:]):
            falha('DOIT_IDENTIDADE_DIVERGENTE')
        if not txt(s['A3'].value).startswith('Endereço: ') or any(txt(c.value) for c in s[3][1:]):
            falha('DOIT_ENDERECO_CABECALHO_INVALIDO')
        if tuple(txt(c.value) for c in s[4][:12]) != CABECALHO: falha('DOIT_CABECALHO_INVALIDO')
        return w, s, data_posicao
    except Exception:
        w.close()
        raise


def identificar(conteudo):
    w, _, posicao = carregar(conteudo)
    w.close()
    return CODIGO_TECNICO, NOME, posicao


class LeitorDoItXLSX:
    formato_id = 'do_it_inadimplencia_xlsx_v1'

    def ler(self, conteudo, *, contexto):
        if contexto.codigo_condominio != CODIGO_TECNICO: falha('DOIT_CONTEXTO_DIVERGENTE')
        w, s, posicao = carregar(conteudo)
        try:
            digest = sha256(conteudo).hexdigest()
            def origem(n, colunas='A_L'):
                return Origem(arquivo_id=contexto.arquivo_id, sha256=digest,
                    leitor_versao=self.formato_id+'@1', linha=n,
                    identificador=f'xlsx_aba1_r{n}_{colunas}', data_fonte=posicao)
            units, people, boletos, notes, finais = [], [], [], [], []
            unidade = recibo = None
            totais_recibos = []; chaves = set(); vistos = set(); fechado = False
            ocorrencia = 0;cauda=[];cauda_fechada=False
            for row in s.iter_rows(min_row=5):
                n = row[0].row; v = tuple(c.value for c in row[:12]); a = txt(v[0])
                if not any(txt(c.value) for c in row): continue
                if fechado:
                    if cauda_fechada or any(txt(x)for x in v[:5]):falha('DOIT_CONTEUDO_APOS_FECHAMENTO',n)
                    vetor=tuple(moeda(x,n)for x in v[6:])
                    if txt(v[5])=='Total da unidade:' and len(cauda)<len(finais):
                        if vetor!=finais[len(cauda)]:falha('DOIT_RESUMO_UNIDADE_DIVERGENTE',n)
                        cauda.append(vetor)
                    elif txt(v[5])=='Total acumulado:' and len(cauda)==len(finais):
                        if vetor!=somar(finais):falha('DOIT_RESUMO_GERAL_DIVERGENTE',n)
                        cauda_fechada=True
                    else:falha('DOIT_RESUMO_INCOMPLETO_OU_AMBIGUO',n)
                    continue
                m = UNIDADE.fullmatch(a)
                if m:
                    if unidade is not None or recibo or any(txt(x) for x in v[1:]): falha('DOIT_UNIDADE_NAO_FECHADA', n)
                    chave = chave_unidade(m[1], m[2])
                    if chave in chaves: falha('DOIT_UNIDADE_DUPLICADA', n)
                    chaves.add(chave)
                    unidade = Unidade(id=id_estavel('uni_doit',contexto.condominio_id,chave),
                        condominio_id=contexto.condominio_id,administradora_id=contexto.administradora_id,
                        bloco_original=m[1],unidade_original=m[2],chave_normalizada=chave,
                        normalizador_versao='identidade_real_v1',origem=origem(n,'A'))
                    units.append(unidade); totais_recibos=[]
                    people.append(Pessoa(id=id_estavel('pessoa_doit',unidade.id),unidade_id=unidade.id,
                        nome=m[3],relacao_unidade='nome_no_cabecalho_financeiro',origem=origem(n,'A')))
                    continue
                if txt(v[5]) == 'Total acumulado:':
                    if unidade is not None or recibo or any(txt(x)for x in v[:5]): falha('DOIT_FECHAMENTO_FORA_CONTEXTO',n)
                    if tuple(moeda(x,n)for x in v[6:]) != somar(finais): falha('DOIT_TOTAL_GERAL_DIVERGENTE',n)
                    fechado=True
                    continue
                if txt(v[5]) == 'Total da unidade:':
                    if unidade is None or recibo or not totais_recibos or any(txt(x)for x in v[:5]): falha('DOIT_UNIDADE_FORA_CONTEXTO',n)
                    total=tuple(moeda(x,n)for x in v[6:])
                    if total!=somar(totais_recibos): falha('DOIT_TOTAL_UNIDADE_DIVERGENTE',n)
                    finais.append(total);unidade=None
                    continue
                if txt(v[4]) == 'Total do recibo:':
                    if unidade is None or recibo is None or any(txt(x)for x in (*v[:4],v[5])): falha('DOIT_RECIBO_FORA_CONTEXTO',n)
                    total=tuple(moeda(x,n)for x in v[6:])
                    if not recibo['itens'] or total!=somar(recibo['vetores']): falha('DOIT_TOTAL_RECIBO_DIVERGENTE',n)
                    bid=id_estavel('boleto_doit',unidade.id,recibo['identificador'],ocorrencia)
                    chave_recibo=(unidade.id,recibo['identificador'])
                    repetido=chave_recibo in vistos
                    vistos.add(chave_recibo)
                    # Não deduplicar recibos de linhas distintas. Identidade técnica
                    # separa a ocorrência, mantendo o identificador original na nota.
                    identificador=(recibo['identificador']+'_ocorrencia_'+str(ocorrencia)
                                   if repetido else recibo['identificador'])
                    if repetido:
                        notes.append(RessalvaLeitura(codigo='DOIT_IDENTIFICADOR_REPETIDO_EM_REVISAO',
                            registro_id=bid,origens=tuple(recibo['origens'])+(origem(n),)))
                    boletos.append(Boleto(id=bid,condominio_id=contexto.condominio_id,unidade_id=unidade.id,
                        identificador=identificador,vencimento=recibo['vencimento'],emissao=recibo['emissao'],
                        apontamentos=tuple(recibo['apontamentos']),
                        composicao=Composicao(itens=tuple(recibo['itens']),total_original=total[0]),
                        origens=tuple(recibo['origens'])+(origem(n),)))
                    notes.append(RessalvaLeitura(codigo='DOIT_RECIBO_RECONCILIADO',gravidade='informativo',registro_id=bid,
                        origens=tuple(recibo['origens'])+(origem(n),),valores_originais=(json.dumps({
                            'identificador_original':recibo['identificador'],'ordem_ocorrencia':ocorrencia,
                            'emissao_original':recibo['emissao_original'],
                            'componentes':recibo['componentes'],'totais':[format(x,'.2f')for x in total]},ensure_ascii=False),)))
                    totais_recibos.append(total);recibo=None
                    continue
                if unidade is None or txt(v[5]): falha('DOIT_LINHA_FORA_CONTEXTO',n)
                if a:
                    marca=re.fullmatch(r'([0-9]+)(?:\s+(A|AJ|J|AE))?',a)
                    if recibo is not None or not marca: falha('DOIT_RECIBO_INVALIDO',n)
                    ocorrencia+=1
                    # A ordem distingue ocorrências; igualdade de valor/data não deduplica.
                    emissao=None
                    if isinstance(v[2],datetime) or re.fullmatch(r'[0-9]{2}/[0-9]{2}/[0-9]{4}',txt(v[2])):
                        emissao=data_fonte(v[2],n)
                    recibo={'identificador':marca[1],'vencimento':data_fonte(v[1],n),
                        'emissao':emissao,'emissao_original':txt(v[2]),
                        'apontamentos':[Apontamento(codigo_original=marca[2],namespace_formato=self.formato_id,origem=origem(n,'A'))]if marca[2]else[],
                        'itens':[],'vetores':[],'origens':[],'componentes':[]}
                elif recibo is None or txt(v[1]) or txt(v[2]): falha('DOIT_CONTINUACAO_AMBIGUA',n)
                if not txt(v[3]) or not txt(v[4]): falha('DOIT_COMPONENTE_INCOMPLETO',n)
                vetor=tuple(moeda(x,n)for x in v[6:])
                idx=len(recibo['itens'])+1
                recibo['itens'].append(ItemComposicao(codigo=str(idx),descricao_original=txt(v[4]),
                    valor=vetor[0],origem=origem(n,'G')))
                recibo['vetores'].append(vetor);recibo['origens'].append(origem(n))
                recibo['componentes'].append({'linha':n,'conta':txt(v[3]),'historico':txt(v[4]),'original':format(vetor[0],'.2f')})
            if not fechado or unidade is not None or recibo or not boletos: falha('DOIT_FECHAMENTO_INCOMPLETO')
            if cauda and not cauda_fechada:falha('DOIT_RESUMO_INCOMPLETO_OU_AMBIGUO')
            notes.append(RessalvaLeitura(codigo='DOIT_FONTE_RECONCILIADA',gravidade='informativo',
                origens=(origem(1),origem(2)),valores_originais=(json.dumps({'posicao':posicao.isoformat(),
                    'unidades':len(units),'recibos':len(boletos),'endereco_cabecalho':txt(s['A3'].value)[len('Endereço: '):]},ensure_ascii=False),)))
            return LoteCanonico(unidades=tuple(units),pessoas=tuple(people),boletos=tuple(boletos),ressalvas=tuple(notes))
        finally:w.close()
