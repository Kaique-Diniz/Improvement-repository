"""EXP-04: pré-análise com hipótese explícita; não autoriza política ou integração."""
from collections import Counter, defaultdict
from decimal import Decimal

from conversor.domain.canonical import Contato, RessalvaLeitura
from conversor.domain.documents import resolver_documento
from conversor.domain.recognition import normalizar_assinatura
from conversor.application.bbz_cadastro import cruzar_cadastro_bbz, registrar_temporalidade_cadastro
from conversor.readers.bbz_cadastro import conferir_emissoes
from conversor.application.debt_descriptions import interpretar_lote_bbz, POLITICA_BBZ_CONDOMINIO_V11
from conversor.export.contract import LinhaExportacao, DividaExportacao
from conversor.export.identifiers import preencher_endereco
from conversor.readers.exp04_identity import PERFIS_EXP04
from conversor.readers.text_support import ErroLeitura

PAPEIS_TITULARES={'proprietario','proprietario: responsavel e morador','proprietario: responsavel nao morador'}


def associar_doit(lote,cadastro=None):
    """Correspondência exata de contexto/chave, papel, nome e documento válido.

    Divisões textuais do cadastro não viram blocos numéricos por inferência.
    Pessoas adicionais nunca geram boletos. Evidências de terceiro são retidas.
    """
    if cadastro is None:return lote,{'SEM_CADASTRO':len(lote.unidades)}
    escopos={(u.administradora_id,u.condominio_id)for u in lote.unidades}
    if any((u.administradora_id,u.condominio_id)not in escopos for u in cadastro.unidades):
        raise ErroLeitura('CADASTRO_DE_OUTRO_CONDOMINIO')
    unidades={u.id:u for u in cadastro.unidades};participantes=defaultdict(list)
    for p in cadastro.pessoas:
        u=unidades[p.unidade_id]
        participantes[(u.administradora_id,u.condominio_id,u.chave_normalizada)].append(p)
    pessoas={p.unidade_id:p for p in lote.pessoas};saida=[];notas=list(lote.ressalvas);stats=Counter()
    for u in lote.unidades:
        p=pessoas[u.id];grupo=participantes[(u.administradora_id,u.condominio_id,u.chave_normalizada)]
        titulares=[c for c in grupo if normalizar_assinatura(c.relacao_unidade)in PAPEIS_TITULARES]
        matches=[c for c in titulares if normalizar_assinatura(c.nome)==normalizar_assinatura(p.nome)]
        motivo=('DIVISAO_UNIDADE_NAO_COMPROVADA'if not grupo else 'PAPEL_TITULAR_NAO_COMPROVADO'if not titulares
                else 'TITULAR_AMBIGUO_OU_NOME_DIVERGENTE'if len(matches)!=1 else None)
        if motivo is None:
            c=matches[0];d=resolver_documento(c)
            if d.bloqueante or not d.valor:motivo='DOCUMENTO_TITULAR_NAO_COMPROVADO'
            elif any(resolver_documento(outro).valor==d.valor and normalizar_assinatura(outro.nome)!=normalizar_assinatura(c.nome)
                     for outro in titulares):motivo='DOCUMENTO_CONFLITANTE_ENTRE_TITULARES'
            else:
                p=p.model_copy(update={'documento':c.documento,'documento_origem':c.documento_origem,
                    'evidencias_documentais':tuple(e.model_copy(update={'titular_id':p.id})for e in d.evidencias),
                    'contato':c.contato})
                stats['ASSOCIACAO_INDIVIDUAL_COMPROVADA']+=1
        if motivo:
            stats[motivo]+=1
            notas.append(RessalvaLeitura(codigo='DOIT_'+motivo,registro_id=u.id,origens=(p.origem,)))
        saida.append(p)
    return lote.model_copy(update={'pessoas':tuple(saida),'ressalvas':tuple(notas)}),dict(stats)


def preparar(fontes,perfil_id,*,cadastro=None,data_ref=None):
    from conversor.web.service import reconhecer,ler
    if perfil_id not in PERFIS_EXP04:raise ErroLeitura('EXP04_PERFIL_NAO_SUPORTADO')
    perfil,codigo,leitor=reconhecer(fontes,perfil_informado=perfil_id)
    lote,_=ler(fontes,perfil,codigo,leitor,'inadimplencia')
    cad=None
    if cadastro is not None:
        pc,cc,lc=reconhecer(cadastro,cadastro=True,perfil_informado=perfil_id)
        if pc['id']!=perfil_id or cc!=codigo:raise ErroLeitura('CADASTRO_DE_OUTRO_CONDOMINIO')
        cad,ctx_cadastro=ler(cadastro,pc,cc,lc,'cadastro')
    descricoes={}
    if perfil['familia']=='bbz_exp04':
        lote,descricoes=interpretar_lote_bbz(lote,politica=POLITICA_BBZ_CONDOMINIO_V11)
        if cad is not None:
            lote,auditoria=cruzar_cadastro_bbz(lote,cad)
            if data_ref is not None:
                lote,auditoria=registrar_temporalidade_cadastro(lote,auditoria,
                    conferir_emissoes(cadastro,contexto=ctx_cadastro),data_ref=data_ref)
            retencoes=dict(Counter(m for u in auditoria['unidades'].values()for m in u['motivos']))
            if any(r.codigo=='BBZ_CADASTRO_PERIODO_ANTERIOR'for r in lote.ressalvas):retencoes['CADASTRO_DE_PERIODO_ANTERIOR']=1
        else:retencoes={'SEM_CADASTRO':len(lote.unidades)}
    else:lote,retencoes=associar_doit(lote,cad)
    if cad is not None:retencoes['ATUALIDADE_CADASTRAL_NAO_ATESTADA']=1
    return perfil,lote,cad,descricoes,retencoes


def projetar_hipotese(perfil,lote,*,data_ref,prazo_hipotetico,modo,endereco_padrao=None,descricoes=None):
    """DTOs somente de prévia comparativa. Sem código de integração aprovado.

    Chamada exige hipótese numérica explícita; não há default, aprovação ou UI
    que ative essa hipótese no MVP. O utilitário privado só emite agregados.
    """
    if perfil['id']not in PERFIS_EXP04 or type(prazo_hipotetico)is not int or not 0<=prazo_hipotetico<=3650 or modo not in('A','B'):
        raise ErroLeitura('EXP04_HIPOTESE_INVALIDA')
    descricoes=descricoes or {};pessoas={p.unidade_id:p for p in lote.pessoas};linhas=[];contagens=Counter()
    for u in lote.unidades:
        p=pessoas[u.id];endereco,_=preencher_endereco(p.contato.endereco,endereco_padrao)
        p=p.model_copy(update={'contato':p.contato.model_copy(update={'endereco':endereco.model_copy(update={'complemento':u.chave_normalizada})})})
        # Rótulo técnico deliberadamente distinto de qualquer destino histórico.
        cedente='EXP04_NAO_INTEGRAR_'+u.id.split(':')[-1][:24]
        base=dict(processamento_id='pre_analise_exp04',registro_id=u.id,nm_cedente_cedente=perfil['nome'],cedente=cedente,pessoa=p)
        boletos=sorted((b for b in lote.boletos if b.unidade_id==u.id),key=lambda b:(b.vencimento,b.identificador,b.id))
        excluidos=False;revisao=False;parcela=0
        for b in boletos:
            if b.composicao.total_original<=0:
                revisao=True;contagens['VALOR_NAO_POSITIVO_EM_REVISAO']+=1;continue
            if(data_ref-b.vencimento).days<=prazo_hipotetico:
                excluidos=True;contagens['PRAZO_HIPOTETICO_NAO_ATINGIDO']+=1;continue
            parcela+=1
            rotulo=descricoes[b.id].descricao if b.id in descricoes else 'RECIBO '+b.identificador.split('_ocorrencia_')[0]
            linhas.append(LinhaExportacao(**base,tipo='divida',divida=DividaExportacao(contrato=cedente,
                produto=perfil['nome'],nome_divida=rotulo,parcela=parcela,vencimento=b.vencimento,valor=b.composicao.total_original)))
        if modo=='B'and excluidos and not revisao:linhas.append(LinhaExportacao(**base,tipo='cadastral'))
    return linhas,dict(contagens)


def resumo_hipotese(perfil,lote,*,data_ref,prazo_hipotetico,descricoes=None):
    a,motivos=projetar_hipotese(perfil,lote,data_ref=data_ref,prazo_hipotetico=prazo_hipotetico,modo='A',descricoes=descricoes)
    b,_=projetar_hipotese(perfil,lote,data_ref=data_ref,prazo_hipotetico=prazo_hipotetico,modo='B',descricoes=descricoes)
    assert [l for l in b if l.tipo=='divida']==a
    return {'estado':'PRE_ANALISE_HIPOTETICA_NAO_HOMOLOGADA','data_ref':data_ref.isoformat(),
        'operador':'gt','dias_hipoteticos':prazo_hipotetico,'dividas':len(a),'cadastrais_B':len(b)-len(a),
        'valor_original':format(sum((l.divida.valor for l in a),Decimal(0)),'.2f'),
        'financeiro_A_B_igual':True,'motivos':motivos,'politica_aprovada':False,'integracao_aprovada':False}
