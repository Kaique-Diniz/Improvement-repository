from collections import Counter
from datetime import timedelta
from decimal import Decimal
from io import BytesIO
import json
from pathlib import Path

from openpyxl import load_workbook
import pytest
from fastapi.testclient import TestClient

from conversor.application.exp04_preparation import preparar,projetar_hipotese,resumo_hipotese
from conversor.export.contract import materializar
from conversor.export.xlsx import escrever_xlsx
from conversor.domain.template import Template,COLUNAS
from conversor.readers.text_support import ErroLeitura
from conversor.web.service import PERFIS,reconhecer,ler,analisar,PedidoDiagnostico,configurar
from conversor.web.ephemeral import criar_app_efemero
from tests.web.test_classic_local import boot,ORIGIN
from tests.int02.fixtures import caso as antigo,homologar,PERFIS as ANTIGOS
from .fixtures import NOVOS,REF,NOME,CPF,caso,conhecer,doit_fin,doit_cad,pessoa


@pytest.mark.parametrize('perfil',NOVOS)
def test_reconhecimento_e_leitores_por_papel(monkeypatch,perfil):
    f,c=caso(perfil);conhecer(monkeypatch,perfil,f,c)
    p,code,parser=reconhecer(f)
    assert p['id']==perfil and p['identidade_EXP04']['politica_cobranca_aprovada']is False
    pc,cc,lc=reconhecer(c,cadastro=True,perfil_informado=perfil)
    assert pc['id']==perfil and cc==code
    lote,_=ler(f,p,code,parser,'inadimplencia');cad,_=ler(c,pc,cc,lc,'cadastro')
    assert len(lote.boletos)==3 and not cad.boletos
    assert sum(b.composicao.total_original for b in lote.boletos)==Decimal('300.00')
    assert all(b.composicao.itens[1].valor==Decimal('-10.00')for b in lote.boletos)
    with pytest.raises(ErroLeitura):ler(c,p,code,parser,'cadastro')


@pytest.mark.parametrize('financeiro',NOVOS)
@pytest.mark.parametrize('cadastro',NOVOS)
def test_cruzamentos_de_cadastro(monkeypatch,financeiro,cadastro):
    f,cf=caso(financeiro);_,cc=caso(cadastro)
    conhecer(monkeypatch,financeiro,f,cf)
    if financeiro==cadastro:
        assert len(preparar(f,financeiro,cadastro=cf)[1].boletos)==3
    else:
        with pytest.raises(ErroLeitura):preparar(f,financeiro,cadastro=cc)


@pytest.mark.parametrize('perfil',NOVOS)
def test_politicas_pendentes_bloqueiam_mvp_sem_gravar(tmp_path,perfil):
    f,_=caso(perfil)
    assert PERFIS[perfil]['dias']is None
    with pytest.raises(ErroLeitura,match='EXP04_POLITICA_COBRANCA_NAO_APROVADA'):
        configurar(PERFIS[perfil],'ficticio')
    with pytest.raises(ErroLeitura,match='EXP04_POLITICA_COBRANCA_NAO_APROVADA'):
        analisar(f,PedidoDiagnostico(data_ref=REF,modo='B',condominio=perfil),processamento_id='ficticio',destino=tmp_path/'saida')
    assert not(tmp_path/'saida').exists()


@pytest.mark.parametrize('perfil',NOVOS)
@pytest.mark.parametrize('prazo',[30,60])
def test_limites_hipoteticos_A_B_30_colunas(tmp_path,monkeypatch,perfil,prazo):
    f,c=caso(perfil,dias=(prazo+1,prazo,prazo-1));conhecer(monkeypatch,perfil,f,c)
    p,lote,_,desc,_=preparar(f,perfil,cadastro=c)
    a,_=projetar_hipotese(p,lote,data_ref=REF,prazo_hipotetico=prazo,modo='A',descricoes=desc)
    b,_=projetar_hipotese(p,lote,data_ref=REF,prazo_hipotetico=prazo,modo='B',descricoes=desc)
    assert len(a)==1 and len(b)==2 and [x for x in b if x.tipo=='divida']==a
    assert a[0].divida.vencimento==REF-timedelta(days=prazo+1)and a[0].divida.valor==Decimal('100.00')
    assert b[1].divida is None
    vals=[materializar(x).valores for x in b]
    assert all(len(v)==30 for v in vals)and all(x==''for x in vals[-1][24:])
    # Somente DTOs fictícios são escritos neste teste; não habilita exportação real.
    path=tmp_path/'SINTETICO_NAO_IMPORTAR.xlsx'
    escrever_xlsx(b,Template(id='exp04_ficticio',nome='Sintetico',versao='1',espaco_final_coluna_27=False),path,data_ref=REF)
    w=load_workbook(path);assert tuple(c.value for c in w['Dados'][1])==COLUNAS;w.close()


@pytest.mark.parametrize('perfil',NOVOS)
def test_multiplicidade_financeira_e_cadastro_opcional(monkeypatch,perfil):
    f,c=caso(perfil,dias=(31,31,30));conhecer(monkeypatch,perfil,f,c)
    p,lote,_,desc,_=preparar(f,perfil)
    r=resumo_hipotese(p,lote,data_ref=REF,prazo_hipotetico=30,descricoes=desc)
    assert r['dividas']==2 and r['valor_original']=='200.00'and r['cadastrais_B']==1
    assert not r['politica_aprovada']and r['financeiro_A_B_igual']


@pytest.mark.parametrize('alteracao,codigo',[
    (lambda s:setattr(s['G8'],'value',999),'DOIT_TOTAL_RECIBO_DIVERGENTE'),
    (lambda s:setattr(s.cell(s.max_row-1,7),'value',999),'DOIT_RESUMO_UNIDADE_DIVERGENTE'),
    (lambda s:setattr(s.cell(s.max_row,7),'value',999),'DOIT_RESUMO_GERAL_DIVERGENTE'),
    (lambda s:setattr(s['E6'],'value','=1+1'),'DOIT_FORMULA_NAO_PERMITIDA'),
    (lambda s:s.delete_rows(s.max_row),'DOIT_RESUMO_INCOMPLETO_OU_AMBIGUO')])
def test_doit_fechamentos_formulas_e_cauda_recusam_alteracao(alteracao,codigo):
    with pytest.raises(ErroLeitura,match=codigo):preparar(doit_fin(mutar=alteracao),'do_it_pinheiros')


@pytest.mark.parametrize('tipo',['multiplo','parente','locatario','imobiliaria','invalido','nome_divergente','validado','divisao_pendente'])
def test_doit_A1_titularidade_e_retencoes(monkeypatch,tipo):
    if tipo=='multiplo':ps=[pessoa(),pessoa(documento='00000000272')]
    elif tipo in ('parente','locatario','imobiliaria'):
        ps=[pessoa(papel={'parente':'Proprietário: Cônjuge','locatario':'Inquilino: Responsável contratualmente','imobiliaria':'Imobiliária'}[tipo])]
    elif tipo=='invalido':ps=[pessoa(documento='00000000000')]
    elif tipo=='nome_divergente':ps=[pessoa(nome='Outra Pessoa Ficticia')]
    elif tipo=='divisao_pendente':ps=[pessoa(divisao='SETOR RESIDENCIAL')]
    else:ps=[pessoa()]
    f,c=doit_fin(),doit_cad(ps);conhecer(monkeypatch,'do_it_pinheiros',f,c)
    p,lote,_,desc,ret=preparar(f,'do_it_pinheiros',cadastro=c)
    linhas,_=projetar_hipotese(p,lote,data_ref=REF,prazo_hipotetico=30,modo='A')
    assert len(linhas)==1
    val=materializar(linhas[0]).valores
    assert val[3]==NOME and (val[2]==CPF)==(tipo=='validado')
    assert bool(val[21])==(tipo=='validado')


def test_doit_cadastro_participantes_nao_geram_boletos_e_orfao_retido(monkeypatch):
    ps=[pessoa(),pessoa(nome='Outra Pessoa Ficticia',papel='Proprietário: Filho')]
    f,c=doit_fin(),doit_cad(ps,mutar=lambda s:s.append(['']*11+['00000000191']))
    conhecer(monkeypatch,'do_it_pinheiros',f,c)
    _,lote,cad,_,_=preparar(f,'do_it_pinheiros',cadastro=c)
    assert len(cad.pessoas)==2 and len(cad.unidades)==1 and not cad.boletos
    assert len(lote.boletos)==3 and any(r.codigo=='DOIT_REGISTRO_SEM_IDENTIDADE_RETIDO'for r in cad.ressalvas)


def test_doit_cadastro_novo_nao_confirmado_so_pela_escolha():
    with pytest.raises(ErroLeitura,match='EXP04_CADASTRO_IDENTIDADE_NAO_COMPROVADA'):
        reconhecer(doit_cad(),cadastro=True,perfil_informado='do_it_pinheiros')


@pytest.mark.parametrize('perfil',NOVOS)
def test_HTTP_novos_reconhecem_isolam_e_bloqueiam_politica(tmp_path,monkeypatch,perfil):
    f,cad=caso(perfil);conhecer(monkeypatch,perfil,f,cad)
    app=criar_app_efemero(area_temporaria=tmp_path)
    with TestClient(app,base_url=ORIGIN)as c:
        boot(c)
        r=c.post('/api/identificar',files={'inadimplencia':('nome-enganoso.xlsx',f)})
        assert r.status_code==200 and r.json()['perfil']==perfil
        r=c.post('/api/conversoes',data={'data_ref':REF.isoformat(),'modo':'B','condominio':perfil},
            files={'inadimplencia':('outro-condominio.xlsx',f),'cadastro':('cadastro.bin',cad)})
        assert r.status_code==422 and r.json()['detail']=='EXP04_POLITICA_COBRANCA_NAO_APROVADA'
        assert 'Pessoa'not in r.text and CPF not in r.text
    assert not list(tmp_path.iterdir())


@pytest.mark.parametrize('perfil',ANTIGOS)
def test_HTTP_seis_antigos_continuam_convertendo_e_baixando(tmp_path,monkeypatch,perfil):
    x=antigo(perfil);homologar(monkeypatch,[x])
    with TestClient(criar_app_efemero(area_temporaria=tmp_path),base_url=ORIGIN)as c:
        boot(c)
        idr=c.post('/api/identificar',files={'inadimplencia':('arquivo.bin',x.financeiro)})
        assert idr.status_code==200 and idr.json()['perfil']==perfil
        r=c.post('/api/conversoes',data={'data_ref':x.ref.isoformat(),'modo':'B','condominio':perfil},
            files={'inadimplencia':('arquivo.bin',x.financeiro),'cadastro':('cadastro.bin',x.cadastro)})
        assert r.status_code==200
        saida=c.get('/api/conversoes/'+r.json()['id']+'/excel')
        assert saida.status_code==200
        w=load_workbook(BytesIO(saida.content));assert tuple(c.value for c in w['Dados'][1])==COLUNAS;w.close()
    assert not list(tmp_path.iterdir())
