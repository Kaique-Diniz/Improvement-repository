"""Recusa estática de links, extras e divergências; não certifica NTFS."""
from hashlib import sha256
from pathlib import Path
import pytest
import os

from tools.exp04.reconstruir import arquivos, verificar, Bloqueio
from tools.exp04.prereconciliar import carregar_guard, HASH_GUARD_R1, ErroSeguro


def criar_link(p, destino, *, diretorio=False):
    try:
        p.symlink_to(destino, target_is_directory=diretorio)
    except OSError as e:
        if os.name == 'nt' and getattr(e, 'winerror', None) == 1314:
            pytest.skip('EXP04_SYMLINK_SEM_PRIVILEGIO_1314; controle nativo NAO_VALIDADO')
        raise


def test_verificar_hashes_extras_e_conteudo(tmp_path):
    (tmp_path/'src').mkdir()
    p = tmp_path/'src/modulo.py'
    p.write_text('SINTETICO = True\n', encoding='utf-8')
    expected = arquivos(tmp_path)
    assert verificar(tmp_path, expected) == 1
    p.write_text('SINTETICO = False\n', encoding='utf-8')
    with pytest.raises(Bloqueio, match='CONTEUDO_CANDIDATA_DIVERGENTE'):
        verificar(tmp_path, expected)
    expected = arquivos(tmp_path)
    (tmp_path/'extra.py').write_text('', encoding='utf-8')
    with pytest.raises(Bloqueio):
        verificar(tmp_path, expected)


@pytest.mark.parametrize('tipo', ['arquivo', 'quebrado', 'pai', 'extra'])
def test_nao_atravessa_links_esperados_ou_extras(tmp_path, tipo):
    outside = tmp_path/'externo'
    outside.mkdir()
    (outside/'modulo.py').write_text('SINTETICO = True\n', encoding='utf-8')
    root = tmp_path/'candidata'
    root.mkdir()
    expected = {'src/modulo.py': sha256((outside/'modulo.py').read_bytes()).hexdigest()}
    if tipo == 'pai':
        criar_link(root/'src', outside, diretorio=True)
    else:
        (root/'src').mkdir()
        (root/'src/modulo.py').write_bytes((outside/'modulo.py').read_bytes())
        if tipo == 'arquivo':
            (root/'src/modulo.py').unlink()
            criar_link(root/'src/modulo.py', outside/'modulo.py')
        elif tipo == 'quebrado':
            criar_link(root/'inesperado', outside/'ausente')
        else:
            criar_link(root/'extra', outside, diretorio=True)
    with pytest.raises(Bloqueio, match='LINK_OU_REPARSE_RECUSADO'):
        verificar(root, expected)


def test_guard_R1_nao_e_substituido_por_codigo_local_nao_auditado(tmp_path):
    p = tmp_path/'tools/reconciliacao_privada/seguranca.py'
    p.parent.mkdir(parents=True)
    p.write_text('raise RuntimeError("NAO_EXECUTAR")\n', encoding='utf-8')
    with pytest.raises(ErroSeguro, match='VERIFICADOR_R1_DIVERGENTE'):
        carregar_guard(tmp_path)
