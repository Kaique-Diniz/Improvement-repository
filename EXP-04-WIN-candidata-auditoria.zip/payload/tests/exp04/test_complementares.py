"""Somente documentos fabricados; nenhuma linha dos anexos privados."""
from datetime import datetime
from hashlib import sha256
from io import BytesIO
import json

from fastapi.testclient import TestClient
from openpyxl import Workbook
from openpyxl.utils.datetime import to_excel
import pytest

from conversor.application.exp04_preparation import preparar, projetar_hipotese
from conversor.domain.template import COLUNAS
from conversor.export.contract import materializar
from conversor.export.identifiers import EnderecoPadrao
from conversor.readers.text_support import ErroLeitura
from conversor.web.ephemeral import criar_app_efemero
from conversor.web.service import PERFIS, reconhecer
from tests.int02.fixtures import PERFIS as ANTIGOS, caso as antigo, homologar
from tests.web.test_classic_local import boot, ORIGIN
from tools.exp04.prereconciliar import historico, ErroSeguro, main
from .fixtures import NOVOS, REF, CPF, caso, conhecer, doit_fin, doit_cad, pessoa, salvar


@pytest.mark.parametrize('origem', (*ANTIGOS, *NOVOS))
@pytest.mark.parametrize('selecionado', (*ANTIGOS, *NOVOS))
def test_financeiro_de_outro_perfil_nunca_e_associado(monkeypatch, origem, selecionado):
    if origem in ANTIGOS:
        x = antigo(origem)
        homologar(monkeypatch, [x])
        raw = x.financeiro
    else:
        raw, cad = caso(origem)
        conhecer(monkeypatch, origem, raw, cad)
    if origem == selecionado:
        assert reconhecer(raw, perfil_informado=selecionado)[0]['id'] == origem
    else:
        with pytest.raises(ErroLeitura):
            reconhecer(raw, perfil_informado=selecionado)


@pytest.mark.parametrize('perfil', NOVOS)
def test_endereco_sintetico_em_A_B_nao_altera_financeiro(perfil):
    f, _ = caso(perfil)
    p, lote, _, desc, _ = preparar(f, perfil)
    endereco = EnderecoPadrao(endereco=dict(logradouro='Rua Sintetica', numero='10', cep='00000000',
                              bairro='Bairro Ficticio', cidade='Cidade Ficticia', uf='SP'),
                              evidencia=dict(arquivo='SINTETICO.xlsx', sha256='1'*64,
                                             aba='Sintetica', celulas={'logradouro': 'A1'}))
    sem, _ = projetar_hipotese(p, lote, data_ref=REF, prazo_hipotetico=30, modo='B', descricoes=desc)
    com, _ = projetar_hipotese(p, lote, data_ref=REF, prazo_hipotetico=30, modo='B',
                               descricoes=desc, endereco_padrao=endereco)
    assert [(l.tipo, l.divida) for l in com] == [(l.tipo, l.divida) for l in sem]
    for l in com:
        v = materializar(l).valores
        assert v[4] == 'Rua Sintetica' and v[5] == '10' and v[10] == 'SP'
        assert v[6] == lote.unidades[0].chave_normalizada


@pytest.mark.parametrize('perfil', NOVOS)
def test_contexto_novo_isolado_e_descarte_explicito(tmp_path, perfil):
    raw, _ = caso(perfil)
    app = criar_app_efemero(area_temporaria=tmp_path)
    with TestClient(app, base_url=ORIGIN) as c:
        boot(c)
        r = c.post('/api/identificar', files={'inadimplencia': ('ignorar-nome.xlsx', raw)})
        assert r.status_code == 200
        url = '/api/contextos/' + r.json()['contexto'] + '/configuracao'
        assert c.get(url).status_code == 200
        owner = c.cookies.get('conversor_session')
        headers = dict(c.headers)
        c.cookies.clear()
        boot(c)
        assert c.get(url).status_code == 404
        c.cookies.clear()
        c.cookies.set('conversor_session', owner)
        c.headers.update(headers)
        assert c.delete('/api/sessao').status_code == 200
        boot(c)
        assert c.get(url).status_code == 404
    assert not list(tmp_path.iterdir())


def test_doit_recibo_repetido_preserva_ocorrencias_e_comercial():
    def repetir(s):
        s['A9'] = s['A6'].value
    raw = doit_fin(dias=(31, 31, 29), bloco='2', numero='LOJA01', mutar=repetir)
    _, lote, _, _, _ = preparar(raw, 'do_it_pinheiros')
    assert len(lote.boletos) == 3
    assert lote.boletos[0].identificador == '90000000'
    assert lote.boletos[1].identificador.startswith('90000000_ocorrencia_')
    assert len({b.id for b in lote.boletos}) == 3
    assert any(r.codigo == 'DOIT_IDENTIFICADOR_REPETIDO_EM_REVISAO' for r in lote.ressalvas)
    assert lote.unidades[0].bloco_original == '2' and lote.unidades[0].unidade_original == 'LOJA01'
    assert all(b.emissao is None for b in lote.boletos)  # token opaco não é data


@pytest.mark.parametrize('doc,valido', [('00123456000149', True), ('00123456000140', False)])
def test_doit_CNPJ_com_zeros_e_documento_invalido_retido(monkeypatch, doc, valido):
    f, c = doit_fin(), doit_cad([pessoa(documento=doc)])
    conhecer(monkeypatch, 'do_it_pinheiros', f, c)
    p, lote, _, _, _ = preparar(f, 'do_it_pinheiros', cadastro=c)
    linhas, _ = projetar_hipotese(p, lote, data_ref=REF, prazo_hipotetico=30, modo='A')
    assert materializar(linhas[0]).valores[2] == (doc if valido else '')


def test_doit_blocos_distintos_nao_promovem_contatos(monkeypatch):
    f, c = doit_fin(bloco='2'), doit_cad([pessoa(divisao='1')])
    conhecer(monkeypatch, 'do_it_pinheiros', f, c)
    p, lote, _, _, ret = preparar(f, 'do_it_pinheiros', cadastro=c)
    linhas, _ = projetar_hipotese(p, lote, data_ref=REF, prazo_hipotetico=30, modo='A')
    assert not materializar(linhas[0]).valores[2]
    assert ret['DIVISAO_UNIDADE_NAO_COMPROVADA'] == 1


def test_valor_nao_positivo_em_revisao_nao_libera_linha_B():
    def zerar_primeiro(s):
        for row in (6, 7):
            for col in (7, 8, 12):
                s.cell(row, col).value = 0
        for row in (10, 11, 12, 13):
            for col in (7, 8, 12):
                s.cell(row, col).value = 100
    raw = doit_fin(dias=(31, 30), componentes=[('COTA SINTETICA', '100.00')], mutar=zerar_primeiro)
    p, lote, _, _, _ = preparar(raw, 'do_it_pinheiros')
    linhas, motivos = projetar_hipotese(p, lote, data_ref=REF, prazo_hipotetico=30, modo='B')
    assert not linhas and motivos['VALOR_NAO_POSITIVO_EM_REVISAO'] == 1
    assert motivos['PRAZO_HIPOTETICO_NAO_ATINGIDO'] == 1


@pytest.mark.parametrize('tipo', ['serial', 'datetime', 'texto'])
def test_template_historico_data_Excel_sem_aba_Dados(tipo):
    w = Workbook()
    s = w.active
    s.title = 'Historico Sintetico'
    s.append([c + (' ' if c == 'NM_DIVIDA_CEDENTE' else '') for c in COLUNAS])
    v = [None] * 30
    v[6] = 'BL1-UNI000001'
    d = datetime(2026, 9, 30)
    v[28] = to_excel(d) if tipo == 'serial' else d if tipo == 'datetime' else '30/09/2026'
    v[29] = '100,00'
    s.append(v)
    s['AE2'].number_format = 'General'  # coluna apenas estilizada, sem dado
    r, counter = historico(salvar(w))
    assert r['financeiras'] == 1 and r['valor_original'] == '100.00'
    assert list(counter)[0][1:] == ('2026-09-30', '100.00')


def test_template_formula_e_coluna_extra_nao_sao_evidencia():
    for formula in (False, True):
        w = Workbook()
        s = w.active
        s.append(COLUNAS)
        v = [None] * 30
        v[6], v[28], v[29] = 'BL1-UNI1', '30/09/2026', '=1+1' if formula else 100
        s.append(v)
        if not formula:
            s['AE2'] = 'EXTRA'
        with pytest.raises(ErroSeguro, match='TEMPLATE_FORMULA_OU_COLUNA_EXTRA'):
            historico(salvar(w))


def test_cli_nao_imprime_argumento_privado_ou_traceback(capsys):
    assert main(['--opcao-inexistente', 'DADO_PRIVADO_NAO_PUBLICAR']) == 2
    out = capsys.readouterr()
    assert 'DADO_PRIVADO' not in out.out and not out.err
    assert json.loads(out.out)['codigo'] == 'ARGUMENTOS_EXP04_INVALIDOS'


@pytest.mark.parametrize('perfil', NOVOS[:3])
def test_codigo_de_destino_historico_nao_e_codigo_de_origem(perfil):
    from tests.bbz.conftest import planilha
    p = PERFIS[perfil]
    destino = {'on_brooklin': '3132', 'citzy_paulista': '3310', 'panorama_diadema_club': '653'}[perfil]
    with pytest.raises(ErroLeitura, match='IDENTIDADE_DOCUMENTAL_CONFLITANTE'):
        reconhecer(planilha(codigo=destino, nome=p['aliases'][0]))
