from datetime import date,timedelta
from decimal import Decimal
from io import BytesIO
from hashlib import sha256
from openpyxl import Workbook

from tests.bbz.conftest import planilha,unidade,recibo
from tests.bbz.cadastro_fixtures import cadastro as pdf_cadastro,ficha
from conversor.web.service import PERFIS
from conversor.readers.do_it_xlsx import CABECALHO
from conversor.readers.do_it_cadastro import CABECALHO as CAD

REF=date(2026,11,9)
NOME='Pessoa Integralmente Ficticia'
CPF='00000000191'
NOVOS=('on_brooklin','citzy_paulista','panorama_diadema_club','do_it_pinheiros')


def salvar(w):
    out=BytesIO();w.save(out);w.close();return out.getvalue()


def doit_fin(*,dias=(31,30,29),componentes=None,bloco='1',numero='000001',nome=NOME,cauda=True,mutar=None):
    w=Workbook();s=w.active
    s.append(['','Inadimplência\nPosição em: 09/11/2026',''])
    s.append(['Condomínio: DO IT PINHEIROS']);s.append(['Endereço: Rua Ficticia 10'])
    s.append(CABECALHO);s.append([f'Bloco {bloco} - Unidade {numero} : {nome}'])
    unit=[Decimal(0)]*6
    for i,d in enumerate(dias):
        total=[Decimal(0)]*6
        for j,(historico,valor)in enumerate(componentes or [('COTA FICTICIA','110.00'),('AJUSTE FICTICIO','-10.00')]):
            v=Decimal(valor);vet=[v,v,Decimal(0),Decimal(0),Decimal(0),v]
            s.append([str(90000000+i)if j==0 else'',REF-timedelta(days=d)if j==0 else'',
                      '999999'if j==0 else'',str(j+1),historico,'']+[float(x)for x in vet])
            total=[a+b for a,b in zip(total,vet)]
        s.append(['','','','','Total do recibo:','']+[float(x)for x in total])
        unit=[a+b for a,b in zip(unit,total)]
    s.append(['','','','','','Total da unidade:']+[float(x)for x in unit])
    s.append(['','','','','','Total acumulado:']+[float(x)for x in unit])
    if cauda:
        s.append(['','','','','','Total da unidade:']+[float(x)for x in unit])
        s.append(['','','','','','Total acumulado:']+[float(x)for x in unit])
    if mutar:mutar(s)
    return salvar(w)


def pessoa(*,nome=NOME,divisao='1',numero='000001',papel='Proprietário',documento=CPF,email='titular@example.invalid',telefone='(11) 90000-0001'):
    return [nome,telefone,email,divisao,numero,'','','','Sim',papel,'',documento,'','','Ativo']


def doit_cad(pessoas=None,mutar=None):
    w=Workbook();s=w.active;s.append(CAD)
    for p in pessoas or [pessoa()]:s.append(p)
    if mutar:mutar(s)
    return salvar(w)


def caso(perfil,*,dias=None,nome_cad=NOME,documento=CPF):
    if perfil=='do_it_pinheiros':return doit_fin(dias=dias or(31,30,29)),doit_cad([pessoa(nome=nome_cad,documento=documento)])
    p=PERFIS[perfil];days=dias or(31,30,29)
    fin=planilha([dict(unidade('000001',bloco='0',recibos=[recibo(str(900000+i),due=REF-timedelta(days=d),
        componentes=[('COTA CONDOMINIAL 09/2026','110.00'),('DESCONTO COTA CONDOMINIAL','-10.00')])for i,d in enumerate(days)]),nome=NOME)],
        codigo=p['codigo_origem_documentado'],nome=p['aliases'][0])
    cad=pdf_cadastro([ficha(nome=nome_cad,documento=documento)],codigo=p['codigo_origem_documentado'],nome=p['aliases'][0])
    return fin,cad


def conhecer(monkeypatch,perfil,fin,cad):
    for role,blob in [('inadimplencia',fin),('cadastro',cad)]:
        monkeypatch.setitem(PERFIS[perfil]['fontes_homologacao_sha256'],role,sha256(blob).hexdigest())
