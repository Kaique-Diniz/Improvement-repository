"""EXP-04: somente fixtures construídas do zero, sem documentos reais."""
