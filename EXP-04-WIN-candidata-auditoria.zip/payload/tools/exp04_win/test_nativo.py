"""Somente Windows real; inventário de ACL não é comprovação de isolamento."""
import ctypes
from ctypes import wintypes
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess

import pytest
from conversor.adapters import windows_acl_evidence as wae
from conversor.adapters.private_json import escrever_json
from conversor.adapters.protected_sources import FontesLocaisProtegidas
from conversor.readers.contracts import FonteProtegida
from conversor.readers.text_support import ErroLeitura
from tools.exp04_win.ntfs import inventariar

pytestmark = pytest.mark.skipif(os.name != 'nt', reason='WINDOWS_REAL_NAO_DISPONIVEL; NAO_VALIDADO')


def test_ordinal_nativo_case_insensitive_sem_casefold():
    assert wae._compare_string_ordinal_ignore_case('ação.TXT', 'AÇÃO.txt') == 0
    assert wae._compare_string_ordinal_ignore_case('a', 'b') == -1
    assert wae._compare_string_ordinal_ignore_case('b', 'a') == 1
    assert wae._compare_string_ordinal_ignore_case('ß', 'ss') != 0


def test_ordinal_nativo_preserva_sufixo_apos_nao_BMP():
    assert wae._compare_string_ordinal_ignore_case('a\U0001f600x', 'a\U0001f600y') != 0
    assert wae._compare_string_ordinal_ignore_case('a\U0001f600x', 'a\U0001f600x') == 0


def test_alias_8_3_real_e_arquivo_diferente(tmp_path):
    folder = tmp_path/'Pasta Sintetica Longa Para Alias'
    folder.mkdir()
    path = folder/'Arquivo Sintetico Longo.txt'
    path.write_bytes(b'SINTETICO')
    other = folder/'Outro Arquivo Sintetico.txt'
    other.write_bytes(b'SINTETICO')
    api = ctypes.WinDLL('kernel32', use_last_error=True).GetShortPathNameW
    api.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
    api.restype = wintypes.DWORD
    buf = ctypes.create_unicode_buffer(32768)
    n = api(str(path), buf, len(buf))
    assert 0 < n < len(buf), 'GET_SHORT_PATH_FALHOU'
    alias = buf.value
    if alias.casefold() == str(path).casefold():
        pytest.skip('ALIAS_8_3_NAO_DISPONIVEL; expansao real NAO_VALIDADA')
    assert wae._mesmo_path_normalizado(alias, str(path)) is True
    assert wae._mesmo_path_normalizado(alias, str(other)) is False


def test_caminhos_distintos_nao_equivalem_por_conteudo(tmp_path):
    a, b = tmp_path/'um.txt', tmp_path/'dois.txt'
    a.write_bytes(b'SINTETICO')
    b.write_bytes(a.read_bytes())
    assert wae._mesmo_path_normalizado(str(a), str(b)) is False


def test_hardlink_rejeitado_no_contrato_diagnostico(tmp_path):
    a, b = tmp_path/'origem.txt', tmp_path/'hardlink.txt'
    a.write_bytes(b'SINTETICO')
    os.link(a, b)
    assert os.stat(a).st_ino == os.stat(b).st_ino and os.stat(a).st_nlink >= 2
    assert wae._mesmo_path_normalizado(str(a), str(b)) is False
    ev = wae.coletar_evidencia_acl(str(a), str(b), owner_sid='S-OWN-SINTETICO', group_sid=None, aces=[])
    assert ev['caminho_coincide'] is False
    assert ev['autoriza_acesso'] is False and ev['aplicada_ao_leitor'] is False


def test_junction_externa_recusada_pelo_leitor_producao(tmp_path):
    root, outside = tmp_path/'area', tmp_path/'externa'
    root.mkdir()
    outside.mkdir()
    data = b'SINTETICO_SEM_DOCUMENTOS'
    (outside/'fonte.txt').write_bytes(data)
    link = root/'junction'
    # Junction não exige habilitar criação de symlinks. Sem elevar privilégios.
    env = dict(os.environ, EXP04_JUNCTION_LINK=str(link), EXP04_JUNCTION_TARGET=str(outside))
    p = subprocess.run('cmd.exe /d /v:off /c mklink /J "%EXP04_JUNCTION_LINK%" "%EXP04_JUNCTION_TARGET%"',
                       env=env, capture_output=True, timeout=20, check=False)
    assert p.returncode == 0, 'JUNCTION_NAO_CRIADA'
    try:
        fonte = FonteProtegida(arquivo_id='sintetico', sha256=sha256(data).hexdigest())
        with pytest.raises(ErroLeitura, match='FONTE_FORA_DA_AREA_AUTORIZADA'):
            FontesLocaisProtegidas(root, {'sintetico': 'junction/fonte.txt'}).ler(fonte)
        assert (outside/'fonte.txt').read_bytes() == data
    finally:
        # rmdir remove só a junção criada pelo teste; nunca seu destino.
        link.rmdir()


def test_inventario_ntfs_da_escrita_preserva_pendencia(tmp_path, request):
    arquivo = tmp_path/'auditoria_sintetica.json'
    obj = {'tipo': 'EXP04_WIN_SINTETICO', 'documento_real': False}
    escrever_json(arquivo, obj)
    before = sha256(arquivo.read_bytes()).hexdigest()
    r = inventariar(arquivo)
    assert r['sistema_arquivos'] == 'NTFS', 'VOLUME_NAO_NTFS'
    assert r['dacl_efetiva_homologada'] is False
    assert r['acesso_outro_usuario_testado'] is False
    assert r['politica_integrada_ao_escritor'] is False
    assert sha256(arquivo.read_bytes()).hexdigest() == before
    assert json.loads(arquivo.read_text(encoding='utf-8')) == obj
    request.node.user_properties.append(('inventario_ntfs', json.dumps(r, ensure_ascii=True, sort_keys=True)))
    request.node.user_properties.append(('seguranca_ntfs', 'DACL_WINDOWS_NAO_VALIDADA; EVIDENCIA_INSUFICIENTE'))
