"""Erros esperados de capacidade não ocultam falhas inesperadas."""
from pathlib import Path
from types import SimpleNamespace
import json
import xml.etree.ElementTree as ET

import pytest
from tests import windows_support as suporte
from tools.exp04_win import ntfs
from tools.exp04_win.executar import ler_junit, resumo, fora_git, Bloqueio, sanitizar_xml


def test_1314_so_no_windows_produz_skip_explicito(monkeypatch, tmp_path):
    monkeypatch.setattr(suporte, '_windows', lambda: True)
    def negar(*a, **k):
        e = OSError('SENTINELA_PRIVADA_NAO_EXIBIR')
        e.winerror = 1314
        raise e
    monkeypatch.setattr(Path, 'symlink_to', negar)
    with pytest.raises(pytest.skip.Exception, match='1314.*NAO_VALIDADA'):
        suporte.criar_symlink(tmp_path/'link', tmp_path/'alvo')


@pytest.mark.parametrize('windows,winerror', [(False, 1314), (True, 5), (True, 183)])
def test_outros_erros_nao_viram_skip(monkeypatch, tmp_path, windows, winerror):
    monkeypatch.setattr(suporte, '_windows', lambda: windows)
    def negar(*a, **k):
        e = OSError('FALHA_SINTETICA')
        e.winerror = winerror
        raise e
    monkeypatch.setattr(Path, 'symlink_to', negar)
    with pytest.raises(OSError):
        suporte.criar_symlink(tmp_path/'link', tmp_path/'alvo')


def test_sonda_nao_windows_nao_simula_aprovacao(monkeypatch):
    monkeypatch.setattr(ntfs, 'os', SimpleNamespace(name='posix'))
    with pytest.raises(ntfs.EvidenciaInsuficiente, match='WINDOWS_REAL_NAO_DISPONIVEL'):
        ntfs.inventariar('NAO_ABRIR')


@pytest.mark.parametrize('saida,codigo', [
    ('{"caminho":"SENTINELA_PRIVADA"}', 'SONDA_RESULTADO_INVALIDO'),
    ('NAO_JSON', 'SONDA_NTFS_INDISPONIVEL'),
])
def test_sonda_recusa_saida_nao_sanitizada(monkeypatch, saida, codigo):
    monkeypatch.setattr(ntfs, 'os', SimpleNamespace(name='nt'))
    monkeypatch.setattr(ntfs.subprocess, 'run', lambda *a, **k: SimpleNamespace(returncode=0, stdout=saida))
    with pytest.raises(ntfs.EvidenciaInsuficiente, match=codigo) as e:
        ntfs.inventariar('CAMINHO_SINTETICO')
    assert 'SENTINELA' not in str(e.value)


def test_sonda_timeout_nao_expoe_caminho(monkeypatch):
    monkeypatch.setattr(ntfs, 'os', SimpleNamespace(name='nt'))
    def falhar(*a, **k):
        raise TimeoutError('CAMINHO_PRIVADO_NAO_EXIBIR')
    monkeypatch.setattr(ntfs.subprocess, 'run', falhar)
    with pytest.raises(ntfs.EvidenciaInsuficiente, match='SONDA_NTFS_INDISPONIVEL') as e:
        ntfs.inventariar('CAMINHO_SINTETICO')
    assert 'CAMINHO_PRIVADO' not in str(e.value)


def test_junit_skip_nunca_significa_controle_aprovado(tmp_path):
    xml = tmp_path/'sintetico.xml'
    xml.write_text('<testsuites><testsuite><testcase classname="tests.modulo" name="test_link">'
                   '<skipped message="1314; NAO_VALIDADA"/></testcase></testsuite></testsuites>', encoding='utf-8')
    cases = ler_junit(xml)
    assert cases[0]['estado'] == 'NÃO_VALIDADO'
    r = resumo(cases, 0, 1)
    assert r['estado_testes'] == 'NÃO_VALIDADO' and r['execucao_sem_falhas']
    assert resumo(cases, 2, 1)['estado_testes'] == 'FALHOU'
    assert resumo(cases, 0, 2)['estado_testes'] == 'FALHOU'


@pytest.mark.parametrize('tipo', ['normal', 'danificado', 'bare'])
def test_evidencias_git_mesmo_com_metadata_danificada_bloqueiam(tmp_path, tipo):
    area = tmp_path/'privada'
    area.mkdir()
    assert fora_git(area) == area
    if tipo == 'bare':
        (tmp_path/'objects').mkdir()
        (tmp_path/'config').write_text('', encoding='utf-8')
    else:
        (tmp_path/'.git').mkdir()
        if tipo == 'normal':
            (tmp_path/'.git/HEAD').write_text('ref: refs/heads/main\n', encoding='utf-8')
    with pytest.raises(Bloqueio, match='EVIDENCIAS_DENTRO_GIT'):
        fora_git(area)


def test_raiz_git_recusada_sem_depender_de_symlink():
    from tests.bbz.test_persistent_links import RepositorioVinculosJSON
    from conversor.readers.text_support import ErroLeitura
    with pytest.raises(ErroLeitura):
        RepositorioVinculosJSON(Path(__file__).resolve().parents[2])


def test_sanitizacao_junit_preserva_XML_e_codifica_caminhos(tmp_path):
    out = tmp_path/'evidencia & unicode ação'
    out.mkdir()
    xml = out/'nativo.xml'
    tree = ET.Element('testsuites')
    suite = ET.SubElement(tree, 'testsuite', hostname='HOST_SINTETICO')
    case = ET.SubElement(suite, 'testcase', classname='sintetico', name='test_link', file=str(out/'modulo.py'))
    skipped = ET.SubElement(case, 'skipped', message='NAO_VALIDADO '+str(out))
    skipped.text = str(out/'arquivo & nome.txt')
    ET.ElementTree(tree).write(xml, encoding='utf-8')
    sanitizar_xml(xml, out)
    result = ET.parse(xml).getroot()
    assert result.find('testsuite').get('hostname') == 'SANITIZADO'
    assert result.find('.//testcase').get('file') == str(Path('[EVIDENCIAS]')/'modulo.py')
    assert str(out) not in xml.read_text(encoding='utf-8')
    assert ler_junit(xml)[0]['estado'] == 'NÃO_VALIDADO'
