param([Parameter(Mandatory=$true)][string]$Arquivo)
$ErrorActionPreference = 'Stop'
try {
    $Item = Get-Item -LiteralPath $Arquivo -Force
    if ($Item.PSIsContainer -or (($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) {
        throw 'TIPO_NAO_SUPORTADO'
    }
    $Drive = New-Object System.IO.DriveInfo ([IO.Path]::GetPathRoot($Item.FullName))
    $Acl = Get-Acl -LiteralPath $Item.FullName
    $Pasta = Get-Acl -LiteralPath $Item.DirectoryName
    $Amplos = @('S-1-1-0', 'S-1-5-11', 'S-1-5-32-545', 'S-1-5-32-546', 'S-1-5-7')
    $LeituraAmpla = 0
    $NaoResolvidas = 0
    foreach ($Regra in $Acl.Access) {
        try {
            $Sid = $Regra.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value
        } catch {
            $NaoResolvidas++
            continue
        }
        if (($Amplos -contains $Sid) -and
            ($Regra.AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow) -and
            (([int]$Regra.FileSystemRights -band [int][Security.AccessControl.FileSystemRights]::ReadData) -ne 0)) {
            $LeituraAmpla++
        }
    }
    # Inventario somente: ACE Allow isolada nao calcula acesso efetivo.
    # Nao imprimir identidade, SID, SDDL, caminho ou mensagem de excecao.
    $Resumo = [ordered]@{
        schema = 'EXP04_WIN_NTFS@1'
        sistema_arquivos = $Drive.DriveFormat
        arquivo_herda_dacl = -not $Acl.AreAccessRulesProtected
        pasta_herda_dacl = -not $Pasta.AreAccessRulesProtected
        quantidade_regras = @($Acl.Access).Count
        regras_amplas_permitindo_leitura = $LeituraAmpla
        regras_nao_resolvidas = $NaoResolvidas
        acesso_outro_usuario_testado = $false
        dacl_efetiva_homologada = $false
        politica_integrada_ao_escritor = $false
        codigo = 'DACL_WINDOWS_NAO_VALIDADA'
    }
    [Console]::WriteLine(($Resumo | ConvertTo-Json -Compress))
    exit 0
} catch {
    [Console]::WriteLine('{"codigo":"SONDA_NTFS_INDISPONIVEL"}')
    exit 2
}
