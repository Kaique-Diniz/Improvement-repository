"""Testes com UTF-8, integridade e bloqueio separado da homologação de segurança."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).absolute().parents[2]
sys.path.insert(0, str(ROOT))
from tools.exp04.reconstruir import caminho, verificar

BASE = '770d062d29c4361d6932592883df9339bb4089bc'
SCOPES = {
    'focados': (['tests/exp04'], 188),
    'seis': (['tests/passaredo', 'tests/oma', 'tests/vero', 'tests/itajuba',
              'tests/beach_parque', 'tests/int02'], 649),
    'completa': (['tests'], 2842),
    'complementares': (['tools/exp04_win/test_ordinal.py', 'tools/exp04_win/test_compatibilidade.py'], None),
    'nativos': (['tools/exp04_win/test_nativo.py'], 7),
}


class Bloqueio(Exception):
    pass


class Argumentos(argparse.ArgumentParser):
    def error(self, _):
        raise Bloqueio('ARGUMENTOS_INVALIDOS')


def fora_git(path):
    p = caminho(path, diretorio=True)
    for node in (p, *p.parents):
        if os.path.lexists(node/'.git'):
            raise Bloqueio('EVIDENCIAS_DENTRO_GIT')
        if sum(os.path.lexists(node/n) for n in ('HEAD', 'objects', 'refs', 'config')) >= 2:
            raise Bloqueio('EVIDENCIAS_DENTRO_GIT')
    return p


def sanitizar(texto, out):
    for value, label in ((str(ROOT), '[CANDIDATA]'), (str(out), '[EVIDENCIAS]'),
                         (os.environ.get('USERPROFILE'), '[PERFIL]'),
                         (os.environ.get('HOME'), '[HOME]')):
        if value:
            texto = texto.replace(value, label)
    return re.sub(r'hostname="[^"]*"', 'hostname="SANITIZADO"', texto)


def sanitizar_xml(path, out):
    # Operar nos valores decodificados: caminhos com &/Unicode não podem
    # escapar da sanitização nem marcadores podem virar tags inválidas.
    tree = ET.parse(path)
    for node in tree.iter():
        for key, value in list(node.attrib.items()):
            node.set(key, 'SANITIZADO' if key == 'hostname' else sanitizar(value, out))
        if node.text:
            node.text = sanitizar(node.text, out)
        if node.tail:
            node.tail = sanitizar(node.tail, out)
    tree.write(path, encoding='utf-8', xml_declaration=True)


def ler_junit(path):
    root = ET.parse(path).getroot()
    cases = []
    for c in root.iter('testcase'):
        failure = c.find('failure')
        error = c.find('error')
        skipped = c.find('skipped')
        state = 'FALHOU' if failure is not None or error is not None else 'NÃO_VALIDADO' if skipped is not None else 'APROVADO'
        cases.append({'nodeid': c.get('classname', '').replace('.', '/')+'.py::'+c.get('name', ''),
                      'estado': state, 'skip': skipped.get('message', '') if skipped is not None else None,
                      'pendencias': [p.get('value') for p in c.findall('./properties/property')
                                    if p.get('name') == 'seguranca_ntfs']})
    return cases


def resumo(cases, exitcode, expected):
    failed = sum(c['estado'] == 'FALHOU' for c in cases)
    skipped = sum(c['estado'] == 'NÃO_VALIDADO' for c in cases)
    count_ok = expected is None or len(cases) == expected
    ok = exitcode == 0 and not failed and count_ok
    return {'estado_testes': ('NÃO_VALIDADO' if skipped else 'APROVADO') if ok else 'FALHOU',
            'execucao_sem_falhas': ok,
            'coletados': len(cases), 'aprovados': len(cases)-failed-skipped,
            'falhas_ou_erros': failed, 'ignorados': skipped, 'coleta_esperada_confere': count_ok,
            'exitcode_pytest': exitcode, 'casos': cases}


def main(argv=None):
    out = None
    version = data = vf = None
    try:
        p = Argumentos(description=__doc__)
        p.add_argument('--versao', required=True, type=Path)
        p.add_argument('--evidencias', required=True, type=Path)
        p.add_argument('--escopo', choices=(*SCOPES, 'todos'), default='todos')
        args = p.parse_args(argv)
        if sys.version_info[:2] != (3, 12):
            raise Bloqueio('PYTHON_312_OBRIGATORIO')
        vf = caminho(args.versao)
        data = vf.read_bytes()
        version = json.loads(data)
        if version['baseline'] != BASE:
            raise Bloqueio('BASELINE_DIVERGENTE')
        git = subprocess.run(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], capture_output=True,
                             timeout=20, check=False)
        if git.returncode or git.stdout.decode('ascii').strip() != BASE:
            raise Bloqueio('GIT_CANDIDATA_INVALIDO')
        n = verificar(ROOT, version['arquivos'])
        parent = fora_git(args.evidencias)
        out = parent/('execucao-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex)
        out.mkdir(mode=0o700)
        env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
                   PYTHONPATH=os.pathsep.join((str(ROOT), str(ROOT/'src'))))
        results = {}
        selected = list(SCOPES) if args.escopo == 'todos' else [args.escopo]
        for name in selected:
            paths, expected = SCOPES[name]
            xml = out/(name+'.xml')
            cmd = [sys.executable, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                   '--tb=short', '--junitxml='+str(xml), '--basetemp='+str(out/('temp-'+name)), *paths]
            run = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True,
                                 encoding='utf-8', errors='replace', check=False)
            (out/(name+'.log')).write_text(sanitizar(run.stdout+'\n'+run.stderr, out), encoding='utf-8')
            if not xml.is_file():
                raise Bloqueio('JUNIT_NAO_GERADO')
            sanitizar_xml(xml, out)
            results[name] = resumo(ler_junit(xml), run.returncode, expected)
        if vf.read_bytes() != data:
            raise Bloqueio('MANIFESTO_SUBSTITUIDO')
        verificar(ROOT, version['arquivos'])
        all_pass = all(r['execucao_sem_falhas'] for r in results.values())
        any_skipped = any(r['ignorados'] for r in results.values())
        individual = {}
        for result in results.values():
            individual.update({c['nodeid']: c for c in result['casos']})
        history = json.loads((ROOT/'tools/exp04_win/casos_historicos.json').read_text(encoding='utf-8'))
        matrix = []
        for row in history['casos']:
            observed = individual.get(row['nodeid_correspondente_D2'])
            control = ('NÃO_VALIDADO' if row['grupo'] in ('MODO', 'CHMOD') else observed['estado']) if observed and os.name == 'nt' else 'NÃO_VALIDADO'
            matrix.append({'id': row['id'], 'nodeid': row['nodeid_correspondente_D2'],
                           'vinculo_historico': row['vinculo_com_execucao_EXP04'],
                           'sistema_observado': sys.platform,
                           'estado_teste_observado': observed['estado'] if observed else 'NÃO_VALIDADO',
                           'estado_controle_windows': control,
                           'motivo_skip': observed['skip'] if observed else None,
                           'pendencias': observed['pendencias'] if observed else []})
        # Ler DACL ou aprovar pytest não comprova isolamento entre contas.
        report = {'schema': 'EXP04_WIN_EXECUCAO@1', 'sistema': sys.platform,
                  'python': sys.version.split()[0], 'pythonutf8_filhos': '1',
                  'manifesto_sha256': sha256(data).hexdigest(), 'hashes': n,
                  'integridade_antes_depois': True, 'resultados': results,
                  'matriz_correspondencias_19': matrix,
                  'estado_testes': ('NÃO_VALIDADO' if any_skipped else 'APROVADO') if all_pass else 'FALHOU',
                  'estado_seguranca_windows': 'NÃO_VALIDADO',
                  'codigo_seguranca': 'EVIDENCIA_INSUFICIENTE; DACL_WINDOWS_NAO_VALIDADA',
                  'homologacao_windows_integral': False, 'conversao_real_novos_perfis': 'BLOQUEADA'}
        (out/'relatorio.json').write_text(json.dumps(report, ensure_ascii=True, indent=2)+'\n', encoding='utf-8')
        print(json.dumps({'estado_testes': report['estado_testes'], 'estado_seguranca_windows': 'NÃO_VALIDADO',
                          'hashes': n, 'relatorio': out.name+'/relatorio.json'}, ensure_ascii=True))
        return 2 if not all_pass else 3 if os.name == 'nt' else 0
    except KeyboardInterrupt:
        code = 'EXECUCAO_INTERROMPIDA'
    except Bloqueio as exc:
        code = str(exc)
    except Exception:
        code = 'EXECUCAO_BLOQUEADA_POR_ERRO_OPERACIONAL'
    integrity = False
    try:
        if version is not None and vf.read_bytes() == data:
            verificar(ROOT, version['arquivos'])
            integrity = True
    except Exception:
        pass
    failure = {'estado': 'FALHOU', 'codigo': code, 'homologacao_windows_integral': False,
               'integridade_final': integrity}
    if out is not None:
        try:
            (out/'erro.json').write_text(json.dumps(failure, indent=2)+'\n', encoding='utf-8')
        except Exception:
            pass
    print(json.dumps(failure))
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
