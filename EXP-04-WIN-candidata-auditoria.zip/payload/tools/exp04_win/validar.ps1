param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Versao,
    [Parameter(Mandatory=$true)][string]$Evidencias,
    [ValidateSet('focados','seis','completa','complementares','nativos','todos')][string]$Escopo = 'todos'
)
$ErrorActionPreference = 'Stop'
try {
    & $Python -B (Join-Path $PSScriptRoot 'executar.py') `
        --versao $Versao --evidencias $Evidencias --escopo $Escopo
    $Resultado = $LASTEXITCODE
} catch {
    Write-Output 'EXECUCAO_POWERSHELL_BLOQUEADA'
    exit 2
}
# 0: Linux/testes; 2: falha/bloqueio; 3: testes Windows passaram, seguranca pendente.
if ($Resultado -eq 3) {
    Write-Output 'EVIDENCIA_INSUFICIENTE; DACL_WINDOWS_NAO_VALIDADA; SEM_HOMOLOGACAO'
}
exit $Resultado
