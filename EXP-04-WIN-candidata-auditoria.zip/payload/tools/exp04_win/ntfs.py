"""Inventário nativo separado de autorização; não altera ACLs nem políticas."""
import json
import os
from pathlib import Path
import subprocess


class EvidenciaInsuficiente(Exception):
    pass


def inventariar(arquivo):
    if os.name != 'nt':
        raise EvidenciaInsuficiente('WINDOWS_REAL_NAO_DISPONIVEL')
    try:
        p = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-File',
                            str(Path(__file__).with_name('inventario_ntfs.ps1')),
                            '-Arquivo', str(arquivo)], capture_output=True, text=True,
                           encoding='utf-8', errors='strict', timeout=30, check=False)
        if p.returncode:
            raise EvidenciaInsuficiente('SONDA_NTFS_INDISPONIVEL')
        obj = json.loads(p.stdout)
    except EvidenciaInsuficiente:
        raise
    except Exception:
        raise EvidenciaInsuficiente('SONDA_NTFS_INDISPONIVEL') from None
    keys = {'schema', 'sistema_arquivos', 'arquivo_herda_dacl', 'pasta_herda_dacl',
            'quantidade_regras', 'regras_amplas_permitindo_leitura', 'regras_nao_resolvidas',
            'acesso_outro_usuario_testado', 'dacl_efetiva_homologada',
            'politica_integrada_ao_escritor', 'codigo'}
    bools = ('arquivo_herda_dacl', 'pasta_herda_dacl', 'acesso_outro_usuario_testado',
             'dacl_efetiva_homologada', 'politica_integrada_ao_escritor')
    nums = ('quantidade_regras', 'regras_amplas_permitindo_leitura', 'regras_nao_resolvidas')
    if (not isinstance(obj, dict) or set(obj) != keys or obj['schema'] != 'EXP04_WIN_NTFS@1'
            or obj['codigo'] != 'DACL_WINDOWS_NAO_VALIDADA'
            or obj['sistema_arquivos'] not in ('NTFS', 'ReFS', 'FAT', 'FAT32', 'exFAT')
            or any(type(obj[k]) is not bool for k in bools)
            or any(type(obj[k]) is not int or obj[k] < 0 for k in nums)
            or any(obj[k] for k in ('acesso_outro_usuario_testado', 'dacl_efetiva_homologada',
                                    'politica_integrada_ao_escritor'))):
        raise EvidenciaInsuficiente('SONDA_RESULTADO_INVALIDO')
    return obj
