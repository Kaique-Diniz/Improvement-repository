"""Aplicar diff auditado somente em worktree limpa do baseline EXP-04.

Não cria worktree, não instala, não usa rede e não faz commit. Todos os erros
expostos são códigos constantes. Falha de escrita exige descartar a tentativa
manualmente e criar outra worktree; nenhuma remoção automática é realizada.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess

BASE = '770d062d29c4361d6932592883df9339bb4089bc'


class Bloqueio(Exception):
    pass


def caminho(path, *, diretorio=False):
    p = Path(os.path.abspath(path))
    for node in (*reversed(p.parents), p):
        st = node.lstat()
        if (stat.S_ISLNK(st.st_mode) or getattr(st, 'st_file_attributes', 0) & 0x400
                or (hasattr(node, 'is_junction') and node.is_junction())):
            raise Bloqueio('LINK_OU_REPARSE_RECUSADO')
        if node != p and not stat.S_ISDIR(st.st_mode):
            raise Bloqueio('PAI_NAO_DIRETORIO')
    if not (stat.S_ISDIR(st.st_mode) if diretorio else stat.S_ISREG(st.st_mode)):
        raise Bloqueio('TIPO_DE_CAMINHO_INVALIDO')
    return p


def arquivos(root):
    root = caminho(root, diretorio=True)
    mapa = {}
    stack = [root]
    while stack:
        folder = stack.pop()
        for p in folder.iterdir():
            if p.parent == root and p.name == '.git':
                if p.is_symlink() or getattr(p.lstat(), 'st_file_attributes', 0) & 0x400:
                    raise Bloqueio('GIT_METADADO_INVALIDO')
                continue
            st = p.lstat()
            if stat.S_ISDIR(st.st_mode) and not getattr(st, 'st_file_attributes', 0) & 0x400:
                caminho(p, diretorio=True)
                stack.append(p)
            else:
                caminho(p)
                mapa[p.relative_to(root).as_posix()] = sha256(p.read_bytes()).hexdigest()
    return mapa


def verificar(root, esperado):
    if not esperado or arquivos(root) != esperado:
        raise Bloqueio('CONTEUDO_CANDIDATA_DIVERGENTE')
    return len(esperado)


def git(root, *args):
    p = subprocess.run(['git', '-C', str(root), *args], capture_output=True,
                       timeout=60, check=False)
    if p.returncode:
        raise Bloqueio('GIT_OPERACAO_RECUSADA')
    return p.stdout


def executar(pacote, candidata, somente_verificar=False):
    pacote = caminho(pacote, diretorio=True)
    candidata = caminho(candidata, diretorio=True)
    manifest = json.loads(caminho(pacote / 'MANIFESTO_SHA256.json').read_text(encoding='utf-8'))
    # Conferir TODOS os membros do pacote, inclusive patch e versões; sem extras.
    conteudo = arquivos(pacote)
    conteudo.pop('MANIFESTO_SHA256.json', None)
    if conteudo != manifest['arquivos']:
        raise Bloqueio('PACOTE_DIVERGENTE')
    versao = json.loads((pacote / 'VERSAO_EXP04_SHA256.json').read_text(encoding='utf-8'))
    if versao['baseline'] != BASE:
        raise Bloqueio('BASELINE_MANIFESTO_DIVERGENTE')
    if git(candidata, 'rev-parse', 'HEAD').decode().strip() != BASE:
        raise Bloqueio('HEAD_DIVERGENTE')
    if somente_verificar:
        return verificar(candidata, versao['arquivos'])
    base = json.loads((pacote / 'BASELINE_SHA256.json').read_text(encoding='utf-8'))
    verificar(candidata, base['arquivos'])
    if git(candidata, 'status', '--porcelain', '--untracked-files=all'):
        raise Bloqueio('WORKTREE_NAO_LIMPA')
    patch = pacote / 'EXP04.patch'
    git(candidata, 'apply', '--check', str(patch))
    git(candidata, 'apply', str(patch))
    return verificar(candidata, versao['arquivos'])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--pacote', required=True, type=Path)
    p.add_argument('--candidata', required=True, type=Path)
    p.add_argument('--verificar', action='store_true')
    a = p.parse_args()
    try:
        n = executar(a.pacote, a.candidata, a.verificar)
    except Bloqueio as e:
        print(json.dumps({'estado': 'BLOQUEADO', 'codigo': str(e)}))
        return 2
    except Exception:
        print('{"estado":"BLOQUEADO","codigo":"FALHA_OPERACIONAL_RECONSTRUCAO"}')
        return 2
    print(json.dumps({'estado': 'INTEGRIDADE_CONFERIDA', 'hashes': n}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
