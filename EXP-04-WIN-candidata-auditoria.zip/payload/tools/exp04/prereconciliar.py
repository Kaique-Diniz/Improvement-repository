"""Pré-reconciliação privada EXP-04: hipóteses explícitas, só agregados na saída.

Reusa a leitura/integridade REC-01-R1 auditada sem copiá-la ou modificá-la.
Não chama analisar(), não ativa política e não gera XLSX real.
"""
import argparse
from collections import Counter
from contextlib import redirect_stdout,redirect_stderr
from datetime import date,datetime
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import importlib.util
from importlib.resources import files
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode=True
HASH_GUARD_R1='2d30d5544db79a08f4829047d819fcc9074a2c32c439b1f3373e5b482acfc42c'


class ErroSeguro(Exception):pass
class Argumentos(argparse.ArgumentParser):
    def error(self,_):raise ErroSeguro('ARGUMENTOS_EXP04_INVALIDOS')
class Descartar:
    def write(self,_):return 0
    def flush(self):pass


def carregar_guard(raiz):
    path=raiz/'tools/reconciliacao_privada/seguranca.py'
    for node in (path,*path.parents):
        st=node.lstat()
        if node.is_symlink()or getattr(st,'st_file_attributes',0)&0x400:raise ErroSeguro('VERIFICADOR_R1_CAMINHO_INVALIDO')
    if sha256(path.read_bytes()).hexdigest()!=HASH_GUARD_R1:raise ErroSeguro('VERIFICADOR_R1_DIVERGENTE')
    nome='exp04_guard_r1_auditado';spec=importlib.util.spec_from_file_location(nome,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[nome]=mod;spec.loader.exec_module(mod)
    return mod


def historico(data):
    from openpyxl import load_workbook
    from openpyxl.utils.datetime import from_excel
    from conversor.domain.template import COLUNAS
    from conversor.domain.identity import chave_unidade
    w=load_workbook(BytesIO(data),read_only=True,data_only=False,keep_links=False)
    try:
        candidatos=[]
        for sh in w:
            header=next(sh.iter_rows(values_only=True))
            if tuple(str(v).rstrip()for v in header[:30])==COLUNAS:candidatos.append(sh)
        if len(candidatos)!=1:raise ErroSeguro('TEMPLATE_ESTRUTURA_AMBIGUA')
        sh=candidatos[0];financeiros=Counter();valor=Decimal(0);cad=0;datas=Counter();sem_pareamento=0;total=0
        for cells in sh.iter_rows(min_row=2):
            vals=[c.value for c in cells]
            if not any(v is not None for v in vals):continue
            if any(c.data_type=='f'for c in cells)or any(v is not None for v in vals[30:]):raise ErroSeguro('TEMPLATE_FORMULA_OU_COLUNA_EXTRA')
            total+=1
            if vals[29]is None:cad+=1;continue
            money=Decimal(str(vals[29]).replace('.','').replace(',','.'))if isinstance(vals[29],str)and','in vals[29]else Decimal(str(vals[29]))
            if not money.is_finite()or money!=money.quantize(Decimal('.01')):raise ErroSeguro('TEMPLATE_VALOR_INVALIDO')
            due=vals[28];datas[type(due).__name__]+=1
            if isinstance(due,datetime):due=due.date()
            elif isinstance(due,date):pass
            elif type(due)in(int,float):due=from_excel(due,w.epoch).date()
            elif isinstance(due,str):
                try:due=datetime.strptime(due.strip(),'%d/%m/%Y').date()
                except ValueError:due=date.fromisoformat(due.strip())
            else:raise ErroSeguro('TEMPLATE_DATA_INVALIDA')
            valor+=money
            m=re.fullmatch(r'BL([A-Za-z0-9]+)-UNI([A-Za-z0-9]+)',str(vals[6]))
            if not m:sem_pareamento+=1;continue
            financeiros[(chave_unidade(m[1],m[2]),due.isoformat(),format(money,'.2f'))]+=1
        return {'linhas':total,'financeiras':total-cad,'cadastrais':cad,'valor_original':format(valor,'.2f'),
                'tipos_datas':dict(datas),'sem_pareamento_documental':sem_pareamento},financeiros
    finally:w.close()


def main(argv=None):
    guard=None;lidos=[];resumos=[];erro=None;saida=None;versao=None;raiz=None;integ=False
    try:
        p=Argumentos(description=__doc__)
        p.add_argument('--rec01-r1',required=True,type=Path)
        p.add_argument('--candidata',required=True,type=Path)
        p.add_argument('--versao',required=True,type=Path)
        p.add_argument('--manifesto',required=True,type=Path)
        p.add_argument('--saida-pai',required=True,type=Path)
        p.add_argument('--execucao',required=True)
        p.add_argument('--referencia',required=True,type=date.fromisoformat)
        p.add_argument('--prazos',required=True,nargs='+',type=int)
        args=p.parse_args(argv)
        if sys.version_info[:2]!=(3,12):raise ErroSeguro('PYTHON_312_OBRIGATORIO')
        guard=carregar_guard(args.rec01_r1)
        raiz=guard.caminho_estatico(args.candidata)
        vf=guard.Arquivo.ler(args.versao.parent,args.versao.name);lidos.append(vf);versao=json.loads(vf.conteudo)
        guard.verificar_candidata(raiz,versao)
        guard.fora_git(args.manifesto.parent);mf=guard.Arquivo.ler(args.manifesto.parent,args.manifesto.name);lidos.append(mf)
        m=json.loads(mf.conteudo)
        if m.get('schema')!='EXP04_PRIVADO@1'or m.get('exemplo')is not False:raise ErroSeguro('MANIFESTO_PRIVADO_INVALIDO')
        if sorted(x['perfil']for x in m['perfis'])!=sorted(('on_brooklin','citzy_paulista','panorama_diadema_club','do_it_pinheiros')):
            raise ErroSeguro('MANIFESTO_PERFIS_INCOMPLETOS')
        for r in m['raizes'].values():
            guard.fora_git(r)
            if Path(r).absolute().is_relative_to(raiz):raise ErroSeguro('FONTE_DENTRO_CANDIDATA')
        parent=guard.fora_git(args.saida_pai)
        if parent.is_relative_to(raiz):raise ErroSeguro('SAIDA_DENTRO_CANDIDATA')
        saida=guard.pasta_saida(parent,args.execucao)
        sys.path.insert(0,str(raiz/'src'))
        from conversor.application.exp04_preparation import preparar,resumo_hipotese
        from conversor.domain.identity import chave_unidade
        referencias=json.loads(files('conversor.web').joinpath('exp04_historicos.json').read_text(encoding='utf-8'))
        for item in m['perfis']:
            fontes={}
            for role in ('financeiro','cadastro','template'):
                spec=item.get(role)
                if spec is None and role=='cadastro':fontes[role]=None;continue
                f=guard.Arquivo.ler(m['raizes'][spec['raiz']],spec['arquivo'],spec['sha256']);lidos.append(f);fontes[role]=f.conteudo
            if sha256(fontes['template']).hexdigest()!=referencias[item['perfil']]['sha256_template']:
                raise ErroSeguro('TEMPLATE_HISTORICO_DE_OUTRO_CONTEXTO')
            with redirect_stdout(Descartar()),redirect_stderr(Descartar()):
                perfil,lote,cad,desc,ret=preparar(fontes['financeiro'],item['perfil'],cadastro=fontes['cadastro'],data_ref=args.referencia)
                template,counter=historico(fontes['template'])
            units={u.id:u for u in lote.unidades};hipoteses=[]
            refs=[(args.referencia,n)for n in args.prazos]+[(date.fromisoformat(r['referencia']),int(r['prazo']))for r in item.get('comparacoes_historicas',[])]
            for ref,n in refs:
                r=resumo_hipotese(perfil,lote,data_ref=ref,prazo_hipotetico=n,descricoes=desc)
                esperado=Counter((units[b.unidade_id].chave_normalizada,b.vencimento.isoformat(),format(b.composicao.total_original,'.2f'))
                    for b in lote.boletos if b.composicao.total_original>0 and(ref-b.vencimento).days>n)
                unidades_hipotese={k[0]for k in esperado};unidades_template={k[0]for k in counter}
                sem_equivalencia=unidades_hipotese^unidades_template
                r['comparacao_template']={'adicionais_hipotese':sum((esperado-counter).values()),'ausentes_hipotese':sum((counter-esperado).values()),
                    'pareamento_limitado':bool(template['sem_pareamento_documental']or sem_equivalencia),
                    'quantidade_chaves_unidade_nao_coincidentes':len(sem_equivalencia),
                    'diferenca_valor_original':format(Decimal(r['valor_original'])-Decimal(template['valor_original']),'.2f'),
                    'limite':'TEMPLATE_HISTORICO_NAO_COMPROVA_REGUA_OU_TITULARIDADE'}
                hipoteses.append(r)
            if any(not re.fullmatch(r'[A-Z0-9_]{1,100}',k)for k in ret):raise ErroSeguro('CODIGO_AGREGADO_INESPERADO')
            resumos.append({'perfil':item['perfil'],'recibos_origem':len(lote.boletos),'unidades_financeiras':len(lote.unidades),
                'valor_original_integral':format(sum((b.composicao.total_original for b in lote.boletos),Decimal(0)),'.2f'),
                'componentes_negativos':sum(i.valor<0 for b in lote.boletos for i in b.composicao.itens),
                'grupos_financeiros_repetidos':sum(n>1 for n in Counter((b.unidade_id,b.vencimento,b.composicao.total_original)for b in lote.boletos).values()),
                'participantes_cadastro':len(cad.pessoas)if cad else 0,'unidades_cadastro':len(cad.unidades)if cad else 0,
                'unidades_com_multiplos_participantes':sum(n>1 for n in Counter(p.unidade_id for p in cad.pessoas).values())if cad else 0,
                'ocorrencias_leitura':dict(Counter(r.codigo for r in (*lote.ressalvas,*(cad.ressalvas if cad else ())))),
                'retencoes':ret,'template':template,'hipoteses':hipoteses,
                'pendencias':['POLITICA_COBRANCA_NAO_APROVADA','VINCULO_INTEGRACAO_NAO_APROVADO']})
    except KeyboardInterrupt:erro='EXECUCAO_INTERROMPIDA'
    except ErroSeguro as e:erro=str(e)
    except Exception:erro='PRE_RECONCILIACAO_NAO_CONCLUIDA'
    finally:
        try:
            if guard and versao:
                for f in lidos:f.conferir()
                guard.verificar_candidata(raiz,versao);integ=erro is None
        except Exception:erro='INTEGRIDADE_FINAL_FALHOU'
    report={'schema':'EXP04_AGREGADO@1','estado':'ERRO_OPERACIONAL'if erro else'PRE_ANALISE_NAO_HOMOLOGADA',
            'codigo':erro or'EXECUCAO_COMPARATIVA_CONCLUIDA','integridade_final':integ,'perfis':resumos,
            'candidata_manifesto_sha256':sha256(vf.conteudo).hexdigest()if versao else None,
            'arquivos_candidata':len(versao['arquivos'])if versao else 0,
            'exportacao_operacional':False,'politica_aprovada':False,'dados_individuais_incluidos':False}
    if saida:
        guard.gravar_novo(saida/'EXP04_agregado.json',guard.json_bytes(report))
    print(json.dumps({'estado':report['estado'],'codigo':report['codigo'],'perfis':len(resumos),'integridade_final':integ}))
    return 2 if erro else 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except KeyboardInterrupt:
        print('{"estado":"ERRO_OPERACIONAL","codigo":"EXECUCAO_INTERROMPIDA"}');raise SystemExit(2)
    except Exception:
        print('{"estado":"ERRO_OPERACIONAL","codigo":"FALHA_OPERACIONAL_EXP04"}');raise SystemExit(2)
