# EXP-04 — pré-reconciliação documental

Os 12 anexos foram disponibilizados nesta tarefa e lidos privadamente fora do
Git em Linux/Python 3.12.14. Nenhum documento nem dado individual integra esta
entrega. As contagens seguintes são de leitura efetiva desta tarefa, não resultados
Windows. A execução agregada final e seu manifesto de versão acompanham o pacote
em `evidencias/`; consulte esse JSON para hipóteses, diferenças e retenções.

| Perfil | Recibos de origem | Unidades financeiras | Valor original integral | Componentes negativos | Participantes/unidades cadastrais |
|---|---:|---:|---:|---:|---:|
| On Brooklin | 576 | 310 | 418.578,80 | 2 | 434 / 434 |
| Citzy Paulista | 502 | 130 | 311.191,35 | 68 | 298 / 298 |
| Panorama Diadema Club | 792 | 177 | 624.597,29 | 775 | 658 / 658 |
| Do It Pinheiros | 808 | 134 | 342.657,55 | 0 | 596 / 345 |

Os totais integrais incluem todos os recibos lidos, antes de hipótese de prazo.
Não usar quantidade de participantes como quantidade de dívidas. O cadastro
Do It contém múltiplos participantes por unidade e uma linha órfã separada, não
contada como pessoa; a associação divisão/bloco ainda não está autorizada.

## Checkpoints históricos fornecidos e leituras atuais

| Perfil | Template financeiro | Valor histórico | Adicionais cadastrais históricos | Hipótese comparativa informada |
|---|---:|---:|---:|---|
| On Brooklin | 275 | 186.206,87 | 0 | >60 dias em 09/11/2026 |
| Citzy Paulista | 387 | 210.262,31 | 3 | >30 dias em 14/10/2026 |
| Panorama Diadema Club | 626 | 463.704,16 | 0 | >30 dias em 08/10/2026 ou >60 em 09/11/2026 |
| Do It Pinheiros | 730 | 306.786,94 | 78 | >30 dias em 09/11/2026 |

Esses checkpoints constam da solicitação do usuário; os templates também foram
lidos nesta tarefa, sem alterar seus bytes. A rodada agregada compara hipóteses
30/60 em 09/11 e as duas referências históricas declaradas no manifesto privado.
Coincidência financeira com qualquer coluna não autoriza escolher uma régua.

A inspeção inicial de Citzy reproduziu 388 dívidas / 234.836,67 na hipótese >30
em 09/11, isto é, uma dívida / 24.574,36 a mais que o checkpoint de 14/10. Não há
filtro para forçar o total antigo; a comparação por multiconjunto deve preservar
lançamentos históricos e explicitar acréscimos. Datas datetime, texto ou seriais
Excel são tratadas usando o calendário do workbook, nunca como texto monetário.

O template Citzy usa aba de nome diferente de `Dados` e uma 31ª coluna somente
estilizada e vazia: isso é aceito apenas na leitura histórica. Coluna extra com
dado ou fórmula é recusada. O contrato de saída atual permanece com 30 colunas
e `NM_DIVIDA_CEDENTE` sem espaço final; não foi alterado para copiar o histórico.

## Limites das evidências

- Sem aprovação das políticas e vínculos não existem dívidas operacionalmente
  autorizadas dos quatro; os números são seleções explicitamente hipotéticas.
- Pareamento histórico usa unidade/data/valor e multiplicidade. Códigos históricos
  sem mapeamento compreendido são explicitados como `pareamento_limitado`; não
  constituem divergência financeira comprovada nem aprovação completa.
- A/B da prévia preserva as dívidas; adicionais B são calculados e não forçados a
  0/3/0/78. Diferenças cadastrais exigem revisão documental, papel e atualidade.
- Origem dos anexos é o envio do usuário. SHA-256 comprova integridade de bytes,
  não uma atestação independente da procedência ou autorização de uso operacional.
- Endereços reais e titularidade não foram homologados; mapeamentos Do It e
  cadastros antigos/ambíguos continuam retidos. Logs públicos não contêm nomes,
  documentos, contatos, unidades privadas ou caminhos das fontes.
- Segurança Windows/NTFS, concorrência e integração real de destino não são
  comprovadas por esta pré-análise Linux nem pelo êxito de testes sintéticos.
