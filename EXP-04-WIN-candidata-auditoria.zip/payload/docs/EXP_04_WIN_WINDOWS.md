# EXP-04-WIN — revalidação nativa privada

Usar uma pasta nova em `%LOCALAPPDATA%`, sem administrador. Não executar sobre a
EXP-04 de 448 hashes nem sobre D2/R1. Conferir o SHA-256 do ZIP local auditado
antes de extrair. Nenhum comando instala dependências, muda políticas do Windows,
altera DACL ou dá privilégios de symlink.

## Reconstrução

O pacote inclui um reconstrutor autônomo derivado do EXP-04 (mesmas validações,
nomes de patch/manifesto ajustados), manifesto do baseline e de toda a candidata,
diff completo e diff incremental contra EXP-04. Ele recusa worktree não limpa,
extras, links/reparse, divergência de hashes/HEAD e arquivos preexistentes
modificados. Usa `git apply --check` antes da aplicação e confere todos os hashes
depois. Interrupção de escrita não remove a tentativa: preserve-a e use outra
worktree nova, sem sobrescrever a árvore anterior.

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'EXP04-WIN'
$Pacote = Join-Path $Root 'pacote'
$C = Join-Path $Root 'candidata'
$Repo = Join-Path $HOME 'Improvement-repository' # ajustar
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe' # ajustar
$Evidencias = Join-Path $Root 'Evidencias'
if (Test-Path -LiteralPath $C) { throw 'DESTINO_JA_EXISTE' }
New-Item -ItemType Directory -Path $Evidencias -Force | Out-Null
& git -C $Repo worktree add --detach $C 770d062d29c4361d6932592883df9339bb4089bc
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_NAO_CRIADA' }
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_RECUSADA' }
```

`MANIFESTO_SHA256.json` cobre o pacote exceto ele próprio;
`VERSAO_EXP04_WIN_SHA256.json` cobre todo o código/documentação da candidata.
O manifesto da EXP-04 original também acompanha o pacote para a comparação de
herança/preservação, sem misturar as duas versões. HEAD é necessário, insuficiente
para comprovar correspondência com a candidata auditada.

## Execução das cinco seleções

O Python precisa ser 3.12 e usar as dependências existentes. O executor força
`PYTHONUTF8=1`, `PYTHONIOENCODING=utf-8`, `PYTHONDONTWRITEBYTECODE=1` somente nos
filhos de teste. Não altera o código de produção para contornar CP1252. Os
resultados, temporários e JUnit ficam fora do Git em pasta única, sem sobrescrita.

```powershell
& $Python -B (Join-Path $C 'tools\exp04_win\executar.py') `
    --versao (Join-Path $Pacote 'VERSAO_EXP04_WIN_SHA256.json') `
    --evidencias $Evidencias --escopo todos
$Codigo = $LASTEXITCODE
if ($Codigo -eq 2) { throw 'FALHA_OU_BLOQUEIO_DE_EXECUCAO' }
if ($Codigo -eq 3) {
    Write-Host 'Testes sem falha; DACL_WINDOWS_NAO_VALIDADA; SEM_HOMOLOGACAO'
}
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'INTEGRIDADE_FINAL_DIVERGENTE' }
```

Alternativa equivalente PowerShell 5.1, se a política vigente permite scripts:

```powershell
& (Join-Path $C 'tools\exp04_win\validar.ps1') `
    -Python $Python -Versao (Join-Path $Pacote 'VERSAO_EXP04_WIN_SHA256.json') `
    -Evidencias $Evidencias -Escopo todos
```

Não usar `-ExecutionPolicy Bypass` nem alterar a política para este teste. Se ela
bloquear a sonda `.ps1`, registrar falha operacional / evidência insuficiente.
Os escopos individuais são `focados` (188), `seis` (649), `completa` (2.842),
`complementares` e `nativos` (sete). Não somar contagens sobrepostas.

O retorno 0 em Linux significa execuções sem falhas, não homologação Windows;
2 indica falha/bloqueio; 3 em Windows preserva o bloqueio de segurança mesmo se
todos os testes executados passaram. O relatório distingue APROVADO, FALHOU e
NÃO_VALIDADO por caso/escopo. As expressões condicionais 0600 produzem properties
de pendência, enquanto continuam as verificações documentais no Windows.

## Escopo dos controles nativos

- Comparação ordinal real com case-insensitive e diferença de sufixo não BMP.
- Alias 8.3 obtido por `GetShortPathNameW`, sem nome curto inventado. Ausência de
  alias gera skip explícito e controle NÃO_VALIDADO, não aprovação da expansão.
- Caminhos distintos com conteúdo igual permanecem distintos.
- Hardlink recusado pelo comparador diagnóstico; isso não altera o contrato de
  autorização por ID/hash do leitor de produção ou sua política de origem física.
- Junction externa criada em diretório sintético sem elevar privilégios e
  recusada pelo leitor de produção. Seu êxito é evidência separada, não substitui
  os nove cenários específicos de symlink que não puderem ser executados.
- Escrita JSON sintética, integridade do conteúdo e inventário de volume/DACL
  sem nomes, SIDs ou caminhos; acesso por outra conta e DACL efetiva permanecem
  não comprovados. Nada instala ou verifica automaticamente uma política nativa
  de produção; `politica_integrada_ao_escritor=false` é explícito.

Erro inesperado na API ou na criação nativa falha o teste; só capacidade
explicitamente ausente admite skip. Não tratar indisponibilidade como prova de
rejeição, nem mudar privilégios para obter verde.

Compartilhar apenas logs/JSON/JUnit sanitizados. Não copiar documentos reais,
credenciais, ACLs com identidades ou caminhos privados para o repositório.
Fornecer os 19 nodeids e motivos dos sete skips históricos para reconciliar a
matriz provisória. Nenhuma execução habilita conversão real dos quatro perfis.
