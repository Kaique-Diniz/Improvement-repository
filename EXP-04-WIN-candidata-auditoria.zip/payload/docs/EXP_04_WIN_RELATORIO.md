# EXP-04-WIN — candidata isolada para auditoria

## Versão e preservação

Baseline BPQ-04 `770d062d29c4361d6932592883df9339bb4089bc`, acrescido da
EXP-04 íntegra de 448 arquivos e apenas das alterações Windows desta revisão.
A worktree EXP-04 original, sua reconstrução, D2, R1 e pacotes anteriores não
são modificados. Não há commit, push, PR, merge ou publicação autorizados.

O ZIP EXP-04 publicado continua com SHA-256
`0d9eb11f040c1e8c0548a2227107076a33275f6e4771d344fc26f945f9297e14`.
HEAD não representa as mudanças não commitadas: usar o manifesto completo da
nova candidata, o diff incremental EXP-04→WIN e o diff completo BPQ-04→WIN.

## Evidência Windows recebida

O usuário relatou 2.842 coletados, 2.816 aprovados, 19 falhas, sete ignorados,
zero erros de coleta, com Python 3.12 e UTF-8; 448 hashes da EXP-04 conferidos.
Informou cinco falhas da API, nove de criação de symlink/erro 1314 e cinco de
proteção POSIX/Windows. Os 19 casos que antes dependiam de CP1252 passaram com
`PYTHONUTF8=1`. Esses dados são **evidências fornecidas pelo usuário**, não uma
execução Windows nesta tarefa.

Os nodeids e motivos individuais dos sete skips ainda não constavam do material
quando esta matriz foi preparada. As 19 correspondências D2 ficam explicitamente
provisórias, sem apresentar uma transcrição fictícia de JUnit. Consultar
`EXP_04_WIN_MATRIZ_19.md` e `tools/exp04_win/casos_historicos.json`.

## Comparação com D2 e baseline

Os arquivos dos testes correspondentes eram idênticos em bytes na EXP-04 e no
BPQ-04. O escritor JSON, fonte protegida e armazenamento privado envolvidos também
não foram alterados pela expansão. O defeito da DLL/assinatura já estava no
baseline. A indisponibilidade de symlink é capacidade da conta Windows e não
demonstra falha de rejeição. Bits/chmod POSIX não demonstram DACL Windows.

Foi comparada a D2 existente antes de desenvolver alterações. Reaproveitados:

- **API:** arquivo `windows_acl_evidence.py` byte a byte igual à correção D2.
  `WinDLL("kernel32", use_last_error=True)`, cinco argumentos, `c_wchar_p` e
  `c_int` (BOOL Win32 de 32 bits), retorno `c_int`; comprimentos em unidades
  UTF-16; erros/indisponibilidade/NUL falham fechados, sem fallback textual em
  Windows. Sem tolerância nova de ACEs ou promoção do diagnóstico a autorização.
- **Symlink:** helper `tests/windows_support.py` igual ao D2; skip só para
  `os.name == nt` e `winerror == 1314`. Outros erros propagam. Foram trocados
  cinco pontos de criação que abrangem nove cenários parametrizados/individuais.
  A verificação Git do caso misto foi antecipada ao eventual skip; há regressão
  independente para que Git não dependa da disponibilidade de links.
- **Permissões:** mesmo princípio das três correções POSIX D2, sem copiar as
  alterações de codificação da árvore histórica. Só a expressão de modo 0600
  está condicionada a POSIX; funções documentais não recebem skip. No Windows,
  properties JUnit registram `DACL_WINDOWS_NAO_VALIDADA; EVIDENCIA_INSUFICIENTE`.
  Os dois parâmetros que simulam perda de acesso via chmod são ignorados apenas
  em Windows, com esse motivo explícito. Nenhuma exceção de produção é suprimida.
- **Não incorporado:** patch de UTF-8 em `web/app.py`, alterações de encoding de
  fixtures/testes D2 e demais ferramentas/árvore histórica. Nesta tarefa, UTF-8 é
  configuração explícita dos subprocessos de teste, conforme evidência recebida.

## Asserções e preservação funcional

Uma comparação AST confirmou que todas as expressões `assert` preexistentes dos
cinco arquivos históricos alterados permanecem exatamente iguais. Isso não
equivale a dizer que sua execução independe da plataforma: três expressões de
modo passam a executar exclusivamente em POSIX, dois parâmetros de chmod são
POSIX, e nove cenários podem ser ignorados por falta comprovada de privilégio.
Essas condições são documentadas individualmente na matriz e no JUnit.

Preservadas as verificações de contagem de canônicos, conflitos, CPF/CNPJ,
integridade de auditoria JSON, reconstrução de contratos e ausência de documentos
no stdout. Nenhuma asserção documental foi removida, reduzida ou substituída.

**Único arquivo de produção diferente da EXP-04:**
`src/conversor/adapters/windows_acl_evidence.py`, exclusivamente diagnóstico.
Todos os demais arquivos da EXP-04, incluindo reconhecimento dos quatro,
políticas bloqueadas, A1/B1, 30 colunas e seis perfis, mantêm os mesmos bytes.
Não há mudança em valores, prazos, leitores, cadastro, ACL/DACL de arquivos,
persistência ou documentos privados.

## Segurança: evidência e limites

O código confirma que `private_simulation_json.conferir_local_privado` só aplica
checagem de bits de modo em POSIX. `private_json.escrever_json` usa temporário e
replace, sem instalar ou verificar DACL. `FontesLocaisProtegidas` verifica mapa,
área, links e SHA-256, mas não chama um verificador de DACL. `mesmas_regras` é
comparador exato de listas de ACEs; sua existência e os comentários legados não
demonstram integração de leitura/política ACL nesses fluxos. Não foi modificado.

A sonda nova apenas lê ACLs/volume do arquivo JSON sintético e agrega contagens,
herança e regras amplas de Allow para leitura. Uma ACE isolada não computa acesso
efetivo; grupos não listados, deny/ordem, tokens, privilégios e outras contas
continuam fora dessa evidência. Não expõe nomes, SIDs, SDDL ou caminhos no JSON.
Não altera políticas de execução, ACLs nem eleva privilégios.

**Isolamento efetivo continua NÃO_VALIDADO / EVIDENCIA_INSUFICIENTE.** O executor
mantém `homologacao_windows_integral=false` e retorna código 3 em Windows quando
os testes não falham mas a pendência persiste. Skip nunca vira APROVADO. Uma sonda
NTFS aprovada só aprova seu escopo de inventário, não a proteção da aplicação.

## Validação

Os complementares ficam em `tools/exp04_win/`, fora do testpaths original: isso
preserva os exatos 188, 649 e 2.842 casos solicitados nas três seleções. São
executados separadamente; não se somam às aprovações da suíte original.

Seleção inicial de módulos afetados + complementares: 203 aprovados em Linux,
um aviso conhecido AnyIO/Starlette. As execuções finais de 188/649/2.842 e os
complementares/nativos são registradas no pacote, com logs, JUnit e manifestos.

Este ambiente oferece Linux/Python 3.12.14. **Windows real, PowerShell 5.1,
NTFS, API real, privilégios e isolamento entre contas não foram executados aqui.**
Mocks validam contratos e falhas, não substituem Windows. O roteiro prepara
revalidação sem modificar D2, R1 ou EXP-04 original.

## Pendências impeditivas

1. Nodeids/tracebacks individuais da rodada Windows e motivos dos sete skips.
2. Revalidação nativa da candidata, com manifesto completo conferido.
3. Capacidade de symlink/8.3 indisponível: controle permanece NÃO_VALIDADO.
4. DACL efetiva e isolamento entre contas/processos, incluindo integração da
   política aos fluxos reais; inventário não remove esse bloqueio.
5. Políticas financeiras, vínculos e demais pendências da EXP-04 original:
   **conversões reais dos quatro continuam BLOQUEADAS**.
