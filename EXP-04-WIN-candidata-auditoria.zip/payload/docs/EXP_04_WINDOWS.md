# EXP-04 — execução privada Windows

Esta candidata tem baseline BPQ-04, não substitui D2. Não executar sobre as
worktrees auditadas. Nenhum comando instala dependências, altera políticas de
segurança ou exige administrador. O Python/venv existente deve ser 3.12 e conter
as dependências versionadas no projeto. A execução nativa EXP-04 está pendente.

## 1. Reconstrução isolada

Extraia o ZIP local auditado para uma pasta nova, por exemplo
`%LOCALAPPDATA%\EXP04\pacote`. Confira seu SHA-256 contra o informado na entrega:

```powershell
$ErrorActionPreference = 'Stop'
$Root = Join-Path $env:LOCALAPPDATA 'EXP04'
$Pacote = Join-Path $Root 'pacote'
$Repo = Join-Path $HOME 'Improvement-repository' # ajustar para seu checkout
$C = Join-Path $Root 'candidata'
$Python = Join-Path $env:LOCALAPPDATA 'WIN01D-Auditoria\venv\Scripts\python.exe'
if (Test-Path -LiteralPath $C) { throw 'DESTINO_JA_EXISTE' }
New-Item -ItemType Directory -Path $Root -Force | Out-Null
& git -C $Repo worktree add --detach $C 770d062d29c4361d6932592883df9339bb4089bc
if ($LASTEXITCODE -ne 0) { throw 'WORKTREE_NAO_CRIADA' }
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C
if ($LASTEXITCODE -ne 0) { throw 'RECONSTRUCAO_RECUSADA' }
```

O reconstrutor confere manifesto de todo o pacote, baseline/hash de todos os
arquivos, HEAD, ausência de extras e estado limpo; executa `git apply --check`
antes da aplicação; confere todo o conteúdo final. Não sobrescreve arquivos
modificados ou não rastreados preexistentes. Metadados de worktree `.git` são a
única exceção de arquivo extra. Links/reparse e pais simbólicos são recusados.
Falha operacional durante escrita não é revertida por exclusão automática:
preserve a tentativa e crie outra worktree nova antes de usar a candidata.

`MANIFESTO_SHA256.json` cobre todos os membros exceto o próprio manifesto;
`VERSAO_EXP04_SHA256.json` cobre a candidata completa, não apenas seu HEAD.
Confiança inicial depende do SHA-256 do ZIP e da auditoria desses scripts.

## 2. Testes sem documentos reais

```powershell
$Resultados = Join-Path $Root ('Resultados-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $Resultados | Out-Null
$env:PYTHONDONTWRITEBYTECODE = '1'
Push-Location $C
try {
    & $Python -B -m pytest -q -p no:cacheprovider tests/exp04 --tb=short `
        --junitxml=(Join-Path $Resultados 'exp04.xml')
    if ($LASTEXITCODE -ne 0) { throw 'TESTES_EXP04_REPROVADOS' }
    & $Python -B -m pytest -q -p no:cacheprovider `
        tests/passaredo tests/oma tests/vero tests/itajuba tests/beach_parque tests/int02 `
        --tb=short --junitxml=(Join-Path $Resultados 'seis.xml')
    if ($LASTEXITCODE -ne 0) { throw 'REGRESSAO_SEIS_REPROVADA' }
} finally { Pop-Location }
```

Não usar `-X utf8` para ocultar incompatibilidades. Não considerar Linux ou a
homologação anterior D2 como resultado Windows desta candidata. Como o baseline
não inclui os patches C/D2, a suíte Windows integral pode reencontrar falhas
históricas; registrar evidências e avaliar integração em tarefa autorizada separada.
Privilégio de symlink ausente e política DACL não validada não são aprovações.
Os quatro cenários sintéticos de symlink EXP-04 só são ignorados se a tentativa
real de criação retornar erro Windows 1314; o motivo explicita controle nativo
não validado. Não se solicita elevação nem alteração de política para executá-los.

## 3. Manifesto privado e comparação

Crie pastas privadas fora de qualquer Git em `%LOCALAPPDATA%\EXP04\Privado` e
`%LOCALAPPDATA%\EXP04\Evidencias`. Copie o exemplo do manifesto para a primeira
pasta e edite-o localmente: `exemplo: false`, raiz absoluta local, caminhos
relativos com `/`, hashes SHA-256 dos documentos originais. Não publique esse
manifesto, documentos ou caminhos. Placeholders não são aceitos como evidência.
Hashes atestam bytes, não procedência independente ou aprovação operacional.

São necessários os três documentos por perfil; cadastro pode ser `null` para
rodada sem complemento, explicitamente retida. Os templates devem corresponder
aos hashes históricos por condomínio; troca entre perfis é recusada. Outro
template exige revisão documental, não edição silenciosa dos hashes aprovados.

O utilitário reutiliza o helper REC-01-R1 existente, sem copiá-lo nem alterá-lo.
Seu SHA-256 obrigatório é
`2d30d5544db79a08f4829047d819fcc9074a2c32c439b1f3373e5b482acfc42c`.
Esse arquivo deve existir em
`tools\reconciliacao_privada\seguranca.py` sob a raiz indicada:

```powershell
$R1 = Join-Path $Root 'REC-01-R1' # ajustar para a R1 auditada preservada
$Privado = Join-Path $Root 'Privado'
$Evidencias = Join-Path $Root 'Evidencias'
# Criar previamente as duas pastas fora do Git; não copiar dados para $C.
& $Python -B (Join-Path $C 'tools\exp04\prereconciliar.py') `
    --rec01-r1 $R1 --candidata $C `
    --versao (Join-Path $Pacote 'VERSAO_EXP04_SHA256.json') `
    --manifesto (Join-Path $Privado 'manifesto.json') `
    --saida-pai $Evidencias --execucao ('rodada-' + [guid]::NewGuid().ToString('N')) `
    --referencia 2026-11-09 --prazos 30 60
if ($LASTEXITCODE -ne 0) { throw 'PRE_RECONCILIACAO_NAO_CONCLUIDA' }
& $Python -B (Join-Path $Pacote 'reconstruir.py') --pacote $Pacote --candidata $C --verificar
if ($LASTEXITCODE -ne 0) { throw 'INTEGRIDADE_FINAL_DIVERGENTE' }
```

O resultado `PRE_ANALISE_NAO_HOMOLOGADA` significa comparação concluída, nunca
aprovação da regra, endereço ou cadastro. O utilitário lê fontes protegidas,
confere identidade/hash antes e após, recusa áreas Git/links estáticos e nomes de
saída existentes, emite códigos seguros e só escreve JSON agregado. Não produz
XLSX real, não chama conversão normal nem instala dependências.

Os controles do helper são de contenção/leitura/integridade: não comprovam DACL
efetiva, exclusividade física contra hardlinks ou imunidade a toda corrida de
substituição Windows. Não elevar privilégios nem mudar ACLs para obter resultado.

## 4. Revisão antes de habilitar os quatro

Documentar aprovação da política de cada condomínio (prazo, operador, vigência,
exclusões), vínculo administradora→destino, unidades comerciais e divisão/bloco,
titularidade e atualidade do cadastro, endereço autorizado e segurança nativa.
Comparar agregados financeiros, linhas B e divergências justificadas; não importar
prévia técnica no destino. Só outra revisão autorizada poderá ativar configurações
operacionais. Esta tarefa não faz essa ativação.
