# EXP-04-WIN — matriz individual de correspondencia das 19 falhas

**Limite de proveniência:** o usuário informou contagens e grupos, mas ainda não forneceu os nodeids/tracebacks individuais nem os motivos dos sete skips. Os identificadores abaixo são correspondências propostas com os históricos D2, não uma reconstrução fictícia do JUnit EXP-04. Todos os 19 correspondentes passaram na seleção Linux desta tarefa. Validação individual do vínculo com a rodada Windows permanece pendente.

| ID | Grupo | Nodeid correspondente | Linux | Nova candidata Windows |
|---|---|---|---|---|
| WIN-01 | API | `tests/test_acl_evidence.py::test_evidencia_sempre_hardcoded_false` | APROVADO | NÃO_VALIDADO |
| WIN-02 | API | `tests/test_acl_evidence.py::test_normalizacao_8_3_expande_nome_curto` | APROVADO | NÃO_VALIDADO |
| WIN-03 | API | `tests/test_acl_evidence.py::test_comparacao_de_caminho_e_case_insensitive_ordinal` | APROVADO | NÃO_VALIDADO |
| WIN-04 | API | `tests/test_acl_evidence.py::test_hardlink_e_rejeitado_na_comparacao_de_caminho` | APROVADO | NÃO_VALIDADO |
| WIN-05 | API | `tests/test_acl_evidence.py::test_evidencia_com_baseline_registra_artefato_mas_nao_autoriza` | APROVADO | NÃO_VALIDADO |
| WIN-06 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[registro.json]` | APROVADO | NÃO_VALIDADO |
| WIN-07 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[chave.bin]` | APROVADO | NÃO_VALIDADO |
| WIN-08 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[escrita.lock]` | APROVADO | NÃO_VALIDADO |
| WIN-09 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[evidencias]` | APROVADO | NÃO_VALIDADO |
| WIN-10 | LINK | `tests/bbz/test_persistent_links.py::test_symlinks_rejeitados_sem_escrever_no_destino[cabecas]` | APROVADO | NÃO_VALIDADO |
| WIN-11 | LINK | `tests/bbz/test_persistent_links.py::test_raiz_link_ancestral_e_git_recusados` | APROVADO | NÃO_VALIDADO |
| WIN-12 | LINK | `tests/bbz/test_persistent_links.py::test_fonte_em_link_com_mesmos_bytes_tambem_e_recusada` | APROVADO | NÃO_VALIDADO |
| WIN-13 | LINK | `tests/phase3/test_protected_sources.py::test_fontes_rejeitam_acesso_invalido_sem_conteudo_no_erro[link-FONTE_CONTEM_LINK]` | APROVADO | NÃO_VALIDADO |
| WIN-14 | LINK | `tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[symlink]` | APROVADO | NÃO_VALIDADO |
| WIN-15 | MODO | `tests/phase3/test_private_validation.py::test_canonicos_so_por_opcao_explicita_na_area_privada` | APROVADO | NÃO_VALIDADO |
| WIN-16 | MODO | `tests/phase3/test_private_validation.py::test_conflito_documental_nao_confirma_gabarito_e_grava_auditoria_protegida` | APROVADO | NÃO_VALIDADO |
| WIN-17 | MODO | `tests/test_documents.py::test_auditoria_documental_persiste_em_json_protegido` | APROVADO | NÃO_VALIDADO |
| WIN-18 | CHMOD | `tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[permissao_fonte]` | APROVADO | NÃO_VALIDADO |
| WIN-19 | CHMOD | `tests/private_simulation/test_private_storage.py::test_isolamento_git_links_e_permissoes[permissao_raiz]` | APROVADO | NÃO_VALIDADO |

## Causa e alteração por grupo

### API

DLL oleaut32 incorreta e sete argumentos; contrato Win32 exige Kernel32 e cinco argumentos. Confirmacao estatica e evidencia de grupo fornecida pelo usuario.

Reuso exato da correcao diagnostica D2: ctypes com UTF-16, erros fechados e NUL recusado; sem integrar ACL na producao.

### LINK

WinError 1314 reportado para o grupo: criacao do link nao foi executada; nao demonstra falha de rejeicao do leitor.

Helper D2 ignora somente WinError 1314 no Windows; demais erros continuam falhando. Verificacao Git independente precede eventual skip.

### MODO

Bits POSIX de st_mode nao comprovam DACL NTFS. As verificacoes documentais continuam independentes.

Assercao exata 0600 preservada sob os.name == posix; no Windows, property DACL_WINDOWS_NAO_VALIDADA. Sem skip da funcao documental.

### CHMOD

chmod nao simula ampliacao de DACL; protecao de modo no fluxo existente e condicionada a POSIX. Isolamento Windows nao comprovado.

Ignorar apenas os dois parametros POSIX no Windows; EVIDENCIA_INSUFICIENTE, bloqueio de homologacao preservado.

## Origem e segurança

Os arquivos desses testes eram byte a byte iguais ao baseline BPQ-04 na EXP-04 original. O módulo ACL, o escritor JSON e os fluxos de permissão/proteção envolvidos também são herdados; a expansão dos quatro perfis não os modificou. A classificação de herança usa inspeção e comparação, sem alegar uma execução Windows nova do baseline.

APROVADO em Linux significa o teste correspondente executado naquele sistema. Mocks de WinDLL exercitam assinatura/tratamento, sem certificar chamada nativa. DACL, privilégios de symlink, junções, nomes 8.3 e isolamento efetivo exigem evidência Windows separada.

Os sete skips históricos são contagem fornecida pelo usuário, com motivos ainda NÃO_VALIDADO. Não foram associados automaticamente aos dois POSIX legados, symlink ACL ou quatro links EXP-04, embora essa composição seja plausível.

O JSON adjacente a esta matriz (`tools/exp04_win/casos_historicos.json`) contém causas, alterações, sistemas, ressalvas e status por caso. Não substituir pendência de DACL por aprovação porque uma função documental passou.
