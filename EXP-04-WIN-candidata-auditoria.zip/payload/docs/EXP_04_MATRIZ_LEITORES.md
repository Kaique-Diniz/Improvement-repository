# EXP-04 — matriz de compatibilidade

Evidência: inspeção estrutural e leitura dos anexos enviados nesta tarefa, fora do
Git, em Linux/Python 3.12.14; testes públicos usam exclusivamente fontes fabricadas.
Compatibilidade de leitura não significa homologação da regra de cobrança.

| Perfil | Financeiro | Cadastro | Contrato comprovado nesta preparação | Pendências |
|---|---|---|---|---|
| On Brooklin | `LeitorBBZXLSX` existente | `LeitorCadastroBBZ` existente | 576 recibos; 165 páginas/434 unidades cadastrais; fechamentos e continuação entre páginas | Política, integração, atualidade cadastral e Windows |
| Citzy Paulista | `LeitorBBZXLSX` existente | `LeitorCadastroBBZ` existente | 502 recibos; 107 páginas/298 unidades; negativos preservados; datas históricas Excel | Política, integração, diferença temporal e Windows |
| Panorama Diadema Club | `LeitorBBZXLSX` existente | `LeitorCadastroBBZ` existente | 792 recibos; 239 páginas/658 unidades; 775 componentes negativos | Política ambígua, administradora/vínculo, atualidade e Windows |
| Do It Pinheiros | `LeitorDoItXLSX` novo | `LeitorCadastroDoIt` novo | 808 recibos/134 unidades; fechamentos em seis colunas e resumo repetido; 596 participantes/345 unidades | Política, administradora/vínculo, divisão→bloco, comercial, A1 e Windows |

## Cobertura de testes

`tests/exp04/test_exp04.py`: quatro reconhecimentos, 16 cruzamentos cadastrais,
papéis de leitura, bloqueio da régua, prazo estrito 30/60 e limites, negativos,
igualdade A/B, 30 colunas atuais, alterações de totais/cauda/fórmulas, A1,
cadastro opcional/órfão, HTTP novo bloqueado e seis HTTP anteriores com download.

`tests/exp04/test_complementares.py`: 100 combinações de identidade financeira dos
dez perfis, códigos de destino confundidos com origem, endereços sintéticos A/B,
isolamento e encerramento de sessão, recibo repetido/comercial, blocos distintos,
CNPJ com zeros/inválido, datas seriais/datetime/texto, aba histórica alternativa,
coluna extra/formula e erros de CLI sanitizados.

`tests/exp04/test_reconstrucao.py`: hashes, extras, symlink de arquivo, pai, link
quebrado e diretório extra; recusa de helper R1 não auditado. Os testes de links
Linux não substituem junction/reparse, DACL, locks ou concorrência Windows.

## Eixos ainda sem aprovação

| Eixo | Estado | Motivo |
|---|---|---|
| Leitura estrutural dos quatro anexos | Executada em Linux | Agregados e reconciliação de componentes disponíveis |
| Política financeira autorizada | BLOQUEADO | Ausência confirmada pelo usuário para os quatro |
| Integração de destino | BLOQUEADO | Template histórico não é autorização; dois vínculos sequer comprovados |
| Cadastro Do It divisão/bloco e comercial | BLOQUEADO | Nenhuma equivalência presumida |
| Endereço e atualidade cadastral privados | NAO_EXECUTADO para homologação | Teste sintético não comprova configuração real vigente |
| Aplicação Windows desta candidata EXP-04 | NAO_EXECUTADO | Roteiro privado preparado; D2 preservada não é esta árvore |
| Segurança NTFS/DACL e substituição concorrente | Sem evidência nova | Não alterada nem homologada nesta etapa |
| Conversão operacional dos quatro | BLOQUEADO | Não existe régua aprovada ou vínculo ativo de saída |

Os seis perfis anteriores têm regressões específicas e HTTP; isso não transfere
aprovação dos seus controles nativos para os quatro novos.
