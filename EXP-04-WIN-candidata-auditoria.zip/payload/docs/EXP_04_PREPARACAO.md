# EXP-04 — preparação técnica dos quatro perfis

Baseline obrigatório: `770d062d29c4361d6932592883df9339bb4089bc`.
Worktree isolada EXP-04, HEAD destacado no baseline, sem commit ou publicação.

## Decisão de escopo confirmada pelo usuário

O usuário informou que **nenhum dos quatro condomínios possui política de
cobrança formalmente aprovada comprovada**. Também não há comprovação definitiva
da administradora/vínculo de integração de Panorama e Do It. Por isso a entrega
prepara reconhecimento, leitura, identidade, associação conservadora e comparação
hipotética. **Os quatro perfis são reconhecidos pelo MVP, mas a conversão HTTP e
a configuração da régua permanecem bloqueadas**, com HTTP 422 e código seguro
`EXP04_POLITICA_COBRANCA_NAO_APROVADA`.

Isso limita expressamente o item de conversão HTTP dos dez perfis: os seis
anteriores continuam convertendo e disponibilizando download; nos quatro novos,
o teste comprova reconhecimento e recusa controlada, não geração autorizada.
Não há homologação, cobrança, exportação operacional ou importação no destino.

## Arquitetura e identidade

| Perfil | Origem interna | Destino histórico | Administradora no template | Estado da integração |
|---|---|---|---|---|
| On Brooklin | 1343 | 3132 | BBZ | Pendente de aprovação |
| Citzy Paulista | 1704 | 3310 | BBZ | Pendente de aprovação |
| Panorama Diadema Club | 1991 | 653 | GRAICHE_2 | Administradora/vínculo não comprovados |
| Do It Pinheiros | Sem código numérico comprovado | 3224 | GRAICHE | Administradora/vínculo não comprovados |

Os códigos de destino não substituem os códigos de origem. A identidade das
fontes BBZ exige nome/alias interno e código de origem concordantes. Seleção
explícita e nome de arquivo não substituem essa verificação. Financeiro e cadastro
de outro perfil são recusados. Hash conhecido é evidência de bytes, não aprovação
da política ou de segurança do sistema operacional.

O cadastro Do It não contém identidade interna suficiente: somente o SHA-256
documental conhecido o vincula a esse perfil. Outro cadastro exige revisão e
atualização documental, mesmo com seleção explícita do condomínio. O financeiro
Do It tem assinatura própria com nome interno, cabeçalhos e posição.

`perfis_saida.json` e `identidades_integracao.json` **não foram alterados**. Esses
catálogos representam vínculos aprovados; não foi criada decisão de responsável
fictícia para satisfazer seu schema. Os quatro perfis pendentes estão em
`perfis.json`, com `dias` e `regra_prazo` nulos. Destinos históricos e seus hashes
ficam em `exp04_historicos.json`, marcado como evidência sem autorização.
O nome legado `fontes_homologacao_sha256` identifica fontes conhecidas; para
EXP-04, seus hashes não significam homologação.

## Leitura e cadastro

Três perfis reutilizam diretamente os leitores BBZ financeiro/PDF, a interpretação
de históricos e a associação cadastral BBZ existentes. Do It usa leitores próprios
de financeiro e cadastro XLSX. Todos preservam valores originais com Decimal,
ajustes negativos, origem documental, recibos e componentes.

O leitor Do It concilia seis colunas monetárias por recibo, unidade e total geral.
A cauda repetida de subtotais é validada contra a ordem e os valores originais,
sem gerar novas dívidas. O campo opaco de emissão é preservado na evidência em
memória, sem transformá-lo em data. Identificadores de recibos repetidos têm
ocorrências técnicas distintas e alerta de revisão, sem deduplicação silenciosa.

A associação Do It exige contexto, divisão/unidade, nome, papel titular e CPF/CNPJ
válido. Cônjuge, parente, locatário, imobiliária e procurador não são promovidos a
titular. Multiplicidade/conflito retém dados pessoais, preservando dívidas. Não há
mapeamento autorizado de `SETOR RESIDENCIAL` para bloco 1 ou `LOJAS` para bloco 2;
os arquivos atuais ficam com essa associação pendente. `LOJA01` permanece textual.
Uma linha cadastral órfã é retida sem atribuição; participantes não criam boletos.

## Comparação hipotética

`application/exp04_preparation.py` exige prazo e referência explícitos. Não há
prazo operacional padrão. A prévia usa identificador técnico `EXP04_NAO_INTEGRAR`,
não código histórico de destino. Modo B preserva todas as dívidas do A e acrescenta
uma linha por unidade com recibo fora da hipótese de prazo, sem valores líquidos
em revisão na unidade; não força os totais
históricos de linhas cadastrais. Valores líquidos não positivos ficam em revisão,
com contagem explícita; componentes negativos dos demais recibos são preservados.

O utilitário privado só emite agregados, não XLSX real nem relatório por morador.
A comparação financeira com template usa multiconjunto de unidade/data/valor,
preservando repetições. Codificações históricas de unidade não compreendidas são
marcadas como pareamento limitado, sem equivalências inferidas. Contagens iguais
não comprovam titularidade, endereço, procedência independente ou política.

## Preservação e pendências

- WIN-01-D2, REC-01-R1, seus pacotes e worktrees anteriores são preservados.
- EXP-04 parte do baseline exigido; não incorpora automaticamente as correções
  Windows de C/D2. O roteiro explicita que compatibilidade nativa desta árvore
  ainda exige execução Windows e revisão de eventual integração separada.
- Sem mudança na régua dos seis perfis, ACLs, bind local, exportador universal,
  persistência, descarte ou ADDR-01.
- Nenhum anexo privado ou endereço real foi incluído no Git/pacote. Evidências
  canônicas individuais são transitórias em memória; apenas agregados saem do
  utilitário. Manifesto com caminhos privados é externo e não integra a entrega.
- Falta aprovar prazo, operador, vigência, exclusões, identidade de integração,
  endereço por condomínio, atualização cadastral e mapeamentos Do It/comerciais.

Consulte `EXP_04_MATRIZ_LEITORES.md`, `EXP_04_PRE_RECONCILIACAO.md`,
`EXP_04_WINDOWS.md` e `EXP_04_ENTREGA.md` para evidências e limites.
