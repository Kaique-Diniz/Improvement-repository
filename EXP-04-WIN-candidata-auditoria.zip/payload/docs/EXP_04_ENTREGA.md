# EXP-04 — entrega para revisão

## Resultado e limites

Preparados quatro perfis documentais, leitura dos três formatos financeiros BBZ
com reaproveitamento e leitores próprios Do It, associação conservadora, prévia
hipotética A/B e ferramenta privada de agregação. Nenhuma política foi aprovada
por inferência. A conversão normal dos quatro novos está bloqueada.

Os seis anteriores mantêm testes de conversão HTTP/download. Não se declara
homologação dos quatro novos, segurança nativa Windows ou ativação de saída.

## Arquivos de produção alterados ou novos

| Arquivo | Efeito |
|---|---|
| `src/conversor/readers/do_it_xlsx.py` | Novo leitor financeiro; identidade, componentes, seis totais, cauda e proveniência |
| `src/conversor/readers/do_it_cadastro.py` | Novo leitor de participantes; papéis/documentos/contatos, órfãos retidos |
| `src/conversor/readers/exp04_identity.py` | Identidade específica, cruzamentos e cadastro Do It por hash documental |
| `src/conversor/application/exp04_preparation.py` | A1 Do It conservadora e comparação A/B com hipótese obrigatória |
| `src/conversor/web/perfis.json` | Quatro perfis pendentes; os registros anteriores preservados |
| `src/conversor/web/exp04_historicos.json` | Destinos/hashes históricos, sem aprovação de integração |
| `src/conversor/web/service.py` | Despacho dos leitores/reconhecimento e recusa da régua/conversão pendente |
| `src/conversor/web/ephemeral.py` | Tradução de dois códigos EXP-04 para HTTP 422 seguro |
| `src/conversor/web/static/classico.js` | Duas mensagens de erro compreensíveis para os bloqueios |
| `pyproject.toml` | Inclusão do JSON histórico nos package-data; nenhuma dependência adicionada |

Não foram modificados leitores BBZ, regras dos seis, exportador, contratos,
`perfis_saida.json`, `identidades_integracao.json`, ACLs ou persistência.

## Testes e evidências

- Primeira rodada EXP-04: 61 aprovados.
- Regressões selecionadas dos seis anteriores: 649 aprovados, um aviso conhecido.
- Rodada consolidada inicial EXP-04: 187 aprovados, zero falhas/skips; após a
  revisão de valores não positivos, a rodada final é registrada no pacote.
- A suíte integral Linux e as verificações finais são registradas em
  `RESULTADOS_FINAIS.md` e `evidencias/` do pacote, com contagens JUnit e comandos.
- O aviso é a depreciação preexistente do alias AnyIO em Starlette TestClient.
- Os 100 cruzamentos financeiros cobrem os dez perfis; os 16 cadastrais novos
  cobrem combinações entre os quatro. Testes individuais não usam anexos reais.
- Nenhum resultado Linux é apresentado como execução Windows nativa.

## Diff, integridade e preservação

`EXP04.patch` inclui diffs rastreados **e os arquivos novos não rastreados**.
`VERSAO_EXP04_SHA256.json` descreve toda a candidata; `BASELINE_SHA256.json` a base.
`MANIFESTO_SHA256.json` cobre todo o pacote exceto ele próprio. Logs/JUnit
sanitizados e relatório agregado privado sem dados individuais ficam em
`evidencias/`. O pacote não inclui entradas privadas, manifesto de caminhos,
worktrees antigas, credenciais ou caches.

A preservação de refs, arquivos, estados Git e ZIPs anteriores é conferida contra
o inventário inicial externo; o resultado final acompanha a entrega. HEAD isolado
não é prova da correspondência entre código e execução. O reconstrutor recusa
conteúdo divergente e extras antes de aplicar o patch em worktree nova.

## Próxima decisão necessária

Revisar os resultados financeiros comparativos e as retenções cadastrais. Obter
políticas aprovadas dos quatro e vínculos de destino, especialmente Panorama/Do
It; documentar divisão/bloco/comercial, endereços e atualidade cadastral. Só então
autorizar etapa específica de configuração e validação Windows. Não há commit,
push, PR, merge ou publicação nesta entrega.
