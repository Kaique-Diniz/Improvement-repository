# EXP-04-WIN — candidata local para auditoria

**Não homologada em Windows. Conversões reais dos quatro perfis bloqueadas.**

Começar por `RESULTADOS_FINAIS.md`, `MATRIZ_19.csv` e
`payload/docs/EXP_04_WIN_RELATORIO.md`. Os vínculos individuais com os 19
reprovados Windows são provisórios até receber os nodeids/tracebacks; os motivos
dos sete skips históricos também não foram fornecidos. Nenhum foi inventado.

- `EXP04_PARA_WIN.patch`: somente 18 arquivos novos/alterados desta revisão.
- `EXP04_WIN.patch`: reconstrução completa BPQ-04 + EXP-04 + WIN, 41 arquivos.
- `payload/`: cópias dos arquivos preparados, incluindo os não rastreados.
- `VERSAO_EXP04_WIN_SHA256.json`: todos os 460 hashes da candidata.
- `VERSAO_EXP04_ORIGINAL_SHA256.json`: os 448 hashes da EXP-04 original.
- `BASELINE_SHA256.json`: hashes dos 430 arquivos do commit-base.
- `MANIFESTO_SHA256.json`: todos os membros do pacote exceto ele próprio.
- `evidencias/`: JUnit, logs sanitizados, resultados, integridade e preservação.
- `reconstruir.py`: bootstrap autônomo derivado do EXP-04, substituindo apenas
  os nomes do patch/manifesto (proveniência em `DERIVACAO_RECONSTRUTOR.json`).

Usar somente worktree nova no commit
`770d062d29c4361d6932592883df9339bb4089bc`; não aplicar sobre D2, R1 ou EXP-04
existente. O reconstrutor recusa extras, links, reparse, conteúdo alterado ou
baseline incorreto e usa `git apply --check` antes de escrever. Não sobrescreve
artefatos preexistentes silenciosamente. Se a política Git de checkout converter
LF/CRLF, a verificação bloqueia: criar outra worktree com
`git -c core.autocrlf=false -C REPO worktree add --detach NOVA_PASTA BASE`, sem
alterar configuração global nem sobrescrever a primeira tentativa.

No PowerShell, seguir `payload/docs/EXP_04_WIN_WINDOWS.md`. O executor força
UTF-8 nos filhos de teste, confere todos os hashes antes/depois e grava evidências
fora do Git. Não instala dependências, não altera ACLs, políticas ou privilégios.
Retorno 3 em Windows significa testes sem falha mas segurança não comprovada;
não significa homologação. A sonda de ACL é só inventário.

Nenhum ZIP anterior foi substituído. Este pacote permanece local, sem commit,
push, PR, merge ou publicação. Não inclui documentos privados ou credenciais.
