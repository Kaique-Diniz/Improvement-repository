# EXP-04-WIN — resultado consolidado

## Estado da candidata

Candidata isolada no baseline BPQ-04 mais EXP-04, com 460 hashes conferidos
antes/depois dos testes. Somente `windows_acl_evidence.py` difere em produção
da EXP-04 e é idêntico ao patch D2 auditado. O helper de symlink também é
reaproveitado byte a byte. Não houve alteração de produção após a suíte final.

Sem commit, push, PR, merge, publicação ou modificação das worktrees/pacotes
anteriores. Os 448 hashes da EXP-04 e 454 da D2 permanecem conferidos. A R1
permanece igual ao inventário inicial. Não foram abertos documentos privados.

## Testes efetivamente executados

Linux/Python 3.12.14; filhos com `PYTHONUTF8=1`, sem instalar dependências.

| Escopo | Coletados | Aprovados | Falhas/erros | Ignorados | Estado |
|---|---:|---:|---:|---:|---|
| focados | 188 | 188 | 0 | 0 | APROVADO |
| seis | 649 | 649 | 0 | 0 | APROVADO |
| completa | 2842 | 2842 | 0 | 0 | APROVADO |
| complementares | 36 | 36 | 0 | 0 | APROVADO |
| nativos | 7 | 0 | 0 | 7 | NÃO_VALIDADO |

A suíte completa contém os 188 e 649, não é uma soma das rodadas. Os 36
complementares são separados dos 2.842 originais. Há um aviso preexistente de
depreciação AnyIO/Starlette nas seleções que importam TestClient.

Os sete testes nativos novos foram coletados, mas **nenhum foi executado em
Windows**: em Linux são NÃO_VALIDADO por `WINDOWS_REAL_NAO_DISPONIVEL`.
Esses sete não são os sete skips da execução histórica Windows do usuário.

Uma rodada intermediária passou nos testes mas revelou erro de sanitização XML
do executor. Foi corrigido operando nos campos XML decodificados; uma regressão
cobre caminho com `&`, Unicode, hostname e skip. Seus arquivos intermediários
permanecem fora do pacote; os logs/JUnit entregues são de uma nova rodada
completa, foram parseados com sucesso e correspondem ao manifesto final.

## Matriz das 19 correspondências

Os 19 correspondentes do histórico D2 passaram na seleção Linux dos módulos
afetados (203 casos). A análise estática demonstra DLL/assinatura erradas,
limitações POSIX versus DACL e necessidade de criação real do link para testá-lo.
Os arquivos desses testes eram idênticos entre BPQ-04 e EXP-04. Isso sustenta a
classificação de problemas herdados; não simula uma nova execução Windows.

**O usuário ainda não forneceu os 19 nodeids/tracebacks desta rodada ou motivos
dos sete skips.** Por isso `MATRIZ_19.csv` e JSON apresentam as correspondências
como provisórias. Causas individuais não são inferidas como prova primária pelo
nome do teste. Evidência Windows recebida: 2.842 coletados, 2.816 aprovados,
19 falhas, sete skips, zero erro de coleta, 448 hashes e UTF-8.

## Segurança e alterações em asserções

As expressões assert dos cinco arquivos históricos alterados foram preservadas
por comparação AST. Três asserções de modo são condicionadas a POSIX, preservando
o exato `st_mode & 0o777 == 0o600`. No Windows, continuam contagem de canônicos,
conflitos, CPF/CNPJ, JSON, contratos e privacidade; properties JUnit registram a
pendência DACL. Não há skip das três funções documentais.

Os dois parâmetros que usam chmod como simulação POSIX recebem skip só em
Windows. O helper ignora somente a tentativa de criar symlink que realmente
retorna Windows 1314; outros erros propagam. A verificação Git do caso misto
executa antes do eventual skip e tem cobertura independente nos complementares.
Nenhuma rejeição de link, ACE ou verificação de produção foi enfraquecida.

**DACL_WINDOWS_NAO_VALIDADA / EVIDENCIA_INSUFICIENTE permanece bloqueador.**
A sonda apenas lê volume e DACL, sem nomes/SIDs/SDDL/caminhos na saída. Não
calcula acesso efetivo de todas as contas, nem integra uma política ao escritor.
O comparador puro `mesmas_regras` e os comentários legados não demonstram sua
integração aos fluxos de leitura/escrita. Os módulos reais desses fluxos foram
inspecionados e não foram alterados.

Sete controles nativos preparados: ordinal/case-insensitive, sufixo não BMP,
alias 8.3 real + arquivo diferente, caminhos distintos, hardlink no contrato
diagnóstico, junction externa no leitor de produção e inventário NTFS/DACL da
escrita JSON. Junction é evidência separada, não substitui cenários de symlink
ignorados. Falta testar no Windows e comprovar isolamento entre contas/processos.
Não há aproximação textual como fallback Windows para a API ordinal.

## Integridade e transição

O diff incremental passou em `git apply --check` contra a EXP-04 original, sem
alterá-la. O pacote inclui reconstrução completa e manifesto integral, não apenas
HEAD ou diff de rastreados. Conferência de reconstrução Linux em worktree nova
acompanha o pacote após sua conclusão.

Usar o roteiro Windows para testar uma nova worktree. A API diagnóstica e a
configuração UTF-8 não autorizam homologação de segurança. Skips permanecem
NÃO_VALIDADO. O executor mantém `homologacao_windows_integral=false`, registra
a pendência e retorna 3 no Windows quando não há falhas mas falta evidência.
Reconhecimento, A1/B1, finanças, 30 colunas, seis perfis anteriores e os bloqueios
dos quatro novos têm os mesmos bytes da EXP-04.

**As conversões reais dos quatro novos condomínios continuam BLOQUEADAS.**
