# WIN19-H3-I — índice, fontes e limites da apuração

24/11/2026 — America/Sao_Paulo.
Pasta exclusivamente documental nova: /workspace/work/WIN19-H3-I-APURACAO-PUBLICACAO-20261124,
externa ao Git/entregas anteriores. Não é custódia do JUnit.

## Nove documentos

1. [RELATORIO_H3_I_APURACAO.md](RELATORIO_H3_I_APURACAO.md) — respostas às oito
   perguntas e separação entre publicação, autorização e operação.
2. [CRONOLOGIA_PUBLICACAO.md](CRONOLOGIA_PUBLICACAO.md) — sequência, horários
   registrados/mtime e limites de comprovação.
3. [EVIDENCIAS_GITHUB_H3_F_R1.md](EVIDENCIAS_GITHUB_H3_F_R1.md) — GETs, objetos,
   binário em memória, refs e registros técnicos contemporâneos.
4. [MATRIZ_AUTORIZACOES_E_FONTES.csv](MATRIZ_AUTORIZACOES_E_FONTES.csv) — 14 questões
   com fonte, classificação, escopo expresso/inferido e pendências.
5. [AVALIACAO_EXPOSICAO_E_IMPACTO.md](AVALIACAO_EXPOSICAO_E_IMPACTO.md) — inventário
   e cinco eixos, com confidencialidade institucional pendente de classificação.
6. [ERRATA_PROPOSTA_PROTOCOLO_H3_H.md](ERRATA_PROPOSTA_PROTOCOLO_H3_H.md) — texto
   externo proposto, sem alterar a linha 22 ou o protocolo original.
7. [DECISOES_PENDENTES_H3_I.md](DECISOES_PENDENTES_H3_I.md) — cenários A/B, decisões
   do responsável e bloqueios preservados.
8. INDICE_ENTREGA_H3_I.md — este inventário/proveniência.
9. [MANIFESTO_SHA256_H3_I](MANIFESTO_SHA256_H3_I) — oito arquivos anteriores;
   exclui a si; hash próprio informado na conversa.

## Referências obrigatórias lidas

Instrução H3-I recebida como Texto colado.txt: 7.724 bytes, SHA-256
6806856f7b016f01d14bb90f84fd162c8039f06946bc509c7a50291d3069d64f.
PARECER_INDEPENDENTE_WIN19_H3_H_2026-11-24.md: 8.647 bytes, SHA-256
66c7b3c565ba84ff0caa844d690899f5139417104aa57aba96e375ab7d352f3b.
PARECER_INDEPENDENTE_WIN19_H3_F_R1_2026-11-24.md: 7.253 bytes, SHA-256
eb6d4941b8e6c280c574a08ef45d8b6538bc91f0f3352ff189059f752110d365.
Pareceres lidos como fundamento, sem executar anexos; não são autorização nativa.

| Fonte documental local | Bytes | SHA-256 |
|---|---:|---|
| Protocolo H3-H — PROTOCOLO_EXECUCAO_WINDOWS.md | 5551 | ce5622646e63fc61a994ca3162d8516a16acc94204c41376acf6615e4ee4e75a |
| Índice R1 — INDICE_ENTREGA_H3_F_R1.md | 4749 | 80d818408e7d78e732b782f78219dd74cd4e3451096627a6bfad30dc2c5bb685 |
| Manifesto R1 — MANIFESTO_SHA256_H3_F_R1 | 633 | 5b517e9b7572c5505b6bd35ecefb19ad127e0d4e7842bc0447f61b15b311f99d |

Também consultada a instrução original H3-F-R1, Texto colado.txt de 10.550 bytes,
SHA-256 5dfad987e01bc8f7bef5ed83675a28b6ad0fd09b0584000cb98d37319c4eba47,
para confrontar as restrições iniciais. Pacote R1, manifesto e seis documentos
foram conferidos; sete documentos/manifesto H3-H também. Fontes permaneceram iguais.

## Fonte conversacional de autorização e processo

CONV-MAT-R1/CONV-PUB-R1 são rótulos locais, não IDs originais da plataforma.
CONV-PUB-R1 identifica a mensagem do usuário imediatamente após a entrega R1:
“organize os arquivos gerados, em um zip, publique e disponibilize ele.”.
A ordem e o texto estão disponíveis no histórico desta conversa. Não há export
nativo assinado, ID ou timestamp original de mensagem fornecidos; não se inventam.
O pedido é evidência expressa de ZIP/publicação, e a instrumentação GitHub/commit/
push é inferência contextual separada, não transcrição literal ou aprovação por
silêncio. Exceções antigas de outros pacotes não são tratadas como autorização
específica substituta deste pedido.

O histórico de chamadas/saídas das ferramentas iniciadas pelo assistente Codex
registra Python/subprocessos Git em checkout temporário isolado, commit raiz de arquivo único, push da ref e
verificação pública. São registros de processo disponíveis na conversa, não log
GitHub de ator autenticado ou monitoramento independente de sistema.

## Fontes remotas e temporárias

Endpoints e resultados estão em EVIDENCIAS_GITHUB_H3_F_R1.md, apenas GETs de repo,
commit, árvores, heads/tags e metadado do commit posterior H3-H. Nenhuma conta,
credencial ou audit log privado foi consultado. O único binário remoto lido foi
o ZIP alvo, em memória, HTTP Date observado 24/11/2026 18:25:52 GMT. Não se
baixaram outros documentos privados ou artefatos remotos.

Snapshot local heads-antes.txt: 5.889 bytes, SHA-256
7196724879f55b7372269b92d7853cc721273b8e2f24c5e6d776ab3681331467.
commit.txt: 41 bytes, SHA-256
7b571bb39bbddf060cc31da2f9c77fc2996b8f56bc965e7f22897b78c5cc9645.
Reflog HEAD local: 257 bytes, SHA-256
407f96459a217e7c319e44349fc441063958281ca236a2cf2337521f36561953.
Nenhum desses registros foi alterado. mtime é metadado observado e não timestamp
forense de criação, mensagem ou push. Hashes de snapshots autenticam os bytes
lidos nesta apuração, sem torná-los imutáveis ou atestados pelo GitHub.

## Ferramentas, preservação e limites

Conector GitHub somente GET. Como não fornece download binário, o ZIP autorizado
foi lido por HTTP GET em buffer de memória, sem extração em disco. Python -I -B/
biblioteca padrão para metadados, ZIP/CSV documentais, comparação e SHA-256/blob
Git. Nenhum código do pacote foi executado ou parseado como PowerShell.

A matriz usa CONFIRMADO_POR_EVIDENCIA, RELATADO, INFERIDO e SEM_FONTE, com o escopo
da proposição explícito. Não confundir metadado comprovado com autoria humana,
hora de push ou autorização formal de cada instrumento. Integridade não prova
segurança/confidencialidade institucional nem ausência global de outras operações.

Só os oito documentos novos e manifesto foram escritos fora do repositório.
Sem ZIP, Git/refs/visibilidade alterados, remediação, publicação, Windows/teste,
parser, JUnit, custódia ou ACL/privilégio. Parar para auditoria independente.
