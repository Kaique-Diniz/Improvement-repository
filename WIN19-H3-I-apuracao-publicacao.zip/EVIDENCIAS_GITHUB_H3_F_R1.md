# H3-I — evidências GitHub e corroboração local

24/11/2026. Todas as consultas remotas foram GET; sem credenciais, logs privados
de conta ou modificação de referências. ZIP alvo lido em memória, sem execução.

## Consultas públicas e resultados

| Consulta | Observação |
|---|---|
| [Repositório](https://api.github.com/repos/Kaique-Diniz/Improvement-repository) | private=false; ramo padrão main |
| [Commit Git](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/commits/4b0e6890035e0562358b5e5175e274386889adea) | SHA esperado; pais=[]; autor/committer Codex Audit Transfer e data 2026-11-24T17:44:42Z; verificação criptográfica do commit não marcada como verificada |
| [Árvore do commit](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/trees/5f513436577e350cd6bbfda0dac32ce034bded45) | Não truncada, uma entrada regular 100644, ZIP de 20.627 bytes, blob a0d64ad88554c221404116739f67bb56b7c37ebc |
| [Heads](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/matching-refs/heads/) | 71; uma ponta aponta diretamente ao SHA alvo: refs/heads/transfer/win19-h3-f-r1-correcoes |
| [Tags](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/matching-refs/tags/) | Lista vazia na consulta atual; nenhuma tag apontando diretamente ao alvo |
| [Commit main](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/commits/04f29ff5fc9124b988bd611d3d1b8d7224ae874f) | Mesmo SHA do snapshot pré-transferência |
| [Árvore raiz main](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/trees/5cf89604462dfe9473ff6df9b46c1ab14a720212) | Não truncada, 21 entradas, sem ZIP no caminho raiz publicado; não se fez varredura recursiva de conteúdos |
| [Commit H3-H posterior](https://api.github.com/repos/Kaique-Diniz/Improvement-repository/git/commits/55863d90ea3d0f08cedf0661947d02ee7953b5b0) | Root sem pais, data registrada 18:07:39Z, publicação de outro ZIP em outra ref |

Mensagem exata do commit alvo:
`chore(audit): disponibilizar WIN19-H3-F-R1 para auditoria independente`.
A árvore sem pais/arquivo único confirma o limite do commit; não atesta todas as
operações de uma conta, configurações, workflows ou eventos intermediários.
Não há prova de merge do alvo em main; a consulta confirmou apenas a ausência
do caminho publicado na árvore atual e o SHA de main inalterado.

## Bytes atuais do arquivo público

[URL histórica consultada](https://raw.githubusercontent.com/Kaique-Diniz/Improvement-repository/4b0e6890035e0562358b5e5175e274386889adea/WIN19-H3-F-R1-correcoes.zip).
É uma referência de evidência desta investigação, não uma recomendação operacional
de obtenção/execução. HTTP 200; Date informado Tue, 24 Nov 2026 18:25:52 GMT.
Leitura limitada a 20.628 bytes para detectar excesso; resultado efetivo 20.627.
Sem persistência de nova cópia: somente buffer em memória e leitura ZIP/CSV.

SHA-256 obtido:
442e17cfaae0afe91ff63d3fa60ba3e824e988f0ff586a436f9513a4612dffaa.
SHA-1 de objeto Git blob obtido:
a0d64ad88554c221404116739f67bb56b7c37ebc.
O segundo é hash de `blob ` + comprimento decimal + byte NUL + conteúdo;
não é o SHA-1 simples do ZIP nem substitui o SHA-256 do artefato.
CRC sem erro, sete entradas, seis nomes/tamanhos/hashes internos conferidos.
O binário remoto coincide com o ZIP e documentos locais previamente autenticados.

## Mudanças de referências observadas

heads-antes.txt local: 69 refs, nenhuma branch alvo; 5.889 bytes, SHA-256
7196724879f55b7372269b92d7853cc721273b8e2f24c5e6d776ab3681331467.
Comparado à coleção atual de 71 heads: zero antigas removidas, zero antigas com
SHA modificado, duas novas:

- transfer/win19-h3-f-r1-correcoes → 4b0e6890035e0562358b5e5175e274386889adea;
- transfer/win19-h3-h-preparacao-parser → 55863d90ea3d0f08cedf0661947d02ee7953b5b0.

A segunda pertence a etapa posterior distinta. Não se atribui sua criação à
transferência H3-F-R1. Esse confronto não é inventário histórico de tags, refs
apagadas/intermediárias ou todos os eventos GitHub. Não foi percorrido o grafo
completo de ancestralidade de cada branch; “única ponta direta” não significa
prova de inexistência de qualquer outra referência indireta/retida pelo serviço.

## Processo contemporâneo registrado

O assistente Codex desta conversa iniciou a chamada de ferramenta local registrada,
executando Python com subprocessos Git em checkout temporário isolado: init de branch, adição do
único ZIP, commit raiz, verificação de árvore/bytes e push de HEAD para a ref
exclusiva. A identidade técnica foi configurada como parâmetros da chamada;
a transferência usou helper de autenticação já disponível, sem credencial impressa.
Não se acessou sua configuração/token para tentar identificar pessoa.
A saída histórica registra `[new branch] HEAD -> transfer/win19-h3-f-r1-correcoes`.

Corroboração local preservada:

| Registro | Bytes/hash/conteúdo conferido |
|---|---|
| commit.txt | 41 bytes; SHA-256 7b571bb39bbddf060cc31da2f9c77fc2996b8f56bc965e7f22897b78c5cc9645; SHA alvo |
| HEAD do checkout temporário | ref: refs/heads/transfer/win19-h3-f-r1-correcoes |
| Reflog HEAD | Um registro de commit inicial; 257 bytes; SHA-256 407f96459a217e7c319e44349fc441063958281ca236a2cf2337521f36561953; zero→SHA alvo, epoch 1795542282, offset +0000 |
| download-publico.zip histórico | 20.627 bytes, mesmo SHA-256 442e17…ffaa; igual ao ZIP local |

Reflog confirma registro local de commit inicial, não um evento de push no GitHub.
Autor/committer não provam identidade da conta que autenticou o push. Não há PID
ou identidade humana autenticada em audit log disponível nesta apuração.
