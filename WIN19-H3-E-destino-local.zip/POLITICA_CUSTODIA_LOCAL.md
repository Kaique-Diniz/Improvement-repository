# H3-E — política de custódia inicial local

24/11/2026. POLITICA_APROVADA_PELO_USUARIO nos limites expressos da instrução H3-E.
Não é termo operacional H3-C nem evidência de proteção efetiva.

## Papéis e acesso

O próprio usuário será o custodiante principal. Identidade nominal e legitimidade
serão formalizadas em registro privado. Não presumir prova de identidade da conta
Windows, do operador H2 ou de alias herdado do Portão B. Coadministradores serão
pessoas específicas, previamente autorizadas; nomes, responsabilidades e limites
ficarão privados. Não publicar pessoas, contas, SIDs ou caminho pessoal.

Alterações de acesso, movimentações e exclusões exigem aprovação prévia e específica
do custodiante. Isso não autoriza alterações de ACL/privilégios nesta tarefa nem
por iniciativa dos coadministradores. Administração compartilhada não autoriza
participação automática na cópia inicial. Registros, revisão da retenção, eventual
substituição e responsabilidades concretas ainda precisam de formalização privada.

## Ambiente e destino

Execução inicial planejada localmente pelo usuário no seu computador Windows,
disco interno, diretório local novo e exclusivo, fora de Git/worktrees, R1-FIX,
C5–C8, custódias anteriores e pastas sincronizadas. O caminho definitivo é pendente
de aprovação/verificação. Nenhum nome de pasta ou perfil de usuário prova proteção.

A assistência remota não integra o escopo atual. Acesso independente, assistência,
compartilhamento de pasta em rede ou transferência remota não estão autorizados.
Não instalar/configurar/exigir soluções remotas. A preferência histórica por sessões
supervisionadas fica apenas como possibilidade futura sujeita a autorização própria.

## Retenção vinculada à H4, com limite inicial

- Modalidade B: vinculada à conclusão da H4, máximo inicial de 180 dias.
- Marco de contagem: somente após cópia fiel aceita e verificada, com evento real
  identificado na cadeia privada. H2 e a presente data não iniciam a contagem.
- Revisões nos dias 60, 120 e 180, contados do marco real; datas concretas ainda
  inexistentes. Nenhuma tarefa agendada ou revisão foi executada.
- Conclusão antecipada da H4 desencadeia revisão da necessidade, sem descarte
  automático ou autorização implícita de H4.
- Prorrogação somente com justificativa e aprovação expressa, limite/revisão
  identificáveis. Não renovar por silêncio, nem presumir qualquer prazo adicional.
- Avaliar obrigações institucionais de preservação antes da custódia operacional.
  Eventual conflito exige decisão legítima, sem ignorar obrigação nem presumir sua
  existência. Não interpretar 180 dias como ordem para violá-la ou eliminá-la.
- Nenhuma exclusão automática, inclusive ao término da H4, em 180 dias, por
  revogação, falha, cópia parcial ou divergência. Eventual descarte precisa de
  aprovação prévia específica e procedimento próprio; preservar a origem.

## Limites operacionais

Validade da autorização de cópia é decisão separada: início e término ainda
pendentes. Os 180 dias não autorizam executar por esse período. Fonte, destino,
proteção, método específico, cadeia privada e termo operacional precisam ser
aprovados antes de H3-C. Esta política não homologa DACL ou controles do produto.
Nenhuma cópia, acesso remoto ou mudança de segurança é concedida por este texto.
