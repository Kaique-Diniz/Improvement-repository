# H3-E — requisitos e sequência de pré-condições da cópia fiel futura

24/11/2026. Especificação de requisitos, sem comando executável, script, API/flags
implementados ou procedimento Windows aprovado. H3-C NAO_AUTORIZADA.

## Sequência de condições anteriores à operação

1. Submeter a documentação H3-E à revisão independente, considerando o parecer
   H3-D já consultado; formalizar identidades, legitimidade, coadministração e
   responsabilidades privadamente. Sua aceitação documental não autoriza cópia.
2. Aprovar caminho local exato e demonstrar proteção suficiente após futura avaliação
   somente de leitura autorizada. Preservar as separações, execução local e ausência
   de sincronização/compartilhamento remoto. Não criar pasta para avaliá-la.
3. Formalizar retenção B, 180 dias após aceite, revisões 60/120/180 e H4 antecipada,
   responsabilidades e avaliação de obrigações institucionais. Sem exclusão automática.
4. Preparar em etapa própria o procedimento Windows específico de cópia, com
   identidade, concorrência, criação exclusiva, preservação, fechamento e resposta
   a falhas tecnicamente justificadas. Submetê-lo à revisão sem executá-lo.
5. Obter termo operacional expressamente aprovado, identificando método, objeto,
   finalidade, custodiante, local/proteção, início e fim da validade e registros.
   Autorização temporal não é retenção; a política atual não substitui esse termo.

## Requisitos que o método específico precisará satisfazer

- Fonte nominal H2: completa-utf8.xml no local histórico relativo a LOCALAPPDATA.
  Fingerprint relatado: 441.505 bytes e SHA-256
  `3d084916b92b8202c57ee249bc99d9288fc2d1b9dad69c78656e9d3b7d70ba28`.
  Não se recalculou o hash nesta H3-E. Exigir igualdade atual exata antes da cópia,
  sem buscar substitutos ou atualizar o fingerprint diante de divergência.
- Autenticar a fonte dentro dos limites observáveis, com identificação suficiente
  e estabilidade durante validação/abertura/cópia. Correspondência de SHA-256 não
  demonstra autenticidade histórica da rodada, comando ou manifesto 448 utilizado.
- Exigir destino/proteção aprovados e revalidar condições mutáveis pertinentes;
  definir como impedir redirecionamento/substituição concorrente, inclusive dos
  ancestrais. A inspeção anterior não prova sozinha ausência de corrida futura.
- Criar cópia independente exclusivamente, sem sobrescrever arquivo preexistente,
  sem aceitar link como substituto de cópia e sem seguir reparse inesperado.
  Colisão, ambiguidade ou identidade insuficiente interrompem a operação.
- Preservar integralmente bytes e original; sem parsing XML, normalização, edição,
  decodificação/regravação, restauração de timestamp ou sanitização da fonte.
- Conferir tamanho e hashes de origem/destino e estabilidade pertinente; fechamento
  dos recursos e conclusão precisam ser demonstrados antes de aceitar a cópia.
  Não marcar cópia parcial ou exclusão/fechamento inconclusivo como sucesso.
- Registrar cadeia privada com apenas eventos efetivos: objeto/fingerprint,
  identidade observada e limitações, autorização/método, custodiante, origem/destino,
  ferramenta, UTC, resultados de integridade e encerramento. Dados pessoais e
  caminhos reais ficam privados; uma versão pública exige autorização própria.
- Interromper diante de divergência, alteração concorrente, proteção insuficiente,
  reparse, falha de API, acesso indevido ou validade ausente/expirada. Preservar
  evidências e parciais com acesso protegido; não limpar/excluir automaticamente,
  tentar fonte/local alternativo ou mudar segurança para concluir.

## Limite desta preparação

Nenhuma cópia, abertura do XML, execução Windows ou conferência atual da fonte foi
realizada. Não há procedimento técnico aprovado; os itens acima são critérios de
projeto/revisão. O aceite futuro apenas poderá confirmar os fatos observados, não
validar retrospectivamente a história da execução ou aprovar H3-S/H4/WIN/DACL.
