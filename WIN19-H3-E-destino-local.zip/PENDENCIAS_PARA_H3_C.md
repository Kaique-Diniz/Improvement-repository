# H3-E — pendências e condições para futura H3-C

24/11/2026. H3-C NAO_AUTORIZADA. Todas as condições operacionais continuam abertas.

| Pendência | Decisão/evidência necessária | Efeito enquanto aberta |
|---|---|---|
| Formalização do custodiante | Identidade nominal, legitimidade, deveres e substituição em registro privado | Política aprovada não é designação comprovada |
| Coadministradores | Identificação privada e responsabilidades de pessoas específicas autorizadas | Sem participação/acesso/movimentação/exclusão presumidos |
| Caminho local exato | Proposta privada e aprovação após evidência pertinente | Nenhum local escolhido, criado ou aprovado |
| Proteção efetiva do local | Avaliação futura somente de leitura autorizada, incluindo volume interno/local, ancestrais, Git, áreas proibidas, sincronização e acessos existentes | Sem proteção demonstrada, não copiar nem alterar segurança |
| Obrigações institucionais | Avaliação legítima de preservação e compatibilidade da política com obrigações reais | Não presumir inexistência nem descarte em 180 dias |
| Responsabilidades e registros | Designar responsáveis por cadeia, acesso, revisão 60/120/180, H4 antecipada, prorrogação e descarte específico | Não preencher eventos futuros ou criar agenda automática |
| Validade de autorização | Início e término/expiração específicos da operação de cópia | Os 180 dias de retenção não autorizam operação |
| Procedimento Windows específico | Método identificado, revisão de identidade/concorrência/exclusividade/bytes/hash/fechamento/falhas e aprovação própria | Requisitos textuais não são comando executável nem método aprovado |
| Termo operacional H3-C | Aprovação expressa legítima de escopo, local/proteção, método e validade | Nenhuma execução autorizada por esta H3-E |

O parecer H3-D foi recebido e consultado. A ressalva editorial (18 pendentes e
duas propostas, sem aprovação na H3-D) está explicitada apenas nos documentos
novos. Não modifica o original nem elimina a necessidade de verificação do destino,
autorização operacional ou comprovação histórica do XML.

Retenção já definida em política: vinculada à H4, máximo inicial 180 dias após
cópia fiel aceita/verificada, revisão em 60/120/180 e se H4 terminar antes,
prorrogação expressa justificada e nenhuma exclusão automática. Não reclassificar
essa escolha como integralmente indefinida; sua implementação continua pendente.
Nenhum marco de contagem ocorreu. Referências futuras a dias/datas exigem evento
real e registro UTC, sem inventar aprovação/assinatura ou herdar prazo do Portão B.

## Portões preservados

H3-C=NAO_AUTORIZADA; H3-S=NAO_AUTORIZADA; H4=NAO_AUTORIZADA;
assistência_remota=ADIADA_NAO_AUTORIZADA;
vinculos_historicos=PROVISORIO_SEM_FONTE;
WIN-01..WIN-19=NÃO_VALIDADO; DACL=NÃO_VALIDADO;
runner_C=NÃO_IMPLEMENTADO; C/D/E=BLOQUEADOS;
CONVERSOES_REAIS=BLOQUEADAS; prontidao_para_executar=false.

Sem comando/preflight/teste/inspeção Windows, ACL, privilégio, conta, criação de
custódia, cópia XML ou solução remota. Não publicar XML nem evidências privadas.
Esta entrega não reabre Portão B, R1-FIX ou contratos/candidatas anteriores.
Parar para revisão independente. Próxima decisão: aprovação do local e do
procedimento técnico após revisão das evidências correspondentes, em escopos
próprios; nenhuma liberação automática resulta deste documento.
