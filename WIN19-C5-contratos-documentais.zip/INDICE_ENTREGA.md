# WIN19-C5 — contratos em documentação, para revisão

19/11/2026, America/Sao_Paulo. Nova pasta externa ao Git. **Nenhum dos seis arquivos
finais Categoria A foi criado.** Nenhum B foi implementado ou executado.

## Entregáveis principais

1. [RELATORIO_C5_CONSOLIDACAO.md](RELATORIO_C5_CONSOLIDACAO.md) — decisões propostas
   ESPECIFICADO por seis contratos, limites e estados efetivamente preservados.
2. [CONTRATO_EVENTO_PROPOSTO.md](CONTRATO_EVENTO_PROPOSTO.md) — evento sem PASS,
   observado/esperado, ausência e falha de persistência.
3. [CONTRATO_MENSAGEM_ACK_PROPOSTO.md](CONTRATO_MENSAGEM_ACK_PROPOSTO.md) — ACK como
   declaração correlacionável, nunca prova de persistência.
4. [CONTRATO_ESTADOS_PROPOSTO.md](CONTRATO_ESTADOS_PROPOSTO.md) — taxonomias, arestas
   documentais e bloqueio de promoções entre dimensões.
5. [CONTRATO_RELATORIO_PROPOSTO.md](CONTRATO_RELATORIO_PROPOSTO.md) — resultados por
   afirmação/eixo, fontes, sentinelas, cleanup, custódia, histórico e lacunas.
6. [CONTRATO_COBERTURA_21_PROPOSTO.md](CONTRATO_COBERTURA_21_PROPOSTO.md) — esquema
   de 14 colunas e tabela Markdown de 21 subcasos/19 IDs, sem criar CSV final.
7. [CONTRATO_VETORES_SINTETICOS_PROPOSTO.md](CONTRATO_VETORES_SINTETICOS_PROPOSTO.md) —
   dez propostas SINTETICO_NAO_EXECUTADO, completas ou projeções tipadas.
8. [MATRIZ_INTERFACES_E_DEPENDENCIAS_C5.csv](MATRIZ_INTERFACES_E_DEPENDENCIAS_C5.csv) —
   seis linhas com dados, segurança, dependências, rejeição e decisão humana.
9. [RISCOS_E_DECISOES_PENDENTES_C5.md](RISCOS_E_DECISOES_PENDENTES_C5.md) — D5-01..11,
   limites de expressividade/prova e dependências runtime fora de A.
10. [ESCOPO_EXATO_AUTORIZACAO_FUTURA_A.md](ESCOPO_EXATO_AUTORIZACAO_FUTURA_A.md) —
    lista exclusiva dos seis caminhos e conteúdo/proibições, sem conceder autorização.
11. [MATRIZ_DIFERENCAS_C4_C5.csv](MATRIZ_DIFERENCAS_C4_C5.csv) — 11 temas de diferenças,
    nenhuma mudança em produto, estados de T ou controles.
12. [MANIFESTO_SHA256](MANIFESTO_SHA256) — nome/tamanho/hash somente dos arquivos
    efetivamente entregues nesta pasta, excetuando o próprio manifesto.

## Documentos de apoio e fontes

- [BASE_COMUM_E_VERSIONAMENTO_C5.md](BASE_COMUM_E_VERSIONAMENTO_C5.md) integra as
  seis propostas. Não é um sétimo arquivo Categoria A a criar. Define versão,
  perfil offline, tipos, nulidade, referências e limites estruturais versus operacionais.
- [INVENTARIO_FONTES_C5.csv](INVENTARIO_FONTES_C5.csv) contém dez fontes locais,
  tamanhos, SHA e limites; o alias MATRIZ_C2_AUDITADA identifica a fonte de planejamento.
- fontes_recebidas/: cópias literais da instrução C5 e parecer C4, sem executar conteúdo.
- [CONFERENCIA_DOCUMENTAL.md](CONFERENCIA_DOCUMENTAL.md) registra contagens e hashes,
  sem parser/validador de schema ou resultado de teste.

A base cita consultas públicas ao Core/Validation JSON Schema e RFC 8259. Não se
arquivaram páginas remotas nem se atribuiu SHA fictício. URLs aparecem nos documentos
de fundamentação, não nos seis arquivos finais, que não existem nesta C5.
Nenhuma regra foi apresentada como garantia de verdade, custódia ou autorização.

Base C4: ZIP d217ad580898d415b8689f3cf6d65773f29a19f30080fdb21e046b9789af89ee,
manifesto 82ced21c6a8ee98f4b888899abdda3c69519aaeb24f9af225e51ae320ce8053d.
Parecer obrigatório SHA
8712dddef05a9408cfeadaae8549fd3607f99197baa218e9693b71538e22db64,
que não autorizou materializar A, implementar B ou executar testes.

## Ressalvas centrais e parada

Versão proposta 0.1.0-proposta-c5, campos fechados e dialeto offline precisam de
revisão humana. Sem $schema, um consumidor genérico não tem dialeto garantido;
perfil aprovado deve selecioná-lo sem rede. Relações entre registros e prova factual
são S/P, não validação estrutural automática. Vetores/projeções não são execuções.
Timeout/capacidade/orçamento/retenção permanecem PARA_REVISÃO, sem valores ativos.

Seis contratos ESPECIFICADO apenas documentalmente; todos NÃO_CRIADO/NÃO_VALIDADO,
autorização PENDENTE. Isso não promove T01/T06 ESPECIFICADO, T02 BLOQUEADO ou
T03/T04/T05/T07 PARCIAL. 19 vínculos PROVISORIO_SEM_FONTE; sete skips sem primário.
prontidao_para_executar=false; autorizacao_testes=PENDENTE; runner_C=NÃO_IMPLEMENTADO;
WIN01–WIN19/DACL=NÃO_VALIDADO; D01–D10=PARA_APROVAÇÃO;
C/D/E e CONVERSOES_REAIS=BLOQUEADOS. Portão B encerrado, autorização consumida.

Sem criação de A/B, Python, pytest, PowerShell, preflight, import/ferramenta do produto,
scripts/fixtures, candidata/worktree/Git/configuração/dependências/ACL/privilégios,
coleta privada Windows, conversão, commit/push/merge/publicação ou ZIP novo.
Utilitários de texto/arquivo/hash apenas para documentos; exemplos não analisados
por parser. Parar após C5 para revisão independente, sem pedido automático de execução.
