# Base comum dos contratos C5 — proposta documental

19/11/2026. Versão proposta: **0.1.0-proposta-c5**. Nenhum dos seis arquivos finais
foi criado. Esta base integra os seis documentos de contrato; não é sétimo artefato
Categoria A proposto. Não contém schema operacional, validador ou comando.

## 1. Estrutura, semântica e prova são níveis distintos

E = restrição estrutural representável em schema/tipo; S = relação semântica entre
campos/registros; P = prova factual, custódia e autorização externa. Um schema não
comprova S/P só porque aceitou E. Referência a revisor, autorização ou hash é uma
declaração, não assinatura verdadeira nem prova de que algo ocorreu. Nenhum dado
dispara operação. Inspeção humana é suficiente para revisar estes contratos agora.
Qualquer futuro avaliador/serializador/parser/resolvedor pertence a B e não existe.

## 2. Dialeto e perfil estritamente local

Propor JSON Schema Draft 2020-12 para os três arquivos .schema.json: tipos fechados,
const/enum, required, oneOf e condicionais, sem vocabulário executável. Os outros
três arquivos são dados/catálogos, não schemas. Justificativa: representar variantes
e campos ausentes explicitamente sem código de julgamento.

Para conservar a restrição C4 de nenhum URL externo nos seis arquivos, o perfil
C5 propõe OMITIR $schema/$id e declarar o dialeto nos metadados de estados.json:
dialeto_schemas = DRAFT_2020_12_OFFLINE_C5. A versão aparece como const nas instâncias.
Isso é uma escolha de perfil para revisão, não comportamento autônomo padrão.
O [Core oficial](https://json-schema.org/draft/2020-12/json-schema-core) define
comportamento dependente da implementação quando $schema é omitido. Portanto um
consumidor genérico que escolha outro dialeto NÃO está autorizado a alegar compatibilidade.
Futuro consumo precisará selecionar explicitamente o dialeto offline aprovado,
sem descobrir meta-schema na rede. Não há consumidor necessário à inspeção estática.

Proibir referências entre arquivos nesta versão: tipos comuns serão repetidos
literalmente nos três schemas, a conferir na revisão. $ref somente a $defs do PRÓPRIO
arquivo, sem ciclos, $dynamicRef, $id, URI externa ou caminho .. . Não referenciar
estados.json/CSV/vetores como se fossem schemas. Referências de dados são IDs em
catálogos locais; não são instruções de abrir arquivos. Conferir manualmente que
enums/definições repetidas coincidem. Não usar format callbacks, contentEncoding,
contentSchema, código embutido ou preenchimento por default. A
[especificação Validation](https://json-schema.org/draft/2020-12/json-schema-validation)
distingue anotação/estrutura; default/readOnly não criam autorização ou proteção.

## 3. Tipos comuns e presença

Todos os objetos são fechados, sem campo desconhecido, mapa de extensão arbitrária
ou chave dinâmica privada. R = obrigatório, O = opcional. Ausência de O não implica
false, zero, sucesso ou autorização; cada O tem semântica declarada. Null só onde
expressamente permitido. Obrigatório sem valor disponível usa estado + null + motivo,
não string SEM_FONTE em campo numérico, zero ou hash inventado. Chave duplicada,
NaN/Infinity, BOM, byte inválido ou JSON truncado não é documento admitido. JSON
UTF-8 sem BOM, LF final, conforme perfil de interoperabilidade baseado no
[RFC 8259](https://www.rfc-editor.org/rfc/rfc8259). Não normalizar bytes de uma fonte
para “corrigir” hash. Enums usam as grafias exatas Unicode aqui propostas.
Recusar chaves duplicadas/BOM/truncamento é condição da futura leitura de bytes;
JSON Schema, depois de um parser que perdeu essa informação, não a demonstra.

| Tipo | Definição de representação proposta |
|---|---|
| ID | String ASCII de 1..64 caracteres, padrão ^[A-Z][A-Z0-9_-]{0,63}$, alias sem dado pessoal |
| CodigoSeguro | String ASCII 1..96, padrão ^[A-Z][A-Z0-9_]{0,95}$; não mensagem livre de exceção |
| Versao | Const 0.1.0-proposta-c5 nesta revisão |
| NaturezaRegistro | REGISTRO_DECLARADO ou SINTETICO_NAO_EXECUTADO; o primeiro também não prova veracidade |
| Seq | Inteiro 1..9007199254740991; zero não é sequência ausente |
| Contagem | Inteiro 0..9007199254740991, sem float/coerção de string |
| Win | WIN-01..WIN-19, enum exato sem faixas inferidas por consumidor |
| Subcaso | Enum de 21 valores no contrato cobertura; não nodeid |
| Eixo | FUNCIONAL, NATIVO, DACL ou CONTEXTO; CONTEXTO não é eixo de aprovação |
| SHA | 64 caracteres hexadecimais minúsculos; declaração de hash, não cálculo ou atestado |
| Tempo | String UTC no formato textual YYYY-MM-DDTHH:MM:SSZ ou null; calendário/veracidade exigem revisão semântica |
| ListaRefs | Lista de IDs sem duplicatas, vazia permitida quando não há evidência; não resolve rede/arquivos |

Os comprimentos de ID/código e faixas numéricas são opções de REPRESENTAÇÃO para
revisão, não capacidade do ambiente, orçamento, quantidade máxima de eventos ou
prazo. Não inventar timeout, retenção, orçamento de I/O ou número de tentativas.
Limites de bytes totais, eventos/mensagens/resultados e buffers: PARA_REVISÃO,
sem valor numérico ativo neste perfil. Não apresentar arquivo estruturalmente aceito
como seguro para consumo ilimitado em runtime. A precisa apenas de inspeção estática.
Arrays são finitos por representação JSON, sem maxItems operacional genérico;
cardinalidades de cobertura 21/19 e dos modelos históricos decorrem do escopo.

## 4. Objetos comuns, sem campos implícitos

**HashDeclarado** (todos R): estado = NAO_DISPONIVEL, DECLARADO, CONFERIDO_DOCUMENTALMENTE,
DIVERGENTE ou FABRICADO_PARA_ILUSTRACAO; sha256 = SHA|null; fonte_ref = ID|null;
revisao_ref = ID|null. NAO_DISPONIVEL exige três null. DECLARADO exige hash e fonte,
revisão null. CONFERIDO_DOCUMENTALMENTE exige hash/fonte/revisão; a realidade da revisão
é P. DIVERGENTE exige fonte e revisão, hash pode faltar se não foi possível obtê-lo.
FABRICADO exige natureza sintética do objeto ancestral, hash ilustrativo e fonte de
modelo; revisão null. Proibido rotular hash fabricado como conferido. E/S/P separados.

**Observacao** (todos R): estado = OBSERVADO, NAO_OBSERVADO, NAO_DISPONIVEL ou
NAO_OBSERVAVEL; tipo = BOOLEANO, INTEIRO, CODIGO_WIN32, NTSTATUS_HEX, CODIGO_APLICACAO,
ROTULO ou AUSENTE; valor = tipo correspondente|null; motivo = CodigoSeguro|null;
origem = PRODUTO, HELPER, CLI, DOCUMENTO ou NAO_DISPONIVEL; evidencia_refs = ListaRefs.
OBSERVADO exige valor não nulo e origem; boolean não é inteiro. CODIGO_WIN32 é
inteiro 0..4294967295, NTSTATUS_HEX é texto 0x e oito hexadecimais maiúsculos;
INTEIRO tem magnitude até 9007199254740991, demais rótulos são CodigoSeguro. Não
inferir erro nativo de código app ou de nome do cenário. Ausente exige tipo AUSENTE,
valor null, motivo não nulo e origem NAO_DISPONIVEL. OBSERVADO só declara observação; sem prova não autoriza
PASS. ROTULO não é canal livre para path/segredo. Motivo de observação presente é
null ou código seguro de ressalva; conteúdo privado fica fora, não em raw embutido.

**Esperado** (todos R): estado = DEFINIDO ou NAO_DEFINIDO; tipo/valor iguais à tipagem
acima, fonte_ref = ID|null. DEFINIDO exige fonte e valor; NAO_DEFINIDO exige AUSENTE,
null e fonte null. Não usa OBSERVADO e não substitui Observacao. Igualdade entre esperado
e observado não é cálculo/julgamento feito pelo contrato.

**FalhaSegura** (todos R): fase = enum de etapas do evento; codigo_seguro = CodigoSeguro;
camada = PREPARACAO, PRODUTO, HELPER, OBSERVADOR, TRANSPORTE, CLI ou CLEANUP;
codigo_original = Observacao; evidencia_refs = ListaRefs. Primeiro erro é null ou
esse objeto; erros adicionais são lista do mesmo tipo. Campo seguro não contém
str(exc), stack, locals, host, SID ou documento.

**CustodiaRef** (todos R): estado = NAO_DEFINIDA, DECLARADA, REVISAO_DOCUMENTAL ou
INCOMPLETA; registro_ref = ID|null; integridade = HashDeclarado. NAO_DEFINIDA exige
registro null; DECLARADA/REVISAO_DOCUMENTAL exigem registro, INCOMPLETA permite null.
Ler um ID/hash não comprova responsável, localização ou retenção; isso é P privada.
Não incluir prazo nem caminho. Dado desconhecido continua explicitamente desconhecido.

## 5. Compatibilidade e segurança

Versão exata, sem migração/coerção silenciosa. Cada nova versão exige revisão e novo
manifesto; nem versão minor promete compatibilidade se objetos são fechados. Mudança
de enum, significado, presença, limites ou campos exige nova versão, sem reescrever
fonte antiga. Consumidor futuro que desconheça versão/campo/enum recusa a interpretação,
sem ignorar e produzir verde. Nenhum nome de arquivo dispara ação ou resolve endereço.

Unicidade por ID, igualdade dinâmica de hashes/campos, integridade de sequência,
referência cruzada e veracidade NÃO são garantidas por JSON Schema básico. uniqueItems
não assegura unicidade de uma chave em objetos diferentes. Essas regras S/P estão
explicitadas para revisão documental e eventual implementação B autorizada à parte.
Não afirmar que materializar A já as verifica.

Dados permitidos: aliases, enums, códigos seguros, booleanos, contagens, referências
e hashes não secretos aprovados. Proibidos: handles, ponteiros, credenciais, CPF/CNPJ,
valores financeiros privados, bytes raw, paths reais, URLs externas ou metadados de
conta/host. Um ID com regex válida ainda pode esconder dado pessoal: revisão humana
é indispensável. Por isso validade estrutural, privacidade, verdade e autorização
são verificações distintas. Campos hash/referência/código são potencialmente sensíveis.

## 6. Decisões para o revisor

Aceitar/rever versão/dialeto offline sem $schema, repetição local dos tipos, campos
fechados, representação da ausência, taxonomias, limites só estruturais e falta de
portabilidade implícita para consumidor genérico. Nenhuma dessas decisões está aprovada
pelo simples texto. A C5 propõe os seis contratos como ESPECIFICADO documentalmente,
sem criar A, sem B ou validação. Limites operacionais permanecem PARA_REVISÃO.
