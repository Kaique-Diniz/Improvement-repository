# C5-C — estados.json, catálogo proposto

19/11/2026. **ESPECIFICADO documentalmente; NÃO CRIADO.** Estados são dados e não
máquina executável. Base comum é normativa nesta proposta. Nenhuma transição tem
callback, ação, condição em código ou comando associado.

## 1. Ficha de campos do catálogo futuro

Todos R e fechados: versao_contrato = Versao; natureza_catalogo = PROPOSTA_DECLARATIVA;
dialeto_schemas = DRAFT_2020_12_OFFLINE_C5; taxonomias = objeto com as chaves exatas
da tabela abaixo; etapas_origem e tipos_evento = listas exatas do contrato evento;
transicoes_documentais = lista de Transicao; marco_C5 = Marco; referencias_documentais
= lista de ReferenciaEditorial. Sem null na raiz. Listas de enum não vazias, únicas,
sem alteração silenciosa de grafia/ordem na mesma versão.

**Transicao** (todos R): transicao_id ID, dimensao = uma chave da tabela; origem/destino
= valores dessa mesma taxonomia; fundamento = DOCUMENTO_REVISAO, REGISTRO_AUTORIZACAO,
EVIDENCIA_EXECUCAO, CORRECAO_RASTREAVEL ou REGISTRO_CUSTODIA; referencia_regra = ID;
efeito = NENHUM. Não contém expressão a avaliar nem dispara transição de outro eixo.

**ReferenciaEditorial** (todos R): referencia_id ID, classe = DOCUMENTO_REFERENCIA ou
MODELO_SINTETICO; integridade HashDeclarado; versao_rotulo ID|null. Não abre caminho,
calcula hash ou confere fonte. Unicidade de referencia_id é S, não uniqueItems só.

**Marco** (todos R): desenho_tecnico = objeto fechado T01/T06 ESPECIFICADO, T02
BLOQUEADO, T03/T04/T05/T07 PARCIAL; runner = NÃO_IMPLEMENTADO; testes = PENDENTE;
prontidao_para_executar = false; controles = lista de 19 pares Win/NÃO_VALIDADO;
vinculos_historicos = PROVISORIO_SEM_FONTE; dacl = NÃO_VALIDADO; politica_dacl =
PARA_APROVAÇÃO; portoes = objeto C/D/E BLOQUEADOS; conversoes_reais = BLOQUEADAS.
Marco é declaração documental DA C5, não configuração de execução ou default para
preencher relatórios. Mudá-lo requer versão/revisão, não ação do catálogo.
Cada par em controles é objeto fechado com controle_win (Win) e estado (const
NÃO_VALIDADO), ambos R; o conjunto deve conter exatamente os 19 Win, sem duplicação.

## 2. Taxonomias distintas

| Dimensão | Valores fechados propostos | Por que separada |
|---|---|---|
| desenho | ESPECIFICADO, PARCIAL, BLOQUEADO | Texto revisável não equivale a implementação |
| implementacao | NÃO_IMPLEMENTADO, IMPLEMENTACAO_DECLARADA, IMPLEMENTACAO_REVISADA_DOCUMENTALMENTE | Estado de fonte/revisão, não teste |
| autorizacao | PENDENTE, AUTORIZADA_DECLARADA, NEGADA, REVOGADA | Declaração precisa de fonte/escopo; não executa nada |
| execucao | NAO_INICIADA, PREPARACAO_DECLARADA, EM_ANDAMENTO_DECLARADO, ENCERRADA_DECLARADA, BLOQUEADA, INTERROMPIDA, TIMEOUT, CRASH, INCONCLUSIVA | Não descreve sucesso do controle |
| resultado_ensaio | NAO_EXECUTADO, PASS, FAIL, SKIP, BLOQUEADO, INCONCLUSIVO | PASS/FAIL/SKIP exigem contexto futuro ou exemplo explicitamente sintético |
| resultado_funcional | NÃO_VALIDADO, APROVADO, FALHOU | Não altera nativo/DACL |
| resultado_nativo | NÃO_VALIDADO, APROVADO, FALHOU | Origem/capacidade nativa precisam de prova própria |
| resultado_dacl | NÃO_VALIDADO, APROVADO, FALHOU | Aprovação requer política, execução e autorização D separadas |
| custodia | NAO_DEFINIDA, DECLARADA, REVISAO_DOCUMENTAL, INCOMPLETA | Hash não concede custódia |
| integridade | NAO_DISPONIVEL, DECLARADO, CONFERIDO_DOCUMENTALMENTE, DIVERGENTE, FABRICADO_PARA_ILUSTRACAO | Último só em natureza sintética |
| cleanup | NAO_SOLICITADO, NAO_INICIADO, CONCLUSAO_DECLARADA, NAO_COMPROVADO, FALHOU, RESIDUO_PRESERVADO | Nenhum valor significa segurança ou PASS |
| sentinelas | NAO_OBSERVADAS, PRESERVACAO_DECLARADA, DIVERGENCIA_DECLARADA, INCONCLUSIVAS | Estado declarado por comparação, não o mecanismo de proteção |
| vinculo_historico | PROVISORIO_SEM_FONTE | Versão C5 não confirma história por resultado prospectivo |
| revisao_historica | PENDENTE | Sem fonte primária/revisão, não promover nesta versão |

A semântica de HashDeclarado/CustodiaRef detalha nulidade conforme cada estado.
Observacao e Esperado mantêm enums próprios, não pertencem a resultado_ensaio.
PENDENTE não é sinônimo de NAO_EXECUTADO; SKIP não é sinônimo de NÃO_VALIDADO,
mas a afirmação não exercitada por skip permanece NÃO_VALIDADO.

## 3. Transições documentalmente permitidas

Cada linha é relação proposta, não regra executável. Os IDs da linha poderão ser
ROT_DESENHO_01 etc., sem campo livre. Toda mudança registra a peça anterior; não
reescrever fonte passada. O catálogo terá as relações abaixo, por origem/destino.

| Dimensão | De → para | Fundamento e limite |
|---|---|---|
| desenho | PARCIAL → ESPECIFICADO; ESPECIFICADO → PARCIAL; qualquer um desses → BLOQUEADO; BLOQUEADO → PARCIAL | Revisão com motivo; não promove implementacao/resultado |
| implementacao | NÃO_IMPLEMENTADO → IMPLEMENTACAO_DECLARADA → IMPLEMENTACAO_REVISADA_DOCUMENTALMENTE | Fonte/hashes, autorização de criação e revisão; sem execução implícita |
| autorizacao | PENDENTE → AUTORIZADA_DECLARADA ou NEGADA; AUTORIZADA_DECLARADA → REVOGADA | Registro externo explícito, escopo/versão; autorização A não vale B/C/D |
| execucao | NAO_INICIADA → PREPARACAO_DECLARADA; PREPARACAO_DECLARADA → EM_ANDAMENTO_DECLARADO ou BLOQUEADA | Só em futura execução com autorização própria e contexto; catálogo não inicia processo |
| execucao | EM_ANDAMENTO_DECLARADO → ENCERRADA_DECLARADA, INTERROMPIDA, TIMEOUT, CRASH ou INCONCLUSIVA | Evidência do estado, sem PASS implícito |
| resultado_ensaio | NAO_EXECUTADO → PASS, FAIL, SKIP, BLOQUEADO ou INCONCLUSIVO | Critérios do relatório; setup falho é BLOQUEADO, não FAIL funcional fabricado |
| cada resultado de eixo | NÃO_VALIDADO → APROVADO ou FALHOU | Fonte/revisão da afirmação e autorização adequada àquele eixo |
| custodia | NAO_DEFINIDA → DECLARADA → REVISAO_DOCUMENTAL; DECLARADA/REVISAO_DOCUMENTAL → INCOMPLETA | Registro específico, sem herdar retenção de B |
| integridade | NAO_DISPONIVEL → DECLARADO → CONFERIDO_DOCUMENTALMENTE ou DIVERGENTE | Referências de fonte/revisão; nunca inferir pela forma do hash |
| cleanup | NAO_INICIADO → CONCLUSAO_DECLARADA, NAO_COMPROVADO, FALHOU ou RESIDUO_PRESERVADO | Registro separado; não altera resultado de segurança |
| sentinelas | NAO_OBSERVADAS → PRESERVACAO_DECLARADA, DIVERGENCIA_DECLARADA ou INCONCLUSIVAS | Observação específica e comparação integral, sem aprovar DACL |

Relações ausentes não são permitidas nesta versão. Estados terminais de execução
não reiniciam no mesmo execucao_id; nova tentativa é outra identidade/contexto.
PASS/FAIL/SKIP não se reescrevem para obter verde; correção documental posterior
exige referência de retificação/revisão que preserve o registro anterior, não uma
transição SKIP→PASS. Um novo ensaio pode ter outro resultado, sem alterar o skip.
Autorização revogada não invalida ou autoriza retroativamente um run sem examinar
seu contexto histórico; nenhum comando deriva do estado atual.

## 4. Proibições de inferência e exemplo

Não há arestas desenho→implementação, implementação→validação, cleanup→segurança,
funcional→DACL, SKIP→PASS ou ausência de erro→homologação. Dimensões diferentes não
podem figurar numa mesma aresta. Conclusão de schema/serialização não é dimensão
de resultado. Interpretação de lista de transições como ações pertence a B e não
está autorizada. Marco atual permanece integralmente preservado.

Exemplo editorial SINTETICO_NAO_EXECUTADO (projeção, não arquivo completo):

| desenho | implementacao | ensaio | funcional | nativo | DACL | cleanup |
|---|---|---|---|---|---|---|
| ESPECIFICADO | NÃO_IMPLEMENTADO | NAO_EXECUTADO | NÃO_VALIDADO | NÃO_VALIDADO | NÃO_VALIDADO | NAO_INICIADO |

Outro modelo pode ilustrar ensaio PASS e funcional APROVADO, mantendo DACL
NÃO_VALIDADO. Ser sintético impede considerá-lo execução/evidência. Não há transição
ou evento que produza essa linha automaticamente. O catálogo não é prova de estado.

## 5. Revisão de segurança e inconsistências

Permitir enums/IDs e relações puras; proibir código, expressões a avaliar, hooks,
URLs, paths, credenciais e valores privados. IDs de fontes podem ser sensíveis,
portanto o alias precisa de revisão. Sem defaults, preenchimento ou executores.

E não comprova que origens/destinos, ref_rule e enum copiados são semanticamente
coerentes: conferir S documentalmente. Rejeitar relação entre dimensões, duplicata
conflitante, enum desconhecido, promoção indevida e alteração do marco disfarçada
na mesma versão. CABE AO REVISOR aceitar taxonomias, arestas e recusa de migração
silenciosa; não é aprovação técnica dos controles. B futura seria necessária para
avaliar transições em runtime, mas não para definir/inspecionar esses dados agora.
