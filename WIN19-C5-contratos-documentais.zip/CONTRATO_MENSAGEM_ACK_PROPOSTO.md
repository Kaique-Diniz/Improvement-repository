# C5-B — mensagem.schema.json e ACK, proposta documental

19/11/2026. **ESPECIFICADO documentalmente; arquivo final NÃO CRIADO.** A mensagem
representa declarações. Não envia, recebe, confirma disco, sincroniza ou reenvia.
Base comum e objetos fechados aplicam-se integralmente.

## 1. Ficha de campos

Todos R; variantes usam null onde indicado, sem omitir chave.

| Campo | Tipo | Semântica |
|---|---|---|
| versao_contrato, natureza | Versao, NaturezaRegistro | Exatamente C5 e separação de sintético |
| mensagem_id, execucao_id | ID | Identidades declaradas; únicas no conjunto admitido |
| sequencia_mensagem | Seq | Ordem das mensagens, distinta da sequência de eventos |
| tipo | REFERENCIA_EVENTO, ACK_DECLARADO ou INCIDENTE_CORRELACAO | Nenhuma variante dispara transporte |
| evento_ref | ReferenciaEvento ou null | Alvo declarado, null só em incidente sem alvo recuperável |
| mensagem_origem_ref | ID ou null | ACK referencia mensagem de origem; demais null |
| transmissao_declarada | NAO_INFORMADA, ENVIO_DECLARADO, RECEBIMENTO_DECLARADO ou INCONSISTENTE | Não é observação autenticada ou sucesso |
| correlacao | NAO_VERIFICADA, CORRESPONDENCIA_DECLARADA ou INCONSISTENTE | Nem igualdade declarada comprova gravação |
| confirmacao | AckDeclarado ou null | Somente no tipo ACK_DECLARADO |
| incidente | IncidenteCorrelacao ou null | Somente no tipo INCIDENTE_CORRELACAO |
| custodia | CustodiaRef | Registro separado da afirmação de ACK |

**ReferenciaEvento** (R): evento_id ID, sequencia_evento Seq, hash_evento HashDeclarado.
O digest se refere aos bytes UTF-8 EXATOS da representação do evento identificada
pela fonte, não a um objeto reserializado. Não definir canonicalizador/algoritmo de
serialização. Espaçamento/ordem distintos podem gerar outro hash; sem bytes de origem
não comparar por suposição. O esquema não calcula o digest.

**AckDeclarado** (R): confirmacao_id ID, mensagem_confirmada_ref ID, evento_id ID,
sequencia_evento Seq, hash_evento HashDeclarado e semantica const
RECEBIMENTO_DECLARADO_SEM_PROVA_DE_DISCO. A repetição permite confronto documental;
igualdade dinâmica não é implementada por schema. Não há campo persistido=true.

**IncidenteCorrelacao** (R): codigo = ACK_NAO_APRESENTADO, ACK_DUPLICADO,
CORRELACAO_INCONSISTENTE ou HASH_NAO_COMPARAVEL; mensagem_refs ListaRefs,
evidencia_refs ListaRefs. Sem payload raw ou reenvio. Lista vazia explicita ausência
de peça, não prova que a peça não existe em outro contexto.

## 2. Regras de variante e correlação

REFERENCIA_EVENTO exige evento_ref, confirmacao/incidente/origem null. ACK_DECLARADO
exige evento_ref/confirmacao/origem e incidente null. INCIDENTE_CORRELACAO exige
incidente, confirmacao/origem null e correlacao não pode ser CORRESPONDENCIA_DECLARADA.
Uma mensagem de referência pode estar NAO_VERIFICADA sem ACK; isso não é sucesso.

CORRESPONDENCIA_DECLARADA exige IDs/execução/sequências/digests coincidentes na peça
confirmada e na declaração de ACK. Digests ausentes NÃO são iguais por ambos serem
null; usar NAO_VERIFICADA e registrar HASH_NAO_COMPARAVEL em incidente separado.
Hash fabricado só em SINTETICO_NAO_EXECUTADO e nunca prova execução ou persistência.
Se um ACK tiver campos essenciais ausentes, não fabricar IDs: documentar o incidente
com referências disponíveis, não um ACK completo inventado.

Duplicação de ACK, mensagem ou sequência conflitante exige manter a evidência das
ocorrências e incidente; não deduplicar silenciosamente para produzir correspondência.
IDs de mensagens válidas são únicos; a evidência de duplicação pode ser registrada
em incidente com refs das peças/ocorrências, sem tornar o conjunto conflitante válido.
Não inferir ausência por timeout numérico: nenhum prazo foi aprovado neste contrato.

O ACK apenas representa declaração de recebimento correlacionável. Não prova flush,
fsync, gravação no disco, integridade futura, autorização, execução ou proteção DACL.
A prova de persistência, se algum dia existir, terá fonte/revisão independente.

## 3. Exemplo completo de mensagem sem ACK — SINTETICO_NAO_EXECUTADO

```json
{
  "versao_contrato":"0.1.0-proposta-c5",
  "natureza":"SINTETICO_NAO_EXECUTADO",
  "mensagem_id":"MSG_MODELO_01",
  "execucao_id":"RUN_MODELO_01",
  "sequencia_mensagem":1,
  "tipo":"REFERENCIA_EVENTO",
  "evento_ref":{"evento_id":"EV_MODELO_01","sequencia_evento":1,"hash_evento":{"estado":"NAO_DISPONIVEL","sha256":null,"fonte_ref":null,"revisao_ref":null}},
  "mensagem_origem_ref":null,
  "transmissao_declarada":"NAO_INFORMADA",
  "correlacao":"NAO_VERIFICADA",
  "confirmacao":null,
  "incidente":null,
  "custodia":{"estado":"NAO_DEFINIDA","registro_ref":null,"integridade":{"estado":"NAO_DISPONIVEL","sha256":null,"fonte_ref":null,"revisao_ref":null}}
}
```

Proposta ilustrativa de ACK em tabela (não instância completa): MSG_ACK_MODELO,
confirma MSG_MODELO_01/EV_MODELO_01/seq1; hashes ilustrativos iguais, explicitamente
FABRICADO_PARA_ILUSTRACAO; semantica fixa acima. Nem esse modelo pode ser contado
como recibo real. Divergência de evento_id ou hash torna a correlação inconsistente,
mesmo que ambos objetos sejam estruturalmente válidos.

## 4. Segurança, inconsistências e critérios de revisão

Permitidos aliases/seq/refs/digest não secreto; proibidos handles, endpoint, pipe,
socket, path, token, recibo privado raw e comandos. Hash/identificador de confirmação
pode ser sensível; não tratar formato como sanitização. URL não é destino de correlação.

S/P: IDs duplicados, igualdade entre objetos e custódia não são resolvidos por
JSON Schema básico. Não usar $data ou callback não padrão para simular garantia.
Falta de contexto, bytes ou prova mantém NAO_VERIFICADA; ausência não recebe ACK
implícito. Nunca emitir confirmação por preencher default ou serializar sem erro.

Rejeitar campos/versão/variantes desconhecidos, ACK sem alvo essencial, declaração
de correspondência com nulls/digests divergentes ou promessa de persistência. Permitir
incidente incompleto como dado, sem classificá-lo PASS. Revisão humana deve aceitar
campos redundantes, tratamento de conflitos e a semântica limitada do ACK.
Dependências são apenas tipos/evento/estados documentais. Transporte, escrita,
verificação dinâmica e reenvio seriam B, não implementados nem autorizados.
