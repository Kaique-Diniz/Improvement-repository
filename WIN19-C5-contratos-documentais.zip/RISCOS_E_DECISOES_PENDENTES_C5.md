# C5 — riscos e decisões humanas pendentes

19/11/2026. Seis contratos ESPECIFICADO apenas como proposta documental. Nenhum
arquivo final criado, nenhuma decisão de materialização/autorização concedida.

## 1. Decisões da proposta a aceitar ou rever

| ID | Decisão proposta | Risco/condição antes de autorizar materializar |
|---|---|---|
| D5-01 | Draft 2020-12 offline sem $schema/$id/URLs nos seis arquivos | Omissão de dialeto tem comportamento genérico dependente do consumidor; perfil explícito não é portabilidade automática. Aceitar isso ou revisar escopo, sem buscar rede |
| D5-02 | Versão exata 0.1.0-proposta-c5, campos fechados, tipos repetidos em $defs próprios | Divergência entre cópias/enums precisa de confronto documental, não ignorância de campos novos |
| D5-03 | Null + estado + motivo para ausência | Null/zero/false/SEM_FONTE não são intercambiáveis; não presumir resultado favorável |
| D5-04 | Evento sem PASS; ACK só recebimento declarado | Validade do objeto não prova observação/disco/autorização. Hash ausente não casa por null=null |
| D5-05 | Estado e resultado em taxonomias independentes | Uma aresta em dados não executa ação nem promove outro eixo; custódia/cleanup não são DACL |
| D5-06 | Report por afirmação/21casos com impedimentos e agregado sem PASS | Identidade/refs, afirmações completas e provas são S/P, não verificados por JSON Schema básico |
| D5-07 | Limites de representação, não orçamento operacional | IDs/códigos curtos e faixas inteiras são proposta estrutural. Tamanho total/fluxo/timeout/retenção permanecem PARA_REVISÃO, sem default ativo |
| D5-08 | Sem refs entre arquivos, só $defs no próprio schema | Duplicação favorece leitura offline mas exige revisão exata dos tipos comuns. Dados de estados/vetores não são schemas |
| D5-09 | Dez vetores incluem objetos completos e projeções explicitamente editoriais | Projeção não satisfaz schema integral do alvo; não alegar teste de validação nem contar modelo como evidência |
| D5-10 | Cobertura CSV fixa21/19 e sem nodeids executáveis/históricos | A tabela descreve intenção; não prova origem do caso, seleção de testes ou execução |
| D5-11 | Aprovação futura de seis arquivos estritamente passivos | Não inclui parser/validador/serializador, scripts auxiliares, imports ou atividade B “de apoio” |

Nenhum desses pontos bloqueia escrever a presente especificação ou inspecioná-la
em texto. Sua aceitação humana é necessária antes da próxima materialização.
ESPECIFICADO não quer dizer ACEITO, CRIADO, ESTRUTURALMENTE_VALIDADO ou VERDADEIRO.

## 2. Limites de expressividade e prova

Schemas podem restringir chaves/tipos/enums/variantes. Não comprovam que ID existe
em outro registro, hash foi calculado sobre os bytes certos, autorização é legítima,
ordem é íntegra, revisor assinou ou evento aconteceu. uniqueItems de objetos não
substitui unicidade por chave. Comparar propriedade a outra dinamicamente não é
magia de $ref. Não introduzir $data, callback ou resolvedor como atalho em A.

Referências e IDs com forma segura podem codificar dado privado. Regex não garante
sanitização. Campos código/hash/custódia/autorização/revisão precisam de revisão
humana e regra de privacidade. Dados raw, paths, segredos e documentos não fazem
parte dos seis artefatos. Mesmo hash de segredo ou valor de baixa entropia é proibido.

Um contrato fechado pode recusar documento novo legítimo; a resposta é nova versão
revisada, não coerção/downgrade ou mudança silenciosa para aceitar verde. Limites
operacionais não definidos significam que consumir isso em runtime ainda exige B,
perfil e autorização; não significam capacidade ilimitada ou default herdado de C3.

## 3. Guardas de resultado

PASS/FAIL/SKIP em registro futuro real dependem de evento/contexto/prova adequados;
falha de preparação antes do alvo não é FAIL funcional. SKIP mantém o eixo não
exercitado NÃO_VALIDADO. Valor zero/true/sem exceção, sucesso de serialização ou
cleanup concluído não autorizam aprovação. Resultado funcional não aprova DACL.

Ramo de erro nativo WIN-03 fica BLOQUEADO, embora comparação Unicode possa ter outra
subafirmação. Não remover ramo ou caso do denominador. WIN-18/19 são protocolos DACL
bloqueados; chmod e sharing violation não substituem prova D. Relatório com 20 casos
não vira cobertura completa. Historicamente os 19 vínculos continuam provisórios,
revisor PENDENTE e sete skips aguardam fonte primária, sem inferência por nome.

Modelos todos SINTETICO_NAO_EXECUTADO podem ilustrar PASS, mas nunca comprovar run,
autorização ou fonte primária. Hash fabricado mantém rótulo; projeção permanece
projeção. Nenhum vetor foi executado nem analisado por parser/validador nesta C5.

## 4. Dependências abertas que NÃO pertencem a A

T01/T06 seguem ESPECIFICADO; T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL. Observer,
transporte/ACK real, bootstrap, DLLs/imports, identidade nativa/ABI, snapshot,
processos, CLI, julgamento runtime, cancelamento/cleanup continuam B, inexistentes
ou não autorizados. Definir seus dados não implementa esses mecanismos.

Prontidão false, autorização de testes PENDENTE, runner NÃO_IMPLEMENTADO,
WIN01–WIN19 e DACL NÃO_VALIDADO, D01–D10 PARA_APROVAÇÃO; C/D/E e conversões reais
BLOQUEADOS. Portão B encerrado, autorização consumida. Nenhum runtime tem permissão
por receber campo AUTORIZADA_DECLARADA sem documento externo específico e revisão.

## 5. Sequência de decisões e parada

Primeiro revisar a C5 e semântica concreta proposta. Depois, se desejado, autorizar
EXATAMENTE os seis arquivos declarativos em tarefa nova; a autorização não foi dada
aqui. Inspeção dos seis bytes produzidos será posterior. Validar por runtime,
implementar B e executar ensaios são decisões separadas. Não solicitar desbloqueio
automático nem corrigir o produto/candidata para satisfazer o modelo.

Não criar ZIP/publicar nesta tarefa. Sem Git, instalação, configuração, ACL, contas,
privilégios, coleta Windows ou conversões. A verificação de hash dos documentos
novos é integridade documental, não homologação. Entregar e parar para revisão.
