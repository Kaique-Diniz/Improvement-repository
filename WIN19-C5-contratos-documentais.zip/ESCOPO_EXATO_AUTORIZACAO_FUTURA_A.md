# C5 — escopo exato de eventual autorização futura A

19/11/2026. **PROPOSTA. AUTORIZAÇÃO NÃO CONCEDIDA.** Este documento não permite
materializar os arquivos. A C5 atual entrega só as definições em Markdown/matrizes.

## 1. Lista exclusiva para uma decisão posterior

Todos em pasta externa nova, sem Git/candidata e sem sobrescrita. Nenhum caminho foi
criado nesta C5. Versão proposta 0.1.0-proposta-c5, sujeita ao parecer independente.

| Caminho futuro exato | Conteúdo permitido e documento de origem | Proibições específicas |
|---|---|---|
| contratos_c/evento.schema.json | Tipos/variantes de evento da BASE e CONTRATO_EVENTO_PROPOSTO.md, objetos fechados e defs locais | PASS implícito, dados reais, código, handles/ponteiros, persistence implementada |
| contratos_c/mensagem.schema.json | Mensagens/ACK declarativos da BASE e CONTRATO_MENSAGEM_ACK_PROPOSTO.md | Transporte, endpoint, sync/reenvio, hash calculado, promessa de disco |
| contratos_c/estados.json | Taxonomias, relações e marco C5 de CONTRATO_ESTADOS_PROPOSTO.md | Ação por transição, callback, função, promoção entre dimensões |
| contratos_c/relatorio.schema.json | Campos/variantes do CONTRATO_RELATORIO_PROPOSTO.md, sem agregado de homologação | Julgador, parser/serializer/validator, evidência factual ou execução |
| contratos_c/cobertura_21.csv | Exatamente 21linhas/19IDs/14colunas da proposta de cobertura | Nodeid histórico inventado, seletor de pytest, resultado observado ou exclusão de ramo bloqueado |
| contratos_c/vetores_de_contrato.json | Dez modelos tipados de CONTRATO_VETORES_SINTETICOS_PROPOSTO.md, todos SINTETICO_NAO_EXECUTADO | Fixture/teste/script/gerador, modelo como fonte primária, dado privado ou comando |

A base comum define dialeto offline, versão, refs locais e compatibilidade. Sem
$schema/$id/URL externo nos seis arquivos, sem ref entre arquivos; só $defs internos
acíclicos, sem resolve/rede. Essa escolha precisa ser aceita na autorização, sem
supor que consumidor genérico adote o dialeto certo. Nenhum script de apoio pertence
à lista, mesmo que alegue apenas conferir os dados.

## 2. Pré-condições da futura decisão

Aceite específico do conteúdo, campos, enumerações, presença/nulidade, relações S/P,
limites estruturais, projeções dos vetores e itens D5-01..11. Local externo novo e
procedimento de preservação definidos. O escopo deve dizer se permite documentação
auxiliar/manifesto junto dos seis arquivos; não incluir outros artefatos ativos.

A eventual materialização não deve executar Python, pytest, PowerShell, imports,
validadores, exemplos, transporte, filesystem de laboratório, callbacks ou geração
automática de código. Escrita dos seis arquivos e documentação de integridade não
se confunde com implementação de efeitos descritos. Inspeção textual/hash é diferente
de chamar parser/validador; qualquer verificação executável precisaria de autorização
própria, não implícita em “criar os seis arquivos”.

Não instalar dependências, mudar configuração ou repositório, criar worktree, alterar
candidata R1-FIX 470/base 770d062d29c4361d6932592883df9339bb4089bc, DACL, privilégios,
contas, W14P, leitor ou regra de negócio. Não recuperar dados privados Windows,
repetir B, converter realmente, commit/push/merge/publicar. Transferência futura de
pacote, se necessária, tem escopo próprio e não integra autorização de A.

## 3. Evidência exigida após uma eventual criação autorizada

Entregar seis arquivos legíveis como dados, manifesto de tamanho/SHA, origem de cada
definição, diferenças frente à C5 aceita e limitações sem alegar validação runtime.
Comparar a lista exata, nomes e natureza sintética dos exemplos. Manter objetos
fechados, sem defaults ou resoluções implícitas. Revisor poderá inspecionar sem importar
módulos. Aceitação dos seis bytes ainda não implementa B ou autoriza ensaios C/D.

Mudança necessária de campo/dialeto/enums ou inclusão de outro arquivo requer nova
revisão da proposta, não ajuste silencioso. Nenhum campo AUTORIZADA_DECLARADA pode
substituir o registro externo de autorização real. Não iniciar a próxima tarefa
por meio desse documento. Parar após a presente entrega documental C5.
