# C5-A — evento.schema.json, contrato proposto

19/11/2026. Decisão proposta: **ESPECIFICADO documentalmente**. Arquivo final NÃO
CRIADO. Aplica-se BASE_COMUM_E_VERSIONAMENTO_C5.md; esta é especificação, não schema.
Evento registra observação declarada, não julgamento, autorização ou prova automática.

## 1. Ficha de campos da instância futura

Todos os campos abaixo são R. Null somente onde indicado. Objetos comuns e limites
são os da base. Campos desconhecidos são recusados.

| Campo | Tipo/limite | Semântica |
|---|---|---|
| versao_contrato | Versao | Exatamente a revisão proposta |
| natureza | NaturezaRegistro | Sintético nunca se mistura a evidência de execução real |
| evento_id | ID | Único no catálogo da sessão; não gerado pelo contrato |
| execucao_id | ID | Sessão lógica, não prova que houve execução |
| sequencia | Seq | Ordem declarada por sessão, não cronologia autenticada |
| tipo_evento | INICIO, PRECONDICAO, CAPACIDADE, OBSERVACAO, FALHA_PREPARACAO, INTERRUPCAO, FALHA_PERSISTENCIA, CUSTODIA ou ENCERRAMENTO | Não há tipo que promova resultado automaticamente |
| etapa_origem | PREPARACAO, REFERENCIAS, POSITIVO, ADVERSARIAL, OPERACAO, COMPARACAO, PERSISTENCIA, ENCERRAMENTO ou CUSTODIA | Rótulo da origem, não comando |
| controle_win | Win ou null | Null só em evento CONTEXTO sem alvo de controle |
| subcaso_id | Subcaso ou null | Relação fixa WIN/subcaso no contrato cobertura |
| afirmacao_id | ID ou null | Identifica a subafirmação; null só em CONTEXTO |
| eixo | Eixo | CONTEXTO não resulta em aprovação de segurança |
| instante_utc | Tempo | Null se não disponível; não inventar instante |
| motivo_instante | CodigoSeguro ou null | Obrigatório não nulo se instante null; null quando instante informado |
| observado | Observacao | Estado/tipo/valor/motivo/origem/refs, separados do esperado |
| esperado | Esperado | Não é resultado observado |
| completude_observacao | DISPONIVEL_DECLARADA, INCOMPLETA ou NAO_INICIADA | Não significa integridade factual ou persistência |
| lacunas | Lista de CodigoSeguro distintos | Vazia só quando não há lacuna declarada; não prova ausência real |
| primeira_falha | FalhaSegura ou null | Primeira causa conhecida, sem str(exc) privado |
| falhas_adicionais | Lista de FalhaSegura | Nunca substitui a primeira falha |
| persistencia_registro | NAO_ALEGADA, NAO_DEMONSTRADA ou FALHA_DECLARADA | Nenhum valor significa gravação durável comprovada |
| integridade_referencia | HashDeclarado | Refere outra peça/registro, nunca hash de si mesmo |
| custodia | CustodiaRef | Referência declarada, sem path ou responsável concreto |

## 2. Regras E/S/P e ausência

E: estado ausente em Observacao exige tipo AUSENTE, valor null e motivo; campos
obrigatórios não desaparecem. DISPONIVEL_DECLARADA exige observado. FALHA_PERSISTENCIA
exige persistencia_registro=FALHA_DECLARADA, primeira_falha na camada OBSERVADOR ou
TRANSPORTE e completude INCOMPLETA. Esse evento pode ser relato posterior/por canal
alternativo: sua existência não prova que o canal de persistência que falhou o gravou.

S: ordem/ID único, referências locais existentes, WIN/subcaso correto e preservação
da primeira falha são relações a revisar. Sem fonte de ordem não reconstruir o
passado. O contrato descreve ordem declarada; não implementa journal/ACK ou identifica
perda de evento sozinho. Se nem relato posterior existir, ausência continua ausência.

P: código “observado” e hash informado podem ser falsos. Falta de evidência primária
ou custódia impede promover resultado. Não incluir campo PASS/FAIL/SKIP no evento.
Um retorno booleano true ou inteiro zero não é PASS implícito. Null de falha também
não é sucesso. Eventos completos estruturalmente podem conter observação ausente;
nesse caso completude é INCOMPLETA, sem julgar controle.

## 3. Exemplo documental completo — SINTETICO_NAO_EXECUTADO

Proposta fabricada, não arquivo/fixture. EVI_MODELO_01 e REGRA_MODELO_01 são aliases
de modelo no catálogo editorial dos vetores, não evidências reais.
O boolean true abaixo é um indicador fabricado de modelo, não o valor da flag
autoriza_acesso do produto nem uma autorização; não reinterpretá-lo como tal.

```json
{
  "versao_contrato": "0.1.0-proposta-c5",
  "natureza": "SINTETICO_NAO_EXECUTADO",
  "evento_id": "EV_MODELO_01",
  "execucao_id": "RUN_MODELO_01",
  "sequencia": 1,
  "tipo_evento": "OBSERVACAO",
  "etapa_origem": "OPERACAO",
  "controle_win": "WIN-01",
  "subcaso_id": "WIN-01",
  "afirmacao_id": "FLAGS_DIAGNOSTICAS",
  "eixo": "FUNCIONAL",
  "instante_utc": null,
  "motivo_instante": "MODELO_SEM_RELOGIO",
  "observado": {"estado":"OBSERVADO","tipo":"BOOLEANO","valor":true,"motivo":null,"origem":"HELPER","evidencia_refs":["EVI_MODELO_01"]},
  "esperado": {"estado":"DEFINIDO","tipo":"BOOLEANO","valor":true,"fonte_ref":"REGRA_MODELO_01"},
  "completude_observacao": "DISPONIVEL_DECLARADA",
  "lacunas": ["MODELO_SEM_EVIDENCIA_REAL"],
  "primeira_falha": null,
  "falhas_adicionais": [],
  "persistencia_registro": "NAO_ALEGADA",
  "integridade_referencia": {"estado":"NAO_DISPONIVEL","sha256":null,"fonte_ref":null,"revisao_ref":null},
  "custodia": {"estado":"NAO_DEFINIDA","registro_ref":null,"integridade":{"estado":"NAO_DISPONIVEL","sha256":null,"fonte_ref":null,"revisao_ref":null}}
}
```

Modelo ausente: substituir conceitualmente observado por estado NAO_OBSERVADO,
AUSENTE/null, motivo OBSERVACAO_AUSENTE, origem NAO_DISPONIVEL, refs vazias e
completude INCOMPLETA. Esta descrição editorial não é operação de transformação.

## 4. Segurança, inconsistências e revisão

Permitidos: aliases, enums, códigos/booleanos/contagens, referências aprovadas.
Proibidos: handles/ponteiros/paths, mensagens raw, documentos e segredos. Mesmo ID,
código e hash podem revelar dado privado; exigem revisão humana. Origem HELPER não
se converte em PRODUTO; código app não é Win32. Limite de bytes por evento continua
PARA_REVISÃO, sem fixar os 64 KiB anteriores como valor aceito.

Rejeitar falta/tipo/enum desconhecido, campo resultado=PASS, combinação de ausência
com valor preenchido, autorreferência de hash ou dado sensível. Ordenação incoerente
não será reparada silenciosamente. Inconsistência de contexto deve ficar explícita,
não rotulada observação completa. Julgar veracidade requer fonte externa, não schema.

Dependências: base comum, taxonomias e cobertura documentais; nenhuma Categoria B
para definir/revisar o contrato. Produzir/persistir eventos reais exigiria B e execução
separadamente autorizados. O revisor deve aceitar presença/nulidade, tipagem, variante
de falha de persistência e ausência de julgamento automático antes de materializar A.
