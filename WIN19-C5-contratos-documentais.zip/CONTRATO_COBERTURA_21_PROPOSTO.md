# C5-E — cobertura_21.csv, especificação documental

19/11/2026. **ESPECIFICADO documentalmente; arquivo final NÃO CRIADO.** Esta tabela
é planejamento/rastreabilidade. Não contém nodeid histórico, expressão de seleção,
comando, filename executável ou instrução de executar teste. A base C5 é aplicável.

## 1. Cabeçalho e ficha de colunas

Ordem EXATA proposta (14 colunas):

`versao_contrato;subcaso_id;controle_win;grupo;afirmacoes_previstas;eixo_funcional;eixo_nativo;eixo_dacl;estado_execucao;vinculo_historico;revisao_historica;bloqueios_previstos;fonte_planejamento_ref;natureza`

| Coluna | Tipo/presença/valor | Semântica |
|---|---|---|
| versao_contrato | R, Versao | Mesma versão dos demais contratos |
| subcaso_id | R, enum de 21 | Chave primária, não identificador de pytest |
| controle_win | R, enum Win | Relação fixa da tabela abaixo |
| grupo | R, API, LINK, MODO ou CHMOD | CHMOD é rótulo herdado, nunca proposta de prova NTFS |
| afirmacoes_previstas | R, um ou mais ID separados por pipe, sem repetição | Lista documental, ordem da tabela; não ação a executar |
| eixo_funcional/eixo_nativo/eixo_dacl | R, const NÃO_VALIDADO nas três colunas | Planejamento não contém resultados de execução |
| estado_execucao | R, const NAO_EXECUTADO | Não aceita PASS/FAIL/SKIP como resultado observado |
| vinculo_historico | R, const PROVISORIO_SEM_FONTE | Sem inferir correspondência histórica |
| revisao_historica | R, const PENDENTE | Sem assinatura humana inventada |
| bloqueios_previstos | R, códigos seguros únicos separados por pipe | Sempre AUTORIZACAO_TESTES_PENDENTE, mais os específicos |
| fonte_planejamento_ref | R, ID | Referência local a documento/matriz, nunca JUnit fictício |
| natureza | R, const PLANEJAMENTO_NAO_EXECUTADO | Não admite confusão com tabela de resultados |

Nenhum null ou campo vazio. Não usar null, zero ou célula em branco como sinônimo
de falta de fonte. A ausência histórica já tem enum explícito. Não há O nesta versão.

## 2. Conjunto fechado de 21 linhas propostas

A tabela é parte da especificação Markdown, NÃO é o arquivo CSV final. Bloqueios
listados abaixo somam-se ao comum AUTORIZACAO_TESTES_PENDENTE em todas as linhas.
Fonte editorial comum proposta: MATRIZ_C2_AUDITADA, alias que referencia os bytes da
matriz C2 no inventário; não é evidência de execução. Todas as três colunas de eixo
continuam NÃO_VALIDADO, estado NAO_EXECUTADO e vínculo/revisão provisório/PENDENTE.

| Subcaso | WIN | Grupo | afirmações previstas | Bloqueio específico adicional |
|---|---|---|---|---|
| WIN-01 | WIN-01 | API | FLAGS_DIAGNOSTICAS | T04_AMBIENTE_PENDENTE |
| WIN-02 | WIN-02 | API | ALIAS_REAL; NOMES_DISTINTOS | ALIAS_8_3_NAO_DEMONSTRADO |
| WIN-03 | WIN-03 | API | UNICODE_ORDINAL; ERRO_API_NATIVA | T02_ERRO_API_NATIVA_BLOQUEADO |
| WIN-04 | WIN-04 | API | POSITIVOS_IDENTIDADE; HARDLINK_NOME_DISTINTO | T03_IDENTIDADE_PENDENTE |
| WIN-05 | WIN-05 | API | BASELINE_SEM_AUTORIZACAO | T04_AMBIENTE_PENDENTE |
| WIN-06 | WIN-06 | LINK | LINK_REGISTRO | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-07 | WIN-07 | LINK | LINK_CHAVE | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-08 | WIN-08 | LINK | LINK_LOCK | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-09 | WIN-09 | LINK | LINK_EVIDENCIAS | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-10 | WIN-10 | LINK | LINK_CABECAS | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-11-A | WIN-11 | LINK | RAIZ_GIT | T04_AMBIENTE_PENDENTE |
| WIN-11-B | WIN-11 | LINK | ANCESTRAL_REPOSITORIO; ANCESTRAL_APP | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-12 | WIN-12 | LINK | FONTE_LINK_MESMOS_BYTES | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-13-A | WIN-13 | LINK | FONTE_LINK_INTERNA | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-13-B | WIN-13 | LINK | FONTE_LINK_EXTERNA | CAPACIDADE_SYMLINK_PENDENTE |
| WIN-14 | WIN-14 | LINK | AUTORIDADE_CORPO_RECIBO | T05_SNAPSHOT_PENDENTE |
| WIN-15 | WIN-15 | MODO | OPCAO_CANONICOS | T04_AMBIENTE_PENDENTE |
| WIN-16 | WIN-16 | MODO | CLI_DOCUMENTOS; DTO_ISOLADO | T06_DEPENDENCIAS_PENDENTES |
| WIN-17 | WIN-17 | MODO | AUDITORIA_ROUNDTRIP | T04_AMBIENTE_PENDENTE |
| WIN-18 | WIN-18 | CHMOD | PROTOCOLO_DACL_FONTE | PORTAO_D |
| WIN-19 | WIN-19 | CHMOD | PROTOCOLO_DACL_RAIZ | PORTAO_D |

As separações por ponto e vírgula na célula de Markdown são enumeração editorial;
o futuro CSV usaria pipe interno, sem transformar os subitens em outras linhas.
WIN-03 continua UM subcaso com duas afirmações; erro nativo bloqueado não some nem
vira 22º caso. WIN-11 e WIN-13 têm dois subcasos cada. Grupos: API 5, LINK 11, MODO 3,
CHMOD 2. Listar capacidade pendente não declara erro 1314 observado em novo run.
A lista de bloqueios não é completa como análise runtime: não implica prontidão
se um código específico não estiver citado. Todos dependem de revisão/autorização.

## 3. Unicidade, formato e referências

Exatamente 21 linhas de dados, 19 controle_win distintos. Chave subcaso_id única;
únicas duplicações legítimas no agrupamento controle_win são WIN-11 e WIN-13,
respectivamente A/B. Conjunto e pares obrigatórios são os da tabela. Nem chave
vazia, variante desconhecida ou WIN-11 genérico substituem WIN-11-A/B. Não inferir
nodeid histórico de rótulo ou nome do cenário. O modelo preserva procedência C2/C3/C4
como referência documental, nunca os converte em testcase executado.

UTF-8 sem BOM, separador semicolon, LF e LF final. Cabeçalho único, sem linhas de
comentário/vazias; quoting CSV convencional com aspas duplas e duplicação de aspas,
mas a gramática dos campos desta versão não admite aspas, delimitador, CR/LF, NUL
ou valor arbitrário. Não emitir fórmula de planilha; células não começam com =,+,-,@.
Pipe é exclusivo da enumeração interna, nunca operador. Não editar os bytes de CSV
anterior para se conformarem: seria um NOVO arquivo, só após autorização.

IDs de fonte devem existir no catálogo editorial local. Hash da fonte, se conhecido,
é declaração de integridade, não prova do JUnit. Refs não resolvem URL/path. Unicidade
e equivalência por coluna são S de conjunto, não propriedades garantidas por escrever
um cabeçalho ou por uniqueItems em outra estrutura JSON.

## 4. Exemplo, riscos e revisão

Exemplo editorial SINTETICO_NAO_EXECUTADO: linha WIN-03 com afirmações
UNICODE_ORDINAL|ERRO_API_NATIVA, todas as três avaliações NÃO_VALIDADO e bloqueios
AUTORIZACAO_TESTES_PENDENTE|T02_ERRO_API_NATIVA_BLOQUEADO. É proposta textual,
não linha de resultado e não seleção de testes. Uma linha com PASS em eixo_funcional
seria recusada neste artefato, mesmo se um futuro relatório contivesse PASS legítimo.

Permitidos: IDs/grupos/estados/refs de planejamento; proibidos nodeids reconstruídos,
comandos/paths, dados de cliente, nomes pessoais, credenciais e evidência raw.
Rótulos/códigos podem esconder PII e precisam de revisão humana. B futura seria
necessária para selecionar/executar/avaliar, mas nenhuma dessas funções integra A.

Rejeitar 20/22 linhas, chave duplicada, remoção de ramo bloqueado, confirmação histórica,
DACL homologada ou arquivo que represente execução como se fosse planejamento.
Revisor deve comparar conjunto/afirmações com C2 e aceitar as novas colunas como
modelo, sem promover controle. Não há dependência de runtime para revisar a tabela.
