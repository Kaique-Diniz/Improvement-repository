# C5-F — vetores_de_contrato.json, exemplos propostos

19/11/2026. **ESPECIFICADO documentalmente; arquivo final NÃO CRIADO.** Todos os
vetores terão natureza **SINTETICO_NAO_EXECUTADO**. Não são fixtures, testes, logs,
evidências observadas ou um gerador a executar. Nenhum resultado foi medido.

## 1. Ficha do catálogo futuro

Raiz fechada com campos R: versao_contrato Versao; natureza const SINTETICO_NAO_EXECUTADO;
referencias_modelo lista de ReferenciaModelo; vetores lista EXATA de dez Vetor.
ReferenciasModelo define os aliases EVI_MODELO_01, REGRA_MODELO_01 e EVI_PARCIAL_MODELO,
todos classe MODELO_SINTETICO, integridade NAO_DISPONIVEL ou FABRICADO_PARA_ILUSTRACAO,
sem bytes/paths/revisão real. Nunca PRIMARIA_EXECUCAO. Pode haver aliases adicionais
explicitamente listados abaixo para correlação, sem fonte de verdade inventada.

**ReferenciaModelo** (R): referencia_id ID; classe const MODELO_SINTETICO;
integridade HashDeclarado. Sem null na raiz. Todo alias referenciado precisa constar
no contexto editorial ou ser ID do objeto de modelo correspondente.

**Vetor** (R): vetor_id enum V01..V10; natureza const SINTETICO_NAO_EXECUTADO;
tipo_exemplo enum abaixo; exemplo objeto da variante; interpretacao const
MODELO_SEM_EVIDENCIA_REAL; expectativa_documental = ADMISSIVEL_COMO_MODELO ou
INCONCLUSIVO_COMO_EVIDENCIA; proibicao_inferencia CodigoSeguro.
Não há campo comando, callable, entrada de programa, resultado de teste executado
ou assert a avaliar. A expectativa é instrução de revisão documental, não ação.

Variantes de exemplo:

| tipo_exemplo | Objeto permitido em exemplo |
|---|---|
| EVENTO_COMPLETO | Todas as chaves/tipos do contrato evento, natureza sintética |
| MENSAGEM_COMPLETA | Todas as chaves/tipos do contrato mensagem, natureza sintética |
| AFIRMACAO_EDITORIAL | ProjecaoAfirmacao, expressamente não relatório completo |
| CAPACIDADE_EDITORIAL | controle_win e subcaso_id + campos de Capacidade do relatório + resultado_ensaio e tres eixos, todos R |
| EXECUCAO_EDITORIAL | EstadoExecucao + saidas_parciais_refs ListaRefs, sem prazo/duração |
| CLEANUP_EDITORIAL | Cleanup do relatório + resultado_funcional do eixo, sem conclusão de segurança |
| RELATORIO_EDITORIAL | casos_modelados lista não vazia de ProjecaoAfirmacao + situacao_cobertura e homologacao const NAO_CONCEDIDA_PELO_CONTRATO |

**ProjecaoAfirmacao** (todos R): controle_win Win; subcaso_id Subcaso; afirmacao_id ID;
resultado_ensaio do catálogo; funcional/nativo/DACL cada resultado de eixo;
fundamento = MODELO_SINTETICO ou NENHUM; bloqueios lista CodigoSeguro.
Seu tipo limita a interpretação: não pode ser entregue como instância completa de
relatorio.schema.json. Os objetos comuns/variantes não admitem chaves desconhecidas.

## 2. Dez propostas de vetores — todos SINTETICO_NAO_EXECUTADO

| ID/tipo | Conteúdo documental proposto | O que demonstra e o que NÃO prova |
|---|---|---|
| V01 EVENTO_COMPLETO | Instância completa mostrada no contrato evento: EV_MODELO_01, boolean true, esperado definido e lacuna MODELO_SEM_EVIDENCIA_REAL | Forma completa de evento, sem PASS ou prova de ocorrência |
| V02 EVENTO_COMPLETO | Mesmo conjunto obrigatório de campos, EV_MODELO_02/seq2, observado NAO_OBSERVADO/AUSENTE/null, motivo OBSERVACAO_AUSENTE/origem NAO_DISPONIVEL/refs vazias; completude INCOMPLETA | Ausência explícita não é false/zero nem aprovação |
| V03 AFIRMACAO_EDITORIAL | WIN-01/FLAGS_DIAGNOSTICAS, ensaio PASS, funcional APROVADO, nativo/DACL NÃO_VALIDADO, fundamento MODELO_SINTETICO, bloqueio MODELO_SEM_EVIDENCIA_REAL | Favorável funcional ilustrativo não aprova DACL nem run real |
| V04 AFIRMACAO_EDITORIAL | WIN-03/ERRO_API_NATIVA, ensaio BLOQUEADO, tres eixos NÃO_VALIDADO, fundamento NENHUM e bloqueio T02_ERRO_API_NATIVA_BLOQUEADO | Ramo nativo continua sem prova; NUL/mock não o preenchem |
| V05 EVENTO_COMPLETO | EV_MODELO_05/seq5, FALHA_PREPARACAO/PREPARACAO, observado CODIGO_APLICACAO/FIXTURE_MODELO_INVALIDA, primeira_falha camada PREPARACAO e código original declarado sintético; completo nos campos, observação INCOMPLETA | Setup falho não é FAIL funcional ou rejeição segura do produto |
| V06 CAPACIDADE_EDITORIAL | WIN-06/WIN-06, capacidade INDISPONIVEL_DECLARADA, observado CODIGO_WIN32/1314 de HELPER e ref EVI_MODELO_01, ensaio SKIP, tres eixos NÃO_VALIDADO | Código 1314 é fabricado no modelo; não nova execução Windows ou capacidade medida |
| V07 EXECUCAO_EDITORIAL | Estado TIMEOUT, interrupção TIMEOUT/OPERACAO, encerramento_comprovado=null, saídas parciais EVI_PARCIAL_MODELO, primeira_falha pode ser null com lacuna de fonte | Timeout sem duração/orçamento inventado, evidência incompleta sem PASS |
| V08 CLEANUP_EDITORIAL | Estado FALHOU, remocao_comprovada=false, residuo_preservado=true, ref EVI_PARCIAL_MODELO; resultado funcional NÃO_VALIDADO | Resíduo preservado e limpeza falha não somem num agregado favorável |
| V09 MENSAGEM_COMPLETA | Mensagem integral do contrato ACK: MSG_MODELO_01, evento de modelo, hash indisponível, confirmacao=null e correlacao NAO_VERIFICADA | Ausência de ACK comprovado não é recebimento ou disco confirmado |
| V10 RELATORIO_EDITORIAL | Três projeções: V03 favorável funcional; V04 ramo bloqueado; WIN-18/PROTOCOLO_DACL_FONTE BLOQUEADO/tres eixos NÃO_VALIDADO/NENHUM/PORTAO_D; situação PARCIAL, homologação não concedida | Resultados independentes permanecem visíveis; projeção não contém os 21 casos e NÃO é relatório completo válido |

EV_MODELO_02 mantém campos de contexto do exemplo V01, integridade/custódia não
comprovadas, esperado NAO_DEFINIDO/AUSENTE/null/fonte null e lacuna OBSERVACAO_AUSENTE.
EV_MODELO_05 usa o mesmo conjunto de chaves, falhas_adicionais vazias, persistência
NAO_ALEGADA e tempo null/motivo MODELO_SEM_RELOGIO. Sua FalhaSegura tem fase
PREPARACAO, codigo_seguro FIXTURE_MODELO_INVALIDA, camada PREPARACAO,
codigo_original igual à Observacao sintética e evidencia_refs de modelo. Não traz
API nativa, traceback, documento, identificador de conta ou caminho.
Seu esperado é NAO_DEFINIDO/AUSENTE/null/fonte null; não se compara erro de setup
a um resultado funcional esperado para simular que o produto foi exercitado.

Essas relações editoriais definem exemplos, não um operador de merge/instrução de
transformação no futuro JSON. Na eventual materialização autorizada, objetos do tipo
COMPLETO terão todas as chaves explicitamente, sem expressão “copiar V01”, referência
remota ou callback. Projeções permanecerão tipadas como editoriais, não se completarão
por default nem poderão ser contadas como relatório de execução.

## 3. Exemplo de uma projeção integral — não relatório integral

```json
{
  "vetor_id":"V04",
  "natureza":"SINTETICO_NAO_EXECUTADO",
  "tipo_exemplo":"AFIRMACAO_EDITORIAL",
  "exemplo":{
    "controle_win":"WIN-03",
    "subcaso_id":"WIN-03",
    "afirmacao_id":"ERRO_API_NATIVA",
    "resultado_ensaio":"BLOQUEADO",
    "funcional":"NÃO_VALIDADO",
    "nativo":"NÃO_VALIDADO",
    "DACL":"NÃO_VALIDADO",
    "fundamento":"NENHUM",
    "bloqueios":["T02_ERRO_API_NATIVA_BLOQUEADO"]
  },
  "interpretacao":"MODELO_SEM_EVIDENCIA_REAL",
  "expectativa_documental":"INCONCLUSIVO_COMO_EVIDENCIA",
  "proibicao_inferencia":"NAO_PROMOVER_RAMO_NATIVO"
}
```

Exemplo estático para leitura humana; não foi analisado por parser ou validado.
Vetores V01/V02/V05/V09 completos podem ser ADMISSIVEL_COMO_MODELO; os demais
podem ser assim admitidos como projeções, mas todos são INCONCLUSIVOS como evidência
real. Os dois rótulos de expectativa não são PASS de teste nem validação factual.

## 4. Segurança, limites e revisão

Permitidos apenas aliases fabricados, enums/booleanos/códigos de modelo e refs sem
conteúdo privado. Proibidos nomes de pessoa/cliente/conta, CPF/CNPJ, valores privados,
paths reais, URLs, segredos, ponteiros/handles ou payload executável. SHA fabricado,
se usado em variante de ACK, será rotulado e não corresponderá a cálculo afirmado;
V09 usa null para evitar confusão. Não criar arquivo para conferir o exemplo.

Rejeitar natureza ausente/real, IDs V duplicados/faltantes, projeção rotulada como
relatório completo, exemplo usado como evidência primária, DACL promovida, pressuposto
de ACK ou dados proibidos. Arrays/vetores têm cardinalidade estrutural dez por esta
proposta; nenhuma capacidade/timeout/retenção operacional é inferida desse número.

Inconsistências conhecidas: projeções não satisfazem o schema integral do alvo e
não devem fingir isso; rótulo de expectativa é proposto, não resultado de validador;
fonte comum do modelo pode compartilhar erro. Revisor deve confrontar cada vetor
com tipos, taxonomias e limites e decidir se exige mais exemplos completos em versão
nova. Nenhum runtime B é necessário para inspecionar estaticamente; futuros testes,
fixtures, serializadores/validadores ou geração automática continuam fora de A.
