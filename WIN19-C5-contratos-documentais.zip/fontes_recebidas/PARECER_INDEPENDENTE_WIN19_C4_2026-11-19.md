# EXP-04 / WIN19 — Parecer independente sobre a C4 documental

**Revisão:** 19/11/2026  
**Objeto:** `WIN19-C4-documental.zip`, entrega declarada em 18/11/2026  
**Decisão:** **ACEITA NO ESCOPO DOCUMENTAL, COM RESSALVAS**. Não autoriza criação dos arquivos Categoria A, implementação dos componentes Categoria B, testes, DACL, conversões reais ou publicação.

## 1. Escopo de auditoria e integridade

Realizada inspeção estática dos bytes do ZIP, sem extrair ou executar os arquivos nele contidos, sem importar módulos do produto e sem acessar o Windows do usuário.

- SHA-256 do ZIP: `d217ad580898d415b8689f3cf6d65773f29a19f30080fdb21e046b9789af89ee`.
- Arquivo ZIP: **16 entradas**, nenhuma diretoria, um manifesto e 15 arquivos manifestados. Teste CRC do contêiner: sem erro.
- Manifesto `MANIFESTO_SHA256`: SHA-256 `82ced21c6a8ee98f4b888899abdda3c69519aaeb24f9af225e51ae320ce8053d`, igual ao fornecido pelo usuário.
- Conferência de conjuntos, tamanhos e SHA-256: **15/15 arquivos corretos**; o manifesto exclui somente o próprio manifesto, sem entradas extras.
- Entradas do ZIP: nomes relativos, sem travessia de diretório, duplicação ou symlinks identificados nos metadados do contêiner.
- `MATRIZ_C4_DECISOES_T01_T07.csv`: **7 linhas / 12 colunas**; T01/T06 `ESPECIFICADO`, T02 `BLOQUEADO`, T03/T04/T05/T07 `PARCIAL`. Todos `NÃO_IMPLEMENTADO`, `NÃO_VALIDADO`, `PENDENTE`.
- `MATRIZ_DIFERENCAS_C3_C4.csv`: **13 linhas / 8 colunas**.
- `INVENTARIO_FONTES_C4.csv`: **14 referências / 7 colunas**. Seus hashes foram cotejados com as duas fontes literais incluídas no ZIP e com os arquivos correspondentes em anexos disponíveis das rodadas C3, R2, Portão B e complementação C1/C2. **14/14 hashes correspondem** aos bytes disponíveis. Isso autentica as cópias documentais analisadas, não sua origem física na máquina Windows ou seus efeitos operacionais.
- `REFERENCIAS_OFICIAIS_C4.csv`: **36 referências documentais / 7 colunas**; o CSV expressamente não atribui hashes aos conteúdos remotos não arquivados.

## 2. Avaliação do conteúdo

**T03 — PARCIAL.** A especificação distingue `FILE_ID_INFO`, atributos e reparse, handle terminal versus ancestrais, relação pai/nome/objeto, Win32 versus NTSTATUS e limites de ABI (AMD64/LLP64) e de reutilização de IDs. A abertura relativa via `NtCreateFile` é proposta, não comprovada. Faltam binding no SDK real, prova de tratamento dos ancestrais, ownership e observação da capacidade de symlink. O contrato não autoriza operações destrutivas por mera comparação de paths.

**T04 — PARCIAL.** O perfil proposto Python `-I -S -B -X utf8`, hashes de executáveis e dependências, ambiente Git positivo e controle de imports/DLLs diferencia isolamento de bootstrap de sandbox de segurança. Ainda faltam inventário real dos binários/DLLs, origem de dependências, criação/supervisão do processo e observação independente. Não há permissão para inicializar Git ou executar Python.

**T07 — PARCIAL.** O desenho propõe Job Object exclusivo, criação suspensa, atribuição antes da retomada, herança controlada e exclusão somente após prova de titularidade do objeto e do nome. Reconhece corretamente que `CloseHandle`, timeout, PID, marcações, `File ID` ou `delete-pending` isolados não provam término nem remoção segura. Falta demonstrar binding, jobs aninhados, descendentes, objetos criados dinamicamente, relação pai/nome e limites operacionais. Os antigos 20 ciclos/100 ms/2 s continuam `PARA_REVISÃO`.

**T01/T06 — ESPECIFICADO documentalmente; T02 — BLOQUEADO; T05 — PARCIAL.** Nenhum desses estados é equivalente a teste `PASS`, implementação ou aceitação DACL. O ramo nativo de erro WIN-03 permanece uma lacuna explícita da cobertura.

## 3. Delimitação da proposta A/B/C

**Categoria A:** o documento prevê seis arquivos de dados, e **nenhum foi criado nesta entrega**:

1. `contratos_c/evento.schema.json`
2. `contratos_c/mensagem.schema.json`
3. `contratos_c/estados.json`
4. `contratos_c/relatorio.schema.json`
5. `contratos_c/cobertura_21.csv`
6. `contratos_c/vetores_de_contrato.json`

Apenas schemas, enumerações, dados de cobertura e exemplos sintéticos, sem Python, hooks, validadores runtime, callbacks, efeitos de filesystem, URLs externas ou ações disparadas por transições. A **lista é elegível para exame de autorização futura**, não autorização para produzi-la agora. O conteúdo, campos, enumerações e regras de referência ainda precisarão de revisão de versão.

**Categoria B:** dez componentes ativos propostos (supervisor, observador, bootstrap, identidade Windows, snapshots, laboratório, cancelamento, cleanup, CLI e julgamento) permanecem sem autorização e com dependências técnicas abertas.

**Categoria C:** continuam excluídos a execução dos 21 cenários, mudanças no produto/candidata, W14P, DACL, privilégios/contas, conversões reais e publicação.

## 4. Ressalvas e pendências bloqueadoras

1. **Não promover estados:** T01/T06 especificados não são implementação; T03/T04/T05/T07 parciais e T02 bloqueado impedem autorização integral de B.
2. **ABI/TOCTOU/namespace:** comprovar no futuro o comportamento real de objetos, ancestrais e nomes antes de qualquer exclusão ou acesso relevante.
3. **Bootstrap:** validar binários/SDK/DLLs do alvo e evitar chamar `-I` de isolamento de segurança contra código hostil no mesmo token.
4. **Cleanup:** definir propriedade por objeto dinâmico, tratamento de descendentes, ausência positiva e retenção de resíduo quando a identidade for incerta; não aprovar exclusão recursiva por prefixo.
5. **História:** JUnit `completa-utf8.xml`, comando, log, ambiente, versão de código e associação do manifesto de 448 com a rodada Windows ainda faltam. **19 vínculos continuam `PROVISORIO_SEM_FONTE`; 7 skips ainda não reconciliados por fonte primária.**
6. **Limite probatório:** a correspondência de 14 hashes de fontes e 15 hashes do ZIP não comprova ausência de efeitos no workspace do Codex nem execução segura no Windows. A declaração de que nenhum teste foi rodado permanece declaração do executor, não medição independente do host.

## 5. Parecer e próximo portão

**Decisão:** C4 aceita **documentalmente com ressalvas**, sem mudança de estados técnicos. A proposta **Categoria A** é suficientemente delimitada para ser submetida a uma **decisão separada, expressa e específica de autorização para produzir apenas os seis arquivos declarativos**, mediante revisão de nomes, conteúdo permitido, schema e manifestação de que nenhuma ação ativa será executada. A C4 não contém os seis arquivos; portanto, sua semântica concreta ainda não foi inspecionada.

Não autorizar nesta decisão componentes Categoria B ou qualquer execução. O mais útil em paralelo continua sendo localizar e autenticar, sob protocolo de custódia próprio e separado, o JUnit original da rodada Windows, sem reexecutar os 2.842 testes. A fonte secundária textual não substitui o XML original.

Estados preservados: `prontidao_para_executar=false`; `autorizacao_testes=PENDENTE`; `runner_C=NÃO_IMPLEMENTADO`; `WIN01–WIN19=NÃO_VALIDADO`; `DACL=NÃO_VALIDADO`; `D01–D10=PARA_APROVAÇÃO`; `C/D/E=BLOQUEADOS`; `CONVERSOES_REAIS=BLOQUEADAS`. Nenhum commit, push, merge ou publicação autorizado.
