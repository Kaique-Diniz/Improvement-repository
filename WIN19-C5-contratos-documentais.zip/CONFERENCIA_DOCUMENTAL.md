# Conferência documental C5 — 19/11/2026

Conferência de texto, contagens e hashes, sem executar conteúdo dos documentos,
parsear exemplos JSON ou validar schemas. Não é pytest, preflight ou teste de produto.

| Peça documental | Observação |
|---|---|
| Matriz de interfaces | Seis linhas/16 colunas; seis decisões ESPECIFICADO, seis NÃO_CRIADO, seis NÃO_VALIDADO e autorizações PENDENTE |
| Diferenças C4/C5 | 11 linhas/7 colunas, sem alteração de estados de T ou controles |
| Inventário local | Dez fontes/6 colunas, hashes novamente conferidos sem divergência |
| Tabela editorial de cobertura | 21 linhas/21 subcasos/19 Win; grupos5API/11LINK/3MODO/2CHMOD |
| Vetores em Markdown | Dez linhas V01..V10; tipos completos ou projeções e natureza sintética explícita |
| Base C4 | Manifesto 82ced21c6a8ee98f4b888899abdda3c69519aaeb24f9af225e51ae320ce8053d e arquivos cobertos continuam conferindo |
| Fontes inventariadas da C4 | Hashes comparados novamente sem divergência, preservando as referências anteriores |
| Seis arquivos finais/produto | Nenhum .json, cobertura_21.csv ou diretório contratos_c criado nesta entrega |
| Executáveis | Nenhum .py/.ps1/.sh/.bat/.cmd/.exe novo |
| Conteúdo compartilhável | Busca textual sem padrões de token/chave privada/CPF-CNPJ formatado/path pessoal; revisão não equivale a prova forense |

Os exemplos JSON permanecem apenas dentro de Markdown e não foram extraídos,
parseados, executados ou validados. Contar linhas/editorial não prova validade de
um arquivo final que ainda não existe. Projeções não são relatório completo.
Expectativas dos vetores são propostas, não PASS medido. A revisão de consistência
identificou explicitamente limites E/S/P e a necessidade de escolha offline do dialeto.

Foram usados utilitários de texto/arquivo/hash, edição de documentos e leitura pública
das fontes oficiais citadas. Não houve Python, pytest, PowerShell, import/produto,
validador/serializador/parser de schema, criação de A/B, fixture, instalação, nova
candidata/worktree, Git/configuração, privilégio/ACL/conta/política, coleta Windows,
conversão, limpeza histórica, commit, push, merge ou publicação. A correspondência
de hashes não atesta ausência de efeitos históricos do workspace ou comportamento
Windows. Não houve verificação operacional dos 470 arquivos nem correção retrospectiva.

O manifesto raiz registra apenas documentos efetivamente presentes, com bytes/SHA,
e exclui só a si próprio. O hash do manifesto é informado na conversa. Nenhum ZIP
novo foi produzido nesta tarefa. Arquivos anteriores foram preservados, sem reescrita.

T01/T06 ESPECIFICADO; T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL; runner NÃO_IMPLEMENTADO;
controles/DACL NÃO_VALIDADO; vínculos provisórios; C/D/E e conversões bloqueados.
A decisão de escrever os seis arquivos finais continua PENDENTE. Parar na C5.
