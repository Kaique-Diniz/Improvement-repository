# WIN19-C5 — consolidação dos contratos declarativos propostos

19/11/2026, America/Sao_Paulo. **Somente documentação.** Nenhum dos seis arquivos
finais foi criado, nenhum schema operacional, parser, serializador, validador,
fixture ou runner implementado. A proposta não concede autorização de materialização.

## 1. Decisões propostas por arquivo

| Arquivo futuro | Decisão documental C5 | O que foi definido | O que falta antes de produzir |
|---|---|---|---|
| evento.schema.json | ESPECIFICADO | Campos/variantes, ausência, observado/esperado, falha de persistência e nenhum PASS | Revisão da semântica/nulidade e perfil offline |
| mensagem.schema.json | ESPECIFICADO | Mensagens, ACK declarativo e correlação/ausência/conflito, sem prova de disco | Aceitar redundância e relações S/P, sem implementar transporte |
| estados.json | ESPECIFICADO | Taxonomias independentes, transições como dados e marco C5 preservado | Revisar enums/arestas sem ação ou promoção implícita |
| relatorio.schema.json | ESPECIFICADO | Contexto, 21casos, afirmações/eixos, fontes, cleanup/custódia e lacunas | Aceitar guardas que exigem prova externa e limites de agregado |
| cobertura_21.csv | ESPECIFICADO | 14colunas, chave, conjunto21/19 e afirmações, sem nodeids/executor | Confrontar planejamento C2 e aprovar formato sem promover histórico |
| vetores_de_contrato.json | ESPECIFICADO | Dez modelos, tipos completos/projeções e natureza sintética obrigatória | Rever conteúdo e limites de projeção, sem tratar exemplo como evidência |

ESPECIFICADO = desenho textual completo para exame, não ACEITO, CRIADO, PASS ou
VALIDADO. As seis decisões são sobre contratos A, não promoção de T03/T04/T05/T07.
Todos os seis continuam NÃO_CRIADO, NÃO_VALIDADO e autorização PENDENTE. Aceitação
independente pode exigir revisão antes de uma tarefa futura de materialização.

## 2. Decisões conjuntas e limite probatório

A base comum congela proposta 0.1.0-proposta-c5, dialeto Draft 2020-12 offline,
objetos fechados, ausência por estado/null/motivo, tipos consistentes e referências
somente internas. Sem URL/$schema/$id nos seis arquivos; dialeto explicitado no
catálogo, sem supor autodetecção por consumidor genérico. Essa escolha preserva a
restrição de dados sem URLs, mas precisa de aceite do perfil, pois a ausência de
$schema não garante comportamento uniforme. Não existe consumidor/validador agora.
Tipos comuns repetidos localmente favorecem inspeção sem resolvedor, com risco de
divergência que a revisão deverá confrontar. Não há refs entre arquivos nesta versão.

Separar E (estrutura), S (relações entre registros) e P (fato/custódia/autorização)
é obrigatório. JSON Schema não comprova hash, fonte, igualdade dinâmica, unicidade
por chave, autorização real ou que o evento ocorreu. Campo de revisão preenchido
não é assinatura verdadeira. Regex não garante ausência de PII; segurança precisa
de revisão de conteúdo. Nenhum default pode preencher PASS ou permissão.

Os eventos não têm resultado PASS/FAIL/SKIP. ACK declara recebimento/correlação, não
persistência em disco. Relatório mantém resultado por afirmação/subcaso e três eixos,
com estado de execução, preparação/interrupção, capacidade, sentinelas, cleanup,
integridade/custódia e histórico separados. Não existe agregado PASS/homologação.
Lista incompleta, NV ou bloqueio não pode sumir por resumo favorável.

Limites de representação de IDs/códigos/inteiros são opções estruturais da proposta,
não orçamento/capacidade nativa. Tamanho total, throughput, timeout, buffers, tentativas
e retenção continuam PARA_REVISÃO, sem número operacional inventado ou herança de
valores C3. Cardinalidades 21/19 e dez modelos decorrem do escopo, não do ambiente.

## 3. Cobertura, vetores e história

Cobertura mantém 21 subcasos/19 Win, grupos API5/LINK11/MODO3/CHMOD2; WIN-11-A/B e
WIN-13-A/B separados. WIN-03 possui UNICODE_ORDINAL e ERRO_API_NATIVA como afirmações,
a última explicitamente bloqueada, sem criar 22º caso ou removê-la. WIN-18/19 mantêm
PORTAO_D e nenhuma homologação. Não há nodeid histórico reconstruído ou seletor.

Os dez vetores são SINTETICO_NAO_EXECUTADO, inclusive quando ilustram PASS/FAIL/SKIP.
Os exemplos completos de evento/mensagem não são fontes de execução. Projeções
editoriais não fingem ser relatório integral com 21 casos; tipos tornam essa limitação
explícita. As expectativas de admissibilidade são propostas para revisão humana,
não resultados de parser/teste. Nenhum bloco de exemplo foi executado/validado.

19 vínculos continuam PROVISORIO_SEM_FONTE, revisor PENDENTE; sete skips históricos
aguardam fonte primária. O JUnit original, log/comando/ambiente, versão física e
associação do manifesto 448 ao run não foram recuperados ou inferidos. Não houve
coleta/cópia privada Windows, pedido de raw ou repetição do Portão B. Retenção própria
continua pendente, sem herdar automaticamente 90 dias. Nenhum exemplo confirma história.

## 4. Autorização futura A e dependências

ESCOPO_EXATO_AUTORIZACAO_FUTURA_A.md nomeia seis caminhos exclusivos e as proibições.
O documento é proposta, não autorização. Nenhum contrato precisa de B para ser
definido ou inspecionado textualmente, mas emitir eventos reais, persistir/transportar,
comparar em runtime, julgar, validar, importar ou executar cenários seria outra tarefa.
Não introduzir um “utilitário de apoio” ativo sob o rótulo passivo.

A revisão humana deve aceitar D5-01..11: dialeto offline, campos/versão, nulidade,
correlação, taxonomias, guardas, limites, refs, vetores, cobertura e fronteira A/B.
Se houver alteração, registrar versão/hash novos, sem mudança silenciosa ou execução
para produzir aparência de validação. Materialização, inspeção dos bytes futuros,
implementação B, execução C e DACL D continuam decisões separadas.

## 5. Fontes e preservação

Referência obrigatória lida: PARECER_INDEPENDENTE_WIN19_C4_2026-11-19.md, SHA
8712dddef05a9408cfeadaae8549fd3607f99197baa218e9693b71538e22db64,
que aceita C4 documental com ressalvas sem autorizar criar A/B ou testar. Instrução
C5 e parecer são copiados literalmente em fontes_recebidas/. Inventário local registra
origem/tamanho/SHA. Consultas às especificações oficiais JSON Schema/RFC 8259 foram
apenas leitura pública; links estão na base, sem arquivar páginas ou inventar hash
remoto. Não executar exemplos ou ferramentas dessas referências.

Base C4: ZIP d217ad580898d415b8689f3cf6d65773f29a19f30080fdb21e046b9789af89ee,
manifesto 82ced21c6a8ee98f4b888899abdda3c69519aaeb24f9af225e51ae320ce8053d.
Matriz C2 de planejamento referenciada tem SHA
bacea89f2b5c0e33f47d15fdd8405573d8fe2a038c7e865182f1bfceb44715fd;
não é fonte primária Windows. Candidata R1-FIX 470/base
770d062d29c4361d6932592883df9339bb4089bc preservadas; sem verificação operacional
no Windows, instalação ou modificação do produto. Hash de documento não é telemetria.

## 6. Estados obrigatórios e parada

prontidao_para_executar=false; autorizacao_testes=PENDENTE;
runner_C=NÃO_IMPLEMENTADO; WIN01–WIN19=NÃO_VALIDADO;
vinculos_historicos=PROVISORIO_SEM_FONTE;
T01/T06=ESPECIFICADO; T02=BLOQUEADO; T03/T04/T05/T07=PARCIAL;
DACL=NÃO_VALIDADO; D01–D10=PARA_APROVAÇÃO; C/D/E=BLOQUEADOS;
CONVERSOES_REAIS=BLOQUEADAS. Portão B encerrado, autorização única consumida.

Somente novos documentos externos ao Git, matrizes de revisão e integridade.
Nenhum arquivo final A, script/schema operacional/validator/runtime B, Python,
pytest, PowerShell, preflight, import/produto, teste, candidata/worktree/configuração,
dependência, privilégio/ACL/DACL/conta/política, conversão real ou publicação foi
criado/executado/alterado. Sem commit, push ou merge. Parar após C5 para revisão.
