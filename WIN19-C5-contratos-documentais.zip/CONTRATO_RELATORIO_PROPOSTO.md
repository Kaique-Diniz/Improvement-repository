# C5-D — relatorio.schema.json, proposta documental

19/11/2026. **ESPECIFICADO documentalmente; arquivo final NÃO CRIADO.** O relatório
representa declarações/evidências referenciadas por afirmação. Não julga, executa,
serializa, autoriza ou homologa. Aplica-se integralmente a base C5.

## 1. Ficha da raiz — todos R, objeto fechado

| Campo | Tipo/cardinalidade/nulidade | Semântica |
|---|---|---|
| versao_contrato, natureza | Versao, NaturezaRegistro | Sintético nunca é run real |
| relatorio_id, execucao_id | ID | Sem prova de existência/autorização por conter ID |
| versoes_referencia | Lista de ReferenciaVersao, ao menos uma | Identifica artefatos declarados e não só HEAD |
| autorizacoes | Objeto com A, B, C, D, E, cada AutorizacaoRef | Escopos independentes, não ações |
| execucao | EstadoExecucao | Interrupções/setup separados de resultado |
| casos | Lista de Caso, exatamente 21 IDs de subcaso | Mesmo não executados, omissões não desaparecem do denominador |
| evidencias | Lista de Evidencia | Primária/secundária/modelo explicitamente separadas |
| eventos_refs, mensagens_refs | ListaRefs | Referências de dados, não fonte de ACK real por si |
| historico | Historico | 19 vínculos provisórios e sete skips não reconciliados |
| cleanup | Cleanup | Estado próprio, sem impacto automático nos eixos |
| custodia | CustodiaRef | Não inferida de hash |
| lacunas | Lista de CodigoSeguro distintos | Nenhum impedimento pode ser omitido pelo resumo |
| situacao_cobertura | NAO_EXECUTADA, PARCIAL, ENCERRADA_COM_RESSALVAS ou EVIDENCIA_INSUFICIENTE | Não existe agregado PASS/APROVADO |
| efeito_autorizador | Const NENHUM | Documento não concede execução |
| homologacao | Const NAO_CONCEDIDA_PELO_CONTRATO | Relatório bem formado não homologa |
| conversoes_reais | Const BLOQUEADAS | Sem autorização operacional nesta versão |

Todas as listas são finitas; sem limite numérico operacional inventado para
quantidade de evidências/afirmações/bytes. Cardinalidade 21 e 19 é de escopo.
Nenhum campo desconhecido/exec payload, arquivo raw ou caminho é aceito.

## 2. Objetos de contexto — todas as chaves enumeradas R

**ReferenciaVersao:** referencia_id ID; classe MANIFESTO_CANDIDATA, CONTRATO_DECLARATIVO,
DEPENDENCIA ou DOCUMENTO_REFERENCIA; versao_rotulo ID|null; integridade HashDeclarado.
Sem digest não afirmar correspondência; HEAD sozinho não basta. Nenhum path.

**AutorizacaoRef:** estado = PENDENTE, AUTORIZADA_DECLARADA, NEGADA ou REVOGADA;
registro_ref ID|null; escopo = A, B, C, D ou E; versao_alvo Versao. PENDENTE/NEGADA
podem ter registro null; autorizada/revogada exigem registro. A chave do mapa deve
coincidir com escopo. Verdade, vigência e limite da autorização são P, não estrutura.
A não dá autorização de executar C, nem C dá autorização D/E.

**EstadoExecucao:** estado do catálogo; precondicoes = lista de Condicao;
interrupcoes = lista de Interrupcao; primeira_falha FalhaSegura|null;
falhas_adicionais lista de FalhaSegura; encerramento_comprovado = boolean|null.
Null é ausência de prova, true continua declaração a conferir, não dado medido pelo
contrato. Não substituir crash/timeout por conclusão sem erro.

**Condicao:** condicao_id ID; estado = SATISFEITA_DECLARADA, NAO_DEMONSTRADA ou
FALHOU; observado Observacao; evidencia_refs ListaRefs. **Interrupcao:** tipo =
SETUP, TIMEOUT, CRASH, CANCELAMENTO ou PERSISTENCIA; fase da tabela de eventos;
evidencia_refs ListaRefs; detalhe_seguro CodigoSeguro. Sem duração/limite inventado.

**Evidencia:** evidencia_id ID; classe = PRIMARIA_EXECUCAO, SECUNDARIA_RELATO,
DOCUMENTO_REFERENCIA ou MODELO_SINTETICO; origem_rotulo ID; execucao_ref ID|null;
integridade HashDeclarado; custodia CustodiaRef; revisao_ref ID|null. Modelos só em
natureza sintética. Primária exige associação declarada à execução; revisão factual
não decorre de preencher esse rótulo. Secundária não é promovida para confirmar história.

## 3. Caso e afirmações — resultados independentes

**Caso:** controle_win Win; subcaso_id Subcaso; afirmacoes lista de Afirmacao (mínimo
uma e IDs únicos); capacidade = Capacidade; sentinelas = Sentinelas; lacunas lista
de CodigoSeguro. A relação controle/subcaso e o conjunto de 21 são os da cobertura.
WIN-03 exige UNICODE_ORDINAL e ERRO_API_NATIVA em linhas distintas de afirmação.
A última fica BLOQUEADO/NÃO_VALIDADO nesta versão, mesmo se Unicode passar.
Em cada caso, o conjunto de afirmacao_id deve corresponder ao conjunto previsto
na cobertura: uma afirmação não executada fica explícita, não some por omissão.

**Capacidade:** estado = NAO_OBSERVADA, DISPONIVEL_DECLARADA ou INDISPONIVEL_DECLARADA;
observado Observacao; evidencia_refs ListaRefs. Indisponível só com origem/motivo,
não por inferência de rodada antiga. Não apagar afirmação que dependia dela.

**Sentinelas:** estado do catálogo; bytes_integrais_comparados = boolean|null;
identidade_conferida = boolean|null; evidencia_refs ListaRefs. Hash igual não
substitui comparação integral. Campo true não prova que o mecanismo a realizou.

**Afirmacao:** afirmacao_id ID; resultado_ensaio do catálogo;
funcional/nativo/DACL cada resultado do eixo; observado Observacao; esperado Esperado;
fundamento Fundamento; evidencia_refs ListaRefs; eventos_refs ListaRefs;
bloqueios lista de CodigoSeguro; revisao_ref ID|null. Todos R. Não emitir PASS só
porque observado é zero/true. Não existe campo “todos aprovados” que substitua eixos.

**Fundamento:** classe = NENHUM, MODELO_SINTETICO, EVIDENCIA_EXECUCAO_DECLARADA ou
EVIDENCIA_EXECUCAO_REVISADA; autorizacao_ref ID|null; revisao_ref ID|null;
criterio_ref ID|null. NENHUM exige três null; MODELO só em natureza sintética,
critério pode ser alias de modelo, sem autorização real; classe declarada exige
critério/autorização; revisada exige os três. Esses campos não autenticam aprovação.

## 4. Guardas semânticas contra falsa aprovação

Para REGISTRO_DECLARADO, PASS/APROVADO requer positivo/precondições satisfeitos,
capacidade relevante realmente alcançada, afirmação correspondente exercitada,
resultado confrontado com esperado, evidência de execução primária ligada ao run,
integridade/custódia/revisão e autorização específica verificadas externamente.
Fundamento deve ser EVIDENCIA_EXECUCAO_REVISADA, refs não vazias e critério/revisão
presentes. A simples marcação desses campos não substitui P. Sem esses elementos,
não se interpreta como PASS legítimo; registrar INCONCLUSIVO/BLOQUEADO e lacuna.

FAIL não precisa de resultado favorável esperado, mas exige prova da violação do
contrato alcançado. Falha de setup antes do alvo é BLOQUEADO/NAO_EXECUTADO, não
FAIL funcional disfarçado. SKIP exige capacidade indisponível/motivo referenciado;
eixos não exercitados ficam NÃO_VALIDADO. SKIP não promove a outro status.
Cleanup bem sucedido ou ausência de exceção não satisfaz qualquer guarda de segurança.

DACL APROVADO/FALHOU exigiria fonte própria e autorização D com política/objetos/
tokens aprovados, nunca funcional, chmod ou sharing. WIN-18/19 são bloqueados
nesta versão C5: resultado_ensaio=BLOQUEADO, eixos NÃO_VALIDADO e bloqueio PORTAO_D.
Isso não autoriza produzir dados de ensaio D nesta etapa. Todos os resultados
reais atuais continuam NÃO_VALIDADO fora dos modelos fabricados.

SINTETICO_NAO_EXECUTADO pode ilustrar PASS/FAIL/SKIP/APROVADO, mas fundamento é
MODELO_SINTETICO (ou NENHUM em bloqueio/ausência), evidências somente MODELO_SINTETICO, autorizações PENDENTE e nenhum
exemplo pode ser contado como run/evidência real. Não misturar naturezas em um
relatório para promover cobertura. Uma instância bem formada não é veracidade.

situacao_cobertura=PARCIAL ou ENCERRADA_COM_RESSALVAS nunca oculta BLOQUEADO,
NÃO_VALIDADO, timeout, resíduo, fonte ausente ou restrição. Na existência de falha
de evidência necessária, usar EVIDENCIA_INSUFICIENTE, sem apagar casos. Ordem de
conservadorismo documental: insuficiência de prova prevalece no resumo; depois
NAO_EXECUTADA se nenhum alvo foi exercitado; demais recortes incompletos são PARCIAL
ou ENCERRADA_COM_RESSALVAS com lacunas. Isso é semântica proposta, não rotina.

## 5. Cleanup, história e nulidade

**Cleanup:** estado do catálogo; remocao_comprovada = boolean|null;
residuo_preservado = boolean|null; evidencia_refs ListaRefs; falhas lista FalhaSegura.
CONCLUSAO_DECLARADA exige remocao_comprovada=true e residuo_preservado=false.
RESIDUO_PRESERVADO exige residuo_preservado=true e remocao_comprovada=false ou null;
remoção global true com resíduo true é inconsistente. São declarações sujeitas a prova. Tempo esgotado ou nome
inexistente por caminho não autentica remoção. Nenhum timeout/orçamento é incluído.

**Historico:** vinculos = lista exata dos 19 Win com vinculo_historico const
PROVISORIO_SEM_FONTE, revisor const PENDENTE e fonte_primaria const SEM_FONTE;
fontes_secundarias_refs ListaRefs; skips_quantidade_relatada const 7;
skips_individualizacao const PENDENTE_FONTE_PRIMARIA. O sete é relato histórico,
não contagem de skips futuros. Não preencher por semelhança de nomes ou resultados.
Novo confronto com fonte primária/revisão exigiria revisão do perfil, sem reescrever
história neste contrato congelado.

Null/ausência nunca é false/sucesso. Campo O: nenhum nesta revisão; variantes usam
null/estado nas chaves obrigatórias. Campos futuros desconhecidos são recusados,
sem migração silenciosa. Valores numéricos/IDs/refs seguem base comum.

## 6. Exemplo documental e inconsistências conhecidas

Projeção editorial SINTETICO_NAO_EXECUTADO, não relatório completo nem schema:

| Subafirmação | ensaio ilustrativo | funcional | nativo | DACL | Prova |
|---|---|---|---|---|---|
| FLAGS_DIAGNOSTICAS | PASS | APROVADO | NÃO_VALIDADO | NÃO_VALIDADO | MODELO_SINTETICO |
| ERRO_API_NATIVA | BLOQUEADO | NÃO_VALIDADO | NÃO_VALIDADO | NÃO_VALIDADO | NENHUM |
| PROTOCOLO_DACL_FONTE | BLOQUEADO | NÃO_VALIDADO | NÃO_VALIDADO | NÃO_VALIDADO | NENHUM |

O relatório completo futuro ainda conteria todos os 21 casos e as outras chaves;
a projeção não deve ser salva como instância válida. Ver vetores V03/V04/V10.

Inconsistências a rejeitar: PASS real sem prova/revisão/autorização, DACL aprovada
por resultado funcional, omissão de casos/ramo bloqueado, eixos misturados, modelo
no catálogo primário, histórico confirmado por fonte secundária ou agregado favorável
que esconda NV. Unicidade por chave, refs resolvidas, associação run/capacidade/
autorização e veracidade são S/P, não garantidas pelo schema básico. E não basta.

## 7. Segurança e critérios de revisão

Dados permitidos: resultados declarados, aliases/códigos seguros, integridade/
custódia por referência e lacunas. Proibir raw, documentos, contatos, financeiro
privado, paths, handles/ponteiros, segredos e comandos. IDs/hash/código ainda podem
ser sensíveis e exigem revisão. Nenhuma retenção herdada ou valor operacional novo.

Revisor deve conferir presença/tipos/enums, guardas por natureza/afirmação/eixo,
conjunto 21/19, limites de agregado, campos de incerteza e ausência de default/PASS.
Ordem S/P e privacidade precisam ser aceitas explicitamente. Construir avaliador,
parser, relatório executável ou fonte factual seria Categoria B/execução separada;
nenhum deles é dependência para inspecionar este contrato como documento.
