# C4-B — contrato concreto de bootstrap, não implementado

18/11/2026. Não executar esta especificação. Nenhum Python, Git, import, instalação,
configuração ou descoberta de testes foi realizado. Categoria B; T04 = PARCIAL.
A escolha do perfil torna o desenho inspecionável, não comprova seu funcionamento.

## 1. Escolha de inicialização

Proposta: supervisor externo chama executáveis absolutos aprovados sem shell; Python
usa script de bootstrap externo pelo caminho absoluto, nunca launcher py, associação
de arquivo, stdin ou código passado por string. O perfil alvo proposto é Windows
AMD64/CPython 3.12 64 bits. Não inferir arquitetura, patch ou disponibilidade sem
registro futuro autorizado. O supervisor/process creation depende de T07, não é A.

No contrato de argumentos, selecionar os modos -I (isolamento), -S (sem site
automático), -B (sem escrita de bytecode) e -X utf8; vedar -O/-OO para não remover
asserções. São parâmetros especificados, não uma linha de comando para executar.
Esses comportamentos constam da [documentação Python 3.12](https://docs.python.org/3.12/using/cmdline.html).
O modo isolado ignora PYTHON*; portanto não depender de PYTHONPATH, PYTHONUTF8 ou
PYTHONDONTWRITEBYTECODE para obter os efeitos. Não anunciar isolamento por variável
ignorada. A página consultada apresenta documentação 3.12.16, não atesta o patch do
computador do usuário ou a compatibilidade de seu ambiente.

## 2. Manifestos de ambiente exigidos

| Referência | Informação obrigatória antes de futura execução | Situação atual |
|---|---|---|
| Python | Path absoluto, SHA, patch 3.12, arquitetura, python312.dll/stdlib/extensões/runtime e arquivos de configuração | SEM_FONTE para instalação Windows aprovada |
| Git | Path absoluto, SHA, versão, git-core/DLLs e recursos efetivamente usados | SEM_FONTE para instalação Windows aprovada |
| Candidata | Manifesto 470 aprovado e hash a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c; baseline 770d062d29c4361d6932592883df9339bb4089bc | Referência documental preservada, sem inspeção operacional Windows |
| Bootstrap/runner futuros | Arquivos completos, SHA, tamanho, fonte revisada e nenhuma ação ao importar dados declarativos | NÃO_IMPLEMENTADO |
| Dependências/plugins | Arquivo, versão, diretório, hash, imports transitivos e extensões nativas | Conjunto final Windows ainda não aprovado |
| Parâmetros | Raízes externas, cwd, TEMP/TMP, saídas, limites, autorizações e custodiante | PENDENTE |

Sem ambiente exatamente aprovado, retornar bloqueio; não escolher Python global,
instalar pacote, baixar DLL ou alterar o ambiente para continuar. Um path absoluto
sem hash/origem não basta, e hash prévio não impede troca concorrente do binário.
Essa limitação deve integrar o modelo de confiança aprovado, não ser ocultada.

## 3. Ambiente por lista positiva

Construir o ambiente do filho a partir de lista explícita, não os.environ.copy.
Somente valores Windows necessários à execução, como SystemRoot/WINDIR confirmados,
mais TEMP/TMP exclusivos do laboratório e PATH mínimo aprovado. Nenhum valor é
obtido de variável arbitrária sem validação. Não redefinir HOME nem opções globais.
Não transmitir tokens, credenciais, proxies autenticados ou variáveis do usuário.

No processo Git, detectar e RECUSAR qualquer GIT_* herdada não aprovada, em vez de
normalizar silenciosamente um contexto estranho. Construir do zero apenas controles
internos permitidos: GIT_CONFIG_NOSYSTEM verdadeiro; GIT_CONFIG_GLOBAL e
GIT_CONFIG_SYSTEM apontando a arquivos vazios próprios; GIT_TERMINAL_PROMPT=0.
São valores gerados pelo futuro supervisor, não herdados. Nomes/valores secretos
não entram em logs; registrar só categoria da recusa e hash do perfil público.

GIT_DIR/WORK_TREE/COMMON_DIR/INDEX_FILE/OBJECT_DIRECTORY, alternates, CONFIG_COUNT,
CONFIG_PARAMETERS, TEMPLATE_DIR, EXEC_PATH, TRACE e equivalentes não são herdados.
Configuração local será nova, sem include. O [manual Git](https://git-scm.com/docs/git)
documenta substituição das fontes global/sistema. Não mudar arquivo global, registro
ou configuração do repositório existente. Variável de processo não é mudança de
política persistente, mas sua aplicação ainda exige autorização de execução.

## 4. Busca de módulos e inicialização sem efeitos de testes

O mapa de caminhos é dado aprovado: stdlib/ZIP e DLLs do runtime, raízes das
dependências congeladas, módulos externos do runner e raízes estritamente necessárias
da candidata. Recusar entrada vazia, cwd, path relativo, reparse, volume ou diretório
não aprovado. Não decidir origem pela simples existência do arquivo ou pelo basename.

Antes de qualquer import do projeto, o bootstrap deverá comparar o perfil efetivo
ao mapa e hashes. Só loaders padrão aprovados e módulos built-in/frozen esperados;
module spec/origin e extensões carregadas devem corresponder. Conferência após import
é complementar: código já pode ter sido executado. Um loader hostil pode mentir sobre
origin, portanto isso pressupõe runtime e dependências confiáveis sob revisão.

Não processar .pth, sitecustomize ou usercustomize. Não chamar site.addsitedir, que
pode processar .pth. A [inicialização de sys.path em 3.12](https://docs.python.org/3.12/library/sys_path_init.html)
também depende de runtime, pyvenv.cfg e arquivos ._pth. O perfil inicial proposto
recusa ._pth inesperado ou configuração não manifestada; não remove o arquivo para
“consertar” ambiente. Não derivar diretórios aprovados apenas de sys.prefix sob -S,
pois a inicialização de venv varia entre versões. Se a instalação exigir bootstrap
especial, revisar outra proposta antes de executar, sem herdar solução da 3.14.

Nenhum import de testes legados ou fixtures para construir esperado. Nenhuma chamada
a pytest.main, descoberta, registro de hooks ou execução em nível de módulo. Para
futura etapa de ensaios autorizada, desabilitação de plugins automáticos e cache será
explícita; isso não suprime magicamente conftest ou side effects do próprio código.
Os módulos passiveis de Categoria A não serão Python: serão somente dados, sem import.

## 5. DLLs e extensões

O runtime carrega DLLs antes de o bootstrap poder inspecionar sys.path. Congelar a
distribuição/arquivos e aprovar onde ficam o executável, runtime e dependências é
precondição. Não tratar -I como controle da busca nativa de DLL. Cwd será externo e
sem bibliotecas candidatas a carregamento; caminhos e dependências precisam de revisão.

O perfil de código nativo futuro deve usar bibliotecas do sistema por origem
controlada e extensões aprovadas. [os.add_dll_directory](https://docs.python.org/3.12/library/os.html#os.add_dll_directory)
permite tratar diretórios adicionais de dependências no processo; não autoriza
adicionar PATH global ou diretório arbitrário da candidata. Handles desses diretórios
terão lifetime próprio. O catálogo de DLLs transitivas e a estratégia concreta de
carregamento ainda não estão fechados; sem ele, extensão não aprovada bloqueia.
Não executar import para descobrir empiricamente qual DLL o ambiente carregaria.

## 6. Git sintético: comando permitido e destinos

Futura allowlist de operações permite somente a inicialização sintética prevista em
WIN-11-A, com argumentos estruturados, destino novo próprio, template vazio explícito
e hooksPath próprio vazio, sem shell, aliases, rede, helper ou comando externo do
usuário. O [manual git-init](https://git-scm.com/docs/git-init) mostra que ambiente e
templates podem mudar destinos/conteúdo; portanto a ausência de herança deve ser
observável antes da operação. Não reutilizar configuração de repo pessoal.

O perfil proíbe separate-git-dir, shared, bare, reinit e destinations não autenticados
nesse caso mínimo. Erro ao inicializar é falha de preparação, não prova de recusa do
produto. Template/config vazios e parâmetros precisam estar na evidência, com hashes
e resultado, sem stderr bruto público. A versão específica do Git Windows deve ser
confrontada com o manual e o código futuro; o manual corrente não fixa seus bytes.
Nenhum Git foi inicializado nesta C4.

## 7. Caches, escrita e limites da proteção

Outputs, journal, cwd e temporários serão externos. Proibir cache pytest, bytecode,
pytest discovery e escrita intencional de módulos da candidata. Integridade futura
antes/depois deve abranger os 470 arquivos e extras inesperados, sem executar isso
agora. Desativar pyc não impede toda escrita de uma dependência ou import.

Mesmo token Windows não é fronteira de segurança contra código hostil: um import
malicioso pode gravar/exfiltrar antes de a verificação final detectar estado. Checagem
final não impede modificação transitória revertida. Se o contrato exigir impossibilidade
física de escrever, haverá dependência de desenho/política de SO fora deste bootstrap,
sem aplicar DACL ou elevação nesta tarefa. Não chamar esta proposta de sandbox.

## 8. Critérios de inspeção e decisão

Antes de qualquer implementação B: fechar perfis/arquivos Windows e bootstrap,
origens transitivas, DLLs, inicialização do supervisor e análise de efeitos de import.
A inspeção futura deve localizar todas as APIs de processo/filesystem, carregamentos,
configurações e caminhos de erro; provar que nenhum módulo A dispara B ou testes.

T04 continua PARCIAL apesar da seleção concreta de modos/ambiente. Não existem
runtime e dependências Windows aprovados, binding/process creation auditado ou código
inspecionado. Ausência dessas condições bloqueia, sem instalação/correção automática.
Nenhum estado de validação foi promovido; implementação e execução requerem decisões
posteriores distintas. C4 entrega só este contrato documental.
