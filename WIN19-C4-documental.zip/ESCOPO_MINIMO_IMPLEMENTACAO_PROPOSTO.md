# C4-E — proposta mínima de implementação futura

18/11/2026. **NÃO AUTORIZADA E NÃO IMPLEMENTADA.** Nenhum módulo, schema operacional
ou fixture foi criado nesta C4. Os caminhos abaixo são nomes previstos em uma pasta
externa futura, não arquivos existentes nem alterações na candidata.

## 1. Categoria A — potencialmente elegível, só dados declarativos

Proposta mínima: se houver autorização posterior, produzir exclusivamente os seis
artefatos de dados abaixo e documentação de interfaces. Não criar módulo Python,
entrypoint, runner, import, observador, validator executável ou teste, nem mesmo para
“validar” esses arquivos. Não haver dependência de T03/T04/T07 ativa é condição de A.

| Arquivo previsto | Interface declarativa | Dependências | Riscos e critérios de revisão |
|---|---|---|---|
| contratos_c/evento.schema.json | EventoSeguro: identificador, sequência, etapa, origem da API/código, eixos e integridade | Campos T01 aceitos | Sem default de PASS, conteúdo privado ou callback; limites propostos assinalados |
| contratos_c/mensagem.schema.json | Mensagem e ACK: identificador, sequência/hash e estado | Contrato T01, sem implementação de transporte | Sem pipe/rede/arquivo aberto; sem ACK presumido |
| contratos_c/estados.json | Estados e transições permitidas como dados | Semântica C3/C4 revisada | Estado de desenho separado de execução; nenhuma transição dispara função |
| contratos_c/relatorio.schema.json | Resultado por subafirmação/eixo, cleanup, custódia e lacunas | T01/T06 e política de status aceitos | Nada de agregado verde apagar bloqueio, skip ou falta de fonte |
| contratos_c/cobertura_21.csv | IDs/subcasos/afirmações/capacidade/referência de origem | Matriz C2 congelada, vínculos provisórios | Preservar 21/19 e ramo T02 bloqueado; sem gerar seleção executável de pytest |
| contratos_c/vetores_de_contrato.json | Exemplos mínimos fabricados de mensagens/resultados, só dados | Schemas aprovados e sem documentos reais | Não são fixtures executáveis nem resultados observados; sem paths reais/segredos |

Interfaces não levam handles/ponteiros, credencial ou objeto de produto: apenas
rótulos e valores seguros. Tipos nativos ficam opacos/rotulados e não impõem ABI em A.
Schemas não usarão referências remotas, resolução de rede, extensões de formato que
executem callbacks, geração de código, comandos embutidos ou includes não aprovados.
Referências locais, se necessárias, somente às peças declarativas manifestadas.

A não é elegível antes de rever campos, enumerações e limites. Código que serialize,
valide em runtime, abra arquivo, leia ambiente, faça hash no computador ou interprete
transição já pertence a B. “Passivo” não autoriza importar um módulo com side effects.
O parecer futuro deve aprovar exatamente a lista A; o ato de documentá-la não concede
permissão para criá-la nesta tarefa.

## 2. Categoria B — fechamento técnico e autorização adicionais

| Módulo externo futuro previsto | Interface conceitual | Dependências e riscos | Critério prévio à autorização |
|---|---|---|---|
| runner_c/supervisor.py | Estados, filhos próprios, stop e relatório parcial | T01/T04/T07, criação suspensa e herança | Ownership/job/ABI e caminho de falha aprovados |
| runner_c/observador.py | Persistir evento e confirmar sequência/hash | T01, escrita/sync/transporte e erro de disco | Contrato de durabilidade/ACK, limites e recuperação revisados |
| runner_c/bootstrap.py | Admitir ambiente e origem, sem descobrir testes por import | T04, runtime/.pth/DLL/plugin | Perfis Windows e todos os hashes/fontes transitivos fixados |
| runner_c/identidade_windows.py | Abrir/consultar objeto por handle e ancestral | T03, NtCreateFile/Win32, structs e TOCTOU | Protocolo relativo, ABI e direitos/efeitos justificados |
| runner_c/snapshots.py | Observar fronteiras e comparar estado | T01/T03/T05, segredos e consistência | S0/S1/S2, vazios/IDs/bytes e falhas de snapshot revisados |
| runner_c/laboratorio.py | Criação exclusiva e mapa de objetos sintéticos | T03/T07, capacidade/atribuição de descendentes | Nunca reutilizar área/candidata/residual ou inferir posse só por path |
| runner_c/cancelamento.py | Encerrar apenas workers próprios | T07, job/herança/espera/fechamento | Sem PID por nome, sem breakaway; observer fora do job |
| runner_c/cleanup.py | Remoção própria e resíduo com evidência | T03/T07, operação destrutiva | Primitivas, associação de nome, ownership e orçamento aprovados |
| runner_c/cli.py | Adaptar processo/streams/JSON/oráculo | T01/T04/T06/T07, perda de saída e common-mode da fixture | Positivos, oráculo independente, canais e estados incompletos revisados |
| runner_c/julgamento.py | Aplicar critérios sem executar teste oculto | T01/T06 e cobertura aprovada | Resultados por afirmação/eixo, sem descartar T02/skips/DACL |

Nomes previstos não autorizam esqueleto, stub, import ou binding nesta etapa. Não
antecipar B dentro de A por utilitário “de apoio”. A implementação integral de B
não está pronta para autorização com T03/T04/T05/T07 parciais. Cada componente
exigirá escopo e diff próprios e parada antes da execução.

## 3. Categoria C — explicitamente excluída

- Execução, coleta, importação com descoberta ou ensaio dos 21 cenários.
- Alterar src/, ferramentas ou testes da candidata R1-FIX 470, baseline BPQ-04,
  motor de limpeza/share0x3, perfis, regras financeiras/cadastrais ou formatos A/B.
- Aplicar W14P ou qualquer correção funcional no produto.
- Implantar/mudar ACL/DACL, privilégios, Developer Mode, contas, tokens ou política.
- Acesso entre contas, repetição da coleta única B, conversões reais, publicação,
  commit, push, merge ou novas worktrees por autorização de implementação A/B.

Não há arquivos ou módulos a produzir em C. Uma necessidade legítima fora dessa
fronteira requer nova tarefa/autorização, sem reinterpretar autorização limitada.

## 4. Dossiê para eventual decisão posterior

Antes de aceitar A: lista exata, schemas/interfaces como dados, dependências sem
execução, classificação de limites e status, custódia e critérios de revisão. Antes
de aceitar B: fechar os impedimentos correspondentes, hashes do ambiente/SDK/binários,
fontes completas e projeto de ABI/processos/erro, impacto no produto (se houver) em
proposta separada. O revisor deve identificar toda ação ao importar/inicializar.

Eventual autorização de escrita deve dizer quais verificações, se alguma, podem
ser executadas. Não inferir autorização de teste/import/parsing de uma autorização
para criar dados ou código. A execução do Portão C exige decisão separada após
revisão do diff, manifesto e roteiro. DACL e homologação exigem ainda seus portões.

**Recomendação atual:** apenas submeter A à revisão documental de elegibilidade.
Não solicitar implementação integral nem execução. Nesta C4 nenhum arquivo da
lista futura foi criado; os únicos novos arquivos são os documentos desta entrega.
