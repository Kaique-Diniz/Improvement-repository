# Conferência documental C4 — 18/11/2026

Utilitários de arquivo/texto/hash, sem execução de produto, teste, script, Python,
PowerShell, preflight ou sonda. Consultas públicas de documentação são apenas leitura.

| Peça | Conferência observada |
|---|---|
| Matriz T01–T07 C4 | Sete linhas/12 colunas; estados iguais aos C3: dois ESPECIFICADO, quatro PARCIAL, um BLOQUEADO |
| Implementação/validação/autorização | Todos sete NÃO_IMPLEMENTADO, NÃO_VALIDADO e PENDENTE |
| Diferenças C3/C4 | 13 linhas/8 colunas com fonte e limites |
| Fontes locais | 14 registros/7 colunas; hashes novamente comparados sem divergência |
| Referências oficiais | 36 links/7 colunas; sem bytes HTML arquivados ou SHA de página atribuído |
| Manifesto C3 | SHA d745d53ad223097386813628e8d1c1b94355abf99003d1289ed9d29658edc502 e arquivos cobertos continuam correspondendo |
| Fontes inventariadas na C3 | Hashes comparados novamente, sem divergência, inclusive referências de código |
| História C3 | 19 vínculos provisorios/decisões pendentes/zero confirmação, sete fichas SEM_FONTE preservadas |
| Código/schema operacional novo | Nenhum .py/.ps1/.sh/.bat/.cmd/.exe/.schema.json criado |
| Conteúdo compartilhável | Busca textual sem padrões de token/chave privada/CPF-CNPJ formatado/path de perfil; não é auditoria forense |

Os tamanhos e layouts ABI são requisitos de conferência futura contra SDK, não
medições feitas pelo executor nesta tarefa. Não houve Windows nativo, importação
de ctypes, carregamento de DLL ou processamento de exemplos. A fonte oficial é
linkada perto das afirmações; inferências de projeto e limitações estão separadas.

A criação dos documentos não modifica as versões anteriores. Não houve alteração
intencional de produção, candidata 470, motor/share0x3, conta, política ou ACL. A
conferência de hashes dessas referências não equivale a telemetria independente
de todo o workspace ou a revalidação operacional no computador Windows.
Nenhuma prova primária ausente foi reconstruída e W14P não foi aplicada.

O manifesto raiz cobre apenas arquivos presentes nesta entrega, com tamanho/SHA,
excluindo só a si próprio. Seu hash é informado na conversa. Nenhum ZIP novo,
commit/push/merge/publicação ou autorização de execução foi produzido nesta etapa.
A publicação anterior da C3 pertence à autorização então dada, não à presente C4.

Estados preservados: prontidão false, testes PENDENTE, runner NÃO_IMPLEMENTADO,
controles/DACL NÃO_VALIDADO, C/D/E e conversões bloqueados. Parar para revisão.
