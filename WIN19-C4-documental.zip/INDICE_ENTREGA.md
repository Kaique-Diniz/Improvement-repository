# WIN19-C4 — entrega documental para revisão independente

18/11/2026, America/Sao_Paulo. Pasta nova externa ao Git. Não implementa ou autoriza
runner, schema operacional, fixture, coleta, teste ou mudança de segurança.

## Entregáveis

1. [RELATORIO_C4_CONSOLIDACAO.md](RELATORIO_C4_CONSOLIDACAO.md) — conclusão e decisões,
   preservação da base e limites da proposta mínima.
2. [ESPECIFICACAO_T03_IDENTIDADE_WINDOWS.md](ESPECIFICACAO_T03_IDENTIDADE_WINDOWS.md) —
   APIs/ABI, direitos/efeitos/erros, tipos/positivos e abertura segura ainda parcial.
3. [ESPECIFICACAO_T04_BOOTSTRAP_ISOLADO.md](ESPECIFICACAO_T04_BOOTSTRAP_ISOLADO.md) —
   perfil concreto de modos/ambiente, imports/.pth/DLLs e hashes Windows pendentes.
4. [ESPECIFICACAO_T07_CLEANUP_SEGURO.md](ESPECIFICACAO_T07_CLEANUP_SEGURO.md) —
   ownership, processos/jobs/handles, exclusão por identidade, limites e resíduos.
5. [DEPENDENCIAS_T01_T02_T05_T06.md](DEPENDENCIAS_T01_T02_T05_T06.md) — contratos
   preservados, S0/S1/S2, W14P não aplicada e lacuna T02 explícita na cobertura.
6. [MATRIZ_C4_DECISOES_T01_T07.csv](MATRIZ_C4_DECISOES_T01_T07.csv) — sete decisões
   de desenho, fontes e motivos, sem promoção por descrição.
7. [ESCOPO_MINIMO_IMPLEMENTACAO_PROPOSTO.md](ESCOPO_MINIMO_IMPLEMENTACAO_PROPOSTO.md) —
   seis nomes de arquivos A declarativos futuros, módulos B pendentes e C excluída.
8. [RISCOS_RESIDUAIS_E_CRITERIOS_DE_ACEITE.md](RISCOS_RESIDUAIS_E_CRITERIOS_DE_ACEITE.md) —
   critérios antes de aceitar A/B e antes de execução posterior.
9. [MATRIZ_DIFERENCAS_C3_C4.csv](MATRIZ_DIFERENCAS_C3_C4.csv) — 13 linhas de confronto
   de desenho entre C3 e C4, sem alterar resultados históricos ou código.
10. [MANIFESTO_SHA256](MANIFESTO_SHA256) — SHA, bytes e nome relativo somente dos
    arquivos efetivamente entregues nesta pasta, exceto o próprio manifesto.

## Fontes e versões

- [INVENTARIO_FONTES_C4.csv](INVENTARIO_FONTES_C4.csv): 14 fontes locais com tamanho,
  mtime UTC, SHA e limite de origem. Inclui anexos, C3, W14P, snapshot e referências
  de manifesto/candidata. Hash de documento não comprova execução ou efeitos remotos.
- [REFERENCIAS_OFICIAIS_C4.csv](REFERENCIAS_OFICIAIS_C4.csv): 36 links públicos
  Microsoft/Python/Git consultados como documentação, data e limite. Não foram
  arquivados bytes das páginas, não há SHA de página inventado ou atestado nativo.
  Sucesso de leitura de documentação não comprova suporte/binding do alvo real.
- fontes_recebidas/: instrução C4 e parecer C3, cópias literais. O texto colado foi
  renomeado descritivamente, com bytes preservados. Nenhum exemplo foi executado.
- [CONFERENCIA_DOCUMENTAL.md](CONFERENCIA_DOCUMENTAL.md): contagens, consistência e
  integridade das fontes/C3, sem teste de produto ou segurança.

Base C3: ZIP dfaa59e9b9656b93e366a41c2263f84b08f26c2a094f009eceb1c7844c365be9,
manifesto d745d53ad223097386813628e8d1c1b94355abf99003d1289ed9d29658edc502.
Candidata R1-FIX 470, referência a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c,
base 770d062d29c4361d6932592883df9339bb4089bc, preservadas sem verificação operacional.

## Resultado e ponto de parada

T01/T06 ESPECIFICADO; T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL. Implementação/validação
não promovidas. Categoria A apenas potencialmente elegível a autorização posterior;
nenhum arquivo proposto de A/B criado agora. C não está autorizada. Limites de
20 ciclos/100 ms/2 s continuam PARA_REVISÃO, sem defaults ativos ou prova de conclusão.

19 vínculos PROVISORIO_SEM_FONTE e sete fichas históricas pendentes. Sem coleta JUnit,
preenchimento por inferência ou associação comprovada do manifesto 448 ao run.
prontidao_para_executar=false; autorizacao_testes=PENDENTE;
runner_C=NÃO_IMPLEMENTADO; WIN01–WIN19=NÃO_VALIDADO; DACL=NÃO_VALIDADO;
D01–D10 PARA_APROVAÇÃO; C/D/E=BLOQUEADOS; CONVERSOES_REAIS=BLOQUEADAS.
Portão B encerrado documentalmente, autorização única consumida.

Somente leitura estática, consultas de documentação pública e utilitários de
arquivo/texto/hash para documentos novos. Nenhum Python, pytest, PowerShell, import,
preflight, script do pacote, teste, instalação, candidata/worktree/configuração,
permissão/conta/ACL/privilégio/política, conversão, cleanup histórico, commit, push,
merge, ZIP novo ou publicação. Entregar e parar para revisão independente.
