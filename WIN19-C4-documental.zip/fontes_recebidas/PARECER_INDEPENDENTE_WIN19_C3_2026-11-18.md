# EXP-04 / WIN19 — Parecer independente da preparação documental C3

**Data de referência:** 18/11/2026  
**Objeto:** `WIN19-C3-preparacao-documental.zip`, recebido nesta conversa.  
**Natureza:** auditoria estática de documentação e integridade; nenhum script do pacote foi executado.  
**Decisão:** **ACEITAR A C3 COMO PREPARAÇÃO DOCUMENTAL, COM RESSALVAS; NÃO AUTORIZAR IMPLEMENTAÇÃO INTEGRAL, EXECUÇÃO DO PORTÃO C OU ALTERAÇÃO DA POLÍTICA DACL.**

## 1. Integridade e proveniência

- ZIP recebido: **60.547 bytes**; SHA-256 `dfaa59e9b9656b93e366a41c2263f84b08f26c2a094f009eceb1c7844c365be9`.
- **16 entradas únicas**, sem falha de CRC; uma é `MANIFESTO_SHA256` e **15 são arquivos manifestados**.
- SHA-256 do `MANIFESTO_SHA256`: **`d745d53ad223097386813628e8d1c1b94355abf99003d1289ed9d29658edc502`**, idêntico ao fornecido.
- **15/15** arquivos do manifesto conferidos por bytes e SHA-256, com inventário sem entradas extras ou faltantes. Nenhum caminho de saída absoluta, traversal (`..`) ou symlink foi encontrado no ZIP.
- A autenticidade da origem ou os efeitos de atos realizados no workspace do Codex não decorrem do hash do ZIP; a declaração de não execução/alteração externa é recebida como relato, não auditoria independente do ambiente remoto.
- Referência C2 conferida contra o ZIP anterior disponível: SHA-256 `94f1039bd3bc6263bd82041349f132a0c9aa4ccc047db7d0ade12997324aec24`; manifesto C2 SHA-256 `a8785f24699cfa7ac606f751b54248c2d6832313bc7a06e5b2517e0a01e9def6`.
- O diff `DIFF_ARQUITETURA_C2_C3.patch` reconstitui integralmente os **195 registros de origem** e os **286 registros da nova arquitetura**; sua apresentação não precisa coincidir byte a byte com outro algoritmo de geração de diff para ser semanticamente válida.

## 2. Reconciliação histórica — C3-A

- `MATRIZ_C3_CONFRONTO_HISTORICO.csv`: **19 linhas, 29 colunas**. Os primeiros **25 campos** são preservados da matriz C1 precedente, acrescidos de campos para confronto futuro. Não houve promoção dos vínculos: **19 `PROVISORIO_SEM_FONTE`**, **19 `PENDENTE`**, **19 `confirmacao_por_primario=NAO`**, **19 `vinculo_manifesto_rodada_windows=NAO_DEMONSTRADO`**.
- `MATRIZ_C3_SKIPS_A_CONFERIR.csv`: **7 fichas**, todas identificadas expressamente como modelos não preenchidos, **não** como nodeids ou motivos literais recuperados.
- O protocolo distingue identidade atual do `completa-utf8.xml` de prova contemporânea de seu uso na rodada Windows. Preconiza leitura/cópia apenas após autorização própria, preservação dos bytes, inventário de metadados, custódia local, sanitização autorizada, parser XML sem entidades externas e revisão humana dos vínculos. Não presume 1:1 entre controles WIN e falhas originais.
- A rodada relatada de **2.842 coletados / 2.816 aprovados / 19 falhas / 7 skips** permanece informação histórica secundária. O manifesto EXP-04 de 448 entradas (SHA-256 `19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb`) foi identificado, mas sua associação àquela execução não está demonstrada.
- **Pendências primárias:** XML/JUnit original, comando/argv, stdout/stderr/log da mesma execução, ambiente e plugins, versão física do código e prova contemporânea de uso do manifesto; definição própria de custódia/retenção C1.

## 3. Decisões técnicas — C3-B

A matriz `MATRIZ_T01_T07_DECISOES.csv` possui **7 linhas e 16 colunas**, com os estados de implementação `NÃO_IMPLEMENTADO`, validação `NÃO_VALIDADO` e autorização de execução `PENDENTE` em todos os registros:

| ID | Decisão **de desenho** | Fundamentação e limitação residual |
|---|---|---|
| T01 — Observador durável | **ESPECIFICADO** | Supervisor/escritor único, sequenciamento, journal, ACK após persistência solicitada, primeira falha e registros parciais descritos. Nenhuma prova de durabilidade real, queda de energia ou proteção contra regravação pelo mesmo token. |
| T02 — Erro nativo WIN-03 | **BLOQUEADO** | Não existe estratégia segura e observável documentada para o ramo de erro real; não confundir NUL pré-API, mock ou falha de preparação com erro da API. |
| T03 — Links/identidade | **PARCIAL** | Diferenças entre symlink, junction, hardlink, alias e identidade física definidas; handles, assinaturas/ABI e capacidade symlink ainda dependentes de projeto/revisão. |
| T04 — Git/Python | **PARCIAL** | Ambiente por lista positiva e prevenção de imports com efeitos colaterais definidos conceitualmente; bootstrap concreto, dependências e hashes Windows não fixados. |
| T05 — Autoridade/WIN-14 | **PARCIAL** | Fronteiras de snapshots ampliadas; W14P **não aplicada**, coleta segura de identidade/diretórios e observabilidade dependem de T01/T03. Igualdade final não prova ausência de modificação transitória. |
| T06 — CLI/oráculo/WIN-16 | **ESPECIFICADO** | Separação de CLI, JSON, auditoria e DTO; oráculo prévio e drenagem de stdout/stderr previstos. Depende de T01/T04/T07 e revisão independente da fixture sintética. |
| T07 — Limpeza | **PARCIAL** | Titularidade, recursos próprios, preservação de resíduos e evidências descritas; remoção nativa por identidade, cancelamento/processos e limites de observação ainda não revisados. Os 20 ciclos/100 ms/2 s são apenas **PARA_REVISÃO**. |

**Interpretação obrigatória:** `ESPECIFICADO` não é `IMPLEMENTADO`, `PASS` ou `VALIDADO`; `PARCIAL` não abre o respectivo cenário; `BLOQUEADO` em T02 é específico ao ramo de erro nativo, sem autorizar executar outras subafirmações.

## 4. Avaliação da proposta de implementação

`ESCOPO_PROPOSTO_IMPLEMENTACAO_C.md` separa funções de supervisor, journal/observador, transporte, bootstrap, identidade, laboratório sintético, snapshots, CLI/oráculo, julgamento e cleanup. O desenho exige artefatos externos e preserva a candidata R1-FIX 470; exclui implantação DACL, mudanças no produto e execução. Isso é apropriado **como material para revisão de eventual escopo limitado**, não como autorização tácita para construir um executor completo.

Para qualquer autorização futura de implementação, é necessário nomear explicitamente módulos permitidos, interfaces, artefatos proibidos, dependências T03/T04/T05/T07 que devem ser resolvidas antes de codificar ou aceitas como exclusões, tratamento de T02, assinaturas/handles e plano de auditoria de imports/efeitos. **A implementação e os testes devem ter autorizações distintas.** A documentação atual não demonstra a segurança operacional de criação/remoção de recursos ou dos subprocessos.

## 5. Ressalvas e condicionantes

1. **Fonte primária faltante:** nenhuma das 19 falhas foi reconciliada por JUnit original; sete skips continuam fichas vazias. A recuperação deve ter custodiante, destino, retenção, finalidade e eventual compartilhamento definidos em autorização específica, sem herdar automaticamente os 90 dias da custódia B.
2. **T02:** definir em decisão separada se o ramo de erro nativo permanece excluído/inconclusivo, com impacto explícito na cobertura. Não criar prova artificial insegura.
3. **T03/T04/T05/T07:** resolver o desenho de ABI/identidade, bootstrap/imports, snapshot W14P e limpeza por identidade antes de autorizar qualquer código que use esses mecanismos. Em especial, não transformar o timeout de dois segundos em garantia operacional.
4. **Limite de integridade:** hashes provam correspondência dos arquivos recebidos, mas não que a candidata Windows permaneceu inalterada nesta entrega ou que o manifesto 448 foi usado na rodada histórica.
5. **Escopo proibido:** manter DACL D01–D10 em `PARA_APROVAÇÃO`; não habilitar privilégios, alterar contas, executar pré-flight/pytest, aplicar patch funcional, repetir o Portão B ou realizar conversões reais.

## 6. Decisão e próximo ponto de parada

**ACEITA A C3 DOCUMENTAL COM RESSALVAS.** O projeto está apto a **revisar uma proposta limitada de implementação**, mas **não** a implementar o runner integral nem executar os 21 subcasos. Se uma etapa seguinte for autorizada, ela deverá primeiro delimitar componentes estritamente documentais ou passivos e enumerar dependências pendentes. A recuperação do JUnit original e a autenticação histórica da rodada devem tramitar separadamente.

**Estados preservados:** `prontidao_para_executar=false`; `autorizacao_testes=PENDENTE`; 19 vínculos `PROVISORIO_SEM_FONTE`; WIN-01..WIN-19 e DACL `NÃO_VALIDADO`; runner `NÃO_IMPLEMENTADO`; C/D/E e conversões reais `BLOQUEADOS`; Portão B encerrado documentalmente, autorização única consumida.

Esta revisão não executou scripts, testes, preflight, comandos da candidata nem operações no computador Windows do usuário.
