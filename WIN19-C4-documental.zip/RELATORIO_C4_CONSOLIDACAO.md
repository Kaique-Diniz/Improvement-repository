# WIN19-C4 — fechamento técnico e delimitação documental

18/11/2026, America/Sao_Paulo. Escopo exclusivo: documentação, revisão estática e
especificação. Não houve implementação ou execução do runner, ensaio ou publicação.

## 1. Conclusão

C4 delimita o desenho com catálogo de APIs/ABI/direitos/erros, perfil de bootstrap,
modelo de processos/cleanup e proposta mínima A/B/C. **Não declara encerradas as
quatro pendências parciais pela existência desses documentos.** Estados de desenho
mantidos: T01/T06 ESPECIFICADO; T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL.

A única proposta potencialmente elegível para decisão posterior é Categoria A:
seis arquivos de dados declarativos e seus contratos, sem Python, imports, callbacks,
validador runtime ou atividade de filesystem/processo. Supervisor, bootstrap,
observador persistente, identidade, snapshots, CLI, laboratório e limpeza são B e
continuam dependentes de fechamento técnico. Não foi criado arquivo de A ou B agora.
Execução dos 21 cenários, produto, W14P, DACL, privilégios/contas e conversões são C,
explicitamente excluídos. A elegibilidade documental de A não é autorização de criação.

## 2. Fundamentação e versões

Referência obrigatória lida: PARECER_INDEPENDENTE_WIN19_C3_2026-11-18.md, que aceita
C3 documental com ressalvas e não autoriza implementação integral. A instrução C4
também foi lida integralmente. Cópias literais estão em fontes_recebidas/, com hashes
no inventário e manifesto. Os anexos são fonte de instrução/parecer, não evidência
primária do run Windows ou telemetria de efeitos no workspace.

C3 preservada: ZIP 60.547 bytes, SHA-256
dfaa59e9b9656b93e366a41c2263f84b08f26c2a094f009eceb1c7844c365be9;
manifesto d745d53ad223097386813628e8d1c1b94355abf99003d1289ed9d29658edc502.
Candidata R1-FIX de 470 arquivos e referência documental
REFERENCIA_R1_FIX_470_SHA256.json, SHA
a3b5a0e74126135e42cd75963345c3ba6c585282dd474feb4080682df940f27c,
base 770d062d29c4361d6932592883df9339bb4089bc, permanecem inalteradas. Não se
reexecutou a verificação operacional desses 470 arquivos nem se acessou o Windows.

Foram consultadas estaticamente referências oficiais Microsoft, Python 3.12 e Git.
Os links constam das especificações e de REFERENCIAS_OFICIAIS_C4.csv. São suporte
documental de API e semântica, não prova de que o binário/SDK/alvo atende ao contrato.
Não foram arquivados os bytes das páginas, não se atribuiu SHA fictício a elas e
não se executou código de seus exemplos. A página Python consultada apresenta 3.12.16;
não se inferiu a versão instalada do usuário. Compatibilidade com ambiente concreto
continua pendente. O catálogo é proposta de engenharia, com limites explícitos.

## 3. Resultado por frente

| Frente | Especificação/decisão nova | O que permanece aberto |
|---|---|---|
| C4-A/T03 | ABI LLP64 proposta, structs, consulta/bytes/tag/volume/nome, alternativa relativa NtCreateFile e erros distintos | Root/ancestrais resistentes a troca, binding/SDK, ownership do nome, capacidade symlink |
| C4-B/T04 | Perfil Python 3.12 isolado sem site/bytecode e UTF-8; Git absoluto com ambiente/config/template próprios | Hashes Windows reais, runtime/DLLs/imports transitivos e bootstrap auditado |
| C4-C/T07 | Job próprio, criação suspensa, herança restrita, término/espera, disposição por handle e resíduo | ABI/lifetime, jobs aninhados, atribuição de arquivos dinâmicos e conclusão de ausência |
| C4-D/T05 | S0/S1/S2 separam delta da fixture e efeitos do produto; fronteiras independentes | Coleta consistente por T01/T03/T04/T07, sem interferência do observador; W14P não aplicada |
| C4-D/T01/T06 | Escritor fora do job, erro capturado na camada certa e canais completos sob cancelamento | Integração/durabilidade/oráculo/fixtures ainda não implementados ou validados |
| C4-D/T02 | Lacuna de erro nativo explicitada na cobertura | Nenhuma estratégia segura observável; não usar prova artificial nem omitir subafirmação |
| C4-E | Arquivos/interfaces/dependências/riscos/critérios por A/B/C | Parecer e autorização de implementação limitada posteriores e separados de execução |

Pontos que delimitam risco em vez de prometer garantia: OPEN_REPARSE_POINT terminal
não autentica todos os ancestrais; volume+ID não prova posse do nome; CloseHandle
não prova processo morto ou nome removido; mesma identidade/hash final não prova
não leitura ou não alteração transitória; -I não é sandbox de DLL/código hostil.
Essas conclusões são usadas para impedir promoção de estado, não para declarar
vulnerabilidade funcional nova sem reprodução adequada.

20 ciclos/100 ms/2 s e limites de journal anteriores permanecem PARA_REVISÃO.
Não há valores ativos, fundamentos empíricos novos ou garantia por timeout. Em
posse/identidade incerta, preservar e bloquear; nunca apagar por prefixo, marker
ou simples descendência da pasta temporária. Motor/share0x3 e residual histórico
não foram acessados para operação ou alterados.

## 4. Decisão de cada pendência

MATRIZ_C4_DECISOES_T01_T07.csv preserva sete linhas e distingue estado C3, decisão
C4, evidência e motivo de não promoção. Todos continuam NÃO_IMPLEMENTADO,
NÃO_VALIDADO e autorização PENDENTE. Nenhuma assinatura ou consulta de documentação
constitui aceite de binding/código ou encerramento de risco. O núcleo da proposta
mínima limita A para não depender ativamente das capacidades ainda abertas em B.

Não se recomenda implementar B integralmente com os bloqueios atuais. Mesmo para
A é necessária autorização posterior com lista exata e revisão de conteúdo. Código
ou avaliação runtime que pareça “apoio” continua B. Implementação autorizada não
implica execução, parsing de teste, import do projeto ou validação Windows.

## 5. Reconciliação histórica e segurança preservadas

O JUnit completa-utf8.xml continua apenas referenciado no Windows do usuário; não
se presumiu existência, acesso, bytes ou integridade. Manifesto 448 SHA
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb
continua sem associação comprovada à rodada de 2.842 casos/19 falhas/sete skips.
As 19 linhas históricas e sete fichas C3 foram preservadas sem preencher por inferência.
Recuperação/custódia/retenção próprias cabem a procedimento separado, sem pedir raw
privado nem herdar os 90 dias de B. Desvio Python anterior não foi reencenado.

WIN01–WIN19=NÃO_VALIDADO; DACL=NÃO_VALIDADO; D01–D10 PARA_APROVAÇÃO;
prontidao_para_executar=false; autorizacao_testes=PENDENTE;
runner_C=NÃO_IMPLEMENTADO; C/D/E=BLOQUEADOS; CONVERSOES_REAIS=BLOQUEADAS.
Portão B encerrado documentalmente, autorização única consumida. Resultados Windows
anteriores não foram reexecutados, corrigidos retrospectivamente ou promovidos.

## 6. Entrega e parada

Somente documentos novos externos ao Git, fontes recebidas copiadas e metadados
estáticos. Utilitários de arquivo/texto/hash e consultas de documentação pública;
nenhum Python, pytest, PowerShell, preflight, import, script de projeto, teste,
fixture executável, runner, nova candidata/worktree/configuração/dependência,
permissão/ACL/conta/privilégio/política, conversão, limpeza histórica, commit, push,
merge ou publicação. Nenhum código do produto alterado.

O manifesto cobre somente o que está efetivamente entregue nesta pasta, excluindo
só a si próprio. A matriz C3/C4 identifica as diferenças documentais. A conferência
de hashes não é auditoria independente de efeitos do workspace ou atestação do
Windows remoto. Entregar C4 e parar para revisão independente, sem solicitar
execução ou desbloqueio automático.
