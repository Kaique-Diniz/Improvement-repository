# C4-A — identidade Windows, primitivas e limites

18/11/2026. **Especificação estática. Nenhuma chamada abaixo foi executada.**
API documentada não equivale a binding auditado ou garantia validada. Categoria B
inteira permanece sem autorização. T03 continua PARCIAL, com subfronteira de
abertura segura sob concorrência bloqueada até revisão independente.

## 1. Perfil ABI proposto e precondições

Perfil inicial PARA_REVISÃO: Windows desktop AMD64, processo CPython 3.12 de 64 bits,
volume local NTFS de laboratório próprio. A arquitetura/instalação do usuário não
foi comprovada nesta C4; não inferir 64 bits da versão Python. x86, ARM64, SMB, ReFS,
volumes remotos e namespaces especiais ficam fora desse perfil, não aprovados.

Contrato LLP64: HANDLE/PVOID/ponteiros e SIZE_T/ULONG_PTR têm 8 bytes nesse perfil;
DWORD/ULONG/ACCESS_MASK/BOOL têm 4; WCHAR/USHORT têm 2; BOOLEAN tem 1; LARGE_INTEGER
é de 64 bits; NTSTATUS é inteiro com sinal de 32 bits, não BOOL. WINAPI/NTAPI seguem
a ABI Windows do alvo; não usar layout Linux de long/wchar nem empacotamento artificial.
São requisitos de revisão futura contra headers SDK, não medições feitas aqui.
Os direitos abaixo são perfis mínimos propostos para cada composição de operações,
não garantia de que todo filesystem aceita a mesma máscara. Quando a abertura
relativa exigir FILE_TRAVERSE no pai, isso também deve ser justificado; não presumir
privilégio de travessia. Acesso insuficiente bloqueia, sem ampliar direitos por tentativa.

Layouts esperados para conferência independente: FILE_ID_INFO = serial de volume
64 bits + ID de 128 bits (24 bytes); FILE_ATTRIBUTE_TAG_INFO = dois DWORD (8 bytes);
FILE_STANDARD_INFO = dois LARGE_INTEGER, DWORD NumberOfLinks, BOOLEAN DeletePending
+ Directory e padding (24 bytes). Os últimos BOOLEAN não são BOOL de 4 bytes.
A enumeração FileIdBothDirectoryInfo tem estrutura variável: offsets, comprimento
UTF-16 e buffer precisam de conferência de limites antes de percorrer entradas.
Não existe binding autorizado por simplesmente listar esses tamanhos.

Identidade será tupla de volume + file ID, associada a handle vivo, tipo e época de
criação do ensaio. Serial de volume não é UUID global nem prova de titularidade.
ID pode ser reutilizado depois da exclusão. Caminho, conteúdo/hash, owner e identidade
física são fatos diferentes. O mapa de propriedade exige criação exclusiva própria.
Identificadores reais de volume/arquivo e localização ficam privados; o derivado
compartilhável usa rótulos e booleans, sem dumps ou hashes de identificadores de baixa
entropia. BACKUP_SEMANTICS permite o perfil de diretório, mas não atribui nem habilita
privilégio; direitos insuficientes continuam bloqueio, sem ajuste de token.

## 2. Catálogo de primitivas candidatas

As assinaturas são notação documental C, não código de implementação. Falha significa
preservar primeira causa e bloquear a operação dependente, sem elevar direitos.

### P03-01 — abrir para inspeção terminal

[CreateFileW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew):
HANDLE (LPCWSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE).
Perfil de consulta: FILE_READ_ATTRIBUTES, OPEN_EXISTING, OPEN_REPARSE_POINT e
BACKUP_SEMANTICS para diretórios; atributos/segurança/template sem mutação.
Compartilhamento 0x3 pode ser avaliado como retenção sem SHARE_DELETE, não promessa
de imutabilidade. Não alterar o 0x3 do motor existente. Não usar CREATE_ALWAYS,
TRUNCATE_EXISTING ou DELETE_ON_CLOSE. Retorno INVALID_HANDLE_VALUE captura erro
imediato; não confundir com NULL. Abrir pode causar acessos/efeitos de SO; não prova
DACL. OPEN_REPARSE_POINT não autentica todos os ancestrais. Falta de prova dessa
fronteira bloqueia abertura sensível, mesmo com caminho textual normalizado.

### P03-02 — consultar identidade, tipo e estado

[GetFileInformationByHandleEx](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getfileinformationbyhandleex):
BOOL (HANDLE, FILE_INFO_BY_HANDLE_CLASS, LPVOID, DWORD). Handle próprio de metadados,
classe/estrutura e tamanho exatos. FileIdInfo fornece identidade; FileAttributeTagInfo,
atributos/tag; FileStandardInfo, tipo, links e pendência. As estruturas estão nas
referências [FILE_ID_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_info),
[FILE_ATTRIBUTE_TAG_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_attribute_tag_info) e
[FILE_STANDARD_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_standard_info).
Requisitos de acesso variam por classe; perfil proposto usa READ_ATTRIBUTES, sem
solicitar leitura de conteúdo para metadados. Falha/estrutura inesperada bloqueia,
sem fallback de identidade para hash/caminho. Consulta não modifica intencionalmente
bytes; não é captura atômica de toda árvore nem proteção contra escrita concorrente.

### P03-03 — metadados legados, sem rebaixar identidade

[GetFileInformationByHandle](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfileinformationbyhandle):
BOOL (HANDLE, LPBY_HANDLE_FILE_INFORMATION). Consulta em handle de metadados; BOOL
zero exige erro imediato. FileIndex alto/baixo e serial de 32 bits são dados do
perfil legado, não truncamento silencioso da tupla de 128/64 bits escolhida. Serve
para cotejo, inclusive NumberOfLinks, não para aceitar um volume que não suporte o
contrato aprovado. Retorno parcial/inconsistente mantém NÃO_VALIDADO. Não elevar.

### P03-04 — identificar reparse sem seguir o destino

[DeviceIoControl](https://learn.microsoft.com/en-us/windows/win32/api/ioapiset/nf-ioapiset-deviceiocontrol):
BOOL (HANDLE, DWORD, LPVOID, DWORD, LPVOID, DWORD, LPDWORD, LPOVERLAPPED).
Somente [FSCTL_GET_REPARSE_POINT](https://learn.microsoft.com/en-us/windows/win32/api/winioctl/ni-winioctl-fsctl_get_reparse_point),
handle da entrada, entrada NULL/tamanho zero, buffer de saída limitado e bytes
retornados válidos. Perfil síncrono sem OVERLAPPED; não omitir bytesReturned.
Direito de consulta e READ_ATTRIBUTES conforme perfil, sem write/DELETE. Nada de
SET/DELETE_REPARSE_POINT. Buffer/tag/offset inválido, estado que muda ou erro
inesperado bloqueiam. Não ler destino retornado como forma de autorizar acesso.
Leitura da tag só distingue categoria; não prova ausência de reparse em ancestrais.

### P03-05 — ler bytes do objeto autenticado

[ReadFile](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-readfile):
BOOL (HANDLE, LPVOID, DWORD, LPDWORD, LPOVERLAPPED). FILE_READ_DATA no handle regular
já autenticado; no perfil nativo síncrono incluir SYNCHRONIZE quando exigido pelo
modo. Buffer próprio válido, tamanho limitado, contagem real e EOF conferidos;
comparação integral dos bytes, hash complementar. Não abrir pelo caminho novamente
para “validar” o handle. Falha ou leitura parcial sem conclusão comprovada bloqueia.
Leitura pode afetar último acesso; não promete congelamento de metadata ou memória.
A leitura de segredo fica só em custódia/memória aprovada, nunca no evento público.

### P03-06 — nomes e aliases, apenas corroborativos

[GetFinalPathNameByHandleW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfinalpathnamebyhandlew):
DWORD (HANDLE, LPWSTR, DWORD, DWORD). Handle de consulta existente, flags nome/volume
aprovadas, buffer em WCHAR com contagem incluindo terminador disponível. Zero é
falha; tamanho insuficiente exige observação/realocação limitada, não uso truncado.
Nome final é diagnóstico, não autorização por prefixo de string. Não publicar path.

[GetShortPathNameW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getshortpathnamew):
DWORD (LPCWSTR, LPWSTR, DWORD). Não requer handle de escrita. Uma consulta de tamanho
e preenchimento limitado não cria alias. Zero gera erro imediato; retorno sem alias
realmente distinto significa capacidade não demonstrada. Longo/curto devem abrir o
mesmo objeto sob o protocolo seguro. Nunca fabricar 8.3, assumir igualdade de nomes
por conteúdo ou usar sucesso nominal como prova de isolamento.

### P03-07 — verificar características do volume

[GetVolumeInformationByHandleW](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getvolumeinformationbyhandlew):
BOOL (HANDLE, LPWSTR, DWORD, LPDWORD, LPDWORD, LPDWORD, LPWSTR, DWORD).
Handle legítimo de arquivo/diretório no volume, buffers/ponteiros próprios de saída,
sem escrita. Perfil de consulta, nenhuma abertura de disco bruto. BOOL zero captura
erro; volume não elegível bloqueia. Nome do filesystem e flags não são prova de DACL,
e o serial de 32 bits dessa consulta não substitui o serial de FILE_ID_INFO.

### P03-08 — fechar com rastreabilidade

[CloseHandle](https://learn.microsoft.com/en-us/windows/win32/api/handleapi/nf-handleapi-closehandle):
BOOL (HANDLE). Só handle criado/recebido e ainda possuído pelo componente, com
transferência explícita e fechamento único. Falha captura erro antes de outra API;
não tentar fechar repetidamente um valor já invalidado/reutilizado. Não fecha memória
ou lista de atributos, não termina processo por si só e não comprova remoção de nome.
Falha secundária de fechamento não apaga primeira falha. Estado incerto bloqueia
operações dependentes e preserva evidência, sem declarar limpeza concluída.

## 3. Abertura relativa e fronteira de concorrência ainda PARCIAL

Caminho absoluto inspecionado por componentes e retenção de handles reduzem janelas,
mas não constituem por si prova contra todo redirecionamento. A alternativa candidata
é abertura componente a componente relativa a diretório autenticado, rejeitando
reparse durante resolução. Nem essa alternativa está autorizada como código.

[NtCreateFile](https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntcreatefile):
NTSTATUS (PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PIO_STATUS_BLOCK,
PLARGE_INTEGER, ULONG, ULONG, ULONG, ULONG, PVOID, ULONG).
RootDirectory aponta ao pai autenticado; nome Unicode deve ser um único componente,
sem separador, .., ADS, namespace especial ou NUL. OPEN existente, sem sobrescrita;
sem EA/alocação ou security descriptor novo. READ_ATTRIBUTES para metadados;
FILE_LIST_DIRECTORY para enumerar; READ_DATA para bytes; SYNCHRONIZE quando o modo
síncrono o exige. Não reutilizar constantes Win32 OPEN_EXISTING como FILE_OPEN NT.

[OBJECT_ATTRIBUTES](https://learn.microsoft.com/en-us/windows/win32/api/ntdef/ns-ntdef-_object_attributes)
permite RootDirectory e OBJ_DONT_REPARSE; o último prevê recusa quando a resolução
encontra reparse. Não confundir essa recusa do HELPER com recusa funcional do PRODUTO.
Para inspecionar entrada de link do laboratório, seria necessário um perfil separado
de abertura da própria entrada, nunca atravessar seu destino inadvertidamente.

Layouts candidatos AMD64: OBJECT_ATTRIBUTES 48 bytes; UNICODE_STRING 16; IO_STATUS_BLOCK
16, com união inicial de tamanho de ponteiro e ULONG_PTR final. Validar offsets,
alinhamento, comprimentos Unicode EM BYTES e lifetime de buffers contra SDK/ABI.
NTSTATUS original deve ser preservado; não obter GetLastError para inventar erro NT.
STATUS_PENDING/estado não previsto não autoriza usar saídas ainda não concluídas.
Conversão diagnóstica de status, se desejada, exigirá contrato próprio sem substituir
status original. Binding, suporte do alvo e prova de resolução segura continuam pendentes.

Não escolher fallback por pathname quando essa fronteira não puder ser justificada.
Metadados podem ser especificados, mas leitura/exclusão de segurança sob concorrência
permanece bloqueada até aceitar o protocolo relativo, sua ABI e seus limites.

## 4. Tipos e controles futuros — sem executar

| Tipo | Observação necessária | Positivo/negativo e limite |
|---|---|---|
| Symlink | Entrada própria com tag SYMLINK e alvo sintético | Tipo arquivo/diretório correto; sem capacidade, NÃO_VALIDADO |
| Junction | Reparse tag MOUNT_POINT e destino próprio | Prova específica de junction; não substitui symlink |
| Hardlink | Nomes distintos, mesmo volume/ID e contagem coerente | Mesmo arquivo físico, regra de nome do comparador pode recusar |
| Alias 8.3 | Alias real distinto e mesma identidade aberta | Próprio/equivalente true, outro arquivo igual em bytes false |
| Arquivo comum | Tipo regular, identidade e bytes conhecidos | Mesmo path true impede comparador sempre false |
| Reparse desconhecido | Tag/categoria não aprovada | Preservar entrada, bloquear; não seguir para identificar destino |

Não ativar privilégio de symlink, Developer Mode ou elevação. O 1314 deve ser
capturado efetivamente na futura criação, não herdado como prova daquela tentativa.
Falha de preparação/helper, capacidade ausente e rejeição funcional têm eventos
separados. Se o produto nunca foi chamado, não há PASS de rejeição do produto.

## 5. Decisão e critérios de revisão

T03 = PARCIAL. Catálogo/API/ABI documentado melhora revisabilidade, não encerra a
segurança da resolução. Antes de qualquer código Categoria B: aprovar perfil real
do Windows/SDK, direitos por operação, convenções, structs/offsets, ownership,
política de share, alternativa de abertura relativa e casos de substituição. Antes
de execução: autorização distinta e evidência nativa. Nenhuma mudança no leitor,
na regra de hardlinks, DACL ou candidata foi feita. APIs citadas são referências
oficiais consultadas estaticamente, não resultados observados da máquina do usuário.
