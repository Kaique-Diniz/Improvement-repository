# C4-D — dependências e impacto na cobertura

18/11/2026. Revisão textual. Nenhum contrato descrito está implementado ou validado.

## T01 — ESPECIFICADO, preservado com condicionantes

Preservar supervisor/escritor separados, journal externo ao temporário, sequência,
confirmação de persistência solicitada antes do setup/julgamento, primeira falha e
estados incompletos. Hash de journal não autentica contra reescrita pelo mesmo token.
Não prometer durabilidade contra perda de energia ou DACL pelo simples ACK.

C4 acrescenta dois requisitos de integração: escritor/supervisor não podem integrar
o job de workers cancelado por T07; qualquer captura de Win32 ocorre no emissor antes
de outra API, e NTSTATUS não é reconstruído por GetLastError. Falha de preparação ou
probe de tamanho esperado recebe fase própria, sem mascarar primeiro erro inesperado.
Se o produto não expõe a API interna, registrar NÃO_OBSERVÁVEL e só o erro disponível.

Os limites C3 de 64 KiB por evento e 30 s de espera de confirmação continuam propostas
PARA_REVISÃO, não valores empiricamente homologados. Falha de escrita, buffer inválido,
transporte ou ACK impede avanço, sem perda/truncamento silencioso. Fechar handle de
processo não resolve falha de persistência ou término. Não alterar o contrato para
obter PASS. T01 tem desenho especificado, mas observador persistente é Categoria B;
nenhuma autorização de schema Categoria A autoriza construir esse escritor.

## T02 — BLOQUEADO no erro nativo WIN-03

A distinção permanece: nativo 1/2/3, wrapper -1/0/+1, DLL/preparação, recusa pré-API,
falha efetivamente retornada e superfície não observável. Não há indução segura
aprovada do erro real com buffers válidos. NUL, mock, ponteiro inválido ou carregar
DLL errada não satisfazem o contrato. Não mexer no produto para produzir falha.

Impacto na cobertura futura: WIN-03 terá registro separado para comparação funcional
e para ramo de erro. Se a comparação algum dia passar sob autorização, esse resultado
não aprova o ramo bloqueado ou WIN-03 integralmente. A cobertura conserva 21 cenários/
19 IDs: subafirmações não se tornam cenários adicionais nem somem do denominador.
Não omitir a lacuna em agregado verde; não excluir silenciosamente o ramo da matriz.
A decisão de aceitar cobertura parcial, se houver, exige aceite explícito posterior.

## T05 — PARCIAL, W14P não aplicada

W14P foi reexaminada apenas como texto: acrescenta igualdade da árvore authority.raiz,
mas o helper da proposta continua mapa de arquivos regulares→bytes. Faltam identidade,
diretórios vazios, resolução segura, consistência concorrente e evento anterior a
asserts internos. A descrição dessas faltas não encerra nenhuma delas.

Dependências: T01 para observações completas; T03 para handles/ancestrais e bytes do
objeto certo; T04 para origem dos imports/helpers; T07 para lifetime sem destruir
recursos/evidências ou interferir no produto. O observador não pode obter recusa
artificial por manter handle cujo sharing impede o positivo: esse efeito precisa
ser tratado como falha de preparação, sem alterar share0x3 do motor.

### Estados de referência do futuro ensaio

| Marco futuro | Referência permitida | O que comparar |
|---|---|---|
| S0, após positivo completo | Pacote mínimo gravado/relido, corpo/recibo/assinatura/ator e policy legítima | Identidade, bytes e diretórios das fronteiras estáveis |
| S1, após adversarial próprio | Somente troca autorizada da entrada de fonte para link real | Registrar delta da fixture, sem tolerar mudanças extras |
| S2, após tentativa recusada | Estado observado antes de julgar o código esperado | Fronteiras protegidas contra S1 e efeitos legítimos da fixture contra S0 |
| Encerramento | Remoção só de entrada própria se identidade/posse provadas | Resultado de cleanup separado, resíduos preservados |

Não exigir que toda árvore S2 seja idêntica a S0 quando a própria fixture fez uma
troca documentada em S1, nem usar esse delta para tolerar alterações da autoridade.
Registro de mudanças autorizadas deve ser específico por entrada, não whitelist ampla.

| Fronteira | Conteúdo/identidade a observar | Lacuna restante |
|---|---|---|
| Fontes/sentinelas | Bytes completos, objeto/volume e entrada; comparar alvo por handle próprio anterior, não seguindo o link | Abertura e corrida de T03 |
| Corpos | Corpo positivo e nenhum corpo/temporário adversarial | Enumeração/consistência e identificação de efeitos |
| Âncoras/recibos/locks | Recibo, associação, assinatura e layout estável após fechamento do positivo | Backend/lifetime/compartilhamento reais |
| Chave/concessões | Igualdade privada em memória, sem conteúdo ou hash de credencial público | Acesso seguro/observação parcial de estado |
| Policies e toda autoridade | Nomes/tipos/identidades/bytes/diretórios vazios, incluindo entradas inesperadas | Snapshot integral sem reparse ou perda de evento |

Metadados de último acesso podem mudar por leitura; não equivalem a alteração de
bytes e não serão prometidos imutáveis. Dados de política que não puderem ser lidos
legitimamente permanecem NÃO_OBSERVÁVEIS, não iguais por suposição. Snapshot final
igual não prova ausência de leitura, escrita transitória revertida, exfiltração,
proteção DACL ou todo estado em memória. Essas alegações exigiriam outra observação
aprovada, não a aplicação automática de W14P.

## T06 — ESPECIFICADO, preservado com condicionantes

Preservar CLI/JSON/auditoria/DTO/exportação como planos diferentes, oráculo declarativo
congelado antes do leitor, positivo antes do conflito, duas evidências documentais
esperadas e zero divergências do gabarito. DTO do esperado não é objeto do CLI;
retorno dois sem JSON pode ser bloqueio. Não gerar XLSX fictício nem atribuir aprovação
financeira privada a fixture sintética. Conversões reais continuam bloqueadas.

T04 agora fixa o perfil de importação; T07 propõe criação suspensa/job/herança restrita.
T06 depende da revisão desses mecanismos para que stdout/stderr não escapem, fiquem
presos ou se percam. Drenagem dos dois canais é contínua para custódia externa, com
estado parcial em timeout/crash, sem aguardar só retorno normal. Ausência de EOF ou
de processo finalizado comprovado impede declarar saída completa e cleanup seguro.

O revisor futuro deve verificar que canais herdados são só os necessários e que o
escritor de evidência permanece vivo fora do job cancelado. Saídas brutas sintéticas
com valores documentais não são publicadas por conveniência; derivados agregados
sem locals/segredos. Nenhum fluxo foi executado agora. T06 continua desenho especificado,
adaptador CLI/oráculo runtime é Categoria B, não automaticamente elegível em A.

## Limite comum

C4 não promove os 19 vínculos ou os 21 cenários. Fonte primária histórica continua
faltante; sete fichas permanecem modelos. DACL D01–D10 PARA_APROVAÇÃO; Portão B
encerrado e autorização consumida; C/D/E bloqueados. Qualquer necessidade de mudar
produto, política ou ABI será proposta em escopo separado, nunca implementada aqui.
