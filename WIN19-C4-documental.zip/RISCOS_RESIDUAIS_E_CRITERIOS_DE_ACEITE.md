# C4 — riscos residuais e critérios de aceite

18/11/2026. Aceite de documentação não é aceite de código ou operação.

## 1. Impedimentos técnicos remanescentes

| Risco | Delimitação nesta C4 | Critério antes de implementar o componente B |
|---|---|---|
| Root/ancestral redirecionado | OPEN_REPARSE_POINT terminal não autentica toda resolução | Protocolo de raiz/abertura relativa por handle, ABI e semântica aprovados; sem fallback textual |
| Troca de objeto/nome | ID não prova posse do nome nem sobrevive como autoridade à exclusão/recriação | Ownership, handle vivo, pai/nome/volume/ID ligados e efeitos de share revisados |
| Tipo/estrutura lido errado | BOOLEAN/BOOL, WCHAR e ponteiros não têm o mesmo tamanho | Headers SDK e layouts do alvo, sem empacotamento artificial ou ABI Linux |
| Capacidade symlink indisponível | Não criar privilégio nem substituir por junction | Capacidade legítima futura ou NÃO_VALIDADO específico |
| Bootstrap .pth/plugin/DLL | Perfil -I/-S não torna código hostil seguro | Runtime e dependências Windows fixados, origem/carregamento e efeitos auditados |
| Origem depois do import | Side effect pode acontecer antes de inspecionar módulo | Mapa e loaders confiáveis antes do uso; revisão completa dos imports |
| Interferência do observador | Handles podem causar recusa que não viria do produto | Positivos com o mesmo observador e classificação causal de falha de preparação |
| Snapshot incompleto | W14P não cobre vazios/identidade/race/estado transitório | Modelo S0/S1/S2 e camada segura aprovados, sem segredo em evento |
| Filhos/handles desconhecidos | PID/owner/prefixo não prova recurso próprio | Herança e job aninhado revisados, criança atribuída antes de retomar |
| Cleanup destrutivo | File ID/marker/caminho abaixo da raiz não autoriza apagar | Criação atribuída, identidade/nome autenticados, sem reparse e resultado separado |
| Timeout tido como prova | Prazo não garante término da API nem desaparecimento | Evidência positiva de término/ausência; limites fundamentados e resíduo explícito |
| Journal perdido ou reescrito | ACK/hash não é prova de energia/DACL/imutabilidade | Contrato preservado, custódia e falhas de escrita/ACK revisadas; nenhuma alegação excedente |

Continuam T01/T06 ESPECIFICADO; T02 BLOQUEADO; T03/T04/T05/T07 PARCIAL. Não foi
promovido estado só pela adição de assinatura ou texto. Antes de executar qualquer
B, haverá ainda autorização própria de ensaio e verificação do código produzido.

## 2. Critérios de elegibilidade A, sem aprovar criação agora

A proposta limitada só pode avançar depois de aceitar lista exata de arquivos de
dados, campos/status e ausência de comportamento ativo. Deve ser possível inspecionar
A sem importar pacote ou criar recurso. Nenhum .py/.ps1, script, callback, comando,
referência remota de schema, descoberta de testes, avaliador runtime ou resolução de
caminho pertence a A. Tipos nativos são rótulos, não bindings.

Aceitar a definição de evento ou resultado não aceita observador/supervisor. Aceitar
um schema não autoriza executar um validador. Na futura proposta, qualquer dependência
que invoque T03/T04/T07 transfere o componente para B e bloqueia sua inclusão em A.
Não anexar status de ensaio como exemplo “observado” nem dar defaults de PASS.

## 3. Critérios de revisão nativa de B

A documentação oficial consultada fundamenta APIs e limitações, mas não autentica
o SDK, arquitetura, runtime, binários ou capabilities do Windows do usuário. Os
hashes reais desse ambiente seguem pendentes. Não executar sonda para preenchê-los
nesta etapa. Win32 retorna BOOL/DWORD/HANDLE conforme função; Native NT retorna
NTSTATUS. LastError só é significativo no caminho que o documenta; timeout e VOID
não ganham código fictício. Preservar primeiro erro e secundários separadamente.

Antes de autorizar código nativo, o revisor deve aceitar assinaturas, buffers,
alinhamento, ponteiros/lifetime, enumerações, direitos mínimos por operação, efeitos,
share e fechamento único. Uma consulta de metadata não recebe write/DELETE por
conveniência. Não instalar ACL ou elevar para abrir objeto. Falha segura preserva
o objeto e registra bloqueio, em vez de tentar acesso mais amplo.

Antes de cleanup/cancelamento, aceitar ownership, relação pai/nome, handles próprios,
job/herança/esperas e ausência confirmada. Não alterar o 0x3 do motor ou o residual
histórico. 20 ciclos/100 ms/2 s, assim como limites de journal propostos na C3, são
PARA_REVISÃO, não defaults homologados ou garantias do SO.

## 4. Cobertura e segurança permanecem limitadas

T02 não pode desaparecer da cobertura futura: comparação ordinal eventualmente
aprovada não aprova o ramo de erro, nem WIN-03 integral. Symlink indisponível não
produz PASS nativo; junction/hardlink/alias têm contratos próprios. A matriz futura
mantém 21 subcasos/19 IDs e limitações por subafirmação, sem agregado que oculte NV.

DACL continua NÃO_VALIDADO. D01–D10 PARA_APROVAÇÃO, com herança/owner e operações por
objeto/papel ainda pendentes. Mesmo token, chmod, sharing violation, job próprio,
leitura de ACL ou flags sintéticas não demonstram proteção integrada entre contas.
Não aplicar DACL manualmente para atribuir segurança ao fluxo do aplicativo.

Igualdade final de bytes não comprova ausência de leitura/exfiltração ou alteração
transitória revertida. Bootstrap é isolamento de dependências em ambiente cooperativo,
não sandbox contra código hostil de mesmo token. Se esses requisitos forem essenciais,
é necessária proposta de arquitetura/política separada, não relaxamento dos critérios.

## 5. História e custódia continuam separadas

19 vínculos PROVISORIO_SEM_FONTE, zero confirmações; sete fichas pendentes, não nodeids
recuperados. Original completa-utf8.xml da máquina Windows, comando/argv/log/ambiente,
versão física e associação do manifesto 448 continuam faltantes. O hash
19f936f1ac1c69698224b53175ec0da1beb5971674e9d284a0e0c679cdf2cedb
identifica o documento recebido, não seu uso. Não presumir existência/integridade
no caminho histórico. Não preencher matriz por memória, nomes ou contagens.

Custódia/retenção C1 são próprias, sem herdar os 90 dias de B. Não pedir raw privado.
Desvio processual Python anterior permanece declarado com efeitos não demonstrados;
comando SEM_FONTE, sem replay. A C4 não corrige retroativamente essa evidência.

## 6. Estados e parada

prontidao_para_executar=false; autorizacao_testes=PENDENTE;
runner_C=NÃO_IMPLEMENTADO; WIN01–WIN19=NÃO_VALIDADO; DACL=NÃO_VALIDADO;
C/D/E=BLOQUEADOS; CONVERSOES_REAIS=BLOQUEADAS. Portão B encerrado documentalmente,
autorização única consumida. Candidata R1-FIX 470 e baseline 770d062d29c4361d6932592883df9339bb4089bc
preservados. Sem implementação, execução, configuração ou publicação.
Entregar a C4 e parar para revisão independente.
