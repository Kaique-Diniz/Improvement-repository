# C4-C — processos, cancelamento e cleanup seguro

18/11/2026. **Somente proposta documental. Nenhum processo ou objeto de laboratório
foi criado, cancelado ou removido.** T07 permanece PARCIAL; código Categoria B não
autorizado. Não alterar motor existente, temporarios.py, share0x3 ou residual antigo.

## 1. Titularidade: o que precisa estar provado

Registro de criação exclusiva liga run/componente a raiz, pai, nome, volume, file ID,
tipo e handle próprio. Um marker, prefixo E4, owner/SID, PID ou caminho sob basetemp
não prova sozinho titularidade. File ID sozinho tampouco identifica qual nome de
hardlink pertence ao ensaio. Não atribuir automaticamente todo descendente a quem
criou a raiz: um objeto desconhecido pode ter sido adicionado por outro processo.

Arquivos criados dinamicamente por subprocesso precisam de protocolo de atribuição
revisado ou outra fronteira suficiente de criação. Essa atribuição não está resolvida
para uma árvore arbitrária de pytest; não inventar rastreabilidade por snapshot final.
Se não for possível justificar uma entrada, preservar o objeto e o laboratório,
registrar bloqueio e não iniciar exclusão recursiva. Evidência continua fora da área.

Operações destrutivas dependem da abertura/identidade de T03, inclusive pais e nome,
com proteção contra substituição entre inspeção e uso. Path normalizado, comparação
prévia ou reabertura por pathname não garantem isso. A alternativa relativa por handle
permanece candidata, não binding aprovado. Objeto inesperado/reparse/volume distinto
bloqueia; nunca seguir destino ou fazer fallback para rmtree/Remove-Item.

## 2. Recursos e processos próprios

O supervisor e o escritor de eventos ficam FORA do grupo de workers a encerrar.
O futuro grupo de processos deve ser novo, sem nome compartilhado, com handle não
herdável e somente filhos criados pelo supervisor. O mapa guarda handle e identidade
de criação; não procurar processo por nome nem reabrir PID para “recuperar” posse.
Nenhum controle de processo é isolamento contra código hostil sob o mesmo token.

Proposta de ordem: journal inicial confirmado → job próprio configurado → processo
próprio criado suspenso → atribuição ao job confirmada → herança restrita conferida
→ registro confirmado → retomada do thread. Se atribuição falhar, não retomar para
“continuar sem proteção”. Encerrar só o processo suspenso comprovadamente próprio,
registrar falha e esperar término. Se isso falhar, preservar resíduo/handles e
bloquear. Não usar breakaway, elevação ou job/conta de terceiro.

Os subprocessos descendentes e exceções de jobs aninhados precisam ser revisados
para a versão Windows real. KILL_ON_JOB_CLOSE é proteção de encerramento proposta,
sem BREAKAWAY_OK/SILENT_BREAKAWAY_OK, não prova de que todos os recursos já terminaram.
A saída de um worker não é prova de fim de todos os escritores da árvore.

## 3. APIs de processo candidatas e direitos — nenhuma executada

Convenção Windows do alvo; ponteiros/HANDLE/SIZE_T conforme perfil T03. Structs de
startup, atributos e job precisam de offsets/tamanhos contra SDK antes de binding.
Não usar layout aproximado nem converter VOID em BOOL.

| Primitiva/documentação | Assinatura documental e parâmetros de proposta | Direitos mínimos e falha segura |
|---|---|---|
| [CreateJobObjectW](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-createjobobjectw) | HANDLE (LPSECURITY_ATTRIBUTES, LPCWSTR); atributos NULL e nome NULL para objeto novo não herdável | Retorno NULL captura erro. A criação não tem parâmetro de máscara mínima; handle é próprio, sem delegação ou promessa DACL |
| [SetInformationJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-setinformationjobobject) | BOOL (HANDLE, JOBOBJECTINFOCLASS, LPVOID, DWORD); limites do job próprio, estrutura ExtendedLimitInformation revisada | JOB_OBJECT_SET_ATTRIBUTES; BOOL zero captura erro, não iniciar worker se configuração falhar |
| [CreateProcessW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw) | BOOL (LPCWSTR, LPWSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES, BOOL, DWORD, LPVOID, LPCWSTR, LPSTARTUPINFOW, LPPROCESS_INFORMATION) | ApplicationName absoluto, cmdline mutável própria, ambiente/cwd aprovados. CREATE_SUSPENDED e herança explícita, sem shell/credencial. Falha não entrega processo válido; não usar saídas não inicializadas |
| [AssignProcessToJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject) | BOOL (HANDLE job, HANDLE process); ambos próprios, antes de retomar | JOB_OBJECT_ASSIGN_PROCESS e processo PROCESS_SET_QUOTA/PROCESS_TERMINATE; falha bloqueia, sem contornar jobs existentes |
| [ResumeThread](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-resumethread) | DWORD (HANDLE thread); somente thread inicial próprio | THREAD_SUSPEND_RESUME; DWORD all-bits-one é falha, não BOOL false. Contagem anterior precisa corresponder ao estado suspenso previsto |
| [TerminateJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-terminatejobobject) | BOOL (HANDLE job, UINT exitCode); job próprio e código de cancelamento identificado | JOB_OBJECT_TERMINATE; falha registra erro. Sucesso solicita término, não comprova cleanup/EOF de logs |
| [TerminateProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-terminateprocess) | BOOL (HANDLE process, UINT exitCode); só filho próprio, inclusive suspenso ainda não atribuído | PROCESS_TERMINATE; retorno não substitui espera de término. Nenhuma execução por PID arbitrário |
| [WaitForSingleObject](https://learn.microsoft.com/en-us/windows/win32/api/synchapi/nf-synchapi-waitforsingleobject) | DWORD (HANDLE, DWORD prazo); handle próprio retido durante a espera, sem INFINITE | SYNCHRONIZE; WAIT_TIMEOUT não usa LastError como falha da API; WAIT_FAILED exige captura imediata. Não fechar handle por outro fluxo enquanto espera |
| [GetExitCodeProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getexitcodeprocess) | BOOL (HANDLE, LPDWORD); informação de término do próprio worker | PROCESS_QUERY_LIMITED_INFORMATION ou direito compatível; somente junto da espera sinalizada. Código de saída isolado não comprova morte ou PASS |

Flags de criação são descritas na [referência oficial](https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags).
A estrutura de job contém campos dependentes de tamanho de ponteiro, como SIZE_T;
não copiar bytes de exemplo x86 para AMD64. A [estrutura oficial](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information)
é referência de revisão, não atestado de que o binding existe.

## 4. Herança restrita e fechamento de recursos

STARTUPINFOEX/atributo HANDLE_LIST é a alternativa proposta para herdar somente
as pontas necessárias de stdout/stderr/canal do worker. Não herdar job, processo,
thread, segredo, handle da candidata ou escritor. bInheritHandles sozinho não é lista
positiva. A interação da lista com atributos/herança exige revisão de código nativo.

[InitializeProcThreadAttributeList](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-initializeprocthreadattributelist):
BOOL (LPPROC_THREAD_ATTRIBUTE_LIST, DWORD, DWORD, PSIZE_T). A consulta de tamanho
prevista pela API pode retornar insuficiência de buffer: registrar como preparação
esperada, não recusa funcional do produto. Allocação limitada própria e tamanho
SDK obrigatórios; erro fora desse contrato bloqueia.

[UpdateProcThreadAttribute](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute):
BOOL (LPPROC_THREAD_ATTRIBUTE_LIST, DWORD, DWORD_PTR, PVOID, SIZE_T, PVOID, PSIZE_T).
HANDLE_LIST terá apenas handles próprios e buffers vivos até CreateProcess. Falha
zero captura erro; não executar fallback de herança ampla.

[DeleteProcThreadAttributeList](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-deleteprocthreadattributelist):
VOID (LPPROC_THREAD_ATTRIBUTE_LIST). Não inventar retorno ou LastError de sucesso;
liberar a alocação própria depois conforme seu allocator, não CloseHandle.

Handles têm único responsável e encerramento ordenado. Fechar processo/thread não
os termina; usar P03-08 apenas depois do tratamento adequado e sem fechamento duplo.
Qualquer falha secundária de close é preservada com a primeira falha, nunca ocultada.
Término do worker deve preceder exclusão de seus arquivos; logs são drenados com
limite revisado. Se não há EOF/cópia consistente, manter relatório incompleto.

## 5. Exclusão candidata por identidade — ainda sem autorização

[SetFileInformationByHandle](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-setfileinformationbyhandle):
BOOL (HANDLE, FILE_INFO_BY_HANDLE_CLASS, LPVOID, DWORD), classe FileDispositionInfo.
O handle precisa de DELETE, mais consulta de identidade do perfil. A
[FILE_DISPOSITION_INFO](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_disposition_info)
usa BOOLEAN DeleteFile, de um byte, não BOOL de quatro. Struct/tamanho precisam de
revisão no SDK. Não usar DELETE_ON_CLOSE implícito, ignore-readonly, semântica POSIX
estendida ou alteração de ACL/atributos como fallback.

Efeito solicitado é destrutivo; só permitido futuramente para entrada própria já
aberta/autenticada com associação pai/nome/ID. Sucesso não comprova desaparecimento
imediato. Após fechar os handles devidos, comprovar ausência pelo pai autenticado,
sem atravessar redirecionamento ou apagar substituto. Estado delete-pending não é
arquivo removido. Diretório não vazio ou erro real bloqueia, sem remover o conteúdo
inesperado para fabricar a precondição. Hardlink exige titularidade DO NOME, não só
mesmo file ID. Essas garantias de namespace ainda dependem de T03 e revisão nativa.

## 6. Revisão dos limites 20/100 ms/2 s

**20 ciclos, 100 ms e dois segundos permanecem PARA_REVISÃO.** Não serão defaults
ativos nem garantia operacional em uma eventual implementação. C4 não encontrou
fundamento empírico nativo para adotá-los: não executou stress, medição ou sonda.
Prazo expirado só limita a espera, não certifica conclusão da WinAPI ou ausência.

Uma futura política deverá fixar orçamento total e por fase/objeto, número máximo
de observações e tratamento de chamada bloqueante com base no volume/filesystem,
quantidade de objetos, semântica de delete-pending e evidência independente. Não
repetir exclusão indefinidamente. Um pedido de exclusão por entrada pode ser limite
conservador de desenho, mas também precisa de revisão; observar conclusão não deve
reenviar a operação destrutiva. Não usar timeout como critério de PASS.

Sem orçamento aprovado ou capacidade de cancelamento própria, não iniciar o trecho
destrutivo. Se a API bloquear, o supervisor preserva a evidência e registra timeout;
não cancelar I/O de processo alheio nem alegar que matar um processo reverteu operações.
Caso se precise de primitivas adicionais de cancelamento, criar proposta separada
com ABI/ownership; CancelIoEx não é um “cancelar qualquer WinAPI” genérico.

## 7. Evidências e estados de saída

Antes de limpar, confirmar journal e relatório parcial fora do laboratório; guardar
snapshot/bytes de referência, estado dos workers, handles e mapa de propriedade.
Persistir fase, API/operação, código original Win32/NTSTATUS/errno, categoria de
objeto, profundidade/contadores, primeira falha e erros secundários. Sem nomes privados,
paths completos, segredo ou conteúdo de documento no derivado.

Estados distintos por entrada: não tentada; recusada por identidade; exclusão
solicitada; pendente; ausência confirmada; resíduo; verificação incompleta. Limpeza
só concluída se todas as entradas previstas e a raiz própria têm conclusão justificada,
sem objetos desconhecidos. Ausência sem causa observável ou identidade alterada não
vira sucesso. Falha de limpeza não apaga PASS/FAIL funcional já evidenciado, mas
impede sucesso operacional global e permanece explícita no relatório.

Em crash/timeout/falha parcial, preservar laboratório, journal, JUnit e logs. Não
executar limpeza retroativa de pasta histórica nem encerrar processo encontrado por
nome. Novo procedimento de resíduo exige autorização específica; não aplicar no
contêiner antigo. O observador pode falhar também: conservar último checkpoint e
classificar incompletude, em vez de inventar prova de remoção.

## 8. Decisão

T07 = PARCIAL. Estão delimitados candidato de contenção própria, assinaturas, direitos,
ordem, efeitos e recusa. Permanecem pendentes ABI/layouts reais, herança/job aninhado,
atribuição de cada arquivo dinâmico, vínculo pai/nome/handle resistente a troca,
conclusão de exclusão e orçamento tecnicamente justificado. Nenhum desses requisitos
é encerrado por esta descrição. Motor/candidata inalterados; nenhuma operação realizada.
