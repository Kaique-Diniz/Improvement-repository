# Pacote local EXP-04

Comece por `RESULTADOS_FINAIS.md` e `payload/docs/EXP_04_PREPARACAO.md`.
Diff completo: `EXP04.patch`. Inventário: `INVENTARIO_ALTERACOES.json`.
Manifestos: `MANIFESTO_SHA256.json`, `VERSAO_EXP04_SHA256.json`, `BASELINE_SHA256.json`.
Roteiro privado Windows: `payload/docs/EXP_04_WINDOWS.md`.
Logs/JUnit, agregado sem dados individuais e preservação: `evidencias/`.

Não executar sobre D2, R1 ou outra worktree existente. Não habilita conversão
operacional dos quatro perfis. Sem publicação autorizada para este pacote.
