# EXP-04 — resultado consolidado para revisão

Candidata isolada no baseline `770d062d29c4361d6932592883df9339bb4089bc`,
sem commits, push, PR, merge ou publicação. 23 arquivos novos/alterados: 10 de
código/configuração/empacotamento e 13 de ferramentas, testes e documentação.
O diff inclui os 18 arquivos não rastreados; não é apenas `git diff` de rastreados.
Todos os 448 arquivos finais estão no manifesto de versão. Nenhum código foi
alterado depois da rodada integral final.

## Execuções Linux efetivas

Python 3.12.14, dependências existentes, sem instalação nem `-X utf8`.

- EXP-04 final: **188 aprovados, zero falhas, erros ou skips**, um aviso conhecido.
- Seis perfis: **649 aprovados, zero falhas, erros ou skips**, um aviso conhecido.
- Suíte integral final: **2.842 aprovados, zero falhas, erros ou skips**, um aviso.
- A suíte integral é uma execução única; não é soma da suíte com rodadas focadas.
  Os 188 e os 649 são seleções já contidas no escopo integral, não se somam a ele.
- Aviso: depreciação do alias AnyIO BlockingPortal em Starlette TestClient.
- Sintaxe Python/JSON/TOML, `node --check`, `pip check`, `git diff --check`: OK.
- Os logs/JUnit compartilháveis tiveram somente caminhos do executor e hostname
  sanitizados; as contagens foram conferidas por testcase. Originais preservados
  fora da worktree, sem conteúdo individual dos anexos.

Comandos (na raiz da candidata, com o Python/venv existente):

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python -B -m pytest -q -p no:cacheprovider tests/exp04 --tb=short --junitxml=FORA_DO_GIT/focados.xml
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python -B -m pytest -q -p no:cacheprovider tests/passaredo tests/oma tests/vero tests/itajuba tests/beach_parque tests/int02 --tb=short --junitxml=FORA_DO_GIT/seis.xml
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python -B -m pytest -q -p no:cacheprovider --tb=short --junitxml=FORA_DO_GIT/completa.xml
```

## Comparação documental privada, sem ativação da régua

Os 12 anexos reais foram lidos fora do Git. A rodada final concluiu os quatro
perfis com hashes/identidades de entrada e os 448 hashes da candidata conferidos
antes e depois. Seu JSON inclui o hash do manifesto da versão efetivamente usada.
O helper externo R1 auditado permanece sem alterações. Nenhum XLSX real foi gerado.

As linhas abaixo são **hipóteses estritas em 09/11/2026**, não regras autorizadas.
São as hipóteses indicadas na pré-análise do usuário; ambas 30/60 constam do JSON.

| Perfil | Hipótese | Dívidas A | Valor original | Adicionais B calculados | Pareamento histórico limitado |
|---|---|---:|---:|---:|---|
| on_brooklin | >60 | 275 | 186206.87 | 301 | False |
| citzy_paulista | >30 | 388 | 234836.67 | 114 | True |
| panorama_diadema_club | >60 | 626 | 463704.16 | 166 | True |
| do_it_pinheiros | >30 | 730 | 306786.94 | 78 | True |

On Brooklin coincide integralmente em unidade/data/valor com o template na
hipótese >60. Seu B calculado acrescenta 301 linhas, não os zero do checkpoint.
Citzy em 14/10 >30 reproduz 387 / 210262.31; em 09/11 >30, 388 / 234836.67:
diferença temporal de uma dívida / 24574.36. Cinco linhas históricas de Citzy têm
codificação não reconhecida para pareamento; isso impede afirmar igualdade por
unidade completa, apesar da coincidência de contagens/valores históricos.

Panorama reproduz 626 / 463704.16 nas duas hipóteses históricas declaradas. A
codificação das unidades não coincide com a origem; o confronto por chave mostra
626 adicionais/626 ausentes, sem demonstrar divergência de valor ou autorização
para inferir equivalência entre blocos. B calculado acrescenta 166 linhas.

Do It reproduz 730 / 306786.94 e 78 adicionais B. Há 13 adicionais/13 ausentes
no pareamento por chave histórica, mantendo a pendência de codificação comercial.
Confirma 596 participantes, 345 unidades e 128 combinações múltiplas; todas as
134 unidades financeiras ficam com associação divisão/bloco não comprovada.
Uma linha órfã é retida sem atribuição. Não há promoção de documento/contato por
parentesco ou papel de terceiro. Cadastro anterior/atualidade não atestada também
está explícito nos três perfis BBZ; 25 divergências nominais On Brooklin são retidas.

Coincidência de totais não comprova endereço, titularidade, procedência
independente, integração ou política. `pareamento_limitado` também pode refletir
chaves presentes somente em uma hipótese/data; não autoriza concluir sua causa.

## Preservação, privacidade e pendências

Refs e 14 worktrees anteriores preservadas em HEAD, estado Git e arquivos;
oito ZIPs anteriores com SHA-256 preservado; D2 com seus 454 hashes conferidos.
Os catálogos aprovados e leitores BBZ originais mantêm os mesmos bytes. Os 13
registros preexistentes de perfis mantêm os mesmos objetos de configuração.

O pacote contém somente código, fixtures geradas por código, documentação,
manifestos, diff e agregados. Não contém PDF/XLSX real, manifesto com caminhos
privados, nomes/contatos/documentos de moradores, credenciais ou cookies. A busca
auxiliar contra 2.569 campos dos XLSX não encontrou dado individual no payload;
quatro coincidências eram somente um rótulo genérico de papel. A construção por
lista explícita e a revisão complementam a busca; regex não é prova universal de
ausência de segredos. Logs/JUnit são de testes sintéticos.

**Pendente:** políticas aprovadas dos quatro; administradora/vínculo Panorama e
Do It; aprovação dos destinos de todos; divisão/bloco/comercial; atualidade e
titularidade cadastral; endereço real autorizado; execução Windows desta candidata
e controles nativos. Não houve alteração de ACLs, persistência ou ADDR-01.
Os quatro reconhecem no HTTP, mas conversão permanece bloqueada com 422. Os seis
anteriores continuam convertendo/baixando nos testes. D2 e suas evidências não
substituem validação desta árvore BPQ-04; não foram incorporados patches C/D2.

O roteiro completo está em `payload/docs/EXP_04_WINDOWS.md`. Para reconstruir,
usar worktree nova no baseline, `reconstruir.py --pacote ... --candidata ...`;
depois `--verificar`. Recusa arquivos divergentes, extras, links e reparse points.
Erros de escrita não provocam exclusão automática: preservar a tentativa e usar
outra worktree. A execução PowerShell/NTFS nativa permanece pendente.
